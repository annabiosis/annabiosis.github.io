/*
 * The arithmetic of a random draw, with no firmware in it.
 *
 * This header is what makes the draw testable: every rule that decides a patch —
 * the character's window and the free middle it is blended with, the corner snapped
 * onto a semitone of the drone's base, the drum's pitch taken from a degree of the
 * scale in a register the corner leaves room for, the rotation that lands a pulse on
 * the downbeat, the grid — lives here as plain arithmetic over plain numbers. The
 * application calls it with its own constants and its own generator; the host test in
 * build/accept/random_host.c calls the very same functions with the same constants and
 * a seeded generator, a hundred thousand times, and checks the result.
 *
 * Nothing here touches a global, a parameter or an engine: the caller passes what it
 * knows (the drone's base frequency, the cutoff's floor and ceiling, the scale's
 * degrees) and gets a number back. That is the whole point — the model in
 * tools/random-model.js argues the design, this file is the design, and the host test
 * proves the two agree.
 */
#ifndef SYNTH_RANDOM_MATH_H
#define SYNTH_RANDOM_MATH_H

#include <math.h>
#include <stdint.h>

/* Two octaves of the widest scale fit here: twelve degrees times two. */
#define RR_DEGREE_MAX 24

/* How likely each scale is to be drawn. The modes a listener names — the two
 * pentatonics, hirajoshi, aeolian, dorian, phrygian, blues — come up three times as
 * often as the ones that are a colour rather than a home; the four that quantise
 * almost nothing are rarer still, because a draw reaching for chromatic is the one
 * case where the player's own key would be better. The order is the firmware's
 * SEQ_SCALES, and the count is asserted there. */
#define RR_SCALE_COUNT 21

/*
 * Eight characters. Each names a window for every parameter that decides what the
 * patch sounds like; the windows overlap on purpose, so two patches of one character
 * differ while both still sound like that character.
 */
typedef struct {
    const char *name;
    float cutoff[2], res[2], depth[2], rate[2];
    float lead_cutoff[2], lead_reso[2], lead_attack[2], lead_decay[2];
    float lead_sustain[2], lead_release[2];
    int   lfo_lo, lfo_hi;            /* LFO_SHAPE positions the character allows */
    float mode[3];                   /* LOW, BAND, HIGH — the filter's own shape */
    float wave[6];                   /* SINE TRI SAW PULSE SPR NOISE — the lead's */
    float perc_decay[2], perc_body[2];
    float verb[4];                   /* ROOM HALL CATH PLAT */
    float verb_size[2], verb_damp[2];
} rr_character_t;

/*
 * Eight characters. Each names a window for what decides how the patch sounds, and the
 * windows are deliberately wider than the character's centre: two draws of one character
 * have to differ, or the button is a tape loop. What a character fixes is the CENTRE.
 *
 * The weights are preferences, not bans — the shape of the filter and the lead's waveform
 * are drawn through them on every draw, which is where most of the difference between two
 * patches of one character now comes from.
 */
static const rr_character_t RR_CHARACTERS[] = {
    /* DEEP — the instrument's own voice: the corner low, a long sweep, a slow room. */
    { "DEEP", { 0.10f, 0.45f }, { 0.05f, 0.40f }, { 0.40f, 0.80f }, { 0.02f, 0.35f },
      { 0.08f, 0.45f }, { 0.02f, 0.35f }, { 0.02f, 0.30f }, { 0.40f, 0.80f },
      { 0.50f, 0.90f }, { 0.50f, 0.90f },
      0, 2,
      { 4.0f, 1.0f, 0.3f },
      { 2.0f, 1.0f, 3.0f, 1.0f, 1.0f, 0.0f },
      { 0.45f, 0.85f }, { 0.15f, 0.50f },
      { 1.0f, 3.0f, 0.5f, 0.5f }, { 0.55f, 0.90f }, { 0.25f, 0.65f } },

    /* GLASS — high and resonant, a short tail, a plate. */
    { "GLASS", { 0.58f, 0.90f }, { 0.40f, 0.75f }, { 0.10f, 0.40f }, { 0.40f, 0.85f },
      { 0.55f, 0.95f }, { 0.30f, 0.65f }, { 0.00f, 0.15f }, { 0.15f, 0.50f },
      { 0.25f, 0.60f }, { 0.15f, 0.50f },
      2, 4,
      { 0.5f, 3.0f, 1.5f },
      { 3.0f, 1.0f, 1.0f, 1.0f, 1.0f, 0.0f },
      { 0.10f, 0.40f }, { 0.55f, 0.90f },
      { 0.3f, 0.5f, 0.3f, 3.0f }, { 0.30f, 0.60f }, { 0.50f, 0.85f } },

    /* DIRT — the shaper's own territory: mid-low, wide, all four shapes welcome. */
    { "DIRT", { 0.22f, 0.56f }, { 0.15f, 0.50f }, { 0.20f, 0.60f }, { 0.30f, 0.75f },
      { 0.25f, 0.65f }, { 0.15f, 0.50f }, { 0.00f, 0.15f }, { 0.10f, 0.45f },
      { 0.30f, 0.65f }, { 0.10f, 0.45f },
      0, 4,
      { 2.0f, 2.0f, 1.0f },
      { 1.0f, 1.0f, 3.0f, 2.0f, 1.0f, 0.3f },
      { 0.05f, 0.35f }, { 0.45f, 0.85f },
      { 2.0f, 1.0f, 0.3f, 0.2f }, { 0.25f, 0.55f }, { 0.45f, 0.80f } },

    /* HOLLOW — a pulse behind a corner in the middle, a tube rather than a fold. */
    { "HOLLOW", { 0.33f, 0.68f }, { 0.25f, 0.60f }, { 0.15f, 0.50f }, { 0.15f, 0.60f },
      { 0.35f, 0.70f }, { 0.20f, 0.55f }, { 0.02f, 0.25f }, { 0.25f, 0.60f },
      { 0.40f, 0.75f }, { 0.25f, 0.65f },
      0, 3,
      { 2.0f, 1.5f, 0.5f },
      { 1.0f, 2.0f, 2.0f, 3.0f, 0.5f, 0.0f },
      { 0.25f, 0.60f }, { 0.40f, 0.75f },
      { 2.0f, 1.0f, 0.3f, 0.3f }, { 0.35f, 0.65f }, { 0.35f, 0.70f } },

    /* NOISE — a wash: no resonance anywhere, a cathedral, almost no attack. */
    { "NOISE", { 0.45f, 0.80f }, { 0.02f, 0.30f }, { 0.05f, 0.35f }, { 0.05f, 0.45f },
      { 0.45f, 0.80f }, { 0.05f, 0.35f }, { 0.25f, 0.65f }, { 0.45f, 0.85f },
      { 0.55f, 0.95f }, { 0.55f, 0.95f },
      0, 4,
      { 1.0f, 3.0f, 1.0f },
      { 1.0f, 1.0f, 1.0f, 0.5f, 2.0f, 3.0f },
      { 0.50f, 0.90f }, { 0.00f, 0.30f },
      { 0.3f, 1.0f, 4.0f, 0.5f }, { 0.65f, 0.98f }, { 0.15f, 0.55f } },

    /* BELL — a resonant corner, a long drum, a hall; the lead decays rather than holds. */
    { "BELL", { 0.33f, 0.62f }, { 0.45f, 0.75f }, { 0.05f, 0.30f }, { 0.10f, 0.50f },
      { 0.40f, 0.75f }, { 0.25f, 0.60f }, { 0.00f, 0.10f }, { 0.45f, 0.85f },
      { 0.15f, 0.50f }, { 0.45f, 0.85f },
      0, 2,
      { 1.0f, 3.0f, 1.0f },
      { 3.0f, 3.0f, 1.0f, 0.5f, 0.5f, 0.0f },
      { 0.55f, 0.95f }, { 0.50f, 0.85f },
      { 0.3f, 2.0f, 0.5f, 2.0f }, { 0.50f, 0.85f }, { 0.25f, 0.65f } },

    /* MACHINE — hard, short, a small room: the one character that is a drum machine. */
    { "MACHINE", { 0.22f, 0.51f }, { 0.20f, 0.50f }, { 0.25f, 0.65f }, { 0.50f, 0.95f },
      { 0.25f, 0.60f }, { 0.15f, 0.45f }, { 0.00f, 0.08f }, { 0.02f, 0.30f },
      { 0.15f, 0.50f }, { 0.02f, 0.30f },
      1, 4,
      { 2.0f, 2.0f, 1.0f },
      { 1.0f, 1.0f, 2.0f, 3.0f, 1.0f, 0.0f },
      { 0.02f, 0.25f }, { 0.35f, 0.75f },
      { 3.0f, 0.5f, 0.2f, 0.2f }, { 0.15f, 0.45f }, { 0.50f, 0.85f } },

    /* QUIET — the whole patch drawn back: a soft triangle, a long release, a big room. */
    { "QUIET", { 0.28f, 0.60f }, { 0.05f, 0.35f }, { 0.30f, 0.65f }, { 0.02f, 0.40f },
      { 0.20f, 0.55f }, { 0.05f, 0.35f }, { 0.20f, 0.60f }, { 0.45f, 0.90f },
      { 0.55f, 0.95f }, { 0.50f, 0.95f },
      0, 2,
      { 3.0f, 1.0f, 0.3f },
      { 3.0f, 2.0f, 1.0f, 0.5f, 0.5f, 0.0f },
      { 0.45f, 0.85f }, { 0.10f, 0.45f },
      { 0.5f, 3.0f, 0.3f, 1.0f }, { 0.70f, 0.98f }, { 0.20f, 0.60f } },
};
#define RR_CHARACTER_COUNT ((int)(sizeof(RR_CHARACTERS) / sizeof(RR_CHARACTERS[0])))
/*
 * THE CHARACTER'S PERFORMANCE, in the same order as RR_CHARACTERS: how many of the
 * figure's steps fire, how fast the figure runs, how the lead's notes are joined and how
 * far the drum is allowed to wander.
 *
 * This is here because the corner alone did not make eight characters that can be told
 * apart by ear. A dark patch at 60 BPM with a long gate and a sparse figure is a
 * different instrument from a bright one at 200 BPM with short notes, and the difference
 * is heard before any of the filter numbers are. The timbre draw writes these; the
 * structural draw adds the scale, the root and the figure on top.
 */
typedef struct {
    float density[2];       /* share of the figure's steps that fire */
    float tempo[2];         /* the tempo knob: 30 BPM at 0, 300 at 1, exponential */
    float arp[2];           /* the lead's own speed */
    float scatter[2];       /* how far a note may leave the figure */
    float gate[2];          /* how long a lead note is held */
} rr_feel_t;

static const rr_feel_t RR_FEEL[] = {
    /* DEEP   */ { { 0.20f, 0.40f }, { 0.18f, 0.32f }, { 0.45f, 0.65f }, { 0.02f, 0.10f }, { 0.55f, 0.85f } },
    /* GLASS  */ { { 0.45f, 0.70f }, { 0.45f, 0.60f }, { 0.70f, 0.90f }, { 0.05f, 0.15f }, { 0.25f, 0.55f } },
    /* DIRT   */ { { 0.55f, 0.80f }, { 0.55f, 0.75f }, { 0.60f, 0.85f }, { 0.10f, 0.25f }, { 0.20f, 0.45f } },
    /* HOLLOW */ { { 0.30f, 0.55f }, { 0.30f, 0.45f }, { 0.50f, 0.75f }, { 0.03f, 0.12f }, { 0.40f, 0.70f } },
    /* NOISE  */ { { 0.10f, 0.30f }, { 0.15f, 0.30f }, { 0.35f, 0.60f }, { 0.15f, 0.35f }, { 0.70f, 0.95f } },
    /* BELL   */ { { 0.25f, 0.45f }, { 0.30f, 0.45f }, { 0.55f, 0.80f }, { 0.02f, 0.08f }, { 0.05f, 0.30f } },
    /* MACHINE*/ { { 0.70f, 0.95f }, { 0.70f, 0.92f }, { 0.85f, 1.00f }, { 0.02f, 0.10f }, { 0.15f, 0.35f } },
    /* QUIET  */ { { 0.08f, 0.25f }, { 0.12f, 0.28f }, { 0.35f, 0.55f }, { 0.02f, 0.08f }, { 0.75f, 0.95f } },
};
#define RR_FEEL_COUNT ((int)(sizeof(RR_FEEL) / sizeof(RR_FEEL[0])))
typedef char rr_feel_matches_characters[(RR_FEEL_COUNT == RR_CHARACTER_COUNT) ? 1 : -1];
/* How likely each scale is to be drawn. The modes a listener names — the two
 * pentatonics, hirajoshi, aeolian, dorian, phrygian, blues — come up three times as
 * often as the ones that are a colour rather than a home; the four that quantise almost
 * nothing are rarer still, because a draw reaching for chromatic is the one case where
 * the player's own key would be better. The order is the firmware's SEQ_SCALES, and the
 * count is asserted there. */
#define RR_SCALE_COUNT 21

static const float RR_SCALE_WEIGHT[RR_SCALE_COUNT] = {
    3.0f, 3.0f,                               /* MN PNT MJ PNT */
    1.0f, 1.0f, 1.0f,                         /* MIX LYD M. MIN */
    1.0f,                                     /* IN-SEN */
    1.0f, 3.0f, 3.0f, 3.0f,                   /* ION DOR AEOL PHRY */
    3.0f,                                     /* HIRA */
    3.0f, 0.5f,                               /* BLUES LOCR */
    1.0f,                                     /* H. MIN */
    1.0f, 2.0f, 1.0f, 0.5f,                   /* NIKRIZ HIJAZ SABA PERSIAN */
    0.5f, 0.5f, 0.5f,                         /* WHOLE DIM CHRM */
};
/*
 * The character's share of a value; the rest comes from the free middle.
 *
 * Two shares, not one. What MAKES the character — the corner and the lead's corner — is
 * held at three fifths, because a DEEP that is not dark is not DEEP. Everything that makes
 * two patches of one character differ — resonance, sweep, envelope, the room's size and
 * damping — is only half the character, so the free middle is free to move it.
 */
#define RR_SHARE_IDENTITY 0.6f
#define RR_SHARE_TEXTURE  0.5f

/* The free middle of every range, where a character says nothing. The same 60 %
 * window the old draw used, kept as the second half of every value. */
#define RR_FREE_FLO  0.1f
#define RR_FREE_SPAN 0.8f

/* The generator is the caller's: a context and a number in [0,1). The firmware hands
 * in the hardware generator, the host test a seeded one. */
typedef float (*rr_next_fn)(void *ctx);

static inline float rr_unit(rr_next_fn next, void *ctx)
{
    return next(ctx);
}

static inline int rr_index(rr_next_fn next, void *ctx, int count)
{
    int i = (int)(rr_unit(next, ctx) * (float)count);
    if (i < 0) {
        i = 0;
    } else if (i >= count) {
        i = count - 1;
    }
    return i;
}

/* A position in a list of `count` entries, as a parameter stores it. */
static inline float rr_step01(int index, int count)
{
    if (count <= 1) {
        return 0.0f;
    }
    if (index < 0) {
        index = 0;
    } else if (index > count - 1) {
        index = count - 1;
    }
    return (float)index / (float)(count - 1);
}

/* The character's window, blended with the free middle of the same range. */
static inline float rr_window_share(rr_next_fn next, void *ctx, const float win[2],
                                    float share)
{
    const float inside = win[0] + (win[1] - win[0]) * rr_unit(next, ctx);
    const float free = RR_FREE_FLO + RR_FREE_SPAN * rr_unit(next, ctx);
    return share * inside + (1.0f - share) * free;
}

static inline float rr_window(rr_next_fn next, void *ctx, const float win[2])
{
    return rr_window_share(next, ctx, win, RR_SHARE_IDENTITY);
}

/* A texture control: the free middle gets half of it. */
static inline float rr_texture(rr_next_fn next, void *ctx, const float win[2])
{
    return rr_window_share(next, ctx, win, RR_SHARE_TEXTURE);
}

/*
 * ONE DRAW IN SIX IS WILD: it ignores the character's window and takes the whole travel.
 * Five in six stay in character, which is what makes the button a character button; the
 * sixth is what makes two presses sound like two different instruments rather than two
 * settings of one, and it is the only way the average distance between draws can be
 * larger than a uniform draw over the same middle: the wild sixth reaches the ends.
 */
#define RR_WILD_ONE_IN 4

static inline int rr_wild(rr_next_fn next, void *ctx)
{
    return rr_index(next, ctx, RR_WILD_ONE_IN) == 0;
}

/* The whole travel, when the draw is wild. */
static inline float rr_any(rr_next_fn next, void *ctx)
{
    return 0.02f + 0.96f * rr_unit(next, ctx);
}

/* A value for a control: in the character's window, or anywhere when the draw is wild. */
static inline float rr_pick(rr_next_fn next, void *ctx, const float win[2], float share,
                            int wild)
{
    return wild ? rr_any(next, ctx) : rr_window_share(next, ctx, win, share);
}
/* A weighted choice among `count` weights: the character's preference, not a ban. */
static inline int rr_weighted(rr_next_fn next, void *ctx, const float *weights, int count)
{
    float total = 0.0f;
    for (int i = 0; i < count; i++) {
        total += weights[i];
    }
    float x = rr_unit(next, ctx) * total;
    for (int i = 0; i < count; i++) {
        x -= weights[i];
        if (x <= 0.0f) {
            return i;
        }
    }
    return 0;
}

/*
 * BITE: one draw in three is pushed away from the middle of every texture control at
 * once. Without it every patch is comfortable — the window centres average out, and a
 * hundred draws in a row sound like a hundred settings of one instrument. With it a draw
 * can come out with a very short envelope and a very small room, or a long one and a very
 * big room, and the player hears the difference before reading it.
 *
 * The corner is not stretched: it is the character, and it is already snapped.
 */
static inline float rr_bite(rr_next_fn next, void *ctx)
{
    static const float BITES[8] = { 0.8f, 1.0f, 1.0f, 1.2f, 1.0f, 1.35f, 1.0f, 1.6f };
    return BITES[rr_index(next, ctx, 8)];
}

/*
 * The one combination the draw refuses. A corner under 250 Hz, Q over 3.2 and a sweep
 * over 2.4 octaves together is a blocked filter — the model found it in 1.7 % of the old
 * draws and it is the only "bad patch" left in the design. The sweep gives way, because
 * the corner is the character and the resonance is what makes the shape audible at all.
 */
static inline float rr_clean_sweep(float sweep, float cut_hz, float q)
{
    if (cut_hz < 250.0f && q > 3.2f && sweep * 4.0f > 2.4f) {
        return 0.6f;
    }
    return sweep;
}
static inline float rr_stretch(float v, float bite)
{
    const float s = 0.5f + (v - 0.5f) * bite;
    return (s < 0.0f) ? 0.0f : ((s > 1.0f) ? 1.0f : s);
}

static inline float rr_clamp01(float v)
{
    if (!(v >= 0.0f)) {
        return 0.0f;
    }
    return (v > 1.0f) ? 1.0f : v;
}

/*
 * The corner in hertz for a knob position, and the knob position for a corner that has
 * been pulled onto a semitone of `base_hz` — the drone's own base, A1 at 55 Hz.
 *
 * A corner between two notes beats against the drone it is filtering, and on a
 * sustained patch that beat is the most audible thing in the sound. The snap is in the
 * low register's own units, so the number written is the number the knob would have to
 * be turned to.
 */
static inline float rr_cutoff_hz(float v01, float base_hz, float min_hz, float max_hz,
                                 float octaves)
{
    float hz = base_hz * exp2f((v01 - 0.5f) * 2.0f * octaves);
    if (hz < min_hz) {
        hz = min_hz;
    } else if (hz > max_hz) {
        hz = max_hz;
    }
    return hz;
}

static inline float rr_cutoff_snapped(float v01, float base_hz, float min_hz, float max_hz,
                                      float octaves)
{
    const float hz = rr_cutoff_hz(v01, base_hz, min_hz, max_hz, octaves);
    const int semis = (int)lroundf(12.0f * log2f(hz / 55.0f));
    const float snapped = 55.0f * exp2f((float)semis / 12.0f);
    return rr_clamp01(0.5f + log2f(snapped / base_hz) / (2.0f * octaves));
}

static inline int rr_scale(rr_next_fn next, void *ctx)
{
    float total = 0.0f;
    for (int i = 0; i < RR_SCALE_COUNT; i++) {
        total += RR_SCALE_WEIGHT[i];
    }
    float x = rr_unit(next, ctx) * total;
    for (int i = 0; i < RR_SCALE_COUNT; i++) {
        x -= RR_SCALE_WEIGHT[i];
        if (x <= 0.0f) {
            return i;
        }
    }
    return 0;
}

static inline float rr_midi_hz(float midi)
{
    return 440.0f * exp2f((midi - 69.0f) / 12.0f);
}

static inline float rr_hz_midi(float hz)
{
    return 69.0f + 12.0f * log2f(hz / 440.0f);
}

/*
 * The drum's pitch, in hertz. Three rules narrow the choice, and each one is in the
 * model's report:
 *
 *   the register follows the corner — a corner above 1.2 kHz takes the bottom out of
 *   the drone, so the drum is the one left holding it and must sit in the bass;
 *
 *   a second or a seventh against the drone's middle register is a mistake rather than
 *   a colour, so those degrees are not offered at all;
 *
 *   tonic, fifth and octave are three times as likely as the rest, because that is
 *   where a drum under a drone wants to be.
 */
static inline float rr_drum_pitch_hz(rr_next_fn next, void *ctx,
                                     const int8_t *degrees, int len,
                                     int root_midi, int drone_midi, int bass_only)
{
    float hz[RR_DEGREE_MAX];
    float weight[RR_DEGREE_MAX];
    int count = 0;
    float total = 0.0f;

    /*
     * The register is an absolute one and the root is not, so the notes are enumerated
     * by MIDI number and tested against the scale rather than transposed from the root:
     * a root high enough to put every degree above the drum's window would otherwise
     * leave nothing to choose from, which is how a draw ends up with a drum a seventh
     * away from the drone.
     */
    for (int note = 24; note <= 96 && count < RR_DEGREE_MAX; note++) {
        const float f = rr_midi_hz((float)note);

        if (f < 35.0f || f > 7040.0f) {
            continue;
        }
        if (bass_only ? (f > 87.0f) : (f < 70.0f || f > 175.0f)) {
            continue;
        }

        const int semis = ((note - root_midi) % 12 + 12) % 12;
        int member = 0;
        for (int i = 0; i < len; i++) {
            if (degrees[i] == semis) {
                member = 1;
                break;
            }
        }
        if (!member) {
            continue;
        }

        const int iv = ((note - drone_midi) % 12 + 12) % 12;
        if (iv == 1 || iv == 2 || iv == 10 || iv == 11) {
            continue;
        }

        hz[count] = f;
        weight[count] = (semis == 0 || semis == 7) ? 3.0f : 1.0f;
        total += weight[count];
        count++;
    }

    if (count == 0) {
        return rr_midi_hz((float)(root_midi + 12));
    }

    float x = rr_unit(next, ctx) * total;
    for (int i = 0; i < count; i++) {
        x -= weight[i];
        if (x <= 0.0f) {
            return hz[i];
        }
    }
    return hz[count - 1];
}
/* The grid: eight, twelve or sixteen steps, weighted 2:3:5 — the more steps, the less
 * often, because a sixteen-step figure at speed is a different piece. */
static inline int rr_grid(rr_next_fn next, void *ctx)
{
    static const int weights[3] = { 2, 3, 5 };
    static const int grids[3] = { 8, 12, 16 };
    int x = rr_index(next, ctx, 10);
    for (int i = 0; i < 3; i++) {
        x -= weights[i];
        if (x < 0) {
            return grids[i];
        }
    }
    return 8;
}

/*
 * One wet budget, shared out. Three mixes drawn independently average one and a half
 * wet levels, which is three effects at once on nearly every draw — 95 % of the old
 * draws, by the model's count. Here the total is one draw and the split is three, so
 * the room is always a room and the delay is always a decoration on it.
 */
static inline void rr_wet_budget(rr_next_fn next, void *ctx, float *delay_mix,
                                 float *chorus_mix, float *verb_mix, float *feedback)
{
    const float wet = 0.35f + 0.60f * rr_unit(next, ctx);
    const float wd = 0.30f + 0.90f * rr_unit(next, ctx);
    const float wc = 0.20f + 1.00f * rr_unit(next, ctx);
    const float wv = 0.30f + 0.90f * rr_unit(next, ctx);
    const float share = wd + wc + wv;

    *delay_mix = wet * wd / share;
    *chorus_mix = wet * wc / share;
    *verb_mix = wet * wv / share;

    float fb = 0.25f + 0.5f * rr_unit(next, ctx);
    if (*delay_mix > 0.25f && fb > 0.55f) {
        fb = 0.55f;                 /* a long tail on a loud send is a wash */
    }
    *feedback = fb;
}
/* The rotation that puts a pulse on the first step. A rotation drawn at random leaves
 * the downbeat empty 44 % of the time — the model measured it — and a figure that
 * starts with a rest is a figure the player hears as late. */
static inline int rr_rotation(rr_next_fn next, void *ctx, int steps, int pulses)
{
    if (pulses < 1) {
        pulses = 1;
    }
    if (pulses > steps) {
        pulses = steps;
    }
    const int j = rr_index(next, ctx, pulses);
    const int pos = (int)lroundf((float)j * (float)steps / (float)pulses) % steps;
    return (steps - pos) % steps;
}

#endif /* SYNTH_RANDOM_MATH_H */
