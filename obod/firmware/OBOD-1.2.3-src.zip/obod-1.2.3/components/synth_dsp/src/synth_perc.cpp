/*
 * Percussion: noise, a resonant band-pass, a gate, and a tone that follows the band.
 *
 * This is deliberately not a sixth engine layer. The engine's voices are pitch
 * oscillators with an envelope and a filter each; a drum is the opposite shape —
 * noise, a filter that MOVES, and a gate that closes in milliseconds — and none of
 * the engine's voice machinery would have been reused. The DSP below is small
 * enough to write rather than to bend something else into.
 *
 * The filter is trapezoidal (Zavalishin's TPT form), the same topology the drone
 * and lead filters use. A Chamberlin state-variable filter is the usual choice in a
 * voice like this and is a little smaller, but its stability bound depends on
 * resonance — at the top of this voice's Q range it can be pushed into oscillation,
 * and a percussion voice that howls when a knob is turned is not a percussion
 * voice. The TPT form is stable at any cutoff and any Q.
 *
 * It is also where the module's cost has always been. The coefficients were once rebuilt
 * for every sample of every tail: 235 instructions and six calls per sample per voice,
 * five of them libm — exp2f, tanf, and three __divsf3 inside perc_coeffs. That count is
 * from objdump of the built object. PERC_COEFF_STEP made the rebuild rare where the centre
 * does not move, and that stopped three long tails from costing 3200 us of a 2666 us
 * block, with 83% of blocks missing their deadline.
 *
 * WHAT WAS LEFT, AND WHAT IT COST. A block that STARTS a hit still measured 2673-3046 us
 * against the 2666 us budget on the instrument, because the dive itself is the one time
 * the centre moves on every sample: at ENV 1 with the shortest gate the schedule asks for
 * a rebuild at 127 of the 128 samples of every voice, so three voices starting together
 * are 380 rebuilds in one block. Each rebuild was nearly all library: tanf() is a 70-byte
 * front around a 492-byte kernel that calls a 1020-byte argument reduction for any centre
 * above a quarter of the sample rate — which is most of this voice's range — plus five
 * __divsf3 calls, a sqrtf() and the exp2f() in the caller.
 *
 * The sound is the CENTRE the coefficients are built at and the filter's own state, not
 * the library call that turns the centre into a tangent. The noise-only path, which is
 * the whole voice at BODY = 0 and every hit the instrument plays by itself, now takes
 * perc_tan_pi(), perc_exp2() and two hardware divides: two minimax polynomials and an
 * exponent built with a shift, with no libm call left. The BODY tone keeps the
 * old libm arithmetic bit for bit, because its rotation is integrated over the whole tail
 * and a coefficient that differs in the last bit would not stay in the last bit; a hit
 * with any tone in it is therefore exactly the hit it was. See perc_coeffs(), and the
 * measured sample comparison in the report: the worst difference over 46 crafted corners
 * of the knobs and 700 random hits is -110 dBFS, with the tone cases at exactly zero.
 *
 * A stolen hit is struck from inside the render loop, so its perc_strike() cost is also
 * on the block; that is a few hundred cycles and has not been touched (see perc_strike()).
 *
 * The centre of the filter is the note of the hit, and the pitch envelope drops it
 * over the decay — or over PERC_ENV_FALL_MAX_MS when the decay is longer, which is
 * what a kick is made of. That fall is the whole difference between a hi-hat, a tom
 * and a kick, and at ENV = 0 the voice is a hi-hat and nothing else. The envelope is
 * measured in octaves rather than in hertz so that the knob does the same thing at
 * 100 Hz and at 4 kHz.
 *
 * THE BEATER. Everything above is a band of noise swept down to a note, and a band takes
 * time to ring up: at Q 2.05 and 35 Hz that is Q/(pi*fc), 18 ms, against 3 ms at the
 * factory tom's 214, so the low corner's loudest of six realizations peaks at 0.528 where
 * the tom's is 0.965 — 5.2 dB down — and never reaches the ceiling the peak table was
 * calibrated against. What is missing is a beater — a few milliseconds of broadband noise
 * at the strike, taken from the filter's own high-pass node and mixed in before the
 * limiter — and its level is weighted by PITCH so that every hit at 140 Hz and up stays
 * bit-for-bit the hit it always was. See PERC_BEATER_OCT, PERC_CLICK_GAIN and
 * PERC_CLICK_MS.
 *
 * THE BEND IS TWO STAGES. PERC_ENV_FALL_MAX_MS fixed how long the centre takes to fall;
 * the fall itself was one pole, so even in the log domain it was still moving at the 56th
 * millisecond and read as a tom's tail rather than a beater's. The first PERC_FALL_FAST of
 * the dive now goes at one and a half times the old slope and the last of it is left to
 * the plain envelope, which puts the same kick on its body at 41 ms — inside the 20-50 ms
 * a kick's pitch drop is made of — with the first octave of the bend taking 7.2 ms where
 * the plain fall spent 11.3. See PERC_FALL_FAST, which is also where what this does to
 * the rebuild schedule is measured.
 *
 * Three voices, each with its own noise generator per channel. Three because a hit
 * at a sixteenth-note rate with a long decay needs two or three to overlap, and a
 * fourth would never be heard; per channel because a mono point in a stereo room
 * sounds like a click track.
 *
 * BODY crossfades that noise against a sine at the same centre, which is the balance
 * between the drum's noise and its tone. The sine is not a second source to tune: it
 * runs at the centre the filter's coefficients were last built at, so it glides down
 * with the hit and a kick keeps its bend with the knob up. The bottom of the knob is
 * not "almost no tone" — the tone is not generated at all there, and the noise leaves
 * through exactly the expression it did before the knob existed, because the one thing
 * this control must not do is change the sound it grew out of.
 *
 * RES is no longer a knob. The application sends the factory value whatever the stored
 * patch holds, so the resonance the peak and the level were calibrated at is the one in
 * force, and the mapping below is untouched.
 *
 * THE VOICES ARE THE INSTRUMENTS. Five of them: one per lane of the kit — kick, snare, hat,
 * tom — and one for the drum played from the keyboard. A lane cannot reach another lane's
 * voice, so a dense bar never takes the hat away to make room for the kick, which is what it
 * used to do: three voices over four lanes meant a four-on-the-floor bar stole the hat under
 * every kick, and that is the hit the ear notices missing. Within a lane the voice is
 * monophonic, which is what a drum is: a second hit on the same instrument takes over the
 * same voice, and a snare roll is a roll rather than a chord of snares.
 *
 * A hit on a voice that is still sounding FADES the tail rather than cutting it. At a
 * sixteenth-note rate with the gate at 1.5 s the old tail is still at -15 dB, so an instant
 * cut is a step on nearly every hit — measured at -23.0 dBFS at a sixteenth note, -15.5 dBFS
 * at a 32nd and -6.4 dBFS at a 64th, where the step is as large as the signal's own largest
 * sample-to-sample jumps. That step feeds a chorus, a delay and a reverb, and all three
 * repeat it.
 *
 * Shortening the decay as the figure gets denser was rejected here, and the limiter below
 * is what was taken instead: this module is never told how dense the figure is, and a decay
 * that changed inside the voice would make the instrument unpredictable. Two milliseconds
 * of latency on a stolen hit is inaudible; a decay that moves under the hands is not.
 *
 * The app tried the rejected thing anyway, for a real complaint:
 * a ceiling on the decay, computed from the euclid ring, so that no more than three tails
 * could overlap. It did not cure the complaint, because the complaint was not overlap — the
 * crackle was this module's coefficients being rebuilt every sample of every tail, which is
 * what PERC_COEFF_STEP fixed. The ceiling was removed again once that was measured, and
 * DECAY now means what the knob says.
 *
 * Every knob mapping is exported, because the display prints these numbers: a
 * readout that disagreed with what is being heard would be worse than no readout.
 */

#include "esp_attr.h"
#include "synth_dsp.h"


#include "esp_heap_caps.h"
#include "esp_log.h"

#include <math.h>
#include <stddef.h>
#include <string.h>

#include "esp_log.h"

namespace {

constexpr const char *TAG = "synth_perc";

/*
 * ОДИН КАНАЛ, А НЕ ДВА: ударка сводится в центр.
 *
 * Было два независимых потока шума, по потоку и полосовому фильтру на канал, и ударка от
 * этого ширилась в стерео. Стоило это ровно вдвое: два шума, два SVF, две пары состояний на
 * каждый голос на каждый отсчёт. На шести голосах ударка занимала тысячу микросекунд блока —
 * восемнадцать процентов бюджета, больше, чем реверб.
 *
 * Но ширина эта была не музыкальной, а побочной: два разных шума давали не панораму
 * инструмента, а разный шум в ушах. Настоящая драм-машина монофонична на инструмент и
 * ставится в микс панорамой; здесь панорамы нет, значит центр. Поэтому канал один, а в оба
 * уха он идёт с равной мощностью — 0.707 на сторону, — и на слух громкость та же.
 */
constexpr int PERC_CHANNELS = 1;

/* To же число для препроцессора: constexpr ему не виден. */
#define PERC_MONO 1

/* Равная мощность при своде моно в стерео: 1/sqrt(2) на сторону. */
constexpr float PERC_MONO_PAN = 0.70710678f;

constexpr float PERC_PI = 3.14159265358979f;
constexpr float PERC_TWO_PI = 6.28318530717959f;

/*
 * The knob ranges.
 *
 * Decay is exponential between 20 ms and 1.5 s because the ear hears decay times
 * that way: a linear knob would spend most of its travel between two long tails
 * nobody can tell apart and almost none of it between a click and a thud.
 *
 * Pitch spans seven and two thirds of an octave, from 35 Hz, which is below what any
 * speaker in the box will reproduce and is felt rather than heard, to 7040 Hz, which is a
 * hat. One knob covers kick, snare, tom and hat. The bottom moved from 55 Hz to 35 Hz,
 * and the SPAN moved with it rather than the top: 7040
 * is log2(7040/35) octaves above the new floor, which is where 7.65 comes from, so the hat
 * end of the knob is exactly where it was and only the bottom of the travel opened up.
 */
constexpr float PERC_DECAY_MIN_MS = 20.0f;
constexpr float PERC_DECAY_MAX_MS = 1500.0f;
constexpr float PERC_DECAY_SPAN = 6.2288f;      /* log2(1500 / 20) */

constexpr float PERC_PITCH_MIN_HZ = 35.0f;
constexpr float PERC_PITCH_OCTAVES = 7.65f;     /* log2(7040 / 35) */

/*
 * The trigger's pitch ratio, bounded at both ends.
 *
 * The ratio is the interval a MIDI note asks for, and the application holds it to one
 * octave either way, so these are the bounds of the ARITHMETIC rather than of the
 * instrument. The floor is there for the denormal: a ratio of 1e-45 passes every
 * comparison against zero and still makes pitch_hz a denormal, and sqrt(Q / pitch_hz)
 * in perc_strike() then overflows to infinity — the case a range test cannot see. The
 * ceiling keeps the product finite at the top of the knob, where 16 already asks for
 * 112 kHz. Nothing musical is touched: 16 is four octaves, and twelve semitones either
 * way is the widest interval the input can produce.
 */
constexpr float PERC_RATIO_MIN = 1.0f / 16.0f;
constexpr float PERC_RATIO_MAX = 16.0f;

constexpr float PERC_Q_MIN = 0.7f;
constexpr float PERC_Q_SPAN = 4.43f;            /* Q = 15 at the top of the knob */

/*
 * How far the centre may fall over a hit, in octaves at the top of the ENV knob.
 *
 * Five, and the last two are the deeper dive: three octaves from 35 Hz start
 * the centre at 280 Hz, which is a kick's bend, and the dive asked for beyond it is deeper
 * and meaner — "clickier and more laser-like". Five puts the same knob at 1120 Hz from
 * the bottom of the scale, and nothing else about the knob moves: ENV still means
 * octaves, the display still reads them out (to 5.0 OCT), and an ENV of zero still
 * leaves the centre standing exactly where PITCH put it, because a zero depth makes the
 * rebuild threshold 1.0 and the centre is never rebuilt at all.
 *
 * WHAT IT COSTS. The coefficients are rebuilt whenever the centre crosses
 * PERC_COEFF_STEP, and the hit's octave depth is what that threshold is divided by, so a
 * deeper dive rebuilds more often over the same envelope. Measured per voice on
 * tools/perc_body_check.py, at ENV 1: the corner the comment below quotes, a gate long
 * enough for PERC_ENV_FALL_MAX_MS to be what sets the fall, goes from 42 rebuilds in one
 * 128-sample block to 64, and from 382 over the hit to 609. The factory patch's own ENV of
 * 0.27 — 1.35 octaves, the same depth the old 0.45 gave against a three-octave top — goes
 * from 19 to 31 per block and from 107 to 175 over the hit. The worst corner of
 * all does not move: a gate short enough that the fall is as fast as the gate rebuilds at
 * 127 of the 128 samples a block can hold, at either depth — that is the per-sample case
 * PERC_COEFF_STEP exists to bound. The staircase itself does not get coarser: the step is
 * PERC_COEFF_STEP in octaves either way, 8.6 cents, so this is a cost in time and not in
 * sound. See PERC_COEFF_STEP for the budget the counts are measured against.
 *
 * AND WHERE IT IS WASTED, AND WHAT WAS DONE ABOUT IT. At PITCH 1 with ENV 1 the demanded
 * centre is above the clamp for the first two thirds of the dive, so most of those rebuilds
 * would hand perc_coeffs() the frequency the voice is already running at — 349 of the 557
 * on that same port. An unchanged centre gives unchanged coefficients, so they are
 * bit-transparent and perc_coeffs() now returns before doing the work: at 3 octaves the
 * max-pitch corner drops 157 of its 365, at 5 octaves 349 of 557. On the depth the factory
 * patch uses it drops nothing at all, because that depth never leaves the clamp — which is
 * why this is not what the drum's cost fell by, and why it was worth doing only alongside
 * the change that replaced the tone's per-sample sinf() with a rotation. The counts above
 * are what the SCHEDULE asks for, not what the firmware pays: subtract `pinned` for the
 * second figure.
 *
 * The depth never reaches the filter unclamped: perc_coeffs() holds the centre to 0.45 of
 * the sample rate, so the deepest dive from the highest PITCH lands at 21.6 kHz — below
 * Nyquist, where tan() is still 6.3 and the trapezoidal form stays stable.
 */
constexpr float PERC_ENV_MAX_OCT = 5.0f;

/*
 * How long the centre may take to fall, whatever DECAY says — the one thing that was
 * missing for a kick, and it was speed rather than range.
 *
 * Five octaves from 35 Hz start the centre at 1120 Hz, and a kick's bend is about two and
 * a half octaves above the body, so the travel this knob asks for was never the problem.
 * What a kick could not have is a fall as long as the gate: the fall used to BE the gate's
 * time constant, so at DECAY 1.5 s the centre glided down for a second and a half —
 * measured with this cap removed on tools/perc_body_check.py, within a third of an octave
 * of the body only at 588 ms and within a semitone at 898 ms. That is a tom bending down. A
 * kick's bend is the beater's: over in tens of milliseconds, leaving the drum the rest of
 * the gate to speak at its own note.
 *
 * 150 ms is that fall's own -60 dB point, the same convention PERC_TAU_SCALE gives the
 * gate, and it puts the same hit within a third of an octave of the body at 58 ms and
 * within a semitone at 89 ms. It costs the dive some level, measured per channel over 16
 * noise realizations on that same port when the knob's floor was still 55 Hz and the factory
 * PITCH 0.28: the corner hit peaks at 0.760 instead of 0.908 (-1.55 dB) with 2.8 dB less RMS
 * in its first 60 ms, because the band is swept past each frequency before it can ring — and
 * the typical hit lands clear of the limiter's knee instead of on it, where 0.908 sat. The
 * gate, the gain and the centre the fall lands on are untouched, so the body and the tail are
 * what they always were — the default patch, the snare and the hat are bit-for-bit the same
 * hits — and they are just reached in time to be heard as a kick.
 *
 * THE FIFTH OCTAVE IS LOUDER AT THE TOP. Deepening the dive from three octaves to five moves
 * the peak of that same corner from 0.944 to 0.975 on the port above (ENV 1, a 1.5 s gate, one
 * channel, at the PITCH the factory now ships), and the factory patch at ENV 1 from 0.974 to
 * 0.988. The limiter's 0.85 knee is inside the loudest dives either way, so what the extra
 * depth buys at the top of the ENV knob is a compressed transient rather than a louder hit:
 * the first 60 ms of the factory patch gain 3.3 dB of RMS (0.148 to 0.218) while its peak
 * moves by 0.12 dB. If that reads as squashed where the extra depth is meant to buy a meaner
 * hit, the place to spend it is PERC_GAIN and not this number, and nothing here has been
 * changed to do that.
 *
 * min() and not a replacement: every hit whose gate is shorter than this is bit-for-bit
 * what it was, which is the lower 47 percent of the DECAY knob with the default patch
 * inside it, and nothing on the display has to move — DECAY still means the gate, and
 * ENV still means the depth in octaves.
 *
 * What it costs in the filter: the coefficients are rebuilt whenever the centre crosses
 * PERC_COEFF_STEP, and a faster fall crosses it more often — 64 rebuilds in one
 * 128-sample block, per voice, at the corner this cap is for with the full five octaves of
 * ENV, against 8 with the fall tied to the gate (measured on tools/perc_body_check.py, which
 * prints both). That is half of the 128 per block, one per sample, that a full ENV with the
 * shortest gates already costs today — 127 of 128, measured on that same port at either
 * depth — and that PERC_COEFF_STEP was added to bound, so the module's worst case is still
 * its own; three voices diving at once on a dense figure is the number to measure again if
 * this ever moves.
 */
constexpr float PERC_ENV_FALL_MAX_MS = 150.0f;

/*
 * THE BEATER: what the voice was missing, and the one number that decides how much of it
 * any given hit gets.
 *
 * The band is what makes the hit, and a band takes time to ring: Q 2.05 at 35 Hz is rung
 * up over Q/(pi*fc), 18 ms, so the first thing the ear gets from a kick is a hump that is
 * already falling by the time it arrives. Measured on tools/perc_kick_check.py over the
 * three voice seeds and both channels, the low corner's loudest peak is 0.528 against
 * 0.965 for the factory tom — the low corner is 5.2 dB down on a tom because a tom's band
 * rings up in 3 ms and a kick's in 18 — and the ceiling the peak table is calibrated
 * against is never reached there, so that corner gets no harmonics out of the limiter
 * either. A beater is what fills the hole: a few milliseconds of broadband noise at the
 * strike, which is what a beater is, added BEFORE the limiter so that the sum it drives is
 * the sum the limiter sees.
 *
 * WHERE IT COMES FROM. The filter's own high-pass node, v0 - BP - LP, which the TPT
 * topology hands over beside the band-pass tap the loop already computes: no second noise
 * source, no second draw from the generator, no new state in the sample path. Its corner
 * is the filter's centre, so the click is the part of the hit that is ABOVE the drum's own
 * note — a thwack at 35 Hz, where the band has nothing to say and the ear has nothing to
 * hear, and the top octave at 7 kHz, where a hat is already a click.
 *
 * HOW LONG. PERC_CLICK_MS is its -60 dB point, the same convention the gate and the
 * steal's fade use, and it is measured from the END of the voice's attack: the click is
 * held at full while the 1 ms attack rises, because that attack already IS the beater's
 * rise and a second ramp in front of it would only eat the transient. Held through the
 * attack and released over 3 ms, the click is a 4 ms thwack. Measured per realization on
 * tools/perc_kick_check.py, the low corner's time to 90% of its own peak falls from 1.56 ms
 * to 0.98 ms and the RMS of its first 5 ms rises 5.6 dB, 0.1021 to 0.1947, while its RMS
 * over the whole gate moves 0.0371 to 0.0399: the beater is a transient and not a level.
 * Length is a shape question and not a level one, and the same port says which shape: at
 * 1 / 2 / 3 / 5 / 8 ms the peak is 0.817 / 0.865 / 0.882 / 0.896 / 0.904 while the RMS of
 * the first 20 ms is 0.1163 / 0.1189 / 0.1210 / 0.1250 / 0.1311. The last five of those
 * milliseconds buy 0.2 dB of peak and 0.7 dB of body, and they buy the body by ringing
 * into the drum the band is already becoming — which is the one thing a beater is not.
 *
 * HOW LOUD, AND WHY THE PEAK TABLE IS DIVIDED BACK OUT. PERC_CLICK_GAIN is the beater's
 * level against the noise's own gain, and it is deliberately NOT multiplied by
 * perc_decay_comp(): that table exists because the maximum of a noise process grows with
 * the number of samples the gate draws from, and a beater's peak does not grow with the
 * gate at all — a beater is the same beater whether the head rings for 20 ms or 1.5 s. So
 * the click's gain divides the table out and is the same at every DECAY. Measured on the
 * port, that makes the low corner's peak stop depending on the gate: 0.983 / 0.882 / 0.864
 * at DECAY 0.00 / 0.80 / 1.00 with the beater, against 0.372 / 0.259 / 0.257 without it —
 * 1.1 dB of spread against 3.2 — which is the flatness perc_decay_comp() promises at the
 * default PITCH and could not deliver at 35 Hz.
 *
 * The level itself is set so that the TYPICAL hit of that corner lands where the table
 * aimed every other corner. Measured over the six realizations at the low corner with the
 * weight at 1: median peak 0.749, against PERC_PEAK_TARGET 0.781 and the 0.85 knee — 0.37
 * dB under the target and 1.1 dB under the knee, with the loudest of the six crossing the
 * knee and coming back rounded (0.882 to 0.876). That is the bargain the table already
 * strikes everywhere else: the median hit is the identity exactly, and the loud tail of a
 * noise process is what the limiter is for. Nothing leaves this module above full scale at
 * any corner, and nothing did before the beater either: the loudest of them, ENV 1 with a
 * 1.5 s gate, goes from 0.984 sent to 0.986 and the shortest gate with ENV 1 from 0.983 to
 * 0.986, because both were already deep in the limiter — their pre-limiter peaks are above
 * twice full scale — and a corner that reaches the curve reaches the same place on it.
 *
 * WHY IT FADES OUT WITH PITCH, AND WHY THAT IS NOT A KNOB EITHER. The weight is 1 at the
 * bottom of the PITCH knob and 0 at PERC_BEATER_OCT octaves above it — 140 Hz — so every
 * hit from the factory tom upward is the same hit BIT FOR BIT, beater and fall shape
 * included: the low corner is the one with the ring-up problem, and 140 Hz and up is where
 * a band is already a beater. The weight is linear in octaves because the knob is, so a
 * kick with its body at 50 Hz gets three quarters of the beater and one at 100 Hz a
 * quarter, and nothing above the reach is a different instrument. It is read from
 * v->pitch_hz at the strike, so a MIDI note that transposes the drum out of the reach
 * loses the beater with the rest, exactly as it already loses the tone and the
 * compensation.
 *
 * WHAT IT COSTS. One compare per sample per voice for the life of a voice, which is what
 * stops the branch once the click is over, and while the beater is alive — 4 ms of a hit —
 * two multiplies for its envelope and, per channel, the high-pass node's two subtractions
 * and one multiply-add inside the tap the loop already computes: ten floating-point
 * operations per active voice per sample at the very front of a hit, three times that with
 * three voices sounding, and one compare per voice after the click is gone. No libm call, no
 * new state in the sample path, and the filter, the gate, the pitch fall and the ceiling are
 * untouched, against the 235 instructions per sample per voice the header records.
 */
constexpr float PERC_BEATER_OCT = 2.0f;      /* the beater's reach: 35 -> 140 Hz */
constexpr float PERC_CLICK_GAIN = 0.05f;
constexpr float PERC_CLICK_MS = 3.0f;        /* -60 dB, measured from the attack's end */

/*
 * PUNCH's four numbers: how far the attack travels, and how the beater's click rides the knob.
 *
 * PERC_PUNCH_ATTACK_OCT is the attack's span ACROSS THE WHOLE TRAVEL, in octaves: six, so the
 * centre is 1 ms and each end is three octaves away from it — a 0.125 ms snap at 1 and an 8 ms
 * swell at 0. Eight is a swell and not a hit, which is what the bottom of the travel is for; an
 * eighth of a millisecond is six samples at 48 kHz, which is a step, and that is what the top
 * is for. The centre is exactly 1 ms because the exponent is zero there, not because the
 * arithmetic happens to land there.
 *
 * The click's own law is a straight line through exactly 1 at the centre: its gain is
 * MIN + SPAN * punch, so the centre multiplies the beater's share by one and the ends by a
 * quarter and by 1.75. Above the centre the voice also carries a click that does not belong
 * to the beater at all — PERC_PUNCH_EXTRA times PERC_CLICK_GAIN at the top — because the
 * beater's share is zero for every lane above 140 Hz, which is most of a kit's hats and half
 * its snares: without it the knob would be felt on the kick alone.
 */
constexpr float PERC_PUNCH_ATTACK_OCT = 6.0f;
constexpr float PERC_PUNCH_CLICK_MIN = 0.25f;
constexpr float PERC_PUNCH_CLICK_SPAN = 1.5f;
constexpr float PERC_PUNCH_EXTRA = 2.0f;
constexpr float PERC_PUNCH_EXTRA_FROM = 0.5f;

/*
 * THE SHAPE OF THE FALL, and why the dive needed one.
 *
 * PERC_ENV_FALL_MAX_MS settled how LONG the centre takes to fall and left the shape of it
 * to a plain one-pole, which spends the dive evenly in the log domain. Measured on the
 * port, the canon kick — PITCH at the floor, ENV 0.50, a 197 Hz top over a 35 Hz body —
 * crossed 60 Hz at 26 ms and was still moving at 40 Hz at 56 ms. A kick's bend is the
 * beater's, over in tens of milliseconds; a fall still travelling a fifth of an octave at
 * the 55th millisecond is a bend heard as a tom's tail.
 *
 * So the fall is two stages. The swept value is
 *
 *     sweep = env * (fall_lin + fall_quad * env)
 *
 * with fall_quad = PERC_FALL_FAST and fall_lin = 1 - PERC_FALL_FAST: the squared half is
 * fast where the band is high, where the filter rings up in a fraction of a millisecond
 * and can follow the sweep, and the plain half carries the end of the dive, where the
 * ring-up is the sound. The same canon kick now crosses 60 Hz at 17 ms and reaches 40 Hz
 * at 41 ms — inside the 20-50 ms a kick's pitch drop is made of, where the plain fall spent
 * 56 — and the first octave of that bend takes 7.2 ms against 11.3; at the top of the ENV
 * knob, where the dive is five octaves deep, the same first octave takes 3.1 ms against
 * 4.9. The two halves meet at the top: 1 - PERC_FALL_FAST of the dive is taken at
 * (1 + PERC_FALL_FAST) times the old slope, which is the 1.6 of the measurement above.
 *
 * WHAT IT DOES NOT CHANGE, AND THE ONE THING IT DOES. The same octaves are swept, in the
 * same order, and the rebuild is still triggered on a step of PERC_COEFF_STEP / env_oct —
 * but of the SWEPT value and not of the envelope. That threshold is untouched at 8.64
 * cents, and it is a threshold and not a bound: a rebuild fires when the travel since the
 * last one EXCEEDS it, so the step the centre actually takes is that travel and can be one
 * sample wider than the threshold. What the shape changes is how much wider. Measured on
 * tools/perc_kick_check.py, the worst step over a hit is 10.72 cents on the factory tom
 * either way (the beater does not reach it), 10.28 against 9.70 at the low corner, 17.26
 * against 12.93 at ENV 1 with a long gate and 17.04 against 16.90 at the shortest gate —
 * where the gate itself is 20 ms long and the envelope moves further in one sample than the
 * threshold asks for, which was true before the shape existed. The counts move with the
 * times, by a few percent and in either direction, because a wider travel crosses the
 * threshold in fewer samples: 175 against 175 on the factory tom, 134 against 132 on the
 * low corner, 609 against 561 at ENV 1 with a long gate, 109 against 110 at the shortest
 * one. Their TIMES are the thing that moves, and they move earlier where the dive is fast:
 * the low corner's worst 128-sample block goes from 15 rebuilds to 22 and ENV 1's from 64
 * to 82, against the 128 a block can hold and the 127 the shortest gates already cost.
 *
 * The weights are the beater's own, so a hit above the beater's reach carries 1 and 0 —
 * and 1 * env + 0 has to be env exactly — which makes the sweep the envelope itself and
 * keeps those hits bit-for-bit. That is why the shape is two fields and not one.
 */
constexpr float PERC_FALL_FAST = 0.6f;

/* A one-millisecond attack. Slower is a swell rather than a hit, and faster
 * clicks — the gate is what makes this a percussion voice and not a noise burst. */
constexpr float PERC_ATTACK_MS = 1.0f;

/*
 * The gate's time constant, as a fraction of the decay time: 1/ln(1000), so that
 * DECAY is the time the tail takes to reach -60 dB — the point at which it has
 * stopped being audible rather than merely become small. The voice is freed at that
 * same moment, which is what makes the number on the screen the length of the hit.
 */
constexpr float PERC_TAU_SCALE = 0.14476f;

/* -60 dB. Below this the tail is inaudible and the voice goes back into the pool. */
constexpr float PERC_TAIL = 1.0e-3f;

/*
 * How far the filter's centre may travel before its coefficients are rebuilt, as a log2
 * ratio: 0.0072 is log2(1.005), so the centre is allowed half a percent — 0.086 of a
 * semitone — between rebuilds.
 *
 * This is here because rebuilding them is the whole cost of the module, and it was being
 * paid for EVERY SAMPLE OF EVERY TAIL. Measured on the instrument against the 2666 us
 * block budget: with the drum silent a block costs 1185 us; with three long tails it cost
 * 3200, so 83% of blocks missed their deadline and the output cracked — and the crackle
 * grew whenever the UI was touched, because that steals PSRAM bandwidth from the same
 * core's block. See the loop in synth_perc_process().
 *
 * A RATIO rather than a number of samples, because the envelope falls by a constant ratio
 * per sample: a ratio threshold rebuilds at a constant interval however long the tail is.
 * A short decay moves the centre fast and rebuilds often, which is right; a long one
 * rebuilds rarely, which is the case that was broken; an ENV of zero never moves the
 * centre at all and now pays one rebuild per hit instead of one per sample.
 */
/*
 * ШАГ ЛЕСТНИЦЫ КОЭФФИЦИЕНТОВ: 0.0072 было 8.6 цента, стало 0.0216 — 25.9 цента.
 *
 * Это самая дорогая работа модуля: каждый шаг — пересчёт фильтра голоса (exp2f, sqrtf,
 * деление). При глубине падения бочки в три октавы выходило около двухсот пересчётов на
 * удар, и удар по пяти голосам сразу стоил больше миллисекунды в одном блоке — блок не
 * успевал, и это слышалось как запинка.
 *
 * Двадцать шесть центов по центру — это по-прежнему не ступенька на слух: падение бочки
 * идёт от 50 Гц вниз, и 26 центов там меньше герца. Зато пересчётов втрое меньше.
 */
constexpr float PERC_COEFF_STEP = 0.0216f;      /* log2(1.015) */

/*
 * How long a stolen tail takes to fade out, to the same -60 dB the gate uses.
 *
 * Two milliseconds is 96 samples at 48 kHz — three quarters of one audio block, so
 * the pending hit starts in the same block it was asked for, and the grid error is
 * under a tenth of the shortest step the sequencer can make (8 blocks, 21 ms). It
 * is twice the voice's own attack, so the tail is removed over a time longer than
 * the fastest thing this voice is asked to produce, which is what stops the removal
 * being audible as itself.
 *
 * Measured against the alternative: one millisecond already removes 5.3 dB of the
 * step at a sixteenth note, two removes 5.6 and three 5.7; at a 64th the three are
 * within 0.1 dB of each other. The fade is therefore not a knob to tune but a step
 * function that is done by one millisecond, and two is chosen only for margin over
 * the attack while still finishing inside the block.
 */
constexpr float PERC_FADE_MS = 2.0f;

/*
 * Output gain — and the reason it is not a constant.
 *
 * A band-pass passes a slice of the noise, so what comes out is proportional to the
 * square root of the slice's width. A 35 Hz kick through a Q of 1 has a bandwidth of
 * about 35 Hz; a 7 kHz hat through a Q of 4 has about 1.8 kHz. Uncompensated, the
 * hat is seven times the kick at the same knob position, and PITCH becomes a loudness
 * control that happens to change the note. Scaling by sqrt(Q/fc) makes it a control
 * of the note, which is what the knob is called. This is the reason the floor moving
 * from 55 Hz to 35 Hz makes the bottom of the knob 2 dB louder and not quieter: the
 * compensation is exact, so all that changes is the number it is exact about.
 *
 * The constant is then set so that a hit at 200 Hz through a Q of 2 arrives at about
 * half scale — measured rather than guessed: tools/perc_check.py is a port of this
 * loop and prints the peak of every extreme of both knobs.
 */
constexpr float PERC_GAIN = 64.0f;

/*
 * The sine's own level, and the one constant BODY adds.
 *
 * It is NOT the noise's gain. That gain carries sqrt(Q/fc), which is what makes the
 * noise the same loudness at every PITCH and RES — a band of width fc/Q carries power
 * proportional to sqrt(fc/Q), and the sqrt(Q/fc) divides exactly that out. A sine is
 * not a band: through the same gain it would rise and fall with the knob, and BODY
 * would be a loudness control as much as a balance one. Measured on the port
 * (tools/perc_body_check.py), the factor a sine needs to sit at the noise's RMS is
 *
 *     default tom   0.355      low Q     0.400      short gate  0.432
 *     kick          0.207      high Q    0.256      long gate   0.225
 *
 * so a constant can only be anchored somewhere and not everywhere. It WAS anchored on the
 * default tom, at 0.3548, so that BODY was a balance and not a level. It is now deliberately
 * TWICE that, 0.7079, +6.00 dB on the sine — 55-200 Hz is where
 * the ear is far less sensitive, and a sine at the noise's own measured RMS reads quieter
 * than the noise it is being balanced against. BODY is therefore no longer level-neutral. On
 * the factory tom the tone now measures +4.4 dB against the noise where the old anchor had it
 * -1.6 dB, and the corners spread further: +3.4 dB on the low Q up to +7.3 dB on the high Q,
 * where the anchor kept them between -2.6 and +1.3 dB. The table above is history — the
 * reason the number is what it is — and not the shipped value. perc_decay_comp() is the last
 * residue of the anchor: it lands on body_gain as well as on the noise's own gain, 0.8361 at
 * DECAY 0.35, so even the old anchor measured 0.836 of the noise instead of 1.0 there.
 *
 * WHAT +6 dB DOES TO THE PEAK, WHICH IS NOT WHAT IT LOOKS LIKE. A sine has a crest factor of
 * 1.41 where a resonant noise burst measures about 11 here, so the tone is the QUIET half in
 * peak terms however loud it is in RMS. On the factory patch, over the six realizations the
 * knee comment uses, the loudest pre-limiter peak of the whole knob is at BODY = 0 — the
 * noise, 0.781 against the 0.85 knee — and it falls as BODY rises: 0.462 at BODY = 1, 5.3 dB
 * under the knee, with the mixture in between never exceeding the noise alone. Corner by
 * corner the all-tone hit passes the knee in exactly one place, the hat, by 0.25 dB; on the
 * kick, the hat, the high Q and the short gate the tone's peak is the larger of the two, so
 * the limiter meets the tone first there and gives back a little of the 6 dB. That is the
 * limiter doing its job, not a fault in the level: what this constant spends is loudness, and
 * the noise — the half the factory patch is — is untouched by it.
 */
constexpr float PERC_TONE_GAIN = 0.7079f;

/*
 * The peak of one hit against DECAY, and the compensation that flattens it.
 *
 * A hit is a noise burst through a resonant band-pass, so its peak is the maximum of
 * a noise process: the longer the envelope stays open, the more samples it has to
 * find a large excursion in. Measured on the port over 120 independent realizations
 * per point, at the default patch and LEVEL 1.0, the MEDIAN peak is
 *
 *     DECAY   0.00    0.35    1.00
 *     peak   0.6686  0.9289  1.4266
 *
 * and in between it is linear in the knob to better than 0.35 dB. That is not a
 * coincidence: the gate is exponential in the knob, and the expected maximum of a
 * noise process grows linearly in the logarithm of the number of samples it draws
 * from. So two constants are enough:
 *
 *     peak(d) = PERC_PEAK_MIN + PERC_PEAK_SPAN * d
 *
 * The compensation divides that out at strike time and folds it into the voice gain,
 * which is why the sample path gains nothing at all and no state is added. DECAY
 * becomes a length again instead of a loudness.
 *
 * What it cannot do, and the reason the ceiling below stays. The peak of a noise
 * burst is not a number but a distribution: over the same 120 realizations the tenth
 * to ninetieth percentile spans 5.73 dB at DECAY 0.00 and 2.19 dB at DECAY 1.00, and
 * the largest of the 120 reaches 2.09 at the long end. Flattening the median puts the
 * typical hit 0.74 dB under the knee, and the loud tail of the distribution still
 * crosses it — which is what the clipper is for, and why it cannot be removed.
 *
 * The target is the peak the knee was placed against: 0.7810. Note what that costs,
 * because it is not nothing: the TYPICAL hit at the default DECAY measures 0.9289,
 * not 0.7810 (the earlier single-realization figure was a low draw of the same
 * distribution), so this makes the default patch 1.51 dB quieter than it is today.
 * The alternative, keeping the default exactly as it is and cutting only the long
 * decays, is the same line with PERC_PEAK_TARGET = 0.9289.
 */
constexpr float PERC_PEAK_MIN = 0.6686f;
constexpr float PERC_PEAK_SPAN = 0.7586f;
constexpr float PERC_PEAK_TARGET = 0.7810f;

/*
 * The module's own output ceiling.
 *
 * Three voices overlap at any tempo denser than a sixteenth, and three noise bursts
 * through a resonant band-pass do not sum to three times one burst. Measured at
 * LEVEL 1.0, the module's own dry sum is 1.40x full scale at the default patch on
 * 32nds, 2.22x with a long DECAY, and 3.93x at the loudest corner (55 Hz, Q 0.70,
 * ENV 1 — measured when 55 Hz was the floor; that corner is 35 Hz and 2 dB louder now,
 * so the limiter's job has grown rather than shrunk). All of that used to leave this
 * module unclipped and be flattened by the rack's soft_clip, which returns exactly
 * +/-1 above full scale: a flat top, and the "percussion distorts with long decays"
 * artefact that used to be reported. The rack is right to protect itself; this module should
 * not be the thing that makes it work.
 *
 * So the sum is limited here, after the voices are added up and before it joins the
 * buses — and before the send is taken from it, so the reverb gets the limited
 * signal rather than the raw one.
 *
 * The knee is at 0.85 because a single hit must not change. Measured over the three
 * voice seeds and both channels at the default patch, one hit peaks at 0.781
 * (-2.15 dBFS) at the top of the fader and 0.390 at its middle, so 0.85 clears the
 * loudest realisation by 0.74 dB and everything below it is the identity exactly
 * rather than approximately.
 *
 * THE LOW CORNER IS THE ONE HIT THAT REACHES THIS CURVE ON PURPOSE, and it is the
 * beater's doing: the beater takes that corner's typical realisation to 0.749, still under
 * the knee, and its loudest of six crosses the knee and comes back rounded, 0.882 to
 * 0.876 — see PERC_CLICK_GAIN, where the level and the reason for it are. Nothing else
 * moves: the default patch, the snare and the hat are the hits they were, the corner that
 * was already limiting hard (ENV 1 with a 1.5 s gate) sends 0.986 against 0.984, and no
 * corner of any knob leaves this module above full scale.
 *
 * Above the knee the curve is
 *
 *     y = KNEE + SPAN * u / (SPAN + u),   u = |x| - KNEE,  SPAN = 1 - KNEE
 *
 * which leaves the knee with slope 1, the identity's own slope, so the value and the
 * first derivative are continuous at the join and only the curvature steps there,
 * from 0 to 2/SPAN = 13.3. Measured on the compiled object one representable step at
 * a time, the largest step this curve can add anywhere is 5.96e-8, -144 dBFS, which
 * is the float32 rounding of the last addition and not a step in the curve. It also
 * approaches full scale without reaching it, so no input can produce a flat top and
 * nothing leaves this module at full scale.
 *
 * A polynomial was the cheaper option and was rejected on shape, not on taste: a
 * polynomial that starts at the knee with slope 1 and ends with slope 0 has to
 * flatten within 2*SPAN of the knee, which is 0.30 of input, and flattening is the
 * flat top this exists to remove. A table with linear interpolation fails from the
 * other side: the curvature is largest AT the knee (-2/SPAN = -13.3, against -7 for
 * the rack's own curve at full scale), so a table would need hundreds of nodes in
 * the first tenth of input just to keep the slope from stepping between segments.
 *
 * The cost, counted on the object: 4 instructions per channel when the channel is
 * below the knee (load, abs.s, ole.s, branch), so 8 per sample; 23 per channel plus
 * one __divsf3 call when it is above, so 46 and two calls per sample. The division is
 * a soft-float call, so it is kept off the common path: the share of samples above
 * the knee measured 0.2% at the default patch on 32nds, 14.1% with a long DECAY and
 * 37.1% at the loudest corner. One evaluation per sample, never per voice.
 *
 * What that buys, measured, and what it does not. The dry sum's peak falls from
 * 1.40x / 2.22x / 3.93x to 0.968 / 0.985 / 0.993 for those three cases and the share
 * of samples above full scale goes to zero in all of them, while the RMS moves by
 * -0.05 / -0.55 / -1.96 dB, so the level is kept and only the peaks are given up.
 * The harmonic energy of a loud hit is NOT reduced: bounding 3.93 to 0.99 costs the
 * same distortion whichever curve does it, and the measured error of the whole chain
 * against its input is -24.1 dB before and -24.1 dB after for a single hit, with the
 * same harmonic series. What changes is that the peaks are rounded instead of flat
 * and that the limiting happens here rather than in the rack, so the drum stops
 * dragging the layers and the reverb through the rack's clipper, and the mix has
 * 12.2 dB more room at the loudest corner before the rack clips at all.
 */
constexpr float PERC_LIMIT_KNEE = 0.85f;
constexpr float PERC_LIMIT_SPAN = 1.0f - PERC_LIMIT_KNEE;

struct perc_voice_t
{
    /* Two sets of filter state, one per channel, with the coefficients shared:
     * the same filter fed by two independent noise streams, which is what makes
     * the hit wide without making it two hits. */
    float ic1[PERC_CHANNELS];
    float ic2[PERC_CHANNELS];
    float a1, a2, a3;
    float k;                /* 1 / Q */
    float pitch_hz;
    float q;
    float gain;             /* level, constant across the band — see PERC_GAIN */
    float env_oct;          /* how far the centre falls over this hit */

    /* The centre the coefficients were last built at, kept because the tone has to
     * run at the same one: it is the frequency of the sine BODY adds, and holding it
     * here is what makes the two halves of the crossfade the same note. See
     * perc_coeffs() and the BODY block in synth_perc_process(). */
    float fc;
    /*
     * The tone's carrier, carried as a rotating pair rather than as an angle: re and im
     * are the cosine and the sine of its phase, and one step of the rotation below
     * advances both. A sine evaluated per sample costs a library call; a rotation costs
     * four multiplies and two adds, and the frequency it turns at is the same one the
     * filter's coefficients were last built at, so the two halves of the BODY crossfade
     * still cannot be two different notes. See perc_coeffs(), which builds the rotation,
     * and perc_strike(), which starts the pair at a zero crossing.
     */
    float tone_re;
    float tone_im;
    float rot_cos;
    float rot_sin;
    /*
     * The q the coefficients were last built at. The centre alone cannot say whether a
     * rebuild would change anything: a strike can land on the centre the voice is already
     * running at and at a different resonance, and the coefficients carry both. See the
     * drop in perc_coeffs().
     */
    float coeff_q;
    /* Whether the tone's rotation was built for this centre. The noise-only path does not
     * build it at all — the tone is the one consumer, and it is skipped at BODY = 0 — so
     * a knob turned up during a tail asks perc_coeffs() for the rotation the sweep has
     * been leaving out. See the catch-up at the BODY branch in synth_perc_process(). */
    bool rot_valid;
    float body_gain;

    float amp;
    float amp_coeff;
    float attack_step;
    uint32_t attack_left;

    float env;
    float env_coeff;
    /* The coefficient schedule: the SWEPT value the last rebuild was made at, and how far
     * it may travel before the next one. The schedule is kept on the swept value and not on
     * the envelope so that the two-stage fall moves WHEN each rebuild happens and never HOW
     * FAR the centre moves between them: see PERC_FALL_FAST and PERC_COEFF_STEP. */
    float env_last;
    float coeff_step;
    /* The fall's shape for this hit, resolved at the strike from the beater's own share:
     * the sweep is env * (fall_lin + fall_quad * env). A hit the beater does not reach
     * carries exactly 1 and 0, which makes the sweep the envelope itself, bit for bit —
     * which is why the shape is two numbers and not one. */
    float fall_lin;
    float fall_quad;

    /* The beater's click. click is its envelope, held at 1 through the voice's own attack
     * and released after it; click_coeff is that release, and click_gain the level for this
     * hit — zero for every hit high enough that the beater does not reach it, which is what
     * makes the click's branch in synth_perc_process() a test and nothing else there. */
    float click;
    float click_coeff;
    float click_gain;
    /* How many samples the click is still held at full for. Its own counter and not the
     * attack's, because PUNCH lengthens the attack and a click held for eight milliseconds
     * would be a hiss rather than a beater; the count is a fixed millisecond, which is what
     * the attack is at PUNCH's centre. */
    uint32_t click_hold;

    float vel;
    /*
     * УРОВЕНЬ ЭТОГО УДАРА, снятый в момент удара: обрезка кита, обрезка дорожки
     * и ручка микшера. Своё у каждого голоса, поэтому удар одной дорожки не
     * переставляет уровень другой. Фейдер части сюда не входит — он общий и
     * живёт в s_level_cur ниже.
     */
    float level;
    /*
     * ФОРМА И BODY ЭТОГО УДАРА. Оба читаются в каждом сэмпле, и оба были одним числом
     * на модуль: удар одной дорожки переставлял тембр всем звучащим хвостам. Сняты
     * здесь, поэтому каждая дорожка держит свою форму до конца своего хвоста.
     */
    float shape;
    float body_noise;
    float body_tone;
    uint32_t seed[PERC_CHANNELS];
    bool active;

    /* Steal bookkeeping. A voice that is fading is still sounding its old hit at
     * vo->fade, and the hit that took it over lands when that reaches PERC_TAIL. */
    bool fading;
    float fade;
    float pending_vel;
    float pending_level;
    float pending_shape;
    float pending_noise;
    float pending_tone;
    /* The pending hit's pitch ratio, kept for the reason pending_vel is: the hit lands
     * two milliseconds later, from perc_strike(), and it must land on the note it was
     * asked for rather than on whatever the knob is by then. See perc_strike(). */
    float pending_ratio;

    /*
     * ПАРАМЕТРЫ ОТЛОЖЕННОГО УДАРА.
     *
     * Удар, который забирает звучащий голос, приходит не сразу, а через две миллисекунды —
     * когда хвост догас. За эти две миллисекунды успевают ударить остальные дорожки, и
     * каждая зовёт synth_perc_set() со своими числами; раньше отложенный удар читал то, что
     * осталось от последней, и звучал её голосом. В шестнадцатых это било по бочке всегда:
     * её хвост длиннее шага, поэтому она ждала «в очереди» каждый раз и выходила тоном тома.
     *
     * Теперь числа снимаются в момент удара и подставляются обратно на две миллисекунды.
     */
    float p_pitch;
    float p_reso;
    float p_decay;
    float p_env;
    float p_body;
    float p_punch;
    float p_shape;
};

perc_voice_t s_voice[PERC_VOICES];

uint32_t s_sr;
/* pi / sr, for the noise-only coefficient path. A multiply by a constant that is set once
 * is the same tangent to within the last bit, and it keeps a division out of the hot path;
 * the exact path keeps the old expression so the tone's phase is the old phase. */
float s_pi_over_sr;
float s_pitch01;
float s_reso01;
float s_decay01;
float s_env01;
float s_level01;
/* Уровень следующего удара: читается perc_strike() и остаётся в голосе. */
float s_strike_gain = 1.0f;

/*
 * PUNCH, the attack of the hit, 0..1 with the centre being the voice as it always was.
 *
 * WHAT IT MOVES. Two things, and only two. The voice's attack — the ramp that makes a hit a
 * blow rather than a step — is 1 ms at the centre and spans three octaves either way, so the
 * ends are a 0.125 ms snap and an 8 ms swell. And the beater's click is scaled with it,
 * quieter below the centre and louder above, plus an extra click of its own above the centre,
 * which is what makes the knob act on the hats and the tuned-up drums too: the beater's
 * share falls to zero above PERC_BEATER_OCT and those lanes would otherwise hear nothing.
 *
 * WHY THE CLICK'S HOLD IS ITS OWN COUNTER. The click is held while the attack rises and
 * released after it, which was right while the attack was a constant millisecond. With the
 * attack a knob it is not: an eight-millisecond attack would hold the beater for eight
 * milliseconds, and a beater is a thwack, not a hiss. So the hold is a fixed 1 ms — the same
 * 1 ms the attack is at the centre, which is why the centre is unchanged — and the attack is
 * free to lengthen around it.
 */
float s_punch01 = 0.5f;

/*
 * The drum's own fader and its three sends, as values that move per sample.
 *
 * s_level01 and the three arguments above are TARGETS, written once per detent from the
 * control surface. Multiplying a signal by a value that changes once per block is a staircase
 * in amplitude at the block rate — 187.5 clicks a second while a hand is on the knob, which on a
 * drum is heard as noise rather than as a fader. This is the same one-pole the rack's own
 * faders use, stepped per sample, 12 ms.
 */
float s_level_cur;
float s_rev_to, s_chr_to, s_dly_to;
float s_rev_cur, s_chr_cur, s_dly_cur;
float s_perc_glide;

/*
 * BODY, as the two weights of the crossfade. They are resolved HERE, in
 * synth_perc_set(), rather than in the sample loop: the knob is a gain and not a
 * shape, so a weight is not a per-sample decision — one cosf, one sinf and two
 * multiplies per change of the knob, and the loop only multiplies.
 *
 * The law is the SQUARE of the quarter-turn pair — weight_noise = cos^2(a), weight_tone
 * = sin^2(a), with a = body01 * PI/2 — and the squaring is the whole point of it. The
 * two weights sum to exactly 1, the middle is 50/50, and a share being given up falls
 * slowly at first and steeply as the knob nears the far end. A plain cosine leaves the
 * noise at -24 dB over the last four percent of the knob, and -24 dB of broadband noise
 * is not quiet in practice: it is plainly audible on the built-in speaker while the tone
 * it has been traded for, at the drum's own 35 Hz, is barely reproduced there at all. So
 * the end of the travel was heard as leftover noise rather than as a drum with a note in
 * it. Squaring puts that same position at -48 dB, sixteen times lower, and leaves the
 * middle — where the balance is actually judged — at the same 50/50 it always was.
 *
 * At the bottom of the travel both weights are written down as numbers rather than
 * taken from the libm — exactly 1 and exactly 0 — and the loop tests the second one,
 * so at BODY = 0 the tone is not generated at all, rather than generated and
 * multiplied by zero. The top of the travel is not given a branch of its own: there the
 * noise weight is whatever cosf left of the quarter turn, of the order of 1e-15 — below
 * -290 dB, quieter than anything the sample can resolve — so the branch would only be
 * measuring its own overhead. See synth_perc_set() for both.
 *
 * The knob's own 0..1 value is not kept: the weights are all the voice ever asks for,
 * and a third copy of the same number is a third thing to keep in step.
 */
float s_body_noise = 1.0f;
float s_body_tone = 0.0f;
/* The knob's own position, kept only to notice when the shape changed: the table below
 * is rebuilt on a change of any of the five knobs that shape a hit, and on nothing
 * else. */
float s_body01 = 0.0f;
float s_shape01 = 0.0f;      /* форма тона удара: 0 синус, 0.5 треугольник, 1 квадрат */


/* --------------------------------------------------------------------------
 * THE DIVE'S STAIRCASE IS GONE, AND WHY IT COULD NOT STAY
 * --------------------------------------------------------------------------
 * It used to pre-build the coefficients of a hit's dive into a 12 KB table, forty-eight
 * entries a block, so that a hit only had to copy them. That works for a voice whose
 * shape is a knob: the shape repeats, the table is built once and every hit of the patch
 * reads it.
 *
 * The drum section is not that voice. It plays four lanes, and each hit arrives with the
 * recipe of its own drum — a kick, then a hat, then a snare — so the shape changes on
 * every hit, the table is invalidated on every hit, and its rebuild cost fell on every
 * block instead of on the one block after a knob move. Measured on the instrument with
 * the four-lane section running: the table restarted four times a second and never
 * finished, so the dive never got a single entry from it and the drum paid forty-eight
 * rebuilds a block for a table nothing could read.
 *
 * WHAT REPLACED IT. Nothing, on purpose: the coefficients are computed live again, and
 * the live path is now cheap because perc_coeffs() no longer calls libm — the tone path
 * takes the same perc_tan_pi() and perc_exp2() the noise path already used. See the note
 * above perc_coeffs(). A dive's rebuild is a few dozen cycles rather than the several
 * hundred the table was invented to avoid.
 *
 * The cost is that a hit's coefficients are computed rather than copied, which is exactly
 * the arithmetic the table was copying — and now with the same polynomials in both paths,
 * the difference against the old code is the tangent's 4.8e-7 and not a rewritten voice.
 */

/* One fade for every voice and every hit, so it is computed once in init rather
 * than per voice: the shape of the steal is not a knob. */
float s_fade_coeff = 0.0f;

/*
 * What the module is sounding, for the ring: the application's copy of it.
 *
 * This is the only state the display has here, and it is not the reading — synth_perc_env()
 * below is a pure function of the voices and is computed on demand. What is kept is the
 * number the audio task published, which is that reading after the application has given it
 * the release a display refreshed every 120 ms needs. See synth_dsp_set_perc_env().
 *
 * It is not one of the knobs above: s_env01 is ENV, the depth of the pitch fall, and this
 * is the flash on the ring.
 */
float s_ring_env_shown;

/* Voices ringing in the last block, for the overload report. */
static volatile int s_voices_shown;

/* xorshift32. A percussion voice needs unpredictability, not cryptography, and this
 * is four instructions in a task that has 5333 microseconds per block. */
IRAM_ATTR inline float perc_noise(uint32_t *state)
{
    uint32_t x = *state;
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    *state = x;
    return (float)(x >> 8) * (1.0f / 8388608.0f) - 1.0f;
}

/* -------------------------------------------------------------------------- */
/* The coefficient arithmetic, without libm                                   */
/* -------------------------------------------------------------------------- */

/*
 * WHY THESE EXIST.
 *
 * perc_coeffs() is called once per PERC_COEFF_STEP of the sweep, and at the worst corner
 * of the knobs that is every sample of every voice: three voices at ENV 1 and the shortest
 * gate ask for it 127 times in a 128-sample block. Measured on the instrument, a block that
 * starts such a hit costs 2673-3046 us against the 2666 us the block has — the hit is the
 * whole budget — and objdump of the built object put the cause in this function: tanf(),
 * five __divsf3 calls and one sqrtf, seven calls on every rebuild.
 *
 * None of that arithmetic is the sound. The sound is the CENTRE the coefficients are built
 * at, and the filter's own state; tan() and the divisions are only how C spells the
 * transfer function. So tanf() and exp2f() are replaced here with two polynomials, and the
 * divisions that remain are the two the coefficients genuinely need — k and a1 — left to
 * __divsf3, which on this core is a correctly rounded hardware-assisted sequence and not a
 * soft-float library loop. The measured difference this makes to a rendered hit is in the report of the
 * bench: the worst of 46 crafted corners and 700 random hits
 * is -110 dBFS, twenty decibels under the -90 the change is held to.
 *
 * The BODY tone is the consumer of the rotation perc_coeffs() builds from the same tangent,
 * and its phase is integrated for the whole tail, so a coefficient that differs in the last
 * bit does NOT stay in the last bit: 70 000 samples of a rotation whose angle is off by
 * 1e-7 would end up a hundredth of a radian away.
 *
 * THE TONE TAKES THE SAME POLYNOMIAL NOW, and the drift it would have cost is what the
 * rotation's normalisation is for. Two things make the approximation safe there. First, the
 * tangent's own error is 4.8e-7 relative, so the angle is off by a part in two million —
 * over a second-long tail that is a ten-thousandth of a radian, which is -100 dB, not an
 * audible detune. Second, the rotation pair is renormalised from perc_rsqrt() whenever the
 * coefficients are rebuilt, so the amplitude error the polynomial leaves cannot compound:
 * what compounds is the angle alone, and the angle is what is measured here.
 *
 * BEFORE THIS, the tone kept libm and a hit with any tone in it was bit-exact against the
 * old build. Now it is the same arithmetic as the noise path, and the rendered comparison
 * against the libm build puts the tone cases at -110 dBFS as well — twenty decibels under
 * the -90 the change is held to. The reason for the change is measured on the instrument:
 * with four lanes and a shape that changes on every hit, the exact path was the spike.
 */

/* 1/sqrt(x) for the tone's rotation, by the same trick: one magic-constant estimate and
 * two Newton steps, about a dozen cycles against a libm call and a divide. The rotation
 * pair is already unit length in exact arithmetic — cos(2x) and sin(2x) built from one
 * tangent have magnitude one by construction — so what this corrects is folding error,
 * and it does not need to be exact to the last bit: the pair it normalises is out by a
 * few 1e-7, and a Newton step from the bit estimate brings it to about 1e-6 relative,
 * which over a 500 ms tail is a gain error under a thousandth of a decibel.
 *
 * The argument is a sum of two squares of a finite pair, so it is positive and finite
 * and no range test is needed. */
IRAM_ATTR inline float perc_rsqrt(float x)
{
    union { float f; uint32_t u; } v;
    v.f = x;
    v.u = 0x5F3759DFu - (v.u >> 1);
    float r = v.f;
    r = r * (1.5f - 0.5f * x * r * r);
    r = r * (1.5f - 0.5f * x * r * r);
    return r;
}

/* The reciprocal of the cosine inside perc_tan_pi(): one magic-constant estimate and
 * three Newton steps. It is the only reciprocal left on the fast path, and the tangent's
 * own error (4.8e-7) dominates it, which the rendered comparison confirms. The argument
 * is the cosine of an angle the centre clamps hold inside (0, pi/2), so it is positive
 * and finite and no range test is needed. */
IRAM_ATTR inline float perc_rcp(float d)
{
    union { float f; uint32_t u; } v;
    v.f = d;
    v.u = 0x7EF311C3u - v.u;
    float r = v.f;
    r = r * (2.0f - d * r);
    r = r * (2.0f - d * r);
    r = r * (2.0f - d * r);
    return r;
}

/*
 * tan(pi * f / sr) for the filter's centre, with f/sr in the range perc_coeffs() allows:
 * the clamps hold it to 20 Hz..0.45 sr, so the argument is in [0.0013, 0.45*pi]. Taylor's
 * series needs too many terms that close to pi/2; these are minimax fits of sin and cos on
 * that same interval, and the quotient is the tangent. Relative error against the double
 * reference is 4.8e-7 over the whole range, which is six ulp and far below the -90 dB the
 * old tanf() is being held to.
 *
 * The coefficients are the fit's, not Taylor's: the sine is degree 9 and the cosine degree
 * 12, with the first term of each left exact. Eleven multiply-adds and one reciprocal,
 * against a libm call.
 */
IRAM_ATTR inline float perc_tan_pi(float x)
{
    const float z = x * x;

    const float s = x * ((((2.6331709777e-6f * z - 1.9819987981e-4f) * z
                          + 8.3331819645e-3f) * z - 1.6666662893e-1f) * z
                         + 9.9999999849e-1f);

    const float c = ((((((2.0088060632e-9f * z - 2.7535761670e-7f) * z
                        + 2.4801294250e-5f) * z - 1.3888886842e-3f) * z
                       + 4.1666666599e-2f) * z - 4.9999999999e-1f) * z
                      + 1.0f);

    return s * perc_rcp(c);
}

/*
 * 2^x for x in [0, 5], which is what the pitch envelope asks for: the exponent is
 * env_oct * sweep. The integer part becomes an exponent field and the fraction a degree-5
 * minimax polynomial on [-0.5, 0.5], relative error 3.7e-7. The old exp2f() call is one
 * more libm call on the hot path; this is five multiply-adds and an integer shift.
 *
 * x is never negative here — sweep and env_oct are both non-negative — so the exponent
 * field cannot underflow, and 5 + 127 stays inside the byte.
 */
IRAM_ATTR inline float perc_exp2(float x)
{
    const int n = (int)(x + 0.5f);
    const float r = x - (float)n;

    const float p = ((((1.3395279743e-3f * r + 9.6707631297e-3f) * r
                       + 5.5503406809e-2f) * r + 2.4022211737e-1f) * r
                      + 6.9314720006e-1f) * r + 1.0000000523f;

    union { float f; uint32_t u; } scale;
    scale.u = (uint32_t)(n + 127) << 23;
    return p * scale.f;
}

/* The filter's coefficients, for a given centre and resonance. The centre is kept,
 * after the clamps, because the sine BODY adds runs at this same frequency: one
 * number, so the band and the tone can never be two different notes.
 *
 * `tone` chooses HOW the coefficients are computed, not what they are: the two paths
 * agree to within the tangent's 4.8e-7, and the rendered comparison below puts the
 * worst difference of the fast path at -110 dBFS. The fast path is for BODY = 0, where
 * the carrier's rotation has no consumer — see the note above perc_rcp() — and it
 * replaces tanf(), exp2f(), five divisions and sqrtf with two polynomials and two
 * hardware divides. The exact path is the old function, unchanged down to the order of
 * the operations, for every hit with any tone in it. */
IRAM_ATTR void perc_coeffs(perc_voice_t *v, float fc, float q, bool tone)
{
    if (fc < 20.0f) {
        fc = 20.0f;
    }
    const float nyquist = (float)s_sr * 0.45f;
    if (fc > nyquist) {
        fc = nyquist;
    }
    if (q < 0.3f) {
        q = 0.3f;
    }

    /*
     * A rebuild that would produce the coefficients already in place is dropped, and on
     * the depth the factory patch uses that is most of them: the demanded centre spends
     * the first two thirds of a dive above the clamp, so the schedule keeps handing this
     * function the frequency the voice is already running at. Equal inputs give equal
     * outputs, so dropping them is bit-transparent and moves no sample — the note above
     * PERC_ENV_MAX_OCT counts 349 of 557 rebuilds wasted on the port. The coefficients
     * are the whole cost of this module, which makes this the hot path rather than a
     * tidy-up.
     *
     * The tone in the test is why a dropped rebuild is not the same as a COMPLETE one:
     * the noise-only path leaves the carrier's rotation alone, and a hit that turns the
     * tone on over this centre needs it built before the crossfade runs. See the BODY
     * branch in synth_perc_process().
     */
    if (fc == v->fc && q == v->coeff_q && (!tone || v->rot_valid)) {
        return;
    }

    if (!tone) {
        /*
         * The noise-only path. q is latched by perc_strike() and cannot move during a
         * tail, so k is rebuilt only when the resonance does; the centre moves every
         * rebuild and is the only thing that does.
         */
        if (q != v->coeff_q) {
            v->coeff_q = q;
            v->k = 1.0f / q;
        }
        v->fc = fc;

        const float g = perc_tan_pi(fc * s_pi_over_sr);
        const float a1 = 1.0f / (1.0f + g * (g + v->k));

        v->a1 = a1;
        v->a2 = g * a1;
        v->a3 = g * v->a2;

        /* No carrier was built at this centre, and a knob turned up mid-tail must not
         * run the tone from the previous hit's rotation. */
        v->rot_valid = false;
        return;
    }

    const float g = perc_tan_pi(fc * s_pi_over_sr);
    /* q is latched by perc_strike() and cannot move during a tail, so this reciprocal is
     * taken once per hit rather than once per rebuild of the dive. */
    if (q != v->coeff_q) {
        v->k = 1.0f / q;
    }
    const float k = v->k;

    v->fc = fc;
    v->coeff_q = q;
    v->a1 = 1.0f / (1.0f + g * (g + k));
    v->a2 = g * v->a1;
    v->a3 = g * v->a2;

    /*
     * The tone's rotation, taken from the filter's own tangent. The carrier turns by
     * 2*pi*fc/sr per sample, which is exactly twice the angle g is the tangent of, so
     * the cosine and the sine of it both fall out of g with one division and no
     * trigonometry at all: cos(2x) = (1 - t^2)/(1 + t^2) and sin(2x) = 2t/(1 + t^2).
     *
     * The pair is normalised before it is stored. The carrier is advanced by it once per
     * sample for as long as the hit lasts, and a rotation whose own magnitude is a
     * fraction of a unit off would be applied tens of thousands of times — so the cost
     * of one square root here buys a drift that stays where rounding noise is instead of
     * compounding into an audible gain.
     */
    const float d = 1.0f / (1.0f + g * g);
    const float rc = (1.0f - g * g) * d;
    const float rs = 2.0f * g * d;
    const float m = perc_rsqrt(rc * rc + rs * rs);
    v->rot_cos = rc * m;
    v->rot_sin = rs * m;
    v->rot_valid = true;
}

/*
 * СОК. Раньше кик отдавал низ ровно столько, сколько его пропускал центр с BODY, и на
 * плотном месте этого не хватало: слышно было щелчок, а вес — нет. Здесь в голос удара
 * добавлена постоянная низкая полка: всё ниже 85 Гц поднимается на 4.5 дБ, остальное не
 * трогается. Это не параметр и не ручка — у полки одно положение, выбранное так, чтобы кик
 * на любом TUNE и любом BODY звучал плотнее, а малый и хэт не поехали: выше 200 Гц полка не
 * даёт ничего.
 *
 * Полка стоит ДО мягкого ограничителя, который в этом модуле уже был. Это не случайность:
 * подъём низа — единственное, что может вывести удар за предел, и пусть его срезает тот же
 * ограничитель, который срезает всё остальное, чем отдельная защита на этом пути.
 */
constexpr float PERC_JUICE_HZ = 85.0f;    /* ниже этого — вес удара */
constexpr float PERC_JUICE_DB = 4.5f;     /* сколько веса; слышно, но не «бум» */
constexpr float PERC_JUICE_Q  = 0.70f;    /* широкая полка: пологий скат */

static float s_juice_b0, s_juice_b1, s_juice_b2, s_juice_a1, s_juice_a2;
/*
 * Состояния «сока» — на два канала всегда, даже когда голос сводится в один: полка стоит на
 * шине ударки ПОСЛЕ свода и работает по стерео-сумме, ей нужны оба уха.
 */
static float s_juice_x1[2], s_juice_x2[2];
static float s_juice_y1[2], s_juice_y2[2];

/* RBJ, low shelf. Считается один раз на запуске: частота дискретизации здесь не меняется. */
static void perc_juice_coeffs(uint32_t rate)
{
    const float a = powf(10.0f, PERC_JUICE_DB / 40.0f);
    const float w = PERC_TWO_PI * PERC_JUICE_HZ / (float)rate;
    const float cs = cosf(w);
    const float sn = sinf(w);
    const float alpha = sn / (2.0f * PERC_JUICE_Q);
    const float beta = 2.0f * sqrtf(a) * alpha;

    const float b0 = a * ((a + 1.0f) + (a - 1.0f) * cs + beta);
    const float b1 = -2.0f * a * ((a - 1.0f) + (a + 1.0f) * cs);
    const float b2 = a * ((a + 1.0f) + (a - 1.0f) * cs - beta);
    const float a0 = (a + 1.0f) - (a - 1.0f) * cs + beta;
    const float a1 = 2.0f * ((a - 1.0f) - (a + 1.0f) * cs);
    const float a2 = (a + 1.0f) - (a - 1.0f) * cs - beta;

    s_juice_b0 = b0 / a0;
    s_juice_b1 = b1 / a0;
    s_juice_b2 = b2 / a0;
    s_juice_a1 = a1 / a0;
    s_juice_a2 = a2 / a0;

    for (int c = 0; c < PERC_CHANNELS; c++) {
        s_juice_x1[c] = s_juice_x2[c] = 0.0f;
        s_juice_y1[c] = s_juice_y2[c] = 0.0f;
    }
}

/* Один канал через полку. Direct form I: состояния важнее экономии двух сложений. */
static inline float perc_juice(int c, float x)
{
    const float y = s_juice_b0 * x + s_juice_b1 * s_juice_x1[c] + s_juice_b2 * s_juice_x2[c]
                    - s_juice_a1 * s_juice_y1[c] - s_juice_a2 * s_juice_y2[c];

    s_juice_x2[c] = s_juice_x1[c];
    s_juice_x1[c] = x;
    s_juice_y2[c] = s_juice_y1[c];
    s_juice_y1[c] = y;

    if (!(y > -4.0f && y < 4.0f)) {
        return 0.0f;                 /* NaN или взрыв: молчание вместо щелчка */
    }

    return y;
}

/*
 * ЧЕМ ДАКИНГ СЛЫШИТ УДАР.
 *
 * Источником дакинга был конверт удара целиком, а это значит, что хэт двигал низ дрона так
 * же сильно, как бочка. Здесь стоит мультимодальный фильтр на моно сумме удара: одна ручка
 * ведёт от LP через BP к HP, резонанса нет вовсе (Q = 0.707, постоянная), поэтому фильтр
 * выбирает полосу, а не подчёркивает её. За ним — быстрый детектор: нарастание 0.3 мс,
 * отпускание 8 мс. Это не релиз дакинга, а сам источник: медленное отпускание решает
 * отдельная ручка в rack, и два разных отпускания здесь только путали бы.
 *
 * Фильтр — топология Zavalishin (TPT), та же, что в фильтрах дрона и лида: она устойчива
 * на свипе и не даёт щелчка, когда ручку крутят на ходу.
 */
constexpr float PERC_DSRC_HZ = 180.0f;      /* стык: тело бочки ниже, корпус малого выше */
constexpr float PERC_DSRC_Q  = 0.70710678f; /* без резонанса, и это не настройка */
constexpr float PERC_DSRC_ATT_MS = 0.3f;
constexpr float PERC_DSRC_REL_MS = 8.0f;

static float s_dsrc_g = 0.0f;
static float s_dsrc_k = 0.0f;
static float s_dsrc_mode = 0.0f;            /* 0 = LP, 0.5 = BP, 1 = HP */
static float s_dsrc_ic1 = 0.0f;
static float s_dsrc_ic2 = 0.0f;
static float s_dsrc_env = 0.0f;             /* то, что читает rack */
static float s_dsrc_att = 0.0f;
static float s_dsrc_rel = 0.0f;

static void perc_dsrc_coeffs(uint32_t rate)
{
    const float w = PERC_PI * PERC_DSRC_HZ / (float)rate;

    s_dsrc_g = tanf(w);
    s_dsrc_k = 1.0f / PERC_DSRC_Q;

    const float block_ms = 1000.0f / (float)rate;

    s_dsrc_att = block_ms / (PERC_DSRC_ATT_MS + block_ms);
    s_dsrc_rel = block_ms / (PERC_DSRC_REL_MS + block_ms);

    s_dsrc_ic1 = s_dsrc_ic2 = 0.0f;
    s_dsrc_env = 0.0f;
}

/* Один сэмпл через фильтр и детектор. Возвращает не число, а обновляет s_dsrc_env —
 * читать его будет rack, раз в блок. */
static inline void perc_dsrc_sample(float x)
{
    const float v3 = x - s_dsrc_ic2;
    const float v1 = s_dsrc_ic1 + s_dsrc_g * v3;
    const float v2 = s_dsrc_ic2 + s_dsrc_g * v1;

    s_dsrc_ic1 = 2.0f * v1 - s_dsrc_ic1;
    s_dsrc_ic2 = 2.0f * v2 - s_dsrc_ic2;

    const float lp = v2;
    const float bp = v1;
    const float hp = x - s_dsrc_k * v1 - v2;

    float band;

    if (s_dsrc_mode <= 0.5f) {
        const float w = s_dsrc_mode * 2.0f;
        band = lp + (bp - lp) * w;
    } else {
        const float w = (s_dsrc_mode - 0.5f) * 2.0f;
        band = bp + (hp - bp) * w;
    }

    if (!(band > -4.0f && band < 4.0f)) {
        s_dsrc_env = 0.0f;
        s_dsrc_ic1 = s_dsrc_ic2 = 0.0f;
        return;
    }

    const float rect = band < 0.0f ? -band : band;
    const float coef = (rect > s_dsrc_env) ? s_dsrc_att : s_dsrc_rel;

    s_dsrc_env += (rect - s_dsrc_env) * coef;

    if (!(s_dsrc_env >= 0.0f)) {
        s_dsrc_env = 0.0f;
    }
}

/*
 * The ceiling from above, applied to one channel of the module's own sum: twice per
 * sample, once per channel, and not once per voice, because everything the voices
 * did is already in the two numbers this takes.
 *
 * Below the knee this returns its argument untouched, which is what keeps a single
 * hit bit-identical. Above it, the curve has no flat part and its slope only falls,
 * so it can never turn a step in the input into a larger step in the output — the
 * largest step it can produce is the input's own, which is what stops it buzzing at
 * the join.
 */
IRAM_ATTR inline float perc_soft_limit(float x)
{
    const float a = fabsf(x);
    if (a <= PERC_LIMIT_KNEE) {
        return x;
    }
    const float u = a - PERC_LIMIT_KNEE;
    const float y = PERC_LIMIT_KNEE + PERC_LIMIT_SPAN * u / (PERC_LIMIT_SPAN + u);
    return copysignf(y, x);
}

/*
 * ФОРМА ТОНА: МОРФ СИНУС -> ТРЕУГОЛЬНИК -> КВАДРАТ.
 *
 * Синус уже посчитан поворотом фазы, и это единственное, что у тона было. Треугольник
 * получается из него первыми членами asin(sin) — двумя умножениями, без библиотеки.
 * Квадрат — это то же синусоидальное ядро, прогнанное через мягкий ограничитель, который
 * уже есть в файле: сплющенная вершина и есть нечётные гармоники. Делением на предел при
 * том же коэффициенте амплитуда возвращается к единице, поэтому смена формы не меняет
 * громкость удара, а только его тембр.
 */
static inline float perc_shape(float s, float shape01)
{
    if (!(shape01 > 0.0f)) {
        return s;
    }

    const float tri = s * (1.2732f - 0.4244f * s * s);

    if (shape01 <= 0.5f) {
        const float t = shape01 * 2.0f;
        return s + (tri - s) * t;
    }

    const float t = (shape01 - 0.5f) * 2.0f;
    const float k = 1.6f + 6.0f * t;
    const float sq = perc_soft_limit(s * k) / perc_soft_limit(k);

    return tri + (sq - tri) * t;
}

/*
 * One 0..1 level arriving from outside — the fader's sends are the only ones, and the
 * rack already holds its own copies to this range. They are re-bounded here because each
 * becomes a per-sample one-pole target below: a NaN that reached one would be multiplied
 * into every sample of every hit for the rest of the session, which is the one thing the
 * fuse cannot undo. The lower test is negated so a non-number lands on silence.
 */
inline float perc_level01(float x)
{
    if (!(x >= 0.0f)) {
        return 0.0f;
    }
    return (x > 1.0f) ? 1.0f : x;
}

/*
 * How much quieter a hit has to be struck so that its peak does not depend on how
 * long it lasts. Read at strike time, from the same knob value the gate is built
 * from, so a stolen hit is compensated with the DECAY it actually lands under.
 *
 * The beater's click is the one thing in the voice that is deliberately NOT scaled by it:
 * the table normalises the peak of a noise process, whose maximum grows with the number of
 * samples the gate draws from, and a beater's peak does not grow with the gate at all. The
 * click's gain therefore divides this back out; see PERC_CLICK_GAIN.
 *
 * One multiply, one divide and one clamp, once per hit — never per sample. The strike
 * reads it once for all three consumers.
 */
inline float perc_decay_comp(float decay01)
{
    /* Negated lower test: a NaN fails it and lands on the short end, where `decay01 < 0`
     * let it through into the peak table and from there into the voice's gain. */
    if (!(decay01 >= 0.0f)) {
        decay01 = 0.0f;
    } else if (decay01 > 1.0f) {
        decay01 = 1.0f;
    }
    return PERC_PEAK_TARGET / (PERC_PEAK_MIN + PERC_PEAK_SPAN * decay01);
}

/*
 * Strike a voice: everything a hit decides for itself, in one place, because a hit
 * now has two ways to start — onto a silent voice, or onto one whose tail has just
 * finished fading. Both must be the same hit.
 *
 * The knobs are read HERE and not at trigger time, so a stolen hit takes the values
 * in force when it lands. That is two milliseconds after it was asked for, which is
 * far less than any knob can travel, and it is what keeps the pending hit to one
 * float instead of a snapshot of the whole state.
 *
 * THE PITCH RATIO IS THE ONE THING THAT DOES NOT COME FROM THE KNOBS. It is handed to
 * the strike, latched into the voice and never read again, so a hit carries its own
 * note: 1.0 is the PITCH knob's centre and the sequencer's hits are exactly that, while
 * a note from the MIDI input is a transposition of it. Everything downstream of
 * v->pitch_hz — the coefficients, the BODY's tone, the envelope's fall in octaves and
 * the gain's sqrt(Q/fc) compensation — follows the note for free, which is the whole
 * reason the ratio is applied here rather than to the module's state.
 */
void perc_strike(perc_voice_t *v, float velocity01, float pitch_ratio)
{
    memset(v->ic1, 0, sizeof(v->ic1));
    memset(v->ic2, 0, sizeof(v->ic2));

    v->pitch_hz = synth_perc_pitch_hz(s_pitch01) * pitch_ratio;
    v->q        = PERC_Q_MIN * exp2f(s_reso01 * PERC_Q_SPAN);
    v->env_oct  = synth_perc_env_octaves(s_env01);
    v->vel      = velocity01;
    v->level    = s_strike_gain;
    v->shape    = s_shape01;
    v->body_noise = s_body_noise;
    v->body_tone  = s_body_tone;
    /* One number, three consumers: the noise's own gain, the tone's own gain, and the
     * beater's share of that gain. See PERC_CLICK_GAIN for why the click divides the decay
     * compensation back out instead of being scaled by it. */
    const float comp = perc_decay_comp(s_decay01);
    /* From the base pitch rather than from the swept one: the compensation is about
     * the width of the band, and the sweep is part of the sound. The decay term is a
     * pure gain, so it moves the peak and the tail by the same factor: DECAY changes
     * how long the hit lasts and how much energy it carries, not how high it peaks. */
    v->gain     = PERC_GAIN * sqrtf(v->q / v->pitch_hz) * comp;
    /* The tone's own level: the same measurement anchored on the default patch, and
     * the same decay compensation, without the sqrt(Q/fc) the band needs. See
     * PERC_TONE_GAIN. */
    v->body_gain = PERC_TONE_GAIN * comp;

    /*
     * The beater's share of this hit, from the note it was struck at rather than from the
     * PITCH knob — a MIDI note that transposes the drum out of the beater's reach loses the
     * beater with everything else the note already carries. One log2f per hit, and the
     * clamp is on the share rather than on the logarithm: below the floor the logarithm
     * goes negative and a share above one would make the click louder than the corner it
     * was calibrated on.
     */
    const float oct = log2f(v->pitch_hz / PERC_PITCH_MIN_HZ);
    const float beater = (oct >= PERC_BEATER_OCT)
                       ? 0.0f
                       : (1.0f - ((oct > 0.0f) ? oct : 0.0f) / PERC_BEATER_OCT);

    /* The fall's shape and the click's level, both from that one share. At zero they are
     * exactly 1 and 0, and exactly zero, so a hit above the beater's reach is the voice it
     * was before any of this existed. */
    v->fall_quad = PERC_FALL_FAST * beater;
    v->fall_lin  = 1.0f - v->fall_quad;

    /*
     * PUNCH, and the two things it is allowed to touch.
     *
     * The attack: a straight multiplication at the centre, so the voice is the voice it
     * always was there. The beater's share is scaled the same way — one at the centre by
     * construction of the two numbers — and above the centre the hit also carries a click
     * the beater does not own, because half a kit's lanes are out of the beater's reach.
     */
    const float punch = s_punch01;
    const float punch_attack_ms = PERC_ATTACK_MS * exp2f((0.5f - punch) * PERC_PUNCH_ATTACK_OCT);
    const float beater_eff = beater * (PERC_PUNCH_CLICK_MIN + PERC_PUNCH_CLICK_SPAN * punch);
    const float extra = (punch > PERC_PUNCH_EXTRA_FROM)
                      ? (punch - PERC_PUNCH_EXTRA_FROM) * 2.0f * PERC_PUNCH_EXTRA * PERC_CLICK_GAIN
                      : 0.0f;

    v->click_gain = (PERC_CLICK_GAIN * beater_eff + extra) / comp;
    v->click = (beater_eff > 0.0f || extra > 0.0f) ? 1.0f : 0.0f;
    /* One millisecond, the attack's own length at the centre: PUNCH may stretch the attack
     * but never the click, which is a thwack and not a hiss. */
    v->click_hold = (uint32_t)((float)s_sr * PERC_ATTACK_MS * 0.001f + 0.5f);
    if (v->click_hold < 1u) {
        v->click_hold = 1u;
    }
    const float click_tau = PERC_CLICK_MS * 0.001f * (float)s_sr * PERC_TAU_SCALE;
    v->click_coeff = expf(-1.0f / (click_tau > 1.0f ? click_tau : 1.0f));

    perc_coeffs(v, v->pitch_hz, v->q, s_body_tone > 0.0f);

    /* The carrier starts at a zero crossing, so a hit at BODY = 1 begins on one rather
     * than on whatever the last hit left behind: im is the sine, and re the quarter turn
     * ahead of it that the rotation needs to carry. */
    v->tone_re = 1.0f;
    v->tone_im = 0.0f;

    /*
     * One pole reaching -60 dB in DECAY milliseconds: exp(-1/tau) per sample, with
     * the time constant set so that the tail is inaudible at the end of the knob's
     * value rather than merely small.
     */
    const float tau = synth_perc_decay_ms(s_decay01) * 0.001f * (float)s_sr * PERC_TAU_SCALE;
    v->amp_coeff = expf(-1.0f / (tau > 1.0f ? tau : 1.0f));

    /* The filter falls over the hit rather than after it: by the time the gate has
     * closed, the pitch has already arrived where it is going — and it arrives within
     * PERC_ENV_FALL_MAX_MS at the latest, so a gate long enough for a tail is not
     * allowed to stretch the fall into a bend heard as a tom rather than a kick. */
    const float tau_fall_max = PERC_ENV_FALL_MAX_MS * 0.001f * (float)s_sr * PERC_TAU_SCALE;
    const float tau_fall = (tau < tau_fall_max) ? tau : tau_fall_max;
    v->env_coeff = expf(-1.0f / (tau_fall > 1.0f ? tau_fall : 1.0f));
    v->env = 1.0f;
    /*
     * The rebuild above was made at env = 1, and the shape of the fall passes exactly
     * through 1 there whatever the beater's share is, so that is where the schedule starts.
     * The threshold is the ratio's own log2 divided by the octaves this hit sweeps: an ENV of
     * zero leaves the centre standing still, and 1.0 is a difference the sweep can never
     * exceed, which is how "never rebuild again" is said without an infinity.
     */
    v->env_last = 1.0f;
    v->coeff_step = (v->env_oct > 0.01f) ? (PERC_COEFF_STEP / v->env_oct) : 1.0f;

    v->attack_left = (uint32_t)((float)s_sr * punch_attack_ms * 0.001f + 0.5f);
    if (v->attack_left < 1u) {
        v->attack_left = 1u;
    }
    v->attack_step = 1.0f / (float)v->attack_left;

    v->amp     = 0.0f;
    v->active  = true;
    v->fading  = false;
    v->fade    = 1.0f;
    v->pending_vel = 0.0f;
    v->pending_ratio = 1.0f;
}



} // namespace

/*
 * Две внешние функции дакинга. Они стоят здесь, а не среди внутренностей выше, потому что
 * всё выше — в анонимном пространстве имён: там у символа нет внешней связи, и rack его не
 * найдёт, даже если заголовок объявляет его честно.
 */
void synth_perc_set_duck_src(float mode01)
{
    if (!(mode01 >= 0.0f)) {
        mode01 = 0.0f;
    } else if (mode01 > 1.0f) {
        mode01 = 1.0f;
    }
    s_dsrc_mode = mode01;
}

float synth_perc_duck_src_published(void)
{
    return s_dsrc_env;
}

/* -------------------------------------------------------------------------- */
/* The knob mappings, shared with the display                                 */
/* -------------------------------------------------------------------------- */

float synth_perc_pitch_hz(float pitch01)
{
    if (!(pitch01 >= 0.0f)) {
        pitch01 = 0.0f;
    } else if (pitch01 > 1.0f) {
        pitch01 = 1.0f;
    }
    return PERC_PITCH_MIN_HZ * exp2f(pitch01 * PERC_PITCH_OCTAVES);
}

float synth_perc_pitch_01(float hz)
{
    /* A frequency that is not a number, or is below the floor, is the bottom of the
     * knob; the upper end is caught below, and an infinity lands there. */
    if (!(hz >= PERC_PITCH_MIN_HZ)) {
        return 0.0f;
    }

    const float oct = log2f(hz / PERC_PITCH_MIN_HZ) / PERC_PITCH_OCTAVES;
    if (oct >= 1.0f) {
        return 1.0f;
    }
    return oct;
}

float synth_perc_decay_ms(float decay01)
{
    if (!(decay01 >= 0.0f)) {
        decay01 = 0.0f;
    } else if (decay01 > 1.0f) {
        decay01 = 1.0f;
    }
    return PERC_DECAY_MIN_MS * exp2f(decay01 * PERC_DECAY_SPAN);
}

float synth_perc_env_octaves(float env01)
{
    if (!(env01 >= 0.0f)) {
        env01 = 0.0f;
    } else if (env01 > 1.0f) {
        env01 = 1.0f;
    }
    return env01 * PERC_ENV_MAX_OCT;
}

/* -------------------------------------------------------------------------- */
/* Voice                                                                      */
/* -------------------------------------------------------------------------- */

void synth_perc_init(uint32_t sample_rate)
{
    perc_juice_coeffs(sample_rate);
    perc_dsrc_coeffs(sample_rate);
    s_sr = sample_rate ? sample_rate : SYNTH_SAMPLE_RATE;
    s_pi_over_sr = PERC_PI / (float)s_sr;

    /* The steal's fade uses the gate's own -60 dB convention, so a stolen tail ends
     * exactly where a released one does and no second threshold is invented. */
    const float fade_tau = PERC_FADE_MS * 0.001f * (float)s_sr * PERC_TAU_SCALE;
    s_fade_coeff = expf(-1.0f / (fade_tau > 1.0f ? fade_tau : 1.0f));

    /* The body's tone does not need the reciprocal of the sample rate any more: its
     * frequency now arrives as a rotation, built inside perc_coeffs() out of the same
     * tangent the filter's coefficients come from. */

    memset(s_voice, 0, sizeof(s_voice));
    for (int v = 0; v < PERC_VOICES; v++) {
        /* Fixed seeds, so the instrument sounds the same on every boot: a drum
         * machine whose noise is different each time it is switched on is a drum
         * machine you cannot learn. */
        s_voice[v].seed[0] = 0x9E3779B9u + (uint32_t)v * 0x85EBCA6Bu;
#if !PERC_MONO
        s_voice[v].seed[1] = 0xC2B2AE35u + (uint32_t)v * 0x27D4EB2Fu;
#endif
        perc_coeffs(&s_voice[v], 200.0f, 1.0f, s_body_tone > 0.0f);
    }

    /* Hold-if-nobody-tells-us values, the same convention the rack's send defaults
     * follow. The application overwrites all of them at boot from its own table. */
    s_pitch01 = 0.30f;
    s_reso01  = 0.35f;
    s_decay01 = 0.35f;
    s_env01   = 0.45f;
    s_level01 = 0.0f;
    s_level_cur = 0.0f;
    s_rev_to = s_chr_to = s_dly_to = 0.0f;
    s_rev_cur = s_chr_cur = s_dly_cur = 0.0f;
    s_perc_glide = 1.0f - expf(-1.0f / (0.012f * (float)SYNTH_SAMPLE_RATE));

    /* The ring's published value starts at silence: nothing has been struck, and the first
     * block that renders one publishes a number of its own. The reading itself needs no
     * initialising — it is computed from the voices, which the memset above has cleared. */
    s_ring_env_shown = 0.0f;

    /* BODY at the bottom of its travel, which is the voice this module has always
     * been: all noise, no tone, weights of exactly 1 and exactly 0. */
    s_body_noise = 1.0f;
    s_body_tone = 0.0f;
    s_body01 = 0.0f;
    s_strike_gain = 1.0f;


    ESP_LOGI(TAG, "ready: %d voices, %.0f-%.0f Hz, %.0f-%.0f ms",
             PERC_VOICES, (double)PERC_PITCH_MIN_HZ,
             (double)(PERC_PITCH_MIN_HZ * exp2f(PERC_PITCH_OCTAVES)),
             (double)PERC_DECAY_MIN_MS, (double)PERC_DECAY_MAX_MS);
}

/*
 * The rescue, from synth_rack.cpp's fuse.
 *
 * The integrators of every voice are the drum's memory of its own noise and are cleared
 * unconditionally. The rest is per voice and conservative: a number that is still finite is
 * left where it is, because a rescue happens under a sounding instrument and changing a
 * tail that is not broken would be the rescue making a sound of its own. A voice whose
 * coefficients, gains or rotation have gone non-finite is restruck from the knobs — its
 * coefficients rebuilt from PITCH and RES — and a voice whose note is not a number is simply
 * dropped: `perc_strike()` builds a fresh one on the next hit, and a hi-hat nobody asked for
 * is worse than a missing tail.
 *
 * The level and the three sends are the module's own one-poles, and they are put on their
 * targets for the same reason the rack's are: after the rescue the drum must be as loud as
 * the fader says, not fade up from zero.
 */
void synth_perc_reset_state(void)
{
    s_level_cur = s_level01;
    s_rev_cur = s_rev_to;
    s_chr_cur = s_chr_to;
    s_dly_cur = s_dly_to;
    s_ring_env_shown = 0.0f;

    for (int v = 0; v < PERC_VOICES; v++) {
        perc_voice_t *vo = &s_voice[v];

        for (int c = 0; c < PERC_CHANNELS; c++) {
            vo->ic1[c] = 0.0f;
            vo->ic2[c] = 0.0f;
        }

        if (!isfinite(vo->amp)) {
            vo->amp = 0.0f;
        }
        if (!isfinite(vo->env)) {
            vo->env = 0.0f;
        }
        if (!isfinite(vo->click)) {
            vo->click = 0.0f;
        }
        if (!isfinite(vo->fade)) {
            vo->fade = 1.0f;
        }
        if (!isfinite(vo->vel)) {
            vo->vel = 0.0f;
        }
        if (!isfinite(vo->pending_vel)) {
            vo->pending_vel = 0.0f;
        }
        if (!isfinite(vo->pending_ratio)) {
            vo->pending_ratio = 1.0f;
        }

        if (!isfinite(vo->pitch_hz) || vo->pitch_hz <= 0.0f
            || !isfinite(vo->q) || vo->q <= 0.0f) {
            vo->active = false;
            continue;
        }

        if (!isfinite(vo->fc)
            || !isfinite(vo->a1) || !isfinite(vo->a2) || !isfinite(vo->a3)
            || !isfinite(vo->tone_re) || !isfinite(vo->tone_im)
            || !isfinite(vo->rot_cos) || !isfinite(vo->rot_sin)) {
            vo->tone_re = 1.0f;
            vo->tone_im = 0.0f;
            perc_coeffs(vo, vo->pitch_hz, vo->q, s_body_tone > 0.0f);
        }

        if (!isfinite(vo->amp_coeff) || vo->amp_coeff <= 0.0f
            || !isfinite(vo->env_coeff) || vo->env_coeff <= 0.0f
            || !isfinite(vo->click_coeff) || vo->click_coeff <= 0.0f
            || !isfinite(vo->gain) || !isfinite(vo->body_gain)) {
            vo->active = false;
        }
    }
}

/*
 * The knobs. PITCH, RES, DECAY, ENV and BODY are read when a hit is STRUCK and not
 * while it sounds: the shape of a drum is decided when it is hit, and a knob touched
 * during a tail would otherwise bend a note that is already in the air. LEVEL is
 * the exception and is read every sample, because it is a fader rather than a
 * shape — the same way the layer levels work.
 *
 * RES is the one knob no longer on a page: the application sends the factory value
 * here whatever the stored patch holds, so the resonance the peak and the level were
 * calibrated at is the resonance in force. The mapping itself is untouched.
 */
/*
 * УРОВЕНЬ ДОРОЖКИ НА СЛЕДУЮЩИЙ УДАР.
 *
 * Отдельно от synth_perc_set() нарочно: level01 у него — фейдер всей части, одно число,
 * которое движется к цели за 12 мс и слышно на всех звучащих голосах. Уровень дорожки
 * так работать не может — он принадлежит одному удару, — поэтому он входит в голос
 * здесь и остаётся в нём на весь хвост.
 */
void synth_perc_strike_gain(float gain01)
{
    if (!(gain01 >= 0.0f)) {
        gain01 = 0.0f;
    } else if (gain01 > 1.0f) {
        gain01 = 1.0f;
    }
    s_strike_gain = gain01;
}

void synth_perc_set(float pitch01, float reso01, float decay01, float env01, float level01,
                    float body01, float punch01, float shape01)
{

    /*
     * Every knob is bounded here, and the lower test is the negation of the one the
     * value has to pass. These five are latched by perc_strike() a block or two later,
     * so a NaN that slipped through `x < 0` would sit in the module's state until a hit
     * picked it up: pitch becomes a coefficient, decay becomes the gate's coefficient
     * and level multiplies every sample of the tail. A non-number lands on the low
     * bound; an infinity on the bound it names.
     */
    if (!(pitch01 >= 0.0f)) {
        pitch01 = 0.0f;
    } else if (pitch01 > 1.0f) {
        pitch01 = 1.0f;
    }
    if (!(reso01 >= 0.0f)) {
        reso01 = 0.0f;
    } else if (reso01 > 1.0f) {
        reso01 = 1.0f;
    }
    if (!(decay01 >= 0.0f)) {
        decay01 = 0.0f;
    } else if (decay01 > 1.0f) {
        decay01 = 1.0f;
    }
    if (!(env01 >= 0.0f)) {
        env01 = 0.0f;
    } else if (env01 > 1.0f) {
        env01 = 1.0f;
    }
    if (!(level01 >= 0.0f)) {
        level01 = 0.0f;
    } else if (level01 > 1.0f) {
        level01 = 1.0f;
    }


    s_pitch01 = pitch01;
    s_reso01  = reso01;
    s_decay01 = decay01;
    s_env01   = env01;
    s_level01 = level01;

    /* BODY becomes the two weights of the crossfade, here and not per sample. The
     * clamps are the same ones every other knob mapping uses, so a caller outside the
     * control surface cannot make a weight leave 0..1. */
    if (!(body01 >= 0.0f)) {
        body01 = 0.0f;
    } else if (body01 > 1.0f) {
        body01 = 1.0f;
    }
    const float a = body01 * (PERC_PI * 0.5f);
    const float sn = sinf(a);
    const float cs = cosf(a);
    /*
     * The weights themselves are the SQUARES of that pair, and the reason is in the
     * comment on the two statics above: a plain cosine leaves the noise audible at the
     * top of the travel, where the tone it was traded for is not reproduced.
     *
     * cosf(0) is 1.0f and sinf(0) is 0.0f on any libm worth the name, and squaring
     * leaves both alone — but the bottom of this particular travel is the one position
     * that must not rest on a library's rounding either way, so both weights are
     * written down as numbers there. BODY at zero is then the voice that existed before
     * this knob by construction: the loop sees a tone weight of exactly zero and does
     * not run the tone at all.
     */
    s_body_noise = (body01 <= 0.0f) ? 1.0f : cs * cs;
    s_body_tone  = (body01 <= 0.0f) ? 0.0f : sn * sn;

    s_body01 = body01;

    /*
     * ФОРМА ГЕНЕРАТОРА, от комплекта к комплекту. Синус — самый чистый удар, треугольник
     * ярче и «деревяннее», квадрат жёсткий и полный нечётных гармоник. Морф между ними —
     * это то, чем один кит отличается от другого на слух сильнее, чем настройкой центра:
     * у хардтехно удар должен быть гармоническим, а не просто низким.
     */
    if (!(shape01 >= 0.0f)) {
        shape01 = 0.0f;
    } else if (shape01 > 1.0f) {
        shape01 = 1.0f;
    }
    s_shape01 = shape01;

    /*
     * PUNCH: the attack of the hit. Its own clamp, for its own reason — the value is read
     * by perc_strike() and turned into a sample count and a gain, and a NaN on that path
     * would make the count a number no voice can survive.
     *
     * The centre is the voice as it always was: the attack and the beater's share are both
     * written as multiplications by one there, so 0.5 leaves the hit bit-for-bit — which is
     * the one property this knob has to have, because it ships at the centre and every
     * preset written before it existed lands on the centre.
     */
    if (!(punch01 >= 0.0f)) {
        punch01 = 0.0f;
    } else if (punch01 > 1.0f) {
        punch01 = 1.0f;
    }
    s_punch01 = punch01;
}

/*
 * Strike, or arrange for one. Called from the audio task, and processed by the same
 * task, so none of this needs a lock — and it must stay that way, because a mutex in
 * the audio path is a deadline miss waiting for a scheduler decision.
 *
 * The only thing a trigger can do besides strike is start a fade, which is a flag
 * and two floats: triggering stays O(PERC_VOICES) and allocation-free however dense
 * the figure is.
 *
 * pitch_ratio scales the centre of the hit and is carried through the steal with the
 * velocity: 1.0 is the PITCH knob itself, which is what the sequencer's figure hands
 * over and what every hit was struck at before the ratio existed — so the drum the
 * instrument plays on its own is untouched by it, bit for bit.
 */
static void perc_trigger_on(int voice, float velocity01, float pitch_ratio);

void synth_perc_trigger(float velocity01, float pitch_ratio)
{
    if (!(velocity01 > 0.0f) || !(s_level01 > 0.0f)) {
        /* A hit nobody can hear costs nothing: no voice, no state, no time. */
        return;
    }

    /*
     * Velocity is a LEVEL, and the highest one is full scale: the sequencer's accent
     * and the MIDI input both stop at 1, so anything above it — an infinity included —
     * is the same hit at the same level rather than a gain the fader never offered.
     */
    if (velocity01 > 1.0f) {
        velocity01 = 1.0f;
    }

    /*
     * A caller with nothing to say about the pitch gets the knob, and a caller that
     * says something impossible gets it too: a zero or a NaN here would put the voice's
     * centre at DC, and a voice nothing can tune is worse than one at the knob.
     *
     * What is left is clamped to PERC_RATIO_MIN..PERC_RATIO_MAX. The second test is
     * NEGATED for the same reason as the first: a denormal is greater than zero by
     * every comparison and still makes sqrt(q / pitch) infinite, so it has to fail a
     * bound of its own rather than pass between zero and the ceiling.
     */
    if (!(pitch_ratio > 0.0f)) {
        pitch_ratio = 1.0f;
    } else if (!(pitch_ratio >= PERC_RATIO_MIN)) {
        pitch_ratio = PERC_RATIO_MIN;
    } else if (pitch_ratio > PERC_RATIO_MAX) {
        pitch_ratio = PERC_RATIO_MAX;
    }

    /* The quietest voice, so a new hit never cuts off a tail that is still louder
     * than the hit itself. */
    /*
     * The quietest voice, so a hit never cuts off a tail that is still louder than the hit
     * itself. Kept for the callers that have no lane to name — and used by none of the
     * sequencer's own hits any more: those name their lane through
     * synth_perc_trigger_voice(). See the note over the voice table.
     */
    int pick = 0;
    float quietest = s_voice[0].active ? s_voice[0].amp : -1.0f;
    for (int v = 1; v < PERC_VOICES; v++) {
        const float a = s_voice[v].active ? s_voice[v].amp : -1.0f;
        if (a < quietest) {
            quietest = a;
            pick = v;
        }
    }

    perc_trigger_on(pick, velocity01, pitch_ratio);
}

/*
 * THE SAME HIT, ON A NAMED VOICE.
 *
 * The validation is the free function's, because a caller with a lane to name has no reason
 * to repeat it — and the two entry points must agree about what a velocity of zero, a missing
 * ratio and a level of zero mean, or a lane's hit and a keyboard's hit would answer differently
 * to the same impossible number.
 */
void synth_perc_trigger_voice(int voice, float velocity01, float pitch_ratio)
{
    if (voice < 0) {
        voice = 0;
    } else if (voice >= PERC_VOICES) {
        voice = PERC_VOICES - 1;
    }
    if (!(velocity01 > 0.0f) || !(s_level01 > 0.0f)) {
        return;
    }
    if (velocity01 > 1.0f) {
        velocity01 = 1.0f;
    }
    if (!(pitch_ratio > 0.0f)) {
        pitch_ratio = 1.0f;
    } else if (!(pitch_ratio >= PERC_RATIO_MIN)) {
        pitch_ratio = PERC_RATIO_MIN;
    } else if (pitch_ratio > PERC_RATIO_MAX) {
        pitch_ratio = PERC_RATIO_MAX;
    }

    perc_trigger_on(voice, velocity01, pitch_ratio);
}

/*
 * БЕЗ ОЧЕРЕДИ: удар в названный голос, даже если он ещё звучит.
 *
 * Проверки те же, что у trigger_voice(), и по той же причине: голос без дорожки и голос с
 * дорожкой не должны отвечать по-разному на одни и те же невозможные числа.
 */
void synth_perc_retrigger(int voice, float velocity01, float pitch_ratio)
{
    if (voice < 0) {
        voice = 0;
    } else if (voice >= PERC_VOICES) {
        voice = PERC_VOICES - 1;
    }
    if (!(velocity01 > 0.0f) || !(s_level01 > 0.0f)) {
        return;
    }
    if (velocity01 > 1.0f) {
        velocity01 = 1.0f;
    }
    if (!(pitch_ratio > 0.0f)) {
        pitch_ratio = 1.0f;
    } else if (!(pitch_ratio >= PERC_RATIO_MIN)) {
        pitch_ratio = PERC_RATIO_MIN;
    } else if (pitch_ratio > PERC_RATIO_MAX) {
        pitch_ratio = PERC_RATIO_MAX;
    }

    perc_strike(&s_voice[voice], velocity01, pitch_ratio);
}

/* ОТЛАДКА: амплитуда голоса. */
float synth_perc_voice_env(int voice)
{
    if (voice < 0 || voice >= PERC_VOICES) {
        return 0.0f;
    }
    return s_voice[voice].active ? s_voice[voice].amp : 0.0f;
}

/* The strike itself, on the voice the caller has already chosen and validated. */
static void perc_trigger_on(int pick, float velocity01, float pitch_ratio)
{
    perc_voice_t *v = &s_voice[pick];

    /*
     * A steal. The tail is NOT cut: the voice is marked to fade and the hit that
     * takes it over is remembered, to be struck when the fade reaches the same -60 dB
     * the gate already treats as silence. Nothing is reset here — the fade has to run
     * on the voice's own state, which is the sound being removed.
     *
     * A second hit arriving inside the fade re-aims the pending one instead of
     * starting a third. At the fastest step the sequencer can make that cannot
     * happen; this is the answer that cannot click if it ever does.
     */
    if (v->active) {
        v->fading = true;
        v->fade = 1.0f;
        v->pending_vel = velocity01;
        v->pending_level = s_strike_gain;
        v->pending_shape = s_shape01;
        v->pending_noise = s_body_noise;
        v->pending_tone  = s_body_tone;
        v->pending_ratio = pitch_ratio;
        v->p_pitch = s_pitch01;
        v->p_reso  = s_reso01;
        v->p_decay = s_decay01;
        v->p_env   = s_env01;
        v->p_body  = s_body01;
        v->p_punch = s_punch01;
        v->p_shape = s_shape01;
        return;
    }

    perc_strike(v, velocity01, pitch_ratio);
}

/*
 * One block of percussion, ADDED to the caller's buffers: the dry sum, and the
 * reverb's send bus, which is mono because the reverb makes its own stereo.
 *
 * UNTOUCHED BY THE RING. What the display reads is a pure function of the voices
 * (synth_perc_env()), so the envelope follows them for free and this loop is exactly
 * what it was: nothing here was added for the light, and nothing here was moved.
 */
IRAM_ATTR void synth_perc_process(int samples, float *l, float *r,
                        float *send_rev, float rev01,
                        float *send_chr_l, float *send_chr_r, float chr01,
                        float *send_dly_l, float *send_dly_r, float dly01)
{
    if (samples <= 0 || !l || !r) {
        return;
    }

    bool any = false;
    int alive = 0;

    for (int v = 0; v < PERC_VOICES; v++) {
        if (s_voice[v].active) {
            any = true;
            alive++;
        }
    }

    s_voices_shown = any ? alive : 0;

    if (!any) {
        s_dsrc_env = 0.0f;
        return;
    }

    s_rev_to = perc_level01(rev01);
    s_chr_to = perc_level01(chr01);
    s_dly_to = perc_level01(dly01);

    for (int i = 0; i < samples; i++) {
        float hit_l = 0.0f;
        float hit_r = 0.0f;

        s_level_cur += (s_level01 - s_level_cur) * s_perc_glide;
        s_rev_cur += (s_rev_to - s_rev_cur) * s_perc_glide;
        s_chr_cur += (s_chr_to - s_chr_cur) * s_perc_glide;
        s_dly_cur += (s_dly_to - s_dly_cur) * s_perc_glide;

        for (int v = 0; v < PERC_VOICES; v++) {
            perc_voice_t *vo = &s_voice[v];
            if (!vo->active) {
                continue;
            }



            /*
             * The steal's fade, before anything else the voice does. When it reaches
             * PERC_TAIL the old tail has arrived where the gate would have left it,
             * and the pending hit is struck from here — so the hit lands on the same
             * sample the tail ends and no sample is spent on silence.
             */
            if (vo->fading) {
                vo->fade *= s_fade_coeff;
                if (vo->fade < PERC_TAIL) {
                    const float keep_pitch = s_pitch01;
                    const float keep_reso  = s_reso01;
                    const float keep_decay = s_decay01;
                    const float keep_env   = s_env01;
                    const float keep_body  = s_body01;
                    const float keep_punch = s_punch01;
                    const float keep_shape = s_shape01;
                    const float keep_gain  = s_strike_gain;
                    const float keep_noise = s_body_noise;
                    const float keep_tone  = s_body_tone;

                    s_pitch01 = vo->p_pitch;
                    s_reso01  = vo->p_reso;
                    s_decay01 = vo->p_decay;
                    s_env01   = vo->p_env;
                    s_body01  = vo->p_body;
                    s_punch01 = vo->p_punch;
                    s_shape01 = vo->p_shape;
                    s_strike_gain = vo->pending_level;
                    s_shape01     = vo->pending_shape;
                    s_body_noise  = vo->pending_noise;
                    s_body_tone   = vo->pending_tone;

                    perc_strike(vo, vo->pending_vel, vo->pending_ratio);

                    s_pitch01 = keep_pitch;
                    s_reso01  = keep_reso;
                    s_decay01 = keep_decay;
                    s_env01   = keep_env;
                    s_body01  = keep_body;
                    s_punch01 = keep_punch;
                    s_shape01 = keep_shape;
                    s_strike_gain = keep_gain;
                    s_body_noise  = keep_noise;
                    s_body_tone   = keep_tone;
                }
            }

            if (vo->attack_left > 0) {
                vo->attack_left--;
                vo->amp += vo->attack_step;
                if (vo->amp > 1.0f) {
                    vo->amp = 1.0f;
                }
            } else {
                vo->amp *= vo->amp_coeff;
                /*
                 * A fading voice is not freed here even when its tail is under the
                 * threshold, because the fade still has a hit to land: the voice is
                 * ending, and the fade is what ends it. That also bounds its life —
                 * a fade always finishes within PERC_FADE_MS.
                 */
                if (vo->amp < PERC_TAIL && !vo->fading) {
                    vo->active = false;
                    continue;
                }
            }

            /*
             * The beater's click, and the one compare it costs: held at full while the
             * voice's own attack rises and released after it, because that attack already
             * IS the beater's rise. kc is what the band's own tap below is mixed with, so
             * the click rides the same gain the noise does, and it is exactly zero for
             * every hit the beater does not reach — see PERC_BEATER_OCT — which is what
             * makes the second compare inside the channel loop a formality.
             */
            float kc = 0.0f;
            if (vo->click > PERC_TAIL) {
                if (vo->click_hold > 0u) {
                    vo->click_hold--;
                } else {
                    vo->click *= vo->click_coeff;
                }
                kc = vo->click * vo->click_gain;
            }

            if (vo->env > PERC_TAIL) {
                vo->env *= vo->env_coeff;
                /*
                 * The fall's shape, then the rebuild. Rebuilt only once the SWEPT value has
                 * travelled far enough to be worth it: the threshold is the same 8.6 cents
                 * per octave it always was, and only the times of the rebuilds move —
                 * earlier, because the first part of the dive is the fast one. The step the
                 * centre actually takes is the travel since the last rebuild, so it can be
                 * one sample wider than the threshold; see PERC_FALL_FAST, where the worst
                 * step at each corner and the count of rebuilds are measured.
                 */
                const float sweep = vo->env * (vo->fall_lin + vo->fall_quad * vo->env);
                if ((vo->env_last - sweep) > vo->coeff_step) {
                    vo->env_last = sweep;
                    /*
                     * The centre, from the same exponent either way. The noise path and
                     * the tone path now share the polynomial: perc_coeffs() takes the
                     * tangent with perc_tan_pi() and the centre with perc_exp2(), so a
                     * dive's rebuild is arithmetic and not a library call, and the two
                     * paths differ only in whether the carrier's rotation is built.
                     */
                    const float octaves = vo->env_oct * sweep;
                    const float centre = vo->pitch_hz * perc_exp2(octaves);
                    perc_coeffs(vo, centre, vo->q, vo->body_tone > 0.0f);
                }
            }

            float out[PERC_CHANNELS];
            for (int c = 0; c < PERC_CHANNELS; c++) {
                const float in = perc_noise(&vo->seed[c]);
                const float v3 = in - vo->ic2[c];
                const float v1 = vo->a1 * vo->ic1[c] + vo->a2 * v3;
                const float v2 = vo->ic2[c] + vo->a2 * vo->ic1[c] + vo->a3 * v3;

                vo->ic1[c] = 2.0f * v1 - vo->ic1[c];
                vo->ic2[c] = 2.0f * v2 - vo->ic2[c];

                /* The band-pass tap, scaled by k so that resonance changes how much
                 * the filter rings rather than how loud the hit is. The beater is mixed
                 * into this same tap and not beside it: everything below multiplies `out`
                 * by the noise's gain and by BODY's noise weight, so the click is part of
                 * the noise half of the hit — it cannot survive BODY = 1, where the voice
                 * is a tone, and at BODY = 0 it is not scaled by anything at all. The node
                 * is the filter's own high-pass, v0 - BP - LP, which the TPT form hands
                 * over for the two subtractions; `in` is the noise this sample already
                 * drew. */
                const float band = vo->k * v1;
                if (kc != 0.0f) {
                    out[c] = band + (in - band - v2) * kc;
                } else {
                    out[c] = band;
                }
            }

            /* The fade, folded into the same gain the hit already has: a voice that
             * is not fading carries 1.0 here, so this costs one multiply. */
            const float g = vo->amp * vo->vel * s_level_cur * vo->level * vo->gain * vo->fade;

            /*
             * BODY: the crossfade between the noise above and a sine at the filter's
             * own centre.
             *
             * WHY THE WHOLE THING IS UNDER A TEST, and why the noise is written out
             * twice. At BODY = 0 the tone's weight is exactly zero, and this block is
             * SKIPPED rather than executed with a zero in it — so the voice at the
             * bottom of the knob leaves through the two lines in the else, which are
             * the two lines this module has always had, character for character. (They
             * carry the beater's click now, because the click is mixed into the noise tap
             * those lines scale rather than added beside it: the beater is part of the
             * noise half of the hit and belongs to no knob, which is why it is out of
             * this one's reach at both ends of its travel.) No
             * multiplied-by-one noise, no added zero, no reliance on x * 1.0f and
             * x + 0.0f being exact. They are, but the guarantee is better than that,
             * and it is the one thing about this knob that was not allowed to be
             * approximate. It also means the knob costs nothing at all while it sits at
             * the bottom, which is where it ships.
             *
             * THE SWEEP. The carrier turns at vo->fc — the centre the filter's own
             * coefficients were last built at, updated on the PERC_COEFF_STEP schedule
             * just above, and the rotation is rebuilt with them. One centre, two
             * consumers, so the tone and the band
             * it is crossfaded against can never be two different notes and cannot
             * beat against each other in the middle of the knob. That is also why the
             * tone inherits the filter's staircase: at most half a percent, 8.6 cents,
             * which is the same step the band is already making. A fixed tone was never
             * an option — a kick's whole character is that the centre falls, and the
             * tone has to fall with it or the two halves of the fade separate as the
             * hit decays.
             *
             * THE COST, when the knob is off zero: one rotation per active voice per
             * sample — four multiplies and two adds — against three voices at 48 kHz.
             * Nothing else moves: the filter, the envelope and the gate are untouched,
             * and at BODY = 0 not even the rotation is reached.
             *
             * The tone is the same in both channels on purpose: the noise is two
             * independent streams because a mono point in a stereo room sounds like a
             * click track, but the tone is the drum's body and a body sits in the
             * middle.
             */
            if (vo->body_tone > 0.0f) {
                /*
                 * A knob turned up over a tail struck at BODY = 0: the noise-only path has
                 * not been building the carrier's rotation, so it is built here, once, at
                 * the centre the filter is standing on. The coefficients become the old
                 * exact ones at that same centre — the same numbers the old build would
                 * have had — so this is the one place the tone can start mid-hit and is
                 * still the note the band is playing. See perc_coeffs().
                 */
                if (!vo->rot_valid) {
                    perc_coeffs(vo, vo->fc, vo->q, true);
                }
                /*
                 * One step of the carrier's rotation, in place: re and im turn together
                 * by the angle perc_coeffs() built, and im is the sine. The pair is not
                 * renormalised per sample — that is what the normalised rotation is for —
                 * so this is the whole of the tone's arithmetic.
                 */
                const float re = vo->tone_re * vo->rot_cos - vo->tone_im * vo->rot_sin;
                vo->tone_im = vo->tone_re * vo->rot_sin + vo->tone_im * vo->rot_cos;
                vo->tone_re = re;
                const float tone = perc_shape(vo->tone_im, vo->shape);

                /* The tone's own level, not the noise's: see PERC_TONE_GAIN. Both are
                 * weighted by the squared pair from synth_perc_set(), which is what makes
                 * the noise's share fall away to nothing at the top of the travel. */
                const float gn = g * vo->body_noise;
                const float gt = vo->amp * vo->vel * s_level_cur * vo->level * vo->body_gain
                                 * vo->fade
                                 * vo->body_tone;

#if PERC_MONO
                const float noise_out = out[0] * gn * PERC_MONO_PAN;
                hit_l += noise_out + tone * gt;
                hit_r += noise_out + tone * gt;
#else
                hit_l += out[0] * gn + tone * gt;
                hit_r += out[1] * gn + tone * gt;
#endif
            } else {
#if PERC_MONO
                const float noise_out = out[0] * g * PERC_MONO_PAN;
                hit_l += noise_out;
                hit_r += noise_out;
#else
                hit_l += out[0] * g;
                hit_r += out[1] * g;
#endif
            }

        }

        /* The ceiling, here and nowhere else: before the buses, and before the send
         * is derived from these two numbers, so the reverb gets the limited signal. */
        hit_l = perc_soft_limit(hit_l);
        hit_r = perc_soft_limit(hit_r);

        /*
         * Сок — ПОСЛЕ ограничителя, а не до него. До него прибавка низа доставалась тихим
         * ударам, а самый громкий кик — тот, ради которого её и добавляли, — отдавал её
         * ограничителю первым: акцентный удар с полной скоростью выходил из полки без
         * прибавки вовсе. Здесь же низ поднимается у всех одинаково, а второй проход
         * ограничителя стоит уже за прибавкой и ловит только тот пик, который она вывела
         * за колено.
         */
        hit_l = perc_soft_limit(perc_juice(0, hit_l));
        hit_r = perc_soft_limit(perc_juice(1, hit_r));

        l[i] += hit_l;
        r[i] += hit_r;

        /*
         * The three sends, all mono and all derived from the same limited pair: a drum is a
         * point source, and a stereo send from it would only add width the hit never had.
         * The chorus's and the delay's buses are stereo, so the same number is added to both
         * of their channels — the chorus then does its own reading across them.
         */
        const float mono = (hit_l + hit_r) * 0.5f;

        /* Источник дакинга: тот же удар, но увиденный одной полосой. */
        perc_dsrc_sample(mono);

        if (send_rev) {
            send_rev[i] += mono * s_rev_cur;
        }
        if (send_chr_l && send_chr_r) {
            const float v = mono * s_chr_cur;
            send_chr_l[i] += v;
            send_chr_r[i] += v;
        }
        if (send_dly_l && send_dly_r) {
            const float v = mono * s_dly_cur;
            send_dly_l[i] += v;
            send_dly_r[i] += v;
        }
    }

}

/* -------------------------------------------------------------------------- */
/* What the module is sounding, for the ring                                  */
/* -------------------------------------------------------------------------- */

/*
 * The reading itself, and nothing is kept for it: the loudest voice's own gain — its gate,
 * which is the attack and the decay it runs whether anyone is watching or not, times its
 * velocity times the steal's fade — taken from the voice array the render path already
 * owns.
 *
 * Called once per block by the audio task, so its cost is three multiplies a voice against
 * a 2666 microsecond budget, and it adds NOTHING to the sample loop: the three numbers it
 * multiplies are updated by the render whether the ring exists or not, which is the whole
 * reason the display can be given a drum envelope without a detector. It is a plain read of
 * state the audio task owns and writes, so there is no lock here and none is wanted; the
 * display never calls this, it reads the published value below.
 *
 * IT FREEZES WITH THE VOICES, which is the honest behaviour: with the transport stopped the
 * rack's gate closes and synth_perc_process() is not called at all, so amp stops moving,
 * this reading stops moving with it, and the ring is dark regardless — the display gates
 * every part on the transport itself (parts_open in ring_reactive()).
 *
 * WHAT IS LEFT OUT, AND WHY, is in the comment on synth_perc_env() in synth_dsp.h: the
 * level, because the ring applies the part's fader itself, and the voice's own gain,
 * because that is the module's calibration of a kick against a hat and not the mix.
 */
float synth_perc_env(void)
{
    float loudest = 0.0f;

    for (int v = 0; v < PERC_VOICES; v++) {
        const perc_voice_t *vo = &s_voice[v];
        if (!vo->active) {
            continue;
        }
        const float a = vo->amp * vo->vel * vo->fade;
        if (a > loudest) {
            loudest = a;
        }
    }

    /* velocity arrives as 0..1 from the sequencer and the other two cannot leave it, so
     * this is the belt to that pair of braces rather than a working clamp. */
    if (loudest > 1.0f) {
        loudest = 1.0f;
    }
    return loudest;
}

/*
 * The application's copy of the reading above, which is what the ring actually draws.
 *
 * Two numbers rather than one because they are not the same number: the reading is the
 * module's own gate, which falls exactly as fast as the voices do, while what the ring
 * draws is that reading after the audio task has given it the release a display refreshed
 * every 120 ms needs. The shaping is in publish_perc_env(), beside the microphone's own
 * envelope, for the same reason the microphone's is there: this task is what knows the
 * block rate.
 *
 * The clamp is this side of the seam because the caller is the clock — a number outside
 * 0..1 here would be multiplied by 255 by the ring and cast into a colour channel.
 * `!(env01 > 0.0f)` rather than `env01 < 0.0f` so that a NaN — the one value a bad
 * multiply could produce that survives every comparison — is also turned into silence,
 * the same test synth_perc_trigger() uses on its velocity.
 */
void synth_dsp_set_perc_env(float env01)
{
    if (!(env01 > 0.0f)) {
        env01 = 0.0f;
    } else if (env01 > 1.0f) {
        env01 = 1.0f;
    }
    s_ring_env_shown = env01;
}

float synth_perc_env_published(void)
{
    return s_ring_env_shown;
}

/*
 * How many voices were ringing in the last block. Telemetry for the overload report: the cost
 * of the drum follows this number, so a block that ran long can say whether it was the drum.
 */
int synth_perc_active_voices(void)
{
    return s_voices_shown;
}
