/*
 * The picture in the middle of the dial while a knob is turning.
 *
 * One 56x56 picture, one paint colour, one bit per pixel: 392 bytes that say what
 * the parameter under the hand does. The page's name steps aside for two seconds,
 * the picture steps in, and the name comes back where it was.
 *
 * WHY A MASK AND NOT AN lv_image. LVGL has no fast path for a 1-bit image: an I1
 * source is expanded while it is drawn, so every frame would decode the same 392
 * bytes and then blend 2,800 pixels through the generic path. The mask is instead
 * written straight into the layer's RGB565 buffer from an LV_EVENT_DRAW_MAIN
 * callback — the same trick the rim and the map use — so the cost of a frame is a
 * bit test per pixel and a store for the ones that are lit. Nothing is allocated,
 * nothing is decoded, and the buffer that is written is the one the panel is about
 * to receive.
 *
 * WHY THE PICTURES ARE DRAWN FROM TABLES. A curve is a polyline of four to eight
 * vertices or a walk along x over a 16-value table, linearly interpolated. There is
 * no logarithm, square root or exponential on any drawing path: the filter table is
 * a decibel response sampled once, offline, and the two reverb tables are decay
 * envelopes of the same kind. The only arithmetic a frame does is add, multiply and
 * compare.
 *
 * Nothing here touches LVGL. The caller owns the object, the colour and the moment;
 * this file owns the geometry.
 */
#pragma once

#include <stdint.h>

#include "synth_app.h"

#ifdef __cplusplus
extern "C" {
#endif

/*
 * The picture's size in pixels, and its mask in bytes.
 *
 * THE FRAME IS 56 x 56 AND THE FIGURE DRAWN IN IT IS 44 x 44, CENTRED: six pixels
 * of air on every side. That is the owner's rule and it is the same on every page,
 * so 56 here is the frame and 44 is a matter of where a figure draws inside it —
 * see the field pv_env() uses, which is the first figure drawn to that rule.
 *
 * 56 divides by 8 exactly: one row is seven whole bytes, so a row never straddles
 * a byte and the mask has no padding bit anywhere. 392 bytes for the whole frame.
 */
#define SYNTH_PREVIEW_W 56
#define SYNTH_PREVIEW_H 56
#define SYNTH_PREVIEW_BYTES ((SYNTH_PREVIEW_W * SYNTH_PREVIEW_H) / 8)

/* Which figure a parameter gets. PREVIEW_NONE means the page's name stays: there is
 * nothing honest to draw for that control at this size, and a placeholder would be
 * worse than the word it replaced. */
typedef enum {
    PREVIEW_NONE = 0,
    PREVIEW_ENV,        /* the lead's four envelope stages, the active one thicker */
    PREVIEW_FILTER,     /* the drone filter: shelf, corner, skirt, hump by MODE */
    PREVIEW_COMP,       /* nine bars being levelled: what a compressor does, not its curve */
        PREVIEW_WAVE,       /* the selected oscillator shape */
    PREVIEW_DELAY,      /* decaying echoes: time to the right, level up */
    PREVIEW_VERB_DAMP,  /* four rings nested one inside another, closing inwards */
    PREVIEW_VERB_MODE,  /* one tail per mode, the selected one thicker */

    /* The second set: the lead's own filter pair, the modulation page, the
     * settings rings and the generators' step figures. Appended, so every kind
     * above keeps the value it had when the first set was measured. */
    PREVIEW_LEAD_FILTER, /* the same figure for the lead's own corner, Q and mode */
    PREVIEW_LEAD_ENV,    /* how far the lead's envelope moves the corner */
    PREVIEW_LFO,         /* the filter LFO's own waveform, eight entries */
    PREVIEW_RATE,        /* the drift's rate: cycles across one picture */
    PREVIEW_MOD_DEPTH,   /* the drift's depth: reference and current amplitude */
    PREVIEW_TRIG,        /* the modulation's trigger: an edge and an arrow */
    PREVIEW_DELAY_MODE,  /* tape against crossfade */
    PREVIEW_DELAY_SYNC,  /* the division grid with the chosen beat marked */
    PREVIEW_CHORUS,      /* two detuned copies of one wave */
    PREVIEW_LEVEL,       /* the master level: a bar filled to its value */
    PREVIEW_DUCK,        /* the level pressed down: a notch in the bars and a ball on a thread */
    PREVIEW_DENSITY,     /* sixteen rings on a grid, thinned out by the knob */
    PREVIEW_FOLLOW,      /* the drone line and the note that pulls it, or not */
    PREVIEW_WIDTH,       /* three registers, spread by the width */
    PREVIEW_ACCENT,      /* a weak onset and an accented one */
    PREVIEW_PERC_PITCH,  /* where the drum's band-pass sits on its axis */
    PREVIEW_PERC_QUANT,  /* the drum's pitch, quantised or not */
    PREVIEW_PERC_DECAY,  /* how long the hit rings */
    PREVIEW_PERC_BODY,   /* the click and the body of the hit */
    PREVIEW_PERC_ENV,    /* how far the drum's filter falls over the hit */
    PREVIEW_ARP,         /* the arpeggiator's staircase: dir, speed, len, range */
    PREVIEW_SWEEP,       /* the LFO wave: rate is the turns, depth the reach */

    /* THE SEND SECTIONS. One figure per section and the same figure on every sector
     * of it, so a sends page reads as one thing while the hand moves along it: rings
     * for the reverb sends, diamonds for the delay sends, two capsules for the chorus
     * sends. How much is sent is carried by the figure — a quarter of the travel adds
     * a ring or a diamond, the capsules drift apart — so the knob reports itself.
     * The effects' own pages are not touched by this: they keep their own figures. */
    PREVIEW_VERB_SECTOR,   /* rings: one more every quarter of the travel */
    PREVIEW_DELAY_SECTOR,  /* diamonds: one more every quarter, never merging */
    PREVIEW_CHORUS_SECTOR, /* two capsules that part as the level rises */

    /*
     * DELAY FEEDBACK, the first figure of an effect's own page. Nine bars on a
     * five-pixel pitch, each one broken in the middle: the outer ends stand on the
     * ladder 40 / 30 / 20 / 14 / 10, and the ladder slides outward as the feedback
     * rises, so the picture grows from the centre bar out to the edges. The gaps ride
     * along — the centre bar parts from 10 to 16 pixels, its neighbours hold a fixed
     * six — which is what makes the middle read as the delay's own repeats rather
     * than a solid comb. It sits on DELAY's FDBK sector only: the delay sends keep
     * their diamonds, and MIX has no picture at all.
     */
    PREVIEW_DELAY_FEEDBACK,

    /*
     * REVERB SIZE, the second figure of an effect's page: a box in isometric view whose
     * depth alone travels, from four pixels to twenty, while the front face stays put.
     * The picture is centred by construction — the depth is always even, so the margins
     * are whole pixels and the box cannot drift sideways — and its outline is the one
     * shape on this dial that matches the owner's art down to the last pixel. It sits on
     * REVERB's SIZE sector only.
     */
    PREVIEW_VERB_SIZE,

    /*
     * CHORUS DEPTH, the third figure of an effect's page: four rings of radius eleven on
     * the cross. At zero they coincide and read as one ring; as the knob turns they part
     * along both axes, out to ten pixels, and the ring opens into a clover of four. The
     * spread is carried in half pixels so the rings move a pixel at a time. It sits on
     * CHORUS's DEPTH sector and, by the owner's request, on the drone page's WIDTH sector
     * as well: the same picture wherever a knob widens something. The rate keeps the chain
     * of rectangles.
     */
    PREVIEW_CHORUS_DEPTH,

    /*
     * CHORUS RATE, the page's other knob: a chain of rounded rectangles, one width for
     * every position — twenty pixels wide, the ends round, two pixels of stroke — whose
     * PITCH alone travels, from twenty pixels down to four. The width never changes; the
     * rectangles stand closer, so at the fast end they overlap and their arcs interleave
     * into a comb. The pitch moves in whole pixels and in steps of one, seventeen of them,
     * because a fractional pitch rounds the left wall one way and the right wall the other
     * and the frame stops mirroring: the chain is anchored so that the middle rectangle's
     * wall sits at x = 12 of the field, which puts every whole pitch on a symmetric frame.
     * It sits on CHORUS's RATE sector; the depth keeps its clover of rings.
     */
    PREVIEW_CHORUS_RATE,

    /*
     * SWING, the percussion sequencer's own figure. A bar of sixteenths is five marks of
     * two pixels across the top; the odd ones sit late by up to ten pixels, and the box
     * below is the straight ruler they are measured against — it never moves, and its
     * three ticks are the beat, the half and the beat. Two marks may not stand closer
     * than six pixels, so a late mark PUSHES the next one and the row bunches up and
     * slides out of the field at the far end. Eleven whole-pixel positions.
     */
    PREVIEW_SWING,

    /*
     * GROOVE, the picture of the written part: sixteen steps on a 4 x 4 grid, ten pixels
     * apart from the third column and third row, an eight-pixel glyph in each cell — a disc
     * for the kick, a hollow diamond for the snare, a square for the hat, a smaller hollow
     * diamond for the tom and a two-pixel square for the ghost hat. Where a step carries
     * several instruments only the highest is drawn, in the order KICK, SNARE, HAT, TOM,
     * GHOST: the figure answers "what does this bar sound like", and two glyphs in one cell
     * answer nothing. Steps run left to right and then down: 0..3, 4..7, 8..11, 12..15.
     */
    PREVIEW_GROOVE,

    /*
     * FILL, the meter of how much of the part is filled: sixteen cells on the same 4 x 4 grid,
     * a six-pixel box in each, and a cell is empty or holds a square of two, four or six
     * pixels, centred. The filling starts at the last cell — the bottom right one — and runs
     * backwards through the reading order, and each position of the knob raises exactly one
     * cell at the front of the queue by one size, so three cells of three sizes stand in a
     * ramp behind the front. That ramp is what the owner's own sample shows: a medium and a
     * small side by side, with big ones behind them. Eighteen units over the whole travel.
     */
    PREVIEW_FILL,

    /*
     * VAR, the tree: the part of the figure that says how far the variation reaches out. Three
     * forks, a two-pixel trunk at the bottom of the field and eight twigs in the crown, all in
     * two-pixel strokes, exactly as the owner drew it — at the top of the travel the picture is
     * his drawing pixel for pixel.
     *
     * The tree grows from the bottom and from the middle of each fork: a branch starts only once
     * its support has grown, so nothing ever hangs in the air, and every branch has its OWN
     * speed and its own pause, which is what a growing tree looks like. One of the two central
     * branches runs about three times faster than the outer ones and leads the whole figure —
     * the owner asked for the side branches to trail further behind it. Every branch still
     * arrives at one, so at the top of the travel the tree is always complete.
     */
    PREVIEW_VAR,

    /*
     * TONE, the ring on a thread: how high the kit sits.
     *
     * The graphic is the owner's, mirrored top to bottom and played backwards, because that is
     * the way round he wants it: at a low value the ring is large and hangs low on the thread,
     * and as the knob rises it shrinks and is drawn up towards the top. At the ends of the
     * travel the frame is his drawing pixel for pixel — see tools/tone-shape.py.
     *
     * The thread is a two-pixel column from row 2 to row 41 and does not pass through the
     * ring: the inside of the ring is empty. The diameter is always even, because the ring is
     * centred between two columns and an odd diameter would make it a pixel wider than it is
     * tall, leaving single pixels on the sides.
     */
    PREVIEW_TONE,

    /*
     * DECAY, the drum's gate — the envelope of one hit. The owner drew it: a floor across the
     * whole field, a left wall, a shelf along the top and a two-pixel slope down to the floor.
     * As the knob rises the shelf lengthens and the slope, keeping its own steepness, moves to
     * the right, so the envelope gets longer without getting shallower.
     *
     * Note that this is the parameter the page calls DECAY (PERC_LENGTH, the gate multiplier)
     * and not the older PERC_DECAY, which the voice no longer reads and which has a figure of
     * its own that never reaches the screen.
     */
    PREVIEW_PERC_LENGTH,

    /*
     * PUNCH, the drum's attack — the figure the owner drew as four frames: an octagon, a
     * four-armed cross, a six-armed star and an eight-armed burst. Read as one sequence it
     * says what the knob does: the ring is the hit at rest, and as the knob rises four, six
     * and eight rays come out of it, so the drum goes from a round soft blow to a spiked one.
     *
     * The four frames are the knots of one polygon. The tips of the rays stand at the same
     * radius in all four of the owner's frames, and only the notches between them go deeper:
     * across the axes 20.5, 20.5, 16.0 and 11.5, across the diagonals 22.2, 15.4, 10.5 and
     * 3.8. So nothing grows and nothing is added: the ring is cut into ever deeper notches
     * until only the rays are left. Between the knots the four numbers are carried straight
     * across, and the stroke is drawn as the fill of the polygon with its two-pixel inward
     * layer removed — see pv_punch(), where the two erodes and why are written down.
     *
     * It sits on the knob the page used to call BODY (PERC_BODY_TRIM): the parameter number
     * stays, so a preset keeps its value on that knob, and the value now means the attack.
     */
    PREVIEW_PUNCH,

    /*
     * TIMBRE, the drum's life — the owner drew two frames: at the minimum a comb of seven
     * tines whose tops form an even arc, at the maximum the same comb with the tines of very
     * different lengths. So the figure says what the knob does: the part stops being a machine.
     *
     * Everything except the tops is constant. The base — a two-row floor with a notch and an
     * arch over it — is the instrument the comb stands on, and in the owner's two frames it is
     * the same pixel for pixel, so it is drawn from a formula rather than from his frame: a
     * ring of radii 9.00 and 11.00 about the field's own axis, which is exactly two pixels
     * thick along the normal and symmetric by construction. His drawing is hand-made and its
     * halves disagree by a pixel in two places; the formula is what makes the arch even.
     *
     * The tines are seven, two pixels wide, six apart, from x = 3 to x = 40, with the same
     * bottom in every frame: each one ends where it meets the base and never leaves it. Only
     * the top moves, from the even arc 13, 6, 3, 2, 3, 6, 13 to his chaotic 25, 12, 22, 7, 12,
     * 2, 32 — one tine longer than the arc, the rest shorter. Above the minimum the tops are
     * deliberately not symmetric: the scatter is the thing the knob is for.
     */
    PREVIEW_PERC_TIMBRE,

    /*
     * SCATTER, how far an onset wanders from its grid line — the owner drew the sequence as six
     * frames: one stripe, the same stripe twice as wide, three stripes, the middle one wide
     * again, five stripes, and five wider still.
     *
     * Read as one sequence, the wide middle is not a stripe growing thicker: it is a PAIR of
     * stripes born on the centre line. A pair is invisible while it stands at zero (its two
     * stripes lie on the centre one), makes the centre look twice as wide at one pixel, and
     * then walks outwards. So the figure is always the centre stripe plus two pairs, each with
     * its own half-distance from the centre: the count goes one, three, five, and the outermost
     * pair ends at fifteen pixels.
     *
     * The diamond is constant and is a formula, not his frame: the owner's hand puts its right
     * side a pixel wider than its left in almost every row, so the figure is a ring of constant
     * thickness about the field's own axis instead. Two details of his drawing are kept as they
     * are, because they are the same in all six frames: the upper arm of every stripe stops on
     * the diamond's axis (row 21) and the lower one starts where the stripe comes out from under
     * the diamond's lower edge, not at the axis.
     */
    PREVIEW_SEQ_SCATTER,

    /*
     * NOTE, the tonic of the scale — twelve icons, one per position of the list, and no figure at
     * all. The knob is the one on SCALE's page whose value is a name rather than an amount, so
     * there is nothing for a curve to say: the owner drew twelve drawings in the list's order, C
     * to B, and the picture is the one his drawing holds for the position the hand is on.
     *
     * The twelve are one lattice seen through windows of different width: 26, 33, 38, 43, 44,
     * 44, 44, 44, 43, 38, 33, 26 pixels from C to B, hung on the right edge for C..D# and on the
     * left edge for G#..B, so the figure opens from C to E, fills the field from E to G, and
     * closes to B. The set therefore swings across the field as the note rises, which is the
     * dynamics the owner's slider prototype was built to judge: the neighbour-to-neighbour
     * difference is 474, 548, 628, 588, 136, 612, 644, 614, 656, 610 and 502 pixels, and the
     * small one is E to F, which stand on the same lattice.
     *
     * Like DELAY_MODE and the oscillator shapes, the icons are carried whole — see pv_note(),
     * which hands the mask the 44 x 6 bytes of the position and nothing else.
     */
    PREVIEW_NOTE,

    /*
     * SHAPE, the lead filter envelope's split — the sixth sector of the TONE page.
     *
     * The envelope is an AR: a rise from the base line to the top of the field and a fall
     * back to it, and the knob is where the peak stands between the two ends. At -100 % the
     * rise is a wall at the left edge and the fall takes the whole picture, at 0 % it is a
     * symmetric triangle, at +100 % the rise owns the picture and the fall is a wall at the
     * right edge. Two straight segments of two pixels, which is the whole of what the shape
     * is: the curve is a one-pole in the filter, and a picture of a curve that reads as a
     * line is one more thing to decode.
     *
     * The peak travels in whole pixels of the 44-pixel field, so two positions of the knob
     * that are closer than 1/44 of the travel draw the same frame — the same quantisation
     * every other figure on this instrument has.
     */
    PREVIEW_LEAD_FENV_SHAPE,

    /*
     * VOICE, the lead's MONO and POLY — the fourth sector of the LEAD page.
     *
     * One line, four, or three stacked, and that is the picture: MONO is a single stroke
     * across the middle of the field, POLY is four of them spread over it, CHORD is three
     * laid on one another with a gap in the voicing. Each stroke is one note, because the
     * switch changes how many notes can sound at once and not how long any of them is.
     *
     * Three states, so the figure has three frames and the hand turning the knob sees it
     * change twice: at twenty-five and at seventy-five, the two thirds of the travel that
     * the detents split it into.
     */
    PREVIEW_LEAD_VOICE,

    /*
     * GATE AND PORTA, the lead's articulation: how long a note is held before it starts to
     * fall, and how fast the fall begins.
     *
     * Both figures come from the owner's own frames, one frame for each end of the travel,
     * and the frames between them are the runs of his two sliding in a straight line — see
     * pv_lead_rows() in the source. GATE is two posts joined at the top with a bar at the
     * foot: at zero the posts stand four pixels apart and the bar runs away to the right,
     * at full they stand at the field's edges and the bar has been swallowed by the post.
     * PORTA is two brackets, the corners between the posts and the bars sharp at zero and
     * rouned off to the limit at full.
     */
    PREVIEW_LEAD_GATE,
    PREVIEW_LEAD_PORTA,

    /*
     * THE MICROPHONE'S ENVELOPE, AND THE LINE THAT FALLS ONTO IT.
     *
     * DEPTH on the LFO's MIC shape: the microphone's envelope is the comb along the foot,
     * and the LFO's own line starts as a straight rule at the top of the field and comes
     * down as the depth rises. It lies on the columns it reaches, two rows of air above
     * them, and sags between them no steeper than forty-five degrees — a rope dropped on
     * a row of pegs, which is what the owner drew. Columns it never reaches keep their
     * air, which is the whole of what the figure says: the depth is how much of the
     * envelope the modulation takes. See pv_lfo_mic() in the source.
     */
    PREVIEW_LFO_MIC,
} synth_preview_kind_t;

/* What the middle should show for `param`, or PREVIEW_NONE. */
synth_preview_kind_t synth_preview_kind(synth_param_t param);

/*
 * Everything the picture depends on, quantised to the pixel grid and packed into
 * one word. Equal keys mean the 392 bytes would be identical, which is how a
 * redraw is skipped while a knob moves inside one screen pixel: the values are
 * quantised to 1/50 of the travel, the same 50 columns the mask is drawn on.
 */
uint32_t synth_preview_key(synth_param_t param);

/* Fill `mask` (SYNTH_PREVIEW_BYTES) with the picture for `param`'s current value. */
void synth_preview_mask(synth_param_t param, uint8_t *mask);

/*
 * Paint the lit bits of `mask` into an RGB565 buffer.
 *
 * `dst` points at the first visible pixel of the picture's box inside the layer,
 * `stride_px` is the layer's row stride in pixels, and (`mx`,`my`) is where the
 * visible rectangle starts inside the 56x56 mask. The caller has already clipped
 * against the layer, so nothing here writes outside `w` x `h`.
 */
void synth_preview_blit(const uint8_t *mask, uint16_t *dst, int stride_px,
                        int mx, int my, int w, int h, uint16_t colour);

#ifdef __cplusplus
}
#endif
