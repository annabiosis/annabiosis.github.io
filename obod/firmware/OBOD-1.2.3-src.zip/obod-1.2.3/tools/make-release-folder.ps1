# Склад выпуска: папка releases/<версия> в рабочей области.
#
# В неё кладётся всё, чем выпуск раздавался, и копия страницы сайта на день выпуска. Папка не
# коммитится: это склад того, что уже опубликовано, а не исходники. Код выпуска в README не
# пишется — он живёт только в посте Boosty.
#
# Запуск: pwsh -File tools\make-release-folder.ps1 -Version 1.2.2
#         pwsh -File tools\make-release-folder.ps1 -Version 1.2.2 -Rel D:\releases
[CmdletBinding()]
param(
  [Parameter(Mandatory = $true)][string]$Version,
  [string]$Rel  = (Join-Path $PSScriptRoot '..\..\releases'),
  [string]$Site = (Join-Path $PSScriptRoot '..\..\annabiosis.github.io\obod')
)

$ErrorActionPreference = 'Stop'

$webflash = Join-Path $PSScriptRoot 'webflash'
$out      = Join-Path ([IO.Path]::GetFullPath($Rel)) $Version

$need = @(
  'firmware\OBOD.bin',
  'firmware\OBOD.bin.enc',
  "firmware\OBOD-$Version-src.zip",
  'lock.json',
  'manifest.json',
  'sources.json'
)

foreach ($f in $need) {
  $p = Join-Path $webflash $f
  if (-not (Test-Path -LiteralPath $p)) { throw "нет файла выпуска: $p" }
}

if (-not (Test-Path -LiteralPath $Site)) { throw "нет папки сайта: $Site" }
if (Test-Path -LiteralPath $out) { Remove-Item -LiteralPath $out -Recurse -Force }
New-Item -ItemType Directory -Path $out | Out-Null

foreach ($f in $need) {
  Copy-Item -LiteralPath (Join-Path $webflash $f) -Destination (Join-Path $out (Split-Path $f -Leaf))
}

# Копия страницы сайта: то, что человек видел в день выпуска.
Copy-Item -LiteralPath $Site -Destination (Join-Path $out 'site') -Recurse

# Хеши файлов папки, кроме самой копии сайта: она большая и её хешировать незачем.
$lines = Get-ChildItem -LiteralPath $out -File | Sort-Object Name | ForEach-Object {
  $h = (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash
  "$h  $($_.Name)  $($_.Length) байт"
}
Set-Content -LiteralPath (Join-Path $out 'SHA256SUMS.txt') -Value $lines -Encoding utf8

$bin = Join-Path $out 'OBOD.bin'
$sz  = (Get-Item -LiteralPath $bin).Length
$sha = (Get-FileHash -LiteralPath $bin -Algorithm SHA256).Hash

$readme = @"
# OBOD $Version

Склад выпуска: образ, архив исходников, замок и копия страницы сайта на день выпуска.

- образ: `OBOD.bin`, $sz байт, SHA-256 `$sha`
- запечатанный образ: `OBOD.bin.enc` (на сайте лежит он, открытый образ — только здесь и на
  странице выпуска в GitHub)
- исходники: `OBOD-$Version-src.zip`, собран из тега `v$Version`
- код выпуска: в посте Boosty, в этой папке не хранится
- страница сайта: `site/`, копия на день выпуска

Хеши всех файлов — в `SHA256SUMS.txt`.
"@
Set-Content -LiteralPath (Join-Path $out 'README.md') -Value $readme -Encoding utf8

"папка выпуска: $out"
Get-ChildItem -LiteralPath $out | Select-Object Mode, Name, Length | Format-Table -AutoSize
