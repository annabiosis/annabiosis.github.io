[Русский](RELEASE-NOTES.md) · **English**

# OBOD 1.2.3

A round synthesizer-controller on the ESP32-S3 with a 360 × 360 dial.

## What is new in 1.2.3

A release about a lead that can sound more than one voice, about a drone that stopped being a
generator, and about knobs that lie a little less than they did.

The lead's VOICE gained a third position, CHORD. A note from the line or from a key sounds as three
scale degrees a third apart, and each degree takes its own voice, so the chord holds as long as the
note holds instead of stopping on the second tone. In the middle of the dial it shows itself as
three bars — the drawing the owner made. The knob's order is back to what it was: POLY, MONO,
CHORD, and the zero of the scale means polyphony again, so old sounds read as they were saved. The
factory position is POLY too. A preset saved in 1.2.2 — where mono came first — comes back with the
opposite position and wants one re-save.

The drone is no longer three exact octaves. DRIFT spreads the registers by up to a semitone, each in
its own phase at one slow speed — a breath every ten seconds — so the three voices meet and part,
and the beats come out uneven, like a live ensemble. The working zone is the first twenty cents,
zero leaves the old sound untouched to the cent, and the top of the travel, a semitone, is there
for experiments rather than for music. The drone's LEVEL became a modulation destination: the LFO
section can swing its level alongside pan, the lead and the drums, or instead of them.

The generator gained SPAN: a walk of one, two or three octaves instead of the two that were written
into the code. On a five-note scale one octave gives a mode rather than a flight, and three give
wide, rare phrases; the factory middle keeps the old behaviour, so stored patches sound as they did.

The scales number twenty-one: IN-SEN, NIKRIZ, HIJAZ, SABA and PERSIAN joined, and the whole list is
ordered by consonance — from the pure degrees to the chromatic one. The position in the list is
what is stored, so the reordering comes with a migration: both the remembered patch and every
record in the preset store walk the old position's map once, at the first start, and a saved sound
stays the mode it was saved as.

Modulation no longer does anything at zero. Choosing a destination in the LFO section changed the
sound even with DEPTH at zero, because the receivers took their depth from a knob on another page.
Now the depth multiplies every receiver, so at zero the section is silent, and the depths of the LFO
and of the filter's own modulator add up as they were meant to: they are two independent
modulators, and a patch may open the sweep from either page or from both.

The level faders in LEVELS and PERC MIX follow a square law. A linear multiplier packed all of the
useful travel into the first third — half of it was only −6 dB, which is nearly as loud. A square
gives −12 dB at the middle, and every ten percent takes off about the same. The numbers read on
screen are unchanged: the factory values are written as the square roots of the old ones.

The level meters turn red within a tenth of their ceiling, the preset page has a DEL, the
arpeggiator has an OFF button, and the chord that used to sound one tone out of three now sounds
all three.

## What is inside

A drone of three spectral parts, a lead of three voices — mono, polyphonic or in chords — drums of
five voices and a microphone input used as a modulation source. Two sequencers, an arpeggiator,
twenty-one scales with quantisation of incoming notes. Effects: chorus, ping-pong delay and reverb
in four modes, the Dattorro plate among them. Twenty-three pages, one hundred and twelve knobs, one
hundred and fifteen sound parameters and one hundred and twenty-eight preset slots in NVS. USB-MIDI
note input with transport and clock.

## What is in the archive

The project's source code, `dependencies.lock` with pinned component versions, the browser flashing
page, the hardware and signal-chain documentation, and the feature and third-party lists.

The ready image is not part of the source archive: it lives in the repository and on the GitHub
release page — `OBOD.bin`, 1 279 536 bytes, SHA-256
`4B7EB1C920C83DA4B8FDA06E58327CFC73C71826A55587ECF4AE4048DC706D37` — while the site carries it
sealed only. The source archive on the site is open to everyone, with no release code.

## Flashing procedure

```
pwsh -NoProfile -File .\tools\idf.ps1 -p COM4 flash
```

Or in the browser: the flashing page on the site, `tools/webflash/serve.ps1` locally. The image on
the site is sealed: the page asks for the release code, derives the key from it and decrypts the
file in the browser, and the device receives an already decrypted image. The release code is one per
release and lives in a Boosty post: posts with codes are available at any subscription level
(boosty.to/annabiosis). Details are in `docs/RELEASE.md`.

## Known limitations

Note input is off at the factory and takes the single USB controller, so there is no debug COM port
on the cable. Control change, pitch bend and program change are not handled, and there is no MIDI
output. A tempo taken from external clock does not reach the delay's sync. There is no master
limiter and no dither, and no Bluetooth MIDI. Kits and grooves are stored by their position in a
list, so a preset from an earlier release may land on another kit or groove: the lists grew longer.

The Russian text in [RELEASE-NOTES.md](RELEASE-NOTES.md) is the source; if the two diverge, the Russian one is right.
