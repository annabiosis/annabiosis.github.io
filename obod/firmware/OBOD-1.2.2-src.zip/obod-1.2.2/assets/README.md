# Runtime assets

Files in this folder are packed into the on-board SPIFFS `storage` partition
and appear on the device at **`/assets`** — not on the SD card, which is a
separate filesystem at `/sdcard`.

Upload them without reflashing the application:

```
VS Code → Tasks: Run Task → FS: Upload assets to SPIFFS
```

or

```powershell
pwsh -File tools/upload_fs.ps1 -Port COM7
```

## Why this exists

During UI work, most changes are an image or a sound, not code. Repacking a
2 MB asset partition takes a couple of seconds; a full build-and-flash cycle
does not. Keeping assets here makes that swap cheap.

## Choosing between this and the SD card

| | `assets/` → SPIFFS `/assets` | SD card `/sdcard` |
|---|---|---|
| Always present | yes | only if a card is inserted |
| Capacity | 7 MB (see `partitions.csv`) | gigabytes |
| Update cost | seconds, over USB | card reader, or an upload path in firmware |
| Wear | flash erase cycles | none |

Rule of thumb: boot-critical UI assets (fonts, icons, the splash image) go
here; anything the user supplies — photos, music, exports — goes on the card.

## Note on `spiffsgen.py`

The upload script sizes the image from `partitions.csv` and calls ESP-IDF's
own `spiffsgen.py`, so editing the partition table keeps it correct. The
`storage` partition is 7 MB, which is why the image cannot simply be made
larger without repartitioning — the two 4 MB OTA slots leave little room.
