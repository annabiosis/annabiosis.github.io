/*
 * Guition JC3636K718C — example application.
 *
 * This file is deliberately thin. It shows the intended shape of an
 * application built on this framework:
 *
 *   1. bring the board up in one call;
 *   2. start the instrument, which takes ownership of the audio output;
 *   3. build the instrument's own screen through ui_app;
 *   4. leave the network alone: it is deliberately not started here;
 *   5. present the board as a USB MIDI device, so notes played on a computer
 *      reach the instrument — channel 1 the lead, channel 2 the percussion
 *      (components/midi; APP_MIDI_ENABLE below);
 *   6. confirm the firmware image so OTA rollback is cancelled.
 *
 * The screen is built by components/synth_ui, not by the SquareLine export,
 * because components/ui/generated/ui.c is a placeholder that
 * tools/squareline_sync.ps1 replaces wholesale. Application screens belong in a
 * component of their own; see the note in ui_app.h.
 */

#include <stdio.h>

#include "esp_heap_caps.h"
#include "esp_log.h"
#include "esp_system.h"

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "app_net.h"
#include "app_settings.h"
#include "bsp/bsp.h"
#include "midi_in.h"
#include "synth_app.h"
#include "synth_dsp.h"
#include "synth_ui.h"
#include "ui_app.h"

static const char *TAG = "app";

/* -------------------------------------------------------------------------- */
/* Network bring-up: off                                                      */
/* -------------------------------------------------------------------------- */
/*
 * The network stays off: the instrument has no use for one. Firmware is
 * written over the wire — the browser flasher or esptool — nothing is downloaded
 * over Wi-Fi, and no screen, tile or status line reads the link. So app_main
 * does not call app_net_init(), the Wi-Fi stack is never initialised, and the
 * SoftAP of a first boot never comes up.
 *
 * components/app_net is untouched and still builds — this switch only takes out
 * its two call sites below. Set it to 1 and the network comes back exactly as it
 * was, including the ring indication; nothing else has to change.
 */
#define APP_NET_BRINGUP 0

#if APP_NET_BRINGUP
/* -------------------------------------------------------------------------- */
/* Network status on the LED ring                                             */
/* -------------------------------------------------------------------------- */
/*
 * The ring belongs to the drone. synth_ui draws the three registers' positions
 * in the stereo field on it, which is the one output that can be read from
 * across the room without looking at the screen.
 *
 * Network state still has to be able to say something, so it BORROWS the ring
 * for a few seconds and then releases it rather than writing to it directly. Two
 * subsystems both owning the ring would leave it showing whichever of them
 * happened to write last, which is how a status indicator turns into a lie.
 */

#define RING_NET_HOLD_MS 4000

static void ring_show_state(app_net_state_t state)
{
    if (!bsp_led_is_available()) {
        return;
    }

    switch (state) {
    case APP_NET_STATE_CONNECTED:
        synth_ui_ring_notify(0, 120, 0, RING_NET_HOLD_MS);  /* green */
        break;
    case APP_NET_STATE_PROVISIONING:
        synth_ui_ring_notify(180, 135, 0, RING_NET_HOLD_MS);/* amber, waiting for a phone */
        break;
    case APP_NET_STATE_CONNECTING:
    case APP_NET_STATE_DISCONNECTED:
        synth_ui_ring_notify(0, 135, 180, RING_NET_HOLD_MS);/* blue, working on it */
        break;
    case APP_NET_STATE_FAILED:
        synth_ui_ring_notify(144, 0, 0, RING_NET_HOLD_MS);  /* red */
        break;
    default:
        /* Nothing to say: hand the ring back immediately. */
        synth_ui_ring_notify(0, 0, 0, 0);
        break;
    }
}

/*
 * Called from the system event task. Keep it short — this runs on the same
 * task that delivers Wi-Fi events.
 */
static void net_state_cb(app_net_state_t state, void *user)
{
    (void)user;

    ESP_LOGI(TAG, "network: %s", app_net_state_name(state));
    ring_show_state(state);

    /* An IP address is the one thing worth surfacing loudly, because it is
     * what you need in order to reach the device. */
    if (state == APP_NET_STATE_CONNECTED) {
        ESP_LOGI(TAG, "reachable at http://%s.local", CONFIG_APP_NET_HOSTNAME);
    }
}
#endif /* APP_NET_BRINGUP */

/* -------------------------------------------------------------------------- */
/* USB MIDI input: does the feature exist at all                              */
/* -------------------------------------------------------------------------- */
/*
 * The feature's own switch, and it is no longer the decision. The decision is the
 * MIDI IN setting (APP_SET_MIDI_IN), which is OFF at the factory and is what the
 * OPTIONS page toggles while the instrument plays; this macro says only whether
 * the firmware carries the component.
 *
 * Two switches rather than one, because they answer different questions. This one is
 * "can this build be a MIDI device" — set it to 0 and app_main never calls
 * components/midi at all, the USB device stack is not linked in as far as the boot
 * path is concerned, and the answer to the port question is never in doubt. That is
 * the same arrangement as APP_NET_BRINGUP above and for the same reason: a switch
 * that also had to change the build graph would be a switch nobody dares turn off.
 *
 * The other one is "should the instrument be one right now", and it has to be a
 * SETTING rather than a macro for the reason the whole change exists: only one
 * controller can own the USB PHY, so while the device stack is up the USB-C socket
 * is a MIDI port and the debug console is gone from the computer. A macro would make
 * that a reflash; the setting makes it a turn of the MIDI IN knob on OPTIONS — see
 * midi_in_set_enabled(), which is the call both paths go through.
 *
 * AND IT IS A DECISION ABOUT THE NEXT BOOT as much as about this one. Turning the
 * input off uninstalls the driver and releases the USB controller, but the debug
 * port does not come back to the computer while the instrument runs: it is on the
 * cable again after a restart with the setting OFF, because that is the value the
 * read below asks for. The port question is therefore settled at boot, and the turn
 * only says what the next boot will answer.
 *
 * NOTHING IS SENT BACK, and no MIDI setting beyond the switch exists: which part a
 * note plays is part of the MESSAGE rather than a setting — channel 1 is the lead and
 * channel 2 is the percussion, and the other fourteen channels are dropped.
 */
#define APP_MIDI_ENABLE 1

/* -------------------------------------------------------------------------- */
/* Reset diagnostics                                                          */
/* -------------------------------------------------------------------------- */

/*
 * Printed on every boot. A reset that produces no log of its own — the RTC
 * watchdog, a brownout, a CPU lockup — is otherwise indistinguishable from
 * "the device rebooted for no reason".
 *
 * The ROM banner that carries the hardware reset reason is not a substitute:
 * it is emitted before the console is usable when the console is the internal
 * USB-Serial-JTAG, because that peripheral re-enumerates during the reset and
 * the host is not listening yet when the banner goes out. Reading the reason
 * from inside the application is the only reliable way to see it.
 */
static const char *reset_reason_name(esp_reset_reason_t reason)
{
    switch (reason) {
    case ESP_RST_UNKNOWN:     return "unknown";
    case ESP_RST_POWERON:     return "power-on";
    case ESP_RST_EXT:         return "external pin";
    case ESP_RST_SW:          return "software (esp_restart)";
    case ESP_RST_PANIC:       return "panic / abort";
    case ESP_RST_INT_WDT:     return "interrupt watchdog";
    case ESP_RST_TASK_WDT:    return "task watchdog";
    case ESP_RST_WDT:         return "other watchdog";
    case ESP_RST_DEEPSLEEP:   return "deep sleep wake";
    case ESP_RST_BROWNOUT:    return "brownout";
    case ESP_RST_SDIO:        return "SDIO";
    case ESP_RST_USB:         return "USB peripheral";
    case ESP_RST_JTAG:        return "JTAG";
    case ESP_RST_EFUSE:       return "eFuse error";
    case ESP_RST_PWR_GLITCH:  return "power glitch";
    case ESP_RST_CPU_LOCKUP:  return "CPU lockup";
    }
    return "unknown";
}

/*
 * The first line the application prints, before bsp_init() and before anything
 * else can fail. The extra warnings are separate diagnoses on purpose: a panic
 * is a fault in the code and leaves a core dump, while a brownout is the supply
 * dipping under load and leaves none.
 */
static void log_reset_reason(void)
{
    const esp_reset_reason_t reason = esp_reset_reason();

    ESP_LOGI(TAG, "reset reason: %d (%s)", (int)reason, reset_reason_name(reason));

    switch (reason) {
    case ESP_RST_PANIC:
        ESP_LOGW(TAG, "previous boot ended in a panic - a core dump should be in flash; "
                      "run tools/crash.ps1 to read it");
        break;
    case ESP_RST_BROWNOUT:
    case ESP_RST_PWR_GLITCH:
        ESP_LOGW(TAG, "previous boot ended in a power fault, not a code fault - "
                      "check the 5 V rail, the ring and the backlight before the firmware");
        break;
    case ESP_RST_TASK_WDT:
    case ESP_RST_INT_WDT:
    case ESP_RST_WDT:
    case ESP_RST_CPU_LOCKUP:
        ESP_LOGW(TAG, "previous boot ended in a watchdog timeout or CPU lockup - "
                      "a task or an interrupt did not return");
        break;
    default:
        break;
    }
}

/* -------------------------------------------------------------------------- */
/* Memory accounting                                                          */
/* -------------------------------------------------------------------------- */

/*
 * Internal RAM is the scarce resource here, not PSRAM: 212 KB total, and the
 * LVGL buffers and every task stack have to come out of it. The synth's own
 * statics already take 38 KB of that. Wi-Fi used to take a large share as well;
 * it is no longer started, so these numbers now show what the instrument alone
 * costs (see APP_NET_BRINGUP).
 *
 * Printing it at each bring-up step is what attributes a drop to a stage. A
 * single total at the end says only that something is expensive.
 */
static void log_internal_heap(const char *stage)
{
    /*
     * The DMA pair matters as much as the total. The display's draw buffers are
     * allocated MALLOC_CAP_DMA only, and when Wi-Fi came up it wanted the same
     * pool for the SoftAP's beacon buffers: a total that looked healthy could
     * still hide a DMA pool with nothing left in it. That is exactly what
     * happened once — Wi-Fi failed to allocate 752 bytes with seven kilobytes
     * free. Nothing competes with the display for that pool now, and the pair is
     * what would catch it if the network is ever switched back on.
     */
    ESP_LOGI(TAG, "internal heap after %-16s %6u B free of %u B, largest %u B, DMA %u/%u B",
             stage,
             (unsigned)heap_caps_get_free_size(MALLOC_CAP_INTERNAL),
             (unsigned)heap_caps_get_total_size(MALLOC_CAP_INTERNAL),
             (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL),
             (unsigned)heap_caps_get_free_size(MALLOC_CAP_DMA),
             (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_DMA));
}

/* -------------------------------------------------------------------------- */
/* Entry point                                                                */
/* -------------------------------------------------------------------------- */

void app_main(void)
{
    log_reset_reason();

    log_internal_heap("boot");

    /* --- 1. Board --------------------------------------------------------- */
    /*
     * BSP_FEATURES_ALL brings up the SD card and the audio codec as well, both
     * of which are optional on this board: no card inserted, or no PCM5100A
     * fitted, produces a warning rather than a failure. bsp_init() returns the
     * first error but still initialises everything else, so it is deliberately
     * not wrapped in ESP_ERROR_CHECK.
     */
    const bsp_features_t features = BSP_FEATURES_ALL();
    const esp_err_t bsp_err = bsp_init(&features);
    if (bsp_err != ESP_OK) {
        ESP_LOGW(TAG, "board came up with warnings (first: %s)", esp_err_to_name(bsp_err));
    }
    bsp_print_info();
    log_internal_heap("bsp_init");

    /* --- 2. Instrument ---------------------------------------------------- */
    /*
     * Started before the UI on purpose: this device's job is to make sound, and
     * from here on the audio task owns the I2S output. It blocks on the DMA for
     * most of every block, so the UI still gets the CPU it needs.
     *
     * Everything the synth configures happens inside synth_app_start(), before
     * its audio task is created — the engine has no locking of any kind, so
     * nothing outside that task may call into it afterwards. That is also why
     * the UI talks to synth_app_set_*() rather than to the engine.
     */
    synth_app_start();
    log_internal_heap("synth_app_start");

    /* --- 2b. What the device remembers ------------------------------------- */
    /*
     * After the instrument, because the sound it may restore has to land on top
     * of the designed voicing rather than under it; before the screen, because
     * synth_ui reads these back while it builds, so that the first thing drawn
     * is the truth rather than a default that is corrected a frame later.
     *
     * This also applies the backlight and the ring brightness, which is why it
     * cannot move any earlier than bsp_init().
     */
    app_settings_init();
    log_internal_heap("app_settings_init");

#if CONFIG_OBOD_STRESS
    /* --- 2c. The stress program, when this is a service build --------------- */
    /*
     * After the settings, because a preset save and load is part of its program and
     * that store is what app_settings_init() opens; before the screen, because the
     * stress program is the only thing this build is for and it needs no page. The
     * task waits a few seconds for the instrument to settle, then runs on its own.
     */
    synth_app_stress_start();
    log_internal_heap("synth_app_stress_start");
#endif

    /* --- 3. Instrument screen --------------------------------------------- */
    /*
     * synth_ui_build() replaces the SquareLine placeholder as the screen
     * builder. Nothing else changes: ui_app still puts the screen's single
     * focusable control under the knob and styles the focus, exactly as it does
     * for the generated UI.
     */
    ESP_ERROR_CHECK(ui_app_init_with_screen(NULL, synth_ui_build));
    log_internal_heap("ui_app_init");

    /*
     * The volume the instrument is actually going to play at, after the screen has put
     * back whatever sound was remembered. One line, because "80% out of the box" and
     * "the sound I saved kept its own level" are both claims about this number.
     */
    ESP_LOGI(TAG, "master %d%%",
             (int)(synth_app_get_param(SYNTH_PARAM_LEVEL) * 100.0f + 0.5f));

    /*
     * The screen is built, so the panel can be lit. The BSP holds the backlight dark
     * until this call: LVGL's own starting screen is white and is what a refresh would
     * draw for the ~800 ms between the port coming up and this point, so lighting on
     * the first refresh showed white for that whole window. From here the level stored
     * in the settings fades up over 200 ms. See bsp_display.h.
     */
    bsp_display_backlight_show();

    /* --- 4. Network: deliberately not started ------------------------------ */
    /*
     * app_net_init() used to be called here, and it is the call that raised the
     * Wi-Fi stack. It is not called any more: the instrument is updated over the
     * wire, and nothing in the UI reads the link, so the radio stays down and
     * the run-time cost and the initialisation order it imposed are gone.
     *
     * Nothing else in this file or in the UI depends on the network having been
     * initialised — see app_net_get_state() / app_net_is_connected() below the
     * switch at the top: they are compiled out with their only callers.
     *
     * The component itself is untouched and still built. Set APP_NET_BRINGUP to
     * 1 to bring this back exactly as it was.
     */

#if APP_NET_BRINGUP
    const esp_err_t net_err = app_net_init();
    if (net_err != ESP_OK) {
        ESP_LOGW(TAG, "network unavailable: %s", esp_err_to_name(net_err));
    } else {
        app_net_register_state_cb(net_state_cb, NULL);
        ring_show_state(app_net_get_state());
    }
    log_internal_heap("app_net_init");
#endif /* APP_NET_BRINGUP */

    /* --- 5. USB MIDI: the instrument as a MIDI device, if it is switched on -- */
    /*
     * Last of the bring-up, deliberately: installing the device stack hands the
     * USB-C port to a peripheral that enumerates and answers the host, and doing
     * that before the panel is lit and the instrument is playing would put a
     * device on the computer that is silent for reasons of its own.
     *
     * Everything the notes will reach already exists by this point — the audio
     * task that drains the ring is running — so a host that starts sending the
     * moment it sees the port cannot outrun the instrument.
     *
     * AND IT IS ASKED FOR, not assumed: the MIDI IN setting is OFF out of the
     * factory, because up means the debug console is gone from the computer while
     * the instrument runs. app_settings_init() above has already read it back, so
     * the port the board offers is the one chosen on the screen — and the
     * choice is made again on every boot, which is what makes a board that was
     * switched off with the console gone come back reachable.
     *
     * The screen's own settings restore has already applied the same value by the
     * time this runs, because the engine starts before the screen is built. That
     * makes this call a restatement in the normal case, and it is kept anyway: main
     * is where a boot decision belongs, asking twice costs one comparison — an
     * enable that is already in force returns at once — and a build without the
     * screen still gets the input it was configured with.
     *
     * A failure here is a warning and not a stop: no MIDI input is a cable to
     * look at, and the instrument plays either way.
     */
#if APP_MIDI_ENABLE
    if (app_settings_get(APP_SET_MIDI_IN)) {
        const esp_err_t midi_err = midi_in_start();
        if (midi_err != ESP_OK) {
            ESP_LOGW(TAG, "USB MIDI unavailable: %s", esp_err_to_name(midi_err));
        } else {
            ESP_LOGI(TAG, "MIDI in: on - the USB-C port is the MIDI device, not the console");
        }
    } else {
        ESP_LOGI(TAG, "MIDI in: off - the USB-C port stays the debug console");
    }
    log_internal_heap("midi_in_start");
#endif /* APP_MIDI_ENABLE */

    /* --- 6. Confirm the firmware image ------------------------------------ */
    /*
     * If the image was written into an OTA slot, the bootloader is holding the
     * previous one in reserve and rolling back unless the image declares itself
     * healthy. The channel that would deliver such an image is not connected any
     * more, but flashing over the wire can leave the same pending state, so the
     * confirmation stays. Reaching this point means the board booted, the panel
     * came up and the instrument screen was built — a reasonable definition of
     * healthy for this device.
     *
     * Move this later (after a self-test, or on first user interaction) if a
     * crash shortly after boot should still trigger a rollback.
     */
    app_ota_mark_valid();

    /*
     * The one thing the audio task has been waiting for: the boot is over, so release
     * the master. Until this call the rack writes exact zeros; from here it waits
     * 150 ms and fades the MASTER up over 700 ms. The call is immediately before the
     * line below on purpose, because "boot complete" is the moment the owner is
     * promised that nothing of the boot is being heard.
     */
    synth_rack_boot_arm();

    ESP_LOGI(TAG, "boot complete");

    /* --- 7. The effects take their memory now ------------------------------ */
    /*
     * The delay's four-second line is a megabyte and a half of PSRAM, and clearing it
     * competes with the audio task for the bus that task runs from. Inside the boot
     * sequence that stopped the radio; at the first turn of a mix knob it landed in the
     * middle of a phrase. So the claim is made here, after the panel, the settings and
     * the radio are up, and it is made by a background task that waits three seconds and
     * then takes the three effects one at a time. A mix knob turned before it has
     * finished still finds silence until the line is ready, which is exactly what it
     * found before; the difference is that the wait now happens before anybody plays.
     *
     * This is the last thing app_main does: nothing below depends on the memory, and a
     * failed claim leaves the effect bypassed rather than holding up the boot.
     */
    synth_dsp_prefetch_start();

    /*
     * Nothing left to do here. LVGL runs in its own task, the audio task in its
     * own, and the application reacts to events. A busy loop in app_main would
     * only compete for CPU.
     *
     * Note that the numbers logged above are a snapshot of bring-up, not the
     * steady state: the synth's own stats line, printed once a second forever,
     * carries the settled figure.
     */
    vTaskDelete(NULL);
}
