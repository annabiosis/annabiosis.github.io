[Русский](README.md) · **English**

# OBOD

A drone synthesizer on the ESP32-S3. A round 360 × 360 display and an encoder: there
are two controls — the ring around the display and the display itself. Notes are
received over USB-MIDI, the sound is stored in 128 preset slots.

Version 1.2.1. MIT license — see [LICENSE](LICENSE).

![Device, front](docs/images/device-front.svg)

## What it is and what it can do

Engine: 48 kHz, 24 voices, 6 buses, 500 Hz control rate, 128-sample block. The
real-time budget is 2.67 ms per block; a typical block is computed in about 1.3 ms.

| | |
|---|---|
| Voices | 24: drone 9 (three registers of three detuned voices each), lead 9 (three notes at once, two oscillators and a sub per note), arpeggiator 3, percussion 3 |
| Drone | three spectral parts LOW, MID, HIGH, each with a waveform of its own: six waveforms SIN, TRI, SAW, SQR, SPR, NSE; filter with sweep and pan drift; follows the lead on request (STAY, SCALE, FULL, CONS) |
| Lead | its own tone, envelope, note generator, Euclidean grid, arpeggiator |
| Sequencers | two Euclidean ones: one for the lead, one for the percussion |
| Percussion | three voices on a band-pass filter, its own Euclidean grid, send to reverb |
| Scales | sixteen, from pentatonics to diminished and chromatic; an incoming note is snapped to the selected scale relative to ROOT |
| Effects | chorus, ping-pong delay, reverb in four modes: ROOM, HALL, CATH, PLAT |
| Mixer | master volume, one-knob master compressor, part levels and sends |
| Microphone | PDM input, sensitivity up to 6×, send to reverb |
| Interface | 22 pages, 99 knobs on the screens, eight color families, a drawer with the section map, a transport screen |
| Patch | 88 parameters — exactly as many as a preset stores |
| Presets | 128 slots in NVS, two-word names, LOAD / SAVE / RND |
| MIDI | note reception over USB: channel 1 — lead, channel 2 — percussion, transport and clock |

Three things around which the control is built deserve to be named separately:

- a **macro** is a live binding, not a preset: a long press on a parameter ties it to
  others under one knob, a double tap turns on inversion;
- the **indication ring** in four modes: the value of the selected knob, a stereo
  picture, light show, and off;
- **random sound in two depths**: a short press changes only the timbre, a long press
  also adds structure — grids, arpeggiator, effect mixes.

There are two ACCENT knobs, one per grid: for the percussion it marks the weak beats of
the hits, for the lead — notes, and the knob on one grid does not move the other. It is not the marked hit that plays quieter, but the
rest: how much quieter is decided by the WEAK VEL setting.

What exactly each page, each knob and each list does is in
[FEATURES.en.md](FEATURES.en.md). The signal chain and trigger diagram is
[docs/signal-chain/obod-signal-chain.html](docs/signal-chain/obod-signal-chain.html).

## Hardware

The device is built on the Guition JC3636K718C board.

| | |
|---|---|
| Module | ESP32-S3R8: two LX7 cores at 240 MHz, 8 MB PSRAM (Octal), 16 MB flash (QIO) |
| Display | round IPS 1.85″, 360 × 360, ST77916 over QSPI, fully laminated |
| Touch | CST816S over I2C, address 0x15 |
| Encoder | mechanical, two signal pins, polled every 1 ms |
| Ring | 13 WS2812 LEDs along the perimeter, data over RMT |
| Audio out | PCM5100A DAC over I2S |
| Audio in | PDM microphone |
| Storage | microSD, SDMMC in four-bit mode |
| Power | a single lithium cell, ETA6003 charger with power-path, HX1.25 cell connector |
| Debug | USB-Serial-JTAG: log and flashing over one cable, without adapters |

![Board, inside](docs/images/inside.svg)

Two things about the board that are worth knowing before the first code change:

- **there is no button on the encoder.** The manufacturer's demo code declares
  `BTN_PIN 0`, but that macro is not used anywhere, and GPIO0 is taken by the ring
  data. The encoder's second pair of contacts does not reach the microcontroller. That
  is why the interface is built on rotation, tap and swipe, and `BSP_ENC_BTN` is set
  to `GPIO_NUM_NC`.
- **the vibration motor is on the board and the firmware does not use it.** The
  DRV2605L driver (LRA, address 0x5A on the touch bus) is fitted to this board series, but
  the feedback in this instrument is the ring and the screen: there is no feedback setting,
  and that address is never addressed on the bus.

Power is arranged as follows: the charger is a part with power-path, that is, while the
cable is plugged in, it is the one that holds the cell node. There is no fuel gauge and
no charge-status line on the board: the cell voltage arrives at GPIO6 through a divider,
and everything else is arithmetic on top of that one number. The microphone is connected
with two signals, so in the BSP it is wired up as PDM.

![Back side with connectors](docs/images/device-back.svg)

The full pin map, the layout, the three board traps and the power budget are in
[docs/HARDWARE.md](docs/HARDWARE.md).

*The four images on this page are placeholders in place of future photos. They are not
photographs of the device.*

## How to build and flash

ESP-IDF 6.1 for the esp32s3 target and PowerShell 7 are required. The script
`tools/idf.ps1` finds the installation itself: first from `.idf-env.json` in the project
root, then in standard locations. `.idf-env.json` does not go into the repository; next
to it lies a sample `.idf-env.json.example` — it must be copied under the name
`.idf-env.json` and corrected:

```json
{ "idfPath": "C:\\esp\\v6.1\\esp-idf" }
```

Build and flash:

```
pwsh -File tools/idf.ps1 build
pwsh -File tools/idf.ps1 -p COM4 flash monitor
```

Substitute your own port; `monitor` may be omitted. There are also scripts for Linux and
macOS — `tools/idf.sh`.

If note reception is enabled on the device, there will be no debug COM port on the
cable: the connector is occupied by the MIDI device. Turn off note reception on the
OPTIONS page and reboot the device — after that the port is back in place.

### Flashing from the browser

Besides the command line, the device can be flashed straight from the browser — with the
[tools/webflash](tools/webflash/README.md) page. Launch: `pwsh -File tools/webflash/serve.ps1`,
then open the address in Chrome or Edge. The page itself transfers to the device the
merged image `tools/webflash/firmware/OBOD.bin`, which `tools/webflash/merge.ps1` builds
from the parts listed in `build/flash_args`.

**What is important to know about presets.** The command-line flash writes partitions at
their addresses and does not touch the settings area: presets and settings remain in
place after it. The browser flash writes the merged image sequentially from address 0,
and it covers the NVS area at addresses 0x9000–0xF000. A write erases its whole range at
once, so settings and presets are lost with it — save the sounds you need in advance.
The erase checkbox in the dialog does not affect this.

## Controls, MIDI and presets

![Pages on the screen](docs/images/screen-pages.svg)

The ring around the display is divided into sectors according to the number of knobs on
the page — one, two, three, four, five or six. A tap on a sector selects the knob, the encoder
turns it, a left-right swipe flips pages, a downward swipe opens the drawer with the
section map, a swipe from the bottom upwards opens the transport screen. Only the encoder
changes a value: both for knobs and for settings.

Presets: 128 slots in NVS, two-word names, a PRESET page with a list. The SAVE button
blinks while the sound differs from the slot. Presets survive a firmware change: the
storage is not cleared by the image fingerprint, the format version is kept in a separate
record, and a slot of an incompatible format is not read and remains in place. Settings —
display brightness, ring brightness and mode,
microphone sensitivity, patch behavior, slide, accent, the time a voice takes to move
between waveforms and note reception — are stored separately from the sound,
do not go into presets and are not moved by the random sound.

MIDI: the device is visible as a USB-MIDI device with the port "OBOD MIDI IN". Channel
1 — lead, channel 2 — percussion, the remaining fourteen channels are discarded. A note
of channel 1 is snapped to the selected scale before sounding; this does not touch the
percussion. Note-on and note-off notes with velocity are accepted, as are transport
(`0xFA` start, `0xFB` continue, `0xFC` stop) and clock (`0xF8`, twenty-four ticks per
quarter). Control change, pitch bend, program change, aftertouch, system common and
SysEx are recognized and discarded. Note reception is the MIDI IN setting on the OPTIONS
page, factory value OFF.

Details on pages, settings and note reception are in [FEATURES.en.md](FEATURES.en.md).
About the hardware and board traps — [docs/HARDWARE.md](docs/HARDWARE.md), about
SquareLine — [docs/SQUARELINE.md](docs/SQUARELINE.md), debugging in VS Code —
[docs/VSCODE.md](docs/VSCODE.md), failure analysis — [docs/TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md).

## Repository structure

```
components/
  bsp_jc3636k718c/   board: display, touch, encoder, audio, battery, SD, ring
  synth_core/        ESP32Synth 2.5.0: voices, buses, integer DSP, PolyBLEP tables
  synth_dsp/         stereo after the engine: drone and lead filters with their own LFOs,
                     percussion, effect rack
  synth_app/         parameters, sequencers, arpeggiator, scales, MIDI reception, presets
  synth_ui/          LVGL screens: pages, ring, macros, fonts
  midi/              note reception over USB
  app_settings/      storage of settings and presets in NVS
  app_net/           provisioning and OTA with rollback; builds but does not run
  ui/                binding to SquareLine Studio
main/                entry point
tools/               build and checks: idf.ps1, check_ui_tables.ps1, promo-check.js,
                     font-metrics-check.js, font_metrics_fix.js, crash.ps1; webflash/ —
                     the browser flashing page
docs/                HARDWARE, SQUARELINE, VSCODE, TROUBLESHOOTING, RELEASE,
                     RELEASE-NOTES, FRAMEWORK, signal chain diagram, images/
web/                 documentation: pages, reference, knobs and lists
partitions.csv       16 MB layout: NVS, otadata, phy_init, two 4 MB OTA partitions, 7 MB SPIFFS and 64 KB for the panic dump
sdkconfig.defaults   board defaults
```

This repository grew out of a template for a BSP framework for this board. The former
main document is preserved as is — [docs/FRAMEWORK.md](docs/FRAMEWORK.md): the
initialization order, work with SquareLine Studio, the deviation from the original
assignment.

The release procedure, the checks before publication and the run on hardware are in
[docs/RELEASE.md](docs/RELEASE.md).

## Known limitations

Note reception occupies the single USB controller of the ESP32-S3: while it is on, there
is no debug COM port on the cable, and it returns only after reception is turned off and
the device is rebooted. Control change, pitch bend and program change are not handled,
and all notes cannot be cleared with the CC 123 command. There is no MIDI output. The
tempo received from the wire does not reach the delay synchronization. There is no master
limiter and no dither.

The full list is in [docs/RELEASE-NOTES.en.md](docs/RELEASE-NOTES.en.md).

## Authors and acknowledgements

The project and the device code — Annabiosis, MIT license.

The voice engine is the **ESP32Synth 2.5.0** library by **Danilo Gabriel**
(danilogcrf2-oss), MIT license. It lives in `components/synth_core` together with
modifications for ESP-IDF 6.1; their list is in `components/synth_core/PATCHES.md`. Taken
from the library are the voice engine, the buses, the built-in integer DSP and the
anti-aliasing tables `AA_Saw` and `AA_Pulse` — that is, the SAW and SQR waveforms. The
stereo after the engine, the drone and lead filters, the percussion, the effect rack, the
modulation generator, the application and the interface were written in this project.

The rest of the third-party material present in the release:

- **ESP-IDF 6.1** — the Espressif framework, Apache-2.0;
- **LVGL 9.6** — interface graphics, MIT;
- **esp-web-tools 10.4.0** — writing the firmware from the browser, Apache-2.0, loaded from unpkg;
- **Mermaid 11.17.2** — rendering of the signal chain diagram in the browser, MIT;
- the **IBM Plex Sans font** — texts of the project pages: `web/`, `tools/webflash/`,
  the signal chain diagram, OFL-1.1, loaded from Google Fonts.

The device screen carries the project's own font: both faces in
`components/synth_ui/src/fonts` are drawn for this instrument, so no third-party font is
embedded in the firmware.

The analysis of third-party components, licenses and what has been removed from the
release is in [THIRD-PARTY.md](THIRD-PARTY.md).

Preparation of the code, documentation and release was carried out together with the
DeepSeek Harness assistant (model deepseek-v4.1-flash-20260910) under the guidance of the
project author.

The Russian text in [README.md](README.md) is the source; if the two diverge, the Russian one is right.