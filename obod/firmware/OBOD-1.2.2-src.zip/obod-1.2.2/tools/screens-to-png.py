"""Превратить сырые кадры прибора в PNG для документации.

Вызывается из tools/screens.ps1 и в одиночку не запускается: аргумент — файл задания,
который составил скрипт, со списком кадров и обоими путями, сырым и готовым.

    python tools/screens-to-png.py <job.json>

Кадр приходит от прибора сырым RGB565: два байта на точку, младшим байтом вперёд — так
шестнадцатибитное слово лежит в памяти ESP32-S3 и так его пишет LVGL. Разбирает его Pillow
режимом 'BGR;16'; проверено на четырёх углах палитры, что он читает именно этот порядок:
0x07E0 даёт чистый зелёный, 0xF800 красный, 0x001F синий.

Сжатие на приборе не делается осознанно: PNG — это работа для компьютера, а не для
инструмента, у которого два и шесть десятых миллисекунды на управление звуком.

Задание и вывод — UTF-8, вывод в консоль только латиницей: на этой машине консоль читает
вывод питона в cp1251 и на кириллице падает.
"""
import json
import sys

from PIL import Image


def frame_to_png(raw_path, png_path, width, height):
    with open(raw_path, 'rb') as handle:
        data = handle.read()

    expected = width * height * 2
    if len(data) != expected:
        raise SystemExit('frame %s is %d bytes, expected %d'
                         % (raw_path, len(data), expected))

    image = Image.frombytes('RGB', (width, height), data, 'raw', 'BGR;16')
    image.save(png_path, 'PNG', optimize=True)
    return image


def main():
    if len(sys.argv) != 2:
        raise SystemExit('usage: screens-to-png.py <job.json>')

    with open(sys.argv[1], encoding='utf-8') as handle:
        job = json.load(handle)

    for item in job['frames']:
        image = frame_to_png(item['raw'], item['png'], item['width'], item['height'])
        print('  %-14s %s  %s' % (item['label'], '%dx%d' % image.size, item['png']))

    print('frames written: %d' % len(job['frames']))


if __name__ == '__main__':
    main()
