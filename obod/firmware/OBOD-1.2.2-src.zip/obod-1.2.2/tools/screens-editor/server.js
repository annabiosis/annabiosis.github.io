/*
 * Редактор экранов прибора: перестановка и переименование ручек на ободе.
 *
 * Что он делает и чего не делает
 *
 *   Геометрия раскладки в прошивке — таблицы RIM_1…RIM_6 (спаны секторов в
 *   градусах), а порядок ручек и подписи — таблицы KNOBS_*. Схема выбирается по
 *   числу секторов страницы, поэтому редактор меняет только две вещи: порядок
 *   записей внутри таблицы (какая ручка в каком слоте) и подпись сектора.
 *   Число ручек на странице, набор параметров, сами таблицы RIM_* и всё, что
 *   дальше по цепочке (описания в web/assets/ref.js, снимки экранов, проверки),
 *   остаются как были: это следующая задача, а не эта.
 *
 *   Правка пишется прямо в components/synth_ui/src/synth_ui.c и только в тело
 *   тронутой таблицы: остальные строки файла не переписываются ни на байт.
 *   Разметку вкладок, каталог разделов и прочие таблицы редактор не трогает.
 *
 * Как запустить
 *
 *   node tools/screens-editor/server.js
 *   → открыть http://127.0.0.1:8788
 *
 *   Переменные окружения: OBOD_SCREENS_PORT — порт, OBOD_SCREENS_NO_OPEN —
 *   не открывать браузер, OBOD_FLASH_PORT — порт прибора для кнопки
 *   «Собрать и прошить» (по умолчанию COM4).
 *
 * Самотест (ничего не пишет на диск)
 *
 *   node tools/screens-editor/server.js --selftest
 *
 * Зависимостей нет: только модули Node, как у tools/editor/server.js.
 */
'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const { execFile, spawn } = require('child_process');

const ROOT = path.join(__dirname, '..', '..');
const SOURCE = path.join(ROOT, 'components', 'synth_ui', 'src', 'synth_ui.c');
const PAGE = path.join(__dirname, 'index.html');
const PORT = Number(process.env.OBOD_SCREENS_PORT || 8788);
const FLASH_PORT = process.env.OBOD_FLASH_PORT || 'COM4';

/* Геометрия обода: те же числа, что в synth_ui.c. */
const GEOMETRY = {
  rimRadius: 162,      /* ARC_R_MID 169 минус половина ARC_W_IDLE 14 */
  rimWidth: 14,
  anchorRadius: 96,    /* ANCHOR_R */
  panelWidth: 112,     /* PANEL_W */
  panelHeight: 48,     /* PANEL_H */
  dialSize: 352        /* ARC_OBJ_SIZE */
};

/* Семейства — по GRP_* из PAGES[]; цвета те же, что в GROUP_COLOR. */
const GROUPS = {
  DRONE: { name: 'Тело',     colour: '#1976D2' },
  LEAD:  { name: 'Голос',    colour: '#AB47BC' },
  GEN:   { name: 'Время',    colour: '#00796B' },
  PERC:  { name: 'Перкуссия', colour: '#2E7D32' },
  FX:    { name: 'Рэк',      colour: '#E91E63' },
  MIX:   { name: 'Микшеры',  colour: '#5D4037' },
  PRESET: { name: 'Пресеты', colour: '#546E7A' },
  SYS:   { name: 'Настройки', colour: '#78909C' }
};

/* Подпись сектора: заглавные буквы, цифры и знаки, которые уже встречаются. */
const LABEL_RE = /^[A-Z0-9][A-Z0-9 .+/-]{0,11}$/;

/* --- разбор файла прошивки ------------------------------------------------- */

function parseRims(text) {
  const rims = {};
  const re = /static const rim_span_t RIM_(\d)\[\] = \{([\s\S]*?)\n\};/g;
  let m;
  while ((m = re.exec(text))) {
    const spans = [];
    const sre = /\{\s*(\d+)\s*,\s*(\d+)\s*\}/g;
    let s;
    while ((s = sre.exec(m[2]))) {
      spans.push({ from: Number(s[1]), to: Number(s[2]) });
    }
    rims[Number(m[1])] = spans;
  }
  return rims;
}

function fmtTableEntries(entries) {
  const widest = entries.reduce((n, e) => Math.max(n, e.label.length), 0);
  return entries.map((e) => {
    const pad = ' '.repeat(widest - e.label.length + 2);
    return '    { "' + e.label + '",' + pad + e.param + ' },';
  }).join('\n');
}

function parseTables(text) {
  const tables = new Map();
  const re = /static const ui_knob_t (KNOBS_[A-Z0-9_]+)\[\] = \{([\s\S]*?)\n\};/g;
  let m;
  while ((m = re.exec(text))) {
    const name = m[1];
    const bodyStart = m.index + m[0].indexOf('{', 0) + 1;
    const bodyEnd = bodyStart + m[2].length;
    const entries = [];
    const ere = /\{\s*"([^"]*)"\s*,\s*([A-Z0-9_]+)\s*\}/g;
    let e;
    while ((e = ere.exec(m[2]))) {
      entries.push({ label: e[1], param: e[2] });
    }
    tables.set(name, { name, entries, bodyStart, bodyEnd });
  }
  return tables;
}

function parsePages(text, tables) {
  const pages = [];
  /*
   * Строка PAGES[]: [PAGE_X] = {"ЗАГОЛОВОК", "ПЛИТКА", KNOBS_X, NK(KNOBS_X), VIEW_KNOBS,
   * false, true, GRP_X }. У страницы списка (PRESET) вместо таблицы стоит NULL и 0: ручек
   * у неё нет, редактору она нужна только чтобы её было видно в списке страниц.
   */
  const re = /\[(PAGE_[A-Z0-9_]+)\]\s*=\s*\{\s*"([^"]+)"\s*,\s*"([^"]+)"\s*,\s*(KNOBS_[A-Z0-9_]+|NULL)\s*,\s*(?:NK\(\s*(KNOBS_[A-Z0-9_]+)\s*\)|0)[\s\S]*?GRP_([A-Z0-9_]+)\s*\}/g;
  let m;
  while ((m = re.exec(text))) {
    const tableName = m[4] === 'NULL' ? null : m[4];
    const table = tableName ? tables.get(tableName) : null;
    if (tableName && !table) { continue; }
    pages.push({
      id: m[1],
      title: m[2],
      chip: m[3],
      table: tableName,
      declared: m[5] || null,
      group: m[6],
      count: table ? table.entries.length : 0
    });
  }
  return pages;
}

function load() {
  const text = fs.readFileSync(SOURCE, 'utf8');
  const tables = parseTables(text);
  const pages = parsePages(text, tables);
  return { text, tables, pages, rims: parseRims(text) };
}

/* --- проверка правки ------------------------------------------------------- */

function validate(original, next, problems) {
  if (next.length !== original.length) {
    problems.push('число ручек на странице меняется: было ' + original.length +
                  ', стало ' + next.length + ' (прототип этого не делает)');
    return;
  }
  const was = original.map((e) => e.param).sort().join(' ');
  const now = next.map((e) => e.param).sort().join(' ');
  if (was !== now) {
    problems.push('набор параметров на странице меняется: ручки можно переставлять и ' +
                  'переименовывать, но не добавлять и не убирать');
  }
  const seen = new Set();
  for (const entry of next) {
    if (!LABEL_RE.test(entry.label)) {
      problems.push('подпись "' + entry.label + '" не годится: заглавные латинские буквы, ' +
                    'цифры, точка, плюс, дефис, до 12 знаков');
    }
    if (seen.has(entry.label)) {
      problems.push('подпись "' + entry.label + '" повторяется на одной странице');
    }
    seen.add(entry.label);
  }
}

/* Готовит новый текст файла: трогает только тела изменённых таблиц. */
function applyToText(text, tables, changes) {
  const edits = [];
  for (const [name, entries] of Object.entries(changes)) {
    const table = tables.get(name);
    if (!table) { throw new Error('нет таблицы ' + name); }
    if (fmtTableEntries(entries) === fmtTableEntries(table.entries)) { continue; }
    edits.push({ start: table.bodyStart, end: table.bodyEnd, body: '\n' + fmtTableEntries(entries) });
  }
  edits.sort((a, b) => b.start - a.start);
  let out = text;
  for (const edit of edits) {
    out = out.slice(0, edit.start) + edit.body + out.slice(edit.end);
  }
  return { text: out, touched: edits.length };
}

/* --- проверки репозитория -------------------------------------------------- */

function runCheck(cmd, args, done) {
  execFile(cmd, args, { cwd: ROOT, timeout: 120000, encoding: 'utf8' }, (err, stdout, stderr) => {
    done({ ok: !err, out: (stdout || '') + (stderr || '') });
  });
}

/* --- сервер ---------------------------------------------------------------- */

function state() {
  const model = load();
  return {
    source: path.relative(ROOT, SOURCE).replace(/\\/g, '/'),
    geometry: GEOMETRY,
    groups: GROUPS,
    rims: model.rims,
    pages: model.pages,
    tables: Object.fromEntries([...model.tables].map(([k, v]) => [k, v.entries]))
  };
}

function json(res, code, data) {
  const body = Buffer.from(JSON.stringify(data), 'utf8');
  res.writeHead(code, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': body.length,
    'Cache-Control': 'no-store'
  });
  res.end(body);
}

function serveFile(res, file, type) {
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); res.end('нет файла'); return; }
    res.writeHead(200, { 'Content-Type': type + '; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end(data);
  });
}

function handleApply(body, res) {
  let payload;
  try {
    payload = JSON.parse(body.toString('utf8'));
  } catch (e) {
    return json(res, 400, { ok: false, problems: ['запрос не разобран: ' + e.message] });
  }

  const model = load();
  const problems = [];
  const changes = payload && payload.tables ? payload.tables : {};

  for (const [name, entries] of Object.entries(changes)) {
    const table = model.tables.get(name);
    if (!table) { problems.push('нет таблицы ' + name); continue; }
    if (!Array.isArray(entries)) { problems.push(name + ': ожидался список ручек'); continue; }
    validate(table.entries, entries, problems);
  }
  if (problems.length) { return json(res, 400, { ok: false, problems }); }

  const result = applyToText(model.text, model.tables, changes);
  if (!result.touched) { return json(res, 200, { ok: true, touched: 0 }); }

  fs.writeFileSync(SOURCE, result.text, 'utf8');
  json(res, 200, {
    ok: true,
    touched: result.touched,
    /* Что придётся обновить за пределами прошивки: это следующая задача. */
    downstream: ['web/assets/ref.js — имена и порядок ручек на страницах',
                 'assets/screens/*.png — снимки экранов, где ручки сдвинулись',
                 'tools/promo-check.js — сверка справочника с прошивкой']
  });
}

/*
 * Сборка и прошивка из окна редактора: тот же цикл, что руками в консоли —
 * tools/idf.ps1 build, затем tools/idf.ps1 -p <порт> flash. Две команды подряд,
 * потому что прошивать несобранное бессмысленно. Пока идёт сборка, кнопку не
 * нажимают второй раз: сервер отвечает 409.
 */
const FLASH = { running: false, ok: null, lines: [], started: 0, port: FLASH_PORT };

function pushLines(chunk) {
  const text = String(chunk).replace(/\r/g, '');
  for (const line of text.split('\n')) {
    if (!line.trim()) { continue; }
    FLASH.lines.push(line.replace(/\s+$/, ''));
  }
  if (FLASH.lines.length > 400) { FLASH.lines.splice(0, FLASH.lines.length - 400); }
}

function runStep(args, done) {
  const child = spawn('pwsh', ['-NoProfile', '-File', 'tools/idf.ps1'].concat(args),
                      { cwd: ROOT, windowsHide: true });
  child.stdout.on('data', pushLines);
  child.stderr.on('data', pushLines);
  child.on('close', (code) => done(code === 0));
  child.on('error', (e) => { pushLines('не запустилось: ' + e.message); done(false); });
}

function startFlash() {
  FLASH.running = true;
  FLASH.ok = null;
  FLASH.lines = [];
  FLASH.started = Date.now();
  pushLines('сборка: tools/idf.ps1 build');

  runStep(['build'], (built) => {
    if (!built) {
      FLASH.running = false;
      FLASH.ok = false;
      pushLines('сборка не прошла, прошивка не начата');
      return;
    }
    pushLines('прошивка: tools/idf.ps1 -p ' + FLASH.port + ' flash');
    runStep(['-p', FLASH.port, 'flash'], (flashed) => {
      FLASH.running = false;
      FLASH.ok = flashed;
      pushLines(flashed ? 'готово: прибор перезапущен' : 'прошивка не прошла');
    });
  });
}

function route(req, res) {
  const url = req.url.split('?')[0];

  if (req.method === 'GET' && (url === '/' || url === '/index.html')) {
    return serveFile(res, PAGE, 'text/html');
  }
  if (req.method === 'GET' && url === '/api/state') {
    try { return json(res, 200, state()); } catch (e) { return json(res, 500, { ok: false, problems: [e.message] }); }
  }
  if (req.method === 'POST' && url === '/api/apply') {
    const chunks = [];
    req.on('data', (c) => chunks.push(c));
    req.on('end', () => {
      try { handleApply(Buffer.concat(chunks), res); } catch (e) { json(res, 500, { ok: false, problems: [e.message] }); }
    });
    return;
  }
  if (req.method === 'GET' && url === '/api/check') {
    runCheck('pwsh', ['-NoProfile', '-File', 'tools/check_ui_tables.ps1'], (a) => {
      runCheck('node', ['tools/rings-check.js'], (b) => {
        json(res, 200, { ok: a.ok && b.ok, ui: a.out.trim(), rings: b.out.trim() });
      });
    });
    return;
  }
  if (req.method === 'POST' && url === '/api/flash') {
    if (FLASH.running) { return json(res, 409, { ok: false, problems: ['сборка уже идёт'] }); }
    startFlash();
    return json(res, 200, { ok: true, port: FLASH.port });
  }
  if (req.method === 'GET' && url === '/api/flash/status') {
    return json(res, 200, {
      running: FLASH.running,
      ok: FLASH.ok,
      port: FLASH.port,
      seconds: FLASH.started ? Math.round((Date.now() - FLASH.started) / 1000) : 0,
      tail: FLASH.lines.slice(-24)
    });
  }

  res.writeHead(404);
  res.end('не найдено');
}

/* --- самотест -------------------------------------------------------------- */

function selftest() {
  let failed = 0;
  const ok = (cond, what, extra) => {
    if (cond) { console.log('  OK   ' + what); } else { console.log('  ПЛОХО ' + what + (extra ? ': ' + extra : '')); failed++; }
  };

  const model = load();
  ok(model.pages.length === 22, 'страниц в PAGES[] — 22', 'найдено ' + model.pages.length);

  const withKnobs = model.pages.filter((p) => p.table);
  ok(withKnobs.length === 21, 'страниц с ручками — 21 (у PRESET ручек нет)',
     'найдено ' + withKnobs.length);

  const total = withKnobs.reduce((n, p) => n + model.tables.get(p.table).entries.length, 0);
  /* 103, not the 105 of the drive era: MASTER lost DRIVE and ALGO, SYSTEM lost DRIVE, and
   * the tonic's note gained its octave as a second sector on SCALE. */
  ok(total === 101, 'ручек на всех страницах — 101', 'найдено ' + total);

  let rimOk = true;
  for (const [count, spans] of Object.entries(model.rims)) {
    if (spans.length !== Number(count)) { rimOk = false; }
  }
  ok(rimOk, 'длина каждой таблицы RIM_* равна числу секторов');

  let formatOk = true;
  for (const [name, table] of model.tables) {
    const text = 'static const ui_knob_t ' + name + '[] = {\n' + fmtTableEntries(table.entries) + '\n};';
    const back = parseTables(text).get(name);
    const same = back && JSON.stringify(back.entries) === JSON.stringify(table.entries);
    if (!same) { formatOk = false; console.log('       расходится: ' + name); }
  }
  ok(formatOk, 'запись и разбор таблиц сходятся');

  /* Перестановка и переименование на первой таблице с двумя и более ручками. */
  const page = withKnobs.find((p) => model.tables.get(p.table).entries.length >= 2);
  const table = model.tables.get(page.table);
  const swapped = table.entries.slice();
  [swapped[0], swapped[1]] = [swapped[1], swapped[0]];
  swapped[0] = { label: swapped[0].label, param: swapped[0].param };

  const renamed = swapped.map((e, i) => (i === 0 ? { label: 'TEST', param: e.param } : e));

  const problems = [];
  validate(table.entries, renamed, problems);
  ok(problems.length === 0, 'правка страницы ' + page.title + ' проходит проверку',
     problems.join('; '));

  const result = applyToText(model.text, model.tables, { [page.table]: renamed });
  const after = parseTables(result.text).get(page.table).entries;
  ok(after[0].label === 'TEST' && after[0].param === table.entries[1].param &&
     after[1].param === table.entries[0].param,
     'перестановка и переименование попадают в текст файла');

  const others = [...model.tables.keys()].filter((n) => n !== page.table);
  const restIntact = others.every((n) => {
    const before = model.text.slice(model.tables.get(n).bodyStart, model.tables.get(n).bodyEnd);
    const now = result.text.indexOf(before) >= 0;
    return now;
  });
  ok(restIntact, 'остальные таблицы остались как были');

  /* Отказ: добавление ручки, повтор подписи, строчные буквы, смена параметра. */
  const strays = [
    ['добавление ручки', renamed.concat([{ label: 'NEW', param: 'SYNTH_PARAM_CUTOFF' }])],
    ['повтор подписи', renamed.map((e) => ({ label: 'SAME', param: e.param }))],
    ['строчные буквы', renamed.map((e, i) => (i === 0 ? { label: 'cutoff', param: e.param } : e))],
    ['смена параметра', renamed.map((e, i) => (i === 0 ? { label: e.label, param: 'SYNTH_PARAM_CUTOFF' } : e))]
  ];
  for (const [what, entries] of strays) {
    const p = [];
    validate(table.entries, entries, p);
    ok(p.length > 0, 'отказ: ' + what);
  }

  console.log(failed ? 'НЕ ПРОШЛО: ' + failed : 'OK: разбор, запись и проверки сходятся');
  process.exit(failed ? 1 : 0);
}

/* --- запуск ---------------------------------------------------------------- */

if (require.main === module) {
  if (process.argv.includes('--selftest')) {
    selftest();
  } else {
    http.createServer(route).listen(PORT, '127.0.0.1', () => {
      console.log('  редактор экранов: http://127.0.0.1:' + PORT);
      console.log('  файл: ' + path.relative(ROOT, SOURCE).replace(/\\/g, '/'));
      if (!process.env.OBOD_SCREENS_NO_OPEN) {
        execFile('cmd', ['/c', 'start', '', 'http://127.0.0.1:' + PORT], () => {});
      }
    });
  }
}

module.exports = { load, parseTables, parsePages, parseRims, fmtTableEntries, applyToText,
                   validate, selftest, GEOMETRY };
