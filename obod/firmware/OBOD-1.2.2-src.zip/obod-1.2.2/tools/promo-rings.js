/*
 * Круги со страницы промо. Отложены целиком и отдельным файлом.
 *
 * Почему отдельно: страница промо переведена в текстовый справочник, кругов на ней нет.
 * Здесь лежит всё, что их рисовало: разметка секторов, конусные градиенты, подписи внутри
 * круга, точки пагинации и таблица экранов вместе с палитрой семейств.
 *
 * Готовой страницы здесь нет намеренно. Чтобы вернуть круги: подключить этот файл,
 * вставить RING_CSS в <style> страницы, положить два контейнера и вызвать
 *
 *     mountRings(document.getElementById('ring-famnav'),
 *                document.getElementById('ring-pages'));
 *
 * Данные взяты из прошивки: углы — из таблиц RIM_1 … RIM_6, цвета — из GROUP_COLOR,
 * заголовки страниц, число и имена секторов — из таблицы PAGES[] и таблиц KNOBS_*.
 * Расхождения с прошивкой ловит tools/rings-check.js: он разбирает этот файл вместе с
 * synth_ui.c и падает, если перечни ручек, заголовки или углы разъехались.
 */

var RING_CSS = `
  .famnav { display: flex; flex-wrap: wrap; gap: 8px; margin: 0 0 12px; }

  .famnav a {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 7px 13px;
    border: 1px solid var(--faint);
    border-radius: 999px;
    color: var(--text);
    font-size: 12.5px;
  }

  .famnav a:hover { border-color: var(--muted); }
  .famnav a .dot { width: 9px; height: 9px; }

  .fam-block { margin-top: 52px; }

  .fam-block h3 { margin: 0 0 2px; scroll-margin-top: 68px; }

  .fam-block .fam-sub { margin: 0 0 6px; color: var(--muted); font-size: 13px; }

  .page-row {
    display: grid;
    grid-template-columns: 128px 1fr;
    gap: 6px 22px;
    align-items: start;
    padding: 20px 0;
    border-top: 1px solid var(--faint);
  }

  .fam-block .page-row:last-child { border-bottom: 1px solid var(--faint); }

  .page-row h4 { margin: 0 0 5px; font-size: 15px; font-weight: 600; color: var(--text); }
  .page-row h4 span { color: var(--muted); font-weight: 400; }

  .page-sectors { margin: 0 0 10px; font-size: 13px; color: var(--accent); letter-spacing: .03em; }

  .page-body { margin: 0; }

  /* Кольцо рисует сам элемент: фон — это conic-gradient из секторов, а отверстие
     посередине вырезает .dial-hole, закрашивая центр цветом страницы. */
  .dial-card { text-align: center; }

  .dial-face {
    position: relative;
    width: 100%;
    aspect-ratio: 1 / 1;
    border-radius: 50%;
  }

  .dial-hole {
    position: absolute;
    inset: 12%;
    border-radius: 50%;
    background: var(--bg);
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 3px;
  }

  .dial-title { font-size: 10.5px; line-height: 1.3; letter-spacing: .08em; }
  .dial-title span { display: block; }

  .dial-dots { display: flex; align-items: center; gap: 4px; margin-top: 5px; }
  .dial-dots i { display: block; width: 4px; height: 4px; border-radius: 50%; background: var(--faint); }

  @media (max-width: 560px) {
    .page-row { grid-template-columns: 1fr; }
    .page-row .dial-card { max-width: 146px; margin: 0 auto 12px; }
  }
`;

/*
 * Круги и описания страниц строятся из одной таблицы PAGES. Оттуда берутся и число
 * секторов, и подписи секторов, поэтому круг и текст под ним не могут разойтись.
 *
 * Цвета — GROUP_COLOR из synth_ui.c: тёмный оттенок заливает сектор, светлый достаётся
 * выбранному, текстовый идёт на подпись внутри круга.
 *
 * Углы взяты из таблиц RIM_1 … RIM_6. LVGL отсчитывает их от трёх часов по ходу
 * стрелки, CSS — от двенадцати, поэтому центры переведены: девять часов
 * четырёхсекторной раскладки — это 270° в CSS, двенадцать часов — 0°.
 */
var RING_FAM = {
  drone:    { fill: '#1565C0', bright: '#64B5F6', text: '#90CAF9', ru: 'Тело',
              hue: 'синий', note: 'звучит всегда' },
  lead:     { fill: '#9C27B0', bright: '#BA68C8', text: '#CE93D8', ru: 'Голос',
              hue: 'фиолетовый', note: 'то, что играют' },
  gen:      { fill: '#00695C', bright: '#4DB6AC', text: '#80CBC4', ru: 'Время',
              hue: 'teal', note: 'решает ноты' },
  perc:     { fill: '#1B5E20', bright: '#66BB6A', text: '#A5D6A7', ru: 'Перкуссия',
              hue: 'зелёный', note: 'своя часть' },
  fx:       { fill: '#C2185B', bright: '#F06292', text: '#F48FB1', ru: 'Рэк',
              hue: 'розовый', note: 'через него идёт всё' },
  mix:      { fill: '#4E342E', bright: '#A1887F', text: '#BCAAA4', ru: 'Микшеры',
              hue: 'коричневый', note: 'ставят части рядом' },
  preset:   { fill: '#37474F', bright: '#90A4AE', text: '#CFD8DC', ru: 'Пресеты',
              hue: 'тёмно-серый', note: 'места хранения' },
  settings: { fill: '#546E7A', bright: '#90A4AE', text: '#90A4AE', ru: 'Настройки',
              hue: 'серый', note: 'свет, рука и память' }
};

/* Где стоит центр первого сектора каждой раскладки, в градусах CSS.
 *
 * Первый сектор таблиц RIM_*: RIM_1 — весь обод, в прошивке приколотый к верху;
 * RIM_2 — {180,360}, RIM_3 — {210,330}, RIM_4 — {135,225}, то есть девять часов,
 * RIM_5 — {234,306}, RIM_6 — {240,300}. Центр — это начало плюс половина разворота;
 * отсчёт LVGL идёт от трёх часов, отсчёт CSS — от двенадцати, поэтому 270° в LVGL и есть
 * 0° в CSS. Углы сверяет tools/rings-check.js, считая их из тех же таблиц. */
var RING_FIRST = { 1: 0, 2: 0, 3: 0, 4: 270, 5: 0, 6: 0 };

/* У шести секторов раскладка одна: RIM_6, звезда точкой в двенадцать (270° по счёту
 * LVGL — это 0° в CSS). Её рисуют страница настроек, три страницы посылов и страница
 * рисунка лида; своего, повёрнутого обода ни у кого нет, поэтому отдельной записи здесь
 * не нужно. */

var RING_PAGES = [
  { t: 'DRONE', c: 'DRN', f: 'drone', k: ['H.OSC', 'M.OSC', 'L.OSC', 'WIDTH', 'FOLLOW'],
    d: 'Форма волны каждого из трёх регистров, ширина дрейфа и то, идёт ли дрон за лидом. Уровни трёх регистров живут на LEVELS, а не здесь: дрон звучит непрерывно, но его баланс читают вместе с остальными частями.' },
  { t: 'DRONE FLTR', c: 'DFL', f: 'drone', k: ['RATE', 'CUTOFF', 'RES', 'DEPTH', 'K.TRCK', 'MODE'],
    d: 'Фильтр и его свип. Срез решает, звучит инструмент как дрон или как машина. RATE делает свип слышимым свипом: на заводских 0,05 Гц цикл идёт двадцать секунд, а наверху ручки ровно 6 Гц у LOW, 8,4 у MID и 4,8 у HIGH — внизу ухо читает это как фактуру, наверху как свип.' },
  { t: 'LFO', c: 'LFO', f: 'drone', k: ['DEST', 'DEST2', 'SHAPE', 'DEPTH', 'SPEED', 'TRIG'],
    d: 'Форма волны дрона: приёмник, форма, глубина, скорость и перезапуск. Это свой LFO со своей скоростью; синус фильтра на странице DRONE FLTR идёт отдельно, а их глубины складываются.' },

  { t: 'LEAD', c: 'LD', f: 'lead', k: ['GATE', 'PORTA', 'OSC', 'VOICE'],
    d: 'GATE задаёт длину ноты, PORTA — глиссандо между нотами, OSC — форму волны, VOICE — сколько у лида голосов: в POLY четыре, и шаги накладываются, в MONO один и каждая нота обрезает предыдущую. Уровень лида стоит на LEVELS, рядом с остальными частями: баланс — решение о целой картине.' },
  { t: 'LEAD TONE', c: 'LTN', f: 'lead', k: ['CUTOFF', 'RES', 'ENV', 'SHAPE', 'K.TRCK', 'MODE'],
    d: 'То, чем играют. ENV решает, насколько глубоко срез идёт за нотой, а SHAPE — как эта огибающая поделена между атакой и релизом: щипок или смычок.' },
  { t: 'LEAD ENV', c: 'ENV', f: 'lead', k: ['ATTACK', 'DECAY', 'RELEASE', 'SUSTAIN'],
    d: 'Четыре ступени огибающей громкости — форма, которую выставляют один раз и по слуху. Отдельно от TONE, потому что семь параметров не помещаются в шесть секторов, а граница здесь та же, что и везде: чем играют и что настраивают однажды.' },

  { t: 'SCALE', c: 'SCL', f: 'gen', k: ['SCALE', 'NOTE', 'OCT', 'DENSITY', 'OCTAVE'],
    d: 'Лад, нота тоники, её октава, плотность и охват регистра. Лад меняет интервалы, и это самое крупное изменение, которое одна ручка делает с мелодией. NOTE и OCT — то, на что рука целится: нота из двенадцати и октава из семи, вместо одной восьмидесятипятиступенной шкалы, где нота искалась на слух. DENSITY превращает поток нот в фразу, OCTAVE решает, как охотно линия уходит в дальний регистр.' },
  { t: 'LEAD EUCLID', c: 'EUCL', f: 'gen', k: ['STEPS', 'PULSES', 'ROTATE', 'ACCENT', 'SCATTER', 'RESET'],
    d: 'n и k эвклидова рисунка, поворот против доли, рисунок акцента, разброс и собственный период выравнивания. Четыре из четырёх — каждая доля, три из восьми — тресильо. SCATTER снимает точное повторение, ACCENT отмечает доли, которые звучат громче остальных. RESET — жест лида: через выбранное число шагов его сетки фраза лида (и арпеджиатор, который играет вместо неё) начинается с первого шага, а перкуссия не двигается. В пресете, записанном до появления поля, читается заводские 16. Когда арпеджиатор забрал сетку себе, по центру страницы появляется ARP IS ACTIVE: сетка не играет, и её ручки ничего не меняют.' },
  { t: 'LEAD ARP', c: 'ARP', f: 'gen', k: ['DIR', 'SPEED', 'LEN', 'RANGE', 'ACCENT'],
    d: 'Направление, скорость, длина фигуры, диапазон и свой рисунок акцента. LEN и RANGE разделены намеренно: три ноты через две октавы и восемь нот через те же две дают один интервал и разные линии. SPEED — тринадцать делений от 4/1 до 1/32, и выключателя в нём нет: арпеджиатор выключается из DIR, и так эвклидова сетка возвращает себе голос. RANGE — просто число октав от нуля до пяти: направление задаёт DIR, поэтому знаков и «плюс-минус» у диапазона больше нет. ACCENT — третий рисунок прибора, у арпеджиатора свой: его шаги и его доли такта не зависят от страницы лида.' },

    { t: 'PERC', c: 'PRC', f: 'perc', k: ['KIT', 'TONE', 'DECAY', 'PUNCH', 'TIMBRE', 'TUNE'],
    d: 'Тембр ударных: набор из двадцати восьми китов, от сухого тесного до длинного и низкого, и правка кита. Последние четыре — глубокий конец: ABYSS на 35 Гц с гейтом в секунду с четвертью, SLUDGE ещё медленнее и толще, MONK на металле вместо кожи, VOID — бочка и воздух вокруг неё. TONE транспонирует весь набор, TUNE — только низкие дорожки, кик и том, чтобы бочка попадала в тональность, а хэт оставался хэтом. DECAY умножает все гейты, PUNCH — атака удара: внизу длинная и мягкая, наверху короткая с щелчком бойка. TIMBRE — жизнь: насколько сильный удар ярче и длиннее, дрожь, уход строя по тактам и как часто дорожка берёт второй голос. Уровень части — на LEVELS.' },
  { t: 'PERC SEQ', c: 'SEQ', f: 'perc', k: ['GROOVE', 'VAR', 'FILL', 'SWING', 'SPEED', 'ACCENT'],
    d: 'Партия ударных: тридцать два записанных грува — от минипопса и диско до брейка, трапа и босановы, дальше семь IDM-строк: бочка заикается (SKIP), снейр двоится (STUT), доли сдвинуты (GRIT, RUST), такт раскалывается (SPLIT, WOBBLE) и три-три-два через весь такт (DRILL), — и то, как они живут. VAR выбирает на цикл один из четырёх ходов — призрачные шестнадцатые, кик на «и» третьей доли, подъезд снейром, снятые хэты — и держит его весь цикл; FILL закрывает последний такт цикла сбивкой; SWING задерживает каждую вторую шестнадцатую; SPEED — только кратные двум отношения к общему такту, ×0.25, ×0.5, ×1 и ×2, и смена скорости ждёт тактовой черты, чтобы ударные не спорили с остальным прибором. ACCENT отмечает доли, звучащие громче. Кольцо точек — это партия: бочка крупнее всех, за ней снейр, том и хэты, призрачная нота мельче всех, сбивка FILL стоит во второй половине такта.' },

  { t: 'PERC MIX', c: 'PMX', f: 'perc', k: ['KICK', 'SNARE', 'HAT', 'TOM'],
    d: 'Баланс четырёх дорожек внутри части. Сто на дорожке — она звучит так, как её записал кит; ручка только ослабляет, добавить сверх записанного она не может. Дорожка на нуле не бьёт вовсе — удар не тратится на тишину, а партия считает его сыгранным, — поэтому нулём дорожку и глушат: двойной тап по сектору опускает её в ноль, второй возвращает прежний уровень. Индикатор на секторе показывает силу последнего удара своей дорожки. Уровни хранятся в патче и пресетах, мьют — жест на панели. Уровень части целиком остаётся на LEVELS.' },

  { t: 'CHORUS', c: 'CHR', f: 'fx', k: ['MIX', 'RATE', 'DEPTH'],
    d: 'Ширина. Стоит перед дилеем и ревербом и попадает в них: на полном миксе реверба реверб и есть выход, поэтому ширина хоруса слышна через него.' },
  { t: 'DELAY', c: 'DLY', f: 'fx', k: ['MIX', 'FDBK', 'TIME', 'SYNC', 'MODE'],
    d: 'Пинг-понг до четырёх секунд на сторону. SYNC подчиняет время темпу с транспорта — двенадцать делений от 1/1 вниз, и ниже 60 bpm целая упирается в буфер, — и тогда дилей едет за темпом сам. Пятый сектор выбирает, как приходит смена времени: TAPE — заводское значение, указатель тормозит, и повторы тянутся за ним, как у ленты; XFADE — прежний отвод гаснет за тридцать миллисекунд, и повторы не тянутся.' },
  { t: 'REVERB', c: 'REV', f: 'fx', k: ['ALGO', 'MIX', 'SIZE', 'DAMP'],
    d: 'Четыре алгоритма: ROOM, HALL, CATH, PLAT. MIX работает как баланс: на половине сухой и влажный равны, на ста процентах остаётся только реверб. Сколько каждого голоса в комнате, решают посылы на LEVELS и SENDS.' },

  { t: 'MASTER', c: 'MST', f: 'mix', k: ['VOL', 'COMP', 'DUCK', 'SRC', 'REL'],
    d: 'Выход, мастер-компрессор и подавление низа дрона ударом. Стоит между рэком и микшерами намеренно: это единственная страница, которая держит всё сразу, и кнопка транспорта в шторке управляет её громкостью. Перегрузки здесь нет: она ушла из прибора вместе со своей страницей.' },
  { t: 'LEVELS', c: 'LVL', f: 'mix', k: ['LEAD', 'PERC', 'LOW', 'MID', 'HIGH'],
    d: 'Кто против кого громче. Баланс — решение о целой картине, поэтому все уровни собраны на одной странице и только здесь: на страницах лида, перкуссии и дрона этих ручек больше нет, и одно и то же число не приходится держать в двух местах.' },
  { t: 'REV SENDS', c: 'RVS', f: 'mix', k: ['LEAD', 'PERC', 'LOW', 'MID', 'HIGH'],
    d: 'Посылы в реверб: ведущий, перкуссия и три регистра дрона, у каждой части своё количество. Микрофона здесь нет: вход работает только как источник модуляции. MIX на странице REVERB — уровень возврата, то есть сколько комнаты приходит обратно; сам посыл звук не глушит.' },
  { t: 'CHR SENDS', c: 'CHS', f: 'mix', k: ['LEAD', 'PERC', 'LOW', 'MID', 'HIGH'],
    d: 'Посылы в хорус, те же пять частей в том же порядке. Хорус возвращается своим путём, параллельно ревербу, и его MIX на странице CHORUS — уровень возврата.' },
  { t: 'DEL SENDS', c: 'DLS', f: 'mix', k: ['LEAD', 'PERC', 'LOW', 'MID', 'HIGH'],
    d: 'Посылы в дилей, те же пять частей. Дилей тоже возвращается параллельно, поэтому посыл в него ничего не уносит в хорус и в реверб.' },

  { t: 'PRESET', c: 'PRS', f: 'preset', k: [],
    d: 'Список слотов по центру и три действия — LOAD, SAVE, RND. Обод у страницы целый: секторов нет, потому что ручек у неё нет. Первой строкой всегда стоит INIT — заводской звук, не слот и не пресет, а сброс патча к тому, с которым инструмент выходит с завода; перезаписать его нельзя, поэтому SAVE на нём спрятан. Точка «не сохранено» отмечает, что звук уже отличается от слота. Долгое нажатие на RND рандомизирует вместе со структурой — сетками, арпеджиатором и посылами.' },

  { t: 'SYSTEM', c: 'SYS', f: 'settings', k: ['SCREEN', 'RING', 'RING FX', 'MIC'],
    d: 'Яркость экрана и кольца, режим кольца и чувствительность микрофона. RESET здесь больше нет: он стал параметром звука, у каждой секвенции свой, и оба стоят на страницах с рисунком — LEAD EUCLID и PERC SEQ.' },
  { t: 'OPTIONS', c: 'OPT', f: 'settings', k: ['PATCH', 'SLIDE', 'RND DEL', 'WEAK VEL', 'MIDI IN', 'MORPH'],
    d: 'Что делать со звуком при выключении, время доезда новых значений, случайный звук и время дилея, велосити удара без акцента, приём нот по USB и время перехода голоса с одной формы волны на другую.' }
];

function mountRings(famnavEl, bodyEl) {
  var FAM = RING_FAM;
  var FIRST = RING_FIRST;
  var PAGES = RING_PAGES;

  /* Кольцо из conic-gradient: первый сектор всегда начинает градиент, а в нужное
     место его ставит параметр from. */
  /* Число секторов — это и есть раскладка: одна таблица на счёт, шести отвечает RIM_6
     у всех страниц, включая две с рисунком. */
  function firstFor(page) {
    return FIRST[page.k.length];
  }

  function rimCss(n, c, first) {
    var gap = 3, step, w, parts, i, a, b;

    if (n === 0) { return c.fill; }
    if (n === 1) { return c.bright; }

    step = 360 / n;
    w = step - gap;
    parts = [];

    for (i = 0; i < n; i++) {
      a = i * step;
      b = a + w;
      parts.push((i === 0 ? c.bright : c.fill) + ' ' + a.toFixed(2) + 'deg ' + b.toFixed(2) + 'deg');
      parts.push('transparent ' + b.toFixed(2) + 'deg ' + ((i + 1) * step).toFixed(2) + 'deg');
    }

    /* Сектор начинается с нуля градиента, поэтому в нужное место его ставит from:
       половина шага назад, плюс половина зазора — тогда центр сектора попадает
       точно на FIRST[n], и весь зазор остаётся между секторами, а не на первом. */
    return 'conic-gradient(from ' + (first - step / 2 + gap / 2).toFixed(2) + 'deg, ' +
           parts.join(', ') + ')';
  }

  function el(tag, cls) {
    var e = document.createElement(tag);
    if (cls) { e.className = cls; }
    return e;
  }

  var total = {}, order = [], seen = {}, i, j, row;

  PAGES.forEach(function (p) {
    total[p.f] = (total[p.f] || 0) + 1;
    if (order.indexOf(p.f) < 0) { order.push(p.f); }
  });

  /* Ссылки на семейства над списком страниц. */
  order.forEach(function (key) {
    var a = el('a');
    a.setAttribute('href', '#fam-' + key);
    a.innerHTML = '<span class="dot" style="background:' + FAM[key].bright + '"></span>' + FAM[key].ru;
    famnavEl.appendChild(a);
  });

  /* Сами страницы: круг слева, описание справа. */
  order.forEach(function (key) {
    var fam = FAM[key];
    var block = el('div', 'fam-block');
    var head = el('h3');

    head.setAttribute('id', 'fam-' + key);
    head.innerHTML = fam.ru + ' <span class="muted">· <span style="color:' + fam.text +
                     '">' + fam.hue + '</span> · ' + fam.note + '</span>';
    block.appendChild(head);

    var sub = el('p', 'fam-sub');
    sub.innerHTML = total[key] + ' ' + (total[key] === 1 ? 'страница' : 'страницы');
    block.appendChild(sub);

    PAGES.forEach(function (p) {
      if (p.f !== key) { return; }

      seen[key] = (seen[key] || 0) + 1;

      row = el('div', 'page-row');
      row.dataset.title = p.t;
      row.dataset.family = key;
      row.dataset.knobs = String(p.k.length);

      var card = el('div', 'dial-card');
      var face = el('div', 'dial-face');
      var hole = el('div', 'dial-hole');

      face.style.background = rimCss(p.k.length, fam, firstFor(p));

      hole.innerHTML = '<div class="dial-title" style="color:' + fam.text + '">' +
        p.t.split(' ').map(function (s) { return '<span>' + s + '</span>'; }).join('') + '</div>';

      var dots = '';
      for (j = 1; j <= total[key]; j++) {
        dots += '<i class="' + (j === seen[key] ? 'on' : '') + '"' +
                (j === seen[key] ? ' style="background:' + fam.bright + '"' : '') + '></i>';
      }
      hole.innerHTML += '<div class="dial-dots">' + dots + '</div>';

      face.appendChild(hole);
      card.appendChild(face);

      var info = el('div', 'page-info');
      var h4 = el('h4');
      var sec = el('p', 'page-sectors');
      var txt = el('p', 'page-body');

      h4.innerHTML = p.t + ' <span>' + p.c + '</span>';
      sec.innerHTML = p.k.length ? p.k.join(' · ') : 'секторов нет';
      txt.innerHTML = p.d;

      info.appendChild(h4);
      info.appendChild(sec);
      info.appendChild(txt);

      row.appendChild(card);
      row.appendChild(info);
      block.appendChild(row);
    });

    bodyEl.appendChild(block);
  });

  /* Подсветка раздела в навигаторе, если браузер умеет наблюдать за пересечениями. */
  if (typeof IntersectionObserver !== 'function') { return; }

  var links = {};
  Array.prototype.forEach.call(document.querySelectorAll('#topnav a'), function (a) {
    links[a.getAttribute('href').slice(1)] = a;
  });

  var observer = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      var link = links[entry.target.id];
      if (!link) { return; }
      if (entry.isIntersecting) {
        Object.keys(links).forEach(function (id) { links[id].className = ''; });
        link.className = 'on';
      }
    });
  }, { rootMargin: '-68px 0px -70% 0px' });

  Object.keys(links).forEach(function (id) {
    var s = document.getElementById(id);
    if (s) { observer.observe(s); }
  });
}