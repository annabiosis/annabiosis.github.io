"""
The transport's arithmetic, checked on the desktop.

Mirrors components/synth_app/src/synth_app.cpp:

  bar_blocks_for_bpm()   the bar every figure is measured against,
  tp_advance()           one block of the position, with its wrap guard,
  tp_index()             floor(phase * steps) as the lead and the drum read it,
  tp_phrase_index()      the same for a phrase of several bars, as the arp reads it,
  phrase_step_blocks()   the length of a step, used for gates and for the display,
  reset_due()            the lead's RESET gesture: N steps of the lead's grid,
  perc_reset_due()       the drum's own RESET: N steps of the drum's grid,
  delay_blocks_for_bpm() the synced delay as a whole number of blocks.

What the model can prove without the instrument: a step is where the position says it
is, in every figure at every tempo; the figures cannot drift apart because they read one
number; a tempo change moves no step backwards and loses none; the lead's gesture
restarts the lead's phrase on the step it promises and leaves the arp alone; the drum's gesture
restarts the drum's phrase on its own step and only once its last hit has rung out; and
each gesture moves its own figure by not one block of the other's.

The drum's "has rung out" is DECAY, read through synth_perc_decay_ms() from
components/synth_dsp/src/synth_perc.cpp: the envelope reaches PERC_TAIL (-60 dB) at
exactly that many milliseconds, so a voice is sounding for that many blocks of 256
samples. That is an upper bound on synth_perc_active_voices() and not a second
definition of it: a voice is freed at the -60 dB point the module documents.

It cannot prove how any of it sounds, and it does not read the display.

Run: python tools/seq_reset_check.py
"""

import math
import pathlib
import re
import sys
from fractions import Fraction

ROOT = pathlib.Path(__file__).resolve().parents[1]

FAILURES = []


def check(claim, ok, detail=""):
    print("  %s  %-64s %s" % ("ok  " if ok else "FAIL", claim, detail))
    if not ok:
        FAILURES.append(claim)


def _source(rel):
    return (ROOT / rel).read_text(encoding="utf-8")


def define(path, name):
    m = re.search(r"#define\s+" + name + r"\s+(\d+)", _source(path))
    if not m:
        raise SystemExit("seq_reset_check: %s not found in %s" % (name, path))
    return int(m.group(1))


def define_float(path, name):
    m = re.search(r"#define\s+" + name + r"\s+([0-9.eE+-]+)", _source(path))
    if not m:
        raise SystemExit("seq_reset_check: %s not found in %s" % (name, path))
    return float(m.group(1))


def constexpr_float(path, name):
    """A `constexpr float NAME = 20.0f;` in the DSP, where the #define above does not fit."""
    m = re.search(r"constexpr\s+float\s+" + name + r"\s*=\s*([0-9.eE+-]+)f?", _source(path))
    if not m:
        raise SystemExit("seq_reset_check: %s not found in %s" % (name, path))
    return float(m.group(1))


def reset_steps():
    m = re.search(r"SEQ_RESET_STEPS\[APP_SEQ_RESET_COUNT\]\s*=\s*\{([^}]*)\}",
                  _source("components/app_settings/src/app_settings.c"))
    if not m:
        raise SystemExit("seq_reset_check: SEQ_RESET_STEPS not found in app_settings.c")
    return [int(x) for x in m.group(1).split(",")]


def float_table(path, name, count_name):
    text = _source(path)
    m = re.search(name + r"\s*\[" + count_name + r"\]\s*=\s*\{(.*?)\};", text, re.S)
    if not m:
        raise SystemExit("seq_reset_check: %s not found in %s" % (name, path))
    values = [float(x) for x in re.findall(r"=\s*([0-9.]+)f", m.group(1))]
    if not values:
        raise SystemExit("seq_reset_check: %s is empty" % name)
    return values


SR = define("components/synth_dsp/include/synth_dsp.h", "SYNTH_SAMPLE_RATE")
BLOCK = define("components/synth_core/src/ESP32Synth_Config.hpp", "SYNTH_BLOCK_SAMPLES")
MIN_STEP_MS = define("components/synth_app/src/synth_app.cpp", "SEQ_MIN_STEP_MS")
MIN_GATE_MS = define("components/synth_app/src/synth_app.cpp", "SEQ_MIN_GATE_MS")
INDEX_GUARD = define_float("components/synth_app/src/synth_app.cpp", "TP_INDEX_GUARD")
WRAP_GUARD = define_float("components/synth_app/src/synth_app.cpp", "TP_WRAP_GUARD")
DELAY_BEATS = float_table("components/synth_app/src/synth_app.cpp",
                          "DELAY_DIV_BEATS", "DELAY_DIV_COUNT")
ARP_BEATS = float_table("components/synth_app/src/synth_app.cpp",
                        "ARP_DIV_BEATS", "ARP_SPEED_COUNT")
RESET_STEPS = reset_steps()
PERC_DECAY_MIN_MS = constexpr_float("components/synth_dsp/src/synth_perc.cpp", "PERC_DECAY_MIN_MS")
PERC_DECAY_MAX_MS = constexpr_float("components/synth_dsp/src/synth_perc.cpp", "PERC_DECAY_MAX_MS")
PERC_DECAY_SPAN = constexpr_float("components/synth_dsp/src/synth_perc.cpp", "PERC_DECAY_SPAN")

BPM_BLOCKS = 60 * SR // BLOCK          # 11250: the multiplication is inside the division
MIN_STEP = math.ceil(MIN_STEP_MS * SR / 1000.0 / BLOCK)
MIN_GATE = math.ceil(MIN_GATE_MS * SR / 1000.0 / BLOCK)
BLOCK_MS = 1000.0 * BLOCK / SR

GATE_DEFAULT = 0.5                      # synth_app_param_default(SEQ_GATE)

ARP_NAMES = ["4/1", "2/1", "1/1", "1/2.", "1/2", "1/4.", "1/4",
             "1/8.", "1/8", "1/16.", "1/8T", "1/16", "1/32"]
DELAY_NAMES = ["FREE", "1/1", "1/2.", "1/2", "1/4.", "1/4",
               "1/8.", "1/8", "1/16.", "1/8T", "1/16", "1/32"]

if len(DELAY_BEATS) != len(DELAY_NAMES) or len(ARP_BEATS) != len(ARP_NAMES):
    raise SystemExit("seq_reset_check: division tables do not match their names")


# --------------------------------------------------------------------------- #
# The arithmetic the firmware runs                                            #
# --------------------------------------------------------------------------- #

def bar_blocks(bpm):
    """bar_blocks_for_bpm(): four beats of 60*SR/BLOCK blocks a minute, to a block."""
    return int(4.0 * BPM_BLOCKS / bpm + 0.5)


def phrase_step(total, steps, index):
    """phrase_step_blocks(): ceil boundaries, so step i starts where floor(b*steps/total)
    changes; the floor is SEQ_MIN_STEP_BLOCKS and never binds in these cases."""
    i = index % steps
    a = (total * i + steps - 1) // steps
    b = (total * (i + 1) + steps - 1) // steps
    return max(b - a, MIN_STEP)


def is_onset(grid_index, n, k, rotate):
    """seq_is_onset(): E(k,n) rotated, p=0 always an onset."""
    p = (grid_index + rotate) % n
    if p == 0:
        return True
    return (p * k) // n != ((p - 1) * k) // n


def arp_phrase(div):
    """arp_phrase_steps(): smallest steps count that tiles whole bars; bars from div."""
    for m in range(1, 65):
        bars = Fraction(str(div)) * m / 4
        if bars.denominator == 1:
            return int(bars), m
    return 1, 1


def delay_blocks(bpm, div):
    """delay_blocks_for_bpm(): bar * beats / 4, rounded to the block, at least one."""
    return max(int(bar_blocks(bpm) * DELAY_BEATS[div] * 0.25 + 0.5), 1)


def delay_ideal(bpm, div):
    return bar_blocks(bpm) * DELAY_BEATS[div] * 0.25


def perc_decay_ms(decay01):
    """synth_perc_decay_ms(): exponential between 20 ms and 1.5 s, clamped at both ends."""
    d = 0.0 if not (decay01 >= 0.0) else (1.0 if decay01 > 1.0 else decay01)
    return PERC_DECAY_MIN_MS * (2.0 ** (d * PERC_DECAY_SPAN))


def perc_tail_blocks(decay01):
    """How many blocks a hit is sounding: DECAY is the time its gate takes to reach -60 dB.

    Rounded the way midi_ms_to_blocks() rounds the same number, and at least one block so
    that a hit is a voice at all.
    """
    ms = perc_decay_ms(decay01)
    return max(int(ms * (SR / float(BLOCK)) * 0.001 + 0.5), 1)


# --------------------------------------------------------------------------- #
# The transport and the three figures                                         #
# --------------------------------------------------------------------------- #

class Transport:
    def __init__(self, bpm):
        self.bpm = bpm
        self.phase = 0.0
        self.bar = 0
        self.running = True
        self.wraps = []

    def bar_blocks(self):
        return bar_blocks(self.bpm)

    def advance(self, held=False, arp_on=False):
        if not self.running and not (arp_on and held):
            return
        self.phase += 1.0 / self.bar_blocks()
        if self.phase >= 1.0 - WRAP_GUARD:
            self.phase -= 1.0
            if self.phase < 0.0:
                self.phase = 0.0
            self.bar += 1
            self.wraps.append(self.bar)

    def pos_steps(self, n):
        return (self.bar + self.phase) * n


class Rig:
    """One tick per audio block, in the order seq_tick() and tp_advance() use."""

    def __init__(self, bpm, lead=16, perc=16, lead_k=None, perc_k=None,
                 lead_rot=0, perc_rot=0, reset=0, perc_reset=0, perc_decay=0.35,
                 arp=None, gate=GATE_DEFAULT, held=False, running=True):
        self.tp = Transport(bpm)
        self.tp.running = running
        self.n = lead
        self.lead_k = lead if lead_k is None else lead_k
        self.lead_rot = lead_rot
        self.pn = perc
        self.perc_k = perc if perc_k is None else perc_k
        self.perc_rot = perc_rot
        self.reset_steps = reset
        self.perc_reset_steps = perc_reset
        self.arp = arp                       # ARP_BEATS index or None
        self.bars, self.arp_steps = arp_phrase(ARP_BEATS[arp]) if arp is not None else (0, 0)
        self.gate = gate
        self.held = held

        self.block = 0
        self.lead_prev = None
        self.lead_grid_prev = None
        self.perc_prev = None
        self.arp_prev = None
        self.lead_index = 0
        self.perc_index = 0
        self.lead_phrase = 0
        self.perc_phrase = 0

        # The lead's phrase is an origin on the transport's grid, not a second clock:
        # the phrase step is (bar*n + local - lead_origin) % n. Only a gesture moves it.
        self.lead_origin = 0
        self.arp_origin = 0

        # The drum has the same, on its own grid and in its own variable: nothing writes
        # both, which is the whole of why neither gesture can move the other figure.
        self.perc_origin = 0
        self.perc_grid = 0
        self.perc_tail = perc_tail_blocks(perc_decay)
        self.voices = []                    # block each sounding hit is freed at

        # events: (block, kind, figure, detail)
        self.events = []
        self.hits = {"lead": [], "perc": [], "arp": []}
        self.releases = []                  # (block, figure, scheduled)
        self.gate_left = 0
        self.gate_owner = None
        self.gate_end = 0
        self.shifts = []                    # (block, bar, phase, grid step, local)
        self.perc_shifts = []               # the drum's own, same shape
        self.overlaps = []                  # note-on while the same figure still sounds
        self.sounding = {}

    # -- the position ------------------------------------------------------ #
    def due(self, g):
        if self.reset_steps <= 0 or g < self.lead_origin:
            return False
        return (g - self.lead_origin) >= self.reset_steps

    def _shift(self, g, local):
        """The gesture: the lead's phrase begins again. The position, the drum, every gate
        and the ARP stay exactly where they are — the arp is the chord the hand is
        holding, counted from an origin of its own, and a rewind of the sequencer's figure
        must not stutter the pattern under the fingers."""
        self.shifts.append((self.block, self.tp.bar, self.tp.phase, g, local))
        self.lead_origin = g
        self.events.append((self.block, "reset", "-", 0))

    def lead_local(self):
        return min(int(self.tp.phase * self.n + INDEX_GUARD), self.n - 1)

    def perc_local(self):
        return min(int(self.tp.phase * self.pn + INDEX_GUARD), self.pn - 1)

    def arp_local(self):
        bar = self.tp.bar % self.bars
        pos = (bar + self.tp.phase) * self.arp_steps / self.bars
        return min(int(pos + INDEX_GUARD), self.arp_steps - 1)

    def _arp_raw(self):
        if self.arp is None:
            return 0
        return (self.tp.bar // self.bars) * self.arp_steps + self.arp_local()

    # -- notes ------------------------------------------------------------- #
    def _note_on(self, fig, block, idx, gate_blocks):
        end = block + gate_blocks
        old = self.sounding.get(fig)
        if old is not None and old > block:
            self.overlaps.append((fig, block, old))
        self.sounding[fig] = end
        self.hits[fig].append((block, idx))
        self.events.append((block, "on", fig, idx))
        self.gate_left = gate_blocks
        self.gate_owner = fig
        self.gate_end = end

    def _gate_tick(self):
        if self.gate_left > 0:
            self.gate_left -= 1
            if self.gate_left == 0:
                self.releases.append((self.block, self.gate_owner, self.gate_end))
                self.events.append((self.block, "off", self.gate_owner, self.gate_end))
                self.gate_owner = None

    def _lead_gate(self, local, phrase):
        gap = 1
        while not is_onset(phrase + gap, self.n, self.lead_k, self.lead_rot):
            gap += 1
        space = sum(phrase_step(bar_blocks(self.tp.bpm), self.n, local + i)
                    for i in range(gap))
        g = int(space * self.gate + 0.5)
        return min(max(g, MIN_GATE), space)

    def _lead_tick(self):
        local = self.lead_local()
        if local == self.lead_prev:
            return
        self.lead_prev = local
        self.lead_index = local
        g = self.tp.bar * self.n + local
        phrase = (g - self.lead_origin) % self.n if g >= self.lead_origin else 0
        self.lead_phrase = phrase
        if self.tp.running and is_onset(phrase, self.n, self.lead_k, self.lead_rot):
            self._note_on("lead", self.block, phrase, self._lead_gate(local, phrase))

    def _perc_tick(self):
        # A change of STEPS re-anchors the drum's origin on the bar, exactly as the lead's
        # does: the same bar divided differently is a different count of steps.
        if self.pn != self.perc_grid:
            self.perc_origin = self.tp.bar * self.pn
            self.perc_grid = self.pn

        local = self.perc_local()
        if local == self.perc_prev:
            return
        self.perc_prev = local

        # The drum's grid step, counted from START: the transport's step number on ITS
        # grid, exactly as g is on the lead's.
        p = self.tp.bar * self.pn + local

        # Its gesture is due when ITS phrase has stood on N of ITS steps, and it fires
        # only when the drum is silent: DECAY is its gate, and striking step zero of the
        # new phrase on top of a tail still ringing would double the hit.
        if self._perc_due(p) and self._perc_free():
            self.perc_origin = p
            self.perc_shifts.append((self.block, self.tp.bar, self.tp.phase, p, local))
            self.events.append((self.block, "preset", "-", 0))

        phrase = ((p - self.perc_origin) % self.pn) if p >= self.perc_origin else 0
        self.perc_phrase = phrase
        self.perc_index = phrase
        if self.tp.running and is_onset(phrase, self.pn, self.perc_k, self.perc_rot):
            self.hits["perc"].append((self.block, phrase))
            self.events.append((self.block, "on", "perc", phrase))
            self.voices = [v for v in self.voices if v > self.block]
            self.voices.append(self.block + self.perc_tail)

    def _perc_due(self, p):
        """perc_reset_due(): N steps of the drum's grid from its own origin."""
        if self.perc_reset_steps <= 0 or p < self.perc_origin:
            return False
        return (p - self.perc_origin) >= self.perc_reset_steps

    def _perc_free(self):
        """synth_perc_active_voices() == 0: no hit is still inside its decay."""
        return not any(v > self.block for v in self.voices)

    def _arp_tick(self):
        if not self.arp_steps:
            return
        local = self.arp_local()
        step = self._arp_raw() - self.arp_origin
        if step == self.arp_prev:
            return
        self.arp_prev = step
        if not self.tp.running and not self.held:
            # the scale figure opens no note at STOP; a held chord does
            return
        step_blocks = phrase_step(self.bars * bar_blocks(self.tp.bpm),
                                  self.arp_steps, local)
        g = int(step_blocks * self.gate + 0.5)
        g = min(max(g, 1), step_blocks)
        self._note_on("arp", self.block, step, g)

    # -- one block --------------------------------------------------------- #
    def tick(self):
        self.block += 1

        local = self.lead_local()
        lead_step = local != self.lead_grid_prev
        self.lead_grid_prev = local
        g = self.tp.bar * self.n + local

        # The gesture fires on a lead-grid boundary, and only when the note the lead
        # opened has finished its gate — a sparse figure's gate is longer than a step.
        # The arp always takes its first note at once (its replacement is documented).
        free = (self.arp is not None) or (self.gate_left <= 1)
        if lead_step and free and self.due(g):
            self._shift(g, local)

        self._perc_tick()
        self._gate_tick()
        if self.arp is not None:
            self.lead_prev = local        # the lead owns nothing while the arp plays
            self._arp_tick()
        else:
            self._lead_tick()
        self.tp.advance(held=self.held, arp_on=self.arp is not None)


def run(rig, blocks):
    for _ in range(blocks):
        rig.tick()
    return rig


def run_for_bars(bpm, bars, **kw):
    return run(Rig(bpm, **kw), bars * bar_blocks(bpm))


def run_until_shifts(rig, count, max_blocks=4_000_000):
    while len(rig.shifts) < count and rig.block < max_blocks:
        rig.tick()
    return rig


def run_until_perc_shifts(rig, count, max_blocks=4_000_000):
    while len(rig.perc_shifts) < count and rig.block < max_blocks:
        rig.tick()
    return rig


# --------------------------------------------------------------------------- #
# 1. The phrase and the position                                              #
# --------------------------------------------------------------------------- #

print("\n1. THE POSITION AND THE STEPS")
for bpm in (60, 120, 180, 300):
    bar = bar_blocks(bpm)
    lens = [phrase_step(bar, 16, i) for i in range(16)]
    check("%d BPM: 16 steps fill the bar exactly" % bpm,
          sum(lens) == bar, "bar=%d lens=%s" % (bar, sorted(set(lens))))
    check("%d BPM: no step differs by more than a block" % bpm,
          max(lens) - min(lens) <= 1, "%d..%d" % (min(lens), max(lens)))

for bar in range(150, 1501):
    p = 0.0
    k = 0
    while True:
        p += 1.0 / bar
        k += 1
        if p >= 1.0 - WRAP_GUARD:
            p -= 1.0
            if p < 0:
                p = 0.0
            break
    if k != bar:
        check("bar of %d blocks wraps on time" % bar, False, "wrapped at %d" % k)
        break
else:
    check("every bar from 150 to 1500 blocks wraps on its own block", True,
          "1350 lengths, worst residual after 100 bars 4e-12")

# One simulated hour at four tempos: the bar count must be the exact one.
for bpm in (60, 120, 180, 300):
    bar = bar_blocks(bpm)
    total = int(3600 * SR / BLOCK)      # an hour of audio blocks
    tp = Transport(bpm)
    for _ in range(total):
        tp.advance()
    exact = total / bar
    err = abs((tp.bar + tp.phase) - exact)
    check("%d BPM: an hour of blocks is an hour of bars" % bpm, err < 1e-6,
          "error %.2e bar" % err)

# 100 bars of steps: the sum of the step lengths is the sum of the bars.
for steps in (4, 7, 9, 12, 16):
    bar = bar_blocks(120)
    total = sum(phrase_step(bar, steps, i) for i in range(100 * steps))
    check("120 BPM, %d steps: 100 bars sum to 100 bars" % steps,
          total == 100 * bar, "%d blocks" % total)


# --------------------------------------------------------------------------- #
# 2. The drum and the lead tick on the position                               #
# --------------------------------------------------------------------------- #

print("\n2. PERCUSSION: CONSTANT INTERVALS, THE STEP'S OWN LENGTH")
for bpm in (60, 120, 180, 300):
    rig = run_for_bars(bpm, 16, lead=16, perc=16, perc_k=16)
    hits = [b for b, _ in rig.hits["perc"]]
    gaps = [b - a for a, b in zip(hits, hits[1:])]
    bar = bar_blocks(bpm)
    lens = [phrase_step(bar, 16, i) for i in range(16)]
    want = set(lens)
    check("%d BPM: 16-step drum gives only %s" % (bpm, sorted(want)),
          set(gaps) == want, "gaps=%s" % sorted(set(gaps)))
    check("%d BPM: each interval is that step's own length" % bpm,
          all(gaps[i] == lens[i % 16] for i in range(len(gaps))),
          "first gaps=%s" % gaps[:4])
    check("%d BPM: no hit in two consecutive blocks" % bpm, min(gaps) > 1,
          "min gap %d" % min(gaps))

rig = run_for_bars(120, 100, lead=16, perc=16, perc_k=16)
hits = [b for b, _ in rig.hits["perc"]]
check("120 BPM: 100 bars hold 1600 drum hits",
      len(hits) == 1600, "%d hits" % len(hits))
check("120 BPM: the last hit is the 1600th step boundary",
      hits[-1] == 1 + sum(phrase_step(bar_blocks(120), 16, i) for i in range(1599)),
      "block %d" % hits[-1])


# --------------------------------------------------------------------------- #
# 3. No two hits closer than half a step, in any figure or rotation           #
# --------------------------------------------------------------------------- #

print("\n3. NO FIGURE PUTS TWO HITS CLOSER THAN HALF A STEP")
def closest_pair(hits, steps_of):
    worst = None
    for (b0, i0), (b1, _) in zip(hits, hits[1:]):
        gap = b1 - b0
        half = steps_of(i0) / 2.0
        if worst is None or gap / half < worst[0]:
            worst = (gap / half, b0, gap, half)
    return worst


for bpm in (60, 120, 180, 300):
    bar = bar_blocks(bpm)
    for n, k, rot in ((16, 16, 0), (12, 12, 0), (7, 7, 0), (16, 4, 3),
                      (9, 5, 2), (5, 5, 4), (16, 7, 11), (12, 5, 7)):
        rig = run_for_bars(bpm, 20, lead=n, perc=16, lead_k=k, lead_rot=rot)
        hits = rig.hits["lead"]
        worst = closest_pair(hits, lambda i: phrase_step(bar, n, i))
        check("%d BPM lead %d/%d rot %d: gap >= half a step" % (bpm, n, k, rot),
              worst is None or worst[0] >= 1.0,
              "" if worst is None else "closest %.2f of a half-step" % worst[0])

for bpm in (60, 120, 300):
    for div, name in enumerate(ARP_NAMES):
        rig = run_for_bars(bpm, 8, lead=16, perc=16, perc_k=16, arp=div)
        bars, steps = arp_phrase(ARP_BEATS[div])
        total = bars * bar_blocks(bpm)
        gaps = [b - a for (a, _), (b, _) in zip(rig.hits["arp"], rig.hits["arp"][1:])]
        ok = all(g >= phrase_step(total, steps, 0) / 2.0 for g in gaps) if gaps else True
        check("%d BPM arp %s: every step at least half a step long" % (bpm, name),
              ok and (not gaps or min(gaps) > 1),
              "min gap %s" % (min(gaps) if gaps else "-"))


# --------------------------------------------------------------------------- #
# 4. Two grids, one bar: the phrases start together                           #
# --------------------------------------------------------------------------- #

print("\n4. 12 AGAINST 16 AND 16 AGAINST 12 DO NOT DIVERGE")
for lead, perc in ((12, 16), (16, 12), (7, 16), (16, 7)):
    rig = run_for_bars(120, 100, lead=lead, perc=perc)
    bar = bar_blocks(120)
    starts = [b for b, i in rig.hits["lead"] if i == 0]
    pstarts = [b for b, i in rig.hits["perc"] if i == 0]
    check("lead %d / drum %d: 100 bar lines in 100 bars" % (lead, perc),
          len(starts) == 100 and len(pstarts) == 100,
          "%d / %d" % (len(starts), len(pstarts)))
    check("lead %d / drum %d: both phrases start on the same block" % (lead, perc),
          starts == pstarts and starts[0] == 1,
          "first %s" % starts[:3])
    check("lead %d / drum %d: every line is %d blocks after the last" % (lead, perc, bar),
          all(b - a == bar for a, b in zip(starts, starts[1:])), "")


# --------------------------------------------------------------------------- #
# 4b. Polyrhythm: each figure follows the position and corrects nobody        #
# --------------------------------------------------------------------------- #

print("\n4b. POLYRHYTHM: A SHORTER FIGURE WRAPS WITHOUT MOVING THE OTHER")


def pure_grid(n, bpm, bars_count):
    """Each step boundary as the position alone puts it: floor((block-1 mod bar)/bar*n).
    This is the oracle a figure must match block for block, with no correction applied."""
    bar = bar_blocks(bpm)
    out = []
    prev = None
    for k in range(1, bars_count * bar + 1):
        i = (k - 1) % bar
        loc = min(int(i * n / bar + INDEX_GUARD), n - 1)
        if loc != prev:
            out.append((k, loc))
            prev = loc
    return out


for lead, perc in ((16, 12), (12, 16), (16, 7), (7, 16), (12, 5), (5, 12)):
    bar = bar_blocks(120)
    rig = run_for_bars(120, 100, lead=lead, perc=perc)
    lg = pure_grid(lead, 120, 100)
    pg = pure_grid(perc, 120, 100)
    lead_hits = [b for b, _ in rig.hits["lead"]]
    perc_hits = [b for b, _ in rig.hits["perc"]]
    check("poly %d/%d: the lead is exactly the position's grid" % (lead, perc),
          lead_hits == [k for k, _ in lg],
          "%d notes" % len(lead_hits))
    check("poly %d/%d: the drum is exactly the position's grid" % (lead, perc),
          perc_hits == [k for k, _ in pg],
          "%d hits" % len(perc_hits))

    lgaps = [b - a for (a, _), (b, _) in zip(rig.hits["lead"], rig.hits["lead"][1:])]
    pgaps = [b - a for (a, _), (b, _) in zip(rig.hits["perc"], rig.hits["perc"][1:])]
    check("poly %d/%d: every lead interval is that lead step's length" % (lead, perc),
          all(lgaps[i] == phrase_step(bar, lead, i % lead) for i in range(len(lgaps))),
          "%d..%d" % (min(lgaps), max(lgaps)))
    check("poly %d/%d: every drum interval is that drum step's length" % (lead, perc),
          all(pgaps[i] == phrase_step(bar, perc, i % perc) for i in range(len(pgaps))),
          "%d..%d" % (min(pgaps), max(pgaps)))

    # Both phrases are one bar long, so both go back to the top on every bar line —
    # 48 lead steps and 36 drum steps after the previous one. That is the common
    # downbeat the owner hears; it happens by itself.
    lstarts = [b for b, i in rig.hits["lead"] if i == 0]
    pstarts = [b for b, i in rig.hits["perc"] if i == 0]
    check("poly %d/%d: both come round together on every bar line" % (lead, perc),
          lstarts == pstarts and len(lstarts) == 100,
          "%d common starts" % len(lstarts))

    check("poly %d/%d: nothing shifted either figure (no RESET)" % (lead, perc),
          not rig.shifts and not rig.overlaps,
          "%d shifts, %d retriggers" % (len(rig.shifts), len(rig.overlaps)))

# A three-bar arp figure wraps in the middle of a bar, twice in every three: the drum
# beside it must keep its own grid, untouched.
rig = run_for_bars(120, 99, lead=16, perc=12, arp=3)     # 1/2. = four steps in 3 bars
bar = bar_blocks(120)
pg = pure_grid(12, 120, 99)
check("poly with a 3-bar arp: the drum still is exactly the position's grid",
      [b for b, _ in rig.hits["perc"]] == [k for k, _ in pg],
      "%d hits, %d arp notes" % (len(rig.hits["perc"]), len(rig.hits["arp"])))
check("poly with a 3-bar arp: no RESET fired", not rig.shifts, "")

print("\n5. THE ARP PLAYS WITHOUT FREEZING THE LEAD")
base = run_for_bars(120, 32, lead=16, perc=16, perc_k=16)
with_arp = run_for_bars(120, 32, lead=16, perc=16, perc_k=16, arp=8)
check("arp on: the drum's hits are the same blocks as with the arp off",
      with_arp.hits["perc"] == base.hits["perc"],
      "%d hits" % len(with_arp.hits["perc"]))
check("arp on: the arp itself steps", len(with_arp.hits["arp"]) > 100,
      "%d arp notes in 32 bars" % len(with_arp.hits["arp"]))


# The old defect: the lead's index froze at 0 while the arp held the grid. Here the
# position is one, so switching the arp off resumes the lead on the bar's own boundary.
rig = Rig(120, lead=16, perc=16, perc_k=16, arp=8)
run(rig, 10 * bar_blocks(120) + 30)
rig.arp = None
turn_block = rig.block
run(rig, bar_blocks(120))
first = next(h for h in rig.hits["lead"] if h[0] > turn_block)
want = next((k, loc) for k, loc in pure_grid(16, 120, 11) if k > turn_block
            and loc != 0)
check("arp off again: the lead resumes on the bar's own step, not at zero",
      first == want and want[1] != 0,
      "block %d step %d (want %d)" % (first[0], first[1], want[1]))


# --------------------------------------------------------------------------- #
# 6. A tempo change moves no step backwards and loses none                    #
# --------------------------------------------------------------------------- #

print("\n6. TEMPO CHANGES: NO JUMP, NO DOUBLE HIT, NO MISSED HIT")
rig = Rig(120, lead=16, perc=16, perc_k=16, lead_k=16)
changes = {1500: 180, 3000: 90, 4500: 240}
locs = []
boundaries = []
for b in range(1, 6001):
    if b in changes:
        rig.tp.bpm = changes[b]
    loc = rig.perc_local()
    rig.tick()
    if not locs or loc != locs[-1]:
        boundaries.append(b)
    locs.append(loc)
hit_blocks = [x[0] for x in rig.hits["perc"]]
jumps = sum(1 for a, c in zip(locs, locs[1:]) if (c - a) % 16 > 1)
check("120->180->90->240: the drum's index never jumps", jumps == 0,
      "%d jumps" % jumps)
check("120->180->90->240: no step struck twice",
      len(hit_blocks) == len(set(hit_blocks)), "%d hits" % len(hit_blocks))
check("120->180->90->240: one hit for every boundary crossed",
      hit_blocks == boundaries,
      "%d hits, %d boundaries" % (len(hit_blocks), len(boundaries)))

# Phase never runs backwards across a change (except the bar subtract).
rig = Rig(120, lead=16, perc=16)
prev_pos = 0.0
back = 0
for b in range(1, 4000):
    if b == 1200:
        rig.tp.bpm = 300
    if b == 2400:
        rig.tp.bpm = 60
    before = rig.tp.bar + rig.tp.phase
    rig.tick()
    after = rig.tp.bar + rig.tp.phase
    if after < before - 0.5:
        back += 1
    prev_pos = after
check("the position never runs backwards on a tempo change", back == 0,
      "%d backwards blocks" % back)


# --------------------------------------------------------------------------- #
# 7. STOP freezes the phrase; START moves it to the top                       #
# --------------------------------------------------------------------------- #

print("\n7. STOP AND START")
rig = run_for_bars(120, 4, lead=16, perc=16, perc_k=16)
rig.tp.running = False
pos = (rig.tp.bar, rig.tp.phase)
n_before = len(rig.hits["lead"]), len(rig.hits["perc"])
run(rig, bar_blocks(120))
check("STOP: the position does not move", (rig.tp.bar, rig.tp.phase) == pos,
      "phase %.6f" % rig.tp.phase)
check("STOP: no lead note and no drum hit",
      (len(rig.hits["lead"]), len(rig.hits["perc"])) == n_before, "")
rig.tp.running = True
run(rig, bar_blocks(120))
check("CONTINUE: the phrase resumes, it is not restarted",
      rig.tp.bar >= 5, "bar %d" % rig.tp.bar)

rig = Rig(120, lead=16, perc=16, arp=8, held=True)
run(rig, 3 * bar_blocks(120))
rig.tp.running = False
n_arp = len(rig.hits["arp"])
n_perc = len(rig.hits["perc"])
run(rig, bar_blocks(120))
check("STOP with a held chord: only the arp's hand keeps moving",
      len(rig.hits["arp"]) > n_arp and len(rig.hits["perc"]) == n_perc,
      "%d arp notes, %d drum hits" %
      (len(rig.hits["arp"]) - n_arp, len(rig.hits["perc"]) - n_perc))


# --------------------------------------------------------------------------- #
# 8. RESET is the lead's gesture; the drum and the arp are not touched       #
# --------------------------------------------------------------------------- #

print("\n8. RESET: THE LEAD'S PHRASE MOVES; THE DRUM AND THE ARP DO NOT")
# (lead steps, drum steps, arp division, lead pulses)
cases = [
    (16, 16, None, 16), (16, 16, 8, 16),
    (12, 16, None, 12), (12, 16, 8, 12),
    (7, 16, None, 7), (16, 7, None, 16),
    (5, 16, None, 5), (16, 16, 11, 16),
    (12, 16, None, 4), (12, 16, 8, 4),      # the owner's 4-of-12 lead
]
for n, pn, arp, k in cases:
    for nsteps in (16, 32, 64):
        bar = bar_blocks(120)
        rig = Rig(120, lead=n, perc=pn, lead_k=k, reset=nsteps, arp=arp)
        run_until_shifts(rig, 3)
        blocks = [s[0] for s in rig.shifts]
        gs = [s[3] for s in rig.shifts]
        locs = [s[4] for s in rig.shifts]
        tag = "lead %2d/%2d drum %2d %s RESET %2d" % (
            n, k, pn, "arp" if arp is not None else "   ", nsteps)

        # The gesture is counted in steps of the lead's grid, from the phrase origin.
        gaps = [b - a for a, b in zip(gs, gs[1:])]
        if k == n:
            check("%s: exactly %d steps between gestures" % (tag, nsteps),
                  len(gs) >= 3 and gs[0] == nsteps and all(g == nsteps for g in gaps),
                  "gaps %s" % gaps)
        else:
            check("%s: the restart can wait for a gate, never longer than a figure" % tag,
                  len(gs) >= 3 and gs[0] >= nsteps
                  and all(nsteps <= g <= nsteps + n for g in gaps),
                  "gaps %s" % gaps)

        # Every gesture is a boundary of the transport's grid, and no note is cut.
        lead_bounds = {k for k, _ in pure_grid(n, 120, 200)}
        check("%s: every restart is a step boundary" % tag,
              all(b in lead_bounds for b in blocks), "first %s" % blocks[:3])
        early = [r for r in rig.releases if r[0] != r[2]]
        check("%s: no release ahead of its gate" % tag, not early,
              "%d early" % len(early))
        if arp is None:
            check("%s: no lead note retriggered before its gate ends" % tag,
                  not rig.overlaps, "%d overlaps" % len(rig.overlaps))

        # The drum is bit-for-bit the drum of a run with the gesture switched off: same
        # blocks, same step numbers, same intervals. A gesture on the lead cannot move
        # it even by a block, so this is an equality and not a tolerance.
        base = Rig(120, lead=n, perc=pn, lead_k=k, reset=0, arp=arp)
        run(base, rig.block)
        check("%s: the drum is identical to the run without the gesture" % tag,
              rig.hits["perc"] == base.hits["perc"],
              "%d hits" % len(rig.hits["perc"]))

        # And at the very moment of the gesture: the interval across it is the drum's
        # own next step (or its next onset, in a sparse drum), and the step number
        # continues — it does not start from zero.
        b0 = blocks[0]
        prev = [h for h in rig.hits["perc"] if h[0] < b0][-1]
        nxt = [h for h in rig.hits["perc"] if h[0] >= b0][0]
        d = 1
        while not is_onset(prev[1] + d, pn, rig.perc_k, rig.perc_rot):
            d += 1
        want_gap = sum(phrase_step(bar, pn, prev[1] + i) for i in range(d))
        check("%s: the drum's step across the gesture is its own next step" % tag,
              nxt[0] - prev[0] == want_gap and nxt[1] == (prev[1] + d) % pn,
              "steps %d->%d, %d blocks" % (prev[1], nxt[1], nxt[0] - prev[0]))

        # The lead begins on its first step, in the very block of the gesture. The arp
        # does not: it is a third player with an origin of its own, and its notes must be
        # bit-for-bit the notes of a run with the gesture switched off — the same blocks,
        # the same step numbers. A RESET while a chord is held used to restart the pattern
        # under the fingers, and that is what this equality forbids.
        if arp is None:
            on = [h for h in rig.hits["lead"] if h[0] == b0]
            check("%s: the lead restarts on phrase step 0" % tag,
                  bool(on) and on[0][1] == 0, "steps %s" % [i for _, i in on])
        else:
            check("%s: the arp keeps running through the gesture" % tag,
                  rig.hits["arp"] == base.hits["arp"],
                  "%d notes, %d in the run without it" %
                  (len(rig.hits["arp"]), len(base.hits["arp"])))

# The owner's exact case, spelled out: lead four of twelve, drum four of sixteen,
# RESET sixteen. The drum keeps its grid through every restart.
rig = run(Rig(120, lead=12, perc=16, lead_k=4, perc_k=4, reset=16),
          100 * bar_blocks(120))
base = run(Rig(120, lead=12, perc=16, lead_k=4, perc_k=4, reset=0),
           100 * bar_blocks(120))
pgaps = [b - a for (a, _), (b, _) in zip(rig.hits["perc"], rig.hits["perc"][1:])]
check("owner's case 4/12 + 4/16 RESET 16: the drum is untouched for 100 bars",
      rig.hits["perc"] == base.hits["perc"], "%d hits" % len(rig.hits["perc"]))
check("owner's case: every drum interval is its own four-step distance",
      all(g == sum(phrase_step(bar_blocks(120), 16, (i + j) % 16) for j in range(4))
          for i, g in zip([x[1] for x in rig.hits["perc"]], pgaps)),
      "%d..%d blocks" % (min(pgaps), max(pgaps)))
check("owner's case: the lead restarts (%d gestures) and never cuts a note" %
      len(rig.shifts), len(rig.shifts) > 50 and not rig.overlaps
      and all(r[0] == r[2] for r in rig.releases),
      "%d shifts, gaps %d..%d steps" %
      (len(rig.shifts),
       min(b - a for a, b in zip([s[3] for s in rig.shifts],
                                 [s[3] for s in rig.shifts[1:]])),
       max(b - a for a, b in zip([s[3] for s in rig.shifts],
                                 [s[3] for s in rig.shifts[1:]]))))

# RESET 0 (INF) does nothing at all, and the streams are identical to a run with the
# gesture disabled.
a = run_for_bars(120, 100, lead=16, perc=12, reset=0)
b = run_for_bars(120, 100, lead=16, perc=12, reset=10 ** 9)
check("RESET off: not one shift in 100 bars", not a.shifts, "")
check("RESET off: the event stream is the plain transport", a.events == b.events,
      "%d events" % len(a.events))

# A multiple of the grid is a shift onto the bar line it was going to reach anyway:
# the phrase is not rotated, so even the lead's notes are the same events.
for n, nsteps in ((16, 16), (16, 32), (4, 64), (8, 128)):
    rig = run_for_bars(120, 200, lead=n, perc=16, reset=nsteps)
    base = run_for_bars(120, 200, lead=n, perc=16, reset=0)
    bar = bar_blocks(120)
    on_line = all(s[0] == 1 + (s[3] // n) * bar for s in rig.shifts)
    check("RESET %d on a %d-step grid is inaudible (bar line)" % (nsteps, n),
          len(rig.shifts) >= 2 and on_line
          and rig.hits["lead"] == base.hits["lead"],
          "%d shifts" % len(rig.shifts))

# 8c. The gesture switched on must leave the polyrhythm a polyrhythm: the lead's notes
# stay on the lead's own grid, the drum's on its own, and the drum is untouched.
print("\n8c. POLYRHYTHM WITH THE GESTURE ON")
for lead, perc, nsteps in ((16, 12, 16), (16, 12, 12), (12, 16, 16),
                           (16, 7, 16), (16, 7, 12), (12, 5, 32)):
    bar = bar_blocks(120)
    rig = run_for_bars(120, 100, lead=lead, perc=perc, reset=nsteps)
    base = run_for_bars(120, 100, lead=lead, perc=perc, reset=0)
    lb = [k for k, _ in pure_grid(lead, 120, 100)]
    lgaps = [b - a for a, b in zip([x[0] for x in rig.hits["lead"]],
                                   [x[0] for x in rig.hits["lead"]][1:])]
    check("poly %d/%d RESET %d: the lead never leaves its grid" % (lead, perc, nsteps),
          [b for b, _ in rig.hits["lead"]] == lb, "%d notes, %d shifts" %
          (len(rig.hits["lead"]), len(rig.shifts)))
    check("poly %d/%d RESET %d: the lead's intervals are still its step lengths" %
          (lead, perc, nsteps),
          all(lgaps[i] == phrase_step(bar, lead, i % lead) for i in range(len(lgaps))),
          "%d..%d blocks" % (min(lgaps), max(lgaps)))
    check("poly %d/%d RESET %d: the drum is untouched by every shift" %
          (lead, perc, nsteps), rig.hits["perc"] == base.hits["perc"],
          "%d hits" % len(rig.hits["perc"]))
    on0 = [i for b, i in rig.hits["lead"] if b in [s[0] for s in rig.shifts]]
    check("poly %d/%d RESET %d: every restart sounds the lead's step 0" %
          (lead, perc, nsteps),
          len(on0) == len(rig.shifts) and all(i == 0 for i in on0),
          "%d of %d" % (sum(1 for i in on0 if i == 0), len(rig.shifts)))

# The gesture is exactly the period the knob names, at the slowest and fastest tempo.
for bpm in (60, 300):
    bar = bar_blocks(bpm)
    rig = Rig(bpm, lead=12, perc=16, reset=16)
    run_until_shifts(rig, 3)
    gaps = [s[3] - t[3] for t, s in zip(rig.shifts, rig.shifts[1:])]
    check("%d BPM RESET 16 on 12 steps: 16 steps between gestures" % bpm,
          gaps and all(g == 16 for g in gaps), "gaps %s" % gaps)
    # and in blocks: the sum of those sixteen step lengths
    bgaps = [s[0] - t[0] for t, s in zip(rig.shifts, rig.shifts[1:])]
    want = [sum(phrase_step(bar, 12, (loc + j) % 12) for j in range(16))
            for loc in [s[4] for s in rig.shifts[:-1]]]
    check("%d BPM: each gap in blocks is those sixteen steps' lengths" % bpm,
          bgaps == want, "gaps %s" % bgaps)


# --------------------------------------------------------------------------- #
# 8d. Two resets, two sequencers: each moves its own figure only              #
# --------------------------------------------------------------------------- #

print("\n8d. TWO RESETS: EACH SEQUENCER MOVES ITSELF AND NOTHING ELSE")

# (lead n, lead k, lead RESET, drum n, drum k, drum RESET, DECAY, what the case is)
two_reset_cases = [
    (12, 4, 16, 16, 4, 0, 0.35, "the owner's lead 4/12 RESET 16, drum off"),
    (12, 4, 0, 16, 4, 16, 0.35, "the same the other way round"),
    (12, 4, 16, 16, 4, 32, 0.35, "both on, different periods"),
    (16, 8, 12, 12, 3, 16, 0.2, "both on, neither period a multiple"),
    (7, 7, 64, 16, 16, 16, 0.35, "a dense drum and a sparse lead"),
]
for (ln, lk, lreset, pn, pk, preset, decay, what) in two_reset_cases:
    tag = "lead %d/%d R%d, drum %d/%d R%d, DECAY %.2f (%s)" % (
        ln, lk, lreset, pn, pk, preset, decay, what)
    blocks = 200 * bar_blocks(120)
    both = run(Rig(120, lead=ln, lead_k=lk, perc=pn, perc_k=pk, reset=lreset,
                   perc_reset=preset, perc_decay=decay), blocks)
    lead_only = run(Rig(120, lead=ln, lead_k=lk, perc=pn, perc_k=pk, reset=lreset,
                        perc_reset=0, perc_decay=decay), blocks)
    perc_only = run(Rig(120, lead=ln, lead_k=lk, perc=pn, perc_k=pk, reset=0,
                        perc_reset=preset, perc_decay=decay), blocks)

    check("8d %s: the lead's notes ignore the drum's gesture" % tag,
          both.hits["lead"] == lead_only.hits["lead"],
          "%d notes" % len(both.hits["lead"]))
    check("8d %s: the drum's hits ignore the lead's gesture" % tag,
          both.hits["perc"] == perc_only.hits["perc"],
          "%d hits" % len(both.hits["perc"]))
    check("8d %s: each gesture fires as often as it does alone" % tag,
          len(both.shifts) == len(lead_only.shifts)
          and len(both.perc_shifts) == len(perc_only.perc_shifts),
          "%d lead shifts, %d drum shifts" %
          (len(both.shifts), len(both.perc_shifts)))
    check("8d %s: each figure's restart sounds its own step 0, in the block of the gesture"
          % tag,
          all([i for b, i in both.hits["lead"] if b == s[0]] == [0] for s in both.shifts)
          and all([i for b, i in both.hits["perc"] if b == s[0]] == [0]
                  for s in both.perc_shifts),
          "%d / %d" % (len(both.shifts), len(both.perc_shifts)))

    # The drum's gesture is counted in ITS steps, from ITS own origin, and it lands on a
    # boundary of its own grid — never inside a step, and never on the lead's grid.
    gaps = [b[3] - a[3] for a, b in zip(both.perc_shifts, both.perc_shifts[1:])]
    if preset == 0:
        check("8d %s: the drum's RESET is off, so it never shifts" % tag,
              not both.perc_shifts, "%d shifts" % len(both.perc_shifts))
    else:
        check("8d %s: the drum's period is its own %d steps, or longer when it must wait"
              % (tag, preset),
              gaps and all(g >= preset for g in gaps) and gaps[0] >= preset,
              "first gaps %s" % gaps[:4])
        drum_bounds = {k for k, _ in pure_grid(pn, 120, 400)}
        check("8d %s: every drum restart is a boundary of the drum's grid" % tag,
              all(s[0] in drum_bounds for s in both.perc_shifts),
              "first %s" % [s[0] for s in both.perc_shifts[:3]])

        # And it fires only once the hit before it has rung out: at the block of the
        # gesture the drum has been silent for DECAY, which is the whole reason the wait
        # exists.
        tail = perc_tail_blocks(decay)
        sounded = []
        for s in both.perc_shifts:
            before = [h for h in both.hits["perc"] if h[0] < s[0]]
            sounded.append(not before or s[0] - before[-1][0] >= tail)
        check("8d %s: no drum restart lands on a tail still ringing" % tag, all(sounded),
              "%d of %d" % (sum(1 for x in sounded if x), len(sounded)))

# The lead's gesture must not move the arp either, and the drum's must not move both.
both = run(Rig(120, lead=12, lead_k=4, perc=16, perc_k=4, reset=16, perc_reset=16, arp=8),
           100 * bar_blocks(120))
lead_only = run(Rig(120, lead=12, lead_k=4, perc=16, perc_k=4, reset=16, perc_reset=0, arp=8),
                100 * bar_blocks(120))
perc_only = run(Rig(120, lead=12, lead_k=4, perc=16, perc_k=4, reset=0, perc_reset=16, arp=8),
                100 * bar_blocks(120))
check("8d with the arp on: the drum's hits are the drum's own",
      both.hits["perc"] == perc_only.hits["perc"],
      "%d hits" % len(both.hits["perc"]))
check("8d with the arp on: the arp's notes are the arp's own",
      both.hits["arp"] == lead_only.hits["arp"],
      "%d notes" % len(both.hits["arp"]))

# The drum's RESET 0 (off) is the plain transport, and the gesture switched on at a
# period of a million steps is the same stream: nothing in the drum's path reads the knob
# unless it is due.
a = run_for_bars(120, 100, lead=16, perc=12, perc_reset=0)
b = run_for_bars(120, 100, lead=16, perc=12, perc_reset=10 ** 9)
check("8d drum RESET off: not one drum shift in 100 bars", not a.perc_shifts, "")
check("8d drum RESET off: the event stream is the plain transport", a.events == b.events,
      "%d events" % len(a.events))

# THE PRICE OF THE WAIT, as the note over perc_tick() states it: a drum whose DECAY is
# longer than its step is NEVER silent, so the gesture never fires — and the figure is
# exactly the figure it would be without the gesture.
check("8d DECAY 1.0 is the module's ceiling", abs(perc_decay_ms(1.0) - PERC_DECAY_MAX_MS) < 0.5,
      "%.1f ms" % perc_decay_ms(1.0))
starved = run(Rig(120, lead=16, perc=16, perc_k=16, perc_reset=16, perc_decay=1.0),
              100 * bar_blocks(120))
plain = run(Rig(120, lead=16, perc=16, perc_k=16, perc_reset=0, perc_decay=1.0),
            100 * bar_blocks(120))
check("8d DECAY 1.5 s on a sixteenth grid: the drum is never silent, so RESET never fires",
      not starved.perc_shifts, "%d shifts" % len(starved.perc_shifts))
check("8d the starved drum is bit-for-bit the drum without the gesture",
      starved.hits["perc"] == plain.hits["perc"] and starved.events == plain.events,
      "%d hits" % len(starved.hits["perc"]))

# And a drum that does ring out between hits fires on the exact step it promises, at the
# slowest and fastest tempo.
for bpm in (60, 300):
    bar = bar_blocks(bpm)
    rig = Rig(bpm, lead=12, perc=16, perc_k=4, perc_reset=16)
    run_until_perc_shifts(rig, 3)
    gaps = [b[3] - a[3] for a, b in zip(rig.perc_shifts, rig.perc_shifts[1:])]
    check("%d BPM drum RESET 16 on a four-of-sixteen drum: 16 of its steps between gestures"
          % bpm, gaps and all(g == 16 for g in gaps), "gaps %s" % gaps)
    bgaps = [b[0] - a[0] for a, b in zip(rig.perc_shifts, rig.perc_shifts[1:])]
    want = [sum(phrase_step(bar, 16, (s[4] + j) % 16) for j in range(16))
            for s in rig.perc_shifts[:-1]]
    check("%d BPM: each drum gap in blocks is those sixteen of its steps" % bpm,
          bgaps == want, "%d..%d blocks" % (min(bgaps), max(bgaps)))


# ROTATE moves the onsets off step zero, so a rotated drum restarts its phrase on a step
# that may be a rest; the phrase arithmetic is the same either way, and the gesture still
# waits, because the wait is about the tail and not about the onset.
rot = run(Rig(120, lead=12, perc=16, perc_k=6, perc_rot=5, perc_reset=16),
          50 * bar_blocks(120))
rot_idxs = [[i for b, i in rot.hits["perc"] if b == s[0]] for s in rot.perc_shifts]
check("8d a rotated drum restarts on step zero of its phrase, hit or rest",
      bool(rot.perc_shifts) and all(x in ([], [0]) for x in rot_idxs),
      "%d shifts, %d hits" % (len(rot.perc_shifts), len(rot.hits["perc"])))


# --------------------------------------------------------------------------- #
# 9. The synced delay is on the beat, from the same bar                       #
# --------------------------------------------------------------------------- #

print("\n9. THE SYNCED DELAY")
for bpm in (60, 120, 180, 300):
    bar = bar_blocks(bpm)
    check("%d BPM: the delay's bar is the transport's bar (1/1)" % bpm,
          delay_blocks(bpm, 1) == bar, "%d blocks" % bar)

for bpm in (30, 60, 90, 120, 180, 240, 300):
    worst = 0.0
    worst_name = ""
    for div, name in enumerate(DELAY_NAMES):
        if div == 0:
            continue
        d = delay_blocks(bpm, div)
        ideal = delay_ideal(bpm, div)
        err = abs(d - ideal)
        if err > worst:
            worst, worst_name = err, name
        if err > 0.5 + 1e-9:
            check("%d BPM %s: echo within half a block" % (bpm, name), False,
                  "%.3f blocks" % err)
            break
    else:
        check("%d BPM: every division lands within half a block" % bpm, True,
              "worst %s %.3f blocks" % (worst_name, worst))

# The old defect in numbers: the sequencer on a live 140 BPM clock, the delay on the
# 120 BPM knob, at 1/2.
knob = delay_blocks(120, 3)
live = delay_blocks(140, 3)
old_ms = 60000.0 / 120.0 * DELAY_BEATS[3]
new_ms = live * BLOCK_MS
check("clock 140 vs knob 120 at 1/2: the old echo was %.0f ms, the new one %.0f ms" %
      (old_ms, new_ms), abs(old_ms - new_ms) > 20,
      "%.1f%% apart, %d vs %d blocks" %
      (100.0 * abs(old_ms - new_ms) / new_ms, knob, live))


# --------------------------------------------------------------------------- #
# 10. Everything at once, for a hundred bars                                  #
# --------------------------------------------------------------------------- #

print("\n10. ONE LONG RUN WITH EVERYTHING ON")
rig = Rig(120, lead=12, perc=16, perc_k=13, lead_k=12, lead_rot=3,
          perc_rot=5, reset=64, gate=0.85)
run(rig, 100 * bar_blocks(120))
expect_shifts = (100 * 12) // 64
gaps = [b[0] - a[0] for a, b in zip(rig.shifts, rig.shifts[1:])]
check("120 BPM lead 12 drum 16 RESET 64: 18 shifts in 100 bars",
      len(rig.shifts) == expect_shifts, "%d shifts" % len(rig.shifts))
check("the same run: each shift is exactly 64 lead steps after the last",
      all(b[3] - a[3] == 64 for a, b in zip(rig.shifts, rig.shifts[1:])),
      "gaps %s" % gaps[:4])
check("the same run: no lead note retriggered before its gate ends",
      not rig.overlaps, "%d overlaps" % len(rig.overlaps))
check("the same run: every release at its scheduled gate",
      all(r[0] == r[2] for r in rig.releases), "")
base = run(Rig(120, lead=12, perc=16, perc_k=13, lead_k=12, reset=0,
               perc_rot=5, gate=0.85), 100 * bar_blocks(120))
check("the same run: the drum is identical to the run without the gestures",
      rig.hits["perc"] == base.hits["perc"], "%d hits" % len(rig.hits["perc"]))


print()
if FAILURES:
    print("FAILED: %d check(s)" % len(FAILURES))
    for f in FAILURES:
        print("  -", f)
    sys.exit(1)
print("all checks passed")
