"""
FOLLOW and the two key trackers, checked on the desktop.

The drone has its own base pitch — 55 / 110 / 220 Hz for LOW, MID and HIGH — and every mode
starts there. The ROOT knob does not transpose it: the knob names the key (the scale and its
tonic), and the drone is brought into that key through the scale. That is the whole point of
this rework: the base used to BE the knob, so turning ROOT walked the drone by up to seven
octaves in every mode.

The three answers, chosen by DRONE_FOLLOW:

  SCALE  the newest lead note's pitch class in the nearest direction: the interval from the
         base folded into +-6, so the drone lands on a scale degree inside its own register.
         The factory answer, and what a record without the byte gets.
  FULL   the whole signed interval from the base, octaves included: the LOW register lands on
         the played note. The only mode whose shift leaves +-6, and the only one that keeps
         following when nothing is held: the last note the lead STARTED — the sequencer's step
         or the arp's — counts as the note for as long as the transport runs, so the drone
         travels with the music. A key that is still down always wins over it.
  CONS   only a consonance above the base moves it — the unison/octave (class 0), the third
         (3, 4), the fourth (5) and the fifth (7), the fifth folded to -5. On anything else
         the drone stands where it stood; releasing every note clears that memory.

STAY used to be the fourth mode and is gone: the pedal, which the melody could not move. A
record written against the four-position list still carries a byte, and synth_app_patch_apply()
maps it — 0 and 1 to SCALE, 2 to FULL, 3 to CONS, anything else to SCALE — so an old sound is
read as the mode it named rather than as whatever now stands in that position. The map is
mirrored here and checked against positions a four-position knob could produce.

THE UPPER REGISTER'S CEILING. In FULL the whole drone travels with the keyboard. Each register
is halved while it is above DRONE_REGISTER_MAX_HZ (10 kHz), so at C8 the HIGH register lands an
octave below where the arithmetic alone would put it — in unison with MID — instead of at
16.7 kHz, where a drone has no mass. This file checks the rule at the top of the range and, just
as important, that NOTHING below 10 kHz moves: LOW and MID at every note a keyboard can send.

THE TWO KEY TRACKERS, DRONE_KTRCK and LEAD_KTRCK, 0..100 percent, factory 0. The drone's
multiplier is 2^(ktrck · (note − 33)/12), the lead's is 2^(ktrck · (note − 57)/12); A1 and A3
are the two parts' own voiced pitches, so at 0 the cutoff is the knob's number and at 100 it
travels with the pitch octave for octave. Both are checked over the whole travel, including
that 50 percent moves the cutoff by half the octaves and that both ends clamp at the filters'
top of band rather than overflowing the int16 slots.

Mirrors components/synth_app/src/synth_app.cpp: seq_scale_note(), drone_base_class(),
drone_fold(), drone_follow_shift(), drone_follow_from_legacy(), drone_set_pitch() with its
ceiling, drone_filter_track_mult(), lead_filter_track_mult(), drone_cutoff_tracked(),
apply_lead_cutoff(), drone_audible(), with the scale tables, the ranges, the bases and the
constants read out of that file rather than copied here.

WHY IT EXISTS. FOLLOW shipped once with an octave lift over it: whenever the drone's LOW
register fell under 26 Hz the whole drone was transposed up by octaves. The lift was a step
function of the TUNED pitch, so a FOLLOW shift could cross it, and at ROOT = C1 the requests
folded(-4) and unfolded(+8) produced the same 207.65 Hz — the drone hopped by octaves as notes
were played. It was found by ear, not by a gate, which is what this file is for: the numbers
below are what the owner approved, and they are checked without the instrument.

It cannot prove how any of it sounds, and it does not read the display.

Run:   python tools/follow_check.py
       python tools/follow_check.py --log build/boot-follow.log   # also compare a device
                                                                  # capture's followtbl rows
"""

import math
import pathlib
import re
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]

APP = "components/synth_app/src/synth_app.cpp"

FAILURES = []


def check(claim, ok, detail=""):
    print("  %s  %-70s %s" % ("ok  " if ok else "FAIL", claim, detail))
    if not ok:
        FAILURES.append(claim)


def source(rel):
    return (ROOT / rel).read_text(encoding="utf-8")


SRC = source(APP)


def define_int(name):
    m = re.search(r"#define\s+" + name + r"\s+(\d+)\b", SRC)
    if not m:
        raise SystemExit("follow_check: %s not found in %s" % (name, APP))
    return int(m.group(1))


def define_float(name):
    m = re.search(r"#define\s+" + name + r"\s+([0-9.]+)f\b", SRC)
    if not m:
        raise SystemExit("follow_check: %s not found in %s" % (name, APP))
    return float(m.group(1))


def body(name, kind="static"):
    """The text between a function's opening brace and the brace that closes it."""
    m = re.search(r'(?:static|extern\s+"C")\s+[\w:]+\s+' + name + r"\s*\([^)]*\)\s*\{", SRC)
    if not m:
        raise SystemExit("follow_check: %s() not found in %s" % (name, APP))
    start = m.end()
    depth = 1
    i = start
    while i < len(SRC) and depth:
        if SRC[i] == "{":
            depth += 1
        elif SRC[i] == "}":
            depth -= 1
        i += 1
    return SRC[start:i - 1]


# --------------------------------------------------------------------------- #
# What the firmware says                                                      #

ROOT_MIN = define_int("SEQ_ROOT_MIN_MIDI")
ROOT_MAX = define_int("SEQ_ROOT_MAX_MIDI")
LEGACY_MIN = define_int("SEQ_ROOT_LEGACY_MIN_MIDI")
LEGACY_MAX = define_int("SEQ_ROOT_LEGACY_MAX_MIDI")
AUD_SILENT = define_float("DRONE_AUDIBLE_SILENT_HZ")
AUD_FULL = define_float("DRONE_AUDIBLE_FULL_HZ")
REGISTERS = define_int("DRONE_REGISTERS")
BASE_HZ = define_float("DRONE_BASE_HZ")
BASE_MIDI = define_int("DRONE_BASE_MIDI")
TAU = define_float("DRONE_TUNE_TAU_S")
SNAP_ST = define_float("DRONE_TUNE_SNAP_ST")
REG_MAX_HZ = define_float("DRONE_REGISTER_MAX_HZ")
CUTOFF_MIN_HZ = define_float("DRONE_CUTOFF_MIN_HZ")
CUTOFF_MAX_HZ = define_float("DRONE_CUTOFF_MAX_HZ")
CUTOFF_OCTAVES = define_float("CUTOFF_MACRO_OCTAVES")
LEAD_REF_MIDI = define_int("LEAD_KTRCK_REF_MIDI")
LEAD_FC_MIN_HZ = define_float("LEAD_FC_MIN_HZ")
LEAD_FC_MAX_HZ = define_float("LEAD_FC_MAX_HZ")
LEAD_FC_DEFAULT_HZ = define_float("LEAD_FC_DEFAULT_HZ")
LEAD_TRACK_MAX_HZ = define_float("LEAD_CUTOFF_TRACK_MAX_HZ")

# The three drone filters' designed corners, in register order: the cfg->fc_hz column of
# s_drones. Parsed rather than restated.
_DRONES = re.search(r"static const drone_register_cfg_t s_drones\[DRONE_REGISTERS\]"
                    r"\s*=\s*\{(.*?)\n\};", SRC, re.S)
if not _DRONES:
    raise SystemExit("follow_check: s_drones[] not found in %s" % APP)
DRONE_FC = [int(m.group(1)) for m in
            re.finditer(r"SYNTH_LAYER_DRONE_\w+,\s*[0-9.]+f,\s*\{[^}]*\},[^,]+,\s*\d+,\s*"
                        r"(\d+),", _DRONES.group(1))]
if len(DRONE_FC) != REGISTERS:
    raise SystemExit("follow_check: expected %d drone corners, read %s"
                     % (REGISTERS, DRONE_FC))

# Every scale, in the order the parameter stores them: (name, [semitone offsets]).
_STEPS = {}
for m in re.finditer(r"static const int8_t (SEQ_[A-Z0-9_]+)\[\]\s*=\s*\{([^}]*)\}", SRC):
    _STEPS[m.group(1)] = [int(x) for x in re.findall(r"-?\d+", m.group(2))]

SCALES = []
for m in re.finditer(r'\{\s*"([^"]+)",\s*(SEQ_[A-Z0-9_]+),\s*(\d+),', SRC):
    name, sym, length = m.group(1), m.group(2), int(m.group(3))
    steps = _STEPS[sym]
    SCALES.append((name, steps, length))
if not SCALES:
    raise SystemExit("follow_check: no scales found in %s" % APP)

SCALE_STEPS = {name: steps for name, steps, _ in SCALES}

# The modes, in the order the list stores them, read from the enum the firmware compares
# against rather than written out twice.
enum_m = re.search(r"enum\s*\{\s*(DRONE_FOLLOW_SCALE[^}]*)\}", SRC)
if not enum_m:
    raise SystemExit("follow_check: no DRONE_FOLLOW enum in %s" % APP)
MODE_ENUM = re.findall(r"(DRONE_FOLLOW_[A-Z]+)", enum_m.group(1))
MODES = [m.split("_", 2)[2] for m in MODE_ENUM if m != "DRONE_FOLLOW_COUNT"]
if MODES != ["SCALE", "FULL", "CONS"]:
    raise SystemExit("follow_check: unexpected mode list %s" % MODES)


# --------------------------------------------------------------------------- #
# The model                                                                   #

def midi_hz(note):
    return 440.0 * 2.0 ** ((note - 69) / 12.0)


def scale_note(note, root, steps):
    """seq_scale_note(): the nearest degree to the note, a tie taking the lower one."""
    pc = (note - root) % 12
    best, best_abs = 0, 12
    for s in steps:
        d = s - pc
        if d > 6:
            d -= 12
        elif d < -6:
            d += 12
        ad = abs(d)
        if ad < best_abs or (ad == best_abs and d < best):
            best, best_abs = d, ad
    return note + best


def base_class(note, root, steps):
    """drone_base_class(): the quantised note's class against the base, 0..11."""
    return (scale_note(note, root, steps) - BASE_MIDI) % 12


def fold(d):
    """drone_fold(): nearest direction, the tritone upwards."""
    return d - 12 if d > 6 else d


def follow_shift(mode, root, steps, note, memory=None):
    """drone_follow_shift(), with CONS's memory passed in as a one-element list."""
    if note < 0:
        if memory is not None:
            memory[0] = 0
        return 0
    c = base_class(note, root, steps)
    if MODES[mode] == "SCALE":
        return fold(c)
    if MODES[mode] == "FULL":
        return scale_note(note, root, steps) - BASE_MIDI
    if MODES[mode] == "CONS":
        if c in (0, 3, 4, 5, 7):
            if memory is not None:
                memory[0] = fold(c)
        return memory[0] if memory is not None else (fold(c) if c in (0, 3, 4, 5, 7) else 0)
    return 0


def follow_from_legacy(v01):
    """drone_follow_from_legacy(): a four-position byte read as one of these three modes."""
    pos = int(v01 * 3.0 + 0.5)
    if pos < 0 or pos > 3:
        return 0.0
    now = 0 if pos <= 1 else (1 if pos == 2 else 2)
    return now / (len(MODES) - 1)


def drone_hz_raw(shift):
    """drone_set_pitch() before its ceiling: the base transposed, one octave per register."""
    tuned = BASE_HZ * 2.0 ** (shift / 12.0)
    return [tuned * (1 << r) for r in range(REGISTERS)]


def ceiling(hz):
    """The upper register's rule: halve while above DRONE_REGISTER_MAX_HZ."""
    while hz > REG_MAX_HZ:
        hz *= 0.5
    return hz


def drone_hz(shift):
    """drone_set_pitch() as it is: the arithmetic, then the per-register ceiling."""
    return [ceiling(h) for h in drone_hz_raw(shift)]


def drone_track_mult(k, shift):
    """drone_filter_track_mult(): 2^(k · shift/12), the shift measured from A1."""
    return 1.0 if k <= 0.0 else 2.0 ** (k * shift / 12.0)


def lead_track_mult(k, note):
    """lead_filter_track_mult(): 2^(k · (note − A3)/12)."""
    return 1.0 if k <= 0.0 else 2.0 ** (k * (note - LEAD_REF_MIDI) / 12.0)


def cutoff_for(register, v01):
    """cutoff_for(): the designed corner, the macro's exponential travel, clamped."""
    fc = DRONE_FC[register] * 2.0 ** ((v01 - 0.5) * 2.0 * CUTOFF_OCTAVES)
    return min(CUTOFF_MAX_HZ, max(CUTOFF_MIN_HZ, fc))


def drone_cutoff(register, v01, k, shift):
    """drone_cutoff_tracked(): the knob's corner times the tracker, clamped."""
    return min(CUTOFF_MAX_HZ, cutoff_for(register, v01) * drone_track_mult(k, shift))


def lead_fc_for(v01):
    """lead_fc_for(): geometric from 80 Hz to 9 kHz."""
    return LEAD_FC_MIN_HZ * (LEAD_FC_MAX_HZ / LEAD_FC_MIN_HZ) ** v01


def lead_cutoff(v01, k, note):
    """apply_lead_cutoff(): the knob's corner times the tracker, clamped."""
    return min(LEAD_TRACK_MAX_HZ, lead_fc_for(v01) * lead_track_mult(k, note))


def audible(hz):
    """drone_audible(): a register is turned DOWN under the band, never tuned up."""
    if hz >= AUD_FULL:
        return 1.0
    if hz <= AUD_SILENT:
        return 0.0
    return (hz - AUD_SILENT) / (AUD_FULL - AUD_SILENT)


def is_degree(midi_note, root, steps):
    """True when the note is a degree of the scale: quantising it does not move it."""
    return scale_note(midi_note, root, steps) == midi_note


# --------------------------------------------------------------------------- #
# 1. The base                                                                 #

print("\n1. ONE BASE FOR ALL THREE MODES, AND IT IS NOT THE ROOT KNOB")
check("the base is %.2f Hz, LOW of 55/110/220" % BASE_HZ, abs(BASE_HZ - 55.0) < 1e-6,
      "%s" % [round(h, 2) for h in drone_hz(0)])
check("shift 0 tunes the three registers to exactly 55 / 110 / 220 Hz",
      [round(h, 2) for h in drone_hz(0)] == [55.0, 110.0, 220.0], "")
check("the base note is MIDI %d, which is %.2f Hz" % (BASE_MIDI, midi_hz(BASE_MIDI)),
      abs(midi_hz(BASE_MIDI) - BASE_HZ) < 1e-9, "A1")
check("the base is a constant, not a function of the ROOT knob",
      "seq_root_midi" not in body("drone_set_pitch", "static void")
      and "DRONE_BASE_HZ" in body("drone_tune_tick", "static void"),
      "no ROOT in the pitch arithmetic")
check("there is no ROOT-derived base left in the file",
      "s_drone_root_hz" not in SRC and "apply_drone_root" not in SRC, "")

# --------------------------------------------------------------------------- #
# 2. SCALE                                                                    #

ROOTS = (ROOT_MIN, ROOT_MIN + 1, LEGACY_MIN, 57, LEGACY_MAX, ROOT_MAX - 1, ROOT_MAX)
NOTES = (-1, 24, 33, 36, 40, 45, 48, 52, 56, 57, 58, 60, 64, 69, 72, 84, 96, 108)

scale_rows = []
for name, steps, length in SCALES:
    for root in ROOTS:
        for note in NOTES:
            if note < 0:
                continue
            shift = follow_shift(0, root, steps, note)
            scale_rows.append((name, root, steps, note, shift))

print("\n2. SCALE MOVES BY SCALE DEGREES ONLY, INSIDE ONE OCTAVE")
check("every SCALE shift is within +-6 semitones",
      all(abs(r[4]) <= 6 for r in scale_rows),
      "widest %+d" % max(abs(r[4]) for r in scale_rows))
check("every SCALE position is a degree of its scale",
      all(is_degree(BASE_MIDI + r[4], r[1], r[2]) for r in scale_rows), "")
check("SCALE ignores the octave: a note and the same note +12 give the same shift",
      all(follow_shift(0, r[1], r[2], r[3] + 12) == r[4]
          for r in scale_rows if r[3] + 12 <= 127), "")
check("SCALE is the interval from the BASE folded, not from the ROOT",
      all(r[4] == fold(base_class(r[3], r[1], r[2])) for r in scale_rows), "")

# --------------------------------------------------------------------------- #
# 3. FULL                                                                     #

full_rows = []
for name, steps, length in SCALES:
    for root in ROOTS:
        for note in NOTES:
            if note < 0:
                continue
            full_rows.append((name, root, steps, note,
                              follow_shift(1, root, steps, note)))

print("\n3. FULL IS THE WHOLE INTERVAL, OCTAVES INCLUDED")
check("every FULL shift is the signed interval from the base, octaves and all",
      all(r[4] == scale_note(r[3], r[1], r[2]) - BASE_MIDI for r in full_rows), "")
check("an octave of the keyboard is twelve semitones of drone",
      all(follow_shift(1, 57, SCALE_STEPS["MN PNT"], n + 12)
          - follow_shift(1, 57, SCALE_STEPS["MN PNT"], n) == 12
          for n in (33, 45, 57, 69, 81, 93)), "")
exceeding = [r for r in full_rows if abs(r[4]) > 6]
check("FULL does leave +-6 (the mode would be pointless otherwise)",
      bool(exceeding), "widest %+d" % max(abs(r[4]) for r in full_rows))
others = [r for r in scale_rows if abs(r[4]) > 6]
check("and no other mode does: FULL is the only one beyond +-6",
      not others, "SCALE widest %d" % max([abs(r[4]) for r in scale_rows]))

# --------------------------------------------------------------------------- #
# 4. CONS                                                                     #

cons_rows = []
for name, steps, length in SCALES:
    for root in ROOTS:
        for note in NOTES:
            if note < 0:
                continue
            cons_rows.append((name, root, steps, note,
                              follow_shift(2, root, steps, note, [0])))

ALLOWED = {0, 3, 4, 5, -5}
print("\n4. CONS MOVES ONLY ON A CONSONANCE AND STANDS STILL OTHERWISE")
check("no CONS shift outside {0, +3, +4, +5, -5}",
      all(r[4] in ALLOWED for r in cons_rows),
      "shifts seen %s" % sorted({r[4] for r in cons_rows}))
check("a fifth above the base arrives as -5, the same class one octave down",
      all(follow_shift(2, 57, SCALE_STEPS["MN PNT"], 33 + 7, [0]) == -5
          for _ in (0,)), "+7 -> -5")
check("the held position is the last consonance, not the current note",
      all(r[4] == 0 for r in cons_rows
          if base_class(r[3], r[1], r[2]) not in (0, 3, 4, 5, 7)), "")

memory = [0]
legato = [follow_shift(2, 57, SCALE_STEPS["MN PNT"], 60, memory),   # +3, a third
          follow_shift(2, 57, SCALE_STEPS["MN PNT"], 66, memory),   # +6, a tritone
          follow_shift(2, 57, SCALE_STEPS["MN PNT"], 60, memory),   # back to +3
          follow_shift(2, 57, SCALE_STEPS["MN PNT"], -1, memory)]   # released
check("CONS legato: +3, then a tritone leaves it on +3, then release is 0",
      legato == [3, 3, 3, 0], "%s" % legato)

# --------------------------------------------------------------------------- #
# 5. The stored byte from the four-position list                              #

print("\n5. AN OLD FOLLOW BYTE IS READ AS THE MODE IT NAMED")
legacy = [(pos / 3.0, follow_from_legacy(pos / 3.0)) for pos in range(4)]
WANT_LEGACY = [(0.0, 0.0), (1.0 / 3.0, 0.0), (2.0 / 3.0, 0.5), (1.0, 1.0)]
check("STAY 0/3 and SCALE 1/3 both arrive at SCALE (0.0)",
      legacy[0] == WANT_LEGACY[0] and legacy[1] == WANT_LEGACY[1], "%s" % legacy[:2])
check("FULL 2/3 arrives at FULL (0.5) and CONS 3/3 at CONS (1.0)",
      legacy[2] == WANT_LEGACY[2] and legacy[3] == WANT_LEGACY[3], "%s" % legacy[2:])
check("a value outside 0..1 is read as SCALE, never as a mode past the list",
      follow_from_legacy(-1.0) == 0.0 and follow_from_legacy(2.0) == 0.0, "")
check("the new default is SCALE, position 0 of three",
      re.search(r"return \(float\)DRONE_FOLLOW_SCALE / \(float\)\(DRONE_FOLLOW_COUNT - 1\)",
                SRC) is not None, "0/(3-1)")

# --------------------------------------------------------------------------- #
# 6. The pitch arithmetic, the ceiling and the level rule                     #

print("\n6. A SHIFT IS THE SAME NUMBER OF SEMITONES ON EVERY REGISTER")
worst = 0.0
for shift in range(-33, 76):
    raw = drone_hz_raw(shift)
    got = drone_hz(shift)
    for r in range(REGISTERS):
        want = raw[r]
        if want <= REG_MAX_HZ:
            worst = max(worst, abs(12.0 * math.log2(got[r] / want)))
check("every register at or below %.0f Hz is exactly base * 2^(shift/12) * its octave"
      % REG_MAX_HZ, worst < 1e-9, "worst error %.2e semitones" % worst)
check("the smoothing is still the 8 ms pole with a 0.2 cent snap",
      abs(TAU - 0.008) < 1e-9 and abs(SNAP_ST - 0.002) < 1e-9,
      "%.3f s / %.3f st" % (TAU, SNAP_ST))

print("\n7. THE UPPER REGISTER'S CEILING DROPS IT AN OCTAVE, IT DOES NOT FILTER IT")
top_note = 108                                   # C8
top_shift = follow_shift(1, 57, SCALE_STEPS["MN PNT"], top_note)
raw_top = drone_hz_raw(top_shift)
cap_top = drone_hz(top_shift)
print("    C8 (MIDI 108), FULL, ROOT A3: shift %+d semitones" % top_shift)
print("    before the ceiling: %8.2f %8.2f %8.2f Hz" % tuple(raw_top))
print("    after  the ceiling: %8.2f %8.2f %8.2f Hz" % tuple(cap_top))
check("C8's HIGH register is over 10 kHz before the rule and at or under it after",
      raw_top[2] > REG_MAX_HZ and cap_top[2] <= REG_MAX_HZ,
      "%.2f -> %.2f Hz" % (raw_top[2], cap_top[2]))
check("the register that was dropped is EXACTLY one octave lower",
      abs(cap_top[2] - raw_top[2] / 2.0) < 1e-9, "%.2f / 2" % raw_top[2])
check("at C8 HIGH now sounds in unison with MID",
      abs(cap_top[2] - cap_top[1]) < 1e-9, "%.2f Hz" % cap_top[2])
check("nothing below 10 kHz anywhere changes: LOW and MID at C8 are untouched",
      cap_top[0] == raw_top[0] and cap_top[1] == raw_top[1], "")

low_rows = list(range(0, 128))
moved_below = [(n, r) for n in low_rows for r in range(REGISTERS)
               if drone_hz_raw(follow_shift(1, 57, SCALE_STEPS["MN PNT"], n))[r]
               <= REG_MAX_HZ
               and drone_hz(follow_shift(1, 57, SCALE_STEPS["MN PNT"], n))[r]
               != drone_hz_raw(follow_shift(1, 57, SCALE_STEPS["MN PNT"], n))[r]]
check("a register at or below 10 kHz NEVER moves: the ceiling touches only what is above it",
      not moved_below, "%d notes x %d registers checked" % (len(low_rows), REGISTERS))
wrong_halving = []
for n in low_rows:
    shift = follow_shift(1, 57, SCALE_STEPS["MN PNT"], n)
    for r in range(REGISTERS):
        raw, got = drone_hz_raw(shift)[r], drone_hz(shift)[r]
        if raw <= REG_MAX_HZ:
            continue
        ratio = raw / got
        # A whole number of octaves, at least one, and the register lands in the band.
        if ratio < 1.0 - 1e-12 or abs(math.log2(ratio) - round(math.log2(ratio))) > 1e-9:
            wrong_halving.append((n, r, raw, got))
check("every register the ceiling does reach is moved by WHOLE octaves, into the band",
      not wrong_halving, "%d registers moved" % sum(
          1 for n in low_rows for r in range(REGISTERS)
          if drone_hz_raw(follow_shift(1, 57, SCALE_STEPS["MN PNT"], n))[r] > REG_MAX_HZ))
one_octave = [n for n in low_rows for r in range(REGISTERS)
              if drone_hz_raw(follow_shift(1, 57, SCALE_STEPS["MN PNT"], n))[r] > REG_MAX_HZ
              and drone_hz_raw(follow_shift(1, 57, SCALE_STEPS["MN PNT"], n))[r]
              <= 2.0 * REG_MAX_HZ
              and abs(drone_hz_raw(follow_shift(1, 57, SCALE_STEPS["MN PNT"], n))[r]
                      / drone_hz(follow_shift(1, 57, SCALE_STEPS["MN PNT"], n))[r] - 2.0)
              > 1e-9]
check("wherever ONE octave is enough, the register is dropped by exactly one", not one_octave,
      "")
worst_cap = max(drone_hz(follow_shift(1, 57, SCALE_STEPS["MN PNT"], n))[2]
                for n in range(0, 128))
check("no register at any keyboard note is left above the ceiling",
      worst_cap <= REG_MAX_HZ + 1e-9, "highest %.2f Hz" % worst_cap)

print("\n8. UNDER THE AUDIBILITY BAND A REGISTER IS TURNED DOWN, NOT TUNED UP")
check("the band is %.0f..%.0f Hz" % (AUD_SILENT, AUD_FULL),
      0 < AUD_SILENT < AUD_FULL < BASE_HZ, "")
check("at the base, every register is at full level",
      [audible(h) for h in drone_hz(0)] == [1.0, 1.0, 1.0], "")
check("a FULL shift to the bottom of the MIDI range fades LOW out and keeps HIGH",
      audible(drone_hz(-33)[0]) == 0.0 and audible(drone_hz(-33)[1]) < 0.1
      and audible(drone_hz(-33)[2]) == 1.0,
      "%s Hz" % [round(h, 2) for h in drone_hz(-33)])
check("halfway through the band the level is halfway",
      abs((AUD_SILENT + AUD_FULL) / 2.0 - AUD_SILENT) / (AUD_FULL - AUD_SILENT) - 0.5 < 1e-9,
      "")
check("nothing above 22 Hz is attenuated by the rule",
      all(audible(h) == 1.0 for h in drone_hz(0)), "")

# --------------------------------------------------------------------------- #
# 9. The two key trackers                                                     #

print("\n9. K.TRCK DOES NOTHING AT 0, FOLLOWS THE PITCH AT 100 AND HALF OF IT AT 50")
check("the drone's reference is the base, MIDI %d (A1)" % BASE_MIDI,
      "s_drone_tune_st / 12.0f" in body("drone_filter_track_mult", "static float")
      and "SYNTH_PARAM_DRONE_KTRCK" in body("drone_filter_track_mult", "static float"), "")
check("the lead's reference is MIDI %d (A3), the pitch s_lead[] is voiced at"
      % LEAD_REF_MIDI,
      LEAD_REF_MIDI == 57 and "LEAD_KTRCK_REF_MIDI" in
      body("lead_filter_track_mult", "static float"), "220 Hz")

VREST = 0.5                                       # CUTOFF at the designed middle
keys = [(3, 0.0), (3, 0.5), (3, 1.0)]             # ktrck travel, FULL octave at note 45
shift_oct = follow_shift(1, 57, SCALE_STEPS["MN PNT"], 45)   # 45 is A2, +12 from A1
shift_two = follow_shift(1, 57, SCALE_STEPS["MN PNT"], 57)   # +24
print("    drone, CUTOFF at %.0f%% (LOW %.1f Hz), FULL shifts %+d / %+d:"
      % (VREST * 100, cutoff_for(0, VREST), shift_oct, shift_two))
for k in (0.0, 0.5, 1.0):
    a = drone_cutoff(0, VREST, k, shift_oct)
    b = drone_cutoff(0, VREST, k, shift_two)
    print("      K.TRCK %3.0f%%: %+d st -> %8.2f Hz (x%.4f)   %+d st -> %8.2f Hz (x%.4f)"
          % (k * 100, shift_oct, a, a / cutoff_for(0, VREST), shift_two, b,
             b / cutoff_for(0, VREST)))
check("K.TRCK 0 leaves the drone cutoff exactly where the knob put it",
      all(drone_cutoff(r, v, 0.0, s) == cutoff_for(r, v)
          for r in range(REGISTERS) for v in (0.0, 0.5, 1.0) for s in (-33, 0, 12, 63)),
      "bit-identical")
check("K.TRCK 100 moves it octave for octave: a +12 shift doubles the corner, -12 halves it",
      abs(drone_track_mult(1.0, 12) - 2.0) < 1e-12
      and abs(drone_track_mult(1.0, 24) - 4.0) < 1e-12
      and abs(drone_track_mult(1.0, -12) - 0.5) < 1e-12, "2^1, 2^2, 2^-1")
check("K.TRCK 50 moves it half as far in octaves: a +12 shift multiplies by sqrt(2)",
      abs(drone_track_mult(0.5, 12) - math.sqrt(2.0)) < 1e-12,
      "x%.6f" % drone_track_mult(0.5, 12))
check("the drone's tracker clamps at the filter's top of band, never above it",
      drone_cutoff(2, 1.0, 1.0, 63) == CUTOFF_MAX_HZ,
      "%.0f Hz" % drone_cutoff(2, 1.0, 1.0, 63))

print("    lead, CUTOFF at %.0f%% (%.1f Hz), reference A3 (MIDI %d):"
      % (VREST * 100, lead_fc_for(VREST), LEAD_REF_MIDI))
for k in (0.0, 0.5, 1.0):
    lo = lead_cutoff(VREST, k, 45)
    hi = lead_cutoff(VREST, k, 69)
    print("      K.TRCK %3.0f%%: A2 %8.2f Hz (x%.4f)   A4 %8.2f Hz (x%.4f)"
          % (k * 100, lo, lo / lead_fc_for(VREST), hi, hi / lead_fc_for(VREST)))
check("the lead at its reference note A3 is the same corner at every K.TRCK",
      all(lead_cutoff(v, k, 57) == lead_fc_for(v)
          for v in (0.0, 0.5, 0.75, 1.0) for k in (0.0, 0.5, 1.0)),
      "x1.0000")
check("K.TRCK 0 leaves the lead cutoff exactly where the knob put it",
      all(lead_cutoff(v, 0.0, n) == lead_fc_for(v)
          for v in (0.0, 0.5, 1.0) for n in (24, 57, 96)), "bit-identical")
check("K.TRCK 100: A4 doubles the lead corner and A2 halves it",
      abs(lead_track_mult(1.0, 69) - 2.0) < 1e-12
      and abs(lead_track_mult(1.0, 45) - 0.5) < 1e-12, "octave up, octave down")
check("K.TRCK 50: A4 multiplies the lead corner by sqrt(2)",
      abs(lead_track_mult(0.5, 69) - math.sqrt(2.0)) < 1e-12,
      "x%.6f" % lead_track_mult(0.5, 69))
check("the lead's tracker clamps at 16 kHz at the top of the keyboard and cutoff",
      lead_cutoff(1.0, 1.0, 108) == LEAD_TRACK_MAX_HZ,
      "%.0f Hz" % lead_cutoff(1.0, 1.0, 108))
check("the factory of both trackers is 0 percent",
      all(re.search(r"case %s:\s*\n(?:\s*case [A-Z_]+:\s*\n)*\s*return 0\.0f;" % name, SRC)
          is not None
          for name in ("SYNTH_PARAM_DRONE_KTRCK", "SYNTH_PARAM_LEAD_KTRCK")),
      "no tracking")

# --------------------------------------------------------------------------- #
# 10. The source itself                                                       #

print("\n10. THE CODE THE MODEL MIRRORS IS STILL THE CODE IN THE FIRMWARE")
check("drone_base_class() quantises the note first and takes it modulo 12",
      "seq_scale_note(note)" in body("drone_base_class", "static int")
      and "% 12" in body("drone_base_class", "static int"), "")
check("drone_fold() is d > 6 ? d - 12 : d",
      "d > 6 ? d - 12 : d" in body("drone_fold", "static int"), "")
cons_body = body("drone_follow_shift")
check("drone_follow_shift() has all three modes",
      all("DRONE_FOLLOW_" + m in cons_body for m in ("SCALE", "FULL", "CONS")), "")
check("STAY is nowhere in the pitch code",
      "DRONE_FOLLOW_STAY" not in cons_body and "drone_stay_shift" not in SRC, "")
check("FULL returns the un-folded interval",
      "DRONE_BASE_MIDI" in cons_body and "drone_fold" not in
      re.search(r"case DRONE_FOLLOW_FULL:(.*?)case", cons_body, re.S).group(1), "")
check("CONS tests the five upward classes 0, 3, 4, 5, 7",
      re.search(r"c == 0 \|\| c == 3 \|\| c == 4 \|\| c == 5 \|\| c == 7", cons_body)
      is not None, "")
check("drone_tune_tick() asks the mode rather than assuming one",
      "drone_follow_mode()" in body("drone_tune_tick", "static void"), "")
check("drone_tune_tick() takes its note from drone_follow_note()",
      "drone_follow_note()" in body("drone_tune_tick", "static void"), "")
check("FULL follows the generator's last note; SCALE and CONS do not",
      body("drone_follow_note", "static int").count("s_lead_last_note") >= 2
      and "DRONE_FOLLOW_FULL" in body("drone_follow_note", "static int")
      and "DRONE_FOLLOW_SCALE" not in body("drone_follow_note", "static int")
      and "DRONE_FOLLOW_CONS" not in body("drone_follow_note", "static int"),
      "the rule this check exists for")
check("a key that is still down wins over the generator's note",
      body("drone_follow_note", "static int").index("midi_newest_note()")
      < body("drone_follow_note", "static int").index("s_lead_last_note"), "")
check("every lead note passes through lead_group_on(), which records it",
      "s_lead_last_note = track_note;" in body("lead_group_on", "static void"), "")
check("the memory is dropped when the transport stops and nothing is held",
      "s_running" in body("drone_follow_note", "static int")
      and "s_lead_last_note = -1;" in body("drone_follow_note", "static int"), "")
check("the shift is smoothed by the 8 ms pole",
      "DRONE_TUNE_TAU_S" in body("drone_tune_tick", "static void"), "")
check("the tick writes the FIXED base, not the ROOT knob",
      "drone_set_pitch(DRONE_BASE_HZ," in body("drone_tune_tick", "static void"), "")
check("there is NO octave lift on the drone's pitch",
      "drone_low_hz" not in SRC and "DRONE_LOW_FLOOR_HZ" not in SRC,
      "the bug this file exists for")
check("drone_set_pitch() applies the ceiling as a halving loop, not a filter",
      "while (hz > DRONE_REGISTER_MAX_HZ)" in body("drone_set_pitch", "static void")
      and "hz *= 0.5f" in body("drone_set_pitch", "static void"), "")
check("the audibility rule only ever multiplies a register's level",
      "drone_audible(" in body("drone_level_apply", "static void")
      and "synth_rack_set_layer_level(" in body("drone_level_apply", "static void"), "")
check("the list prints SCALE, FULL, CONS in that order",
      re.search(r'modes\[\] = \{ "SCALE", "FULL", "CONS" \}', SRC) is not None, "")
check("the old byte is remapped on load by length, not by a guess",
      "drone_follow_from_legacy" in SRC
      and "follow_legacy_count" in body("synth_app_patch_apply", "static void"), "")
check("both cutoffs go through the tracker",
      "drone_filter_track_mult()" in body("drone_cutoff_tracked", "static int32_t")
      and "lead_filter_track_mult()" in body("apply_lead_cutoff", "static void"), "")
check("the drone's note change republishes its cutoff, once per change and not per block",
      "apply_cutoff(s_param[SYNTH_PARAM_CUTOFF])" in body("drone_tune_tick", "static void")
      and "SYNTH_PARAM_DRONE_KTRCK] > 0.0f" in body("drone_tune_tick", "static void"), "")
check("the lead's note change republishes its cutoff",
      "apply_lead_cutoff(s_param[SYNTH_PARAM_LEAD_CUTOFF])"
      in body("lead_group_on", "static void"), "")

# --------------------------------------------------------------------------- #
# 11. The table                                                               #

print("\n11. THE TABLE  (MIN PENT, ROOT A3 = 57, base A1 = 55 Hz)")
TABLE_NOTES = (24, 33, 56, 57, 58, 60, 69, 108)
steps = SCALE_STEPS["MN PNT"]
rows = []
print("    %-5s %-4s %-3s %-3s  %s" % ("mode", "note", "cls", "st", "LOW/MID/HIGH Hz"))
for mode in range(len(MODES)):
    mem = [0]
    for note in TABLE_NOTES:
        cls = base_class(note, 57, steps)
        shift = follow_shift(mode, 57, steps, note, mem)
        hz = drone_hz(shift)
        rows.append((MODES[mode], note, cls, shift, hz))
        print("    %-5s %-4d %-3d %+3d  %8.2f %8.2f %8.2f" %
              (MODES[mode], note, cls, shift, hz[0], hz[1], hz[2]))

check("the table has %d rows and every mode appears" % len(rows),
      len(rows) == len(MODES) * len(TABLE_NOTES), "")
check("the table's widest SCALE/CONS shift is within +-6",
      max(abs(r[3]) for r in rows if r[0] != "FULL") <= 6, "")
check("the table's FULL shifts span more than an octave",
      max(r[3] for r in rows if r[0] == "FULL") -
      min(r[3] for r in rows if r[0] == "FULL") > 12, "")
check("the base row itself is exactly 55/110/220 Hz",
      [round(h, 2) for h in drone_hz(0)] == [55.0, 110.0, 220.0], "")

# --------------------------------------------------------------------------- #
# 12. An optional device capture                                              #

print("\n12. THE SAME NUMBERS FROM THE DEVICE (optional)")
argv = sys.argv[1:]
capture = None
if "--log" in argv:
    capture = pathlib.Path(argv[argv.index("--log") + 1])
if capture is None:
    check("no capture given: pass --log <boot log with followtbl rows> to compare", True,
          "skipped")
else:
    text = capture.read_text(encoding="utf-8", errors="replace")
    got_rows = re.findall(
        r"followtbl: mode\s+(\w+)\s+root\s+(\d+)\s+scale\s+(.+?)\s+note\s+(-?\d+)\s+"
        r"cls\s+(-?\d+)\s+shift\s+([-+]\d+)\s+"
        r"low\s+([\d.]+)\s+mid\s+([\d.]+)\s+high\s+([\d.]+)", text)
    check("the capture has followtbl rows", bool(got_rows), "%d rows" % len(got_rows))
    if got_rows:
        worst_want, worst_hz = 0.0, 0.0
        # The device prints the scale by name; the tables here know the same names.
        by_name = {name.replace(" ", ""): steps for name, steps, _ in SCALES}
        for mode, root, scale, note, cls, shift, low, mid, high in got_rows:
            root, note, cls, shift = int(root), int(note), int(cls), int(shift)
            if mode not in MODES:
                check("the capture's mode %s is one of %s" % (mode, MODES), False, "old capture?")
                continue
            dev_steps = by_name[scale.replace(" ", "")]
            model = follow_shift(MODES.index(mode), root, dev_steps, note, [0])
            worst_want = max(worst_want, abs(model - shift))
            if note >= 0:
                worst_want = max(worst_want, abs(base_class(note, root, dev_steps) - cls))
            hz = drone_hz(shift)
            worst_hz = max(worst_hz, abs(hz[0] - float(low)) / float(low),
                           abs(hz[1] - float(mid)) / float(mid),
                           abs(hz[2] - float(high)) / float(high))
        check("the mode the device applied is the mode the model asks for, every row",
              worst_want < 0.01, "worst %.3f semitones" % worst_want)
        check("the frequencies the device plays are the shift's arithmetic, every register",
              worst_hz < 1e-3, "worst %.2e relative" % worst_hz)

print()
if FAILURES:
    print("FAILED: %d check(s)" % len(FAILURES))
    for f in FAILURES:
        print("  -", f)
    sys.exit(1)
print("all checks passed")
