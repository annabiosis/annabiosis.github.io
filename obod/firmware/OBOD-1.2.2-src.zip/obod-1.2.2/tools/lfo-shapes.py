"""Проверка фигур LFO: каждая из восьми форм SHAPE должна быть видна.

Зачем. У фигуры модуляции было восемь значений, а обход формы шёл через таблицу волн
осциллятора с другими номерами: SQUARE рисовался пилой, SAW — меандром, RANDOM и MIC
ложились в нулевую линию, EXP+ шёл шумом, EXP- не рисовался вовсе. На экране это
выглядело так, что графика экспоненциальных форм пропала. Ни одна проверка этого не
видела: фигуры рисуются в буфер маски, и в снимках экранов их нет — предпросмотр виден
только пока крутят ручку.

Что здесь проверяется. Только числа: высоты точек, которые pv_lfo() положит в буфер.
Сама отрисовка (штрих, маска, буфер) остаётся непроверенной, но провал, который был,
ловится именно здесь — фигура, у которой все точки на одной высоте.

Почему это зеркало, а не сборка кода. Таблицы PV_SIN, PV_NOISE и PV_MIC_ENV читаются из
самого synth_ui_preview.c, поэтому данные разойтись не могут. Формулы повторены здесь
второй раз — так же, как random-model.js повторяет правила броска из synth_app.cpp, — и
если mod_wave() в synth_app.cpp изменится, эту проверку придётся поправить вместе с
pv_lfo(). Сторож, который молча отстал от кода, хуже отсутствия сторожа, поэтому в
каждом случае ниже назван источник.

Запуск: python tools/lfo-shapes.py
"""

import math
import re
import sys

sys.stdout.reconfigure(encoding='utf-8')

SOURCE = 'components/synth_ui/src/synth_ui_preview.c'
SYNTH = 'components/synth_app/src/synth_app.cpp'

# Поле фигуры: pv_lfo() берёт его из PV_FX0, PV_FX1, PV_FY0, PV_FY1, а те заданы
# через #define в начале файла — оттуда они и читаются.
FIELD = re.compile(r'#define\s+PV_FX0\s+(\d+)\s*\n#define\s+PV_FX1\s+(\d+)')
FIELD_Y = re.compile(r'#define\s+PV_FY0\s+(\d+)\s*\n#define\s+PV_FY1\s+(\d+)')


def read_table(text, name):
    match = re.search(r'static const int\d+_t %s\[\d+\] = \{([^}]*)\}' % name, text)
    if not match:
        raise SystemExit('FAIL: нет таблицы %s в %s' % (name, SOURCE))
    return [int(value) for value in match.group(1).replace('\n', ' ').split(',') if value.strip()]


def tab(table, position):
    """Линейная выборка между точками — так же, как pv_tab() в фигуре."""
    position = max(0.0, min(float(len(table) - 1), position))
    low = int(position)
    high = min(low + 1, len(table) - 1)
    return table[low] + (table[high] - table[low]) * (position - low)


def shape_values(shape, sin_table, noise, mic, steps):
    """Высота фигуры на шаге 0..steps-1, -1..1; то же, что pv_lfo() считает для x.

    Источник каждой строки — switch в pv_lfo() и mod_wave() в synth_app.cpp.
    """
    if shape == 0:                                  # SINE
        return tab(sin_table, steps[1] * 16.0) * 0.01
    if shape == 1:                                  # TRI
        return 4.0 * abs(steps[1] - 0.5) - 1.0
    if shape == 2:                                  # SQUARE
        return 1.0 if steps[1] < 0.5 else -1.0
    if shape == 3:                                  # SAW
        return 1.0 - 2.0 * steps[1]
    if shape == 5:                                  # EXP+
        return -math.exp(-6.0 * (1.0 - steps[1]))
    if shape == 6:                                  # EXP-
        return -math.exp(-6.0 * steps[1])
    if shape == 7:                                  # MIC, 0..1, только вверх
        return tab(mic, steps[1] * 15.0) * 0.01
    raise SystemExit('FAIL: форма %d не разобрана проверкой' % shape)


def main():
    text = open(SOURCE, encoding='utf-8').read()
    synth = open(SYNTH, encoding='utf-8').read()

    field = FIELD.search(text)
    field_y = FIELD_Y.search(text)
    if not field or not field_y:
        raise SystemExit('FAIL: не найдено поле фигуры в %s' % SOURCE)

    x0, x1 = int(field.group(1)), int(field.group(2))
    y0, y1 = int(field_y.group(1)), int(field_y.group(2))
    middle = (y0 + y1) // 2
    amp = (y1 - y0) // 2

    sin_table = read_table(text, 'PV_SIN')
    noise = read_table(text, 'PV_NOISE')
    mic = read_table(text, 'PV_MIC_ENV')

    names = ['SINE', 'TRI', 'SQUARE', 'SAW', 'RANDOM', 'EXP+', 'EXP-', 'MIC']

    # Имена и порядок — из списка режимов LFO в synth_app.cpp, а не из головы:
    # если список переставят, проверка скажет об этом, а не проверит не то.
    match = re.search(r'"SINE",\s*"TRI",\s*"SQUARE",\s*"SAW",\s*"RANDOM",\s*"EXP\+",\s*"EXP-",\s*"MIC"', synth)
    if not match:
        raise SystemExit('FAIL: список форм LFO в %s не тот, что ждёт проверка' % SYNTH)

    problems = []
    print('форма    размах  доля поля  направление')
    for shape, name in enumerate(names):
        heights = []
        hold = 0
        held = 0.0
        for index in range(x1 - x0 + 1):
            phase = index / float(x1 - x0)
            if shape == 4:                          # RANDOM: новое значение раз в пять колонок
                if hold == 0:
                    hold = 5
                    held = noise[(index // 5) % len(noise)] * 0.01
                hold -= 1
                value = held
            else:
                value = shape_values(shape, sin_table, noise, mic, (phase, phase))
            heights.append(round(middle - value * amp))

        span = max(heights) - min(heights)
        share = span / float(2 * amp)
        lowest, highest = max(heights), min(heights)
        side = []
        if lowest > middle:
            side.append('вниз')
        if highest < middle:
            side.append('вверх')
        if not side:
            side.append('в обе стороны')

        print('%-8s %6d  %9.2f  %s' % (name, span, share, ' и '.join(side)))

        if span < 4:
            problems.append('%s: размах %d точки — фигура ложится в линию' % (name, span))
        if share > 1.02:
            problems.append('%s: размах больше поля (%.2f)' % (name, share))
        # Высота точки — координата, а не значение: меньше значит выше. EXP и MIC
        # односторонние, поэтому EXP не должен подниматься выше центра, а MIC — ниже.
        if shape in (5, 6) and min(heights) < middle - 1:
            problems.append('%s: EXP заходит выше центра, а mod_wave() отдаёт -1..0' % name)
        if shape == 7 and max(heights) > middle + 1:
            problems.append('%s: MIC заходит ниже центра, а огибающая идёт 0..1' % name)

    if problems:
        print('FAIL: фигуры форм LFO разошлись с mod_wave()')
        for problem in problems:
            print('  - ' + problem)
        sys.exit(1)

    print('OK: все восемь форм LFO рисуются, край и направление совпадают с mod_wave()')


if __name__ == '__main__':
    main()
