<#
.SYNOPSIS
    Read the last reset, the event trail and the core dump from the board.

.DESCRIPTION
    The firmware keeps three traces for a reset that no one watched:

      * the reset reason, printed by the application as its first log line;
      * the last actions before the reset, kept in RTC memory and printed on
        the next boot;
      * a core dump in the `coredump` flash partition, written by the panic
        handler.

    This script captures a boot log from the board, then asks `esp_coredump`
    to decode the dump with the ELF from build/.  If there is no dump it says so
    and shows the reset reason instead.  Everything goes to
    build/crash-<date>.txt so the answer survives the terminal.

.EXAMPLE
    pwsh -File tools/crash.ps1
    pwsh -File tools/crash.ps1 -Port COM4 -Seconds 20
    pwsh -File tools/crash.ps1 -NoReset
#>
param(
    [string] $Port    = 'COM4',
    [int]    $Seconds = 15,
    [string] $OutDir  = 'build',
    [switch] $NoReset
)

$ErrorActionPreference = 'Stop'

. (Join-Path $PSScriptRoot '_idf_env.ps1')
$repoRoot = Get-RepoRoot
$idfPath  = Initialize-IdfEnvironment -RepoRoot $repoRoot
if (-not $idfPath) { exit 3 }

if (-not [System.IO.Path]::IsPathRooted($OutDir)) {
    $OutDir = Join-Path $repoRoot $OutDir
}
if (-not (Test-Path -LiteralPath $OutDir)) {
    New-Item -ItemType Directory -Path $OutDir -Force | Out-Null
}

$stamp      = Get-Date -Format 'yyyy-MM-dd_HH-mm-ss'
$logPath    = Join-Path $OutDir "crash-$stamp.log"
$reportPath = Join-Path $OutDir "crash-$stamp.txt"

# ---------------------------------------------------------------------------
# 1. Boot log.  capture_boot.ps1 already knows how this board's USB-Serial-
# JTAG behaves around a reset, so the reset is left to it.
# ---------------------------------------------------------------------------

Write-Host "==> 1/3 boot log from $Port ($Seconds s)" -ForegroundColor Cyan

$captureArgs = @(
    '-NoProfile',
    '-File', (Join-Path $PSScriptRoot 'capture_boot.ps1'),
    '-Port', $Port,
    '-Seconds', "$Seconds",
    '-OutFile', $logPath
)
if ($NoReset) { $captureArgs += '-NoReset' }

& pwsh @captureArgs
if ($LASTEXITCODE -ne 0) {
    Write-Host "ERROR: could not read $Port" -ForegroundColor Red
    exit $LASTEXITCODE
}

$bootText = ''
if (Test-Path -LiteralPath $logPath) {
    $bootText = Get-Content -LiteralPath $logPath -Raw
}

$reasonMatch = [regex]::Match($bootText, 'reset reason:\s*(\d+)\s*\(([^)]+)\)')
if ($reasonMatch.Success) {
    $resetReason = "$($reasonMatch.Groups[1].Value) ($($reasonMatch.Groups[2].Value))"
} else {
    $resetReason = 'not found in the captured log'
}

# The panic handler records how many bytes it wrote; the coredump component
# reports them again at the next boot. This is evidence from the device, not a
# guess based on the reset reason alone.
$dumpInBoot = [regex]::Match($bootText, 'Found core dump\s+(\d+)\s+bytes in flash')
$dumpSize   = if ($dumpInBoot.Success) { [int]$dumpInBoot.Groups[1].Value } else { 0 }

# ---------------------------------------------------------------------------
# 2. Core dump.  idf.py needs the ELF that produced the image; a dump decoded
# against another build has addresses but no trustworthy function names.
# ---------------------------------------------------------------------------

Write-Host "==> 2/3 core dump from flash" -ForegroundColor Cyan

$elfPath = Join-Path $repoRoot 'build\guition_knob.elf'
$dumpText = ''
$dumpOk = $false

# Read the partition table instead of hard-coding an offset: it is the same file
# the flasher used, and a layout change must not turn into a wrong read.
$coreOffset = $null
$partBin = Join-Path $repoRoot 'build\partition_table\partition-table.bin'
$partTool = Join-Path $idfPath 'components\partition_table\gen_esp32part.py'
if (Test-Path -LiteralPath $partBin) {
    $partText = (& python $partTool $partBin 2>&1 | Out-String)
    $partMatch = [regex]::Match($partText, '(?m)^coredump,data,coredump,0x([0-9A-Fa-f]+),')
    if ($partMatch.Success) {
        $coreOffset = '0x' + $partMatch.Groups[1].Value
    }
}

if (-not (Test-Path -LiteralPath $elfPath)) {
    $dumpText = "No ELF at $elfPath. Build the firmware first."
}
elseif (-not $coreOffset) {
    $dumpText = "No coredump partition in $partBin. The image on the board has no place for a dump."
}
else {
    # esp_coredump reads the partition itself. Going through `idf.py` would run
    # a build first, and a tree that has moved since the image was flashed would
    # replace the ELF the dump must be decoded against.
    Push-Location $repoRoot
    try {
        $dumpText = (& python -m esp_coredump --chip esp32s3 --port $Port `
                        info_corefile $elfPath --off $coreOffset 2>&1 | Out-String)
    }
    finally {
        Pop-Location
    }

    $dumpOk = ($dumpText -match 'CORE DUMP START|Crashed task handle:') -and
              ($dumpText -notmatch 'Failed to load core dump|No core dump|Incorrect size of core dump|does not contain')
}

$taskLines  = @()
$stackLines = @()
if ($dumpOk) {
    $taskLines = @([regex]::Matches($dumpText, '(?m)^.*Crashed task.*$') |
                   ForEach-Object { $_.Value.Trim() })
    $stackLines = @([regex]::Matches($dumpText, '(?m)^\s*#\d+\s+.*$') |
                    ForEach-Object { $_.Value.Trim() })
}

# The decoder occasionally gets an empty task name from the TCB even though the
# stack is complete. The frames still name the task through its entry point, so
# say that rather than printing an empty name as if it were an answer.
$nameMissing = @($taskLines | Where-Object { $_ -match "name: ''" }).Count -gt 0
$entryFrame = $null
if ($nameMissing -and $stackLines.Count -ge 2) {
    $entryFrame = $stackLines[$stackLines.Count - 2]
}

# Drop the tool's environment banner: the report is about the board, not about
# the terminal the command happened to run in.
$dumpBody = $dumpText
$coreStart = $dumpText.IndexOf('==================== ESP32 CORE DUMP START')
if ($coreStart -ge 0) {
    $dumpBody = $dumpText.Substring($coreStart)
}

# ---------------------------------------------------------------------------
# 3. Report.  The whole boot log is kept as well: the reset reason and the
# event ring are in it, and the lines around the panic explain what led there.
# ---------------------------------------------------------------------------

$report = New-Object System.Collections.Generic.List[string]
$report.Add('OBOD crash report')
$report.Add('generated : ' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
$report.Add('port      : ' + $Port)
$report.Add('boot log  : ' + $logPath)
$report.Add('')
$report.Add('== Reset reason ==')
$report.Add('reset reason : ' + $resetReason)
if ($dumpSize -gt 0) {
    $report.Add("core dump    : $dumpSize bytes in flash")
} else {
    $report.Add('core dump    : no dump reported by the firmware at boot')
}
$report.Add('')
$report.Add('== Core dump ==')
if ($dumpOk) {
    $report.Add($dumpBody.Trim())
    if ($nameMissing) {
        $report.Add('')
        $report.Add('Note: the dump does not carry a task name; the stack frames name it.')
        if ($entryFrame) {
            $report.Add('Task entry: ' + $entryFrame)
        }
    }
} else {
    $report.Add('No readable core dump.')
    $report.Add('')
    $report.Add($dumpBody.Trim())
}
$report.Add('')
$report.Add('== Boot log ==')
$report.Add($bootText.Trim())

Set-Content -LiteralPath $reportPath -Value ($report -join "`r`n") -Encoding UTF8

# ---------------------------------------------------------------------------
# 4. Human summary.  A dump is only useful if the crashed task and the stack
# frames are visible without opening the report first.
# ---------------------------------------------------------------------------

Write-Host ''
if ($dumpOk) {
    Write-Host '==> core dump found' -ForegroundColor Green
    foreach ($line in $taskLines) {
        Write-Host "    $line"
    }
    if ($nameMissing) {
        Write-Host '    (the dump has no task name; the stack frames below name the task)'
        if ($entryFrame) {
            Write-Host "    task entry: $entryFrame"
        }
    }
    if ($stackLines.Count -eq 0) {
        Write-Host '    (the dump has no resolved stack frames)'
    } else {
        Write-Host '    stack:'
        foreach ($line in $stackLines) {
            Write-Host "      $line"
        }
    }
} else {
    if ($dumpSize -gt 0) {
        Write-Host "==> core dump present ($dumpSize bytes) but could not be decoded" -ForegroundColor Yellow
        Write-Host "    reset reason: $resetReason"
        Write-Host '    build/guition_knob.elf does not match the image on the board'
    } else {
        Write-Host '==> no core dump' -ForegroundColor Yellow
        Write-Host "    reset reason: $resetReason"
        if ($resetReason -match 'panic|abort') {
            Write-Host '    the reset was a panic, but the dump could not be read;'
            Write-Host '    check that build/guition_knob.elf matches the image on the board'
        }
    }
}

Write-Host ''
Write-Host "report: $reportPath" -ForegroundColor Cyan
