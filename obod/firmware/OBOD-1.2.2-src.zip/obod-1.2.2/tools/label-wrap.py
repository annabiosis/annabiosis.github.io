# -*- coding: utf-8 -*-
"""Надписи с экрана прибора — в рамку (класс .lab)."""
import io, re, sys, glob
sys.stdout.reconfigure(encoding="utf-8")

WORDS = """
ACCENT ATTACK CHORUS COMP CUTOFF DAMP DECAY DENSITY DEPTH DEST DIR DRAWER DRONE DUCK ENV
FDBK FILL FOLLOW GATE GROOVE HIGH K.TRCK KIT LEAD LEN LEVELS LFO LOAD LOW MACRO MASTER MIC MID
MIX MODE MORPH NOTE OCT OCTAVE ONES OPTIONS OSC PAN PARAM PATCH PERC PITCH PORTA PRESET
PULSES PUNCH QUANT RANDOM RANGE RATE RELEASE RES RESET REVERB RING RMB RND ROTATE SAVE SCALE
SCATTER SCREEN SHAPE SIZE SLIDE SPEED STEPS SUSTAIN SWING SYNC SYSTEM TEMPO TIMBRE TIME TONE
TRANSPORT TRIG TUNE VAR VOICE VOL WIDTH FREE FULL CONS FORGET HOLD SKIP STORE
""".split()

PAIRS = ["CHR SENDS", "DEL SENDS", "DRONE FLTR", "FILT+LEAD", "FILT+PAN", "FILT+PERC",
         "LEAD ARP", "LEAD ENV", "LEAD EUCLID", "LEAD SCALE", "LEAD TONE", "LEAD+PAN",
         "LEAD+PERC", "LEAD+PNCH", "MACRO INV", "MACRO 10", "MIDI IN", "PAN+PNCH",
         "PERC PIT", "PERC SEQ", "PIT+DEC", "PIT+E+D", "PIT+ENV", "PUNCH+DEC", "PUNCH+PIT",
         "REV SENDS", "RING FX", "RND DEL", "WEAK VEL", "H.OSC", "L.OSC", "M.OSC"]

ALL = sorted(set(WORDS) | set(PAIRS), key=len, reverse=True)
def alt(lab):
    return r"\s+".join(re.escape(w) for w in lab.split(" "))
PATTERN = re.compile(r"(?<![\w+&./-])(" + "|".join(alt(x) for x in ALL) + r")(?![\w+&./-])")
SKIP = ("code", "pre", "a", "b", "strong", "h1", "h2", "h3", "h4", "title", "script", "style", "textarea")

def wrap_text(t):
    return PATTERN.sub(lambda m: '<span class="lab">%s</span>' % m.group(1), t)

TOKEN = re.compile(r"<!--.*?-->|<[^>]*>", re.S)

def process(t):
    out, pos, depth = [], 0, 0
    for m in TOKEN.finditer(t):
        text = t[pos:m.start()]
        if text:
            out.append(wrap_text(text) if depth == 0 else text)
        tag = m.group(0)
        if tag.startswith("<!--"):
            out.append(tag)                      # комментарий не трогаем и внутрь не смотрим
            pos = m.end()
            continue
        mm = re.match(r"</?\s*([a-zA-Z0-9]+)", tag)
        nm = (mm.group(1).lower() if mm else "")
        skip = nm in SKIP or 'class="lab"' in tag
        selfclosed = tag.endswith("/>") or nm in ("br", "hr", "img", "meta", "link", "input")
        if skip and not selfclosed:
            depth = max(0, depth - 1) if tag.startswith("</") else depth + 1
        out.append(tag)
        pos = m.end()
    tail = t[pos:]
    if tail:
        out.append(wrap_text(tail) if depth == 0 else tail)
    return "".join(out)

total = 0
for p in sorted(glob.glob("web/*.html")):
    t = io.open(p, encoding="utf-8", newline="").read()
    t2 = process(t)
    n = t2.count('<span class="lab">')
    io.open(p, "w", encoding="utf-8", newline="").write(t2)
    total += n
    print("%-24s %4d" % (p, n))
print("всего:", total)
