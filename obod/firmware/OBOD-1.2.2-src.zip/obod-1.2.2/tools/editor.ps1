<#
    Редактор текстов страниц OBOD.

    Поднимает сервер на 127.0.0.1 и открывает браузер: список страниц набора, тексты по
    блокам, предпросмотр, проверки и публикация. Сервер живёт, пока открыто это окно;
    Ctrl+C его останавливает.

    Порт задаётся переменной окружения OBOD_EDITOR_PORT, по умолчанию 8787.
#>
$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $PSScriptRoot
$port = if ($env:OBOD_EDITOR_PORT) { $env:OBOD_EDITOR_PORT } else { '8787' }
$url = "http://127.0.0.1:$port/"

$node = (Get-Command node -ErrorAction SilentlyContinue)
if (-not $node) {
  Write-Host 'Не найден node: редактор работает на нём, как и проверки набора.'
  exit 1
}

Write-Host "Редактор текстов OBOD: $url"
Write-Host 'Остановить — Ctrl+C.'

# Браузер открывает отдельный процесс: это окно остаётся за сервером.
Start-Process pwsh -ArgumentList '-NoProfile', '-Command', "Start-Sleep -Seconds 2; Start-Process '$url'" -WindowStyle Hidden

Push-Location $root
try {
  & $node.Source 'tools\editor\server.js'
} finally {
  Pop-Location
}
