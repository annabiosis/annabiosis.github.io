"""
A one-to-one port of the percussion voice's per-sample loop, to check the numbers
before they cost a build and a flash.

Mirrors synth_perc.cpp: the same mappings, the same trapezoidal SVF, the same gate, and
the same 150 ms cap on how long the centre may take to fall. It rebuilds the coefficients
on every sample rather than on the module's PERC_COEFF_STEP, so its peaks are the
continuous-sweep ideal the instrument only approaches.
Answers three questions:
  1. does a hit make a sound at all, and is it bounded?
  2. does the gate reach -60 dB in the time DECAY promises?
  3. is the filter stable at the extremes of both knobs?
"""

import math

SR = 48000

PERC_DECAY_MIN_MS = 20.0
PERC_DECAY_SPAN = 6.2288
PERC_PITCH_MIN_HZ = 35.0
PERC_PITCH_OCTAVES = 7.65
PERC_Q_MIN = 0.7
PERC_Q_SPAN = 4.43
PERC_ENV_MAX_OCT = 5.0
PERC_ENV_FALL_MAX_MS = 150.0
PERC_ATTACK_MS = 1.0
PERC_TAIL = 1.0e-3
PERC_TAU_SCALE = 0.14476
PERC_GAIN = 64.0


def pitch_hz(v):
    return PERC_PITCH_MIN_HZ * 2.0 ** (v * PERC_PITCH_OCTAVES)


def decay_ms(v):
    return PERC_DECAY_MIN_MS * 2.0 ** (v * PERC_DECAY_SPAN)


def env_octaves(v):
    return v * PERC_ENV_MAX_OCT


def coeffs(fc, q):
    fc = max(20.0, min(fc, SR * 0.45))
    q = max(0.3, q)
    g = math.tan(math.pi * fc / SR)
    k = 1.0 / q
    a1 = 1.0 / (1.0 + g * (g + k))
    return k, a1, g * a1, g * g * a1


class Noise:
    def __init__(self, seed):
        self.s = seed

    def next(self):
        x = self.s
        x ^= (x << 13) & 0xFFFFFFFF
        x ^= x >> 17
        x ^= (x << 5) & 0xFFFFFFFF
        self.s = x & 0xFFFFFFFF
        return (x >> 8) * (1.0 / 8388608.0) - 1.0


def hit(pitch01, reso01, decay01, env01, level01=1.0, seconds=2.0):
    ph = pitch_hz(pitch01)
    q = PERC_Q_MIN * 2.0 ** (reso01 * PERC_Q_SPAN)
    eo = env_octaves(env01)
    tau = decay_ms(decay01) * 0.001 * SR * PERC_TAU_SCALE
    amp_coeff = math.exp(-1.0 / max(tau, 1.0))
    # The centre's fall is capped at 150 ms whatever the gate says, the same min() the C
    # does; without it this port let a 1.5 s gate glide the centre down for a second and a
    # half, which is the tom bend PERC_ENV_FALL_MAX_MS exists to prevent.
    tau_fall = min(tau, PERC_ENV_FALL_MAX_MS * 0.001 * SR * PERC_TAU_SCALE)
    env_coeff = math.exp(-1.0 / max(tau_fall, 1.0))
    gain = PERC_GAIN * math.sqrt(q / ph)

    k, a1, a2, a3 = coeffs(ph, q)

    amp = 0.0
    attack_left = max(1, int(SR * PERC_ATTACK_MS * 0.001 + 0.5))
    attack_step = 1.0 / attack_left
    env = 1.0
    ic1 = [0.0, 0.0]
    ic2 = [0.0, 0.0]
    nl = Noise(0x9E3779B9)
    nr = Noise(0xC2B2AE35)

    peak = 0.0
    rms_acc = 0.0
    n = int(seconds * SR)
    tail_at = None

    for i in range(n):
        if attack_left > 0:
            attack_left -= 1
            amp = min(1.0, amp + attack_step)
        else:
            amp *= amp_coeff
            if amp < PERC_TAIL:
                tail_at = i
                break

        if env > PERC_TAIL:
            env *= env_coeff
            k, a1, a2, a3 = coeffs(ph * 2.0 ** (eo * env), q)

        out = []
        for c, gen in enumerate((nl, nr)):
            x = gen.next()
            v3 = x - ic2[c]
            v1 = a1 * ic1[c] + a2 * v3
            v2 = ic2[c] + a2 * ic1[c] + a3 * v3
            ic1[c] = 2.0 * v1 - ic1[c]
            ic2[c] = 2.0 * v2 - ic2[c]
            out.append(k * v1)

        s = 0.5 * (out[0] + out[1]) * amp * level01 * gain
        peak = max(peak, abs(s))
        rms_acc += s * s

        if not math.isfinite(s) or abs(s) > 50.0:
            return dict(blown=True, i=i, pitch=ph, q=q)

    return dict(
        blown=False,
        pitch=ph,
        q=q,
        peak=peak,
        rms=math.sqrt(rms_acc / n),
        tail_ms=(tail_at / SR * 1000.0) if tail_at else None,
        asked_ms=decay_ms(decay01),
    )


print("mappings")
for v in (0.0, 0.3415, 0.5, 1.0):
    print(f"  pitch {v:.2f} -> {pitch_hz(v):8.1f} Hz    decay {v:.2f} -> {decay_ms(v):8.1f} ms"
          f"    env {v:.2f} -> {env_octaves(v):.2f} oct")

print("\nthe default tom, and the extremes")
cases = [
    ("default tom   ", 0.3415, 0.35, 0.35, 0.27),
    ("lowest kick   ", 0.00, 0.10, 0.80, 0.20),
    ("highest hat   ", 1.00, 0.60, 0.05, 0.00),
    ("max resonance ", 0.50, 1.00, 0.50, 0.50),
    ("max env, long ", 0.40, 0.50, 1.00, 1.00),
]
for name, p, r, d, e in cases:
    out = hit(p, r, d, e)
    if out["blown"]:
        print(f"  {name} BLOWN UP at sample {out['i']} (pitch {out['pitch']:.0f}, Q {out['q']:.1f})")
    else:
        tail = f"{out['tail_ms']:.0f} ms" if out["tail_ms"] else "no tail reached"
        print(f"  {name} peak {out['peak']:.3f}  rms {out['rms']:.4f}  "
              f"pitch {out['pitch']:7.0f} Hz  Q {out['q']:5.2f}  "
              f"tail {tail:>14s} (asked {out['asked_ms']:.0f} ms)")
