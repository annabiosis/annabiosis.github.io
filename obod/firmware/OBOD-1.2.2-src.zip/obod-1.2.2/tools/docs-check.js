/*
 * Проверка пар документов: русский текст и его английский перевод.
 *
 * Переводы живут рядом с оригиналами: README.md и README.en.md,
 * docs/RELEASE-NOTES.md и docs/RELEASE-NOTES.en.md. Сверить построчно два языка нельзя,
 * но можно сверить то, что от языка не зависит и теряется при правке оригинала без
 * правки перевода:
 *
 *   - рисунок заголовков: их число и последовательность уровней;
 *   - ссылки: набор целей, у английских целей снят суффикс .en;
 *   - картинки: их пути обязаны совпадать полностью, набор картинок общий;
 *   - блоки кода: их число;
 *   - строка-оговорка в конце перевода: русский текст основной.
 *
 * Оригинал при этом считается основным: если разошлись, прав перевод, а не оригинал,
 * но проверка об этом и сообщает, чтобы расхождение было видно до коммита.
 *
 * Запуск: node tools/docs-check.js
 */
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');

/*
 * Пары: основной текст и перевод.
 *
 * docs/HARDWARE.md сюда не входит: он написан по-английски с самого начала, переводить
 * его не на что, и перевод ему не нужен.
 */
const PAIRS = [
  ['README.md', 'README.en.md'],
  ['FEATURES.md', 'FEATURES.en.md'],
  ['docs/RELEASE-NOTES.md', 'docs/RELEASE-NOTES.en.md'],
  ['docs/TROUBLESHOOTING.md', 'docs/TROUBLESHOOTING.en.md'],
];

const SOURCE_LINE = 'is the source; if the two diverge, the Russian one is right.';

const problems = [];

function check(ok, where, message) {
  if (!ok) { problems.push(where + ': ' + message); }
}

function read(relative) {
  const full = path.join(root, relative);
  return fs.existsSync(full) ? fs.readFileSync(full, 'utf8') : null;
}

/* Рисунок заголовков: только уровни, без текста. Заголовки внутри блоков кода не в счёт. */
function outline(text) {
  const levels = [];
  let fenced = false;
  for (const line of text.split('\n')) {
    if (/^\s*```/.test(line)) { fenced = !fenced; continue; }
    if (fenced) { continue; }
    const m = line.match(/^(#{1,6})\s+\S/);
    if (m) { levels.push(m[1].length); }
  }
  return levels;
}

/* Цели ссылок и картинок. У английской цели снят суффикс .en: он и есть отличие. */
function targets(text) {
  const links = [];
  const images = [];
  for (const m of text.matchAll(/!?\[[^\]]*\]\(([^)\s]+)\)/g)) {
    const isImage = m[0].startsWith('!');
    const target = m[1].replace(/\.en\.md(#.*)?$/, '.md$1');
    (isImage ? images : links).push(target);
  }
  return { links, images };
}

function fences(text) {
  return (text.match(/^\s*```/gm) || []).length;
}

for (const [mainFile, enFile] of PAIRS) {
  const main = read(mainFile);
  const en = read(enFile);

  if (main === null) { check(false, mainFile, 'файла нет'); continue; }
  if (en === null) { check(false, enFile, 'перевода нет'); continue; }

  const a = outline(main);
  const b = outline(en);
  check(a.length === b.length, enFile,
        'заголовков ' + b.length + ', в оригинале ' + a.length);
  check(a.join(',') === b.join(','), enFile,
        'рисунок заголовков не совпадает: ' + b.join(',') + ' против ' + a.join(','));

  const ta = targets(main);
  const tb = targets(en);

  const missing = ta.links.filter((x) => tb.links.indexOf(x) < 0);
  const extra = tb.links.filter((x) => ta.links.indexOf(x) < 0);
  check(missing.length === 0, enFile, 'нет ссылок из оригинала: ' + missing.join(', '));
  check(extra.length === 0, enFile, 'лишние ссылки: ' + extra.join(', '));

  const imgMissing = ta.images.filter((x) => tb.images.indexOf(x) < 0);
  const imgExtra = tb.images.filter((x) => ta.images.indexOf(x) < 0);
  check(imgMissing.length === 0, enFile, 'нет картинок из оригинала: ' + imgMissing.join(', '));
  check(imgExtra.length === 0, enFile, 'лишние картинки: ' + imgExtra.join(', '));

  check(fences(main) === fences(en), enFile,
        'блоков кода ' + fences(en) + ', в оригинале ' + fences(main));

  check(en.indexOf(SOURCE_LINE) >= 0, enFile, 'нет строки о том, что русский текст основной');
  check(en.indexOf(mainFile.split('/').pop()) >= 0, enFile,
        'нет ссылки на оригинал');

  check(main.indexOf(enFile.split('/').pop()) >= 0, mainFile,
        'в оригинале нет ссылки на перевод');
}

if (problems.length) {
  console.log('НЕ ПРОШЛО, ' + problems.length + ':');
  problems.forEach((p) => console.log('  ' + p));
  process.exit(1);
}

console.log('OK: ' + PAIRS.length + ' пар документов сходятся по заголовкам, ссылкам, ' +
            'картинкам и блокам кода');
