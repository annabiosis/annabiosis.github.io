<#
.SYNOPSIS
    Запечатывает образ прошивки паролем выпуска.

.DESCRIPTION
    Берёт tools/webflash/firmware/OBOD.bin и кладёт рядом OBOD.bin.enc — тот же образ,
    зашифрованный AES-256-GCM ключом, выведенным из кода выпуска (PBKDF2-SHA256).
    Рядом появляется lock.json с параметрами замка: соль, вектор, число итераций,
    размер и хеш открытого образа, размер и хеш запечатанного файла.

    Зачем. Образ лежит на публичном сайте, и страница записи отдаёт его в прибор.
    Пока рядом с ней лежал открытый .bin, прошивку можно было забрать одной командой
    curl. Теперь скачивается только замок, а страница расшифровывает образ в браузере
    после того, как введён код выпуска; код один на выпуск и живёт в посте Boosty.

    ПОЧЕМУ GCM, А НЕ ПРОСТО AES-CTR: GCM проверяет целостность на каждом байте и не
    отдаёт ничего, пока не сойдётся тег. Подменённый или обрезанный файл не расшифруется
    в мусор, который потом уйдёт в прибор, — он не расшифруется вовсе.

    ЧЕСТНО О СИЛЕ ЗАМКА. Замок крепок ровно настолько, насколько крепок код выпуска:
    PBKDF2 с тремястами тысячами итераций удорожает перебор, но код из восьми знаков
    перебирается и так. Код выпуска — не короче двадцати знаков, лучше — фраза из
    нескольких слов: её и набирать легче, и перебирать дольше.

    Скрипт ничего не собирает и не читает CHANGELOG: он берёт уже собранный образ.

.PARAMETER Code
    Код выпуска. Обязательный: без кода замка не бывает.

.PARAMETER Version
    Номер выпуска, который попадёт в lock.json. По умолчанию берётся из manifest.json.

.PARAMETER Iterations
    Число итераций PBKDF2. По умолчанию 310 000. Менять только вместе с пониманием:
    страница берёт число из lock.json, а не из своего кода.

.PARAMETER Image
    Открытый образ. По умолчанию tools/webflash/firmware/OBOD.bin.

.PARAMETER Check
    Только проверить: расшифровать замок тем же кодом и сверить хеши с открытым образом.
    Ничего не пишет. Этим же ключом проверяется выпуск после упаковки.

.EXAMPLE
    pwsh -File tools/webflash/seal.ps1 -Code 'obod-1.2.2-...' -Version 1.2.2
    pwsh -File tools/webflash/seal.ps1 -Code 'obod-1.2.2-...' -Check
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$Code,
    [string]$Version = '',
    [int]$Iterations = 310000,
    [string]$Image = '',
    [switch]$Check
)

$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.Encoding]::UTF8

$Root      = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$Dir       = Join-Path $Root 'tools\webflash\firmware'
$LockPath  = Join-Path $Root 'tools\webflash\lock.json'
$Manifest  = Join-Path $Root 'tools\webflash\manifest.json'
if (-not $Image) { $Image = Join-Path $Dir 'OBOD.bin' }
$Image     = [IO.Path]::GetFullPath($Image)
$Sealed    = "$Image.enc"

if (-not (Test-Path -LiteralPath $Image)) {
    throw "нет открытого образа: $Image — сначала pwsh -File tools/webflash/merge.ps1"
}

function Get-Sha([byte[]]$Bytes) {
    return ([BitConverter]::ToString(
        [System.Security.Cryptography.SHA256]::HashData($Bytes)) -replace '-', '').ToUpperInvariant()
}

function Get-Key([string]$Pass, [byte[]]$Salt, [int]$Rounds) {
    $bytes = [Text.Encoding]::UTF8.GetBytes($Pass)
    return [System.Security.Cryptography.Rfc2898DeriveBytes]::Pbkdf2(
        $bytes, $Salt, $Rounds,
        [System.Security.Cryptography.HashAlgorithmName]::SHA256, 32)
}

$Plain = [IO.File]::ReadAllBytes($Image)
$PlainSha = Get-Sha $Plain

if ($Check) {
    if (-not (Test-Path -LiteralPath $LockPath)) { throw "нет замка: $LockPath" }
    if (-not (Test-Path -LiteralPath $Sealed))   { throw "нет запечатанного образа: $Sealed" }

    $lock = Get-Content -LiteralPath $LockPath -Raw | ConvertFrom-Json
    $sealed = [IO.File]::ReadAllBytes($Sealed)
    if ((Get-Sha $sealed) -ne $lock.sealed.sha256) { throw 'запечатанный файл не тот, что записан в lock.json' }

    $salt = [Convert]::FromBase64String($lock.kdf.salt)
    $iv   = [Convert]::FromBase64String($lock.cipher.iv)
    $key  = Get-Key $Code $salt ([int]$lock.kdf.iterations)

    $body = New-Object byte[] ($sealed.Length - 16)
    $tag  = New-Object byte[] 16
    [Array]::Copy($sealed, 0, $body, 0, $body.Length)
    [Array]::Copy($sealed, $body.Length, $tag, 0, 16)

    $aes = [System.Security.Cryptography.AesGcm]::new($key, 16)
    try {
        $out = New-Object byte[] $body.Length
        $aes.Decrypt($iv, $body, $tag, $out)
    }
    catch {
        throw 'код не подошёл: тег не сошёлся, образ не расшифрован'
    }
    finally { $aes.Dispose() }

    $sha = Get-Sha $out
    if ($sha -ne $PlainSha) { throw "расшифрованный образ не тот: $sha против $PlainSha" }
    "OK: замок открывается этим кодом, образ $($out.Length) байт, SHA-256 $sha"
    return
}

if (-not $Version) {
    if (Test-Path -LiteralPath $Manifest) {
        $Version = (Get-Content -LiteralPath $Manifest -Raw | ConvertFrom-Json).version
    }
}

$salt = New-Object byte[] 16
$iv   = New-Object byte[] 12
[System.Security.Cryptography.RandomNumberGenerator]::Fill($salt)
[System.Security.Cryptography.RandomNumberGenerator]::Fill($iv)

$key   = Get-Key $Code $salt $Iterations
$body  = New-Object byte[] $Plain.Length
$tag   = New-Object byte[] 16
$aes   = [System.Security.Cryptography.AesGcm]::new($key, 16)
try { $aes.Encrypt($iv, $Plain, $body, $tag) }
finally { $aes.Dispose() }

$sealedBytes = New-Object byte[] ($body.Length + 16)
[Array]::Copy($body, 0, $sealedBytes, 0, $body.Length)
[Array]::Copy($tag, 0, $sealedBytes, $body.Length, 16)
[IO.File]::WriteAllBytes($Sealed, $sealedBytes)

$lock = [ordered]@{
    version = $Version
    cipher  = [ordered]@{ name = 'AES-256-GCM'; iv = [Convert]::ToBase64String($iv); tag = 16 }
    kdf     = [ordered]@{
        name       = 'PBKDF2-SHA256'
        iterations = $Iterations
        salt       = [Convert]::ToBase64String($salt)
    }
    plain   = [ordered]@{ path = 'firmware/OBOD.bin';     size = $Plain.Length;        sha256 = $PlainSha }
    sealed  = [ordered]@{ path = 'firmware/OBOD.bin.enc'; size = $sealedBytes.Length;  sha256 = (Get-Sha $sealedBytes) }
    note    = 'Образ ставится из замка: страница выводит ключ из кода выпуска и расшифровывает файл в браузере.'
}
$json = $lock | ConvertTo-Json -Depth 6
[IO.File]::WriteAllText($LockPath, $json + "`n", (New-Object Text.UTF8Encoding $false))

"запечатан: $Sealed"
"  открытый:    $($Plain.Length) байт, SHA-256 $PlainSha"
"  запечатанный: $($sealedBytes.Length) байт, SHA-256 $($lock.sealed.sha256)"
"  замок:       $LockPath — $($lock.cipher.name), $($lock.kdf.name) x $Iterations"
""
"проверка тем же кодом:"
& $PSCommandPath -Code $Code -Image $Image -Check
