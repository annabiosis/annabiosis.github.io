#!/usr/bin/env node
/**
 * Проверка замка браузерным путём.
 *
 * tools/webflash/seal.ps1 проверяет замок тем же .NET, которым его собрал, и это
 * доказывает только то, что скрипт согласен сам с собой. Страница расшифровывает
 * образ через Web Crypto — другой реализацией, — и вопрос, который здесь задаётся,
 * звучит так: открывается ли замок КЛЮЧОМ ИЗ КОДА, выведенным по параметрам из
 * lock.json, тем же способом, каким это сделает браузер.
 *
 * В Node 22 есть crypto.webcrypto.subtle: это тот же интерфейс и та же семантика,
 * что у window.crypto.subtle в браузере, поэтому проверка здесь значит больше, чем
 * сверка двух вызовов .NET между собой.
 *
 * Код не лежит в репозитории и не может лежать: он общий на выпуск и живёт в посте
 * Boosty. Поэтому скрипт принимает его аргументом и ничего не запоминает.
 *
 * Запуск: node tools/webflash/seal-check.mjs 'код выпуска'
 */

import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.join(here, '..', '..');
const lockPath = path.join(here, 'lock.json');
const sealedPath = path.join(here, 'firmware', 'OBOD.bin.enc');

const code = process.argv[2];
if (!code) {
  console.error('нужен код выпуска: node tools/webflash/seal-check.mjs \'код\'');
  process.exit(2);
}

function die(text) {
  console.error('FAIL: ' + text);
  process.exit(1);
}

if (!fs.existsSync(lockPath)) { die('нет ' + path.relative(root, lockPath)); }
if (!fs.existsSync(sealedPath)) { die('нет ' + path.relative(root, sealedPath)); }

const lock = JSON.parse(fs.readFileSync(lockPath, 'utf8'));
const sealed = fs.readFileSync(sealedPath);
const salt = Buffer.from(lock.kdf.salt, 'base64');
const iv = Buffer.from(lock.cipher.iv, 'base64');
const tagLength = Number(lock.cipher.tag) * 8;

const subtle = crypto.webcrypto.subtle;
const base = await subtle.importKey('raw', new TextEncoder().encode(code), 'PBKDF2', false,
                                    ['deriveKey']);
const key = await subtle.deriveKey(
  { name: 'PBKDF2', salt, iterations: Number(lock.kdf.iterations), hash: 'SHA-256' },
  base, { name: 'AES-GCM', length: 256 }, false, ['decrypt']
);

let plain;
try {
  plain = Buffer.from(await subtle.decrypt({ name: 'AES-GCM', iv, tagLength }, key, sealed));
} catch (error) {
  die('код не подошёл: ' + error.message);
}

const got = crypto.createHash('sha256').update(plain).digest('hex').toUpperCase();
const want = String(lock.plain.sha256 || '').toUpperCase();
if (got !== want) { die('образ расшифровался, но хеш другой: ' + got.slice(0, 16) + '…'); }
if (plain.length !== Number(lock.plain.size)) {
  die('длина расшифрованного ' + plain.length + ', в замке ' + lock.plain.size);
}

console.log('OK: замок открывается браузерным путём — Web Crypto, PBKDF2-SHA256 x ' +
            lock.kdf.iterations + ', AES-256-GCM; образ ' +
            plain.length.toLocaleString('ru-RU') + ' байт, SHA-256 ' + got.slice(0, 16) + '…');
