"""
The air around a page's labels, in the exact arithmetic synth_ui.c lays them out with.

Two questions, and one model answers both:

  * the sequencer ring's dots against a figure page's label boxes. With the ring at 142 px
    and the largest dot 16 px across, how close does the nearest dot come to the nearest
    edge of a sector's name or value? Positive is air, 0.0 is a tangent, negative is an
    overlap. The lead's page draws six sectors on RIM_6 and the drum's five on RIM_5, and
    both are measured here.

  * the labels of a page that draws NO ring — the settings page OPTIONS, the SCALE
    page, which has no figure of its own, and the DRONE page, whose five knobs are
    three shapes, the travel and the follow mode — against each other, and its panels
    against the rim and against each other. There is no dot to measure there, so the
    words have to clear the neighbouring words; the same constants and the same integer
    trig are used, so the two answers cannot come from two different geometries.

THIS IS A GUARD, NOT A DESIGN TOOL. The layout is chosen by how the instrument reads and by
the short panel forms the pages print (ACCENT_NAME in synth_app.cpp), not by this script:
it does not pick an order, it is not a reason to rotate a star or to move a page's main
handle. Its job is to notice when a later edit puts a long value back, or moves a sector, or
changes a font or a readout's format — and to fail loudly on the commit that did it instead
of letting a dot land on a letter on the panel.

It checks itself against the published per-page table — the cells each page's own order
actually binds on — and against the published panel-corner figures for every layout the file
describes, including the six-sector OPTIONS page, so a change to the geometry, the fonts or a
readout's format shows up here as a failure rather than as a comment that has quietly stopped
being true.

Run: python tools/ring_clearance.py
"""

import math
import re
import sys

# lv_trigo_sin()'s own table, copied from src/misc/lv_math.c: 0..90 degrees, one entry per
# degree, plus the 32768 that closes it. lv_trigo_cos(a) is lv_trigo_sin(a + 90), which is
# what an implementation that folded the quadrant itself would produce.
SIN = [0,572,1144,1715,2286,2856,3425,3993,4560,5126,5690,6252,6813,7371,7927,8481,
9032,9580,10126,10668,11207,11743,12275,12803,13328,13848,14365,14876,15384,15886,
16384,16877,17364,17847,18324,18795,19261,19720,20174,20622,21063,21498,21926,22348,
22763,23170,23571,23965,24351,24730,25102,25466,25822,26170,26510,26842,27166,27482,
27789,28088,28378,28660,28932,29197,29452,29698,29935,30163,30382,30592,30792,30983,
31164,31336,31499,31651,31795,31928,32052,32166,32270,32365,32449,32524,32588,32643,
32688,32723,32748,32763,32768]


def trigo_sin(angle):
    a = angle % 360
    if a < 90:
        r = SIN[a]
    elif a < 180:
        r = SIN[180 - a]
    elif a < 270:
        r = -SIN[a - 180]
    else:
        r = -SIN[360 - a]
    # lv_trigo_sin() turns the two saturated entries into the one value that does not fit
    # an int16_t, so that a caller dividing by 32767 can reach the radius exactly.
    if r == 32767:
        return 32768
    if r == -32767:
        return -32768
    return r


def trigo_cos(angle):
    return trigo_sin(angle + 90)


def cdiv(a, b):
    """C's integer division, which truncates toward zero rather than down."""
    q = abs(a) // abs(b)
    return q if (a < 0) == (b < 0) else -q


# The constants the layout is drawn with, from synth_ui.c.
SEQ_RING_R = 142          # SEQ_RING_R
ANCHOR_R = 96             # ANCHOR_R
NAME_DY = -11             # NAME_DY
VALUE_DY = 12             # VALUE_DY
DOT = 16                  # SEQ_DOT_ON, the largest dot
SCREEN = 360


def face_metrics(path):
    """line_height, base_line and the advance of every glyph, read from the C face.

    The faces are proportional, so a width cannot be a count of characters times one
    advance: it is the sum of the advances of the glyphs in the string. Reading them here
    rather than keeping a copy of the numbers means this model cannot describe a face the
    firmware does not draw, which is the failure this script exists to catch.
    """
    with open(path, encoding="utf-8") as fh:
        src = fh.read()

    import re
    line = int(re.search(r"\.line_height = (-?\d+),", src).group(1))
    base = int(re.search(r"\.base_line = (-?\d+),", src).group(1))

    body = src[src.index("glyph_dsc[]"):]
    body = body[body.index("{"):body.index("};")]
    pairs = re.findall(r"\.adv_w = (\d+), \.box_w = \d+, \.box_h = \d+, "
                       r"\.ofs_x = -?\d+, \.ofs_y = -?\d+\}, /\* U\+([0-9A-F]{4}) \*/", body)
    adv = {int(cp, 16): int(a) / 16.0 for (a, cp) in pairs}
    return {"line": line, "base": base, "adv": adv}


F14 = face_metrics("components/synth_ui/src/fonts/lv_font_anbscreen_14.c")
F20 = face_metrics("components/synth_ui/src/fonts/lv_font_anbscreen_20.c")
H14, H20 = F14["line"], F20["line"]

# RIM_5's spans. Five fifths from twelve o'clock: 270, 342, 54, 126 and 198 degrees. The
# drum's figure page, PERC SEQ, draws them: its fifth control is RESET, not the ENV it used
# to share with PERC, so it is a five again and no figure page needs a turned rim.
RIM5 = [(234, 306), (306, 18), (18, 90), (90, 162), (162, 234)]

# RIM_4's spans, and RIM_3's: four quarters from nine o'clock (9, 12, 3 and 6 in that
# order) and three thirds from twelve. RIM_3 is here because OPTIONS used it before the
# WEAK VEL sector arrived, so the before and the after are measured the same way.
RIM4 = [(135, 225), (225, 315), (315, 45), (45, 135)]
RIM3 = [(210, 330), (330, 90), (90, 210)]

# RIM_6's spans: six sixtieths as the same star with one more point, so the first sector is
# at twelve o'clock (270 degrees in LVGL's convention) exactly as RIM_5's and RIM_3's are.
# OPTIONS, the three send pages and the lead's figure page, LEAD EUCLID, all draw it, and so
# does DRONE now that its key tracker is its sixth sector; none of them is turned.
RIM6 = [(240, 300), (300, 0), (0, 60), (60, 120), (120, 180), (180, 240)]


def rim_for(count):
    """The spans rim_for() in synth_ui.c hands back for a page with this many sectors."""
    return {1: [(0, 360)], 2: [(180, 360), (0, 180)], 3: RIM3, 4: RIM4, 5: RIM5,
            6: RIM6}[count]

# The panels a sector's selection is drawn on, and the rim's stroke: the note over
# ANCHOR_R measures the worst panel corner, and the 162 px figure it quotes is the one
# the four published numbers below are written against. See panel_note() for the 155 that
# the renderer actually puts there.
PANEL_W = 112
PANEL_H = 48
ARC_QUOTED = 162

# The published panel-corner figures, by sector count, from the note over ANCHOR_R:
# "two 132.4 (29.6), three 156.7 (5.3), four 153.9 (8.1), five 156.8 (5.2), six 156.5 (5.5)".
PUBLISHED_PANEL = {2: 132.4, 3: 156.7, 4: 153.9, 5: 156.8, 6: 156.5}

# ---------------------------------------------------------------------------
# The OPTIONS page, which draws no ring of dots.
#
# The question "does an eight-character label touch a dot" only exists on the two pages
# that draw the figure's ring, and OPTIONS is not one of them. What has to be clear here
# is the words beside the words: the panels at the compass points, each carrying a name
# and a value. The sectors are in KNOBS_SYS2's order and the values are the widest string
# synth_app_param_text() can print for each — RANDOM for PATCH, 0.5 S for SLIDE, OFF for
# RND DEL, a whole velocity for WEAK VEL, and OFF for MIDI IN.
# ---------------------------------------------------------------------------
OPTIONS = [
    ('PATCH',    ('PATCH',    'RANDOM')),
    ('SLIDE',    ('SLIDE',    '0.5 S')),
    ('RND DEL',  ('RND DEL',  'OFF')),
    ('WEAK VEL', ('WEAK VEL', '127')),
]

# The fifth sector, and the page it arrived on. MIDI IN was appended to KNOBS_SYS2 rather
# than inserted, so the four above keep their slots: RIM_5 puts PATCH at 270, SLIDE at 342,
# RND DEL at 54, WEAK VEL at 126 and MIDI IN at 198 — the same five places, in the same
# order, that PERC SEQ uses.
OPTIONS5 = OPTIONS + [('MIDI IN', ('MIDI IN', 'OFF'))]

# The sixth, appended for the same reason and by the same rule: MORPH is the wave morph
# time, whose widest readout is 100 MS. RIM_6 puts PATCH at 270, SLIDE at 330, RND DEL at
# 30, WEAK VEL at 90, MIDI IN at 150 and MORPH at 210.
OPTIONS6 = OPTIONS5 + [('MORPH', ('MORPH', '100 MS'))]

# The sectors OPTIONS used to hold, for the before/after columns.
OPTIONS_BEFORE = [OPTIONS[0], OPTIONS[1], OPTIONS[2]]

# ---------------------------------------------------------------------------
# The SCALE page (was LEAD GEN), which draws no ring of dots either.
#
# FIVE sectors on RIM_5, in KNOBS_GEN's order: SCALE at twelve, NOTE at 342, OCT at 54,
# DENSITY at 126 and OCTAVE at 198. The values are the widest string
# synth_app_param_text() can print for each: the longest scale name ("DIMINISHED" and
# "MIXOLYDIAN" are the same width), the sharpest note name ROOT can print now that it is a
# list of twelve, the octave number, and the two percentages.
#
# THE TONIC IS TWO SECTORS because one knob across eighty-five semitones was a sweep; see
# SYNTH_PARAM_ROOT_OCT. That is what moved this page off RIM_4, and the two new readouts are
# short — "C#" is the widest note, "7" the widest octave — so what the fifth sector costs is
# the rim's geometry and not a pair of long words.
# ---------------------------------------------------------------------------
SCALE = [
    ('SCALE',   ('SCALE',   'DIMINISHED')),
    ('NOTE',    ('NOTE',    'C#')),
    ('OCT',     ('OCT',     '7')),
    ('DENSITY', ('DENSITY', '100%')),
    ('OCTAVE',  ('OCTAVE',  '50%')),
]

# The page's own published numbers, checked by scale_report():
#   the tightest pair of words is SCALE's "DIMINISHED" against OCTAVE's boxes, and the
#   farthest corner is SCALE's value itself — 3.8 px inside the rim's drawn inner edge at
#   155 px, which is the number that matters here.
# They are what tools/ring_clearance.py prints and what the note over KNOBS_GEN quotes.
PUBLISHED_SCALE_AIR = 33.8
PUBLISHED_SCALE_CORNER = 125.4

# The tightest pair of words the page has ever had, by the layout it is drawn with, and
# the farthest label corner from the middle. Published and checked, so that a change to the
# geometry, to a font or to a readout's format fails here rather than quietly falsifying the
# note over KNOBS_SYS2 in synth_ui.c.
#
#   RIM_4  66.7 px, corner 133.4: PATCH's value against the name of RND DEL at three
#          o'clock — the pair the fourth sector put closest, and PATCH still owns the
#          farthest corner of the page. That was the OPTIONS page's four; the SCALE page
#          was measured on the same rim while it had four sectors, and its own figures are
#          in the SCALE section above.
#   RIM_5  43.2 px, corner 126.3: the same value against MIDI IN's name at 198 degrees;
#          MIDI IN in turn owns the worst corner, because its anchor sits lowest.
#   RIM_6  28.2 px, corner 123.0: PATCH's value against MORPH's name, and MORPH's value
#          against PATCH's, the two six-character values either side of twelve o'clock. The
#          closest two words this page has ever carried, and still air; the corner is the
#          best of the three because sixty degrees a side lands every anchor on an exact
#          entry of the trig table.
#
# The faces are proportional, so these are sums of glyph advances rather than a count of
# characters: they moved when the faces did, and every figure here is what the script prints
# for the faces in components/synth_ui/src/fonts.
#
# The corner is against the rim's inner ink: 162 px is the figure the note quotes, 155 px is
# where the renderer actually starts drawing (see panel_note()).
PUBLISHED_LABEL_AIR = {4: 66.7, 5: 43.2, 6: 28.2}
PUBLISHED_LABEL_CORNER = {4: 133.4, 5: 126.3, 6: 123.0}
RIM_INK_INNER = 155.0

# The labels of the two figure pages, and the cells their orders bind on, are defined below
# the width helpers: the accent forms have to be measured before they can be published.


def anchor(span):
    """The point rim_anchor() aligns a sector's labels to, and the span's mid angle."""
    sweep = span[1] - span[0]
    if sweep <= 0:
        sweep += 360
    mid = (span[0] + sweep // 2) % 360
    return mid, cdiv(ANCHOR_R * trigo_cos(mid), 32767), cdiv(ANCHOR_R * trigo_sin(mid), 32767)


def dots():
    """Every dot position the ring can ever take: a step count of 4..16, every step."""
    out = []
    for n in range(4, 17):
        for i in range(n):
            angle = (i * 360) // n
            x = cdiv(SEQ_RING_R * trigo_sin(angle), 32767)
            y = -cdiv(SEQ_RING_R * trigo_cos(angle), 32767)
            out.append((n, i, x, y))
    return out


DOTS = dots()


def advance(s, face):
    """A string's width: the sum of its glyphs' advances, in that face.

    Kerning is not added: it is at most 2 px on a pair and it pulls the letters together,
    so a box measured without it is the wider of the two and the air below is the smaller.
    """
    total = 0.0
    for ch in s:
        a = face["adv"].get(ord(ch))
        if a is None:
            raise SystemExit("the face has no glyph for %r in %r" % (ch, s))
        total += a
    return total


def text_w(s):
    """A name's width, in the 14 px face."""
    return advance(s, F14)


def value_w(s):
    """A value's width, in the 20 px face."""
    return advance(s, F20)


# The panel forms of the eight accent figures, read from the table that prints them. The
# ACCENT sector's value is one of these, so the widest one is what the sweep must measure: a
# longer form added to the firmware moves this model instead of slipping past it.
def accent_names():
    """The strings in ACCENT_NAME, from synth_app.cpp."""
    path = "components/synth_app/src/synth_app.cpp"
    with open(path, encoding="utf-8") as fh:
        src = fh.read()
    m = re.search(
        r"static const char \*const ACCENT_NAME\[ACCENT_COUNT\]\s*=\s*\{([\s\S]*?)\n\};",
        src)
    if not m:
        raise SystemExit("no ACCENT_NAME table in %s" % path)
    return re.findall(r'"([^"]*)"', m.group(1))


ACCENT_NAMES = accent_names()
ACCENT_WIDEST = max(ACCENT_NAMES, key=value_w)


# The wave names and the follow modes, read from the table that prints them, for the same
# reason as the accent forms above: the three shape sectors can show any of the six names,
# and the FOLLOW sector any of its three, so the widest of each is what the sweep measures.
def wave_names():
    """The strings in the wave table of synth_app_param_text(), from synth_app.cpp."""
    path = "components/synth_app/src/synth_app.cpp"
    with open(path, encoding="utf-8") as fh:
        src = fh.read()
    m = re.search(r'static const char \*const waves\[\] = \{([^}]*)\};', src)
    if not m:
        raise SystemExit("no wave name table in %s" % path)
    return re.findall(r'"([^"]*)"', m.group(1))


def follow_names():
    """The strings in the DRONE_FOLLOW case's list, from synth_app.cpp."""
    path = "components/synth_app/src/synth_app.cpp"
    with open(path, encoding="utf-8") as fh:
        src = fh.read()
    # The brace after the colon is part of the match on purpose: the same parameter also
    # appears in the applier's switch as "case ...: break;", and the text case is the one
    # that opens a block and then names its four modes.
    m = re.search(r"case SYNTH_PARAM_DRONE_FOLLOW: \{[\s\S]*?modes\[\] = \{([^}]*)\};", src)
    if not m:
        raise SystemExit("no DRONE_FOLLOW name list in %s" % path)
    return re.findall(r'"([^"]*)"', m.group(1))


WAVE_WIDEST = max(wave_names(), key=value_w)
FOLLOW_WIDEST = max(follow_names(), key=value_w)

# ---------------------------------------------------------------------------
# The DRONE page, which draws no ring of dots either.
#
# Six sectors on RIM_6, in KNOBS_DRONE's order: the high register's shape at twelve
# o'clock, then the middle and the low, the drone's key tracker, the travel and the follow
# mode. The page used to be four sectors on RIM_4 and then five on RIM_5; K.TRCK is the
# sixth and it sits where the owner asked, between the shapes and WIDTH.
#
# The WIDTH sector is MOTION DEPTH, the drone's travel, and its readout is a whole
# percentage; K.TRCK prints the same form, so both measure the same "100%". The shapes
# print their three-letter names and the mode prints SCALE/FULL/CONS.
# ---------------------------------------------------------------------------
DRONE = [
    ('H.OSC',  ('H.OSC',  WAVE_WIDEST)),
    ('M.OSC',  ('M.OSC',  WAVE_WIDEST)),
    ('L.OSC',  ('L.OSC',  WAVE_WIDEST)),
    ('K.TRCK', ('K.TRCK', '100%')),
    ('WIDTH',  ('WIDTH',  '100%')),
    ('FOLLOW', ('FOLLOW', FOLLOW_WIDEST)),
]

# The page's own published numbers, checked by drone_report(): both are recomputed by this
# model and the note over KNOBS_DRONE quotes them, so a label that grows moves the note.
PUBLISHED_DRONE_AIR = 42.1
PUBLISHED_DRONE_CORNER = 126.4

# ---------------------------------------------------------------------------
# The LEAD page, which draws no ring of dots either.
#
# Four sectors on RIM_4, in KNOBS_LEAD's order: GATE on the left, PORTA at the top, OSC on
# the right and VOICE at the bottom. GATE prints whole percents; PORTA prints OFF or a
# millisecond count, the widest of which is "1000 MS"; OSC prints the widest wave name;
# VOICE prints a word, the longer of its two being "POLY".
# ---------------------------------------------------------------------------
LEAD_PAGE = [
    ('GATE',   ('GATE',   '100%')),
    ('PORTA',  ('PORTA',  '1000 MS')),
    ('OSC',    ('OSC',    WAVE_WIDEST)),
    ('VOICE',  ('VOICE',  'POLY')),
]

PUBLISHED_LEAD_AIR = 75.8
PUBLISHED_LEAD_CORNER = 117.5

# The labels of the two figure pages, as they are longest: five sectors on the drum's page,
# six on the lead's. Names are the sector names from KNOBS_PERC_SEQ and KNOBS_EUCLID; values
# are the widest string synth_app_param_text() can print for that parameter. Rows are the
# page's own order: STEPS, PULSES, ROTATE, ACCENT and RESET on both, with the lead's SCATTER
# in the fifth seat. ENV is no longer here — it lives on PERC, which draws no ring — and
# ACCENT is measured on the widest of its eight panel forms, ACCENT_WIDEST, because the
# sector can show any of them. RESET is last on both, and "256" is its widest readout.
PERC = [
    ('STEPS',  ('STEPS', '16')),
    ('PULSES', ('PULSES', '16/16')),
    ('ROTATE', ('ROTATE', '15')),
    ('ACCENT', ('ACCENT', ACCENT_WIDEST)),
    ('RESET',  ('RESET', '256')),
]
LEAD = [
    ('STEPS',   ('STEPS', '16')),
    ('PULSES',  ('PULSES', '16/16')),
    ('ROTATE',  ('ROTATE', '15')),
    ('ACCENT',  ('ACCENT', ACCENT_WIDEST)),
    ('SCATTER', ('SCATTER', '50 %')),
    ('RESET',   ('RESET', '256')),
]

# The two pages' own sector orders, by slot. The drum's five are the lead's six without
# SCATTER; ACCENT is the fourth seat on both, which is where the short panel forms fit.
LEAD_ORDER = ['STEPS', 'PULSES', 'ROTATE', 'ACCENT', 'SCATTER', 'RESET']
PERC_ORDER = ['STEPS', 'PULSES', 'ROTATE', 'ACCENT', 'RESET']

# The cells the note above SEQ_RING_R quotes: the air each page's own order puts on the
# sector it uses, on that page's own rim. STEPS/0 is each page's main control. Every one is
# air; the tightest is the lead's PULSES at 7.7 px.
#
# These numbers are widths of real strings in the 14 px and 20 px faces on the real spans,
# so they moved when the faces or a layout did. Measured, not rounded to anything — run this
# script and the cells below are what it prints.
PUBLISHED = {
    'PERC SEQ': {
        ('STEPS', 0): 22.0,
        ('PULSES', 1): 9.2,
        ('ROTATE', 2): 18.2,
        ('ACCENT', 3): 9.8,
        ('RESET', 4): 12.6,
    },
    'LEAD EUCLID': {
        ('STEPS', 0): 22.0,
        ('PULSES', 1): 7.7,
        ('ROTATE', 2): 16.6,
        ('ACCENT', 3): 15.8,
        ('SCATTER', 4): 12.4,
        ('RESET', 5): 11.3,
    },
}

# The tightest pair of words on either figure page: a box against a neighbouring sector's
# box, in the same arithmetic as the labels themselves. The note above SEQ_RING_R quotes
# both. The lead's is SCATTER's name against a neighbouring value at the 90/150 boundary;
# the drum's is a pair of names on the wider five-sector star.
PUBLISHED_LABEL_MIN = {'LEAD EUCLID': 41.1, 'PERC SEQ': 60.0}


def box(cx, cy, w, h):
    """An auto-sized lv_label centred on (cx, cy), as LVGL places it.

    LVGL centres with an integer division of the box's own width, so an odd width lands
    half a pixel left of the anchor; the coordinates here are relative to the screen's own
    centre.
    """
    left = math.floor((SCREEN - w) / 2) + cx - SCREEN / 2.0
    return (left, cy - h / 2.0, left + w, cy + h / 2.0)


def dist(p, r):
    """Distance from a point to a rectangle, zero inside it."""
    dx = max(r[0] - p[0], 0.0, p[0] - r[2])
    dy = max(r[1] - p[1], 0.0, p[1] - r[3])
    return math.hypot(dx, dy)


def air(label, rim, slot):
    """Pixels of air between the nearest dot and this label in this slot, and where."""
    mid, ax, ay = anchor(rim[slot])
    boxes = [('name', box(ax, ay + NAME_DY, text_w(label[0]), H14)),
             ('value', box(ax, ay + VALUE_DY, value_w(label[1]), H20))]

    best = None
    for (n, i, x, y) in DOTS:
        for (which, b) in boxes:
            a = dist((x, y), b) - DOT / 2.0
            if best is None or a < best[0]:
                best = (a, n, i, x, y, which)
    return best


def row(name, label, rim):
    return [air(label, rim, s)[0] for s in range(len(rim))]


# ---------------------------------------------------------------------------
# A page with no ring: label against label, and panel against rim.
# ---------------------------------------------------------------------------

def label_boxes(label, slot, rim):
    """The name and the value of one sector, as LVGL places them."""
    mid, ax, ay = anchor(rim[slot])
    return [('name', box(ax, ay + NAME_DY, text_w(label[0]), H14)),
            ('value', box(ax, ay + VALUE_DY, value_w(label[1]), H20))]


def rect_air(a, b):
    """The gap between two rectangles, zero if they touch or overlap."""
    dx = max(a[0] - b[2], b[0] - a[2], 0.0)
    dy = max(a[1] - b[3], b[1] - a[3], 0.0)
    return math.hypot(dx, dy)


def label_air(rows, rim, slot):
    """The air between this sector's two boxes and every other sector's, and which pair.

    This is the measurement a page without a dot ring binds on: the two words of a sector
    against the two words of each neighbour.
    """
    mine = label_boxes(rows[slot][1], slot, rim)
    best = None
    for other in range(len(rim)):
        if other == slot:
            continue
        for (w1, b1) in mine:
            for (w2, b2) in label_boxes(rows[other][1], other, rim):
                a = rect_air(b1, b2)
                if best is None or a < best[0]:
                    best = (a, w1, other, w2)
    return best


def panel_corner(rim, slot):
    """The farthest corner of this sector's 112 x 48 panel from the middle of the screen.

    The panel is centred with an integer offset -- (360 - 112) / 2 and (360 - 48) / 2 are
    both whole -- so its corners are the anchor plus or minus half of each side.
    """
    mid, ax, ay = anchor(rim[slot])
    return max(math.hypot(ax + sx * PANEL_W / 2.0, ay + sy * PANEL_H / 2.0)
               for sx in (-1, 1) for sy in (-1, 1))


def panel_gap(rim, count):
    """The smallest gap between any two of a layout's panels, zero when they touch.

    The panels are the boxes a macro member fills; on a page with no macro nothing is
    drawn there, but two panels that overlap would still be two touch areas that overlap,
    and this is the number that says whether they do.
    """
    boxes = []
    for slot in range(count):
        mid, ax, ay = anchor(rim[slot])
        boxes.append((ax - PANEL_W / 2.0, ay - PANEL_H / 2.0,
                      ax + PANEL_W / 2.0, ay + PANEL_H / 2.0))
    worst = None
    for i in range(count):
        for j in range(i + 1, count):
            a = rect_air(boxes[i], boxes[j])
            if worst is None or a < worst:
                worst = a
    return worst


def panel_note():
    """The worst corner of any panel, layout by layout, against the published figures.

    The air column is measured to the 162 px the note over ANCHOR_R quotes, which is also
    what the published numbers were written against. The renderer puts the rim's ink over
    155..169 rather than 162..169 -- see the note over DIV_R_OUT, which corrects an older
    reading of lv_draw_arc's convention -- so the first column is 7 px optimistic about
    the drawn stroke. Both are printed rather than one being quietly believed: it is a
    pre-existing question about the note, not something a new sector introduces, and the
    four-sector layout is the one that still clears the drawn edge.
    """
    print('worst panel corner, and the air inside the rim:')
    bad = 0
    for count in (2, 3, 4, 5, 6):
        rim = rim_for(count)
        worst = max(panel_corner(rim, s) for s in range(count))
        want = PUBLISHED_PANEL[count]
        ok = abs(worst - want) < 1.0
        bad += 0 if ok else 1
        print('  %d sector(s): corner %6.1f px, published %6.1f %s   air to 162: %5.1f'
              '   air to the drawn inner edge at 155: %5.1f   panel gap: %5.1f'
              % (count, worst, want, 'ok' if ok else 'MOVED',
                 ARC_QUOTED - worst, 155.0 - worst, panel_gap(rim, count)))
    print()
    return bad


def label_corner(rows, rim, slot):
    """The farthest corner of this sector's name or value box from the middle of the screen.

    The question the words have to answer against the RIM rather than against each other:
    a box is centred on the anchor, so its outermost corner is what could reach the arc.
    """
    worst = 0.0
    for (_, b) in label_boxes(rows[slot][1], slot, rim):
        for (x, y) in ((b[0], b[1]), (b[2], b[1]), (b[0], b[3]), (b[2], b[3])):
            worst = max(worst, math.hypot(x, y))
    return worst


def scale_report():
    """The angles, the anchors and every label clearance on the SCALE page."""
    print('== SCALE now (5 sectors, RIM_5) ==')
    print('  %-9s %-9s %5s %8s %10s %10s %8s %8s %10s'
          % ('sector', 'span', 'mid', 'anchor', 'name w', 'value w', 'min air', 'to',
             'corner'))
    for slot, (name, label) in enumerate(SCALE):
        span = RIM5[slot]
        mid, ax, ay = anchor(span)
        a = label_air(SCALE, RIM5, slot)
        corner = label_corner(SCALE, RIM5, slot)
        print('  %-9s %-9s %5d %8s %10.1f %10.1f %8.1f  %-14s %8.1f  air %5.1f'
              % (name, '%d-%d' % span, mid, '%d,%d' % (ax, ay),
                 text_w(label[0]), value_w(label[1]), a[0],
                 '%s/%s s%d' % (a[1], a[3], a[2]), corner, RIM_INK_INNER - corner))

    tightest = min(label_air(SCALE, RIM5, s)[0] for s in range(5))
    worst = max(label_corner(SCALE, RIM5, s) for s in range(5))
    bad = 0
    for (got, want, what) in ((tightest, PUBLISHED_SCALE_AIR, 'tightest pair'),
                              (worst, PUBLISHED_SCALE_CORNER, 'worst corner')):
        ok = abs(got - want) < 0.1
        bad += 0 if ok else 1
        print('SCALE, 5 sectors: %-14s %6.1f px, published %6.1f  %s'
              % (what, got, want, 'ok' if ok else 'MOVED'))

    print('  (no ring of dots here either: page_has_figure() excludes the SCALE page)')
    print()
    return bad


def options_report():
    """The angles, the anchors and every label clearance on the OPTIONS page."""
    bad = panel_note()

    for (title, rows, rim) in (('OPTIONS before (3 sectors, RIM_3)', OPTIONS_BEFORE, RIM3),
                               ('OPTIONS before (4 sectors, RIM_4)', OPTIONS, RIM4),
                               ('OPTIONS before (5 sectors, RIM_5)', OPTIONS5, RIM5),
                               ('OPTIONS now (6 sectors, RIM_6)', OPTIONS6, RIM6)):
        print('== %s ==' % title)
        print('  %-9s %-9s %5s %8s %10s %10s %8s %8s %10s'
              % ('sector', 'span', 'mid', 'anchor', 'name w', 'value w', 'min air', 'to',
                 'corner'))
        for slot, (name, label) in enumerate(rows):
            span = rim[slot]
            mid, ax, ay = anchor(span)
            a = label_air(rows, rim, slot)
            corner = label_corner(rows, rim, slot)
            print('  %-9s %-9s %5d %8s %10.1f %10.1f %8.1f  %-14s %8.1f  air %5.1f'
                  % (name, '%d-%d' % span, mid, '%d,%d' % (ax, ay),
                     text_w(label[0]), value_w(label[1]), a[0],
                     '%s/%s s%d' % (a[1], a[3], a[2]), corner, RIM_INK_INNER - corner))
        print()

    # The self-check: the tightest pair of words and the worst corner, against the numbers
    # this file publishes for the note in synth_ui.c.
    for (rows, rim, count) in ((OPTIONS, RIM4, 4), (OPTIONS5, RIM5, 5), (OPTIONS6, RIM6, 6)):
        tightest = min(label_air(rows, rim, s)[0] for s in range(count))
        worst = max(label_corner(rows, rim, s) for s in range(count))
        for (got, want, what) in ((tightest, PUBLISHED_LABEL_AIR[count], 'tightest pair'),
                                  (worst, PUBLISHED_LABEL_CORNER[count], 'worst corner')):
            ok = abs(got - want) < 0.1
            bad += 0 if ok else 1
            print('OPTIONS, %d sectors: %-14s %6.1f px, published %6.1f  %s'
                  % (count, what, got, want, 'ok' if ok else 'MOVED'))

    print('  (the ring of dots is drawn on EUCLID and PERC SEQ only: page_has_figure()')
    print('   in synth_ui.c, which is why nothing here is measured against a dot)')
    print()
    return bad


def page_report(title, rows, rim, pub_air, pub_corner):
    """The angles, the anchors and every label clearance on a page with no ring of dots."""
    print('== %s (%d sectors) ==' % (title, len(rim)))
    print('  %-9s %-9s %5s %8s %10s %10s %8s %8s %10s'
          % ('sector', 'span', 'mid', 'anchor', 'name w', 'value w', 'min air', 'to',
             'corner'))
    for slot, (name, label) in enumerate(rows):
        span = rim[slot]
        mid, ax, ay = anchor(span)
        a = label_air(rows, rim, slot)
        corner = label_corner(rows, rim, slot)
        print('  %-9s %-9s %5d %8s %10.1f %10.1f %8.1f  %-14s %8.1f  air %5.1f'
              % (name, '%d-%d' % span, mid, '%d,%d' % (ax, ay),
                 text_w(label[0]), value_w(label[1]), a[0],
                 '%s/%s s%d' % (a[1], a[3], a[2]), corner, RIM_INK_INNER - corner))

    tightest = min(label_air(rows, rim, s)[0] for s in range(len(rim)))
    worst = max(label_corner(rows, rim, s) for s in range(len(rim)))
    bad = 0
    for (got, want, what) in ((tightest, pub_air, 'tightest pair'),
                              (worst, pub_corner, 'worst corner')):
        ok = abs(got - want) < 0.1
        bad += 0 if ok else 1
        print('%s, %d sectors: %-14s %6.1f px, published %6.1f  %s'
              % (title, len(rim), what, got, want, 'ok' if ok else 'MOVED'))

    print('  (no ring of dots here either: page_has_figure() excludes this page)')
    print()
    return bad


def drone_report():
    """The DRONE page: six sectors on RIM_6, its own label clearances checked."""
    bad = page_report('DRONE', DRONE, RIM6, PUBLISHED_DRONE_AIR, PUBLISHED_DRONE_CORNER)
    print('  (the waves print %s; the mode prints %s)'
          % ('/'.join(wave_names()), '/'.join(follow_names())))
    return bad


def lead_report():
    """The LEAD page: four sectors on RIM_4, GATE/PORTA/OSC/K.TRCK."""
    return page_report('LEAD', LEAD_PAGE, RIM4, PUBLISHED_LEAD_AIR, PUBLISHED_LEAD_CORNER)


def table(rows, title, rim):
    print('== %s ==' % title)
    print('%-8s %s' % ('', ' '.join('%6s' % ('slot%d' % i) for i in range(len(rim)))))
    for (name, label) in rows:
        print('%-8s %s' % (name, ' '.join('%6.1f' % a for a in row(name, label, rim))))
    print()


FIGURES = (
    ('PERC SEQ', PERC, PERC_ORDER, RIM5),
    ('LEAD EUCLID', LEAD, LEAD_ORDER, RIM6),
)


def main():
    bad = 0
    for (title, rows, order, rim) in FIGURES:
        table(rows, '%s (published in synth_ui.c)' % title, rim)

    print('the sectors each page actually uses:')
    for (title, rows, order, rim) in FIGURES:
        labels = dict(rows)
        airs = [air(labels[name], rim, slot)[0] for slot, name in enumerate(order)]
        print('  %-11s %s' % (title, ' '.join('%s@slot%d %5.1f' % (n, s, a)
                                              for s, (n, a) in enumerate(zip(order, airs)))))
        tightest = min(label_air(rows, rim, s)[0] for s in range(len(rows)))
        want = PUBLISHED_LABEL_MIN[title]
        ok = abs(tightest - want) < 0.1
        bad += 0 if ok else 1
        print('  %-11s tightest pair of words %5.1f px, published %5.1f  %s'
              % ('', tightest, want, 'ok' if ok else 'MOVED'))

    print()
    print('binding cells, and the published numbers they are checked against:')
    for (title, rows, order, rim) in FIGURES:
        labels = dict(rows)
        for (key, want) in sorted(PUBLISHED[title].items()):
            name, slot = key
            got, n, i, x, y, which = air(labels[name], rim, slot)
            ok = abs(got - want) < 1.0
            bad += 0 if ok else 1
            print('  %-7s %-11s slot%d  %5.1f px, published %5.1f  %s   '
                  '(%s box, dot %d of %d at %d,%d)'
                  % (name, title, slot, got, want, 'ok' if ok else 'MOVED', which, i, n, x, y))
    print()
    print('ACCENT_NAME: %s; the widest, measured in the 20 px face, is %r at %.1f px'
          % (', '.join(repr(n) for n in ACCENT_NAMES), ACCENT_WIDEST, value_w(ACCENT_WIDEST)))
    print()

    bad += scale_report()
    bad += drone_report()
    bad += lead_report()
    bad += options_report()

    if bad:
        print('FAIL: %d published cell(s) no longer agree with this model' % bad)
        return 1
    print('ok')
    return 0


if __name__ == '__main__':
    sys.exit(main())
