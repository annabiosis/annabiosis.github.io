#include "platform.h"

#include "esp_cpu.h"
#include "esp_heap_caps.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "freertos/task.h"

#include <atomic>
#include <chrono>
#include <cstdarg>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <mutex>
#include <new>
#include <thread>

#ifdef _WIN32
#include <windows.h>
#endif

/*
 * The seam between the firmware's audio sources and a Windows process.
 *
 * This file is deliberately dull: no audio, no test logic, only the handful of ESP-IDF
 * and FreeRTOS names the DSP spells, implemented with the C library and std::thread. The
 * one decision worth stating is that the clock is VIRTUAL. The rack uses esp_timer only
 * to rate-limit its rescue lines, and a bench that ran on the wall clock would make a
 * million-block run take as long as the audio it renders. Advancing time from the block
 * loop keeps the log timestamps meaningful and the run reproducible.
 */

namespace {

std::atomic<int64_t> g_now_us{0};

/* ---- the counted heap ---------------------------------------------------- */

/*
 * Every block carries its own size, so host_heap_used() is a sum over live allocations
 * rather than a guess from malloc_usable_size(). The alignment is that of max_align_t:
 * the DSP asks for float lines and structs with pointers, and both must land where the
 * compiler expects.
 */
struct alignas(16) AllocHeader {
    size_t   size;
    uint64_t magic;
};

constexpr uint64_t ALLOC_MAGIC = 0x484F535453544143ull;   /* "HOSTSTAC" */

std::mutex g_heap_mutex;
size_t     g_heap_used;
size_t     g_heap_peak;
size_t     g_heap_limit;          /* 0 = no ceiling */
uint32_t   g_heap_failures;
uint32_t   g_heap_live;

void *counted_alloc(size_t size)
{
    if (size == 0) {
        size = 1;
    }

    std::lock_guard<std::mutex> lock(g_heap_mutex);

    if (g_heap_limit != 0
        && (size > g_heap_limit || g_heap_used > g_heap_limit - size)) {
        g_heap_failures++;
        return nullptr;
    }

    void *raw = std::malloc(sizeof(AllocHeader) + size);
    if (!raw) {
        g_heap_failures++;
        return nullptr;
    }

    AllocHeader *h = static_cast<AllocHeader *>(raw);
    h->size = size;
    h->magic = ALLOC_MAGIC;

    g_heap_used += size;
    g_heap_live++;
    if (g_heap_used > g_heap_peak) {
        g_heap_peak = g_heap_used;
    }
    return reinterpret_cast<void *>(h + 1);
}

void counted_free(void *ptr)
{
    if (!ptr) {
        return;
    }

    AllocHeader *h = reinterpret_cast<AllocHeader *>(ptr) - 1;
    if (h->magic != ALLOC_MAGIC) {
        /* A pointer this heap did not hand out. The DSP never does that; if it starts,
         * failing loudly here is better than corrupting the count. */
        std::fprintf(stderr, "host heap: free of a foreign pointer %p\n", ptr);
        std::abort();
    }

    std::lock_guard<std::mutex> lock(g_heap_mutex);
    g_heap_used -= h->size;
    g_heap_live--;
    h->magic = 0;
    std::free(h);
}

/* ---- logging ------------------------------------------------------------- */

std::mutex g_log_mutex;

/* ---- the last step, for a crash ------------------------------------------ */

char g_step_context[512];

#ifdef _WIN32
/*
 * A last-resort filter: no rescue counter can see an access violation, and a bench that
 * vanishes on one reports nothing. The step string is written with WriteFile rather than
 * fprintf because the crash may have happened while the logging mutex was held, and a
 * handler that deadlocks looks exactly like a hang.
 */
LONG CALLBACK crash_filter(EXCEPTION_POINTERS *info)
{
    const DWORD code = (info != nullptr && info->ExceptionRecord != nullptr)
                           ? info->ExceptionRecord->ExceptionCode
                           : 0u;

    char buffer[768];
    const int n = std::snprintf(buffer, sizeof(buffer),
                                "\nCRASH: exception 0x%08lx at %p\n  last step: %s\n"
                                "  result: FAIL (the value reached an index no rescue can guard)\n",
                                (unsigned long)code,
                                (info != nullptr && info->ExceptionRecord != nullptr)
                                    ? info->ExceptionRecord->ExceptionAddress
                                    : nullptr,
                                g_step_context[0] ? g_step_context : "(none)");

    DWORD written = 0;
    if (n > 0) {
        WriteFile(GetStdHandle(STD_ERROR_HANDLE), buffer, (DWORD)n, &written, nullptr);
    }

    /* Returning EXCEPTION_EXECUTE_HANDLER here would let Windows terminate with the
     * exception code, which is not the bench's contract: a fail is 1. */
    ExitProcess(1);
    return EXCEPTION_EXECUTE_HANDLER;
}
#endif

char level_letter(host_log_level_t level)
{
    switch (level) {
    case HOST_LOG_DEBUG: return 'D';
    case HOST_LOG_INFO:  return 'I';
    case HOST_LOG_WARN:  return 'W';
    case HOST_LOG_ERROR: return 'E';
    }
    return '?';
}

} // namespace

void host_platform_init(void)
{
    /* The mutexes and the atomics are ready before main() by construction. Nothing to
     * allocate and nothing to tear down; the function exists so the bench can say the
     * seam is up before it touches the DSP. */
#ifdef _WIN32
    SetUnhandledExceptionFilter(crash_filter);
#endif
}

void host_set_step_context(const char *text)
{
    if (text == nullptr) {
        g_step_context[0] = '\0';
        return;
    }

    std::strncpy(g_step_context, text, sizeof(g_step_context) - 1);
    g_step_context[sizeof(g_step_context) - 1] = '\0';
}

void host_advance_us(int64_t us)
{
    if (us > 0) {
        g_now_us.fetch_add(us, std::memory_order_relaxed);
    }
}

int64_t host_now_us(void)
{
    return g_now_us.load(std::memory_order_relaxed);
}

extern "C" int64_t esp_timer_get_time(void)
{
    return host_now_us();
}

extern "C" uint32_t esp_cpu_get_cycle_count(void)
{
    /* A monotonic count at roughly the chip's rate. The firmware has used this to price
     * short spans in its own unit, and a host answer in the same unit keeps those logs
     * comparable. The steady clock has nanosecond resolution here; multiplying by the
     * ESP32-S3's 240 MHz puts the result where the firmware expects it. The low word is
     * the API's own width. */
    using Clock = std::chrono::steady_clock;
    static const Clock::time_point origin = Clock::now();

    const int64_t ns = std::chrono::duration_cast<std::chrono::nanoseconds>(
                           Clock::now() - origin).count();
    return (uint32_t)((uint64_t)ns * 240ull / 1000ull);
}

void host_heap_set_limit(size_t bytes)
{
    std::lock_guard<std::mutex> lock(g_heap_mutex);
    g_heap_limit = bytes;
}

size_t host_heap_used(void)
{
    std::lock_guard<std::mutex> lock(g_heap_mutex);
    return g_heap_used;
}

size_t host_heap_peak(void)
{
    std::lock_guard<std::mutex> lock(g_heap_mutex);
    return g_heap_peak;
}

uint32_t host_heap_failures(void)
{
    std::lock_guard<std::mutex> lock(g_heap_mutex);
    return g_heap_failures;
}

uint32_t host_heap_live_blocks(void)
{
    std::lock_guard<std::mutex> lock(g_heap_mutex);
    return g_heap_live;
}

extern "C" void *heap_caps_malloc(size_t size, uint32_t caps)
{
    (void)caps;
    return counted_alloc(size);
}

extern "C" void *heap_caps_calloc(size_t count, size_t size, uint32_t caps)
{
    (void)caps;

    if (size != 0 && count > (size_t)-1 / size) {
        std::lock_guard<std::mutex> lock(g_heap_mutex);
        g_heap_failures++;
        return nullptr;
    }

    const size_t bytes = count * size;
    void *p = counted_alloc(bytes);
    if (p) {
        std::memset(p, 0, bytes);
    }
    return p;
}

extern "C" void heap_caps_free(void *ptr)
{
    counted_free(ptr);
}

extern "C" void *heap_caps_malloc_prefer(size_t size, size_t num, ...)
{
    (void)num;
    return counted_alloc(size);
}

extern "C" size_t heap_caps_get_free_size(uint32_t caps)
{
    (void)caps;

    std::lock_guard<std::mutex> lock(g_heap_mutex);
    if (g_heap_limit == 0) {
        return (size_t)-1;
    }
    return (g_heap_used >= g_heap_limit) ? 0 : (g_heap_limit - g_heap_used);
}

extern "C" void host_log_line(host_log_level_t level, const char *tag, const char *fmt, ...)
{
    char message[1024];

    va_list ap;
    va_start(ap, fmt);
    std::vsnprintf(message, sizeof(message), fmt, ap);
    va_end(ap);

    const int64_t us = host_now_us();

    std::lock_guard<std::mutex> lock(g_log_mutex);
    std::fprintf(stderr, "%c (%lld.%03lld s) %s: %s\n",
                 level_letter(level),
                 (long long)(us / 1000000),
                 (long long)((us % 1000000) / 1000),
                 (tag != nullptr) ? tag : "?",
                 message);
}

extern "C" uint32_t esp_log_timestamp(void)
{
    const int64_t us = host_now_us();
    return (uint32_t)(us / 1000);
}

extern "C" BaseType_t xTaskCreatePinnedToCore(host_task_fn_t fn, const char *name,
                                              uint32_t stack, void *arg, int priority,
                                              void *handle, int core)
{
    (void)stack;
    (void)priority;
    (void)handle;
    (void)core;

    if (fn == nullptr) {
        return pdFAIL;
    }

    /* A real thread, because the claim tasks are part of the design being tested: the
     * audio path asks and never waits, and the zeroing happens elsewhere. Folding the
     * claim into the call would hide exactly the behaviour under test. */
    try {
        std::thread worker([fn, arg]() { fn(arg); });
        worker.detach();
    } catch (const std::system_error &) {
        std::fprintf(stderr, "host task: could not start %s\n",
                     (name != nullptr) ? name : "?");
        return pdFAIL;
    }

    return pdPASS;
}

extern "C" void vTaskDelay(TickType_t ticks)
{
    /* One tick is one millisecond here; the claim tasks ask for ten. Sleeping for real
     * is what makes the hand-off observable, and it happens at most once per claim. */
    if (ticks == 0 || ticks == portMAX_DELAY) {
        return;
    }

    std::this_thread::sleep_for(std::chrono::milliseconds(ticks));
}

extern "C" void vTaskDelete(void *handle)
{
    (void)handle;
    /* A thread cannot be reaped from inside itself through std::thread, and no DSP
     * module deletes a task at all. Yielding keeps the symbol honest without pretending
     * to terminate anything. */
    std::this_thread::yield();
}
