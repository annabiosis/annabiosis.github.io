/*
 * The host side of the platform seam.
 *
 * Everything the firmware gets from ESP-IDF and FreeRTOS that the audio path touches is
 * implemented here, and nothing else is: the DSP sources are compiled unchanged, so this
 * is the complete list of what the host has to provide. The bench uses the setters below
 * to drive the virtual clock and, when asked, to make the pool refuse an allocation.
 */
#pragma once

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Called once, before synth_dsp_init(). Idempotent. */
void host_platform_init(void);

/* Move the virtual clock forward. Nothing else advances it: there is no real-time
 * dependency in the audio path, and a block costs the same whatever the wall clock says. */
void    host_advance_us(int64_t us);
int64_t host_now_us(void);

/*
 * What the bench was doing, for a crash that no rescue can report.
 *
 * A non-finite value that reaches an unchecked index does not produce a bad sample: it
 * produces an access violation, and the process is gone before the verdict. This string
 * is copied before every step and every block, and the handler installed by
 * host_platform_init() writes it to stderr before exiting with 1, so the last line of a
 * crashed run still names the seed, the step and the value.
 */
void host_set_step_context(const char *text);

/*
 * A ceiling on what the audio path may claim, in bytes. Zero means no ceiling. When the
 * next allocation would cross it, the allocation fails exactly as a full PSRAM pool does,
 * which is how the bypass paths (the effects stay out, the rack keeps playing) are
 * exercised without waiting for a board to run out.
 */
void   host_heap_set_limit(size_t bytes);
size_t host_heap_used(void);
size_t host_heap_peak(void);
uint32_t host_heap_failures(void);
uint32_t host_heap_live_blocks(void);

#ifdef __cplusplus
}
#endif
