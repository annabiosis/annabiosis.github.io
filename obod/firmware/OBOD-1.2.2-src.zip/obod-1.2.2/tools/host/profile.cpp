/*
 * WHERE A BLOCK'S TIME GOES, PART BY PART.
 *
 * WHY THIS EXISTS
 *   The instrument misses its block deadline a few times a second, and the
 *   statistics line has reported a 13.7 ms block while the overload record — eight
 *   slots, oldest overwritten first — only ever shows 3131 us. A number that
 *   disagrees with its own record cannot be fixed by guessing which stage is late.
 *   This bench prices the stages separately, on the same sources the firmware runs:
 *   every translation unit under components/synth_dsp is compiled UNCHANGED, and the
 *   measurement lives entirely outside them.
 *
 * WHAT IS MEASURED, AND HOW
 *   Two kinds of number, and they answer different questions.
 *
 *   A PIPELINE RUN renders a block the way synth_app.cpp's audio task does — clear
 *   the layer accumulators, fill the five buses, run each bus' filter and its pan
 *   capture, then synth_rack_process() — with a timestamp around each call. That is
 *   the table: microseconds per part and its share of the block, for six patches
 *   that between them cover the ways the instrument is played.
 *
 *   The rack is one function, so its insides cannot be timed by wrapping the call.
 *   The three returns and the drum are priced on their OWN functions, with the
 *   configuration the rack has just given them — which is not the same as the rack's
 *   difference, because the chorus and the delay are pinned at full wet and have no
 *   off switch at all. The compressor IS a difference: its zero is a position the API
 *   offers, and the rack's mean with and without it over the same window leaves its own
 *   cost. The drive used to be the second such row and is out of the instrument now, so
 *   what its row used to hold has gone back into the residual where it belongs. What no switch reaches — the sum of
 *   the five buses, the gate ramp, the returns' sum, the fader glide, the master and
 *   the clip — stays as one residual row. The fuse and the silence watchdog are the
 *   block's FIXED cost, found by timing the same rack at 32, 64, 96 and 128 samples
 *   and fitting time = fixed + samples x rate.
 *
 *   A third kind of number is the OUTLIER: a single block that costs many times the
 *   steady one. A mean cannot show one, so the bench drives the suspects by hand —
 *   the block beside a memory claim (a megabyte and a half cleared on the other core
 *   while the audio task keeps rendering), the first drum hit on a voice, a change of
 *   delay time in both of its modes, the longest line the delay can address, and the
 *   four reverb algorithms — and prints the block times one by one.
 *
 * WHAT THIS BENCH IS NOT
 *   The ESP32-S3's voice engine is not here: the five buses are filled with a
 *   deterministic sine/noise sum, as in tools/host/stress.cpp, so the generator row
 *   is a stand-in and the engine's own cost has to be measured on the instrument.
 *   Nor is its memory: a delay line here is ordinary RAM behind an L2 and an L3,
 *   while on the board it is PSRAM behind a cache the display also reads through.
 *   The absolute microseconds are this machine's; the shares are the portable part,
 *   and the long-line experiment exists to show how much of a share is cache.
 *
 * UNITS
 *   Microseconds per block, at 48 kHz and SYNTH_BLOCK_SAMPLES (256) samples — the block
 *   the firmware renders, and the 5333.3 us of audio its deadline is measured against.
 */
#include "platform.h"
#include "synth_dsp.h"
#include "synth_dsp_private.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <limits>
#include <thread>
#include <vector>

namespace {

constexpr int    BLOCK    = SYNTH_BLOCK_SAMPLES;
constexpr double BLOCK_US = (double)BLOCK * 1.0e6 / (double)SYNTH_SAMPLE_RATE;
constexpr int    WARM     = 40;   /* blocks a change gets to settle before a window */
constexpr int    RUN      = 400;  /* default blocks in a measured window */

int g_run = RUN;
bool g_probe = false;

/* -------------------------------------------------------------------------- */
/* The clock                                                                  */
/* -------------------------------------------------------------------------- */

/*
 * rdtsc, and not the steady clock: a stage here is a few microseconds, and two
 * std::chrono reads are most of that. The timestamp is priced — two reads of an
 * empty span, two thousand times, median — and subtracted from every measurement, so
 * a row for a trivial call reads as the call and not as the clock around it.
 */
double g_us_per_tick = 1.0;
double g_stamp_us = 0.0;

inline uint64_t stamp()
{
    __asm__ __volatile__("" ::: "memory");
    const uint64_t t = __rdtsc();
    __asm__ __volatile__("" ::: "memory");
    return t;
}

inline double us_since(uint64_t t0)
{
    const double us = (double)(stamp() - t0) * g_us_per_tick - g_stamp_us;
    return (us > 0.0) ? us : 0.0;
}

void calibrate_clock()
{
    using Clock = std::chrono::steady_clock;

    const Clock::time_point c0 = Clock::now();
    const uint64_t          t0 = stamp();
    volatile double         sink = 0.0;
    while (std::chrono::duration<double>(Clock::now() - c0).count() < 0.10) {
        for (int i = 0; i < 4096; i++) {
            sink += (double)i * 1.0000001;
        }
    }
    const double   us = std::chrono::duration<double, std::micro>(Clock::now() - c0).count();
    const uint64_t t1 = stamp();
    g_us_per_tick = (t1 > t0) ? us / (double)(t1 - t0) : 1.0;

    std::vector<double> spans;
    spans.reserve(2048);
    for (int i = 0; i < 2048; i++) {
        const uint64_t a = stamp();
        const uint64_t b = stamp();
        spans.push_back((double)(b - a) * g_us_per_tick);
    }
    std::sort(spans.begin(), spans.end());
    g_stamp_us = spans[spans.size() / 2];
}

/* -------------------------------------------------------------------------- */
/* Parts                                                                      */
/* -------------------------------------------------------------------------- */

/*
 * A part is one row of the table: a sum over the window, a count, a maximum, and the
 * place that maximum was seen. The maxima are kept per state AND globally, because a
 * maximum is only readable next to the patch it happened in.
 */
struct Part {
    const char *name;
    double      sum_us;
    double      max_us;
    uint64_t    n;
    char        max_where[160];
};

enum PartId {
    P_CLEAR = 0,
    P_GEN,
    P_DRONE,
    P_LEAD,
    P_MIC,
    P_PAN,
    P_RACK,
    P_COUNT
};

const char *const PART_NAME[P_COUNT] = {
    "layers: clear",
    "generator (stand-in)",
    "drone filter x3",
    "lead filter",
    "mic in",
    "pan capture x5",
    "rack (whole)",
};

Part g_part[P_COUNT];
Part g_part_max[P_COUNT];

void parts_reset()
{
    for (int i = 0; i < P_COUNT; i++) {
        g_part[i].sum_us = 0.0;
        g_part[i].max_us = 0.0;
        g_part[i].n = 0;
        g_part[i].max_where[0] = '\0';
    }
}

void parts_reset_maxima()
{
    for (int i = 0; i < P_COUNT; i++) {
        g_part_max[i] = Part{ PART_NAME[i], 0.0, 0.0, 0, { 0 } };
    }
}

void part_add(int id, double us, const char *state, int block)
{
    Part &p = g_part[id];
    p.sum_us += us;
    p.n++;
    if (us > p.max_us) {
        p.max_us = us;
        std::snprintf(p.max_where, sizeof(p.max_where), "%s, block %d", state, block);
    }
    if (us > g_part_max[id].max_us) {
        g_part_max[id].max_us = us;
        g_part_max[id].sum_us = 0.0;
        std::snprintf(g_part_max[id].max_where, sizeof(g_part_max[id].max_where),
                      "%s, block %d", state, block);
    }
}

double part_mean(int id)
{
    return (g_part[id].n > 0) ? (g_part[id].sum_us / (double)g_part[id].n) : 0.0;
}

/* -------------------------------------------------------------------------- */
/* Deterministic numbers                                                      */
/* -------------------------------------------------------------------------- */

/* splitmix64, the same generator the stress bench uses: a seed and a block number
 * are enough to reproduce a run, which is what makes an outlier reportable. */
struct Rng {
    uint64_t s;

    explicit Rng(uint32_t seed) : s((uint64_t)seed * 0x9E3779B97F4A7C15ull + 1u) {}

    uint64_t next()
    {
        uint64_t z = (s += 0x9E3779B97F4A7C15ull);
        z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ull;
        z = (z ^ (z >> 27)) * 0x94D049BB133111EBull;
        return z ^ (z >> 31);
    }

    float unit() { return (float)((next() >> 40) * (1.0 / 16777216.0)); }
};

constexpr int SINE_BITS = 12;
constexpr int SINE_SIZE = 1 << SINE_BITS;

float g_sine[SINE_SIZE];

void sine_table_init()
{
    for (int i = 0; i < SINE_SIZE; i++) {
        g_sine[i] = sinf(2.0f * 3.14159265358979f * (float)i / (float)SINE_SIZE);
    }
}

inline float sine_at(float phase01)
{
    const float p = phase01 * (float)SINE_SIZE;
    int         i = (int)p;
    const float t = p - (float)i;
    i &= (SINE_SIZE - 1);
    const int j = (i + 1) & (SINE_SIZE - 1);
    return g_sine[i] + (g_sine[j] - g_sine[i]) * t;
}

Rng *g_rng = nullptr;

/* -------------------------------------------------------------------------- */
/* The patch                                                                  */
/* -------------------------------------------------------------------------- */

/*
 * The control surface as a patch: every setter the audio task can be handed, in one
 * struct. A state is an instance of it, and applying one is what a preset load does —
 * every setter, in the order the pages send them.
 */
struct Patch {
    const char *name;

    float layer_level[SYNTH_NUM_LAYERS];
    float master;
    float comp;
    float duck;

    float chorus_rate, chorus_depth, chorus_mix;

    float delay_time, delay_fb, delay_mix;
    bool  delay_xfade;

    float reverb_size, reverb_damp, reverb_mix;
    int   reverb_mode;

    float rev_send[SYNTH_NUM_LAYERS];
    float chr_send[SYNTH_NUM_LAYERS];
    float dly_send[SYNTH_NUM_LAYERS];

    float perc_send, perc_chr_send, perc_dly_send;
    float perc_pitch, perc_reso, perc_decay, perc_env, perc_level, perc_body;

    int hits_every;      /* blocks between drum figures; 0 = the drum is not played */
    int voices_wanted;   /* hits per figure */
    int gate;
    int transport;
};

Patch g_patch;

void patch_apply(const Patch &p)
{
    synth_rack_set_master(p.master);
    for (int i = 0; i < SYNTH_NUM_LAYERS; i++) {
        synth_rack_set_layer_level(i, p.layer_level[i]);
        synth_rack_set_reverb_send(i, p.rev_send[i]);
        synth_rack_set_chorus_send(i, p.chr_send[i]);
        synth_rack_set_delay_send(i, p.dly_send[i]);
    }
    synth_rack_set_comp(p.comp);
    synth_rack_set_duck(p.duck);
    synth_rack_set_chorus(p.chorus_rate, p.chorus_depth, p.chorus_mix);
    synth_rack_set_delay(p.delay_time, p.delay_fb, p.delay_mix, p.delay_xfade);
    synth_rack_set_reverb(p.reverb_size, p.reverb_damp, p.reverb_mix, p.reverb_mode);
    synth_rack_set_perc_send(p.perc_send);
    synth_rack_set_perc_chorus_send(p.perc_chr_send);
    synth_rack_set_perc_delay_send(p.perc_dly_send);
    synth_perc_set(p.perc_pitch, p.perc_reso, p.perc_decay, p.perc_env,
                   p.perc_level, p.perc_body);
    synth_rack_set_gate(p.gate);
    synth_rack_set_transport(p.transport);

    g_patch = p;
}

/* -------------------------------------------------------------------------- */
/* The signal path                                                            */
/* -------------------------------------------------------------------------- */

/*
 * The five buses, as the engine would leave them: one sine per layer at its own
 * register, plus a little noise, at 16-bit scale in int32 — the contract
 * synth_fx_pan_capture() documents. The microphone is published the way the audio
 * task publishes it. Nothing here is the instrument's sound; it is a signal with the
 * right scale and the right amount of movement, which is all a cost measurement
 * needs.
 */
struct LayerSignal {
    float   phase;
    float   inc;
    float   pan_phase;
    float   pan_inc;
    int32_t bus[BLOCK];
};

LayerSignal g_sig[SYNTH_NUM_LAYERS];

int16_t g_drone_ep[SYNTH_NUM_LAYERS][8];
int16_t g_lead_ep[8];
int16_t g_mic_ep[8];
int16_t g_pan_ep[SYNTH_NUM_LAYERS][8];
int32_t g_fx_state[SYNTH_NUM_LAYERS][6];

float   g_mic_block[BLOCK];
int16_t g_out[BLOCK * 2];

/* Bench buffers for timing a module on its own: the send, and the wet the reverb and
 * the plate write into. Restored before every timed call, so an effect's own output
 * never becomes its next input. */
float g_mod_l[BLOCK];
float g_mod_r[BLOCK];
float g_mod_l0[BLOCK];
float g_mod_r0[BLOCK];
float g_mod_send[BLOCK];
float g_mod_wet_l[BLOCK];
float g_mod_wet_r[BLOCK];

void signal_init()
{
    static const float   freq[SYNTH_NUM_LAYERS] = { 55.0f, 82.5f, 110.0f, 220.0f, 330.0f };
    static const int16_t pan_milli[SYNTH_NUM_LAYERS] = { -550, -250, 0, 250, 550 };
    static const int16_t pan_rate[SYNTH_NUM_LAYERS]  = { 31, 37, 43, 53, 61 };

    for (int i = 0; i < SYNTH_NUM_LAYERS; i++) {
        g_sig[i].phase = (float)i * 0.173f;
        g_sig[i].inc = freq[i] / (float)SYNTH_SAMPLE_RATE;
        g_sig[i].pan_phase = (float)i * 0.271f;
        g_sig[i].pan_inc = 0.0007f + 0.0001f * (float)i;

        std::memset(g_drone_ep[i], 0, sizeof(g_drone_ep[i]));
        std::memset(g_pan_ep[i], 0, sizeof(g_pan_ep[i]));
        std::memset(g_fx_state[i], 0, sizeof(g_fx_state[i]));

        g_pan_ep[i][0] = pan_milli[i];
        g_pan_ep[i][1] = 400;
        g_pan_ep[i][2] = pan_rate[i];
        g_pan_ep[i][3] = (int16_t)(pan_rate[i] + 17);
        g_pan_ep[i][4] = 4000;
        g_pan_ep[i][5] = 300;
        g_pan_ep[i][6] = 1;
        g_pan_ep[i][7] = (int16_t)i;

        g_drone_ep[i][0] = (int16_t)(400 + 400 * i);
        g_drone_ep[i][1] = 70;
        g_drone_ep[i][2] = (int16_t)(31 + 16 * i);
        g_drone_ep[i][3] = 200;
        g_drone_ep[i][4] = 0;
        g_drone_ep[i][5] = (int16_t)(i % 5);
        g_drone_ep[i][6] = 1;
        g_drone_ep[i][7] = (int16_t)i;
    }

    g_lead_ep[0] = 2400;
    g_lead_ep[1] = 120;
    g_lead_ep[2] = 240;
    g_lead_ep[3] = 4;
    g_lead_ep[4] = 180;
    g_lead_ep[5] = 200;
    g_lead_ep[6] = 350;
    g_lead_ep[7] = 1;

    g_mic_ep[6] = 1;

    for (int i = 0; i < BLOCK; i++) {
        g_mod_l0[i] = 0.12f * sine_at((float)i / (float)BLOCK);
        g_mod_r0[i] = 0.12f * sine_at((float)i / (float)BLOCK + 0.25f);
        g_mod_l[i] = g_mod_l0[i];
        g_mod_r[i] = g_mod_r0[i];
        g_mod_send[i] = 0.10f * sine_at((float)i / (float)BLOCK);
        g_mod_wet_l[i] = 0.0f;
        g_mod_wet_r[i] = 0.0f;
    }
}

struct BlockTimes {
    double clear, gen, drone, lead, mic, pan, rack;
};

/* One block of "engine": the five buses, their filters, their pan captures. The
 * stages are timed one call at a time from the outside, which is why this is split
 * rather than written as one function. */
BlockTimes fill_layers(uint64_t block_index)
{
    BlockTimes t{};
    static const float amp[SYNTH_NUM_LAYERS] = { 0.100f, 0.080f, 0.060f, 0.050f, 0.040f };

    uint64_t t0 = stamp();
    synth_layers_clear(BLOCK);
    t.clear = us_since(t0);

    t0 = stamp();
    for (int i = 0; i < BLOCK; i++) {
        g_mic_block[i] = 0.04f * sine_at((float)((block_index * BLOCK + i) % 4800) / 4800.0f);
    }
    synth_dsp_mic_publish(g_mic_block, BLOCK);

    for (int layer = 0; layer < SYNTH_NUM_LAYERS; layer++) {
        LayerSignal &s = g_sig[layer];
        for (int i = 0; i < BLOCK; i++) {
            const float x = amp[layer] * sine_at(s.phase)
                          + 0.006f * (g_rng->unit() * 2.0f - 1.0f);
            s.phase += s.inc;
            if (s.phase >= 1.0f) {
                s.phase -= 1.0f;
            }
            s.bus[i] = (int32_t)(x * 32768.0f);
        }
    }
    t.gen = us_since(t0);

    t0 = stamp();
    for (int layer = 0; layer < SYNTH_NUM_LAYERS; layer++) {
        if (layer == SYNTH_LAYER_LEAD || layer == SYNTH_LAYER_AUX) {
            continue;
        }
        synth_fx_drone_filter(g_sig[layer].bus, BLOCK, g_drone_ep[layer], g_fx_state[layer]);
    }
    t.drone = us_since(t0);

    t0 = stamp();
    synth_fx_lead_filter(g_sig[SYNTH_LAYER_LEAD].bus, BLOCK, g_lead_ep,
                         g_fx_state[SYNTH_LAYER_LEAD]);
    t.lead = us_since(t0);

    t0 = stamp();
    synth_fx_mic_in(g_sig[SYNTH_LAYER_AUX].bus, BLOCK, g_mic_ep,
                    g_fx_state[SYNTH_LAYER_AUX]);
    t.mic = us_since(t0);

    t0 = stamp();
    for (int layer = 0; layer < SYNTH_NUM_LAYERS; layer++) {
        synth_fx_pan_capture(g_sig[layer].bus, BLOCK, g_pan_ep[layer], g_fx_state[layer]);
    }
    t.pan = us_since(t0);

    return t;
}

void publish_perc_env()
{
    /* The one-pole the audio task publishes with, so the rack's duck reads a number
     * that moves as it does on the board. */
    static float       env01 = 0.0f;
    static const float release =
        1.0f - expf(-((float)BLOCK / (float)SYNTH_SAMPLE_RATE) / 0.140f);

    const float now = synth_perc_env();
    if (now > env01) {
        env01 = now;
    } else {
        env01 += (now - env01) * release;
    }
    if (!(env01 > 0.0f)) {
        env01 = 0.0f;
    } else if (env01 > 1.0f) {
        env01 = 1.0f;
    }
    synth_dsp_set_perc_env(env01);
}

uint64_t g_block = 0;

/* Renders one block with the whole pipeline timed. */
BlockTimes render_block(bool account, const char *state)
{
    BlockTimes t = fill_layers(g_block);

    const uint64_t r0 = stamp();
    synth_rack_process(BLOCK, g_out);
    t.rack = us_since(r0);

    publish_perc_env();
    host_advance_us((int64_t)BLOCK_US);
    g_block++;

    if (account) {
        const int b = (int)(g_block - 1);
        part_add(P_CLEAR, t.clear, state, b);
        part_add(P_GEN, t.gen, state, b);
        part_add(P_DRONE, t.drone, state, b);
        part_add(P_LEAD, t.lead, state, b);
        part_add(P_MIC, t.mic, state, b);
        part_add(P_PAN, t.pan, state, b);
        part_add(P_RACK, t.rack, state, b);
    }

    return t;
}

/* -------------------------------------------------------------------------- */
/* Windows                                                                    */
/* -------------------------------------------------------------------------- */

/* One drum figure: `voices_wanted` hits at once, cycling through the velocities and
 * the ratios a sequencer or a hand would produce. */
void drum_figure(const Patch &p, int block)
{
    if (p.hits_every <= 0 || block % p.hits_every != 0) {
        return;
    }

    static const float ratios[] = { 0.5f, 0.75f, 1.0f, 1.5f, 2.0f, 3.0f, 4.0f };
    const int n = (block / p.hits_every) % 7;
    const int count = (p.voices_wanted > 0) ? p.voices_wanted : 1;
    for (int v = 0; v < count; v++) {
        synth_perc_trigger(0.55f + 0.40f * g_rng->unit(), ratios[(n + v) % 7]);
    }
}

/* A window of the full pipeline: WARM blocks to settle, then the measured ones. */
void window_pipeline(const Patch &p)
{
    patch_apply(p);
    for (int i = 0; i < WARM; i++) {
        drum_figure(p, i);
        render_block(false, p.name);
    }

    parts_reset();
    for (int i = 0; i < g_run; i++) {
        drum_figure(p, i + WARM);
        render_block(true, p.name);
    }
}

/*
 * A window of the rack alone, on the layer buses as the last pipeline block left
 * them. The cost of a block in the rack does not depend on which samples are in
 * those buses, and keeping them fixed is what makes an A/B difference a difference
 * of one part.
 */
double rack_window(const Patch &p, bool keep_voices)
{
    double sum = 0.0;

    for (int i = 0; i < WARM; i++) {
        if (keep_voices) {
            drum_figure(p, i);
        }
        render_block(false, "warm");
    }
    for (int i = 0; i < g_run; i++) {
        if (keep_voices) {
            drum_figure(p, i + WARM);
        }
        const uint64_t t0 = stamp();
        synth_rack_process(BLOCK, g_out);
        sum += us_since(t0);
        publish_perc_env();
        host_advance_us((int64_t)BLOCK_US);
        g_block++;
    }
    return sum / (double)g_run;
}

/* The rack with fewer than 128 samples. Every stage in it is linear in the count,
 * which is what makes the fixed part fall out of two points. */
double rack_window_n(int samples)
{
    double sum = 0.0;

    for (int i = 0; i < WARM; i++) {
        synth_rack_process(samples, g_out);
        host_advance_us((int64_t)((double)samples * 1.0e6 / (double)SYNTH_SAMPLE_RATE));
        g_block++;
    }
    for (int i = 0; i < g_run; i++) {
        const uint64_t t0 = stamp();
        synth_rack_process(samples, g_out);
        sum += us_since(t0);
        host_advance_us((int64_t)((double)samples * 1.0e6 / (double)SYNTH_SAMPLE_RATE));
        g_block++;
    }
    return sum / (double)g_run;
}

/*
 * The same window, with the distribution rather than the mean. A mean is what a
 * table needs; a p10/p50/p90/max is what says whether the mean is a cost or a
 * scheduler. The rescues are counted too: a rescue resets the effects' state, which
 * makes every block after it a different block.
 */
void probe_window(const char *label, int samples, int blocks)
{    std::vector<double> t;
    t.reserve((size_t)blocks);

    const uint32_t r0 = synth_rack_rescue_count();
    for (int i = 0; i < blocks; i++) {
        const uint64_t a = stamp();
        synth_rack_process(samples, g_out);
        t.push_back(us_since(a));
        host_advance_us((int64_t)((double)samples * 1.0e6 / (double)SYNTH_SAMPLE_RATE));
        g_block++;
    }
    std::sort(t.begin(), t.end());

    double sum = 0.0;
    for (double v : t) {
        sum += v;
    }
    std::printf("  %-26s n=%3d  mean %8.3f  p10 %8.3f  p50 %8.3f  p90 %8.3f  max %8.3f"
                "  rescues %u\n",
                label, samples, sum / (double)blocks, t[blocks / 10], t[blocks / 2],
                t[(blocks * 9) / 10], t[blocks - 1],
                (unsigned)(synth_rack_rescue_count() - r0));
}

/* Blocks with nothing timed, for a fade to finish or a pole to settle. */
void settle(int blocks)
{
    for (int i = 0; i < blocks; i++) {
        synth_rack_process(BLOCK, g_out);
        publish_perc_env();
        host_advance_us((int64_t)BLOCK_US);
        g_block++;
    }
}

/* -------------------------------------------------------------------------- */
/* One module at a time                                                       */
/* -------------------------------------------------------------------------- */

/*
 * A module's own cost, called the way the rack calls it: the same function, the same
 * 128 samples, on a send with something in it. The buffers are restored outside the
 * timed span, so what is measured is the module and not a feedback loop through the
 * bench's own memory.
 *
 * The chorus and the delay deserve a word, because the rack sets their mix to ONE and
 * uses the knob as a return level: they run at full wet whenever the rack has its
 * scratch, and a return at zero only silences them at the summing point. So there is
 * no switch that turns them off, and their cost is in every patch — which is exactly
 * why it is worth a row of its own.
 */
double time_stereo(void (*fn)(int, float *, float *), int blocks)
{
    double sum = 0.0;

    for (int i = 0; i < 20; i++) {
        std::memcpy(g_mod_l, g_mod_l0, sizeof(float) * BLOCK);
        std::memcpy(g_mod_r, g_mod_r0, sizeof(float) * BLOCK);
        fn(BLOCK, g_mod_l, g_mod_r);
    }

    for (int i = 0; i < blocks; i++) {
        std::memcpy(g_mod_l, g_mod_l0, sizeof(float) * BLOCK);
        std::memcpy(g_mod_r, g_mod_r0, sizeof(float) * BLOCK);

        const uint64_t t0 = stamp();
        fn(BLOCK, g_mod_l, g_mod_r);
        sum += us_since(t0);
    }
    return sum / (double)blocks;
}

/* The reverb and the plate read a mono send and write a stereo wet. */
double time_send(void (*fn)(int, const float *, float *, float *), int blocks)
{
    double sum = 0.0;

    for (int i = 0; i < 20; i++) {
        fn(BLOCK, g_mod_send, g_mod_wet_l, g_mod_wet_r);
    }

    for (int i = 0; i < blocks; i++) {
        const uint64_t t0 = stamp();
        fn(BLOCK, g_mod_send, g_mod_wet_l, g_mod_wet_r);
        sum += us_since(t0);
    }
    return sum / (double)blocks;
}

/*
 * The drum, on its own. Its cost is per ACTIVE VOICE, and a voice is only alive while
 * its tail is: so this is a figure with a hit every `every` blocks, which is what keeps
 * two or three of them ringing. `live` returns the count the figure settled at.
 */
double time_perc(const Patch &p, int every, int *live)
{
    static const float ratios[] = { 0.5f, 0.75f, 1.0f, 1.5f, 2.0f, 3.0f, 4.0f };

    std::memcpy(g_mod_l, g_mod_l0, sizeof(float) * BLOCK);
    std::memcpy(g_mod_r, g_mod_r0, sizeof(float) * BLOCK);

    synth_perc_reset_state();

    double sum = 0.0;
    for (int i = 0; i < g_run; i++) {
        std::memcpy(g_mod_l, g_mod_l0, sizeof(float) * BLOCK);
        std::memcpy(g_mod_r, g_mod_r0, sizeof(float) * BLOCK);

        if (every > 0 && i % every == 0) {
            synth_perc_trigger(0.55f + 0.40f * g_rng->unit(), ratios[(i / every) % 7]);
        }

        const uint64_t t0 = stamp();
        synth_perc_process(BLOCK, g_mod_l, g_mod_r, g_mod_send, p.perc_send,
                           g_mod_l, g_mod_r, p.perc_chr_send,
                           g_mod_l, g_mod_r, p.perc_dly_send);
        sum += us_since(t0);
    }
    if (live) {
        *live = synth_perc_active_voices();
    }
    return sum / (double)g_run;
}


/*
 * THE SHADOW OF A CLAIM.
 *
 * A claim task sleeps ten milliseconds between looks and then zeroes its line on the
 * core the audio task is not on. The block itself is not held, but the memory bus is
 * shared: this renders blocks in real time until the heap has stopped growing and
 * keeps the worst block, which is the part of a claim the audio task does feel.
 */
struct ClaimShadow {
    double   max_us;
    double   mean_us;
    int      blocks;
    int      heap_block;   /* block number at which the heap first grew */
    uint32_t heap_kb;
};

ClaimShadow claim_shadow(size_t heap0)
{
    ClaimShadow s{ 0.0, 0.0, 0, 0, 0 };
    const auto  t_end = std::chrono::steady_clock::now() + std::chrono::milliseconds(400);
    size_t      last  = host_heap_used();
    int         quiet = 0;

    while (std::chrono::steady_clock::now() < t_end && quiet < 8) {
        const auto  t0 = stamp();
        synth_rack_process(BLOCK, g_out);
        const double us = us_since(t0);
        publish_perc_env();
        host_advance_us((int64_t)BLOCK_US);
        g_block++;

        s.blocks++;
        s.mean_us += us;
        s.max_us = std::max(s.max_us, us);

        const size_t now = host_heap_used();
        if (now != last) {
            if (s.heap_block == 0) {
                s.heap_block = g_block;
            }
            quiet = 0;
        } else {
            quiet++;
        }
        last = now;

        std::this_thread::sleep_for(std::chrono::microseconds(200));
    }

    s.heap_kb = (uint32_t)((host_heap_used() - heap0) / 1024u);
    if (s.blocks > 0) {
        s.mean_us /= (double)s.blocks;
    }
    return s;
}

/* Renders in real time until the heap has stopped growing: the claim tasks are on the
 * other core and a claim is not done until it is done. Called before anything that
 * wants an effect at its steady cost. */
void wait_claim()
{
    size_t last  = host_heap_used();
    int    quiet = 0;

    while (quiet < 10) {
        synth_rack_process(BLOCK, g_out);
        publish_perc_env();
        host_advance_us((int64_t)BLOCK_US);
        g_block++;

        const size_t now = host_heap_used();
        quiet = (now == last) ? quiet + 1 : 0;
        last  = now;
        std::this_thread::sleep_for(std::chrono::microseconds(500));
    }
}

/* -------------------------------------------------------------------------- */
/* Report helpers                                                             */
/* -------------------------------------------------------------------------- */

struct Row {
    const char *name;
    double      us;
};

void print_rows(const char *title, const std::vector<Row> &rows, double total)
{
    if (title) {
        std::printf("\n== %s ==\n", title);
    }

    std::printf("  %-36s %10s %8s\n", "part", "us/block", "share");
    for (const Row &r : rows) {
        std::printf("  %-36s %10.3f %7.1f%%\n", r.name, r.us,
                    (total > 0.0) ? (100.0 * r.us / total) : 0.0);
    }
    std::printf("  %-36s %10.3f %7.1f%%\n", "TOTAL", total, (total > 0.0) ? 100.0 : 0.0);
}

/* -------------------------------------------------------------------------- */
/* Outliers: the drum                                                         */
/* -------------------------------------------------------------------------- */

/* The state builders live at the end of the file, beside the table they feed. */
Patch patch_empty();
Patch patch_effects();
Patch patch_effects_quiet();

/*
 * THE FIRST HIT ON A VOICE, and what three voices cost.
 *
 * A strike latches the knobs into the voice, clears its two resonant sections and
 * starts an attack; a hit that steals a voice that is still ringing fades the old
 * tail first. None of that is visible in a mean, so the first four blocks after the
 * first strike are printed one by one, then the same rack with one voice ringing and
 * with three.
 */
/* Best-of-N, because a window's mean is a cost plus whatever the scheduler did to it.
 * The minimum is the closest thing to the cost itself. */
double best_rack(const Patch &p, bool keep_voices, int reps)
{
    double best = 1.0e9;
    for (int i = 0; i < reps; i++) {
        best = std::min(best, rack_window(p, keep_voices));
    }
    return best;
}

double best_stereo(void (*fn)(int, float *, float *), int reps)
{
    double best = 1.0e9;
    for (int i = 0; i < reps; i++) {
        best = std::min(best, time_stereo(fn, g_run));
    }
    return best;
}

double best_send(void (*fn)(int, const float *, float *, float *), int reps)
{
    double best = 1.0e9;
    for (int i = 0; i < reps; i++) {
        best = std::min(best, time_send(fn, g_run));
    }
    return best;
}

/* A module that has just been reset or switched is not the module the rack pays for:
 * its line is dirty until the task that owns it has finished clearing, and the audio
 * path answers blocks with the line's silence until then. Give it real time first. */
void module_settle(void (*fn)(int, float *, float *), int ms)
{
    for (int i = 0; i < ms; i++) {
        std::memcpy(g_mod_l, g_mod_l0, sizeof(float) * BLOCK);
        std::memcpy(g_mod_r, g_mod_r0, sizeof(float) * BLOCK);
        fn(BLOCK, g_mod_l, g_mod_r);
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
}

void module_settle_send(void (*fn)(int, const float *, float *, float *), int ms)
{
    for (int i = 0; i < ms; i++) {
        fn(BLOCK, g_mod_send, g_mod_wet_l, g_mod_wet_r);
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
}

double best_perc(const Patch &p, int every, int *live)
{
    double best = 1.0e9;
    for (int i = 0; i < 3; i++) {
        best = std::min(best, time_perc(p, every, live));
    }
    return best;
}

/* An effect whose line is still being cleared answers blocks with silence, which is a
 * much cheaper block than the one the rack pays for later. A module is only priced once
 * it is making sound. */
bool module_alive(void (*fn)(int, float *, float *))
{
    std::memcpy(g_mod_l, g_mod_l0, sizeof(float) * BLOCK);
    std::memcpy(g_mod_r, g_mod_r0, sizeof(float) * BLOCK);
    fn(BLOCK, g_mod_l, g_mod_r);

    /* A module that returned early left the send where it found it; one that ran wrote
     * its wet over it. Equal buffers mean the block was the bypass, not the effect. */
    for (int i = 0; i < BLOCK; i++) {
        if (g_mod_l[i] != g_mod_l0[i] || g_mod_r[i] != g_mod_r0[i]) {
            return true;
        }
    }
    return false;
}

bool module_alive_send(void (*fn)(int, const float *, float *, float *))
{
    std::memset(g_mod_wet_l, 0, sizeof(float) * BLOCK);
    std::memset(g_mod_wet_r, 0, sizeof(float) * BLOCK);
    fn(BLOCK, g_mod_send, g_mod_wet_l, g_mod_wet_r);

    for (int i = 0; i < BLOCK; i++) {
        if (g_mod_wet_l[i] != 0.0f || g_mod_wet_r[i] != 0.0f) {
            return true;
        }
    }
    return false;
}

/* Up to a second of real time for a module to answer with sound. Returns false if it
 * never did, which is itself a result: the line was never cleared. */
bool wait_alive(void (*fn)(int, float *, float *), int ms)
{
    for (int i = 0; i < ms; i += 10) {
        if (module_alive(fn)) {
            return true;
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
    return false;
}

bool wait_alive_send(void (*fn)(int, const float *, float *, float *), int ms)
{
    for (int i = 0; i < ms; i += 10) {
        if (module_alive_send(fn)) {
            return true;
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
    return false;
}

void experiment_percussion()
{
    std::printf("\n== percussion: the first hit, and the voices it rings ==\n");

    Patch p = patch_effects();
    p.perc_level = 0.85f;
    p.perc_decay = 0.55f;
    p.hits_every = 0;
    patch_apply(p);

    const double idle = best_perc(p, 0, nullptr);

    /* The strike itself: the first six blocks after the first hit on a voice, timed on
     * the drum's own call so the rack's gate and its neighbours are not in the number. */
    synth_perc_reset_state();
    synth_perc_trigger(0.90f, 1.0f);
    double series[6];
    int    voices[6];
    for (int i = 0; i < 6; i++) {
        std::memcpy(g_mod_l, g_mod_l0, sizeof(float) * BLOCK);
        std::memcpy(g_mod_r, g_mod_r0, sizeof(float) * BLOCK);

        const uint64_t t0 = stamp();
        synth_perc_process(BLOCK, g_mod_l, g_mod_r, g_mod_send, p.perc_send,
                           g_mod_l, g_mod_r, p.perc_chr_send,
                           g_mod_l, g_mod_r, p.perc_dly_send);
        series[i] = us_since(t0);
        voices[i] = synth_perc_active_voices();
    }

    /* A figure with a hit every four blocks: three voices accumulate, and then each
     * new hit steals the quietest — a drum being played, which is the case with the
     * most work in it. */
    int    live_one = 0;
    int    live_three = 0;
    const double figure = best_perc(p, 4, &live_three);
    p.hits_every = 12;
    const double sparse = best_perc(p, 12, &live_one);

    std::printf("  idle, no voice     %8.3f us/block\n", idle);
    for (int i = 0; i < 6; i++) {
        std::printf("  hit + %-2d block(s)  %8.3f us   (voices %d)\n",
                    i + 1, series[i], voices[i]);
    }
    std::printf("  a hit every 4     %8.3f us/block  (+%6.3f, %d voices)\n",
                figure, figure - idle, live_three);
    std::printf("  a hit every 12    %8.3f us/block  (+%6.3f, %d voices)\n",
                sparse, sparse - idle, live_one);
}

/* -------------------------------------------------------------------------- */
/* Outliers: first use of an effect                                           */
/* -------------------------------------------------------------------------- */

/* The sine table the chorus builds inside its first block, timed on the same 1026
 * entries it fills: sinf is a library routine here and a software routine on the
 * chip, which is why the number is only useful as a ratio. */
double time_sine_table()
{
    const uint64_t t0 = stamp();
    for (int i = 0; i < 1026; i++) {
        g_sine[i & (SINE_SIZE - 1)] = sinf(2.0f * 3.14159265358979f * (float)i / 1024.0f);
    }
    return us_since(t0);
}

/* -------------------------------------------------------------------------- */
/* The claims                                                                 */
/* -------------------------------------------------------------------------- */

/*
 * WHAT A CLAIM DOES TO THE BLOCKS BESIDE IT.
 *
 * Every effect claims its memory the first time a mix or a send stops being zero,
 * because claiming at boot stopped the Wi-Fi driver from starting. Three of them hand
 * the zeroing of their line to a task on the other core; the chorus does not, and it
 * also fills a thousand-entry sine table inside the same block it is first called in.
 *
 * On this machine all four claims land within the first second of the run, so the
 * columns below are three facts and not four: what the rack cost before the module was
 * asked for, what it costs with the module settled, and the worst block seen while the
 * heap was still growing. The worst block is the whole storm's, not one module's — but
 * it is the storm that matters, because that is what a block has to fit inside.
 */
void experiment_first_use()
{
    std::printf("\n== the claims: the blocks beside a first use, and the clearing ==\n");
    std::printf("  %-8s %10s %10s %10s %10s\n",
                "module", "before us", "steady us", "worst us", "claim KB");

    static const char *const names[4] = { "chorus", "delay", "reverb", "plate" };

    for (int fx = 0; fx < 4; fx++) {
        const size_t   heap0  = host_heap_used();
        const uint64_t block0 = g_block;
        const double   before = best_rack(g_patch, false, 2);
        std::vector<double> series;

        switch (fx) {
        case 0:
            synth_rack_set_chorus(0.6f, 0.35f, 0.20f);
            break;
        case 1:
            synth_rack_set_delay(12000.0f, 0.35f, 0.20f, true);
            break;
        case 2:
            synth_rack_set_reverb(0.5f, 0.4f, 0.20f, SYNTH_REVERB_HALL);
            break;
        case 3:
            synth_rack_set_reverb(0.5f, 0.4f, 0.20f, SYNTH_REVERB_PLATE);
            break;
        }

        for (int i = 0; i < 60; i++) {
            const uint64_t t0 = stamp();
            synth_rack_process(BLOCK, g_out);
            const double us = us_since(t0);
            publish_perc_env();
            host_advance_us((int64_t)BLOCK_US);
            g_block++;

            if (i < 6) {
                series.push_back(us);
            }
        }

        const ClaimShadow shadow = claim_shadow(heap0);
        const double steady = best_rack(g_patch, false, 2);

        std::printf("  %-8s %10.3f %10.3f %10.3f %10.1f\n", names[fx], before, steady,
                    shadow.max_us, (double)(host_heap_used() - heap0) / 1024.0);
        std::printf("    first blocks us:");
        for (double v : series) {
            std::printf(" %.1f", v);
        }
        std::printf("\n");

        g_patch = patch_effects_quiet();
        patch_apply(g_patch);
        settle(40);
    }

    double sine_us = 1.0e9;
    for (int i = 0; i < 3; i++) {
        sine_us = std::min(sine_us, time_sine_table());
    }
    std::printf("  the chorus builds 1026 sine entries in its first block: %.1f us here\n",
                sine_us);
    std::printf("  every line above is cleared off the audio core; the block that pays is\n"
                "  the one whose memory bus is busy, not the one that asked for the line.\n");
}

void experiment_delay_change()
{
    std::printf("\n== delay: a change of time, in both modes ==\n");

    Patch p = patch_effects();
    for (int i = 0; i < SYNTH_NUM_LAYERS; i++) {
        p.dly_send[i] = 0.15f;
    }
    p.delay_time = 12000.0f;
    p.delay_fb = 0.40f;
    p.delay_mix = 0.25f;
    p.delay_xfade = true;
    p.hits_every = 0;
    patch_apply(p);
    wait_claim();
    settle(120);

    const double steady = best_rack(p, false, 2);

    /* Crossfade to the longest time the line addresses. */
    synth_rack_set_delay(191000.0f, p.delay_fb, p.delay_mix, true);
    double xfade_peak = 0.0;
    double xfade_sum = 0.0;
    for (int i = 0; i < 30; i++) {
        const uint64_t t0 = stamp();
        synth_rack_process(BLOCK, g_out);
        const double us = us_since(t0);
        xfade_peak = std::max(xfade_peak, us);
        if (i < 12) {
            xfade_sum += us;
        }
        publish_perc_env();
        host_advance_us((int64_t)BLOCK_US);
        g_block++;
    }
    settle(100);
    const double long_steady = best_rack(p, false, 2);

    /* Back to the short time, then the tape mode with a small change: a thousand
     * samples of jump arrives in about sixteen blocks at the ceiling. */
    synth_rack_set_delay(12000.0f, p.delay_fb, p.delay_mix, true);
    settle(100);
    synth_rack_set_delay(13000.0f, p.delay_fb, p.delay_mix, false);
    double tape_peak = 0.0;
    double tape_sum = 0.0;
    for (int i = 0; i < 40; i++) {
        const uint64_t t0 = stamp();
        synth_rack_process(BLOCK, g_out);
        const double us = us_since(t0);
        tape_peak = std::max(tape_peak, us);
        if (i < 20) {
            tape_sum += us;
        }
        publish_perc_env();
        host_advance_us((int64_t)BLOCK_US);
        g_block++;
    }

    std::printf("  steady, 250 ms        %8.3f us/block\n", steady);
    std::printf("  crossfade, 12 blocks  %8.3f us/block, peak %8.3f\n",
                xfade_sum / 12.0, xfade_peak);
    std::printf("  steady, 3.98 s        %8.3f us/block\n", long_steady);
    std::printf("  tape slew, 20 blocks  %8.3f us/block, peak %8.3f\n",
                tape_sum / 20.0, tape_peak);
}

/* -------------------------------------------------------------------------- */
/* Outliers: how long the line is                                             */
/* -------------------------------------------------------------------------- */

/*
 * One delay line is four seconds a side whatever the knob says — the line is cut
 * once, at the maximum, because a line that grew would have to be cleared while it
 * was being read. So the knob does not change the footprint, it changes the DISTANCE
 * a read reaches back, and with it how much of the line is in cache. On this machine
 * that is an L2/L3 question; on the board it is PSRAM, where this is the experiment
 * worth repeating.
 */
void experiment_delay_length()
{
    std::printf("\n== delay: cost against the distance read back ==\n");
    std::printf("  %12s %14s %14s %14s\n", "delay, samp", "us/block", "median us", "max us");

    Patch p = patch_effects();
    p.hits_every = 0;
    patch_apply(p);

    static const float times[] = { 96.0f, 1200.0f, 4800.0f, 12000.0f,
                                   48000.0f, 96000.0f, 191000.0f };

    synth_delay_set_mode(true);

    /* The line is claimed and cleared off the audio core; a window taken before that is
     * a window of the bypass path. */
    synth_delay_set(191000.0f, 0.40f, 0.25f);
    wait_alive(synth_delay_process, 3000);

    for (float t : times) {
        synth_delay_set(t, 0.40f, 0.25f);
        /* The crossfade moves the pointer in one step; give the claim and the fade
         * real time, then settle the line. */
        for (int i = 0; i < 150; i++) {
            std::memcpy(g_mod_l, g_mod_l0, sizeof(float) * BLOCK);
            std::memcpy(g_mod_r, g_mod_r0, sizeof(float) * BLOCK);
            synth_delay_process(BLOCK, g_mod_l, g_mod_r);
            std::this_thread::sleep_for(std::chrono::milliseconds(1));
        }
        for (int i = 0; i < 150; i++) {
            std::memcpy(g_mod_l, g_mod_l0, sizeof(float) * BLOCK);
            std::memcpy(g_mod_r, g_mod_r0, sizeof(float) * BLOCK);
            synth_delay_process(BLOCK, g_mod_l, g_mod_r);
        }

        std::vector<double> t_us;
        t_us.reserve(400);
        for (int i = 0; i < 400; i++) {
            std::memcpy(g_mod_l, g_mod_l0, sizeof(float) * BLOCK);
            std::memcpy(g_mod_r, g_mod_r0, sizeof(float) * BLOCK);

            const uint64_t t0 = stamp();
            synth_delay_process(BLOCK, g_mod_l, g_mod_r);
            t_us.push_back(us_since(t0));
        }
        std::sort(t_us.begin(), t_us.end());
        double sum = 0.0;
        for (double v : t_us) {
            sum += v;
        }
        std::printf("  %12.0f %14.3f %14.3f %14.3f\n", (double)t, sum / (double)t_us.size(),
                    t_us[t_us.size() / 2], t_us.back());
    }
}

/* -------------------------------------------------------------------------- */
/* Reverb modes                                                               */
/* -------------------------------------------------------------------------- */

void experiment_reverb_modes()
{
    std::printf("\n== reverb: the four algorithms ==\n");
    std::printf("  %-12s %12s %12s\n", "mode", "us/block", "max us");

    std::vector<float> send(BLOCK);
    std::vector<float> wet_l(BLOCK);
    std::vector<float> wet_r(BLOCK);
    for (int i = 0; i < BLOCK; i++) {
        send[i] = 0.10f * sine_at((float)i / (float)BLOCK);
    }

    static const struct { const char *name; int mode; } modes[] = {
        { "room",      SYNTH_REVERB_ROOM },
        { "hall",      SYNTH_REVERB_HALL },
        { "cathedral", SYNTH_REVERB_CATHEDRAL },
    };

    auto time_one = [&](void (*fn)(int, const float *, float *, float *)) {
        double sum = 0.0;
        double peak = 0.0;
        for (int i = 0; i < 400; i++) {
            const uint64_t t0 = stamp();
            fn(BLOCK, send.data(), wet_l.data(), wet_r.data());
            const double us = us_since(t0);
            sum += us;
            peak = std::max(peak, us);
        }
        return std::pair<double, double>(sum / 400.0, peak);
    };

    for (const auto &m : modes) {
        synth_reverb_set(0.5f, 0.4f, 0.25f, m.mode);
        /* The claim is off-core: give it real time and settle the room. */
        for (int i = 0; i < 300; i++) {
            synth_reverb_process(BLOCK, send.data(), wet_l.data(), wet_r.data());
            std::this_thread::sleep_for(std::chrono::milliseconds(1));
        }
        for (int i = 0; i < 300; i++) {
            synth_reverb_process(BLOCK, send.data(), wet_l.data(), wet_r.data());
        }
        const auto r = time_one(synth_reverb_process);
        std::printf("  %-12s %12.3f %12.3f\n", m.name, r.first, r.second);
    }

    synth_plate_set(0.5f, 0.4f, 0.25f);
    for (int i = 0; i < 300; i++) {
        synth_plate_process(BLOCK, send.data(), wet_l.data(), wet_r.data());
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
    for (int i = 0; i < 300; i++) {
        synth_plate_process(BLOCK, send.data(), wet_l.data(), wet_r.data());
    }
    const auto r = time_one(synth_plate_process);
    std::printf("  %-12s %12.3f %12.3f\n", "plate", r.first, r.second);
}

/* -------------------------------------------------------------------------- */
/* The protections                                                           */
/* -------------------------------------------------------------------------- */

/*
 * THE FUSE AND THE SILENCE WATCHDOG, and everything else a block pays for once.
 *
 * Both are once per block by design: the fuse reads the last mixed sample and the two
 * gains that multiply it, and the watchdog reads the forty-one points the scope
 * decimation already visits. Neither can be switched off from outside, but both are
 * FIXED — they do not scale with the sample count — while every other stage in the
 * rack does. Two windows at different lengths therefore split the rack into a fixed
 * part and a rate, and the fixed part is what they cost.
 */
struct FixedCost {
    double fixed_us;
    double per_sample_us;
};

FixedCost fit_fixed(int samples_a, int samples_b, double a, double b)
{
    FixedCost f;
    const double dx = (double)(samples_b - samples_a);
    f.per_sample_us = (dx != 0.0) ? (b - a) / dx : 0.0;
    f.fixed_us = a - f.per_sample_us * (double)samples_a;
    return f;
}

/* Least squares over every length measured. Two points put the whole fit on the
 * difference of two noisy windows; four put most of it on the slope, which is what a
 * fit of a straight line should be doing. */
FixedCost fit_fixed_ls(const int *samples, const double *us, int count)
{
    double sx = 0.0;
    double sy = 0.0;
    double sxx = 0.0;
    double sxy = 0.0;

    for (int i = 0; i < count; i++) {
        const double x = (double)samples[i];
        sx += x;
        sy += us[i];
        sxx += x * x;
        sxy += x * us[i];
    }

    const double n = (double)count;
    const double den = n * sxx - sx * sx;

    FixedCost f{ 0.0, 0.0 };
    if (den != 0.0) {
        f.per_sample_us = (n * sxy - sx * sy) / den;
        f.fixed_us = (sy - f.per_sample_us * sx) / n;
    }
    return f;
}

void experiment_protections()
{
    std::printf("\n== the fuse and the silence watchdog: the block's fixed cost ==\n");

    Patch quiet = patch_effects_quiet();
    patch_apply(quiet);
    settle(80);

    std::printf("  %-26s %14s %14s\n", "samples", "us/block", "us/sample");
    static const int lens[] = { 32, 64, 96, 128 };
    double t[4] = { 0.0, 0.0, 0.0, 0.0 };
    for (int i = 0; i < 4; i++) {
        for (int rep = 0; rep < 2; rep++) {
            const double v = rack_window_n(lens[i]);
            t[i] = (t[i] == 0.0) ? v : std::min(t[i], v);
        }
        std::printf("  %-26d %14.3f %14.4f\n", lens[i], t[i], t[i] / (double)lens[i]);
    }

    const FixedCost dry = fit_fixed_ls(lens, t, 4);

    Patch full = quiet;
    for (int i = 0; i < SYNTH_NUM_LAYERS; i++) {
        full.rev_send[i] = 0.15f;
        full.chr_send[i] = 0.10f;
        full.dly_send[i] = 0.10f;
    }
    full.chorus_mix = 0.20f;
    full.delay_mix = 0.20f;
    full.reverb_mix = 0.20f;
    full.comp = 0.15f;
    patch_apply(full);
    settle(120);

    double w[4] = { 0.0, 0.0, 0.0, 0.0 };
    for (int i = 0; i < 4; i++) {
        for (int rep = 0; rep < 2; rep++) {
            const double v = rack_window_n(lens[i]);
            w[i] = (w[i] == 0.0) ? v : std::min(w[i], v);
        }
    }
    const FixedCost wet = fit_fixed_ls(lens, w, 4);

    std::printf("  dry path:  fixed %8.3f us + %8.5f us/sample = %8.3f us a block\n",
                dry.fixed_us, dry.per_sample_us,
                dry.fixed_us + dry.per_sample_us * (double)BLOCK);
    std::printf("  with fx:   fixed %8.3f us + %8.5f us/sample = %8.3f us a block\n",
                wet.fixed_us, wet.per_sample_us,
                wet.fixed_us + wet.per_sample_us * (double)BLOCK);
    std::printf("  on the board, as last measured: 277 cycles = %.2f us at 240 MHz\n",
                277.0 / 240.0);
}

/* -------------------------------------------------------------------------- */
/* The states                                                                 */
/* -------------------------------------------------------------------------- */

Patch patch_empty()
{
    Patch p{};
    p.name = "empty";
    for (int i = 0; i < SYNTH_NUM_LAYERS; i++) {
        p.layer_level[i] = 0.85f;
    }
    p.master = 0.90f;
    p.chorus_rate = 0.60f;
    p.chorus_depth = 0.35f;
    p.delay_time = 12000.0f;
    p.delay_fb = 0.35f;
    p.delay_xfade = true;
    p.reverb_size = 0.50f;
    p.reverb_damp = 0.40f;
    p.reverb_mode = SYNTH_REVERB_HALL;
    p.perc_pitch = 0.35f;
    p.perc_reso = 0.35f;
    p.perc_decay = 0.40f;
    p.perc_env = 0.45f;
    p.perc_body = 0.30f;
    p.gate = 1;
    p.transport = 1;
    return p;
}

/* The same patch with nothing sent anywhere: no effect is asked for by it, which is
 * what makes it the base for a first-use experiment. */
Patch patch_effects_quiet()
{
    Patch p = patch_empty();
    p.name = "quiet";
    p.comp = 0.0f;
    p.duck = 0.0f;
    p.hits_every = 0;
    return p;
}

Patch patch_effects()
{
    Patch p = patch_empty();
    p.name = "effects";
    for (int i = 0; i < SYNTH_NUM_LAYERS; i++) {
        p.rev_send[i] = 0.15f + 0.05f * (float)i;
        p.chr_send[i] = (i >= 3) ? 0.20f : 0.10f;
        p.dly_send[i] = (i >= 3) ? 0.18f : 0.08f;
    }
    p.comp = 0.15f;
    p.duck = 0.20f;
    p.chorus_mix = 0.25f;
    p.delay_mix = 0.22f;
    p.reverb_mix = 0.25f;
    p.perc_send = 0.15f;
    p.perc_chr_send = 0.10f;
    p.perc_dly_send = 0.10f;
    return p;
}

Patch patch_fast()
{
    /* A fast figure with a short, crossfaded delay and every send open: the patch with
     * the most switching happening per second. The drive used to be part of this one and
     * is out of the instrument, which only makes the figure cheaper than it priced. */
    Patch p = patch_effects();
    p.name = "fast + short delay";
    for (int i = 0; i < SYNTH_NUM_LAYERS; i++) {
        p.rev_send[i] = 0.10f;
        p.chr_send[i] = 0.14f;
        p.dly_send[i] = 0.20f;
    }
    p.delay_time = 3600.0f;    /* 1/16 at 200 bpm */
    p.delay_fb = 0.45f;
    p.delay_mix = 0.28f;
    p.delay_xfade = true;
    p.chorus_mix = 0.20f;
    p.reverb_mix = 0.18f;
    p.reverb_mode = SYNTH_REVERB_ROOM;
    p.comp = 0.20f;
    return p;
}

Patch patch_long()
{
    Patch p = patch_effects();
    p.name = "long delay (4 s)";
    p.delay_time = 191000.0f;
    p.delay_fb = 0.50f;
    p.delay_mix = 0.25f;
    p.delay_xfade = true;   /* the jump to four seconds is immediate, not a slew */
    p.reverb_mode = SYNTH_REVERB_HALL;
    return p;
}

Patch patch_perc()
{
    Patch p = patch_effects();
    p.name = "percussion";
    p.hits_every = 4;      /* a hit every four blocks: three voices stay ringing */
    p.perc_level = 0.85f;
    p.perc_decay = 0.55f;
    p.perc_body = 0.40f;
    p.perc_send = 0.18f;
    return p;
}

Patch patch_max()
{
    /* Everything at once: five layers at full level and full sends, three returns,
     * the compressor, the duck, and the drum with three
     * voices. The engine's own polyphony is not here — see the header. */
    Patch p = patch_effects();
    p.name = "max polyphony";
    for (int i = 0; i < SYNTH_NUM_LAYERS; i++) {
        p.layer_level[i] = 1.0f;
        p.rev_send[i] = 0.30f;
        p.chr_send[i] = 0.25f;
        p.dly_send[i] = 0.25f;
    }
    p.master = 0.95f;
    p.comp = 0.30f;
    p.duck = 0.30f;
    p.chorus_mix = 0.30f;
    p.delay_mix = 0.30f;
    p.reverb_mix = 0.30f;
    p.reverb_mode = SYNTH_REVERB_PLATE;
    p.hits_every = 4;
    p.perc_level = 0.90f;
    return p;
}

/*
 * One state, priced.
 *
 * The pipeline window gives the rows that can be timed from outside. The rack's
 * insides are then priced one at a time: the three returns on their own functions,
 * the drum on its own function, the compressor as the rack's own
 * difference between its on and off positions — every one of those is a position
 * the API already offers, so nothing here is a special build. The residual is what no
 * switch reaches: the sum of the five layers and their four buses, the gate ramp, the
 * returns' sum, the fader glide, the master and the clip.
 */
void run_state(const Patch &p)
{
    std::printf("\n== patch: %s ==\n", p.name);

    const uint32_t rescues0 = synth_rack_rescue_count();
    window_pipeline(p);

    const double clear = part_mean(P_CLEAR);
    const double gen = part_mean(P_GEN);
    const double drone = part_mean(P_DRONE);
    const double lead = part_mean(P_LEAD);
    const double mic = part_mean(P_MIC);
    const double pan = part_mean(P_PAN);

    const bool voices = (p.hits_every > 0);

    patch_apply(p);
    settle(WARM);

    /* The rack's own total, taken the same way as the parts inside it: a window of the
     * rack alone, best of two, so that the residual is a difference of like numbers. */
    const double rack_total = best_rack(p, voices, 2);

    int    live = 0;
    module_settle(synth_chorus_process, 30);
    module_settle(synth_delay_process, 120);
    if (p.reverb_mix > 0.0f) {
        module_settle_send(synth_reverb_process, 120);
    }

    const bool chorus_ok = wait_alive(synth_chorus_process, 500);
    const bool delay_ok = wait_alive(synth_delay_process, 1000);
    const bool reverb_ok = (p.reverb_mix > 0.0f) ? wait_alive_send(synth_reverb_process, 1000)
                                                 : false;

    const double c_chorus = chorus_ok ? best_stereo(synth_chorus_process, 2) : 0.0;
    const double c_delay = delay_ok ? best_stereo(synth_delay_process, 2) : 0.0;
    const double c_reverb = reverb_ok ? best_send(synth_reverb_process, 2) : 0.0;
    const double c_perc = voices ? (best_perc(p, p.hits_every, &live) - best_perc(p, 0, nullptr))
                                 : 0.0;

    double c_comp = 0.0;
    if (p.comp > 0.0f) {
        Patch q = p;
        q.comp = 0.0f;
        patch_apply(q);
        c_comp = rack_total - best_rack(q, voices, 2);
    }

    /* The fixed part of the block in this patch's configuration, with the drum back at
     * idle so its per-sample work cannot land in the intercept. */
    synth_perc_reset_state();
    patch_apply(p);
    settle(WARM);
    static const int lens[] = { 32, 64, 96, 128 };
    double t[4] = { 0.0, 0.0, 0.0, 0.0 };
    for (int i = 0; i < 4; i++) {
        for (int rep = 0; rep < 2; rep++) {
            const double v = rack_window_n(lens[i]);
            t[i] = (t[i] == 0.0) ? v : std::min(t[i], v);
        }
    }
    const FixedCost fit = fit_fixed_ls(lens, t, 4);
    const double fixed = fit.fixed_us;

    const double residual = rack_total - c_chorus - c_delay - c_reverb
                          - c_comp - c_perc - fixed;

    const double total = clear + gen + drone + lead + mic + pan + rack_total;

    const std::vector<Row> rows = {
        { PART_NAME[P_GEN], gen },
        { PART_NAME[P_CLEAR], clear },
        { PART_NAME[P_DRONE], drone },
        { PART_NAME[P_LEAD], lead },
        { PART_NAME[P_MIC], mic },
        { PART_NAME[P_PAN], pan },
        { "rack: chorus", c_chorus },
        { "rack: delay", c_delay },
        { "rack: reverb", c_reverb },
        { "rack: percussion", c_perc },
        { "rack: compressor", c_comp },
        { "rack: fuse + watchdog", fixed },
        { "rack: sum, gate, master, clip", residual },
    };

    print_rows(nullptr, rows, total);
    std::printf("  block total %.3f us of %.1f us (%.1f%%), rack %.3f us\n",
                total, BLOCK_US, 100.0 * total / BLOCK_US, rack_total);
    std::printf("  rack: %.5f us/sample after the fixed part, drum voices %d%s\n",
                fit.per_sample_us, live, voices ? "" : " (not played)");
    const uint32_t rescues = synth_rack_rescue_count() - rescues0;
    if (rescues > 0) {
        std::printf("  !! %u rescue(s) in this patch: the numbers above are after a reset\n",
                    (unsigned)rescues);
    }
}
} // namespace

/* -------------------------------------------------------------------------- */
/* main                                                                       */
/* -------------------------------------------------------------------------- */

int main(int argc, char **argv)
{
    std::setvbuf(stdout, nullptr, _IONBF, 0);
    std::setvbuf(stderr, nullptr, _IONBF, 0);

    uint32_t seed = 1;
    bool     probe = false;

    for (int i = 1; i < argc; i++) {
        const char *a = argv[i];
        if (std::strcmp(a, "--probe") == 0) {
            probe = true;
        } else if (std::strcmp(a, "--seed") == 0 && i + 1 < argc) {
            seed = (uint32_t)std::strtoul(argv[++i], nullptr, 0);
        } else if (std::strcmp(a, "--blocks") == 0 && i + 1 < argc) {
            g_run = (int)std::strtol(argv[++i], nullptr, 0);
            if (g_run < 40) {
                g_run = 40;
            }
        } else if (std::strcmp(a, "--help") == 0 || std::strcmp(a, "-h") == 0) {
            std::printf("usage: %s [--seed N] [--blocks N] [--probe]\n\n"
                        "  --blocks N  blocks in a measured window (default %d)\n"
                        "  --seed N    seed of the stand-in generator (default 1)\n"
                        "  --probe     only the length sweep, windows in a fixed order:\n"
                        "              the check that the measurement is not drifting\n",
                        argv[0], RUN);
            return 0;
        } else {
            std::fprintf(stderr, "%s: unknown option %s (try --help)\n", argv[0], a);
            return 1;
        }
    }

    calibrate_clock();
    sine_table_init();
    host_platform_init();
    g_probe = probe;

    std::printf("host audio profile: %d Hz, %d-sample blocks (%.1f us of audio), "
                "%d blocks a window\n", SYNTH_SAMPLE_RATE, BLOCK, BLOCK_US, g_run);
    std::printf("clock: %.4f us per timestamp (subtracted), %.0f ticks/us\n",
                g_stamp_us, 1.0 / g_us_per_tick);

    synth_dsp_init(SYNTH_SAMPLE_RATE);
    synth_drone_lfo_trig(0);
    synth_dsp_set_mic_env(0.0f, false);
    synth_dsp_set_perc_env(0.0f);

    g_rng = new Rng(seed);
    signal_init();
    parts_reset_maxima();

    /*
     * The layer buses are filled ONCE and then left alone. Every window that times the
     * rack alone reads them as they are, and they must not be silent: the rack's own
     * silence watchdog would then fire a second into a window, reset every effect, and
     * turn the next blocks into a claim task's memsets. That failure mode was found
     * this way, and it is the same one the instrument has.
     */
    fill_layers(0);

    /* The base the states are built from. It asks no effect for anything, which is
     * what leaves the first-use experiment its first use: nothing has claimed its
     * memory yet, exactly as on a board that has just booted. */
    g_patch = patch_effects_quiet();
    patch_apply(g_patch);

    if (g_probe) {
        std::printf("\n-- probe: the same patch, windows in this order\n");
        settle(80);
        for (int n : { 128, 64, 128, 32, 128, 96, 128, 16, 128 }) {
            probe_window("dry", n, g_run);
        }
        return 0;
    }

    experiment_first_use();
    experiment_percussion();
    experiment_delay_change();
    experiment_delay_length();
    experiment_reverb_modes();
    experiment_protections();

    /* The experiments have left mixes and modes everywhere; put the effects back on
     * a settled patch and clear what they have in their lines. */
    g_patch = patch_effects();
    patch_apply(g_patch);
    settle(120);
    synth_delay_reset_state();
    synth_reverb_reset_state();
    for (int i = 0; i < 120; i++) {
        settle(1);
        std::this_thread::sleep_for(std::chrono::milliseconds(2));
    }
    settle(120);

    const Patch states[] = {
        patch_empty(),
        patch_effects(),
        patch_fast(),
        patch_long(),
        patch_perc(),
        patch_max(),
    };

    for (const Patch &p : states) {
        run_state(p);
    }

    std::printf("\n== maxima over every patch ==\n");
    std::printf("  %-36s %10s   %s\n", "part", "max us", "where");
    for (int i = 0; i < P_COUNT; i++) {
        std::printf("  %-36s %10.3f   %s\n", PART_NAME[i], g_part_max[i].max_us,
                    g_part_max[i].max_where);
    }
    std::printf("  rack maxima are the whole rack; the parts inside it are in the "
                "sections above.\n");

    return 0;
}
