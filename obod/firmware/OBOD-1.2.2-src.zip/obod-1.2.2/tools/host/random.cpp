/*
 * Host test for the random draw.
 *
 * This compiles the SAME header the firmware compiles — synth_random_math.h — with the
 * same constants (base 300 Hz on the low register, the cutoff's floor and ceiling, the
 * three-octave sweep) and a seeded generator, and draws a hundred thousand patches
 * through the same functions, in the same order the application calls them. What it
 * checks is not that the numbers look nice; it is that the rules hold on every draw:
 *
 *   no patch is muddy: a corner under 250 Hz, Q over 3.2 and a sweep over 2.4 octaves
 *   together is the combination that sounds like a blocked filter;
 *
 *   the wet mixes never add up to more than one full level;
 *
 *   the drum is always a degree of the chosen scale;
 *
 *   the drum is never a second or a seventh against the drone's middle register;
 *
 *   the drum holds the bottom when the corner takes it away;
 *
 *   every drawn figure has a pulse on its first step;
 *
 *   the shapes really do vary: the filter's mode, the lead's waveform and the room are
 *   drawn on every patch, so two draws differ by more than their numbers;
 *
 *   and the draws are far enough apart to be heard as different patches.
 *
 * Build: tools/random-check.ps1 compiles this file with the same zig the other host
 * benches use, and also checks that the draw never writes the drive.
 */
#include "../../components/synth_app/src/synth_random_math.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* The firmware's constants, repeated here because the header takes them as arguments:
 * a test that read them from the firmware would be testing the test. */
#define BASE_HZ     300.0f
#define CUT_MIN_HZ   37.5f
#define CUT_MAX_HZ 16000.0f
#define CUT_OCTAVES   3.0f
#define Q0            0.85f
#define Q_EXP         3.0f
#define DEPTH_OCTAVES 4.0f

/* The scales, in the firmware's order and with its degrees. */
static const int8_t SC_MN_PNT[] = { 0, 3, 5, 7, 10 };
static const int8_t SC_MJ_PNT[] = { 0, 2, 4, 7, 9 };
static const int8_t SC_HIRA[]   = { 0, 2, 3, 7, 8 };
static const int8_t SC_AEOL[]   = { 0, 2, 3, 5, 7, 8, 10 };
static const int8_t SC_DOR[]    = { 0, 2, 3, 5, 7, 9, 10 };
static const int8_t SC_PHRY[]   = { 0, 1, 3, 5, 7, 8, 10 };
static const int8_t SC_LYD[]    = { 0, 2, 4, 6, 7, 9, 11 };
static const int8_t SC_MIX[]    = { 0, 2, 4, 5, 7, 9, 10 };
static const int8_t SC_ION[]    = { 0, 2, 4, 5, 7, 9, 11 };
static const int8_t SC_LOCR[]   = { 0, 1, 3, 5, 6, 8, 10 };
static const int8_t SC_HMIN[]   = { 0, 2, 3, 5, 7, 8, 11 };
static const int8_t SC_BLUES[]  = { 0, 3, 5, 6, 7, 10 };
static const int8_t SC_MMIN[]   = { 0, 2, 3, 5, 7, 9, 11 };
static const int8_t SC_WHOLE[]  = { 0, 2, 4, 6, 8, 10 };
static const int8_t SC_DIM[]    = { 0, 2, 3, 5, 6, 8, 9, 11 };
static const int8_t SC_CHRM[]   = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 };

static const int8_t *const SCALES[] = {
    SC_MN_PNT, SC_MJ_PNT, SC_HIRA, SC_AEOL, SC_DOR, SC_PHRY,
    SC_LYD, SC_MIX, SC_ION, SC_LOCR, SC_HMIN, SC_BLUES, SC_MMIN,
    SC_WHOLE, SC_DIM, SC_CHRM,
};
static const int SCALE_LEN[] = { 5, 5, 5, 7, 7, 7, 7, 7, 7, 7, 7, 6, 7, 6, 8, 12 };

/* xorshift32, seeded: a report that changes every run cannot be compared with the last
 * one. */
static uint32_t g_rng = 0x1234567u;

static float seeded_unit(void *ctx)
{
    (void)ctx;
    g_rng ^= g_rng << 13;
    g_rng ^= g_rng >> 17;
    g_rng ^= g_rng << 5;
    return (float)(g_rng >> 8) / 16777216.0f;
}

static int in_scale(int root_midi, int scale, float hz)
{
    const int note = (int)lroundf(rr_hz_midi(hz));
    const int pc = ((note - root_midi) % 12 + 12) % 12;
    for (int i = 0; i < SCALE_LEN[scale]; i++) {
        if (SCALES[scale][i] == pc) {
            return 1;
        }
    }
    return 0;
}

/* The signature the report averages: the fifteen controls a listener hears first, all
 * normalised. Two draws that are clean but identical score zero here. */
#define SIG_DIMS 18
#define SIG_SAMPLE 500

static int g_sig_count;
static float g_sig[SIG_SAMPLE][SIG_DIMS];
static unsigned char g_combos[8][3][6][4];
static int g_combos_used;

static void sig_add(const float *v)
{
    if (g_sig_count < SIG_SAMPLE) {
        memcpy(g_sig[g_sig_count], v, sizeof(float) * SIG_DIMS);
        g_sig_count++;
    }
}

static double pair_spread(void)
{
    const int n = g_sig_count;
    if (n < 2) {
        return 0.0;
    }
    double total = 0.0;
    long pairs = 0;
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            double d = 0.0;
            for (int k = 0; k < SIG_DIMS; k++) {
                d += fabs((double)g_sig[i][k] - (double)g_sig[j][k]);
            }
            total += d / SIG_DIMS;
            pairs++;
        }
    }
    return total / (double)pairs;
}

int main(int argc, char **argv)
{
    const int draws = (argc > 1) ? atoi(argv[1]) : 100000;
    void *ctx = NULL;

    int mud = 0, space = 0, out_of_scale = 0, clash = 0, no_bottom = 0, downbeat = 0;
    int chars[RR_CHARACTER_COUNT] = { 0 };
    int modes[3] = { 0 }, waves[6] = { 0 }, verbs[4] = { 0 };
    float lo = 1e9f, hi = 0.0f;
    double wet_sum = 0.0;

    for (int i = 0; i < draws; i++) {
        const rr_character_t *ch =
            &RR_CHARACTERS[rr_index(seeded_unit, ctx, RR_CHARACTER_COUNT)];
        chars[ch - RR_CHARACTERS]++;

        /* The same order the application draws in: the bite first, then the corner, then
         * the shapes, then the texture. */
        const float bite = rr_bite(seeded_unit, ctx);
        const int wild = rr_wild(seeded_unit, ctx);
        const float cutoff = rr_cutoff_snapped(rr_pick(seeded_unit, ctx, ch->cutoff, RR_SHARE_IDENTITY, wild),
                                               BASE_HZ, CUT_MIN_HZ, CUT_MAX_HZ,
                                               CUT_OCTAVES);
        float depth = rr_stretch(rr_pick(seeded_unit, ctx, ch->depth, RR_SHARE_TEXTURE, wild), bite);
        const int mode = rr_weighted(seeded_unit, ctx, ch->mode, 3);
        (void)rr_weighted(seeded_unit, ctx, ch->mode, 3);   /* the lead's own mode */
        const int wave = rr_weighted(seeded_unit, ctx, ch->wave, 6);
        int drone_wave = rr_weighted(seeded_unit, ctx, ch->wave, 6);
        if (drone_wave == 5) {
            drone_wave = 2;
        }
        (void)drone_wave;
        const int dest = (rr_index(seeded_unit, ctx, 10) < 6)
                             ? rr_index(seeded_unit, ctx, 3)
                             : 3 + rr_index(seeded_unit, ctx, 12 - 3);
        const int trig = (rr_index(seeded_unit, ctx, 10) < 7)
                             ? rr_index(seeded_unit, ctx, 2)
                             : 2 + rr_index(seeded_unit, ctx, 3);
        const float res = rr_stretch(rr_pick(seeded_unit, ctx, ch->res, RR_SHARE_TEXTURE, wild), bite);
        depth = rr_clean_sweep(depth,
                               rr_cutoff_hz(cutoff, BASE_HZ, CUT_MIN_HZ, CUT_MAX_HZ,
                                            CUT_OCTAVES),
                               Q0 * powf(2.0f, Q_EXP * res));
        const float rate = rr_stretch(rr_pick(seeded_unit, ctx, ch->rate, RR_SHARE_TEXTURE, wild), bite);
        (void)rr_stretch(0.3f + 0.4f * rr_unit(seeded_unit, ctx), bite);   /* MOTION_DEPTH */
        (void)rr_unit(seeded_unit, ctx);                                  /* MOTION_RATE */
        (void)rr_index(seeded_unit, ctx, ch->lfo_hi - ch->lfo_lo + 1);    /* LFO_SHAPE */
        const float lead_cutoff =
            rr_pick(seeded_unit, ctx, ch->lead_cutoff, 0.55f, wild);
        const float lead_reso =
            rr_stretch(rr_pick(seeded_unit, ctx, ch->lead_reso, RR_SHARE_TEXTURE, wild), bite);
        (void)rr_unit(seeded_unit, ctx);                                  /* LEAD_ENV */
        const float lead_attack =
            rr_stretch(rr_pick(seeded_unit, ctx, ch->lead_attack, RR_SHARE_TEXTURE, wild), bite);
        const float lead_decay =
            rr_stretch(rr_pick(seeded_unit, ctx, ch->lead_decay, RR_SHARE_TEXTURE, wild), bite);
        const float lead_sustain =
            rr_stretch(rr_pick(seeded_unit, ctx, ch->lead_sustain, RR_SHARE_TEXTURE, wild), bite);
        const float lead_release =
            rr_stretch(rr_pick(seeded_unit, ctx, ch->lead_release, RR_SHARE_TEXTURE, wild), bite);
        const float gate = rr_stretch(0.15f + 0.7f * rr_unit(seeded_unit, ctx), bite);
        const float porta = rr_stretch(0.05f + 0.55f * rr_unit(seeded_unit, ctx), bite);
        const float duck = (rr_index(seeded_unit, ctx, 3) == 0)
                               ? 0.2f + 0.3f * rr_unit(seeded_unit, ctx) : 0.0f;
        /*
         * THE DRUM SECTION, IN THE ORDER THE APPLICATION DRAWS IT: a kit, a groove, and
         * then the trims. The kit and the groove are list positions, so the model draws them
         * as indexes; the trims are the same narrow windows the firmware uses.
         */
        const int perc_kit = rr_index(seeded_unit, ctx, 16);
        const int perc_groove = rr_index(seeded_unit, ctx, 16);
        const float perc_tone = rr_stretch(0.42f + 0.16f * rr_unit(seeded_unit, ctx), bite);
        const float perc_tune = rr_stretch(0.44f + 0.12f * rr_unit(seeded_unit, ctx), bite);
        const float perc_length = rr_stretch(0.36f + 0.28f * rr_unit(seeded_unit, ctx), bite);
        const float perc_body = rr_stretch(0.38f + 0.24f * rr_unit(seeded_unit, ctx), bite);
        const float perc_timbre = rr_stretch(0.18f + 0.42f * rr_unit(seeded_unit, ctx), bite);
        (void)rr_stretch(0.05f + 0.35f * rr_unit(seeded_unit, ctx), bite); /* VARIATION */
        (void)rr_stretch(0.15f + 0.45f * rr_unit(seeded_unit, ctx), bite); /* FILL */
        (void)rr_stretch(0.30f * rr_unit(seeded_unit, ctx), bite);         /* SWING */
        (void)rr_index(seeded_unit, ctx, 8);                              /* SPEED: one in four */
        (void)rr_index(seeded_unit, ctx, 2);
        (void)perc_kit;
        (void)perc_groove;
        (void)perc_tone;
        (void)perc_tune;
        const int verb = rr_weighted(seeded_unit, ctx, ch->verb, 4);
        const float verb_size =
            rr_stretch(rr_pick(seeded_unit, ctx, ch->verb_size, RR_SHARE_TEXTURE, wild), bite);
        const float verb_damp =
            rr_stretch(rr_pick(seeded_unit, ctx, ch->verb_damp, RR_SHARE_TEXTURE, wild), bite);
        (void)rr_stretch(0.2f + 0.5f * rr_unit(seeded_unit, ctx), bite);   /* CHORUS_RATE */
        const float chorus_depth =
            rr_stretch(0.2f + 0.6f * rr_unit(seeded_unit, ctx), bite);

        float dm = 0.0f, cm = 0.0f, vm = 0.0f, fb = 0.0f;
        rr_wet_budget(seeded_unit, ctx, &dm, &cm, &vm, &fb);
        wet_sum += dm + cm + vm;

        modes[mode]++;
        waves[wave]++;
        verbs[verb]++;
        g_combos[ch - RR_CHARACTERS][mode][wave][verb] = 1;

        const float sig[SIG_DIMS] = { cutoff, res, depth, rate, lead_cutoff, lead_reso,
                                      lead_attack, lead_decay, lead_sustain, lead_release,
                                      perc_length, perc_timbre, verb_size, verb_damp,
                                      chorus_depth, gate, porta, duck };
        (void)dest;
        (void)trig;
        sig_add(sig);

        const float cut_hz = rr_cutoff_hz(cutoff, BASE_HZ, CUT_MIN_HZ, CUT_MAX_HZ,
                                          CUT_OCTAVES);
        if (cut_hz < 250.0f && Q0 * powf(2.0f, Q_EXP * res) > 3.2f
            && DEPTH_OCTAVES * depth > 2.4f) {
            mud++;
        }
        if (dm + cm + vm > 1.0f) {
            space++;
        }
        (void)fb;

        const int scale = rr_scale(seeded_unit, ctx);
        const int root = 33 + 12 * rr_index(seeded_unit, ctx, 2)
                         + rr_index(seeded_unit, ctx, 12);
        const float drum = rr_drum_pitch_hz(seeded_unit, ctx, SCALES[scale],
                                            SCALE_LEN[scale], root, 45, cut_hz > 1200.0f);

        if (!in_scale(root, scale, drum)) {
            out_of_scale++;
        }
        const int iv = (((int)lroundf(rr_hz_midi(drum)) - 45) % 12 + 12) % 12;
        if (iv == 1 || iv == 2 || iv == 10 || iv == 11) {
            clash++;
        }
        if (cut_hz > 1200.0f && drum > 87.0f) {
            no_bottom++;
        }
        if (drum < lo) {
            lo = drum;
        }
        if (drum > hi) {
            hi = drum;
        }

        const int steps = rr_grid(seeded_unit, ctx);
        int lead = 3 + rr_index(seeded_unit, ctx, 5);
        if (lead > steps) {
            lead = steps;
        }
        /* ROTATION IS NO LONGER DRAWN: the figure is generated on the downbeat, so the first
         * step of E(lead, steps) is a pulse by construction. The check below stays — it now
         * proves the generator's own promise rather than the draw's correction of it. */
        const int rot = 0;
        int hit = 0;
        for (int p = 0; p < lead; p++) {
            const int pos = (int)lroundf((float)p * (float)steps / (float)lead) % steps;
            if ((pos + rot) % steps == 0) {
                hit = 1;
                break;
            }
        }
        if (hit) {
            downbeat++;
        }
    }

    for (int c = 0; c < RR_CHARACTER_COUNT; c++) {
        for (int m = 0; m < 3; m++) {
            for (int w = 0; w < 6; w++) {
                for (int v = 0; v < 4; v++) {
                    if (g_combos[c][m][w][v]) {
                        g_combos_used++;
                    }
                }
            }
        }
    }
    const int combos_max = RR_CHARACTER_COUNT * 3 * 6 * 4;

    printf("бросков: %d\n", draws);
    printf("мутные сочетания:            %d\n", mud);
    printf("перегруз пространства:       %d\n", space);
    printf("удар вне лада:               %d\n", out_of_scale);
    printf("удар в секунде с дроном:     %d\n", clash);
    printf("корнер высоко, низа нет:     %d\n", no_bottom);
    printf("первый шаг без доли:         %d\n", draws - downbeat);
    printf("средняя сумма мокрых смесей: %.2f\n", wet_sum / draws);
    printf("удар: от %.1f до %.1f Гц\n", lo, hi);
    printf("различие пары бросков:       %.3f  (0 — один и тот же звук, 1 — полюса)\n",
           pair_spread());
    printf("сочетаний характер/фильтр/волна/комната: %d из %d\n",
           g_combos_used, combos_max);
    for (int i = 0; i < RR_CHARACTER_COUNT; i++) {
        printf("  %-8s %5.2f %%\n", RR_CHARACTERS[i].name, 100.0 * chars[i] / draws);
    }
    printf("  формы: низ %.1f %%, полоса %.1f %%, верх %.1f %%\n",
           100.0 * modes[0] / draws, 100.0 * modes[1] / draws, 100.0 * modes[2] / draws);
    printf("  волны: син %.1f, треуг %.1f, пила %.1f, прямоуг %.1f, супер %.1f, шум %.1f %%\n",
           100.0 * waves[0] / draws, 100.0 * waves[1] / draws, 100.0 * waves[2] / draws,
           100.0 * waves[3] / draws, 100.0 * waves[4] / draws, 100.0 * waves[5] / draws);
    printf("  комнаты: рум %.1f, холл %.1f, собор %.1f, плато %.1f %%\n",
           100.0 * verbs[0] / draws, 100.0 * verbs[1] / draws,
           100.0 * verbs[2] / draws, 100.0 * verbs[3] / draws);

    const int failed = mud + space + out_of_scale + clash + no_bottom
                       + (draws - downbeat) + ((g_combos_used < combos_max / 2) ? 1 : 0);
    printf("%s\n", failed == 0 ? "OK: правила держатся на каждом броске"
                               : "ПРОВАЛ: правила не держатся");
    return failed == 0 ? 0 : 1;
}
