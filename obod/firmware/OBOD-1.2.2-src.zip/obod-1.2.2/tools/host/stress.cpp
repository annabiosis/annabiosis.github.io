/*
 * The audio path, on a desktop, without a board.
 *
 * WHY THIS EXISTS
 *   Most of what can go wrong in this instrument is arithmetic that only misbehaves at a
 *   boundary: a cutoff of zero, a feedback of one, a delay time of NaN. Finding those on
 *   the device means flashing, listening and waiting for a reboot; here a block costs
 *   microseconds and a rescue is a line of text. The DSP sources are compiled UNCHANGED —
 *   the exact files that go into the firmware — and the platform seam lives in
 *   tools/host/shim and tools/host/platform.cpp.
 *
 * WHAT IS BUILT
 *   `synth_dsp_init()` constructs the rack, the percussion and the three effects in the
 *   same order as synth_app_start(). The bench then renders SYNTH_BLOCK_SAMPLES-sized
 *   blocks exactly as the audio task does: clear the layer accumulators, run each
 *   layer's bus effects and its pan capture, render the rack, publish the drum's
 *   envelope. What differs is where the engine would be: the five buses are filled
 *   with a deterministic sine/noise signal
 *   instead of ESP32Synth voices, so the test is of the rack and its neighbours rather
 *   than of the sequencer.
 *
 * WHAT IS CHECKED
 *   Two passes. The SWEEP calls every rack and percussion setter with the values that
 *   tend to break arithmetic — zero, one, the ends of the travel, a denormal, both
 *   infinities, NaN, and a random number — and gives each value a few blocks to act. The
 *   sweep is mandatory: a pass that runs out of blocks before its last step is an
 *   incomplete check, and the bench reports it as a failure rather than a shorter pass.
 *   The RANDOM WALK moves the same controls as a hand would: one-pole glides, jumps to the
 *   boundaries, mode changes, delay times from a tempo, and a drum pattern. Every block's
 *   output is read, its peak recorded, and the rack's rescue counter is compared with the
 *   previous block. A rescue is a failure with the seed and the exact step that produced
 *   it, which is the whole of the reproduction recipe.
 *
 * WHY THE RESCUE COUNTER IS THE DETECTOR
 *   synth_rack_process() writes int16, and every int16 is a finite number: a NaN that
 *   reached the conversion has already been stopped by the rack's own fuse, which is what
 *   the counter counts. The bench still checks the float reading of every output sample
 *   and tracks the peak, but the fuse's counter is what can see a non-finite block at all.
 *
 * EXIT CODES
 *   0  every block was finite, no rescue, and every sweep step that the mode runs
 *   1  a rescue, a non-finite output, an incomplete sweep, or a broken invocation
 */

#include "platform.h"
#include "synth_dsp.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <limits>
#include <string>
#include <thread>
#include <vector>

namespace {

constexpr int    BLOCK       = SYNTH_BLOCK_SAMPLES;
constexpr int    BLOCKS_STEP = 8;      /* blocks each sweep value gets to act */
constexpr int    AUDIO_BLOCK_US = (int)((int64_t)BLOCK * 1000000 / SYNTH_SAMPLE_RATE);

/* The sweep is the deterministic half of the check, so its cost is charged before any
 * random soak and its budget is never trimmed. The default run is therefore the whole
 * sweep plus this many walk blocks: 4056 + 2048 = 6104 blocks at 256 samples, 32.6 s of
 * audio. The walk is the soak, not the boundary check; a budget too small for both
 * still gives the sweep every block that is left, and fails if it cannot finish it. */
constexpr uint64_t DEFAULT_RANDOM_BLOCKS = 2048;
constexpr uint64_t SWEEP_SETTLE_BLOCKS  = 32;   /* baseline settling between the passes */

/* -------------------------------------------------------------------------- */
/* Deterministic numbers                                                      */
/* -------------------------------------------------------------------------- */

/* splitmix64. Small, fast, and the whole state is one word, which is what makes a seed
 * and a block number enough to reproduce a run. */
struct Rng {
    uint64_t s;

    explicit Rng(uint32_t seed) : s((uint64_t)seed * 0x9E3779B97F4A7C15ull + 1u) {}

    uint64_t next()
    {
        uint64_t z = (s += 0x9E3779B97F4A7C15ull);
        z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ull;
        z = (z ^ (z >> 27)) * 0x94D049BB133111EBull;
        return z ^ (z >> 31);
    }

    float unit() { return (float)((next() >> 40) * (1.0 / 16777216.0)); }
    float bipolar() { return unit() * 2.0f - 1.0f; }
};

/* The signal generators. A wavetable rather than sinf() per sample: at a million blocks
 * the difference is most of the wall time, and the spectrum is not what is being tested. */
constexpr int SINE_BITS = 12;
constexpr int SINE_SIZE = 1 << SINE_BITS;

float g_sine[SINE_SIZE];

float sine_at(float phase01)
{
    float p = phase01 * (float)SINE_SIZE;
    int   i = (int)p;
    const float t = p - (float)i;
    i &= (SINE_SIZE - 1);
    const int j = (i + 1) & (SINE_SIZE - 1);
    return g_sine[i] + (g_sine[j] - g_sine[i]) * t;
}

void sine_table_init()
{
    for (int i = 0; i < SINE_SIZE; i++) {
        g_sine[i] = sinf(2.0f * 3.14159265358979f * (float)i / (float)SINE_SIZE);
    }
}

/* -------------------------------------------------------------------------- */
/* Control state                                                              */
/* -------------------------------------------------------------------------- */

/*
 * The control surface, as the bench holds it. Every setter writes one of these and then
 * calls the DSP with the whole family — the same way a page of the UI sends a rate, a
 * depth and a mix together. Keeping the values here rather than reading them back from
 * the DSP is what makes the failure line able to print the state the run was in.
 */
float g_layer_level[SYNTH_NUM_LAYERS];
float g_master;
float g_comp;
float g_duck;

float g_chorus_rate;
float g_chorus_depth;
float g_chorus_mix;

float g_delay_time;
float g_delay_fb;
float g_delay_mix;
bool  g_delay_crossfade;

float g_reverb_size;
float g_reverb_damp;
float g_reverb_mix;
int   g_reverb_mode;

float g_rev_send[SYNTH_NUM_LAYERS];
float g_chr_send[SYNTH_NUM_LAYERS];
float g_dly_send[SYNTH_NUM_LAYERS];

float g_perc_send;
float g_perc_chr_send;
float g_perc_dly_send;

float g_perc_pitch;
float g_perc_reso;
float g_perc_decay;
float g_perc_env;
float g_perc_level;
float g_perc_body;

float g_trig_vel;
float g_trig_ratio;

int  g_gate = 1;
int  g_transport = 0;

/* -------------------------------------------------------------------------- */
/* The sweep table                                                            */
/* -------------------------------------------------------------------------- */

enum Kind {
    K_LAYER_LEVEL,
    K_MASTER,
    K_COMP,
    K_DUCK,
    K_CHORUS_RATE,
    K_CHORUS_DEPTH,
    K_CHORUS_MIX,
    K_DELAY_TIME,
    K_DELAY_FB,
    K_DELAY_MIX,
    K_REVERB_SIZE,
    K_REVERB_DAMP,
    K_REVERB_MIX,
    K_REVERB_SEND,
    K_CHORUS_SEND,
    K_DELAY_SEND,
    K_PERC_SEND,
    K_PERC_CHORUS_SEND,
    K_PERC_DELAY_SEND,
    K_PERC_PITCH,
    K_PERC_RESO,
    K_PERC_DECAY,
    K_PERC_ENV,
    K_PERC_LEVEL,
    K_PERC_BODY,
    K_TRIG_VEL,
    K_TRIG_RATIO,
    K_COUNT
};

struct Knob {
    const char *name;
    Kind        kind;
    int         index;
    float       lo;
    float       hi;
};

const Knob g_knobs[] = {
    { "rack.layer_level[0]", K_LAYER_LEVEL, 0, 0.0f, 1.0f },
    { "rack.layer_level[1]", K_LAYER_LEVEL, 1, 0.0f, 1.0f },
    { "rack.layer_level[2]", K_LAYER_LEVEL, 2, 0.0f, 1.0f },
    { "rack.layer_level[3]", K_LAYER_LEVEL, 3, 0.0f, 1.0f },
    { "rack.layer_level[4]", K_LAYER_LEVEL, 4, 0.0f, 1.0f },

    { "rack.master",    K_MASTER, -1, 0.0f, 1.0f },
    { "rack.comp",      K_COMP,   -1, 0.0f, 1.0f },
    { "rack.duck",      K_DUCK,   -1, 0.0f, 1.0f },
    { "rack.chorus.rate",  K_CHORUS_RATE,  -1, 0.01f, 20.0f },
    { "rack.chorus.depth", K_CHORUS_DEPTH, -1, 0.0f, 1.0f },
    { "rack.chorus.mix",   K_CHORUS_MIX,   -1, 0.0f, 1.0f },

    /* The delay's time is in samples, and the two ends of its line are the two values
     * that matter: DELAY_MIN_MS (2 ms, 96 samples) and the longest reachable tap. */
    { "rack.delay.time", K_DELAY_TIME, -1, 96.0f, 191998.0f },
    { "rack.delay.fb",   K_DELAY_FB,   -1, 0.0f, 0.95f },
    { "rack.delay.mix",  K_DELAY_MIX,  -1, 0.0f, 1.0f },

    { "rack.reverb.size", K_REVERB_SIZE, -1, 0.0f, 1.0f },
    { "rack.reverb.damp", K_REVERB_DAMP, -1, 0.0f, 1.0f },
    { "rack.reverb.mix",  K_REVERB_MIX,  -1, 0.0f, 1.0f },

    { "rack.reverb_send[0]", K_REVERB_SEND, 0, 0.0f, 1.0f },
    { "rack.reverb_send[1]", K_REVERB_SEND, 1, 0.0f, 1.0f },
    { "rack.reverb_send[2]", K_REVERB_SEND, 2, 0.0f, 1.0f },
    { "rack.reverb_send[3]", K_REVERB_SEND, 3, 0.0f, 1.0f },
    { "rack.reverb_send[4]", K_REVERB_SEND, 4, 0.0f, 1.0f },

    { "rack.chorus_send[0]", K_CHORUS_SEND, 0, 0.0f, 1.0f },
    { "rack.chorus_send[1]", K_CHORUS_SEND, 1, 0.0f, 1.0f },
    { "rack.chorus_send[2]", K_CHORUS_SEND, 2, 0.0f, 1.0f },
    { "rack.chorus_send[3]", K_CHORUS_SEND, 3, 0.0f, 1.0f },
    { "rack.chorus_send[4]", K_CHORUS_SEND, 4, 0.0f, 1.0f },

    { "rack.delay_send[0]", K_DELAY_SEND, 0, 0.0f, 1.0f },
    { "rack.delay_send[1]", K_DELAY_SEND, 1, 0.0f, 1.0f },
    { "rack.delay_send[2]", K_DELAY_SEND, 2, 0.0f, 1.0f },
    { "rack.delay_send[3]", K_DELAY_SEND, 3, 0.0f, 1.0f },
    { "rack.delay_send[4]", K_DELAY_SEND, 4, 0.0f, 1.0f },

    { "rack.perc_send",       K_PERC_SEND,       -1, 0.0f, 1.0f },
    { "rack.perc_chorus_send", K_PERC_CHORUS_SEND, -1, 0.0f, 1.0f },
    { "rack.perc_delay_send",  K_PERC_DELAY_SEND,  -1, 0.0f, 1.0f },

    { "perc.pitch", K_PERC_PITCH, -1, 0.0f, 1.0f },
    { "perc.reso",  K_PERC_RESO,  -1, 0.0f, 1.0f },
    { "perc.decay", K_PERC_DECAY, -1, 0.0f, 1.0f },
    { "perc.env",   K_PERC_ENV,   -1, 0.0f, 1.0f },
    { "perc.level", K_PERC_LEVEL, -1, 0.0f, 1.0f },
    { "perc.body",  K_PERC_BODY,  -1, 0.0f, 1.0f },

    { "perc.trigger.velocity", K_TRIG_VEL,   -1, 0.0f, 1.0f },
    { "perc.trigger.ratio",    K_TRIG_RATIO, -1, 0.0f, 4.0f },
};

constexpr int KNOB_COUNT = (int)(sizeof(g_knobs) / sizeof(g_knobs[0]));

/* One row of the sweep: a raw number, and whether it should be scaled into the knob's
 * range or handed over exactly as it is. The non-numbers are never scaled — the point is
 * to give the setter the value itself, not a remapped version of it. */
struct TestValue {
    const char *name;
    float       raw;
    bool        random;
};

const TestValue g_values[] = {
    { "0",         0.0f, false },
    { "1",         1.0f, false },
    { "0.5",       0.5f, false },
    { "0.001",     0.001f, false },
    { "0.999",     0.999f, false },
    { "-0.0",     -0.0f, false },
    { "denormal",  std::numeric_limits<float>::denorm_min(), false },
    { "+inf",      std::numeric_limits<float>::infinity(), false },
    { "-inf",     -std::numeric_limits<float>::infinity(), false },
    { "nan",       std::numeric_limits<float>::quiet_NaN(), false },
    { "random",    0.0f, true },
};

constexpr int VALUE_COUNT = (int)(sizeof(g_values) / sizeof(g_values[0]));

/* -------------------------------------------------------------------------- */
/* Applying a knob                                                            */
/* -------------------------------------------------------------------------- */

void perc_apply_all()
{
    synth_perc_set(g_perc_pitch, g_perc_reso, g_perc_decay, g_perc_env,
                   g_perc_level, g_perc_body);
}

void apply_knob(const Knob &k, float v)
{
    switch (k.kind) {
    case K_LAYER_LEVEL:
        if (k.index >= 0 && k.index < SYNTH_NUM_LAYERS) {
            g_layer_level[k.index] = v;
            synth_rack_set_layer_level(k.index, v);
        }
        break;

    case K_MASTER: g_master = v; synth_rack_set_master(v); break;
    case K_COMP:   g_comp = v;   synth_rack_set_comp(v); break;
    case K_DUCK:   g_duck = v;   synth_rack_set_duck(v); break;

    case K_CHORUS_RATE:
        g_chorus_rate = v;
        synth_rack_set_chorus(g_chorus_rate, g_chorus_depth, g_chorus_mix);
        break;
    case K_CHORUS_DEPTH:
        g_chorus_depth = v;
        synth_rack_set_chorus(g_chorus_rate, g_chorus_depth, g_chorus_mix);
        break;
    case K_CHORUS_MIX:
        g_chorus_mix = v;
        synth_rack_set_chorus(g_chorus_rate, g_chorus_depth, g_chorus_mix);
        break;

    case K_DELAY_TIME:
        g_delay_time = v;
        synth_rack_set_delay(g_delay_time, g_delay_fb, g_delay_mix, g_delay_crossfade);
        break;
    case K_DELAY_FB:
        g_delay_fb = v;
        synth_rack_set_delay(g_delay_time, g_delay_fb, g_delay_mix, g_delay_crossfade);
        break;
    case K_DELAY_MIX:
        g_delay_mix = v;
        synth_rack_set_delay(g_delay_time, g_delay_fb, g_delay_mix, g_delay_crossfade);
        break;

    case K_REVERB_SIZE:
        g_reverb_size = v;
        synth_rack_set_reverb(g_reverb_size, g_reverb_damp, g_reverb_mix, g_reverb_mode);
        break;
    case K_REVERB_DAMP:
        g_reverb_damp = v;
        synth_rack_set_reverb(g_reverb_size, g_reverb_damp, g_reverb_mix, g_reverb_mode);
        break;
    case K_REVERB_MIX:
        g_reverb_mix = v;
        synth_rack_set_reverb(g_reverb_size, g_reverb_damp, g_reverb_mix, g_reverb_mode);
        break;

    case K_REVERB_SEND:
        if (k.index >= 0 && k.index < SYNTH_NUM_LAYERS) {
            g_rev_send[k.index] = v;
            synth_rack_set_reverb_send(k.index, v);
        }
        break;
    case K_CHORUS_SEND:
        if (k.index >= 0 && k.index < SYNTH_NUM_LAYERS) {
            g_chr_send[k.index] = v;
            synth_rack_set_chorus_send(k.index, v);
        }
        break;
    case K_DELAY_SEND:
        if (k.index >= 0 && k.index < SYNTH_NUM_LAYERS) {
            g_dly_send[k.index] = v;
            synth_rack_set_delay_send(k.index, v);
        }
        break;

    case K_PERC_SEND:        g_perc_send = v;     synth_rack_set_perc_send(v); break;
    case K_PERC_CHORUS_SEND: g_perc_chr_send = v; synth_rack_set_perc_chorus_send(v); break;
    case K_PERC_DELAY_SEND:  g_perc_dly_send = v; synth_rack_set_perc_delay_send(v); break;

    case K_PERC_PITCH: g_perc_pitch = v; perc_apply_all(); break;
    case K_PERC_RESO:  g_perc_reso = v;  perc_apply_all(); break;
    case K_PERC_DECAY: g_perc_decay = v; perc_apply_all(); break;
    case K_PERC_ENV:   g_perc_env = v;   perc_apply_all(); break;
    case K_PERC_LEVEL: g_perc_level = v; perc_apply_all(); break;
    case K_PERC_BODY:  g_perc_body = v;  perc_apply_all(); break;

    case K_TRIG_VEL:
        g_trig_vel = v;
        synth_perc_trigger(g_trig_vel, g_trig_ratio);
        break;
    case K_TRIG_RATIO:
        g_trig_ratio = v;
        synth_perc_trigger(g_trig_vel, g_trig_ratio);
        break;

    case K_COUNT:
        break;
    }
}

float current_value(const Knob &k)
{
    switch (k.kind) {
    case K_LAYER_LEVEL: return g_layer_level[k.index];
    case K_MASTER: return g_master;
    case K_COMP: return g_comp;
    case K_DUCK: return g_duck;

    case K_CHORUS_RATE: return g_chorus_rate;
    case K_CHORUS_DEPTH: return g_chorus_depth;
    case K_CHORUS_MIX: return g_chorus_mix;

    case K_DELAY_TIME: return g_delay_time;
    case K_DELAY_FB: return g_delay_fb;
    case K_DELAY_MIX: return g_delay_mix;

    case K_REVERB_SIZE: return g_reverb_size;
    case K_REVERB_DAMP: return g_reverb_damp;
    case K_REVERB_MIX: return g_reverb_mix;

    case K_REVERB_SEND: return g_rev_send[k.index];
    case K_CHORUS_SEND: return g_chr_send[k.index];
    case K_DELAY_SEND: return g_dly_send[k.index];

    case K_PERC_SEND: return g_perc_send;
    case K_PERC_CHORUS_SEND: return g_perc_chr_send;
    case K_PERC_DELAY_SEND: return g_perc_dly_send;

    case K_PERC_PITCH: return g_perc_pitch;
    case K_PERC_RESO: return g_perc_reso;
    case K_PERC_DECAY: return g_perc_decay;
    case K_PERC_ENV: return g_perc_env;
    case K_PERC_LEVEL: return g_perc_level;
    case K_PERC_BODY: return g_perc_body;

    case K_TRIG_VEL: return g_trig_vel;
    case K_TRIG_RATIO: return g_trig_ratio;

    case K_COUNT: break;
    }
    return 0.0f;
}

/* The constraint every setter on this API writes: below the range, or not a number, goes
 * to the low bound; above it, to the high one. This is the same negated lower test the
 * firmware uses, applied here when --sanitize asks the bench to model fixed constraints. */
float clamp_like_firmware(float v, float lo, float hi)
{
    if (!(v >= lo)) {
        return lo;
    }
    if (v > hi) {
        return hi;
    }
    return v;
}

float map_into_range(float raw, const Knob &k)
{
    if (!std::isfinite(raw)) {
        return raw;
    }
    return k.lo + raw * (k.hi - k.lo);
}

/*
 * The repaired control surface, for --sanitize: what a setter that rejected every value
 * outside its range would have received. Finite values are mapped into the range the same
 * way the sweep maps them; NaN and a denormal go to the low bound, the infinities to the
 * bound whose direction they name.
 *
 * The denormal is the interesting case and the reason this is more than a clamp: a ratio of
 * 1e-45 is "inside" 0..4 by every comparison, and it still makes sqrt(q / pitch) infinite.
 * A repaired value has to be a musical number, not merely an ordered one.
 */
float repair_value(float raw, const Knob &k)
{
    if (std::isnan(raw)) {
        return k.lo;
    }
    if (raw == std::numeric_limits<float>::infinity()) {
        return k.hi;
    }
    if (raw == -std::numeric_limits<float>::infinity()) {
        return k.lo;
    }
    if (std::fpclassify(raw) == FP_SUBNORMAL) {
        return k.lo;
    }

    const float mapped = k.lo + raw * (k.hi - k.lo);
    if (!(mapped >= k.lo)) {
        return k.lo;
    }
    if (mapped > k.hi) {
        return k.hi;
    }
    return mapped;
}

/* -------------------------------------------------------------------------- */
/* Baseline                                                                   */
/* -------------------------------------------------------------------------- */

void baseline_controls()
{
    for (int i = 0; i < SYNTH_NUM_LAYERS; i++) {
        g_layer_level[i] = 0.85f;
        g_rev_send[i]    = 0.15f + 0.05f * (float)i;
        g_chr_send[i]    = (i >= 3) ? 0.20f : 0.10f;
        g_dly_send[i]    = (i >= 3) ? 0.18f : 0.08f;
    }

    g_master = 0.90f;
    g_comp   = 0.15f;
    g_duck   = 0.20f;

    g_chorus_rate  = 0.60f;
    g_chorus_depth = 0.35f;
    g_chorus_mix   = 0.20f;

    g_delay_time      = 12000.0f;   /* 250 ms at 48 kHz */
    g_delay_fb        = 0.35f;
    g_delay_mix       = 0.20f;
    g_delay_crossfade = false;

    g_reverb_size = 0.50f;
    g_reverb_damp = 0.40f;
    g_reverb_mix  = 0.20f;
    g_reverb_mode = SYNTH_REVERB_HALL;

    g_perc_send     = 0.15f;
    g_perc_chr_send = 0.10f;
    g_perc_dly_send = 0.10f;

    g_perc_pitch = 0.30f;
    g_perc_reso  = 0.35f;
    g_perc_decay = 0.35f;
    g_perc_env   = 0.45f;
    g_perc_level = 0.80f;
    g_perc_body  = 0.30f;

    g_trig_vel   = 0.80f;
    g_trig_ratio = 1.00f;

    synth_rack_set_master(g_master);
    for (int i = 0; i < SYNTH_NUM_LAYERS; i++) {
        synth_rack_set_layer_level(i, g_layer_level[i]);
        synth_rack_set_reverb_send(i, g_rev_send[i]);
        synth_rack_set_chorus_send(i, g_chr_send[i]);
        synth_rack_set_delay_send(i, g_dly_send[i]);
    }
    synth_rack_set_comp(g_comp);
    synth_rack_set_duck(g_duck);
    synth_rack_set_chorus(g_chorus_rate, g_chorus_depth, g_chorus_mix);
    synth_rack_set_delay(g_delay_time, g_delay_fb, g_delay_mix, g_delay_crossfade);
    synth_rack_set_reverb(g_reverb_size, g_reverb_damp, g_reverb_mix, g_reverb_mode);
    synth_rack_set_perc_send(g_perc_send);
    synth_rack_set_perc_chorus_send(g_perc_chr_send);
    synth_rack_set_perc_delay_send(g_perc_dly_send);
    perc_apply_all();
    synth_rack_set_gate(g_gate);
    synth_rack_set_transport(g_transport);
}

/* -------------------------------------------------------------------------- */
/* The signal path                                                            */
/* -------------------------------------------------------------------------- */

struct LayerSignal {
    float   phase;      /* 0..1 */
    float   inc;        /* per sample */
    float   pan_phase;
    float   pan_inc;
    int32_t bus[BLOCK];
};

LayerSignal g_sig[SYNTH_NUM_LAYERS];

int16_t g_drone_ep[SYNTH_NUM_LAYERS][8];
int16_t g_lead_ep[8];
int16_t g_mic_ep[8];
int16_t g_pan_ep[SYNTH_NUM_LAYERS][8];
int32_t g_fx_state[SYNTH_NUM_LAYERS][6];

float g_mic_block[BLOCK];

Rng *g_rng = nullptr;
/* The input's own generator, separate from the walk's. The noise below draws once per
 * sample, so sharing a generator with the test would make every control value depend on
 * how many blocks had already run — and a rescue changes that number. Two generators keep
 * the walk reproducible from its seed even when the fuse fires at a different block. */
Rng *g_sig_rng = nullptr;

void signal_init()
{
    static const float freq[SYNTH_NUM_LAYERS] = { 55.0f, 82.5f, 110.0f, 220.0f, 330.0f };
    static const float amp[SYNTH_NUM_LAYERS]  = { 0.100f, 0.080f, 0.060f, 0.050f, 0.040f };
    static const float pan[SYNTH_NUM_LAYERS]  = { -0.55f, -0.25f, 0.0f, 0.25f, 0.55f };
    static const int16_t pan_milli[SYNTH_NUM_LAYERS] = { -550, -250, 0, 250, 550 };
    static const int16_t pan_rate[SYNTH_NUM_LAYERS]  = { 31, 37, 43, 53, 61 };

    (void)amp;

    for (int i = 0; i < SYNTH_NUM_LAYERS; i++) {
        g_sig[i].phase = (float)i * 0.173f;
        g_sig[i].inc   = freq[i] / (float)SYNTH_SAMPLE_RATE;
        g_sig[i].pan_phase = (float)i * 0.271f;
        g_sig[i].pan_inc   = 0.0007f + 0.0001f * (float)i;

        memset(g_drone_ep[i], 0, sizeof(g_drone_ep[i]));
        memset(g_pan_ep[i], 0, sizeof(g_pan_ep[i]));
        memset(g_fx_state[i], 0, sizeof(g_fx_state[i]));

        g_pan_ep[i][0] = pan_milli[i];
        g_pan_ep[i][1] = 400;                 /* depth, 0..1000 */
        g_pan_ep[i][2] = pan_rate[i];         /* mHz */
        g_pan_ep[i][3] = (int16_t)(pan_rate[i] + 17);
        g_pan_ep[i][4] = 4000;                /* walk period, ms */
        g_pan_ep[i][5] = 300;
        g_pan_ep[i][6] = 1;
        g_pan_ep[i][7] = (int16_t)i;

        g_drone_ep[i][0] = (int16_t)(400 + 400 * i);  /* cutoff, Hz */
        g_drone_ep[i][1] = 70;                        /* Q x 100 */
        g_drone_ep[i][2] = (int16_t)(31 + 16 * i);    /* mHz */
        g_drone_ep[i][3] = 200;                       /* centioctaves */
        g_drone_ep[i][4] = 0;                         /* low pass */
        g_drone_ep[i][5] = (int16_t)(i % 5);          /* shape */
        g_drone_ep[i][6] = 1;
        g_drone_ep[i][7] = (int16_t)i;
    }

    g_lead_ep[0] = 2400;   /* cutoff */
    g_lead_ep[1] = 120;    /* Q x 100 */
    g_lead_ep[2] = 240;    /* envelope, centioctaves */
    g_lead_ep[3] = 4;      /* attack ms */
    g_lead_ep[4] = 180;    /* decay ms */
    g_lead_ep[5] = 200;    /* sustain */
    g_lead_ep[6] = 350;    /* release ms */
    g_lead_ep[7] = 1;      /* gate held */

    g_mic_ep[6] = 1;       /* the microphone is part of the AUX bus */

    (void)pan;
}

/*
 * One block of "engine": a mono int32 bus per layer, its filter, its pan capture. The
 * bus is scaled to 16-bit full scale, which is the contract synth_fx_pan_capture()
 * documents; the layer accumulators are cleared first, exactly as the audio task does.
 */
void fill_layers(uint64_t block_index)
{
    static const float amp[SYNTH_NUM_LAYERS] = { 0.100f, 0.080f, 0.060f, 0.050f, 0.040f };

    synth_layers_clear(BLOCK);

    for (int i = 0; i < BLOCK; i++) {
        g_mic_block[i] = 0.04f * sine_at((float)((block_index * BLOCK + i) % 4800) / 4800.0f);
    }
    synth_dsp_mic_publish(g_mic_block, BLOCK);

    for (int layer = 0; layer < SYNTH_NUM_LAYERS; layer++) {
        LayerSignal &s = g_sig[layer];

        for (int i = 0; i < BLOCK; i++) {
            const float x = amp[layer] * sine_at(s.phase)
                          + 0.006f * (g_sig_rng->unit() * 2.0f - 1.0f);
            s.phase += s.inc;
            if (s.phase >= 1.0f) {
                s.phase -= 1.0f;
            }
            s.bus[i] = (int32_t)(x * 32768.0f);
        }

        if (layer == SYNTH_LAYER_LEAD) {
            synth_fx_lead_filter(s.bus, BLOCK, g_lead_ep, g_fx_state[layer]);
        } else if (layer != SYNTH_LAYER_AUX) {
            synth_fx_drone_filter(s.bus, BLOCK, g_drone_ep[layer], g_fx_state[layer]);
        } else {
            synth_fx_mic_in(s.bus, BLOCK, g_mic_ep, g_fx_state[layer]);
        }

        synth_fx_pan_capture(s.bus, BLOCK, g_pan_ep[layer], g_fx_state[layer]);
    }
}

/* -------------------------------------------------------------------------- */
/* Measurement                                                                */
/* -------------------------------------------------------------------------- */

int16_t g_out[BLOCK * 2];
int     g_peak_min;
int     g_peak_max;
uint64_t g_block;              /* 1-based block number of the run */
uint64_t g_step;               /* 1-based sweep step */
uint64_t g_rescues_seen;
uint64_t g_rescue_events;
uint64_t g_nonfinite_out;
uint64_t g_blocks_done;
uint64_t g_seed;
uint64_t g_inject_block;       /* 0 = no deliberate wound */

float g_perc_env01;
float g_perc_env_release;

const char *g_mode_name = "";

/* The last thing a failure line needs: the whole control surface. */
void print_state(FILE *f)
{
    for (int i = 0; i < KNOB_COUNT; i++) {
        const float v = current_value(g_knobs[i]);
        std::fprintf(f, "%s=%g", g_knobs[i].name, (double)v);
        std::fputc(((i % 4) == 3) ? '\n' : ' ', f);
    }
    std::fprintf(f, "reverb_mode=%d delay_crossfade=%d "
                    "gate=%d transport=%d\n",
                 g_reverb_mode,
                 g_delay_crossfade ? 1 : 0, g_gate, g_transport);
}

void print_float_bits(FILE *f, const char *label, float v)
{
    uint32_t bits;
    std::memcpy(&bits, &v, sizeof(bits));
    std::fprintf(f, "%s=%g (0x%08x)", label, (double)v, (unsigned)bits);
}

/*
 * The failure record. `raw` is the number the sweep asked for and `applied` is what the
 * bench handed the setter (they differ only when --sanitize is on), so the line says both
 * what was tested and what reached the DSP. The seed and block are the reproduction.
 */
constexpr int STEP_HISTORY = 6;
char g_step_history[STEP_HISTORY][160];
int  g_step_history_pos;
int  g_step_history_count;

void history_push(const char *entry)
{
    std::snprintf(g_step_history[g_step_history_pos], sizeof(g_step_history[0]),
                  "%s", entry);
    g_step_history_pos = (g_step_history_pos + 1) % STEP_HISTORY;
    if (g_step_history_count < STEP_HISTORY) {
        g_step_history_count++;
    }
}

/*
 * The last few steps, oldest first, printed with a rescue.
 *
 * The fuse reads the tail of a block, and an effect with a long line — the reverb's combs
 * are over a thousand samples — carries a bad number to that tail several steps after the
 * setter that wrote it. Naming only the step that happened to fire would send a reader to
 * the wrong knob; the history makes the origin visible.
 */
void history_print()
{
    std::fprintf(stderr, "  recent steps (oldest first):\n");
    for (int i = 0; i < g_step_history_count; i++) {
        const int idx = (g_step_history_pos - g_step_history_count + i + STEP_HISTORY)
                        % STEP_HISTORY;
        std::fprintf(stderr, "    %s\n", g_step_history[idx]);
    }
}

void report_rescue(const char *what, float raw, float applied, uint64_t block,
                   bool has_value)
{
    g_rescue_events++;

    synth_rack_rescue_t snap;
    memset(&snap, 0, sizeof(snap));
    synth_rack_rescue_snapshot(&snap);

    std::fprintf(stderr,
                 "\nRESCUE %llu at block %llu (mode %s, seed %llu, step %llu): %s\n",
                 (unsigned long long)g_rescue_events,
                 (unsigned long long)block,
                 g_mode_name,
                 (unsigned long long)g_seed,
                 (unsigned long long)g_step,
                 what);
    if (has_value) {
        std::fprintf(stderr, "  raw ");
        print_float_bits(stderr, "value", raw);
        std::fprintf(stderr, ", applied ");
        print_float_bits(stderr, "value", applied);
        std::fputc('\n', stderr);
    }
    std::fprintf(stderr, "  fuse: cause=%s serial=%u silence=%u nonfinite=%u "
                         "master=%g comp=%g gate=%g duck=%g drone=%g\n",
                 (snap.cause == 1u) ? "silence" : "non-finite",
                 (unsigned)snap.serial, (unsigned)snap.silence_count,
                 (unsigned)snap.nonfinite_count, (double)snap.master,
                 (double)snap.comp, (double)snap.gate, (double)snap.duck,
                 (double)snap.drone);
    std::fprintf(stderr, "  state: ");
    print_state(stderr);

    if (g_step > 0 && g_step_history_count > 0) {
        history_print();
    }
}

void publish_perc_env()
{
    const float now = synth_perc_env();

    if (now > g_perc_env01) {
        g_perc_env01 = now;
    } else {
        g_perc_env01 += (now - g_perc_env01) * g_perc_env_release;
    }

    if (!(g_perc_env01 > 0.0f)) {
        g_perc_env01 = 0.0f;
    } else if (g_perc_env01 > 1.0f) {
        g_perc_env01 = 1.0f;
    }

    synth_dsp_set_perc_env(g_perc_env01);
}

/* Returns true when a rescue happened in this block. */
bool render_block()
{
    const uint32_t before = synth_rack_rescue_count();
    const uint64_t index  = g_block;

    fill_layers(index);

    /* The deliberate wound, for --inject-nan: one non-finite sample on a layer's input,
     * exactly where the engine's output would arrive. It is placed on the LAST sample of
     * the block because the rack's fuse reads the tail — the design assumption is that a
     * number which can stay bad lives in a recursive state, and a single bad sample in the
     * middle of a dry sum is a click the fuse does not pretend to catch. */
    if (g_inject_block != 0 && index == g_inject_block) {
        synth_layer_l(2)[BLOCK - 1] = std::numeric_limits<float>::quiet_NaN();
    }

    synth_rack_process(BLOCK, g_out);
    publish_perc_env();

    for (int i = 0; i < BLOCK * 2; i++) {
        const float f = (float)g_out[i] * (1.0f / 32768.0f);
        if (!std::isfinite(f)) {
            g_nonfinite_out++;
        }
        if (g_out[i] < g_peak_min) {
            g_peak_min = g_out[i];
        }
        if (g_out[i] > g_peak_max) {
            g_peak_max = g_out[i];
        }
    }

    g_blocks_done++;
    g_block++;
    host_advance_us(AUDIO_BLOCK_US);

    const uint32_t after = synth_rack_rescue_count();
    if (after != before) {
        g_rescues_seen += (uint64_t)(after - before);
        return true;
    }
    return false;
}

/* -------------------------------------------------------------------------- */
/* The boot fade, checked by number                                           */
/* -------------------------------------------------------------------------- */
/*
 * The owner's complaint was that the instrument made noise while it was booting, and
 * the fix is that the rack holds the master at zero until main() says the boot is over,
 * then waits 150 ms and ramps over 700 ms. This pass is what proves that, without a
 * board and without an ear:
 *
 *   - every block before the arm renders exact zeros, with a signal on the layers;
 *   - every block that ends before the delay is exact zeros too;
 *   - the gain at each block start is nondecreasing and matches the straight line
 *     (t - delay) / fade within a float ulp, so the ramp is linear in amplitude;
 *   - the faded output of every block is no louder than the SAME block rendered with
 *     the fade finished — the two phases start from the same signal state, so the only
 *     difference is the master multiplier;
 *   - after the ramp the gain is exactly 1.0 and the samples are bit-identical to the
 *     steady run, which is what "the settled instrument did not change" means.
 *
 * The rack is driven through its dry path on purpose — every effect closed, no
 * percussion — so the input to the master is a pure, repeatable function of the block
 * index. The signal generator and the filter LFOs are reset between the two phases, so
 * block N of the fade and block N of the steady run are the same samples.
 */
constexpr int BOOT_CHECK_BLOCKS    = 200;
constexpr int BOOT_SETTLE_BLOCKS   = 16;
constexpr int BOOT_SILENT_BLOCKS   = 4;
constexpr int BOOT_IDENTICAL_BLOCKS = 8;

int32_t boot_block_peak()
{
    int32_t peak = 0;
    for (int i = 0; i < BLOCK * 2; i++) {
        const int32_t v = g_out[i];
        const int32_t a = (v < 0) ? -v : v;
        if (a > peak) {
            peak = a;
        }
    }
    return peak;
}

constexpr uint32_t boot_delay_samples()
{
    return (uint32_t)((float)SYNTH_SAMPLE_RATE * (SYNTH_BOOT_FADE_DELAY_MS / 1000.0f));
}

constexpr uint32_t boot_fade_samples()
{
    return (uint32_t)((float)SYNTH_SAMPLE_RATE * (SYNTH_BOOT_FADE_MS / 1000.0f));
}

float boot_expected_gain(int block)
{
    const uint32_t t = (uint32_t)block * (uint32_t)BLOCK;
    if (t < boot_delay_samples()) {
        return 0.0f;
    }
    const uint32_t f = t - boot_delay_samples();
    if (f >= boot_fade_samples()) {
        return 1.0f;
    }
    return (float)f * (1.0f / (float)boot_fade_samples());
}

/*
 * Fresh signal state for one phase. `signal_init()` already rebuilds the layer phases,
 * the bus filters and the pan endpoints; the RNG and the LFO epochs are the two pieces
 * of state it does not own. The pan depth is zeroed because the drift's own phase lives
 * in the pan module and its absolute position would otherwise differ between the two
 * phases — a static centre gives the same gain without needing that state reset.
 */
void boot_signal_reset(uint32_t seed)
{
    signal_init();
    *g_sig_rng = Rng((uint64_t)seed ^ 0x9E3779B97F4A7C15ull);

    for (int i = 0; i < SYNTH_NUM_LAYERS; i++) {
        g_pan_ep[i][0] = 0;     /* centre */
        g_pan_ep[i][1] = 0;     /* no drift */
    }

    synth_drone_lfo_trig(0);
    synth_drone_lfo_retrigger();

    g_block = 0;
    g_peak_min = 32767;
    g_peak_max = -32768;
    g_nonfinite_out = 0;
    g_rescues_seen = 0;
}

/*
 * The controls this pass runs with: a plain sum of five layers at the baseline levels,
 * master at 0.9, and every effect closed. Closing them also keeps s_want_fx false, so
 * the rack takes its dry path and its output is exactly the layers times the two gains
 * — the shortest path from the fade to the sample.
 */
void boot_controls()
{
    g_gate = 1;
    g_transport = 1;

    g_master = 0.90f;
    synth_rack_set_master(g_master);

    for (int i = 0; i < SYNTH_NUM_LAYERS; i++) {
        g_layer_level[i] = 0.85f;
        synth_rack_set_layer_level(i, g_layer_level[i]);
    }

    g_comp = 0.0f;
    g_duck = 0.0f;
    synth_rack_set_comp(g_comp);
    synth_rack_set_duck(g_duck);

    g_chorus_mix = 0.0f;
    g_delay_mix  = 0.0f;
    g_reverb_mix = 0.0f;
    synth_rack_set_chorus(0.60f, 0.35f, 0.0f);
    synth_rack_set_delay(12000.0f, 0.35f, 0.0f, false);
    synth_rack_set_reverb(0.50f, 0.40f, 0.0f, SYNTH_REVERB_HALL);

    synth_rack_set_gate(g_gate);
    synth_rack_set_transport(g_transport);
}

bool run_boot_fade_check(uint32_t seed)
{
    std::printf("\nboot fade: delay %.3f ms (%u samples), fade %.3f ms (%u samples), "
                "%d-sample blocks\n",
                (double)SYNTH_BOOT_FADE_DELAY_MS, (unsigned)boot_delay_samples(),
                (double)SYNTH_BOOT_FADE_MS, (unsigned)boot_fade_samples(), BLOCK);

    boot_controls();

    /* The layer-level glides start on their targets after 16 blocks, and the pan has
     * settled at its centre. The output is still zero here: the boot gate is closed. */
    boot_signal_reset(seed);
    for (int i = 0; i < BOOT_SETTLE_BLOCKS; i++) {
        render_block();
    }

    /* 1. Silence before the arm, with a live signal behind the gate. */
    boot_signal_reset(seed);
    bool pre_silent = true;
    for (int i = 0; i < BOOT_SILENT_BLOCKS; i++) {
        render_block();
        if (boot_block_peak() != 0) {
            pre_silent = false;
        }
    }

    /* 2. The fade itself, starting from the same signal state as the steady run below. */
    synth_rack_boot_arm();
    boot_signal_reset(seed);

    int32_t  fade_peak[BOOT_CHECK_BLOCKS];
    float    gain_start[BOOT_CHECK_BLOCKS];
    int16_t  fade_tail[BOOT_IDENTICAL_BLOCKS][BLOCK * 2];
    int      first_sound = -1;
    int      nonzero_before_delay = 0;

    for (int b = 0; b < BOOT_CHECK_BLOCKS; b++) {
        gain_start[b] = synth_rack_boot_gain();
        render_block();
        fade_peak[b] = boot_block_peak();

        if (fade_peak[b] != 0 && first_sound < 0) {
            first_sound = b;
        }
        /* The blocks that END before the delay are the ones that must be exactly zero. */
        if ((uint64_t)(b + 1) * (uint64_t)BLOCK <= (uint64_t)boot_delay_samples()
            && fade_peak[b] != 0) {
            nonzero_before_delay++;
        }
        if (b >= BOOT_CHECK_BLOCKS - BOOT_IDENTICAL_BLOCKS) {
            std::memcpy(fade_tail[b - (BOOT_CHECK_BLOCKS - BOOT_IDENTICAL_BLOCKS)],
                        g_out, sizeof(g_out));
        }
    }

    const float gain_after_fade = synth_rack_boot_gain();

    /* 3. The same blocks with the fade finished. */
    boot_signal_reset(seed);
    int32_t steady_peak[BOOT_CHECK_BLOCKS];
    int16_t steady_tail[BOOT_IDENTICAL_BLOCKS][BLOCK * 2];
    for (int b = 0; b < BOOT_CHECK_BLOCKS; b++) {
        render_block();
        steady_peak[b] = boot_block_peak();
        if (b >= BOOT_CHECK_BLOCKS - BOOT_IDENTICAL_BLOCKS) {
            std::memcpy(steady_tail[b - (BOOT_CHECK_BLOCKS - BOOT_IDENTICAL_BLOCKS)],
                        g_out, sizeof(g_out));
        }
    }

    /* 4. The arithmetic of the ramp, at the block boundaries where it is observable. */
    int    drops = 0;
    double linear_error = 0.0;
    for (int b = 0; b < BOOT_CHECK_BLOCKS; b++) {
        const float want = boot_expected_gain(b);
        const double err = std::fabs((double)gain_start[b] - (double)want);
        if (err > linear_error) {
            linear_error = err;
        }
        if (b > 0 && gain_start[b] < gain_start[b - 1]) {
            drops++;
        }
    }

    double step_error = 0.0;
    const double step_want = (double)BLOCK / (double)boot_fade_samples();
    for (int b = 0; b + 1 < BOOT_CHECK_BLOCKS; b++) {
        const float want0 = boot_expected_gain(b);
        const float want1 = boot_expected_gain(b + 1);
        if (want0 > 0.0f && want0 < 1.0f && want1 < 1.0f) {
            const double got = (double)gain_start[b + 1] - (double)gain_start[b];
            const double err = std::fabs(got - step_want);
            if (err > step_error) {
                step_error = err;
            }
        }
    }

    /* 5. No faded block may be louder than its steady counterpart, and after the ramp
     * the two must be the same samples, not merely the same peak. */
    int32_t worst_over = 0;
    int     over_blocks = 0;
    for (int b = 0; b < BOOT_CHECK_BLOCKS; b++) {
        const int32_t over = fade_peak[b] - steady_peak[b];
        if (over > worst_over) {
            worst_over = over;
        }
        if (over > 0) {
            over_blocks++;
        }
    }

    int tail_equal = 0;
    for (int i = 0; i < BOOT_IDENTICAL_BLOCKS; i++) {
        if (std::memcmp(fade_tail[i], steady_tail[i], sizeof(fade_tail[i])) == 0) {
            tail_equal++;
        }
    }

    /* The last block that still begins inside the fade; the one after it starts at 1. */
    int last_fade_block = -1;
    for (int b = 0; b < BOOT_CHECK_BLOCKS; b++) {
        if (boot_expected_gain(b) < 1.0f) {
            last_fade_block = b;
        }
    }

    std::printf("  before arm: %s (%d blocks, peak %d)\n",
                pre_silent ? "exact silence" : "NOT SILENT",
                BOOT_SILENT_BLOCKS, pre_silent ? 0 : 1);
    std::printf("  through the delay: %s (%d blocks end at or before %u samples)\n",
                (nonzero_before_delay == 0) ? "exact silence" : "NONZERO SAMPLE",
                (int)(boot_delay_samples() / (uint32_t)BLOCK), (unsigned)boot_delay_samples());
    std::printf("  first sounding block: %d, gain at its start %.6f (expected %.6f)\n",
                first_sound, (first_sound >= 0) ? (double)gain_start[first_sound] : 0.0,
                (first_sound >= 0) ? (double)boot_expected_gain(first_sound) : 0.0);
    std::printf("  gain: %d blocks from %.6f to %.6f, then exactly %.1f; %s (%d drops)\n",
                last_fade_block + 1, (double)gain_start[0],
                (double)gain_start[last_fade_block], (double)gain_after_fade,
                (drops == 0) ? "monotonic" : "NOT MONOTONIC", drops);
    std::printf("  linearity: max gain error %.3g, max step error %.3g "
                "(step %.9f = %d/%u)\n",
                linear_error, step_error, step_want, BLOCK, (unsigned)boot_fade_samples());
    std::printf("  faded <= steady: %s (%d/%d blocks, worst %+d LSB)\n",
                (over_blocks == 0) ? "yes" : "NO",
                BOOT_CHECK_BLOCKS - over_blocks, BOOT_CHECK_BLOCKS, (int)worst_over);
    std::printf("  after the fade: %d/%d tail blocks bit-identical to the steady run\n",
                tail_equal, BOOT_IDENTICAL_BLOCKS);

    const bool ok = pre_silent
                 && (nonzero_before_delay == 0)
                 && (first_sound >= 0)
                 && (drops == 0)
                 && (linear_error < 1.0e-6)
                 && (step_error < 1.0e-6)
                 && (over_blocks == 0)
                 && (gain_after_fade == 1.0f)
                 && (tail_equal == BOOT_IDENTICAL_BLOCKS);

    std::printf("boot fade: %s\n", ok ? "PASS" : "FAIL");
    return ok;
}

/* -------------------------------------------------------------------------- */
/* Options                                                                    */
/* -------------------------------------------------------------------------- */

enum RunMode { MODE_BOTH, MODE_SWEEP, MODE_RANDOM };

/* Defined with the sweep table below; the default budget needs them before it can be
 * resolved, and the sweep's cost must be a computed number rather than a copied one. */
uint64_t sweep_step_count();
uint64_t sweep_block_budget();

struct Options {
    uint32_t seed = 1;
    uint64_t blocks = 0;         /* 0 = derive from seconds, or from the sweep */
    double   seconds = -1.0;     /* <0 = no --seconds: use the default block budget */
    RunMode  mode = MODE_BOTH;
    bool     keep_going = false;
    bool     sanitize = false;
    bool     transport = false;
    uint64_t inject_block = 0;
    size_t   heap_limit = 0;
    bool     trace = false;
    bool     boot_fade = false;  /* the boot-fade pass, then exit */
    uint64_t start_step = 1;     /* diagnostic resume point after a crash */
};

Options g_opt;

void usage(const char *argv0)
{
    std::fprintf(stderr,
        "usage: %s [--seed N] [--blocks N | --seconds S] [--mode both|sweep|random]\n"
        "          [--keep-going] [--sanitize] [--transport] [--inject-nan N]\n"
        "          [--heap-limit BYTES] [--trace] [--start-step N] [--boot-fade]\n",
        argv0);
}

bool parse_args(int argc, char **argv)
{
    for (int i = 1; i < argc; i++) {
        const char *a = argv[i];

        auto need = [&](const char *name) -> const char * {
            if (i + 1 >= argc) {
                std::fprintf(stderr, "%s: %s needs a value\n", argv[0], name);
                return nullptr;
            }
            return argv[++i];
        };

        if (std::strcmp(a, "--seed") == 0) {
            const char *v = need(a);
            if (!v) return false;
            g_opt.seed = (uint32_t)std::strtoul(v, nullptr, 0);
        } else if (std::strcmp(a, "--blocks") == 0) {
            const char *v = need(a);
            if (!v) return false;
            g_opt.blocks = std::strtoull(v, nullptr, 0);
        } else if (std::strcmp(a, "--seconds") == 0) {
            const char *v = need(a);
            if (!v) return false;
            g_opt.seconds = std::strtod(v, nullptr);
        } else if (std::strcmp(a, "--mode") == 0) {
            const char *v = need(a);
            if (!v) return false;
            if (std::strcmp(v, "both") == 0)        g_opt.mode = MODE_BOTH;
            else if (std::strcmp(v, "sweep") == 0)  g_opt.mode = MODE_SWEEP;
            else if (std::strcmp(v, "random") == 0) g_opt.mode = MODE_RANDOM;
            else {
                std::fprintf(stderr, "%s: unknown mode %s\n", argv[0], v);
                return false;
            }
        } else if (std::strcmp(a, "--keep-going") == 0) {
            g_opt.keep_going = true;
        } else if (std::strcmp(a, "--sanitize") == 0) {
            g_opt.sanitize = true;
        } else if (std::strcmp(a, "--transport") == 0) {
            g_opt.transport = true;
        } else if (std::strcmp(a, "--inject-nan") == 0) {
            const char *v = need(a);
            if (!v) return false;
            g_opt.inject_block = std::strtoull(v, nullptr, 0);
        } else if (std::strcmp(a, "--heap-limit") == 0) {
            const char *v = need(a);
            if (!v) return false;
            g_opt.heap_limit = (size_t)std::strtoull(v, nullptr, 0);
        } else if (std::strcmp(a, "--trace") == 0) {
            g_opt.trace = true;
        } else if (std::strcmp(a, "--boot-fade") == 0) {
            g_opt.boot_fade = true;
        } else if (std::strcmp(a, "--start-step") == 0) {
            const char *v = need(a);
            if (!v) return false;
            g_opt.start_step = std::strtoull(v, nullptr, 0);
            if (g_opt.start_step == 0) {
                g_opt.start_step = 1;
            }
        } else if (std::strcmp(a, "--help") == 0 || std::strcmp(a, "-h") == 0) {
            usage(argv[0]);
            return false;
        } else {
            std::fprintf(stderr, "%s: unknown option %s\n", argv[0], a);
            usage(argv[0]);
            return false;
        }
    }

    if (g_opt.boot_fade) {
        return true;    /* the pass renders its own fixed number of blocks */
    }

    if (g_opt.blocks == 0) {
        if (g_opt.seconds >= 0.0) {
            if (!(g_opt.seconds > 0.0)) {
                std::fprintf(stderr, "%s: --seconds must be positive\n", argv[0]);
                return false;
            }
            /* BLOCK is in samples, so the quotient stays audio seconds whatever the
             * block size is: 20 s at 48 kHz is 3750 blocks of 256, not 1875. */
            g_opt.blocks = (uint64_t)(g_opt.seconds * (double)SYNTH_SAMPLE_RATE
                                      / (double)BLOCK + 0.5);
        } else {
            /* No explicit budget: the sweep is what a default run is for, so its full
             * cost is granted first and the walk soaks on top. */
            g_opt.blocks = sweep_block_budget() + DEFAULT_RANDOM_BLOCKS;
        }
    }

    g_inject_block = g_opt.inject_block;

    if (g_inject_block != 0) {
        /* The injection test is a short, deliberate failure; make sure it has room to
         * reach the block it names. */
        if (g_opt.blocks < g_inject_block + 8) {
            g_opt.blocks = g_inject_block + 8;
        }
    }

    return true;
}

/* -------------------------------------------------------------------------- */
/* Warm-up                                                                    */
/* -------------------------------------------------------------------------- */

/*
 * The claim tasks are real threads, and they wake on a 10 ms sleep. Before any block is
 * measured, every effect is asked for and given real time to finish, including the plate,
 * which is otherwise only claimed the first time its mode is chosen. Without this the
 * first measured blocks would depend on how the scheduler happened to run, and the seed
 * would not be the whole recipe.
 */
bool warm_up()
{
    const uint32_t base = synth_rack_rescue_count();

    for (int phase = 0; phase < 3; phase++) {
        if (phase == 1) {
            synth_rack_set_reverb(g_reverb_size, g_reverb_damp, g_reverb_mix,
                                  SYNTH_REVERB_PLATE);
        } else if (phase == 2) {
            synth_rack_set_reverb(g_reverb_size, g_reverb_damp, g_reverb_mix,
                                  SYNTH_REVERB_HALL);
        }

        for (int i = 0; i < 24; i++) {
            host_set_step_context("warm-up: claiming effect memory and settling");
            if (render_block()) {
                std::fprintf(stderr, "warm-up: rescue before the run; refusing to measure\n");
                return false;
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(8));
        }
    }

    if (synth_rack_rescue_count() != base) {
        return false;
    }

    /* The warm-up is not part of the run: its blocks, its peak and its time do not
     * belong in the verdict, and a seed must start at block one. */
    g_block = 1;
    g_blocks_done = 0;
    g_peak_min = 32767;
    g_peak_max = -32768;
    g_rescues_seen = synth_rack_rescue_count();

    /*
     * THE BENCH IS A BOOTED INSTRUMENT. The rack holds its master at zero until main()
     * arms the boot fade, and this program is not main(): without this the whole run
     * would measure the deliberate silence and pass while testing nothing. Arm it, render
     * past the 150 + 700 ms, then put the signal generator and the counters back so the
     * run starts at block one with the fade at exactly one. The fade itself is measured
     * by --boot-fade, which is a separate process with its own controls.
     */
    synth_rack_boot_arm();
    for (int i = 0; i < BOOT_CHECK_BLOCKS; i++) {
        host_set_step_context("warm-up: passing the boot fade");
        if (render_block()) {
            std::fprintf(stderr, "warm-up: rescue during the boot fade; refusing to measure\n");
            return false;
        }
    }

    signal_init();
    *g_sig_rng = Rng((uint64_t)g_opt.seed ^ 0x9E3779B97F4A7C15ull);
    g_block = 1;
    g_blocks_done = 0;
    g_peak_min = 32767;
    g_peak_max = -32768;
    g_nonfinite_out = 0;
    g_rescues_seen = synth_rack_rescue_count();
    return true;
}

/* -------------------------------------------------------------------------- */
/* Int setter scan                                                            */
/* -------------------------------------------------------------------------- */

struct ModeValue {
    const char *name;
    int         value;
};

void apply_reverb_mode(int m)
{
    g_reverb_mode = m;
    synth_rack_set_reverb(g_reverb_size, g_reverb_damp, g_reverb_mix, m);
}

void apply_gate(int g)
{
    g_gate = g;
    synth_rack_set_gate(g);
}

void apply_transport(int t)
{
    g_transport = t;
    synth_rack_set_transport(t);
}

void apply_crossfade(int c)
{
    g_delay_crossfade = (c != 0);
    synth_rack_set_delay(g_delay_time, g_delay_fb, g_delay_mix, g_delay_crossfade);
}

struct ModeSpec {
    const char     *name;
    const ModeValue *values;
    int             count;
    void          (*apply)(int);
};

const ModeValue g_reverb_modes[] = {
    { "reverb.mode=-1", -1 }, { "reverb.mode=0", 0 }, { "reverb.mode=1", 1 },
    { "reverb.mode=2", 2 },   { "reverb.mode=3", 3 }, { "reverb.mode=4", 4 },
    { "reverb.mode=99", 99 },
};
const ModeValue g_gate_values[] = {
    { "gate=0", 0 }, { "gate=1", 1 },
};
const ModeValue g_transport_values[] = {
    { "transport=0", 0 }, { "transport=1", 1 },
};
const ModeValue g_crossfade_values[] = {
    { "delay.crossfade=0", 0 }, { "delay.crossfade=1", 1 },
};

const ModeSpec g_modes[] = {
    { "reverb.mode", g_reverb_modes, (int)(sizeof(g_reverb_modes) / sizeof(g_reverb_modes[0])), apply_reverb_mode },
    { "gate", g_gate_values, (int)(sizeof(g_gate_values) / sizeof(g_gate_values[0])), apply_gate },
    { "transport", g_transport_values, (int)(sizeof(g_transport_values) / sizeof(g_transport_values[0])), apply_transport },
    { "delay.crossfade", g_crossfade_values, (int)(sizeof(g_crossfade_values) / sizeof(g_crossfade_values[0])), apply_crossfade },
};

constexpr int MODE_SPEC_COUNT = (int)(sizeof(g_modes) / sizeof(g_modes[0]));

/* -------------------------------------------------------------------------- */
/* The sweep                                                                  */
/* -------------------------------------------------------------------------- */

/* The sweep's state, for the verdict. It starts incomplete: a pass that is never
 * reached, or that stops on a rescue, must not leave a green flag behind. */
bool     g_sweep_ran = false;
bool     g_sweep_complete = false;
uint64_t g_sweep_last_step = 0;
uint64_t g_sweep_used_blocks = 0;

uint64_t sweep_step_count()
{
    uint64_t steps = (uint64_t)KNOB_COUNT * (uint64_t)VALUE_COUNT;
    for (int i = 0; i < MODE_SPEC_COUNT; i++) {
        steps += (uint64_t)g_modes[i].count;
    }
    return steps;
}

uint64_t sweep_block_budget()
{
    return sweep_step_count() * (uint64_t)BLOCKS_STEP;
}

/*
 * The budget check that runs before a step. Exhausting the budget is not a shorter
 * pass: the unvisited values are exactly the ones that might have found the next
 * arithmetic hole, so this records the shortfall and fails the run.
 */
bool sweep_out_of_budget(const char *where, uint64_t start, uint64_t max_blocks)
{
    g_sweep_complete = false;
    g_sweep_last_step = g_step;
    g_sweep_used_blocks = g_blocks_done - start;

    std::fprintf(stderr,
                 "sweep: INCOMPLETE (%s): %llu of %llu steps, %llu of %llu blocks; "
                 "budget %llu blocks, raise -Seconds or -Blocks\n",
                 where,
                 (unsigned long long)g_sweep_last_step,
                 (unsigned long long)sweep_step_count(),
                 (unsigned long long)g_sweep_used_blocks,
                 (unsigned long long)sweep_block_budget(),
                 (unsigned long long)max_blocks);
    return false;
}

/* Run one value through a few blocks. Returns false on a rescue in fail-fast mode. */
bool run_one_step(const char *what, float raw, float applied, bool fail_fast)
{
    g_step++;

    {
        char entry[160];
        std::snprintf(entry, sizeof(entry), "step %llu: %s (applied %g)",
                      (unsigned long long)g_step, what, (double)applied);
        history_push(entry);
    }

    for (int b = 0; b < BLOCKS_STEP; b++) {
        char context[512];
        std::snprintf(context, sizeof(context),
                      "seed %u, sweep step %llu, block %llu: %s (raw %g, applied %g)",
                      (unsigned)g_opt.seed, (unsigned long long)g_step,
                      (unsigned long long)g_block, what, (double)raw, (double)applied);
        host_set_step_context(context);

        if (render_block()) {
            report_rescue(what, raw, applied, g_block - 1, true);
            if (fail_fast) {
                return false;
            }
            /* The value has been tested; let the next one overwrite it rather than
             * counting the same wound once per block. */
            break;
        }
    }
    return true;
}

bool run_sweep(uint64_t max_blocks, bool fail_fast)
{
    g_mode_name = "sweep";
    g_sweep_ran = true;
    g_sweep_complete = false;
    const uint64_t start = g_blocks_done;

    for (int i = 0; i < KNOB_COUNT; i++) {
        const Knob &k = g_knobs[i];

        for (int v = 0; v < VALUE_COUNT; v++) {
            if (g_step + 1 < g_opt.start_step) {
                g_step++;
                continue;
            }

            if (g_blocks_done - start + BLOCKS_STEP > max_blocks) {
                return sweep_out_of_budget("parameters", start, max_blocks);
            }

            const TestValue &tv = g_values[v];
            const float raw = tv.random ? (g_rng->unit() * 4.0f - 2.0f) : tv.raw;

            float applied = map_into_range(raw, k);
            if (g_opt.sanitize) {
                applied = repair_value(raw, k);
            }

            apply_knob(k, applied);

            /* A knob on the drum is only tested when the drum is struck: PITCH, RES,
             * DECAY and the rest are read at strike time and latched into a voice, so a
             * setter call with no hit after it leaves the module with a value nothing has
             * used yet. The hit is what puts the value into the arithmetic. */
            if (k.kind >= K_PERC_PITCH && k.kind <= K_PERC_BODY) {
                synth_perc_trigger(0.80f, 1.0f);
            }

            char label[160];
            std::snprintf(label, sizeof(label), "%s = %s%s", k.name, tv.name,
                          g_opt.sanitize ? " (sanitized)" : "");
            if (g_opt.trace) {
                std::fprintf(stderr, "step %llu: %s raw=%g applied=%g\n",
                             (unsigned long long)(g_step + 1), label,
                             (double)raw, (double)applied);
            }
            if (!run_one_step(label, raw, applied, fail_fast)) {
                /* A rescue stops the pass: the remaining values are untested. */
                g_sweep_last_step = g_step;
                g_sweep_used_blocks = g_blocks_done - start;
                return false;
            }
        }
    }

    for (int m = 0; m < MODE_SPEC_COUNT; m++) {
        const ModeSpec &spec = g_modes[m];

        for (int v = 0; v < spec.count; v++) {
            if (g_step + 1 < g_opt.start_step) {
                g_step++;
                continue;
            }

            if (g_blocks_done - start + BLOCKS_STEP > max_blocks) {
                return sweep_out_of_budget("mode scan", start, max_blocks);
            }

            spec.apply(spec.values[v].value);

            char label[160];
            std::snprintf(label, sizeof(label), "%s (%s)", spec.values[v].name, spec.name);
            if (g_opt.trace) {
                std::fprintf(stderr, "step %llu: %s\n",
                             (unsigned long long)(g_step + 1), label);
            }
            if (!run_one_step(label, (float)spec.values[v].value,
                              (float)spec.values[v].value, fail_fast)) {
                g_sweep_last_step = g_step;
                g_sweep_used_blocks = g_blocks_done - start;
                return false;
            }
        }
    }

    /* The scan's last pass may have left the rack on a mode no baseline asks for. */
    apply_reverb_mode(SYNTH_REVERB_HALL);
    apply_crossfade(0);
    apply_gate(1);
    apply_transport(g_opt.transport ? 1 : 0);

    g_sweep_last_step = sweep_step_count();
    g_sweep_used_blocks = g_blocks_done - start;
    g_sweep_complete = true;
    return true;
}

/* -------------------------------------------------------------------------- */
/* The random walk                                                            */
/* -------------------------------------------------------------------------- */

float g_norm[KNOB_COUNT];
float g_target[KNOB_COUNT];

int knob_by_kind(Kind kind)
{
    for (int i = 0; i < KNOB_COUNT; i++) {
        if (g_knobs[i].kind == kind) {
            return i;
        }
    }
    return -1;
}

void random_walk_init()
{
    for (int i = 0; i < KNOB_COUNT; i++) {
        const Knob &k = g_knobs[i];
        const float v = current_value(k);
        g_norm[i] = (k.hi > k.lo) ? (v - k.lo) / (k.hi - k.lo) : 0.0f;
        g_norm[i] = clamp_like_firmware(g_norm[i], 0.0f, 1.0f);
        g_target[i] = g_norm[i];
    }
}

/*
 * One block of a hand on the controls. Every non-trigger knob glides towards its target
 * every block; a few targets move each block, some to a boundary; the effects' modes and
 * the delay's time change on their own schedule. The drum is struck by a separate clock,
 * which is what a sequencer does.
 */
bool run_random(uint64_t blocks, bool fail_fast)
{
    g_mode_name = "random";
    random_walk_init();

    const int i_delay = knob_by_kind(K_DELAY_TIME);

    int hit_in = 8 + (int)(g_rng->next() % 24);
    uint32_t tempo_clock = 0;

    for (uint64_t n = 0; n < blocks; n++) {
        /* Targets: mostly a fresh random point, sometimes a boundary. One or two knobs
         * per block is a hand moving, not a generator rewriting the page. */
        for (int i = 0; i < KNOB_COUNT; i++) {
            const Kind kind = g_knobs[i].kind;
            if (kind == K_TRIG_VEL || kind == K_TRIG_RATIO) {
                continue;
            }
            if (g_rng->unit() < 0.006f) {
                const float r = g_rng->unit();
                if (r < 0.15f) {
                    g_target[i] = 0.0f;
                } else if (r < 0.30f) {
                    g_target[i] = 1.0f;
                } else {
                    g_target[i] = g_rng->unit();
                }
            }
        }

        if ((tempo_clock++ % 32u) == 0u) {
            static const int bpms[] = { 60, 90, 120, 180, 240 };
            static const int divs[] = { 1, 2, 3, 4, 6, 8 };
            const int bpm = bpms[g_rng->next() % 5u];
            const int div = divs[g_rng->next() % 6u];
            const float seconds = (60.0f / (float)bpm) / (float)div;
            const float samples = seconds * (float)SYNTH_SAMPLE_RATE;
            if (i_delay >= 0) {
                const Knob &k = g_knobs[i_delay];
                g_target[i_delay] = clamp_like_firmware((samples - k.lo) / (k.hi - k.lo),
                                                        0.0f, 1.0f);
            }
        }

        /* The two ends of the delay line, jumped to rather than glided to, and with the
         * crossfade toggled: this is the short/long test the sweep cannot do because it
         * tests one value in isolation. */
        if (i_delay >= 0 && (n % 128u) == 0u) {
            g_norm[i_delay] = g_target[i_delay] = ((n / 128u) & 1u) ? 1.0f : 0.0f;
            g_delay_crossfade = ((n / 128u) & 2u) != 0u;
            synth_rack_set_delay(g_delay_time, g_delay_fb, g_delay_mix, g_delay_crossfade);
        }

        /* Glide and apply. Trigger knobs are excluded: they are events, not levels, and
         * re-triggering the drum 48 000 times a second is not a walk. */
        for (int i = 0; i < KNOB_COUNT; i++) {
            const Knob &k = g_knobs[i];
            if (k.kind == K_TRIG_VEL || k.kind == K_TRIG_RATIO) {
                continue;
            }
            const float glide = 0.03f + 0.10f * (float)((i * 37) % 11) / 11.0f;
            g_norm[i] += (g_target[i] - g_norm[i]) * glide;
            g_norm[i] = clamp_like_firmware(g_norm[i], 0.0f, 1.0f);
            apply_knob(k, k.lo + g_norm[i] * (k.hi - k.lo));
        }

        /* Modes. The reverb has four topologies and the plate has its own pool; the
         * delay has two ways to change time. Both are switches a hand can reach, so both
         * move. The drive's four shapers and two positions used to be here and are gone
         * with the stage itself. */
        if ((n % 24u) == 0u) {
            apply_reverb_mode((int)(g_rng->next() % (uint64_t)SYNTH_REVERB_MODE_COUNT));
            apply_crossfade((int)(g_rng->next() & 1u));
        }

        /* A drum figure: irregular, quiet sometimes, never the same twice. */
        if (--hit_in <= 0) {
            static const float ratios[] = { 0.5f, 0.75f, 1.0f, 1.5f, 2.0f, 3.0f, 4.0f };
            hit_in = 10 + (int)(g_rng->next() % 38u);
            synth_perc_trigger(0.15f + 0.85f * g_rng->unit(),
                               ratios[g_rng->next() % 7u]);
        }

        {
            char context[256];
            std::snprintf(context, sizeof(context),
                          "seed %u, random block %llu of %llu",
                          (unsigned)g_opt.seed, (unsigned long long)(n + 1),
                          (unsigned long long)blocks);
            host_set_step_context(context);
        }

        if (render_block()) {
            char label[128];
            std::snprintf(label, sizeof(label),
                          "random walk, block %llu of %llu",
                          (unsigned long long)(n + 1), (unsigned long long)blocks);
            report_rescue(label, 0.0f, 0.0f, g_block - 1, false);
            if (fail_fast) {
                return false;
            }
        }
    }

    return true;
}

/* -------------------------------------------------------------------------- */
/* Report                                                                     */
/* -------------------------------------------------------------------------- */

void print_peak()
{
    if (g_blocks_done == 0) {
        std::printf("peak: no block rendered\n");
        return;
    }

    const int peak = std::max(std::abs(g_peak_min), std::abs(g_peak_max));
    const double dbfs = (peak > 0) ? 20.0 * std::log10((double)peak / 32768.0) : -200.0;

    std::printf("peak: %d .. %d (abs %d, %.1f dBFS)\n",
                g_peak_min, g_peak_max, peak, dbfs);
}

} // namespace

int main(int argc, char **argv)
{
    /* The bench interleaves its own lines with the firmware's rescue log on stderr, and
     * a run that mixed them out of order would be lying about what happened when. */
    std::setvbuf(stdout, nullptr, _IONBF, 0);
    std::setvbuf(stderr, nullptr, _IONBF, 0);

    if (!parse_args(argc, argv)) {
        return 1;
    }

    g_seed = g_opt.seed;
    g_rng = new Rng(g_opt.seed);
    g_sig_rng = new Rng((uint64_t)g_opt.seed ^ 0x9E3779B97F4A7C15ull);

    sine_table_init();
    host_platform_init();
    if (g_opt.heap_limit != 0) {
        host_heap_set_limit(g_opt.heap_limit);
    }

    std::printf("host audio bench: %d Hz, %d-sample blocks, seed %u, %llu blocks "
                "(%.3f s of audio)\n",
                SYNTH_SAMPLE_RATE, BLOCK, (unsigned)g_opt.seed,
                (unsigned long long)g_opt.blocks,
                (double)g_opt.blocks * (double)BLOCK / (double)SYNTH_SAMPLE_RATE);

    synth_dsp_init(SYNTH_SAMPLE_RATE);
    synth_drone_lfo_trig(0);
    synth_dsp_set_mic_env(0.0f, false);

    g_perc_env01 = 0.0f;
    g_perc_env_release = 1.0f - expf(-((float)BLOCK / (float)SYNTH_SAMPLE_RATE) / 0.140f);
    synth_dsp_set_perc_env(0.0f);

    signal_init();

    /* The boot fade has its own controls, its own signal state and its own fixed pass;
     * it deliberately never touches baseline_controls(), because that asks for the
     * effects and the dry path this check depends on would no longer be the path. */
    if (g_opt.boot_fade) {
        const bool ok = run_boot_fade_check(g_opt.seed);
        std::printf("\nresult: %s\n", ok ? "PASS" : "FAIL");
        return ok ? 0 : 1;
    }

    baseline_controls();
    g_transport = g_opt.transport ? 1 : 0;
    synth_rack_set_transport(g_transport);

    g_peak_min = 32767;
    g_peak_max = -32768;

    /* The injection test is deliberately simple: make the track as healthy as the
     * baseline asks for, then wound it once at a known block. It uses no sweep and no
     * random walk, so the only thing that can fail is the fuse. */
    if (g_inject_block != 0) {
        if (!warm_up()) {
            return 1;
        }
        g_mode_name = "inject";
        std::printf("inject: NaN on layer 2 at block %llu\n",
                    (unsigned long long)g_inject_block);

        while (g_block < g_inject_block + 4) {
            char context[256];
            std::snprintf(context, sizeof(context),
                          "seed %u, inject NaN at block %llu, block %llu",
                          (unsigned)g_opt.seed, (unsigned long long)g_inject_block,
                          (unsigned long long)g_block);
            host_set_step_context(context);

            if (render_block()) {
                report_rescue("injected NaN on layer 2", 0.0f, 0.0f, g_block - 1, false);
                break;
            }
        }

        std::printf("blocks: %llu\n", (unsigned long long)g_blocks_done);
        print_peak();
        const uint32_t rescues = synth_rack_rescue_count();
        std::printf("rescues: %u\n", (unsigned)rescues);
        std::printf("result: %s\n", (rescues == 0) ? "PASS" : "FAIL");
        return (rescues == 0) ? 0 : 1;
    }

    if (!warm_up()) {
        return 1;
    }

    const auto t0 = std::chrono::steady_clock::now();

    bool ok = true;
    const bool fail_fast = !g_opt.keep_going;
    const uint64_t total = g_opt.blocks;

    if (g_opt.mode == MODE_RANDOM) {
        ok = run_random(total, fail_fast);
    } else if (g_opt.mode == MODE_SWEEP) {
        ok = run_sweep(total, fail_fast);
    } else {
        /* Random first, so a long soak has already happened before the deterministic
         * sweep gets its turn — and so the sweep's result cannot hide the walk's. The
         * sweep's whole cost, and the settling pass between the two, are reserved first;
         * the walk soaks on what is left, so the run never renders more than asked for.
         * A budget too small for the sweep leaves the walk with nothing and fails on
         * the shortfall instead of quietly checking half the table. */
        const uint64_t sweep_need = sweep_block_budget();
        const uint64_t reserved = sweep_need + SWEEP_SETTLE_BLOCKS;
        const uint64_t random_budget = (total > reserved) ? (total - reserved) : 0;

        ok = (random_budget > 0) ? run_random(random_budget, fail_fast) : true;
        if (ok || g_opt.keep_going) {
            /* A rescue leaves the state as the fuse put it; give the sweep a sane,
             * settled instrument to start from. With no walk there is nothing to settle,
             * and every block belongs to the sweep. */
            if (random_budget > 0) {
                baseline_controls();
                for (uint64_t i = 0; i < SWEEP_SETTLE_BLOCKS && g_blocks_done < total; i++) {
                    if (render_block() && fail_fast) {
                        ok = false;
                        break;
                    }
                }
            }
            if (ok || g_opt.keep_going) {
                const uint64_t spent = g_blocks_done;
                const uint64_t sweep_budget = (total > spent) ? (total - spent) : 0;
                ok = run_sweep(sweep_budget, fail_fast) && ok;
            }
        }
    }

    const auto t1 = std::chrono::steady_clock::now();
    const double wall = std::chrono::duration<double>(t1 - t0).count();
    const double audio = (double)g_blocks_done * (double)BLOCK / (double)SYNTH_SAMPLE_RATE;
    const double speed = (wall > 0.0) ? (audio / wall) : 0.0;
    const uint32_t rescues = synth_rack_rescue_count();

    std::printf("\nverdict\n");
    std::printf("  mode: %s%s\n", (g_opt.mode == MODE_SWEEP) ? "sweep"
                              : (g_opt.mode == MODE_RANDOM) ? "random"
                              : "random + sweep",
                g_opt.sanitize ? " (sanitized inputs)" : "");
    std::printf("  seed: %u\n", (unsigned)g_opt.seed);
    if (g_opt.mode != MODE_RANDOM) {
        if (!g_sweep_ran) {
            std::printf("  sweep: not run (the run stopped before it)\n");
        } else if (g_sweep_complete) {
            std::printf("  sweep: complete (%llu steps, %llu blocks)\n",
                        (unsigned long long)g_sweep_last_step,
                        (unsigned long long)g_sweep_used_blocks);
        } else {
            std::printf("  sweep: INCOMPLETE (%llu of %llu steps, %llu of %llu blocks)\n",
                        (unsigned long long)g_sweep_last_step,
                        (unsigned long long)sweep_step_count(),
                        (unsigned long long)g_sweep_used_blocks,
                        (unsigned long long)sweep_block_budget());
        }
    }
    std::printf("  block: %d samples at %d Hz\n", BLOCK, SYNTH_SAMPLE_RATE);
    std::printf("  blocks: %llu\n", (unsigned long long)g_blocks_done);
    std::printf("  audio: %.3f s, wall: %.3f s (%.1fx realtime, %.2f us/block)\n",
                audio, wall, speed,
                (g_blocks_done > 0) ? (wall * 1e6 / (double)g_blocks_done) : 0.0);
    std::printf("  ");
    print_peak();
    std::printf("  rescues: %u, output non-finite: %llu\n",
                (unsigned)rescues, (unsigned long long)g_nonfinite_out);
    std::printf("  heap: peak %zu bytes, failures %u, live blocks %u\n",
                host_heap_peak(), (unsigned)host_heap_failures(),
                (unsigned)host_heap_live_blocks());

    if (g_opt.keep_going && g_rescue_events > 0) {
        std::printf("  rescue events printed: %llu\n",
                    (unsigned long long)g_rescue_events);
    }

    const bool sweep_ok = (g_opt.mode == MODE_RANDOM) || g_sweep_complete;
    const bool pass = ok && (rescues == 0) && (g_nonfinite_out == 0) && sweep_ok;
    if (pass) {
        std::printf("  result: PASS\n");
    } else {
        const bool sweep_is_reason = !sweep_ok && rescues == 0 && g_nonfinite_out == 0;
        std::printf("  result: FAIL%s\n", sweep_is_reason ? " (sweep incomplete)" : "");
    }
    return pass ? 0 : 1;
}
