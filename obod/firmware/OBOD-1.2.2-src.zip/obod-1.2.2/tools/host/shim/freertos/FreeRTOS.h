/*
 * The FreeRTOS types the audio modules name.
 *
 * Only the few the DSP sources actually spell are defined. A tick is a millisecond here,
 * which is what pdMS_TO_TICKS asks for in the claim tasks; vTaskDelay is a real sleep, so
 * the claim tasks behave as they do on the chip without the bench waiting on an RTOS.
 */
#pragma once

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef uint32_t TickType_t;
typedef int32_t  BaseType_t;
typedef uint32_t UBaseType_t;

#define pdMS_TO_TICKS(ms)  ((TickType_t)(ms))
#define portMAX_DELAY      ((TickType_t)0xFFFFFFFFu)
#define pdPASS             ((BaseType_t)1)
#define pdFAIL             ((BaseType_t)0)

#ifdef __cplusplus
}
#endif
