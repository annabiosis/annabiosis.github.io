/*
 * Tasks as threads.
 *
 * The delay, the reverb and the plate each own a low-priority claim task that allocates
 * and zeroes their lines away from the audio core. That structure is part of what is
 * being tested — the audio path must never wait on the claim — so the host gives it a real
 * thread rather than folding the claim into the call. The core id and the priority are
 * accepted and ignored; the host has neither.
 */
#pragma once

#include "freertos/FreeRTOS.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef void (*host_task_fn_t)(void *);

BaseType_t xTaskCreatePinnedToCore(host_task_fn_t fn, const char *name, uint32_t stack,
                                   void *arg, int priority, void *handle, int core);
void       vTaskDelay(TickType_t ticks);
void       vTaskDelete(void *handle);

#ifdef __cplusplus
}
#endif
