/*
 * The chip's free-running cycle counter.
 *
 * The firmware has used it to price short spans in its own unit. The host has no 240 MHz
 * counter, so the seam derives one from the monotonic clock; the numbers are honest at the
 * scale such probes use (differences of hundreds of cycles) and nothing in the audio path
 * branches on them.
 */
#pragma once

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

uint32_t esp_cpu_get_cycle_count(void);

#ifdef __cplusplus
}
#endif
