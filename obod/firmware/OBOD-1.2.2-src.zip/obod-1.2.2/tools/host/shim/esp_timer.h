/*
 * Virtual microseconds.
 *
 * The audio sources read the clock for one thing only: the timestamp on a rescue line.
 * The host bench moves that clock itself, one block at a time, so a run is deterministic
 * and a long stretch of audio costs no real time. Nothing here sleeps or spins.
 */
#pragma once

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

int64_t esp_timer_get_time(void);

#ifdef __cplusplus
}
#endif
