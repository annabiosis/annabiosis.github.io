/*
 * The heap the DSP sources ask for.
 *
 * On the chip the capability flags choose between internal RAM and PSRAM, and getting
 * that choice wrong has real consequences (see claim_scratch() in synth_rack.cpp). On the
 * host there is one heap; the flags are accepted and ignored. The wrappers exist so the
 * bench can count what the audio path claims and, when asked, refuse an allocation the
 * way a full pool would.
 */
#pragma once

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define MALLOC_CAP_SPIRAM   (1u << 10)
#define MALLOC_CAP_INTERNAL (1u << 11)
#define MALLOC_CAP_8BIT     (1u << 2)

void *heap_caps_malloc(size_t size, uint32_t caps);
void *heap_caps_calloc(size_t count, size_t size, uint32_t caps);
void  heap_caps_free(void *ptr);

/* ESP-IDF's "try these capabilities in order" allocation. The capabilities are
 * irrelevant here, so every order is the same call. */
void *heap_caps_malloc_prefer(size_t size, size_t num, ...);

/* What the pool reports as free. With a limit installed this is the remainder;
 * without one it is the largest value the type can hold. */
size_t heap_caps_get_free_size(uint32_t caps);

#ifdef __cplusplus
}
#endif
