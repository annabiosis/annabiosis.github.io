/*
 * The one attribute the DSP sources use. On the chip IRAM_ATTR places a function in
 * internal RAM so a flash cache miss cannot stretch an audio block; on the host there is
 * no such distinction, so the attribute is empty and the function is written where the
 * compiler wants it.
 */
#pragma once

#ifndef IRAM_ATTR
#define IRAM_ATTR
#endif
