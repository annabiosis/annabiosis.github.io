/*
 * Редактор текстов страниц документации OBOD.
 *
 * Зачем он есть: страницы набора написаны руками, и правка текста не должна требовать ни
 * знания разметки, ни второй выписки текста где-то ещё. Редактор читает те же файлы
 * web/*.html, правит в них только текст найденных блоков и ничего больше: теги, атрибуты,
 * отступы и порядок остаются какими были. Данные, которые не принадлежат тексту — плитки
 * разделов, таблицы ручек, схема тракта, — показаны как нередактируемые и в файл не
 * пишутся.
 *
 * Запуск:
 *     node tools/editor/server.js              # сервер на 127.0.0.1:8787
 *     node tools/editor/server.js --selftest   # проверка разбора и записи без сервера
 *
 * Слушает только 127.0.0.1: это инструмент одного человека за своим компьютером.
 * Внешних пакетов нет, только стандартная библиотека Node.
 */
'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const crypto = require('crypto');
const { execFile } = require('child_process');

const TOOLS = path.join(__dirname, '..');
const ROOT = path.join(TOOLS, '..');                      // репозиторий прошивки
const WORKSPACE = path.join(ROOT, '..');                 // рабочая папка целиком
const WEB = path.join(ROOT, 'web');                      // страницы набора
const SITE = path.join(WORKSPACE, 'annabiosis.github.io');
const PORT = Number(process.env.OBOD_EDITOR_PORT || 8787);

const GIT_ENV = Object.assign({}, process.env, {
  GIT_CONFIG_GLOBAL: path.join(WORKSPACE, '_tools', 'gitconfig'),
  GH_CONFIG_DIR: path.join(WORKSPACE, '_tools', 'gh-config')
});

/* ---------- разбор страницы ---------- */

/* Теги, у которых нет закрывающего: их нельзя держать в стеке разбора. */
const VOID_TAGS = new Set(['area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input',
                           'link', 'meta', 'param', 'source', 'track', 'wbr']);

/* Содержимое этих тегов не разметка, и трогать его редактору нечего. */
const RAW_TAGS = new Set(['script', 'style', 'textarea', 'title']);

/* Блоки, текст которых правит человек. */
const BLOCK_TAGS = new Set(['h1', 'h2', 'h3', 'h4', 'p', 'li', 'figcaption', 'dt', 'dd']);

/* Внутрь этих мест редактор не заходит: их наполняет скрипт или прошивка. */
const FORBIDDEN_TAGS = new Set(['nav', 'header', 'aside', 'pre', 'script', 'style',
                                'textarea', 'title', 'button', 'select', 'svg']);

const KIND_NAMES = {
  h1: 'заголовок страницы', h2: 'заголовок раздела', h3: 'подзаголовок',
  h4: 'подзаголовок', p: 'абзац', li: 'пункт', figcaption: 'подпись к снимку',
  dt: 'термин', dd: 'описание'
};

function attrOf(node, name) {
  const m = new RegExp(name + '\\s*=\\s*"([^"]*)"', 'i').exec(node.attrs || '');
  return m ? m[1] : null;
}

function classOf(node) {
  return attrOf(node, 'class') || '';
}

/*
 * Разбор разметки: узлы с границами открывающего тега, содержимого и закрывающего.
 * Полноценный разбор здесь не нужен: страницы пишутся одним и тем же способом, а
 * ошибка в границах была бы видна сразу — проверка записи сверяет файл побайтово.
 */
function scan(src) {
  const nodes = [];
  const stack = [];
  const ranges = [];
  let diagram = null;
  let i = 0;

  while (i < src.length) {
    const lt = src.indexOf('<', i);
    if (lt < 0) { break; }

    if (src.startsWith('<!--', lt)) {
      const end = src.indexOf('-->', lt);
      const comment = src.slice(lt, end < 0 ? src.length : end + 3);
      if (/BEGIN signal diagram/.test(comment)) {
        diagram = { from: end + 3, to: src.length };
      } else if (/END signal diagram/.test(comment) && diagram) {
        diagram.to = lt;
      }
      i = end < 0 ? src.length : end + 3;
      continue;
    }

    const m = /^<(\/?)([a-zA-Z][a-zA-Z0-9-]*)((?:[^>"']|"[^"]*"|'[^']*')*)>/.exec(src.slice(lt));
    if (!m) { i = lt + 1; continue; }

    const whole = m[0];
    const closing = m[1] === '/';
    const tag = m[2].toLowerCase();
    const attrs = m[3] || '';

    if (!closing && RAW_TAGS.has(tag)) {
      const lower = src.toLowerCase();
      let close = lower.indexOf('</' + tag, lt + whole.length);
      if (close < 0) { close = src.length; }
      const closeEnd = close >= src.length ? src.length : src.indexOf('>', close) + 1;
      const node = { tag, attrs, open: lt, innerStart: lt + whole.length, innerEnd: close,
                     close: closeEnd, parent: stack[stack.length - 1] || null, raw: true };
      nodes.push(node);
      ranges.push([node.innerStart, node.innerEnd]);
      i = closeEnd;
      continue;
    }

    if (closing) {
      for (let k = stack.length - 1; k >= 0; k--) {
        if (stack[k].tag === tag) {
          stack[k].innerEnd = lt;
          stack[k].close = lt + whole.length;
          stack.splice(k);
          break;
        }
      }
      i = lt + whole.length;
      continue;
    }

    const node = { tag, attrs, open: lt, innerStart: lt + whole.length, innerEnd: null,
                   close: null, parent: stack[stack.length - 1] || null, raw: false };
    nodes.push(node);
    if (!VOID_TAGS.has(tag) && !/\/$/.test(whole.slice(0, -1))) { stack.push(node); }
    i = lt + whole.length;
  }

  return { nodes, diagram, rawRanges: ranges };
}

function insideRaw(node, ranges) {
  return ranges.some(([a, b]) => node.open >= a && node.open < b);
}

function insideDiagram(node, diagram) {
  return !!diagram && node.open >= diagram.from && node.open < diagram.to;
}

function ancestorHas(node, test) {
  let n = node.parent;
  while (n) {
    if (test(n)) { return true; }
    n = n.parent;
  }
  return false;
}

function insideMainOrFooter(node) {
  return ancestorHas(node, (n) => n.tag === 'main' || n.tag === 'footer');
}

/* Место, куда редактор не пишет: наполняется скриптом, прошивкой или меню. */
function isForbidden(node, parsed) {
  if (insideDiagram(node, parsed.diagram)) { return true; }
  if (insideRaw(node, parsed.rawRanges)) { return true; }
  return ancestorHas(node, (n) => FORBIDDEN_TAGS.has(n.tag) ||
                                classOf(n).split(/\s+/).indexOf('families') >= 0 ||
                                attrOf(n, 'data-ref') !== null);
}

function hasBlockChild(node, parsed) {
  return parsed.nodes.some((n) => n !== node && BLOCK_TAGS.has(n.tag) && ancestorHas(n, (p) => p === node));
}

/* Текст без переносов: подписи и заголовки в подписи блока показываются одной строкой. */
function collapse(s) {
  return s.replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim();
}

/*
 * Блоки страницы. Берём самые глубокие элементы: если внутри абзаца лежит другой абзац,
 * правится внутренний, а внешний в список не идёт.
 *
 * Подпись блока собирается по тексту страницы: ближайший заголовок выше по разметке даёт
 * раздел, счётчик — номер блока внутри раздела. Так подпись совпадает с тем, что видно
 * в оглавлении, а не с деревом вложенности тегов.
 */
function blocksOf(parsed) {
  const out = [];
  const counters = {};
  let section = null;

  parsed.nodes.forEach((node, index) => {
    const heading = node.tag === 'h1' || node.tag === 'h2' || node.tag === 'h3';
    const editable = BLOCK_TAGS.has(node.tag) && node.innerEnd !== null &&
                     insideMainOrFooter(node) && !isForbidden(node, parsed) &&
                     classOf(node).split(/\s+/).indexOf('kicker') < 0 &&
                     !hasBlockChild(node, parsed);

    if (editable) {
      const own = collapse(parsed.src.slice(node.innerStart, node.innerEnd));
      const kind = KIND_NAMES[node.tag] || node.tag;
      const key = (heading ? '' : (section || '')) + '|' + node.tag;
      counters[key] = (counters[key] || 0) + 1;
      const label = node.tag === 'h1' ? kind + ': ' + own
                  : heading ? kind + ' ' + counters[key] + ': ' + own
                  : (section ? section + ' › ' : '') + kind + ' ' + counters[key];

      out.push({
        id: index,
        kind: node.tag,
        label: label,
        text: displayText(parsed.src.slice(node.innerStart, node.innerEnd)),
        markup: /<[a-zA-Z/]/.test(parsed.src.slice(node.innerStart, node.innerEnd)),
        open: node.open,
        innerStart: node.innerStart,
        innerEnd: node.innerEnd
      });
    }

    if (heading && node.innerEnd !== null && !isForbidden(node, parsed)) {
      section = collapse(parsed.src.slice(node.innerStart, node.innerEnd));
    }
  });

  return out;
}

/*
 * Текст блока для правки. На экране он показывается без отступов переноса: в файле
 * продолжение абзаца сдвинуто на два пробела, и эти пробелы — оформление, а не текст.
 */
function displayText(inner) {
  const lead = /^\s*/.exec(inner)[0];
  const tail = /\s*$/.exec(inner)[0];
  const core = inner.slice(lead.length, inner.length - tail.length);
  if (!core || core.indexOf('\n') < 0) { return core; }

  const lines = core.split('\n');
  const rest = lines.slice(1).filter((l) => l.trim());
  let common = rest.length ? /^[ \t]*/.exec(rest[0])[0] : '';
  rest.forEach((l) => {
    const ind = /^[ \t]*/.exec(l)[0];
    while (common && !l.startsWith(common)) { common = common.slice(1); }
  });

  return [lines[0]].concat(lines.slice(1).map((l) => {
    if (!l.trim()) { return ''; }
    return common && l.startsWith(common) ? l.slice(common.length) : l.replace(/^[ \t]*/, '');
  })).join('\n');
}

/*
 * Запись текста обратно в разметку. Если текст не изменился, возвращается исходное
 * содержимое байт в байт: иначе первый же проход редактора переписал бы весь файл, и
 * разница в истории стала бы нечитаемой.
 */
function renderText(inner, text, fallbackIndent) {
  const lead = /^\s*/.exec(inner)[0];
  const tail = /\s*$/.exec(inner)[0];
  const core = inner.slice(lead.length, inner.length - tail.length);
  if (text === displayText(inner)) { return inner; }

  const rest = core.split('\n').slice(1).filter((l) => l.trim());
  const indent = rest.length ? /^[ \t]*/.exec(rest[0])[0] : (fallbackIndent || '');

  const body = text.split('\n').map((line, i) => {
    if (i === 0) { return line; }
    return line.trim() ? indent + line : '';
  }).join('\n');

  return lead + body + tail;
}

/* Отступ строки, на которой стоит тег: продолжение нового текста выравнивается по нему. */
function lineIndent(src, pos) {
  const start = src.lastIndexOf('\n', pos) + 1;
  return /^[ \t]*/.exec(src.slice(start, pos))[0];
}

/* ---------- состояние ---------- */

function pageFiles() {
  return fs.readdirSync(WEB).filter((f) => f.endsWith('.html')).sort();
}

function revisionOf() {
  const h = crypto.createHash('sha1');
  pageFiles().forEach((f) => {
    h.update(f);
    h.update('\0');
    h.update(fs.readFileSync(path.join(WEB, f)));
    h.update('\0');
  });
  return h.digest('hex').slice(0, 12);
}

/* Меню набора: берём из pages.js, как его читает сайт, а не выписываем заново. */
function navFromPages() {
  const file = path.join(WEB, 'assets', 'pages.js');
  if (!fs.existsSync(file)) { return []; }
  const sandbox = { window: {}, document: {}, console: { log() {} } };
  try {
    vm.runInNewContext(fs.readFileSync(file, 'utf8'), sandbox, { timeout: 2000 });
  } catch (e) {
    return [];
  }
  let best = [];
  const look = (obj) => {
    if (!obj || typeof obj !== 'object') { return; }
    Object.keys(obj).forEach((k) => {
      const v = obj[k];
      if (Array.isArray(v) && v.length && v.every((x) => x && typeof x === 'object' && x.file && x.title)) {
        if (v.length > best.length) { best = v; }
      } else if (v && typeof v === 'object' && !Array.isArray(v)) {
        look(v);
      }
    });
  };
  look(sandbox);
  return best.map((x) => ({ file: x.file, title: x.title }));
}

function readOnlyZones(src) {
  const zones = [];
  if (/class="families"/.test(src)) {
    zones.push({ label: 'плитки разделов',
                 why: 'названия и цвета совпадают с меню набора и с прошивкой' });
  }
  if (/data-ref=/.test(src)) {
    zones.push({ label: 'таблицы ручек и списковых значений',
                 why: 'их рисует assets/ref.js из данных прошивки' });
  }
  if (/BEGIN signal diagram/.test(src)) {
    zones.push({ label: 'схема тракта',
                 why: 'собирается из obod-signal-chain.mmd скриптом gen_html.py между маркерами' });
  }
  zones.push({ label: 'меню, оглавление и переходы между страницами',
               why: 'их строит assets/docs.js по таблице страниц' });
  if (/class="shot"/.test(src)) {
    zones.push({ label: 'снимки экранов',
                 why: 'кадры снимает сам прибор; подписи к ним правятся как обычно' });
  }
  return zones;
}

async function stateOf() {
  const files = pageFiles();
  const nav = navFromPages();
  const order = nav.map((n) => n.file).filter((f) => files.indexOf(f) >= 0);
  files.forEach((f) => { if (order.indexOf(f) < 0) { order.push(f); } });

  const dirty = await dirtyFiles();
  const pages = order.map((file) => {
    const src = fs.readFileSync(path.join(WEB, file), 'utf8');
    const parsed = scan(src);
    parsed.src = src;
    const title = (parsed.nodes.filter((n) => n.tag === 'h1')[0] || null);
    return {
      file: file,
      title: title ? collapse(src.slice(title.innerStart, title.innerEnd)) : file,
      changed: dirty.indexOf(file) >= 0,
      blocks: blocksOf(parsed).map((b) => ({
        id: file + '#' + b.id, kind: b.kind, label: b.label, text: b.text,
        markup: b.markup, note: b.kind === 'h2' ? 'Переименование меняет адрес раздела в ссылках.' : null
      })),
      readOnly: readOnlyZones(src)
    };
  });

  return {
    revision: revisionOf(),
    nav: order.map((file) => {
      const known = nav.filter((n) => n.file === file)[0];
      const page = pages.filter((p) => p.file === file)[0];
      return { file: file, title: known ? known.title : page.title, changed: page.changed };
    }),
    pages: pages,
    dirty: dirty,
    lastRun: lastRun
  };
}

/*
 * Список страниц с несохранёнными правками. Если git недоступен, список просто пуст:
 * без него редактор работает, а падать из-за отметок он не должен. Запуск программы
 * может отказать сразу, исключением, а не через обратный вызов — отсюда try.
 */
function dirtyFiles() {
  return new Promise((resolve) => {
    const done = (err, stdout) => {
      if (err) { resolve([]); return; }
      resolve(stdout.split('\n').map((l) => l.slice(3).trim())
                    .filter((l) => l.endsWith('.html')).map((l) => path.basename(l)));
    };
    let child;
    try {
      child = execFile('git', ['status', '--porcelain', '--', 'web'], { cwd: ROOT, env: GIT_ENV }, done);
    } catch (e) {
      resolve([]);
      return;
    }
    child.on('error', () => resolve([]));
  });
}

/* ---------- запись правок ---------- */

function slug(text) {
  const table = { а: 'a', б: 'b', в: 'v', г: 'g', д: 'd', е: 'e', ё: 'e', ж: 'zh', з: 'z',
                  и: 'i', й: 'y', к: 'k', л: 'l', м: 'm', н: 'n', о: 'o', п: 'p', р: 'r',
                  с: 's', т: 't', у: 'u', ф: 'f', х: 'h', ц: 'c', ч: 'ch', ш: 'sh', щ: 'sch',
                  ъ: '', ы: 'y', ь: '', э: 'e', ю: 'yu', я: 'ya' };
  let out = '';
  text = (text || '').toLowerCase();
  for (const ch of text) {
    if (table[ch] !== undefined) { out += table[ch]; }
    else if (/[a-z0-9]/.test(ch)) { out += ch; }
    else { out += '-'; }
  }
  return out.replace(/-+/g, '-').replace(/^-|-$/g, '') || 'razdel';
}

function applyEdits(revision, edits) {
  if (revision !== revisionOf()) { return { ok: false, stale: true }; }

  const byFile = {};
  edits.forEach((e) => {
    const [file, id] = String(e.id).split('#');
    (byFile[file] = byFile[file] || []).push({ id: Number(id), text: String(e.text) });
  });

  const saved = [];
  const warnings = [];

  Object.keys(byFile).forEach((file) => {
    const full = path.join(WEB, file);
    if (!fs.existsSync(full)) { warnings.push('нет файла ' + file); return; }

    const src = fs.readFileSync(full, 'utf8');
    const parsed = scan(src);
    parsed.src = src;
    const blocks = blocksOf(parsed);
    const list = byFile[file].slice().sort((a, b) => b.id - a.id);
    let out = src;

    list.forEach((edit) => {
      const b = blocks.filter((x) => x.id === edit.id)[0];
      if (!b) { warnings.push(file + ': блок не найден, правка пропущена'); return; }
      if (!edit.text.trim()) { warnings.push(file + ': пустой текст в блоке «' + b.label + '»'); }
      const inner = out.slice(b.innerStart, b.innerEnd);
      out = out.slice(0, b.innerStart) +
            renderText(inner, edit.text, lineIndent(src, b.open) + '  ') + out.slice(b.innerEnd);
    });

    if (out !== src) {
      fs.writeFileSync(full, out, 'utf8');
      saved.push(file);
    }

    /* Переименованный раздел меняет свой адрес, а на него могут ссылаться с других страниц. */
    byFile[file].forEach((edit) => {
      const b = blocks.filter((x) => x.id === edit.id)[0];
      if (!b || (b.kind !== 'h1' && b.kind !== 'h2' && b.kind !== 'h3')) { return; }
      const before = slug(displayText(src.slice(b.innerStart, b.innerEnd)));
      const after = slug(edit.text);
      if (before === after) { return; }
      const holders = [];
      pageFiles().forEach((other) => {
        if (other === file) { return; }
        if (fs.readFileSync(path.join(WEB, other), 'utf8').indexOf('#' + before) >= 0) {
          holders.push(other);
        }
      });
      if (holders.length) {
        warnings.push('раздел «' + collapse(edit.text) + '» сменил адрес: на #' + before +
                      ' ссылаются ' + holders.join(', '));
      }
    });
  });

  return { ok: true, revision: revisionOf(), saved: saved, warnings: warnings };
}

/* ---------- запуск инструментов ---------- */

let lastRun = null;

/*
 * Запуск инструмента набора. Отказ запуска — такой же результат, как ненулевой код
 * возврата: проверка сообщает о нём строкой, а не рушит весь ответ сервера.
 */
function run(cmd, args, opts) {
  return new Promise((resolve) => {
    const done = (err, stdout, stderr) => {
      resolve({ ok: !err, out: (String(stdout) + String(stderr)).trim(), code: err ? (err.code || 1) : 0 });
    };
    try {
      execFile(cmd, args, Object.assign({ cwd: ROOT, env: GIT_ENV, windowsHide: true,
                                          maxBuffer: 8 * 1024 * 1024, timeout: 600000 }, opts || {}), done);
    } catch (e) {
      resolve({ ok: false, out: 'не удалось запустить ' + cmd + ': ' + e.message, code: 1 });
    }
  });
}

const CHECKS = [
  { name: 'снимки экранов', cmd: 'node', args: ['tools/screens-check.js'] },
  { name: 'справочник и прошивка', cmd: 'node', args: ['tools/promo-check.js'] },
  { name: 'пары документов', cmd: 'node', args: ['tools/docs-check.js'] },
  { name: 'таблицы интерфейса', cmd: 'pwsh', args: ['-NoProfile', '-File', 'tools/check_ui_tables.ps1'] },
  { name: 'разбор и запись страниц', cmd: 'node', args: ['tools/editor/server.js', '--selftest'] }
];

async function runChecks() {
  const checks = [];
  for (const c of CHECKS) {
    const r = await run(c.cmd, c.args);
    checks.push({ name: c.name, ok: r.ok, out: r.out });
  }
  lastRun = { checks: checks, at: new Date().toISOString() };
  return checks;
}

async function publish(message) {
  const log = [];
  const checks = await runChecks();
  const bad = checks.filter((c) => !c.ok);
  checks.forEach((c) => log.push((c.ok ? 'прошла: ' : 'НЕ ПРОШЛА: ') + c.name));
  if (bad.length) {
    log.push('');
    bad.forEach((c) => log.push('--- ' + c.name + ' ---', c.out));
    return { ok: false, out: log.join('\n') };
  }

  const build = await run('pwsh', ['-NoProfile', '-File', 'tools/make-site.ps1']);
  log.push('', '--- сборка сайта ---', build.out);

  const msg = (message || '').trim() || 'Правка текстов страниц';

  for (const repo of [ROOT, SITE]) {
    const name = path.basename(repo);
    await run('git', ['add', '-A'], { cwd: repo });
    const diff = await run('git', ['diff', '--cached', '--quiet'], { cwd: repo });
    if (diff.ok) {
      log.push('', name + ': изменений нет, коммит не нужен');
      continue;
    }
    const commit = await run('git', ['commit', '-m', msg], { cwd: repo });
    log.push('', '--- ' + name + ': коммит ---', commit.out);
    if (!commit.ok) { return { ok: false, out: log.join('\n') }; }
    const push = await run('git', ['push'], { cwd: repo });
    log.push('--- ' + name + ': отправка ---', push.out);
    if (!push.ok) { return { ok: false, out: log.join('\n') }; }
  }

  return { ok: true, out: log.join('\n') };
}

/* ---------- сервер ---------- */

const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
               '.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8',
               '.png': 'image/png', '.jpg': 'image/jpeg', '.webp': 'image/webp',
               '.svg': 'image/svg+xml', '.woff2': 'font/woff2', '.bin': 'application/octet-stream',
               '.mmd': 'text/plain; charset=utf-8', '.md': 'text/plain; charset=utf-8' };

function send(res, code, type, body) {
  res.writeHead(code, { 'Content-Type': type, 'Cache-Control': 'no-store' });
  res.end(body);
}

function sendJson(res, code, obj) {
  send(res, code, 'application/json; charset=utf-8', JSON.stringify(obj));
}

function readBody(req) {
  return new Promise((resolve) => {
    let data = '';
    req.on('data', (c) => { data += c; });
    req.on('end', () => {
      try { resolve(JSON.parse(data || '{}')); } catch (e) { resolve({}); }
    });
  });
}

/* Файлы набора отдаются как есть: из них собирается предпросмотр страницы. */
function serveSite(res, urlPath) {
  const rel = decodeURIComponent(urlPath.replace(/^\/site\/?/, ''));
  const full = path.resolve(WEB, rel);
  if (!full.startsWith(WEB) || !fs.existsSync(full) || fs.statSync(full).isDirectory()) {
    send(res, 404, 'text/plain; charset=utf-8', 'нет файла');
    return;
  }
  send(res, 200, MIME[path.extname(full).toLowerCase()] || 'application/octet-stream',
       fs.readFileSync(full));
}

const server = http.createServer(async (req, res) => {
  const url = req.url.split('?')[0];

  try {
    if (req.method === 'GET' && url === '/') {
      const ui = path.join(__dirname, 'ui.html');
      if (!fs.existsSync(ui)) { send(res, 500, 'text/plain; charset=utf-8', 'нет ui.html'); return; }
      send(res, 200, MIME['.html'], fs.readFileSync(ui));
      return;
    }
    if (req.method === 'GET' && url === '/ui.css') {
      send(res, 200, MIME['.css'], fs.readFileSync(path.join(__dirname, 'ui.css')));
      return;
    }
    if (req.method === 'GET' && url === '/ui.js') {
      send(res, 200, MIME['.js'], fs.readFileSync(path.join(__dirname, 'ui.js')));
      return;
    }
    if (url.startsWith('/site/')) { serveSite(res, url); return; }

    if (req.method === 'GET' && url === '/api/state') { sendJson(res, 200, await stateOf()); return; }
    if (req.method === 'GET' && url === '/api/diff') {
      const r = await run('git', ['diff', '--', 'web']);
      sendJson(res, 200, { text: r.out });
      return;
    }
    if (req.method === 'POST' && url === '/api/save') {
      const body = await readBody(req);
      sendJson(res, 200, applyEdits(body.revision, body.edits || []));
      return;
    }
    if (req.method === 'POST' && url === '/api/check') {
      sendJson(res, 200, { checks: await runChecks() });
      return;
    }
    if (req.method === 'POST' && url === '/api/build') {
      const r = await run('pwsh', ['-NoProfile', '-File', 'tools/make-site.ps1']);
      sendJson(res, 200, { ok: r.ok, out: r.out });
      return;
    }
    if (req.method === 'POST' && url === '/api/publish') {
      const body = await readBody(req);
      sendJson(res, 200, await publish(body.message));
      return;
    }

    send(res, 404, 'text/plain; charset=utf-8', 'неизвестный запрос');
  } catch (e) {
    send(res, 500, 'text/plain; charset=utf-8', String(e && e.stack || e));
  }
});

/* ---------- проверка разбора и записи ---------- */

/*
 * Два свойства, на которых держится доверие к редактору:
 *   1. если текст не менялся, файл остаётся байт в байт таким же;
 *   2. текст, прочитанный из блока, после записи и нового чтения совпадает с собой.
 * Обе проверки идут по всем страницам набора.
 */
function selftest() {
  const problems = [];
  let blocks = 0;

  pageFiles().forEach((file) => {
    const src = fs.readFileSync(path.join(WEB, file), 'utf8');
    const parsed = scan(src);
    parsed.src = src;
    const list = blocksOf(parsed);
    blocks += list.length;

    let out = src;
    list.slice().sort((a, b) => b.innerStart - a.innerStart).forEach((b) => {
      const inner = out.slice(b.innerStart, b.innerEnd);
      out = out.slice(0, b.innerStart) + renderText(inner, b.text) + out.slice(b.innerEnd);
    });
    if (out !== src) {
      problems.push(file + ': запись без правок меняет файл');
    }

    list.forEach((b) => {
      const inner = src.slice(b.innerStart, b.innerEnd);
      const again = displayText(renderText(inner, b.text));
      if (again !== b.text) {
        problems.push(file + ': текст блока «' + b.label + '» не переживает запись и чтение');
      }
    });
  });

  if (problems.length) {
    console.log('НЕ ПРОШЛО, ' + problems.length + ':');
    problems.slice(0, 20).forEach((p) => console.log('  ' + p));
    process.exit(1);
  }
  console.log('OK: разбор и запись страниц сходятся: ' + pageFiles().length +
              ' страниц, ' + blocks + ' блоков текста');
}

if (process.argv.indexOf('--selftest') >= 0) {
  selftest();
} else {
  server.listen(PORT, '127.0.0.1', () => {
    console.log('Редактор текстов OBOD: http://127.0.0.1:' + PORT + '/');
    console.log('Страницы: ' + WEB);
  });
}
