/*
 * Логика редактора текстов OBOD.
 *
 * Ванильный JS без сборщиков и внешних зависимостей. Единственный собеседник —
 * сервер редактора (tools/editor/server.js), его API:
 *
 *   GET  /api/state    -> { revision, nav, pages, dirty, lastRun }
 *   POST /api/save     <- { revision, edits:[{id,text}] } -> { ok, revision, saved, warnings }
 *                         при внешних изменениях -> { ok:false, stale:true }
 *   POST /api/check    -> { checks:[{name, ok, out}] }
 *   POST /api/build    -> { ok, out }
 *   POST /api/publish  <- { message } -> { ok, out }
 *   GET  /api/diff     -> { text }
 *   GET  /site/<файл>  -> страница для предпросмотра в iframe
 *
 * Правила, заложенные в правку:
 *   — на сервер уходят только поля, текст которых отличается от прочитанного;
 *   — правки живут в памяти для всех страниц сразу, поэтому переключение
 *     страницы их не теряет, а уход со страницы спрашивает подтверждение;
 *   — непрочитанный или упавший сервер даёт понятную строку, а не пустой экран.
 */
(function () {
  'use strict';

  /* Поля ввода блоков держим здесь: id блока -> textarea. */
  var byId = {};

  /* Номер запуска отрисовки блока: чтобы отложенная отрисовка старого
   * списка не сработала после переключения страницы. */
  var renderToken = 0;

  var S = {
    revision: null,
    nav: [],
    pages: {},       /* file -> { file, title, blocks, readOnly } */
    dirty: [],       /* файлы, изменённые на сервере */
    lastRun: null,
    readOnly: [],
    checked: [],     /* последние проверки, чтобы не терялись при перерисовке */
    current: null,
    prevFile: null,  /* файл, который уже показан в предпросмотре */
    orig: {},        /* id блока -> прочитанный текст */
    text: {},        /* id блока -> текущий текст в памяти */
    editedFiles: {}, /* файл -> есть ли правки в памяти */
    cleaned: {},     /* файлы, по которым наши правки уже приняты сервером */
    loaded: false,
    serverUp: false
  };

  var el = {};
  var lastDiff = '';

  /* ── Мелкие помощники ───────────────────────────────────────────────── */

  function $(id) { return document.getElementById(id); }

  function make(tag, cls, text) {
    var node = document.createElement(tag);
    if (cls) node.className = cls;
    if (text !== undefined && text !== null) node.textContent = String(text);
    return node;
  }

  function clear(node) { while (node.firstChild) node.removeChild(node.firstChild); }

  function show(node, on) { if (node) node.hidden = !on; }

  function asArray(value) { return Object.prototype.toString.call(value) === '[object Array]' ? value : []; }

  function asText(value) {
    if (value === undefined || value === null) return '';
    return typeof value === 'string' ? value : JSON.stringify(value, null, 2);
  }

  function stamp(value) {
    if (!value) return '';
    var d = new Date(value);
    if (isNaN(d.getTime())) return String(value);
    try { return d.toLocaleString('ru-RU'); } catch (e) { return d.toISOString(); }
  }

  function okResponse(res) { return res && (res.ok === true || res.ok === undefined); }

  /* ── Связь с сервером ───────────────────────────────────────────────── */

  /* Все запросы идут через одну дверь: понятная строка вместо необработанного
   * отказа, отдельный признак «сервер молчит» — по нему отличаем обрыв связи
   * от ответа сервера с ошибкой. */
  function request(url, init, timeoutMs) {
    var ctl = typeof AbortController === 'function' ? new AbortController() : null;
    var timer = null;

    if (ctl) {
      init.signal = ctl.signal;
      timer = setTimeout(function () { ctl.abort(); }, timeoutMs || 12000);
    }

    return fetch(url, init).then(function (res) {
      if (timer) clearTimeout(timer);
      return res.text().then(function (body) {
        var data = null;
        if (body) {
          try { data = JSON.parse(body); } catch (e) {
            throw new Error('Ответ сервера ' + res.status + ' не разобран как JSON: ' + body.slice(0, 200));
          }
        }
        if (!res.ok) {
          var detail = data && (data.error || data.message) ? ': ' + (data.error || data.message) : '';
          throw new Error('Сервер ответил ' + res.status + ' ' + res.statusText + detail);
        }
        return data;
      });
    }).catch(function (err) {
      /* Сюда попадает и отказ связи, и испорченный ответ, и молчание сервера.
       * Как бы запрос ни сорвался, наружу уходит одна понятная строка. */
      if (timer) clearTimeout(timer);
      if (err && (err.name === 'AbortError' || err.name === 'TimeoutError')) {
        throw new Error('сервер не ответил вовремя');
      }
      if (err instanceof Error && err.message && err.message !== 'Failed to fetch') throw err;
      throw new Error('сервер недоступен');
    });
  }

  function post(url, payload, timeoutMs) {
    return request(url, {
      method: 'POST',
      cache: 'no-store',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload || {})
    }, timeoutMs);
  }

  /* ── Сообщения ──────────────────────────────────────────────────────── */

  function message(text, kind, actions) {
    var slot = el.msgs;
    clear(slot);

    var box = make('div', 'msg msg-' + (kind || 'info'));
    box.appendChild(make('div', 'msg-text', text));

    if (actions && actions.length) {
      var tools = make('div', 'msg-actions');
      actions.forEach(function (item) {
        var btn = make('button', 'btn btn-small' + (item.primary ? ' btn-primary' : ''), item.label);
        btn.type = 'button';
        btn.addEventListener('click', item.run);
        tools.appendChild(btn);
      });
      box.appendChild(tools);
    }

    slot.appendChild(box);
  }

  function failure(err) {
    var text = err && err.message ? err.message : 'неизвестная ошибка';
    if (text.indexOf('сервер недоступен') === 0) {
      S.serverUp = false;
      message('Сервер редактора не отвечает. Проверьте, что он запущен, и нажмите «Перечитать состояние».', 'error');
    } else if (text.indexOf('сервер не ответил') === 0) {
      message('Сервер не ответил вовремя: ' + text + '. Запрос можно повторить.', 'error');
    } else {
      message(text, 'error');
    }
    /* Кнопки, погашенные на время запроса, возвращаем в строй: отказ сервера
     * не должен оставлять действие недоступным. */
    updateTopbar();
  }

  /* ── Состояние ──────────────────────────────────────────────────────── */

  function loadState(silent) {
    if (!silent) message('Читаю состояние сервера…', 'info');

    return request('api/state', { cache: 'no-store' }, 15000).then(function (data) {
      applyState(data);
      S.loaded = true;
      S.serverUp = true;
      message('Состояние прочитано: страниц ' + S.nav.length + ', выпуск ' + S.revision + '.', 'ok');
      render();
    }, function (err) {
      /* Прочитанное состояние при обрыве связи не выбрасываем: на экране
       * остаётся то, что уже было, а рядом — понятная строка об отказе. */
      failure(err);
      render();
    });
  }

  function applyState(data) {
    if (!data || typeof data !== 'object') throw new Error('Состояние пришло пустым');

    clearLocal();
    S.revision = data.revision === undefined ? null : data.revision;
    S.nav = asArray(data.nav);
    S.dirty = asArray(data.dirty);
    S.readOnly = asArray(data.readOnly);
    S.lastRun = data.lastRun || null;
    S.checked = S.lastRun && asArray(S.lastRun.checks).length ? asArray(S.lastRun.checks) : S.checked;

    S.pages = {};
    asArray(data.pages).forEach(function (page) {
      if (!page || !page.file) return;
      var copy = {
        file: page.file,
        title: page.title || page.file,
        blocks: asArray(page.blocks),
        readOnly: asArray(page.readOnly)
      };
      S.pages[copy.file] = copy;
      registerPage(copy);
    });

    /* Первая страница списка — та, что открыта по умолчанию. */
    var first = S.nav.length ? S.nav[0].file : (Object.keys(S.pages)[0] || null);
    if (!S.pages[S.current]) S.current = S.pages[first] ? first : S.current;
  }

  function clearLocal() {
    S.orig = {};
    S.text = {};
    S.editedFiles = {};
    S.cleaned = {};
  }

  function registerPage(page) {
    page.blocks.forEach(function (block) {
      if (!block || block.id === undefined || block.id === null) return;
      var id = String(block.id);
      var text = block.text === undefined || block.text === null ? '' : String(block.text);
      S.orig[id] = text;
      if (S.text[id] === undefined) S.text[id] = text;
    });
  }

  function pageOf(file) { return S.pages[file] || null; }

  function isChanged(id) {
    var key = String(id);
    return S.text[key] !== undefined && S.text[key] !== S.orig[key];
  }

  function pendingCount() { return Object.keys(S.text).filter(isChanged).length; }

  function editedFiles() { return Object.keys(S.editedFiles).filter(function (f) { return S.editedFiles[f]; }); }

  function hasPending() { return pendingCount() > 0; }

  function dirtyNow() {
    var seen = {};
    var out = [];
    S.dirty.forEach(function (file) { if (!S.cleaned[file] && !seen[file]) { seen[file] = 1; out.push(file); } });
    editedFiles().forEach(function (file) { if (!seen[file]) { seen[file] = 1; out.push(file); } });
    return out;
  }

  /* ── Отрисовка ──────────────────────────────────────────────────────── */

  function render() {
    renderTopbar();
    renderNav();
    renderReadOnly();
    renderPage();
    renderChecks(S.checked);
    renderLastRun();
    updatePreview();
  }

  function renderTopbar() {
    var dirty = dirtyNow();
    var chipDirty = el.chipDirty;

    chipDirty.className = 'chip' + (dirty.length ? ' chip-dirty' : ' chip-clean');
    chipDirty.textContent = dirty.length
      ? 'изменённых файлов: ' + dirty.length
      : 'изменённых файлов нет';
    chipDirty.title = dirty.length ? dirty.join('\n') : '';

    el.chipRev.textContent = S.revision === null || S.revision === undefined
      ? 'выпуск —'
      : 'выпуск ' + S.revision;

    show(el.chipPending, hasPending());
    updateTopbar();
  }

  /* Кнопки гасим, когда действие заведомо бессмысленно: сохранять нечего,
   * состояние не прочитано. */
  function updateTopbar() {
    el.btnSave.disabled = !S.loaded || !hasPending();
    el.btnCheck.disabled = !S.loaded;
    el.btnBuild.disabled = !S.loaded;
    el.btnPublish.disabled = !S.loaded;
    el.btnDiff.disabled = !S.loaded;

    var pending = pendingCount();
    el.serverInfo.textContent = S.loaded
      ? 'страница ' + (S.current || '—') + ' · правок в памяти ' + pending
      : 'состояние не прочитано';
  }

  function renderNav() {
    var list = el.nav;
    clear(list);
    el.navCount.textContent = S.nav.length ? String(S.nav.length) : '';

    if (!S.loaded) {
      list.appendChild(make('p', 'placeholder', 'Список страниц появится после чтения состояния.'));
      return;
    }
    if (!S.nav.length) {
      list.appendChild(make('p', 'placeholder', 'Сервер не сообщил ни одной страницы.'));
      return;
    }

    var dirty = {};
    S.dirty.forEach(function (file) { if (!S.cleaned[file]) dirty[file] = true; });

    S.nav.forEach(function (item) {
      var file = item.file;
      var btn = make('button', 'nav-item');
      btn.type = 'button';
      btn.dataset.file = file;
      btn.title = file + (item.title && item.title !== file ? ' — ' + item.title : '');

      if (file === S.current) btn.className += ' is-current';
      if (dirty[file]) btn.className += ' is-dirty';
      if (S.editedFiles[file]) btn.className += ' is-edited';

      btn.appendChild(make('span', 'nav-mark'));
      btn.appendChild(make('span', 'nav-title', item.title || file));
      btn.appendChild(make('span', 'nav-file', file));

      var marks = [];
      if (dirty[file]) marks.push('файл изменён на диске');
      if (S.editedFiles[file]) marks.push('есть несохранённые правки');
      if (marks.length) btn.title += ' — ' + marks.join(', ');

      btn.addEventListener('click', function () { selectPage(file); });
      list.appendChild(btn);
    });
  }

  /* Уход со страницы с правками спрашиваем, но правки при этом не теряем:
   * они лежат в S.text, а не в полях ввода. */
  function selectPage(file) {
    if (file === S.current) return;

    if (hasPending()) {
      var go = window.confirm(
        'Есть несохранённые правки (' + pendingCount() + ').\n' +
        'Они останутся в памяти редактора и уйдут на сервер при сохранении.\n\n' +
        'Перейти к другой странице?'
      );
      if (!go) return;
    }

    S.current = file;
    message('Открыта страница ' + file + '.', 'info');
    render();
    updatePreview();
  }

  /* Список зон, которые редактор не правит. Сервер сообщает их двумя путями:
   * общим списком состояния и в каждой странице отдельно. Показываем оба,
   * иначе зоны, пришедшие со страницей, пропали бы из раскрытого списка. */
  function readOnlyZones() {
    var zones = asArray(S.readOnly).slice();
    Object.keys(S.pages).forEach(function (file) {
      asArray(S.pages[file].readOnly).forEach(function (zone) {
        zones.push({ label: zone && zone.label ? zone.label : 'без подписи', why: zone && zone.why, file: file });
      });
    });
    return zones;
  }

  function renderReadOnly() {
    var body = el.roBody;
    clear(body);

    var zones = readOnlyZones();
    if (!zones.length) {
      body.appendChild(make('p', 'placeholder', 'Сервер не сообщил нередактируемых зон.'));
      return;
    }

    var list = make('ul', 'ro-list');
    zones.forEach(function (zone) {
      var item = make('li', 'ro-item');
      item.appendChild(make('div', 'ro-label', (zone && zone.label ? zone.label : 'без подписи') +
        (zone && zone.file ? ' · ' + zone.file : '')));
      var why = zone && zone.why ? zone.why : 'причина не указана';
      item.appendChild(make('div', 'ro-why', why));
      list.appendChild(item);
    });
    body.appendChild(list);
  }

  function renderPage() {
    var head = el.pageHead;
    var host = el.blocks;
    clear(head);
    clear(host);
    byId = {};
    renderToken++;
    var token = renderToken;

    if (!S.loaded) {
      head.appendChild(make('p', 'placeholder', 'Состояние ещё не прочитано. Нажмите «Перечитать состояние».'));
      return;
    }

    var page = S.current ? pageOf(S.current) : null;
    if (!page) {
      head.appendChild(make('p', 'placeholder', 'Страница не выбрана. Выберите страницу в списке слева.'));
      return;
    }

    var title = make('h1', 'page-title', page.title || page.file);
    head.appendChild(title);

    var sub = make('div', 'page-sub');
    sub.appendChild(make('span', 'page-file', page.file));
    sub.appendChild(make('span', 'page-count', 'блоков: ' + page.blocks.length));
    var mine = pendingCountOnPage(page);
    if (mine) sub.appendChild(make('span', 'block-edited', 'не сохранено: ' + mine));
    head.appendChild(sub);

    if (page.readOnly.length) {
      var note = make('div', 'page-sub');
      page.readOnly.forEach(function (zone) {
        note.appendChild(make('span', 'chip', (zone.label || 'зона') + ' — ' + (zone.why || 'не правится')));
      });
      head.appendChild(note);
    }

    if (!page.blocks.length) {
      host.appendChild(make('p', 'placeholder', 'На этой странице сервер не нашёл текстовых блоков.'));
      return;
    }

    page.blocks.forEach(function (block) { host.appendChild(renderBlock(block, token)); });

    /* Высоту поля считаем после того, как оно попадёт в документ: до этого
     * scrollHeight равен нулю и поле схлопнулось бы. */
    if (typeof requestAnimationFrame === 'function') {
      requestAnimationFrame(function () {
        if (token !== renderToken) return;
        Object.keys(byId).forEach(function (id) { autosize(byId[id]); });
      });
    }
  }

  function pendingCountOnPage(page) {
    var n = 0;
    page.blocks.forEach(function (b) { if (b && isChanged(b.id)) n++; });
    return n;
  }

  function shortKind(block) {
    if (block.kind) return String(block.kind);
    var label = String(block.label || '');
    var cut = label.indexOf('›');
    return (cut > 0 ? label.slice(0, cut) : label).trim().slice(0, 12);
  }

  function renderBlock(block, token) {
    if (!block || block.id === undefined || block.id === null) {
      return make('p', 'placeholder', 'Блок без опознавательного знака пропущен.');
    }
    var id = String(block.id);
    var card = make('article', 'block');
    card.dataset.id = id;
    if (block.markup) card.className += ' is-markup';
    if (isChanged(id)) card.className += ' is-edited';

    /* Заголовок блока: вид, подпись, отметка правки. */
    var head = make('div', 'block-head');
    head.appendChild(make('span', 'block-kind', shortKind(block)));
    head.appendChild(make('span', 'block-label', block.label || ('блок ' + id)));

    var tools = make('div', 'block-tools');
    if (isChanged(id)) tools.appendChild(make('span', 'block-edited', 'не сохранено'));
    head.appendChild(tools);
    card.appendChild(head);

    var body = make('div', 'block-body');

    /* Место курсора запоминаем до перерисовки: клик по кнопке вставки уводит
     * фокус из поля, но не должен терять, куда вставлять. */
    var spot = null;

    var area = make('textarea', 'block-text');
    area.value = S.text[id] !== undefined ? S.text[id] : (block.text || '');
    area.spellcheck = false;
    area.rows = 1;
    area.title = block.label || id;
    area.setAttribute('aria-label', block.label || ('блок ' + id));

    area.addEventListener('focus', function () { rememberSpot(); });
    area.addEventListener('keyup', function () { rememberSpot(); });
    area.addEventListener('mouseup', function () { rememberSpot(); });
    area.addEventListener('select', function () { rememberSpot(); });

    area.addEventListener('input', function () {
      S.text[id] = area.value;
      if (S.current) S.editedFiles[S.current] = true;

      var changed = isChanged(id);
      card.className = card.className.replace(' is-edited', '') + (changed ? ' is-edited' : '');
      if (changed && !tools.firstChild) tools.appendChild(make('span', 'block-edited', 'не сохранено'));
      if (!changed) clear(tools);

      renderTopbar();
      renderNav();
      autosize(area);
    });

    function rememberSpot() {
      spot = { start: area.selectionStart, end: area.selectionEnd, dir: area.selectionDirection };
    }

    /* Вставка в место курсора: выделенное заменяется, иначе текст встаёт
     * в каретку. После вставки поле остаётся в фокусе. */
    function insertAtCursor(text) {
      var start = area.selectionStart;
      var end = area.selectionEnd;
      if (spot && spot.start !== null) {
        var len = area.value.length;
        start = Math.min(spot.start, len);
        end = Math.min(spot.end, len);
      }
      if (start === null || start === undefined) start = area.value.length;
      if (end === null || end === undefined) end = start;

      if (typeof area.setRangeText === 'function') {
        area.setRangeText(text, start, end, 'end');
      } else {
        area.value = area.value.slice(0, start) + text + area.value.slice(end);
        var at = start + text.length;
        area.selectionStart = area.selectionEnd = at;
      }

      area.dispatchEvent(new Event('input', { bubbles: true }));
      area.focus();
      rememberSpot();
    }

    body.appendChild(area);
    byId[id] = area;

    if (block.markup) {
      body.appendChild(make('p', 'block-marked-hint',
        'Внутри разметка, и она показана как есть: её видно и можно править. Кнопки вставляют разметку в место курсора.'));

      var chips = make('div', 'block-tools');
      [['<b>…</b>', '<b></b>'], ['<code>…</code>', '<code></code>'], ['ссылка', '<a href=""></a>']]
        .forEach(function (pair) {
          var chip = make('button', 'mark-chip', pair[0]);
          chip.type = 'button';
          chip.title = 'Вставить ' + pair[1] + ' в место курсора';
          chip.addEventListener('click', function () { insertAtCursor(pair[1]); });
          chips.appendChild(chip);
        });
      body.appendChild(chips);
    }

    if (block.note) body.appendChild(make('div', 'block-note', block.note));

    card.appendChild(body);
    return card;
  }

  function autosize(area) {
    if (!area) return;
    area.style.height = 'auto';
    area.style.height = (area.scrollHeight + 2) + 'px';
  }

  /* ── Проверки, сборка, публикация, разница ──────────────────────────── */

  function renderChecks(checks) {
    var host = el.outChecks;
    clear(host);

    if (!checks.length) {
      host.appendChild(make('p', 'hint', 'Проверки ещё не запускались.'));
      return;
    }

    var wrap = make('div', 'table-wrap');
    var table = make('table', 'checks');

    var thead = make('thead');
    var hrow = make('tr');
    ['Проверка', 'Итог', 'Вывод'].forEach(function (name, i) {
      var th = make('th', null, name);
      if (i === 2) th.className = 'out';
      hrow.appendChild(th);
    });
    thead.appendChild(hrow);
    table.appendChild(thead);

    var tbody = make('tbody');
    checks.forEach(function (check) {
      var row = make('tr');
      var good = okResponse(check);
      if (!good) row.className = 'bad';

      row.appendChild(make('td', 'name', check && check.name ? check.name : 'без имени'));

      var state = make('td', 'state');
      var mark = make('span', good ? 'ok-mark' : 'bad-mark', good ? 'прошла' : 'не прошла');
      state.appendChild(mark);
      row.appendChild(state);

      row.appendChild(make('td', 'out', check && check.out ? String(check.out) : '—'));
      tbody.appendChild(row);
    });
    table.appendChild(tbody);
    wrap.appendChild(table);
    host.appendChild(wrap);

    var bad = checks.filter(function (c) { return !okResponse(c); }).length;
    host.appendChild(make('p', 'hint', bad
      ? 'Не прошло проверок: ' + bad + ' из ' + checks.length + '.'
      : 'Все проверки прошли: ' + checks.length + '.'));
  }

  function renderLastRun() {
    if (!S.lastRun) { el.checksAt.textContent = 'не запускались'; return; }
    var when = stamp(S.lastRun.at);
    var list = asArray(S.lastRun.checks);
    var bad = list.filter(function (c) { return !okResponse(c); }).length;
    el.checksAt.textContent = when
      ? (bad ? when + ' · не прошло ' + bad : when + ' · всё прошло')
      : 'запускались';
  }

  /* Полный вывод сервера: ни строки не режем, но и не смешиваем разные
   * действия — каждое показывает свой вывод в своём месте. */
  function renderOutput(host, value, kind) {
    clear(host);
    var text = asText(value);
    if (!text) {
      host.appendChild(make('p', 'muted', kind === 'publish' ? 'Публикация не запускалась.' : 'Вывод пуст.'));
      return;
    }
    var pre = make('pre', 'out');
    pre.textContent = text;
    host.appendChild(pre);
  }

  /* ── Действия ───────────────────────────────────────────────────────── */

  /* Собираем правки по всем страницам, а не только по открытой: иначе
   * правки соседней страницы остались бы на экране и не ушли на сервер. */
  function collectEdits() {
    var edits = [];
    Object.keys(S.text).forEach(function (id) {
      if (isChanged(id)) edits.push({ id: id, text: S.text[id] });
    });
    return edits;
  }

  function save() {
    var edits = collectEdits();
    if (!edits.length) {
      message('Несохранённых правок нет: на сервер отправлять нечего.', 'info');
      return;
    }

    el.btnSave.disabled = true;
    message('Сохраняю правок: ' + edits.length + '…', 'info');

    post('api/save', { revision: S.revision, edits: edits }, 20000).then(function (res) {
      if (!res) throw new Error('Пустой ответ на сохранение');

      if (res.stale) {
        renderOutput(el.outSave, asText(res.out || res.message || ''), 'save');
        message('Файлы изменились извне, состояние редактора устарело. Правки на экране целы: ' +
                'скопируйте нужное и перечитайте состояние.', 'warn', [
          { label: 'Перечитать состояние', run: function () { loadState(); }, primary: true }
        ]);
        updateTopbar();
        return;
      }

      if (res.ok === false) throw new Error('Сервер отказал в сохранении' + (res.error ? ': ' + res.error : ''));

      S.revision = res.revision !== undefined ? res.revision : S.revision;

      /* Принятые файлы снимаем с учёта: их правки больше не висят. */
      var saved = asArray(res.saved);
      saved.forEach(function (file) {
        S.cleaned[file] = true;
        S.editedFiles[file] = false;
        var page = pageOf(file);
        if (page) page.blocks.forEach(function (b) {
          if (b && b.id !== undefined && b.id !== null) S.orig[String(b.id)] = S.text[String(b.id)];
        });
      });

      var warnings = asArray(res.warnings);
      var text = 'Сохранено правок: ' + edits.length +
                 (saved.length ? '. Файлы: ' + saved.join(', ') : '') +
                 '. Выпуск ' + S.revision + '.';

      renderOutput(el.outSave, warnings.length
        ? warnings.join('\n')
        : 'Предупреждений сервер не прислал.', 'save');

      if (warnings.length) {
        message(text + ' Предупреждений сервера: ' + warnings.length + '.', 'warn');
      } else {
        message(text, 'ok');
      }

      render();
      updatePreview('сохранение');
    }, failure);
  }

  function check() {
    el.btnCheck.disabled = true;
    message('Запускаю проверки…', 'info');

    post('api/check', {}, 300000).then(function (res) {
      var checks = asArray(res && res.checks);
      S.checked = checks;
      S.lastRun = { checks: checks, at: new Date().toISOString() };

      var bad = checks.filter(function (c) { return !okResponse(c); }).length;
      message(bad
        ? 'Проверки завершены: не прошло ' + bad + ' из ' + checks.length + '.'
        : 'Проверки завершены: все ' + checks.length + ' прошли.', bad ? 'warn' : 'ok');

      renderChecks(checks);
      renderLastRun();
      updateTopbar();
    }, failure);
  }

  function build() {
    el.btnBuild.disabled = true;
    message('Собираю сайт…', 'info');

    post('api/build', {}, 300000).then(function (res) {
      var ok = okResponse(res);
      renderOutput(el.outBuild, res && res.out, 'build');
      message(ok ? 'Сборка сайта прошла.' : 'Сборка сайта завершилась с ошибкой.', ok ? 'ok' : 'error');
      if (S.current) updatePreview('сборка');
      updateTopbar();
    }, failure);
  }

  function publish() {
    var box = $('pub-message');
    var text = box.value.trim();
    if (!text) {
      box.focus();
      message('Сообщение коммита пустое. Впишите строку и повторите публикацию.', 'warn');
      return;
    }

    el.btnPublish.disabled = true;
    message('Публикую: ' + text + '…', 'info');

    post('api/publish', { message: text }, 300000).then(function (res) {
      var ok = okResponse(res);
      renderOutput(el.outPublish, res && res.out, 'publish');
      message(ok ? 'Публикация прошла.' : 'Публикация завершилась с ошибкой.', ok ? 'ok' : 'error');

      /* После публикации изменённых файлов обычно не остаётся. */
      if (ok) loadState(true).then(function () {
        message('Публикация прошла. Состояние перечитано.', 'ok');
      });
      updateTopbar();
    }, failure);
  }

  function diff() {
    el.btnDiff.disabled = true;
    message('Запрашиваю разницу…', 'info');

    request('api/diff', { cache: 'no-store' }, 60000).then(function (res) {
      lastDiff = res && res.text ? String(res.text) : '';
      el.outDiff.textContent = lastDiff || 'Разница пуста.';
      message(lastDiff ? 'Разница получена.' : 'Разница пуста: изменений нет.', 'ok');
      updateTopbar();
    }, failure);
  }

  function copyDiff() {
    var text = lastDiff || el.outDiff.textContent || '';
    if (!text) { message('Копировать нечего: сначала запросите разницу.', 'info'); return; }

    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(function () {
        message('Разница скопирована в буфер обмена.', 'ok');
      }, function () {
        selectDiff();
      });
      return;
    }
    selectDiff();
  }

  /* Запасной путь, если буфер обмена недоступен: выделяем текст, дальше
   * обычное копирование средствами браузера. */
  function selectDiff() {
    try {
      var range = document.createRange();
      range.selectNodeContents(el.outDiff);
      var sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(range);
      message('Текст разницы выделен: скопируйте его средствами браузера.', 'info');
    } catch (e) {
      message('Скопировать не удалось: буфер обмена недоступен.', 'error');
    }
  }

  /* ── Предпросмотр ───────────────────────────────────────────────────── */

  function previewUrl(file) {
    return 'site/' + String(file).split('/').map(encodeURIComponent).join('/');
  }

  function updatePreview(why) {
    var on = el.prevOn.checked;
    var box = el.prevBox;

    if (!on || !S.current) { show(box, false); return; }
    show(box, true);

    var page = pageOf(S.current);
    if (!page) return;

    /* Перерисовка страницы сама по себе предпросмотр не перезагружает:
     * иначе список проверок или правка текста дёргали бы iframe. */
    if (!why && S.prevFile === page.file) return;
    S.prevFile = page.file;

    var url = previewUrl(page.file);
    el.prevOpen.href = url;
    el.prevNote.textContent = why
      ? 'Обновлено после: ' + why + '. Путь ' + url + '.'
      : 'Страница собрана в папке web/ и показана как есть. Путь ' + url + '.';

    /* Отметка времени снимает кеш браузера: перезагрузка всегда свежая. */
    el.prevFrame.src = url + (url.indexOf('?') >= 0 ? '&' : '?') + 't=' + Date.now();
  }

  /* ── Запуск ─────────────────────────────────────────────────────────── */

  function bind() {
    el.btnSave.addEventListener('click', save);
    el.btnCheck.addEventListener('click', check);
    el.btnBuild.addEventListener('click', build);
    el.btnPublish.addEventListener('click', publish);
    el.btnDiff.addEventListener('click', diff);
    el.btnDiffCopy.addEventListener('click', copyDiff);
    el.btnReload.addEventListener('click', function () {
      if (hasPending() && !window.confirm('Есть несохранённые правки (' + pendingCount() +
          ').\nПеречитать состояние и потерять их?')) return;
      loadState();
    });

    el.btnRo.addEventListener('click', function () {
      var open = el.btnRo.getAttribute('aria-expanded') === 'true';
      el.btnRo.setAttribute('aria-expanded', open ? 'false' : 'true');
      el.roMark.textContent = open ? '+' : '−';
      show(el.roBody, !open);
    });

    el.prevOn.addEventListener('change', function () { updatePreview(); });
    el.btnPrevRefresh.addEventListener('click', function () {
      if (!el.prevOn.checked) { el.prevOn.checked = true; }
      updatePreview('обновление вручную');
    });

    window.addEventListener('beforeunload', function (e) {
      if (!hasPending()) return;
      e.preventDefault();
      e.returnValue = '';
      return '';
    });
  }

  function grab() {
    el.msgs = $('msg-slot');
    el.serverInfo = $('server-info');
    el.chipDirty = $('chip-dirty');
    el.chipRev = $('chip-rev');
    el.chipPending = $('chip-pending');
    el.btnSave = $('btn-save');
    el.btnCheck = $('btn-check');
    el.btnBuild = $('btn-build');
    el.btnPublish = $('btn-publish');
    el.btnReload = $('btn-reload');
    el.nav = $('nav');
    el.navCount = $('nav-count');
    el.btnRo = $('btn-ro');
    el.roMark = $('ro-mark');
    el.roBody = $('ro-body');
    el.pageHead = $('page-head');
    el.blocks = $('blocks');
    el.prevOn = $('prev-on');
    el.prevBox = $('prev-box');
    el.prevFrame = $('prev-frame');
    el.prevOpen = $('prev-open');
    el.prevNote = $('prev-note');
    el.btnPrevRefresh = $('btn-prev-refresh');
    el.outChecks = $('out-checks');
    el.checksAt = $('checks-at');
    el.outBuild = $('out-build');
    el.outPublish = $('out-publish');
    el.outDiff = $('out-diff');
    el.btnDiff = $('btn-diff');
    el.btnDiffCopy = $('btn-diff-copy');
    el.outSave = $('out-save');
  }

  function init() {
    grab();
    bind();
    renderChecks([]);
    render();
    loadState();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
