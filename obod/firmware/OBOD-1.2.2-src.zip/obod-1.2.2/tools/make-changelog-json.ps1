# Список изменений для сайта: все версии из CHANGELOG.md в один файл.
#
# Источник один — CHANGELOG.md в корне репозитория. Из него собирается
# tools/webflash/changelog.json, который читают три страницы: вкладка «Из браузера»
# на странице прошивки берёт из него последнюю версию, страница истории показывает
# все, а tools/webflash/index.html — последнюю у себя. Поэтому в файле лежит массив
# versions от новых к старым, и второй копии данных нигде нет.
#
# Даты берутся из тегов выпусков: в самом CHANGELOG.md их нет, а выдумывать нельзя.
# Есть тег версии — есть дата; нет тега — поля date в записи нет, и страница
# показывает версию без даты.
#
# Запуск: pwsh -File tools\make-changelog-json.ps1
#         pwsh -File tools\make-changelog-json.ps1 -Check   проверка, файл не пишется
#
# Обычно вызывается сам: tools\webflash\merge.ps1 пересобирает список при выпуске.

[CmdletBinding()]
param(
    # Только проверить, что файл совпадает с CHANGELOG.md, и ничего не писать.
    [switch] $Check
)

$ErrorActionPreference = 'Stop'

$root = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$changelogPath = Join-Path $root 'CHANGELOG.md'
$jsonPath = Join-Path $root 'tools\webflash\changelog.json'

if (-not (Test-Path -LiteralPath $changelogPath)) {
    throw "нет CHANGELOG.md: $changelogPath"
}

# ---------------------------------------------------------------------------
# Разбор. Версия — заголовок второго уровня, первый знак которого цифра:
# «## 1.2.0». Заголовки вроде «## Текст для страницы выпуска» версией не считаются,
# и всё, что под ними, в список не попадает.
#
# Раздел — «### », пункт — «- ». Строки с отступом продолжают пункт: в файле
# переносы стоят по ширине колонки, а не по смыслу. Обратные кавычки остаются в
# тексте — страница сама рисует по ним врезку кода.
# ---------------------------------------------------------------------------

$lines = (Get-Content -LiteralPath $changelogPath -Raw) -split "`r?`n"

$versions = New-Object System.Collections.ArrayList
$current = $null      # собираемая версия
$sections = $null     # её разделы
$section = $null      # текущий раздел
$item = $null         # текущий пункт

function Close-Item {
    if ($script:item -ne $null -and $script:section -ne $null) {
        [void]$script:section.items.Add($script:item)
    }
    $script:item = $null
}

function Close-Version {
    Close-Item
    if ($script:current -ne $null) {
        if ($script:sections.Count -eq 0) {
            throw ("в версии {0} нет ни одного раздела «### »" -f $script:current.version)
        }
        [void]$script:versions.Add($script:current)
    }
    $script:current = $null
    $script:sections = $null
    $script:section = $null
}

foreach ($line in $lines) {
    if ($line -match '^##\s+(\d[0-9A-Za-z.\-]*)\s*$') {
        Close-Version
        $script:current = [pscustomobject]@{
            version  = $Matches[1]
            sections = (New-Object System.Collections.ArrayList)
        }
        $script:sections = $script:current.sections
        continue
    }
    if ($line -match '^##\s+') {
        # Заголовок второго уровня, но не версия: всё, что под ним, в список не идёт.
        Close-Version
        continue
    }
    if ($script:current -eq $null) { continue }

    if ($line -match '^###\s+(.+?)\s*$') {
        Close-Item
        $title = $Matches[1]

        # Одинаковые разделы внутри одной версии склеиваются: в файле заголовок «### Ритм»
        # встречается дважды, и на странице это читалось бы как два разных раздела подряд.
        $same = $null
        foreach ($s in $script:sections) {
            if ($s.title -eq $title) { $same = $s; break }
        }
        if ($same -ne $null) {
            $script:section = $same
        }
        else {
            $script:section = [pscustomobject]@{
                title = $title
                items = (New-Object System.Collections.ArrayList)
            }
            [void]$script:sections.Add($script:section)
        }
        continue
    }
    if ($script:section -eq $null) { continue }

    if ($line -match '^-\s+(.*)$') {
        Close-Item
        $script:item = $Matches[1].Trim()
        continue
    }
    if ($script:item -ne $null -and $line -match '^\s+\S') {
        $script:item = $script:item + ' ' + $line.Trim()
        continue
    }
    if ($script:item -ne $null -and $line.Trim() -eq '') {
        Close-Item
    }
}
Close-Version

if ($versions.Count -eq 0) {
    throw "в CHANGELOG.md не найдено ни одной версии"
}

# ---------------------------------------------------------------------------
# Даты выпусков — из тегов. Тег аннотированный, у него есть дата создания;
# lightweight-тег тоже годится, у него берётся дата коммита.
# ---------------------------------------------------------------------------

$tagDates = @{}
try {
    $tags = & git -C $root for-each-ref --format='%(refname:short)|%(creatordate:short)' refs/tags 2>$null
    if ($LASTEXITCODE -eq 0 -and $tags) {
        foreach ($row in $tags) {
            $parts = $row -split '\|', 2
            if ($parts.Count -lt 2) { continue }
            $name = $parts[0].Trim() -replace '^v', ''
            $date = $parts[1].Trim()
            if ($name -and $date -match '^\d{4}-\d{2}-\d{2}$') { $tagDates[$name] = $date }
        }
    }
}
catch {
    # Без git список соберётся, просто без дат.
}

$out = New-Object System.Collections.ArrayList
foreach ($v in $versions) {
    $head = [ordered]@{ version = $v.version }
    if ($tagDates.ContainsKey($v.version)) { $head['date'] = $tagDates[$v.version] }

    $body = New-Object System.Collections.ArrayList
    foreach ($s in $v.sections) {
        [void]$body.Add([pscustomobject]@{
            title = $s.title
            items = @($s.items)
        })
    }
    $head['sections'] = @($body)

    [void]$out.Add([pscustomobject]$head)
}

$data = [pscustomobject]@{ versions = @($out) }
$json = ($data | ConvertTo-Json -Depth 8) + "`n"

# Без метки порядка байтов: JSON её не любит, а читает файл браузер.
$bytes = (New-Object System.Text.UTF8Encoding($false)).GetBytes($json)

if ($Check) {
    if (-not (Test-Path -LiteralPath $jsonPath)) {
        throw "нет $jsonPath — соберите: pwsh -File tools\make-changelog-json.ps1"
    }
    $old = [IO.File]::ReadAllText($jsonPath)
    if ($old -ne $json) {
        throw "changelog.json отстал от CHANGELOG.md — пересоберите: pwsh -File tools\make-changelog-json.ps1"
    }
    "список изменений на месте: версий {0}" -f $out.Count
}
else {
    [IO.File]::WriteAllText($jsonPath, $json, (New-Object System.Text.UTF8Encoding($false)))
    $items = 0
    foreach ($v in $out) { foreach ($s in $v.sections) { $items += @($s.items).Count } }
    "changelog.json: версий {0}, разделов {1}, пунктов {2}, {3} байт" -f `
        $out.Count, (($out | ForEach-Object { $_.sections.Count } | Measure-Object -Sum).Sum), $items, $bytes.Length
    "версии: " + (($out | ForEach-Object { $_.version }) -join ', ')
    $noDate = @($out | Where-Object { -not $_.date } | ForEach-Object { $_.version })
    if ($noDate.Count) { "без даты (нет тега): " + ($noDate -join ', ') }
}
