#!/usr/bin/env node
/*
 * Проверка файлов шрифтов components/synth_ui/src/fonts/lv_font_anbscreen_*.c.
 *
 * Файлы приходят от стороннего плагина, а не от собственного генератора, и дважды
 * приходили с данными, которые собираются молча, но рисуются не так, как задумано:
 *
 *   - ofs_y был записан от базовой линии вверх (как в FreeType), а LVGL считает его
 *     зазором между низом глифа и базовой линией (lv_draw_label.c:671). Все глифы
 *     уезжали на 13-14 px вниз, за строку высотой 14, и текста не было видно вовсе;
 *   - кернинговые значения были в целых пикселях, тогда как ядро делит их на 16
 *     (lv_font_fmt_txt.c:250) и хранит продвижение в 1/16 px. Пара в -2 px давала
 *     0.125 px, а ширина глифа потом округляется до целого — кернинг исчезал.
 *
 * Обе ошибки видны без прибора, и обе ловятся здесь: считается та же формула, что
 * в ядре, и проверяется кратность кернинговых значений. Заодно проверяется то, без
 * чего LVGL молча промахивается мимо глифа: порядок разреженного списка кодов и
 * пар (по ним идёт бинарный поиск), счётчики в заголовке файла и границы битмапа.
 *
 * Запуск: node tools/font-metrics-check.js
 */

'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const FONTS = path.join(ROOT, 'components', 'synth_ui', 'src', 'fonts');

const failures = [];
const notes = [];

function fail(message) {
    failures.push(message);
}

function num(re, text, what, file) {
    const m = text.match(re);
    if (!m) {
        fail(`${file}: не найдено ${what}`);
        return null;
    }
    return Number(m[1]);
}

/* Убирает комментарии, чтобы числа в пояснениях не попадали в разбор. */
function strip(text) {
    return text.replace(/\/\*[\s\S]*?\*\//g, ' ').replace(/\/\/[^\n]*/g, ' ');
}

function block(text, name) {
    const re = new RegExp(`static const \\w+ ${name}\\[\\] = \\{([\\s\\S]*?)\\n\\};`);
    const m = text.match(re);
    return m ? m[1] : null;
}

function numbers(list) {
    return (list.match(/-?\d+/g) || []).map(Number);
}

function checkFont(file) {
    const raw = fs.readFileSync(path.join(FONTS, file), 'utf8');
    const text = strip(raw);

    const lineHeight = num(/\.line_height = (\d+)/, text, 'line_height', file);
    const baseLine = num(/\.base_line = (\d+)/, text, 'base_line', file);
    const bpp = num(/\.bpp = (\d+)/, text, 'bpp', file);
    const kernScale = num(/\.kern_scale = (\d+)/, text, 'kern_scale', file);
    const pairCnt = num(/\.pair_cnt = (\d+)/, text, 'pair_cnt', file);
    const cmapNum = num(/\.cmap_num = (\d+)/, text, 'cmap_num', file);
    if (lineHeight === null || baseLine === null) return null;

    /*
     * Заголовок обещает число глифов, bpp и метрики строки. Расходиться с данными
     * ему нельзя: по нему решают, брать ли шрифт, и по нему же правят раскладку.
     */
    const head = raw.match(/\* (\d+) glyphs, (\d+) bpp, line_height = (\d+), base_line = (\d+)\./);
    const kernHead = raw.match(/\* Kerning: (\d+) pairs/);

    /* Глифы. Первая запись в таблице — резервный id 0, в заголовок не входит. */
    const glyphs = [];
    const glyphRe = /\.bitmap_index = (\d+), \.adv_w = (\d+), \.box_w = (\d+), \.box_h = (\d+), \.ofs_x = (-?\d+), \.ofs_y = (-?\d+)/g;
    let m;
    while ((m = glyphRe.exec(text)) !== null) {
        glyphs.push({
            bitmap: Number(m[1]), adv: Number(m[2]), w: Number(m[3]), h: Number(m[4]),
            x: Number(m[5]), y: Number(m[6]),
        });
    }
    const real = glyphs.slice(1);

    if (!head) {
        fail(`${file}: в заголовке нет строки «N glyphs, B bpp, line_height»`);
    } else {
        if (Number(head[1]) !== real.length) {
            fail(`${file}: заголовок обещает ${head[1]} глифов, в таблице ${real.length}`);
        }
        if (Number(head[2]) !== bpp) {
            fail(`${file}: заголовок обещает ${head[2]} bpp, в дескрипторе ${bpp}`);
        }
        if (Number(head[3]) !== lineHeight || Number(head[4]) !== baseLine) {
            fail(`${file}: заголовок обещает line_height ${head[3]} и base_line ${head[4]}, ` +
                `в дескрипторе ${lineHeight} и ${baseLine}`);
        }
    }

    /*
     * Посадка в строку — та же арифметика, что в lv_draw_label.c:671:
     * верх = (line_height - base_line) - box_h - ofs_y.
     */
    const baseline = lineHeight - baseLine;
    let fullyOut = 0;
    let partlyOut = 0;
    real.forEach((g, i) => {
        if (g.w === 0 || g.h === 0) return;
        const top = baseline - g.h - g.y;
        const bottom = top + g.h;
        if (bottom <= 0 || top >= lineHeight) {
            fullyOut++;
            if (fullyOut <= 5) {
                fail(`${file}: глиф id ${i + 1} целиком вне строки — верх ${top}, низ ${bottom} ` +
                    `при строке ${lineHeight} (box_h ${g.h}, ofs_y ${g.y})`);
            }
        } else if (top < 0 || bottom > lineHeight) {
            partlyOut++;
        }
    });
    if (fullyOut > 5) {
        fail(`${file}: ещё ${fullyOut - 5} глифов целиком вне строки`);
    }

    /* Кернинг: значения в 1/16 px при kern_scale 16. */
    const idsBlock = block(text, 'kern_glyph_ids');
    const valBlock = block(text, 'kern_values');
    if (idsBlock === null || valBlock === null) {
        fail(`${file}: нет таблицы кернинговых пар`);
    } else {
        const ids = numbers(idsBlock);
        const vals = numbers(valBlock);
        if (ids.length !== vals.length * 2) {
            fail(`${file}: пар ${ids.length / 2}, значений ${vals.length}`);
        }
        if (pairCnt !== vals.length) {
            fail(`${file}: pair_cnt ${pairCnt}, а значений ${vals.length}`);
        }
        if (kernHead && Number(kernHead[1]) !== vals.length) {
            fail(`${file}: заголовок обещает ${kernHead[1]} пар, в таблице ${vals.length}`);
        }
        if (kernScale === 16) {
            const whole = vals.filter((v) => v % 16 !== 0);
            if (whole.length) {
                fail(`${file}: значения кернинга в пикселях, а не в 1/16 px — ` +
                    `${whole.slice(0, 5).join(', ')}; ядро разделит их на 16 и округлит до нуля`);
            }
        }
        const pairs = [];
        for (let i = 0; i < ids.length; i += 2) pairs.push([ids[i], ids[i + 1]]);
        const sorted = pairs.slice().sort((a, b) => (a[0] - b[0]) || (a[1] - b[1]));
        const broken = pairs.findIndex((p, i) => p[0] !== sorted[i][0] || p[1] !== sorted[i][1]);
        if (broken >= 0) {
            fail(`${file}: пары не в том порядке для бинарного поиска — первая не на месте ` +
                `(${pairs[broken].join(' ')})`);
        }
    }

    /*
     * Разреженный список кодов. Ядро ищет в нём не код, а код минус range_start
     * (lv_font_fmt_txt.c:342) — так он и записан, по возрастанию.
     */
    const lists = raw.match(/static const uint16_t unicode_list_\d+\[\] = \{[\s\S]*?\n\};/g) || [];
    lists.forEach((list, i) => {
        const codes = (list.match(/0x[0-9a-fA-F]+/g) || []).map((v) => parseInt(v, 16));
        const sorted = codes.slice().sort((a, b) => a - b);
        if (codes.join() !== sorted.join()) {
            fail(`${file}: unicode_list_${i} не по возрастанию`);
        }
        if (new Set(codes).size !== codes.length) {
            fail(`${file}: unicode_list_${i} повторяет коды`);
        }
    });

    /* Границы битмапа: последний глиф обязан помещаться в массив. */
    const bm = raw.match(/static LV_ATTRIBUTE_LARGE_CONST const uint8_t glyph_bitmap\[\] = \{([\s\S]*?)\n\};/);
    if (!bm) {
        fail(`${file}: нет glyph_bitmap`);
    } else {
        const size = (bm[1].match(/0x[0-9a-fA-F]{2}/g) || []).length;
        let last = -1;
        let lastNeed = 0;
        real.forEach((g) => {
            const need = Math.ceil((g.w * g.h * bpp) / 8);
            if (g.bitmap + need > size) {
                fail(`${file}: глиф с bitmap_index ${g.bitmap} выходит за битмап (${size} байт)`);
            }
            if (g.bitmap + need > last) {
                last = g.bitmap + need;
                lastNeed = need;
            }
        });
        if (last < size - 8) {
            fail(`${file}: битмап ${size} байт, а последний глиф кончается на ${last}`);
        }
        void lastNeed;
    }

    /*
     * Карта символов: у разреженных диапазонов список кодов обязан быть, у
     * сплошных его быть не должно, и длина списка — та, что записана в cmap.
     */
    const cmapsBlock = block(text, 'cmaps');
    const cmapRe = /\.range_start = (\d+), \.range_length = (\d+), \.glyph_id_start = (\d+),\s*\.unicode_list = (NULL|\w+), \.glyph_id_ofs_list = (NULL|\w+), \.list_length = (\d+), \.type = (LV_FONT_FMT_TXT_CMAP_\w+)/g;
    const cmaps = [];
    while (cmapsBlock && (m = cmapRe.exec(cmapsBlock)) !== null) {
        cmaps.push({
            start: Number(m[1]), length: Number(m[2]), gid: Number(m[3]),
            list: m[4], listLen: Number(m[6]), type: m[7],
        });
    }
    if (!cmaps.length) {
        fail(`${file}: не разобрана таблица cmaps`);
    }
    if (cmaps.length !== cmapNum) {
        fail(`${file}: cmap_num ${cmapNum}, а записей ${cmaps.length}`);
    }
    cmaps.forEach((c, i) => {
        const sparse = /SPARSE/.test(c.type);
        if (sparse && c.list === 'NULL') {
            fail(`${file}: cmap ${i} разреженный, а списка кодов нет`);
        }
        if (sparse && c.list !== 'NULL') {
            const decl = raw.match(new RegExp(`static const uint16_t ${c.list}\\[\\] = \\{([\\s\\S]*?)\\n\\};`));
            if (!decl) {
                fail(`${file}: cmap ${i} ссылается на ${c.list}, которого нет`);
            } else {
                const codes = (decl[1].match(/0x[0-9a-fA-F]+/g) || []).map((v) => parseInt(v, 16));
                if (codes.length !== c.listLen) {
                    fail(`${file}: в ${c.list} ${codes.length} кодов, а list_length ${c.listLen}`);
                }
            }
        }
        if (!sparse && c.list !== 'NULL') {
            fail(`${file}: cmap ${i} сплошной, а список кодов задан`);
        }
    });
    if (!/const lv_font_t lv_font_anbscreen_\d+ = \{/.test(raw)) {
        fail(`${file}: нет описания шрифта lv_font_anbscreen_*`);
    }
    if (!/#include "lvgl\.h"/.test(raw)) {
        fail(`${file}: включение приведено не к виду компонента — нужно #include "lvgl.h"`);
    }

    if (partlyOut) {
        notes.push(`${file}: ${partlyOut} глифов выходят за строку, но видны`);
    }

    return {
        file,
        glyphs: real.length,
        bpp,
        lineHeight,
        pairs: valBlock === null ? 0 : numbers(valBlock).length,
    };
}

function main() {
    let files;
    try {
        files = fs.readdirSync(FONTS).filter((f) => /^lv_font_anbscreen_\d+\.c$/.test(f)).sort();
    } catch (e) {
        console.error(`нет каталога шрифтов: ${FONTS}`);
        return 1;
    }
    if (!files.length) {
        console.error(`в ${FONTS} нет файлов lv_font_anbscreen_*.c`);
        return 1;
    }

    const done = files.map(checkFont).filter(Boolean);

    if (failures.length) {
        failures.forEach((f) => console.error('ОШИБКА: ' + f));
        console.error(`\nне прошло: ${failures.length}`);
        return 1;
    }

    console.log('OK: ' + done.map((d) =>
        `${d.file} — ${d.glyphs} глифов, ${d.bpp} bpp, строка ${d.lineHeight}, пар ${d.pairs}`).join('; ') +
        '; глифы в строке, кернинг в 1/16 px, порядок списков и пар верный');
    notes.forEach((n) => console.log('  ' + n));
    return 0;
}

process.exit(main());
