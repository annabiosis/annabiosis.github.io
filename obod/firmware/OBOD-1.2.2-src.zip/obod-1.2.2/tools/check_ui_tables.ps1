# Checks the two invariants in synth_ui.c whose violation is a run-time crash
# rather than a compile error, because both numbers live beside the tables they
# describe instead of being derived from them:
#
#   1. the knob count a page declares against the table it points at. The sector
#      loop runs to the declared number and skips only what is past it, so one
#      count too many reads past the end of the table, takes whatever follows as
#      a `const char *`, and hands it to lv_label_set_text(). That is a
#      LoadProhibited in lv_strlen on the boot page: the 2026-10-12 bootloop.
#   2. the length of every rim layout against the count its name claims. An
#      explicitly sized array that is initialised short is not an error: C
#      zero-fills the rest, lv_arc_set_bg_angles() gets 0 and 0, and the sector
#      simply disappears with no diagnostic at all.
#
# Run before every build:
#     pwsh -NoProfile -File .\tools\check_ui_tables.ps1
# Exits non-zero on the first failure so it can gate a build.

param([string]$Source = "components/synth_ui/src/synth_ui.c")

$ErrorActionPreference = 'Stop'
$fail = 0
$src = Get-Content $Source

# ---------------------------------------------------------------- knob tables
$knobs = @{}
for ($i = 0; $i -lt $src.Count; $i++) {
    if ($src[$i] -match '^static const ui_knob_t (KNOBS_\w+)\[\] = \{') {
        $name = $Matches[1]; $n = 0; $j = $i + 1
        while ($j -lt $src.Count -and $src[$j] -notmatch '^\};') {
            if ($src[$j] -match '^\s*\{\s*"') { $n++ }
            $j++
        }
        $knobs[$name] = $n
    }
}
if ($knobs.Count -eq 0) { Write-Host "no knob tables found in $Source"; exit 2 }
Write-Host ("knob tables: {0}" -f (($knobs.Keys | Sort-Object | ForEach-Object { "$_=$($knobs[$_])" }) -join ' '))

# ------------------------------------------------------------- pages vs tables
$pages = 0
foreach ($line in $src) {
    if ($line -match '\[(PAGE_\w+)\]\s*=\s*\{\s*"([^"]*)"\s*,\s*"([^"]*)"\s*,\s*(\w+)\s*,\s*([^,]+),') {
        $pages++
        $pg = $Matches[1]; $title = $Matches[2]; $tbl = $Matches[4]; $countToken = $Matches[5].Trim()

        if ($tbl -eq 'NULL') {
            if ($countToken -ne '0') {
                Write-Host "BAD  $pg ($title): table is NULL but the count is $countToken"
                $fail++
            }
            continue
        }
        if (-not $knobs.ContainsKey($tbl)) {
            Write-Host "BAD  $pg ($title): points at $tbl, which is not a knob table here"
            $fail++
            continue
        }
        $real = $knobs[$tbl]

        # Either a literal number -- the form that caused the bootloop -- or a
        # count derived from the table, in which case the argument must be the
        # table the page actually points at.
        if ($countToken -match '^NK\(\s*(\w+)\s*\)$') {
            if ($Matches[1] -ne $tbl) {
                Write-Host "BAD  $pg ($title): count derived from $($Matches[1]) but the page points at $tbl"
                $fail++
            }
        } elseif ($countToken -match '^\d+$') {
            if ([int]$countToken -ne $real) {
                Write-Host "BAD  $pg ($title): declares $countToken knobs, $tbl holds $real"
                $fail++
            }
        } else {
            Write-Host "BAD  $pg ($title): count '$countToken' is neither a number nor NK(table)"
            $fail++
        }
    }
}
Write-Host ("pages with a knob list or NULL: {0}" -f $pages)

# ---------------------------------------------------------------- rim layouts
$rims = 0
for ($i = 0; $i -lt $src.Count; $i++) {
    if ($src[$i] -match '^static const rim_span_t (RIM_(\d+))(\[(\d*)\])? = \{') {
        $name = $Matches[1]; $want = [int]$Matches[2]
        $explicit = $Matches[3]; $declared = $Matches[4]
        $n = 0; $j = $i
        while ($j -lt $src.Count) {
            $n += ([regex]::Matches($src[$j], '\{')).Count
            if ($j -gt $i -and $src[$j] -match '\};') { break }
            $j++
        }
        $n = $n - 1
        $rims++

        if ($n -ne $want) {
            Write-Host "BAD  $name holds $n spans, its name claims $want"
            $fail++
        }
        if ($explicit -and $declared -and [int]$declared -ne $want) {
            Write-Host "BAD  $name is declared [$declared] but its name claims $want"
            $fail++
        }
        if ($explicit -and $declared) {
            Write-Host "WARN $name is declared with an explicit size, so a short initialiser would be zero-filled silently; prefer [] plus a static assert against the name"
        }
    }
}
if ($rims -eq 0) { Write-Host "no rim layouts found in $Source"; exit 2 }

if ($fail -ne 0) { Write-Host "--- FAILED: $fail problem(s)"; exit 1 }
Write-Host "--- ok"
