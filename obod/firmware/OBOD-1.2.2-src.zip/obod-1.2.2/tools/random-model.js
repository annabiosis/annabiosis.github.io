/*
 * Host model of the two random draws (timbre and structure).
 *
 * This is not the firmware. It is the arithmetic the firmware would do, written
 * out where a hundred thousand draws cost a second and a report can be printed:
 * the ranges come from the constants in synth_app.cpp, the windows from
 * preset_rand_flo()/preset_rand_span(), and the musical judgements — what counts
 * as muddy, harsh, masked, over budget — are the ones the design asks for.
 *
 * The point is to answer one question with numbers instead of adjectives: does
 * the constrained draw actually stop producing the patches nobody wants, and does
 * it keep the variety the free draw had? Both draws are run over the same seed
 * base and the same number of patches, and every metric is computed the same way
 * on both sides, so the two columns are comparable.
 *
 * Node, no dependencies. Usage: node tools/random-model.js [draws]
 */
'use strict';

const fs = require('fs');
const path = require('path');

/* ------------------------------------------------------------------------- */
/* Ranges and mappings, transcribed from the firmware                        */
/* ------------------------------------------------------------------------- */

/* The drone cutoff axis: 37.5 Hz to 16 kHz, exponential — DRONE_CUTOFF_MIN_HZ,
 * DRONE_CUTOFF_MAX_HZ, and the same log the knob walks. */
const CUT_MIN = 37.5;
const CUT_OCTAVES = Math.log2(16000.0 / CUT_MIN);

/* Resonance is Q = q0 * 2^(3v) with q0 near 0.8 on the low register and 0.9 in
 * the middle: RESONANCE_RANGE_EXP is 3, the base is the register's own. */
const Q0 = 0.85;
const Q_EXP = 3.0;

/* The drone's sweep reaches four octaves on its own and six with WIDTH;
 * FILTER_DEPTH_AT_FULL is 4. */
const DEPTH_OCTAVES = 4.0;

/* The sweep's rate: twenty seconds a cycle at the bottom, six hertz at the top. */
const RATE_MIN_HZ = 0.05;
const RATE_MAX_HZ = 6.0;

/* The drum's pitch: 35 Hz to 7 kHz, 7.65 octaves. */
const PERC_MIN_HZ = 35.0;
const PERC_OCTAVES = 7.65;

const LFO_SHAPES = ['SINE', 'TRI', 'SQUARE', 'SAW', 'RANDOM', 'EXP+', 'EXP-', 'MIC'];
const VERB_MODES = ['ROOM', 'HALL', 'CATH', 'PLAT'];
const SCALES = [
    { name: 'MN PNT', pcs: [0, 3, 5, 7, 10],   weight: 3.0 },
    { name: 'MJ PNT', pcs: [0, 2, 4, 7, 9],    weight: 3.0 },
    { name: 'HIRA',   pcs: [0, 2, 3, 7, 8],    weight: 3.0 },
    { name: 'AEOL',   pcs: [0, 2, 3, 5, 7, 8, 10], weight: 3.0 },
    { name: 'DOR',    pcs: [0, 2, 3, 5, 7, 9, 10], weight: 3.0 },
    { name: 'PHRY',   pcs: [0, 1, 3, 5, 7, 8, 10], weight: 3.0 },
    { name: 'LYD',    pcs: [0, 2, 4, 6, 7, 9, 11], weight: 1.0 },
    { name: 'MIX',    pcs: [0, 2, 4, 5, 7, 9, 10], weight: 1.0 },
    { name: 'ION',    pcs: [0, 2, 4, 5, 7, 9, 11], weight: 1.0 },
    { name: 'LOCR',   pcs: [0, 1, 3, 5, 6, 8, 10], weight: 0.5 },
    { name: 'H. MIN', pcs: [0, 2, 3, 5, 7, 8, 11], weight: 1.0 },
    { name: 'BLUES',  pcs: [0, 3, 5, 6, 7, 10],    weight: 3.0 },
    { name: 'M. MIN', pcs: [0, 2, 3, 5, 7, 9, 11], weight: 1.0 },
    { name: 'WHOLE',  pcs: [0, 2, 4, 6, 8, 10],    weight: 0.5 },
    { name: 'DIM',    pcs: [0, 2, 3, 5, 6, 8, 9, 11], weight: 0.5 },
    { name: 'CHRM',   pcs: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11], weight: 0.5 },
];

/* ------------------------------------------------------------------------- */
/* The two draws, as they are today                                           */
/* ------------------------------------------------------------------------- */

/* PRESET_RAND_FLO and PRESET_RAND_SPAN: the central sixty percent. The two long
 * division lists get a window of their own, and this is the same arithmetic. */
const TIMBRE = [
    'cutoff', 'resonance', 'filterRate', 'filterDepth', 'motionDepth', 'motionRate',
    'lfoShape', 'leadCutoff', 'leadReso', 'leadEnv', 'leadAttack', 'leadDecay',
    'leadSustain', 'leadRelease', 'percPitch', 'percDecay', 'percEnv', 'percBody',
    'delaySync', 'delayTime', 'delayFeedback', 'chorusRate', 'chorusDepth',
    'verbMode', 'verbSize', 'verbDamp',
];
const STRUCTURE = [
    'scale', 'root', 'density', 'octave', 'seqSteps', 'seqPulses', 'seqRotate',
    'seqScatter', 'percSteps', 'percPulses', 'percRotate', 'arpDir', 'arpSpeed',
    'arpLen', 'arpRange', 'delayMix', 'chorusMix', 'verbMix',
];

/* A seeded generator, so two runs of this file produce the same two reports. */
function rng(seed) {
    let a = seed >>> 0;
    return function () {
        a = (a + 0x6D2B79F5) >>> 0;
        let t = Math.imul(a ^ (a >>> 15), 1 | a);
        t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
}

function windowFor(param) {
    if (param === 'delaySync') return [5 / 11, 4 / 11];
    if (param === 'arpSpeed') return [8 / 12, 3 / 12];
    return [0.2, 0.6];
}

function drawOld(r, list) {
    const p = {};
    for (const name of list) {
        const [flo, span] = windowFor(name);
        p[name] = flo + span * r();
    }
    return p;
}

/* ------------------------------------------------------------------------- */
/* Physical readings of a draw                                               */
/* ------------------------------------------------------------------------- */

const cutoffHz = (v) => CUT_MIN * Math.pow(2, CUT_OCTAVES * v);
const qOf = (v) => Q0 * Math.pow(2, Q_EXP * v);
const depthOct = (v) => DEPTH_OCTAVES * v;
const rateHz = (v) => RATE_MIN_HZ * Math.pow(RATE_MAX_HZ / RATE_MIN_HZ, v);
const percHz = (v) => PERC_MIN_HZ * Math.pow(2, PERC_OCTAVES * v);
const hzToMidi = (hz) => 69 + 12 * Math.log2(hz / 440);
const stepIndex = (v, count) => Math.max(0, Math.min(count - 1, Math.round(v * (count - 1))));

function pick(list, v) {
    return list[stepIndex(v, list.length)];
}

/* What kind of patch the numbers describe, for the table of faults. The four
 * faults are the ones the design names; each is a conjunction, because every
 * half of them is somewhere in a good patch too. */
function faults(p) {
    const cut = cutoffHz(p.cutoff);
    const q = qOf(p.resonance);
    const depth = depthOct(p.filterDepth);
    const mud = cut < 250 && q > 3.2 && depth > 2.4;
    /* HARSH used to need the drive as well: a bright, resonant corner was only harsh when a
     * fold or a hard clip was sitting in front of it. The drive is out of the instrument, so
     * the corner alone is what is left, and this row is stricter about it than it was. */
    const harsh = cut > 4000 && q > 4.5;
    const percInScale = p.percQuantized === true;

    const wet = (p.delayMix || 0) + (p.chorusMix || 0) + (p.verbMix || 0);
    const space = wet > 1.0;

    const steps = p.seqStepsSteps || 16;
    const pulses = p.seqPulsesSteps || 1;
    const rotate = p.seqRotateSteps || 0;
    /* A figure puts its pulses at round(i * n / p); a rotation lands a pulse on
     * the first step when it is the complement of one of those positions. */
    let firstStep = false;
    for (let i = 0; i < pulses; i++) {
        const pos = Math.round(i * steps / pulses) % steps;
        if ((pos + rotate) % steps === 0) { firstStep = true; break; }
    }

    /* The drum masks the drone when it sits within two semitones of the drone's
     * middle register and plays often enough to be the thing the ear follows. */
    /* A clash is a second or a seventh against the drone's middle register, on a
     * drum that plays often: an octave or a fifth is a doubling, not a mask. */
    const iv = ((Math.round(hzToMidi(percHz(p.percPitch)) - hzToMidi(110)) % 12) + 12) % 12;
    const masked = p.percQuantized === true && p.seqStepsSteps !== undefined
        && (iv === 1 || iv === 2 || iv === 10 || iv === 11)
        && (p.percPulsesSteps || 0) >= 4;

    /* Nothing holds the bottom: a corner above 1.2 kHz on a patch whose drum
     * plays in the bass leaves the field to the lead alone. */
    const noLow = cut > 1200 && percHz(p.percPitch) > 87;

    return { mud, harsh, percInScale, space, firstStep, masked, noLow, wet, cut, q, depth, algo, amount };
}

/* ------------------------------------------------------------------------- */
/* The proposal: character first, relations second, numbers last             */
/* ------------------------------------------------------------------------- */

/*
 * Eight characters. Each names a window for every parameter that decides what
 * the patch sounds like, and the windows overlap on purpose: two patches of the
 * same character have to differ. Values are normalised, the same units the knobs
 * use, so nothing here needs translating twice.
 */
/*
 * Eight characters. Each names a window for what decides how the patch SOUNDS, and the
 * windows are deliberately wider than the character's centre: two draws of one character
 * have to differ or the button is a tape loop. What the character fixes is the CENTRE,
 * not the edges.
 *
 * `mode` weights the filter's shape — LOW, BAND, HIGH — and `wave` the lead's six
 * shapes: SINE, TRI, SAW, PULSE, SUPER, NOISE. `verb` weights the four rooms.
 */
const CHARACTERS = [
    { name: 'DEEP', cutoff: [0.10, 0.45], res: [0.05, 0.40], depth: [0.30, 0.55],
      rate: [0.02, 0.35], leadCutoff: [0.08, 0.45], leadReso: [0.02, 0.35],
      leadAttack: [0.02, 0.30], leadDecay: [0.40, 0.80], leadSustain: [0.50, 0.90],
      leadRelease: [0.50, 0.90], lfo: [0, 2], mode: [4, 1, 0.3],
      wave: [2, 1, 3, 1, 1, 0.0], percDecay: [0.45, 0.85], percBody: [0.15, 0.50],
      verb: [1, 3, 0.5, 0.5], verbSize: [0.55, 0.90], verbDamp: [0.25, 0.65] },

    { name: 'GLASS', cutoff: [0.58, 0.90], res: [0.40, 0.75], depth: [0.06, 0.25],
      rate: [0.40, 0.85], leadCutoff: [0.55, 0.95], leadReso: [0.30, 0.65],
      leadAttack: [0.0, 0.15], leadDecay: [0.15, 0.50], leadSustain: [0.25, 0.60],
      leadRelease: [0.15, 0.50], lfo: [2, 4], mode: [0.5, 3, 1.5],
      wave: [3, 1, 1, 1, 1, 0.0], percDecay: [0.10, 0.40], percBody: [0.55, 0.90],
      verb: [0.3, 0.5, 0.3, 3], verbSize: [0.30, 0.60], verbDamp: [0.50, 0.85] },

    { name: 'DIRT', cutoff: [0.22, 0.56], res: [0.15, 0.50], depth: [0.15, 0.40],
      rate: [0.30, 0.75], leadCutoff: [0.25, 0.65], leadReso: [0.15, 0.50],
      leadAttack: [0.0, 0.15], leadDecay: [0.10, 0.45], leadSustain: [0.30, 0.65],
      leadRelease: [0.10, 0.45], lfo: [0, 4], mode: [2, 2, 1],
      wave: [1, 1, 3, 2, 1, 0.3], percDecay: [0.05, 0.35], percBody: [0.45, 0.85],
      verb: [2, 1, 0.3, 0.2], verbSize: [0.25, 0.55], verbDamp: [0.45, 0.80] },

    { name: 'HOLLOW', cutoff: [0.33, 0.68], res: [0.25, 0.60], depth: [0.10, 0.35],
      rate: [0.15, 0.60], leadCutoff: [0.35, 0.70], leadReso: [0.20, 0.55],
      leadAttack: [0.02, 0.25], leadDecay: [0.25, 0.60], leadSustain: [0.40, 0.75],
      leadRelease: [0.25, 0.65], lfo: [0, 3], mode: [2, 1.5, 0.5],
      wave: [1, 2, 2, 3, 0.5, 0.0], percDecay: [0.25, 0.60], percBody: [0.40, 0.75],
      verb: [2, 1, 0.3, 0.3], verbSize: [0.35, 0.65], verbDamp: [0.35, 0.70] },

    { name: 'NOISE', cutoff: [0.45, 0.80], res: [0.02, 0.30], depth: [0.04, 0.20],
      rate: [0.05, 0.45], leadCutoff: [0.45, 0.80], leadReso: [0.05, 0.35],
      leadAttack: [0.25, 0.65], leadDecay: [0.45, 0.85], leadSustain: [0.55, 0.95],
      leadRelease: [0.55, 0.95], lfo: [0, 4], mode: [1, 3, 1],
      wave: [1, 1, 1, 0.5, 2, 3], percDecay: [0.50, 0.90], percBody: [0.0, 0.30],
      verb: [0.3, 1, 4, 0.5], verbSize: [0.65, 0.98], verbDamp: [0.15, 0.55] },

    { name: 'BELL', cutoff: [0.33, 0.62], res: [0.45, 0.75], depth: [0.03, 0.18],
      rate: [0.10, 0.50], leadCutoff: [0.40, 0.75], leadReso: [0.25, 0.60],
      leadAttack: [0.0, 0.10], leadDecay: [0.45, 0.85], leadSustain: [0.15, 0.50],
      leadRelease: [0.45, 0.85], lfo: [0, 2], mode: [1, 3, 1],
      wave: [3, 3, 1, 0.5, 0.5, 0.0], percDecay: [0.55, 0.95], percBody: [0.50, 0.85],
      verb: [0.3, 2, 0.5, 2], verbSize: [0.50, 0.85], verbDamp: [0.25, 0.65] },

    { name: 'MACHINE', cutoff: [0.22, 0.51], res: [0.20, 0.50], depth: [0.20, 0.45],
      rate: [0.50, 0.95], leadCutoff: [0.25, 0.60], leadReso: [0.15, 0.45],
      leadAttack: [0.0, 0.08], leadDecay: [0.02, 0.30], leadSustain: [0.15, 0.50],
      leadRelease: [0.02, 0.30], lfo: [1, 4], mode: [2, 2, 1],
      wave: [1, 1, 2, 3, 1, 0.0], percDecay: [0.02, 0.25], percBody: [0.35, 0.75],
      verb: [3, 0.5, 0.2, 0.2], verbSize: [0.15, 0.45], verbDamp: [0.50, 0.85] },

    { name: 'QUIET', cutoff: [0.28, 0.60], res: [0.05, 0.35], depth: [0.20, 0.45],
      rate: [0.02, 0.40], leadCutoff: [0.20, 0.55], leadReso: [0.05, 0.35],
      leadAttack: [0.20, 0.60], leadDecay: [0.45, 0.90], leadSustain: [0.55, 0.95],
      leadRelease: [0.50, 0.95], lfo: [0, 2], mode: [3, 1, 0.3],
      wave: [3, 2, 1, 0.5, 0.5, 0.0], percDecay: [0.45, 0.85], percBody: [0.10, 0.45],
      verb: [0.5, 3, 0.3, 1], verbSize: [0.70, 0.98], verbDamp: [0.20, 0.60] },
];

/*
 * THE CHARACTER'S PERFORMANCE, in the firmware's order: how many of the figure's steps
 * fire, how fast it runs, how the lead's notes are joined, how far the drum may wander.
 * The corner alone did not make eight characters that can be told apart by ear; a dark
 * patch at 45 BPM with three notes in a bar and a bright one at 210 BPM with every step
 * firing are two instruments before any filter number is heard.
 */
const FEEL = {
    DEEP:    { density: [0.20, 0.40], tempo: [0.18, 0.32], arp: [0.45, 0.65], scatter: [0.02, 0.10], gate: [0.55, 0.85] },
    GLASS:   { density: [0.45, 0.70], tempo: [0.45, 0.60], arp: [0.70, 0.90], scatter: [0.05, 0.15], gate: [0.25, 0.55] },
    DIRT:    { density: [0.55, 0.80], tempo: [0.55, 0.75], arp: [0.60, 0.85], scatter: [0.10, 0.25], gate: [0.20, 0.45] },
    HOLLOW:  { density: [0.30, 0.55], tempo: [0.30, 0.45], arp: [0.50, 0.75], scatter: [0.03, 0.12], gate: [0.40, 0.70] },
    NOISE:   { density: [0.10, 0.30], tempo: [0.15, 0.30], arp: [0.35, 0.60], scatter: [0.15, 0.35], gate: [0.70, 0.95] },
    BELL:    { density: [0.25, 0.45], tempo: [0.30, 0.45], arp: [0.55, 0.80], scatter: [0.02, 0.08], gate: [0.05, 0.30] },
    MACHINE: { density: [0.70, 0.95], tempo: [0.70, 0.92], arp: [0.85, 1.00], scatter: [0.02, 0.10], gate: [0.15, 0.35] },
    QUIET:   { density: [0.08, 0.25], tempo: [0.12, 0.28], arp: [0.35, 0.55], scatter: [0.02, 0.08], gate: [0.75, 0.95] },
};
/* A weighted choice: the character says which shapes it prefers, and the weights are
 * the preference rather than a ban. */
function weighted(r, weights) {
    const total = weights.reduce((a, b) => a + b, 0);
    let x = r() * total;
    for (let i = 0; i < weights.length; i++) {
        x -= weights[i];
        if (x <= 0) return i;
    }
    return 0;
}
/* Between the character's window and the free one: the patch keeps the shape of
 * its character but does not start repeating itself. */
const CHARACTER_SHARE = 0.6;

/*
 * Between the character's window and the free one.
 *
 * Two shares, not one. What MAKES the character — the corner and the lead's corner —
 * is held at three fifths, because a DEEP that is not dark is not DEEP. Everything that
 * makes two patches of one character differ — resonance, sweep, envelope, the room's
 * size and damping — is only half the character, so the free middle is free to move it.
 */
const SHARE_IDENTITY = 0.6;
const SHARE_TEXTURE = 0.5;

const FREE_FLO = 0.1;
const FREE_SPAN = 0.8;

function between(r, win, free, share) {
    const s = share || SHARE_IDENTITY;
    const v = win[0] + (win[1] - win[0]) * r();
    return s * v + (1 - s) * free;
}

const freeDraw = (r) => FREE_FLO + FREE_SPAN * r();

/*
 * ONE DRAW IN SIX IS WILD: it ignores the character's window and takes the whole travel.
 * Five in six stay in character, which is what makes the button a character button; the
 * sixth is the one that makes two presses sound like two different instruments rather
 * than two settings of one. It is also why the average distance between draws can be
 * larger than a uniform draw over the same middle: the wild sixth reaches the ends.
 */
const WILD_SHARE = 1 / 6;
const wild = (r) => r() < WILD_SHARE;
const any = (r) => 0.02 + 0.96 * r();

function pick(r, win, share) {
    return r.wild ? any(r) : between(r, win, freeDraw(r), share);
}

function texture(r, win) {
    return pick(r, win, SHARE_TEXTURE);
}

function pickScale(r) {
    const total = SCALES.reduce((n, s) => n + s.weight, 0);
    let x = r() * total;
    for (const s of SCALES) {
        x -= s.weight;
        if (x <= 0) return s;
    }
    return SCALES[0];
}

/*
 * A drum pitch on a degree of the chosen scale, in the register a body wants:
 * a minor third to a major tenth above the drone's base. Tonic, fifth and octave
 * together take about three draws in five.
 */
function percPitchOnScale(r, scale, bassOnly) {
    const weight = (deg) => {
        const pc = scale.pcs[deg % scale.pcs.length];
        const oct = Math.floor(deg / scale.pcs.length);
        const semis = pc + 12 * oct;
        if (semis === 0 || semis === 7 || semis === 12) return 3.0;
        if (semis === 3 || semis === 4) return 1.5;
        return 1.0;
    };
    const degrees = [];
    for (let d = 0; d < scale.pcs.length * 2; d++) {
        const semis = scale.pcs[d % scale.pcs.length] + 12 * Math.floor(d / scale.pcs.length);
        if (bassOnly ? (semis < 0 || semis > 7) : (semis < 3 || semis > 16)) continue;
        /* Nor a second or a seventh against the drone's middle register: those are
         * the intervals that read as a mistake rather than as colour. The model
         * found them at 12 percent of draws before this line existed. */
        const against = ((semis - 12) % 12 + 12) % 12;
        if (against === 1 || against === 2 || against === 10 || against === 11) continue;
        degrees.push({ semis, weight: weight(d) });
    }
    if (degrees.length === 0) return 55 * Math.pow(2, 7 / 12);
    const total = degrees.reduce((n, d) => n + d.weight, 0);
    let x = r() * total;
    for (const d of degrees) {
        x -= d.weight;
        if (x <= 0) return 55 * Math.pow(2, d.semis / 12);
    }
    return 55 * Math.pow(2, degrees[0].semis / 12);
}

/* A grid and a figure that belongs on it: the drum takes the lead's pulse count,
 * a neighbour's, or nothing, and the rotation is chosen so a pulse lands on the
 * first step rather than drawn and then hoped over. */
function rhythm(r) {
    const grids = [8, 12, 16];
    const gw = [2, 3, 5];
    let x = r() * gw.reduce((a, b) => a + b, 0);
    let steps = 8;
    for (let i = 0; i < grids.length; i++) {
        x -= gw[i];
        if (x <= 0) { steps = grids[i]; break; }
    }
    const pulses = 3 + Math.floor(r() * 5);            /* 3..7 */
    const lead = Math.min(pulses, steps);
    const percChoice = r();
    const perc = percChoice < 0.5 ? lead
               : percChoice < 0.75 ? Math.max(1, lead - 1)
               : Math.min(steps, lead + 1);
    return { steps, lead, perc };
}

/* The first step of the grid always carries a pulse: pick one of the figure's
 * own pulse positions and rotate its complement onto the downbeat. A rotation
 * drawn at random leaves the downbeat empty most of the time — see the column
 * "первый шаг звучит" in the report. */
function rotateFor(steps, pulses, r) {
    const j = Math.floor(r() * pulses);
    const pos = Math.round(j * steps / pulses) % steps;
    return (steps - pos) % steps;
}


/* ------------------------------------------------------------------------- */
/* The constrained draw — timbre                                            */
/* ------------------------------------------------------------------------- */

function drawNewTimbre(r) {
    const ch = CHARACTERS[Math.floor(r() * CHARACTERS.length)];
    const free = () => r();
    const p = {};

    r.wild = wild(r);
    p.cutoff = pick(r, ch.cutoff, SHARE_IDENTITY);
    /* The corner is pulled onto a semitone of the drone's own base: a cutoff
     * between two notes is the one the ear hears as out of tune with itself. */
    const hz = cutoffHz(p.cutoff);
    const semis = Math.round(12 * Math.log2(hz / 55));
    p.cutoff = Math.log2(55 * Math.pow(2, semis / 12) / CUT_MIN) / CUT_OCTAVES;
    p.cutoff = Math.max(0, Math.min(1, p.cutoff));

    p.resonance = texture(r, ch.res);
    p.filterDepth = texture(r, ch.depth);
    p.filterRate = texture(r, ch.rate);
    p.leadCutoff = pick(r, ch.leadCutoff, 0.55);
    p.leadReso = texture(r, ch.leadReso);
    p.leadAttack = texture(r, ch.leadAttack);
    p.leadDecay = texture(r, ch.leadDecay);
    p.leadSustain = texture(r, ch.leadSustain);
    p.leadRelease = texture(r, ch.leadRelease);

    /*
     * THE SHAPE IS A DRAW OF ITS OWN, and it is where most of the difference between two
     * patches of one character comes from now: a low pass and a band pass at the same
     * corner are two different instruments, and so are a saw and a supersaw behind them.
     * The character weights the choice; it does not fix it.
     */
    p.filterMode = weighted(r, ch.mode);            /* 0 LOW, 1 BAND, 2 HIGH */
    p.leadWave = weighted(r, ch.wave);              /* SINE TRI SAW PULSE SPR NOISE */
    /* A slow random shape under a deep sweep is one more hand on the same knob;
     * the shapes with a direction — SINE to SAW — are the ones that read. */
    p.lfoShape = (ch.lfo[0] + (ch.lfo[1] - ch.lfo[0]) * r()) ;
    p.lfoShape = Math.round(p.lfoShape);
    if (p.filterDepth > 0.6 && p.lfoShape === 4) p.lfoShape = 0;

    p.percDecay = texture(r, ch.percDecay);
    p.percBody = texture(r, ch.percBody);
    p.percEnv = 0.2 + 0.6 * r();
    p.verbMode = weighted(r, ch.verb);              /* ROOM HALL CATH PLAT */
    p.verbSize = texture(r, ch.verbSize);
    p.verbDamp = texture(r, ch.verbDamp);
    p.delaySync = 5 / 11 + (4 / 11) * r();
    p.delayTime = 0.3 + 0.4 * r();
    p.delayFeedback = 0.25 + 0.5 * r();
    p.chorusRate = 0.2 + 0.5 * r();
    p.chorusDepth = 0.2 + 0.6 * r();
    p.motionDepth = 0.3 + 0.4 * r();
    p.motionRate = 0.1 + 0.5 * r();

    /* THE DRIVE IS NOT HERE AT ALL, and it is not merely not drawn: the stage, its page and
     * its two knobs left the instrument. The parameters still exist as dead slots so that a
     * stored patch keeps its shape, and a draw never touches them. */

    /*
     * The wet budget is one unit, shared out rather than drawn three times — but WHICH
     * effect owns it is a draw of its own. In the first version the reverb took the
     * largest share on nearly every draw, so every patch sat in the same room; now a draw
     * can be a delay patch with almost no room, or a chorus patch, or a hall.
     */
    const total = 0.35 + 0.60 * r();
    const wd = 0.30 + 0.90 * r(), wc = 0.20 + 1.00 * r(), wv = 0.30 + 0.90 * r();
    const sum = wd + wc + wv;
    p.delayMix = total * wd / sum;
    p.chorusMix = total * wc / sum;
    p.verbMix = total * wv / sum;
    if (p.delayMix > 0.25) p.delayFeedback = Math.min(p.delayFeedback, 0.55);

    /*
     * BITE: one draw in four is pushed away from the middle of every texture control at
     * once. Without it every patch is comfortable — the window centres average out, and a
     * hundred draws in a row sound like a hundred settings of one instrument. With it a
     * draw can come out with a very short envelope and a very small room, or a long one and
     * a very big room, and the player hears the difference before reading it.
     *
     * The corner is not stretched: it is the character, and it is already snapped.
     */
    /* The performance: what makes two characters two instruments before any filter
     * number is heard. */
    const feel = FEEL[ch.name];
    for (const k of ['density', 'tempo', 'arp', 'scatter', 'gate']) {
        const w = feel[k];
        p[k] = r.wild ? any(r) : between(r, w, freeDraw(r), SHARE_TEXTURE);
    }

    const bite = [0.8, 1.0, 1.0, 1.2, 1.0, 1.35, 1.0, 1.6][Math.floor(r() * 8)];
    const stretch = (v) => Math.max(0.0, Math.min(1.0, 0.5 + (v - 0.5) * bite));
    for (const k of ['resonance', 'filterDepth', 'filterRate', 'leadReso', 'leadAttack',
                     'leadDecay', 'leadSustain', 'leadRelease', 'percDecay', 'percBody',
                     'percEnv', 'verbSize', 'verbDamp', 'chorusDepth', 'chorusRate',
                     'motionDepth', 'motionRate']) {
        p[k] = stretch(p[k]);
    }
    p.bite = bite;

    p.character = ch.name;
    return p;
}

function drawNewStructure(r) {
    const p = drawNewTimbre(r);
    const scale = pickScale(r);
    p.scale = SCALES.indexOf(scale);
    p.root = 30 + Math.floor(r() * 40);                  /* a bass-to-tenor root */
    p.octave = 0.35 + 0.3 * r();
    p.density = 0.3 + 0.4 * r();

    const fig = rhythm(r);
    p.seqStepsSteps = fig.steps;
    p.seqPulsesSteps = fig.lead;
    p.seqRotateSteps = rotateFor(fig.steps, fig.lead, r);
    p.seqScatter = 0.05 + 0.20 * r();
    p.percStepsSteps = fig.steps;
    p.percPulsesSteps = fig.perc;
    p.percRotateSteps = rotateFor(fig.steps, fig.perc, r);

    p.percQuantized = true;
    /* The knob's own units: the inverse of percHz(), so anything reading the
     * patch back sees the pitch the draw chose. */
    /* A corner high in the spectrum takes the bottom out of the drone, so the drum
     * is the one left holding it: the register follows the filter rather than
     * being drawn beside it. The model found this at seven percent of draws. */
    const drumHz = percPitchOnScale(r, scale, cutoffHz(p.cutoff) > 1200);
    p.percPitch = Math.log2(drumHz / PERC_MIN_HZ) / PERC_OCTAVES;

    /* Arpeggio: a rise has to have somewhere to rise, so length follows range. */
    p.arpRange = 1 + Math.floor(r() * 3);                /* 1..3 */
    p.arpLen = 2 + Math.floor(r() * (p.arpRange > 2 ? 4 : 3));
    p.arpDir = Math.floor(r() * 3);                      /* never RANDOM */
    p.arpSpeed = 8 / 12 + (3 / 12) * r();
    return p;
}

/* ------------------------------------------------------------------------- */
/* Scoring: eight candidates, the least wrong one wins                       */
/* ------------------------------------------------------------------------- */

function score(p, structural) {
    const f = faults(p);
    let s = 0;
    if (f.mud) s += 3;
    if (f.harsh) s += 3;
    if (f.space) s += 2;
    if (structural) {
        /* Masking: a drum inside two semitones of the drone's tonic at high
         * density is a drum nobody can pick out. */
        if (!f.percInScale) s += 1;
        const steps = p.seqStepsSteps;
        const events = (p.seqPulsesSteps + p.percPulsesSteps) * 16 / steps;
        if (events < 2) s += 2;
        if (f.cut && cutoffHz(p.cutoff) > 1200 && p.percPulsesSteps < 2) s += 1;
    }
    return s;
}

function bestOf(r, structural, tries) {
    let best = null, bestScore = Infinity;
    for (let i = 0; i < tries; i++) {
        const p = structural ? drawNewStructure(r) : drawNewTimbre(r);
        const s = score(p, structural);
        if (s < bestScore) { best = p; bestScore = s; }
        if (s === 0) break;
    }
    best.score = bestScore;
    return best;
}

/* ------------------------------------------------------------------------- */
/* Reports                                                                   */
/* ------------------------------------------------------------------------- */

const DRAWS = Number(process.argv[2] || 100000);

function pct(n, d) { return (100 * n / d).toFixed(2).replace('.', ',') + ' %'; }

function run(label, draws, make) {
    const out = {
        label, mud: 0, harsh: 0, space: 0, inScale: 0, firstStep: 0, masked: 0, noLow: 0, eventsLow: 0,
        wetSum: 0, cuts: [], ivs: [], chars: {}, scales: {}, qs: [], scores: 0, rejected: 0,
        sig: [], combos: new Set(), sweeps: [],
    };
    for (let i = 0; i < draws; i++) {
        const p = make(i);
        const f = faults(p);
        if (f.mud) out.mud++;
        if (f.harsh) out.harsh++;
        if (f.space) out.space++;
        if (f.percInScale) out.inScale++;
        if (f.firstStep) out.firstStep++;
        if (f.masked) out.masked++;
        if (f.noLow) out.noLow++;
        const steps = p.seqStepsSteps || 16;
        const events = ((p.seqPulsesSteps || 0) + (p.percPulsesSteps || 0)) * 16 / steps;
        if (p.seqStepsSteps !== undefined && events < 2) out.eventsLow++;
        out.wetSum += f.wet;
        out.cuts.push(cutoffHz(p.cutoff));
        out.qs.push(f.q);
        if (p.percQuantized === true && p.seqStepsSteps !== undefined) {
            const iv = ((Math.round(hzToMidi(percHz(p.percPitch)) - hzToMidi(110)) % 12) + 12) % 12;
            out.ivs.push(iv);
        }
        if (p.character) out.chars[p.character] = (out.chars[p.character] || 0) + 1;

        /* How different two draws of this draw are from one another. The signature is the
         * parameters a listener hears first, all normalised; the report takes a sample of
         * five hundred and averages every pair's distance over them. A draw whose numbers
         * are clean but whose patches sound alike fails on this line, not on the others. */
        if (out.sig.length < 500) {
            out.sig.push([
                p.cutoff, p.resonance, p.filterDepth, p.filterRate, p.leadCutoff,
                p.leadReso, p.leadAttack, p.leadDecay, p.leadSustain, p.leadRelease,
                p.percDecay, p.percBody, p.verbSize, p.verbDamp, p.chorusDepth,
                p.density, p.tempo, p.arp, p.gate,
            ]);
        }
        if (p.character) {
            out.combos.add([p.character, p.filterMode, p.leadWave, p.verbMode].join('/'));
        }
        /* The corner does not sit still: the sweep takes it DEPTH_OCTAVES octaves either
         * side. Two characters whose sweeps cover the same span sound like one character
         * however different their corners are, so the report measures how much the eight
         * spans overlap each other. */
        if (p.character && out.sweeps.length < 4000) {
            const c = cutoffHz(p.cutoff);
            const oct = 4 * p.filterDepth;
            out.sweeps.push([p.character, c / Math.pow(2, oct), c * Math.pow(2, oct)]);
        }
        /* Only the proposal draws an index: the free draw writes a normalised
         * value and would have to be read back through the list. */
        if (Number.isInteger(p.scale) && SCALES[p.scale]) out.scales[SCALES[p.scale].name] = 1;
        if (p.score !== undefined) { out.scores += p.score; if (p.score > 0) out.rejected++; }
    }
    out.cuts.sort((a, b) => a - b);
    out.qs.sort((a, b) => a - b);
    out.spread = meanPairDistance(out.sig);
    return out;
}

/* The mean distance over every pair of sampled draws, divided by the widest distance
 * the signature could have on one axis: 0 means every draw is the same patch, 1 means
 * every pair is at opposite ends of every control. */
function meanPairDistance(sig) {
    const n = sig.length;
    if (n < 2) return 0;
    const dims = sig[0].length;
    let total = 0, pairs = 0;
    for (let i = 0; i < n; i++) {
        for (let j = i + 1; j < n; j++) {
            let d = 0;
            for (let k = 0; k < dims; k++) d += Math.abs(sig[i][k] - sig[j][k]);
            total += d / dims;
            pairs++;
        }
    }
    return total / pairs;
}

function median(list) { return list[list.length >> 1]; }

function report() {
    const oldT = run('тембр, сейчас', DRAWS, (i) => {
        const r = rng(1000 + i * 7919);
        const p = drawOld(r, TIMBRE);
        p.percQuantized = false;
        return p;
    });
    const newT = run('тембр, предложение', DRAWS, (i) => {
        const r = rng(2000 + i * 7919);
        return bestOf(r, false, 8);
    });
    const oldS = run('структура, сейчас', DRAWS, (i) => {
        const r = rng(3000 + i * 7919);
        const p = drawOld(r, TIMBRE.concat(STRUCTURE));
        p.percQuantized = false;
        const steps = 4 + Math.round(p.seqSteps * 12);
        p.seqStepsSteps = Math.max(4, Math.min(16, steps));
        p.seqPulsesSteps = 1 + Math.round(p.seqPulses * (p.seqStepsSteps - 1));
        p.seqRotateSteps = Math.round(p.seqRotate * (p.seqStepsSteps - 1));
        p.percStepsSteps = Math.max(4, Math.min(16, 4 + Math.round(p.percSteps * 12)));
        p.percPulsesSteps = 1 + Math.round(p.percPulses * (p.percStepsSteps - 1));
        p.percRotateSteps = Math.round(p.percRotate * (p.percStepsSteps - 1));
        return p;
    });
    const newS = run('структура, предложение', DRAWS, (i) => {
        const r = rng(4000 + i * 7919);
        return bestOf(r, true, 8);
    });

    const lines = [];
    const say = (s) => { lines.push(s); console.log(s); };

    say('');
    say('МОДЕЛЬ РАНДОМИЗАЦИИ: ' + DRAWS + ' бросков на столбец, одинаковое зерно');
    say('');
    say('Показатель                          тембр сейчас   тембр новый   структура сейчас   структура новая');
    const row = (name, a, b, c, d) => {
        say(name.padEnd(34) + String(a).padStart(12) + String(b).padStart(14)
            + String(c).padStart(18) + String(d).padStart(19));
    };
    row('мутные сочетания', pct(oldT.mud, DRAWS), pct(newT.mud, DRAWS),
        pct(oldS.mud, DRAWS), pct(newS.mud, DRAWS));
    row('резкие сочетания', pct(oldT.harsh, DRAWS), pct(newT.harsh, DRAWS),
        pct(oldS.harsh, DRAWS), pct(newS.harsh, DRAWS));
    row('перегруз пространства', pct(oldT.space, DRAWS), pct(newT.space, DRAWS),
        pct(oldS.space, DRAWS), pct(newS.space, DRAWS));
    row('удар в ладу', '—', '—', pct(oldS.inScale, DRAWS), pct(newS.inScale, DRAWS));
    row('первый шаг звучит', '—', '—', pct(oldS.firstStep, DRAWS), pct(newS.firstStep, DRAWS));
    row('удар в секунде с дроном', '—', '—', pct(oldS.masked, DRAWS), pct(newS.masked, DRAWS));
    row('низ пропал', '—', '—', pct(oldS.noLow, DRAWS), pct(newS.noLow, DRAWS));
    row('реже двух событий на такт', '—', '—', pct(oldS.eventsLow, DRAWS), pct(newS.eventsLow, DRAWS));
    row('средняя сумма мокрых смесей', (oldT.wetSum / DRAWS).toFixed(2),
        (newT.wetSum / DRAWS).toFixed(2), (oldS.wetSum / DRAWS).toFixed(2),
        (newS.wetSum / DRAWS).toFixed(2));

    /* How much of one character's sweep span lies inside another's: 1 means the two are
     * the same instrument with a different knob position, 0 means a listener can hear
     * which character is playing without looking. */
    const overlap = (runs) => {
        const per = {};
        for (const [name, lo, hi] of runs.sweeps) {
            (per[name] = per[name] || []).push([lo, hi]);
        }
        const names = Object.keys(per);
        const med = (a) => a[Math.floor(a.length / 2)];
        const span = {};
        for (const n of names) {
            const lo = per[n].map((v) => v[0]).sort((a, b) => a - b);
            const hi = per[n].map((v) => v[1]).sort((a, b) => a - b);
            span[n] = [med(lo), med(hi)];
        }
        let total = 0, pairs = 0;
        for (let i = 0; i < names.length; i++) {
            for (let j = i + 1; j < names.length; j++) {
                const a = span[names[i]], b = span[names[j]];
                const lo = Math.max(a[0], b[0]), hi = Math.min(a[1], b[1]);
                if (hi <= lo) continue;
                const inter = Math.log2(hi / lo);
                const union = Math.log2(Math.max(a[1], b[1]) / Math.min(a[0], b[0]));
                total += inter / union;
                pairs++;
            }
        }
        return pairs ? total / pairs : 0;
    };

    say('');
    say('ПЕРЕСТРОЙКА: НАСКОЛЬКО ХАРАКТЕРЫ ПЕРЕКРЫВАЮТ ДРУГ ДРУГА');
    const oline = (name, a, b) => say(name.padEnd(40) + String(a).padStart(14) + String(b).padStart(16));
    oline('показатель', 'сейчас', 'предложение');
    oline('перекрытие полосы перестройки', overlap(oldT).toFixed(2), overlap(newT).toFixed(2));

    say('');
    say('РАЗЛИЧИЕ МЕЖДУ БРОСКАМИ, среднее расстояние по 15 слышимым ручкам');
    const dline = (name, a, b) => say(name.padEnd(40) + String(a).padStart(14) + String(b).padStart(16));
    dline('показатель', 'сейчас', 'предложение');
    dline('среднее расстояние пары бросков', oldT.spread.toFixed(3), newT.spread.toFixed(3));
    dline('различных сочетаний на 1000 бросков',
        Math.min(1000, oldT.combos.size), Math.min(1000, newT.combos.size));

    say('');
    say('РАЗБРОС, чтобы узкие окна не убили разнообразие');
    const span = (r) => (r.cuts[r.cuts.length - 1] / r.cuts[0]);
    const line = (name, a, b) => say(name.padEnd(34) + a.padStart(18) + b.padStart(22));
    line('показатель', 'сейчас', 'предложение');
    line('срез: медиана, Гц', median(oldT.cuts).toFixed(0), median(newT.cuts).toFixed(0));
    line('срез: край к краю, раз', span(oldT).toFixed(1), span(newT).toFixed(1));
    line('резонанс: медиана Q', median(oldT.qs).toFixed(2), median(newT.qs).toFixed(2));
    const q = (list, f) => list[Math.floor(list.length * f)];
    line('срез: нижняя четверть, Гц', q(oldT.cuts, 0.25).toFixed(0), q(newT.cuts, 0.25).toFixed(0));
    line('срез: верхняя четверть, Гц', q(oldT.cuts, 0.75).toFixed(0), q(newT.cuts, 0.75).toFixed(0));
    line('резонанс: нижняя четверть Q', q(oldT.qs, 0.25).toFixed(2), q(newT.qs, 0.25).toFixed(2));
    line('резонанс: верхняя четверть Q', q(oldT.qs, 0.75).toFixed(2), q(newT.qs, 0.75).toFixed(2));
    say('');

    const chars = Object.entries(newT.chars).sort((a, b) => b[1] - a[1]);
    say('ХАРАКТЕРЫ, тембр (ожидалось близко к 1/8 на каждый):');
    say('  ' + chars.map(([n, c]) => n + ' ' + pct(c, DRAWS)).join('   '));
    say('');
    say('ЛАДЫ, структура: встретилось ' + Object.keys(newS.scales).length + ' из ' + SCALES.length);
    say('');
    const avgScore = (newT.scores / DRAWS).toFixed(2);
    say('СРЕДНИЙ ШТРАФ принятого броска: тембр ' + avgScore
        + ', структура ' + (newS.scores / DRAWS).toFixed(2)
        + '; доля бросков, которым понадобилась вторая попытка: '
        + pct(newT.rejected, DRAWS) + ' и ' + pct(newS.rejected, DRAWS));
    say('');

    /* The same numbers as data, for the picture beside this report. */
    const out = path.join(__dirname, '..', '_accept');
    if (fs.existsSync(out)) {
        fs.writeFileSync(path.join(out, 'random-model.json'), JSON.stringify({
            draws: DRAWS,
            cutsOld: oldT.cuts, cutsNew: newT.cuts,
            ivsNew: newS.ivs,
        }), 'utf8');
    }

    return lines.join('\n');
}

const text = report();
const dir = path.join(__dirname, '..', '_accept');
if (fs.existsSync(dir)) {
    fs.writeFileSync(path.join(dir, 'random-model.txt'), text + '\n', 'utf8');
}
