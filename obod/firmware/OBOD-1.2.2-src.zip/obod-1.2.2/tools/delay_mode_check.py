"""
A one-to-one port of the delay's per-sample loop, in both of its time modes, to check the
numbers before they cost a build and a flash — the same method perc_check.py uses for the
drum.

Mirrors components/synth_dsp/src/synth_fx_delay.cpp: the same clamps in the setter, the
same one-pole glide on the read position, the same half-sample ceiling on how fast that
position may walk, and the same 30 ms fade in the mode that does not walk at all. The read
is synth_fx_read() from synth_dsp_private.h, linear interpolation and all.

Answers four questions:
  1. in TAPE, does a change of time bend the repeats, and by how much?
  2. in XFADE, does the read position jump in one sample and the fade last 30 ms?
  3. in XFADE, does the repeats' pitch stay where it was — which is the whole point?
  4. does either mode put a step in the output that a hard jump would?

Run with the bundled interpreter (numpy is there):
  python tools/delay_mode_check.py
"""

import math
import sys

import numpy as np

SR = 48000
DELAY_MAX_MS = 4000.0
DELAY_MIN_MS = 2.0
DELAY_GLIDE_MS = 60.0
DELAY_FB_GLIDE_MS = 20.0
DELAY_SLEW_MAX = 0.5
DELAY_XFADE_MS = 30.0

BLOCK = 128
TONE_HZ = 440.0

FAILURES = []


def check(claim, ok, detail):
    mark = "ok  " if ok else "FAIL"
    print("  %s  %-52s %s" % (mark, claim, detail))
    if not ok:
        FAILURES.append(claim)


class Delay:
    """The module's statics, and its two entry points."""

    def __init__(self, crossfade):
        self.s_rate = float(SR)
        self.s_len = int(SR * DELAY_MAX_MS / 1000.0)
        self.s_line = [np.zeros(self.s_len, dtype=np.float64),
                       np.zeros(self.s_len, dtype=np.float64)]
        self.s_write = 0
        self.s_delay = 0.0
        self.s_target = 0.0
        self.s_glide = 1.0 - math.exp(-1.0 / (DELAY_GLIDE_MS * self.s_rate / 1000.0))
        self.s_fb_glide = 1.0 - math.exp(-1.0 / (DELAY_FB_GLIDE_MS * self.s_rate / 1000.0))
        self.s_xfade_len = int(DELAY_XFADE_MS * self.s_rate / 1000.0)
        self.s_fb = 0.0
        self.s_fb_cur = 0.0
        self.s_mix = 0.0
        # The mode's own state.
        self.s_xfade = crossfade
        self.s_delay_b = 4800.0
        self.s_xfade_n = 0
        # What the run observed.
        self.step_max = 0.0        # the largest one-sample move of the pointer
        self.set_jump = 0.0        # the move the SETTER made, which is outside the loop
        self.fade_seen = 0         # samples spent inside a fade
        self.gain_sum_min = 1.0
        self.gain_sum_max = 1.0

        self.set(self.s_rate * 0.25, 0.35, 0.0)

    def read(self, line, write, delay):
        if delay < 1.0:
            delay = 1.0
        elif delay > float(self.s_len - 2):
            delay = float(self.s_len - 2)
        pos = float(write) - delay
        if pos < 0.0:
            pos += float(self.s_len)
        i0 = int(pos)
        t = pos - float(i0)
        i1 = 0 if (i0 + 1 >= self.s_len) else i0 + 1
        return line[i0] + (line[i1] - line[i0]) * t

    def set(self, time_samples, feedback01, mix01):
        min_samples = DELAY_MIN_MS * self.s_rate / 1000.0
        if not (time_samples >= min_samples):
            time_samples = min_samples
        elif time_samples > float(self.s_len - 2):
            time_samples = float(self.s_len - 2)
        if not (feedback01 >= 0.0):
            feedback01 = 0.0
        elif feedback01 > 0.95:
            feedback01 = 0.95
        if not (mix01 >= 0.0):
            mix01 = 0.0
        elif mix01 > 1.0:
            mix01 = 1.0

        if self.s_xfade and time_samples != self.s_target:
            self.s_delay_b = self.s_delay
            self.set_jump = abs(time_samples - self.s_delay)
            self.s_delay = time_samples
            self.s_xfade_n = self.s_xfade_len

        self.s_target = time_samples
        self.s_fb = feedback01
        self.s_mix = mix01

    def process(self, l, r):
        for i in range(len(l)):
            step = (self.s_target - self.s_delay) * self.s_glide
            if step > DELAY_SLEW_MAX:
                step = DELAY_SLEW_MAX
            elif step < -DELAY_SLEW_MAX:
                step = -DELAY_SLEW_MAX
            before = self.s_delay
            self.s_delay += step
            if abs(self.s_delay - before) > self.step_max:
                self.step_max = abs(self.s_delay - before)

            self.s_fb_cur += (self.s_fb - self.s_fb_cur) * self.s_fb_glide

            rl = self.read(self.s_line[0], self.s_write, self.s_delay)
            rr = self.read(self.s_line[1], self.s_write, self.s_delay)

            if self.s_xfade_n > 0:
                f = 1.0 - float(self.s_xfade_n) / float(self.s_xfade_len)
                rl = rl * f + self.read(self.s_line[0], self.s_write, self.s_delay_b) * (1.0 - f)
                rr = rr * f + self.read(self.s_line[1], self.s_write, self.s_delay_b) * (1.0 - f)
                self.s_xfade_n -= 1
                self.fade_seen += 1
                self.gain_sum_min = min(self.gain_sum_min, f + (1.0 - f))
                self.gain_sum_max = max(self.gain_sum_max, f + (1.0 - f))

            feed = (l[i] + r[i]) * 0.5
            self.s_line[0][self.s_write] = feed + rr * self.s_fb_cur
            self.s_line[1][self.s_write] = rl * self.s_fb_cur

            l[i] = l[i] * (1.0 - self.s_mix) + rl * self.s_mix
            r[i] = r[i] * (1.0 - self.s_mix) + rr * self.s_mix

            self.s_write += 1
            if self.s_write >= self.s_len:
                self.s_write = 0


def tone(n, start_phase=0.0):
    t = (np.arange(n) + start_phase) / SR
    return np.sin(2.0 * math.pi * TONE_HZ * t)


def peak_hz(segment):
    """The frequency of the loudest partial, refined by parabolic interpolation."""
    win = np.hanning(len(segment))
    spec = np.abs(np.fft.rfft(segment * win))
    k = int(np.argmax(spec[1:]) + 1)
    if 0 < k < len(spec) - 1:
        a, b, c = spec[k - 1], spec[k], spec[k + 1]
        denom = a - 2.0 * b + c
        shift = 0.5 * (a - c) / denom if denom != 0.0 else 0.0
    else:
        shift = 0.0
    return (k + shift) * SR / float(len(segment))


def run(crossfade, time_a, time_b, warm_s, after_s):
    """Settle at time_a, change to time_b, and hand back what came out."""
    d = Delay(crossfade)
    d.set(time_a, 0.0, 1.0)          # fully wet: the output IS the read tap
    d.process(tone(BLOCK), tone(BLOCK))   # the module's own boot call is irrelevant here
    phase = BLOCK

    # Warm up on a tone so the line holds a second of it.
    n_warm = int(warm_s * SR)
    l = tone(n_warm, phase)
    phase += n_warm
    r = l.copy()
    d.process(l, r)
    d.step_max = 0.0
    d.set_jump = 0.0
    d.fade_seen = 0
    d.gain_sum_min = 1.0
    d.gain_sum_max = 1.0

    # The change, and a second of what follows.
    d.set(time_b, 0.0, 1.0)
    n_after = int(after_s * SR)
    l = tone(n_after, phase)
    r = l.copy()
    d.process(l, r)
    return d, l


def main():
    print("delay mode check: mirrors synth_fx_delay.cpp at %d Hz, block %d" % (SR, BLOCK))
    time_a = SR * 0.100        # 100 ms
    time_b = SR * 0.500        # 500 ms
    print("  change: %d -> %d samples (%.0f ms -> %.0f ms), walk distance %d samples"
          % (time_a, time_b, time_a / SR * 1000.0, time_b / SR * 1000.0, time_b - time_a))

    tape, tape_out = run(False, time_a, time_b, 1.0, 1.0)
    xf, xf_out = run(True, time_a, time_b, 1.0, 1.0)

    # 1. TAPE walks, bounded by the ceiling, and the repeats bend.
    walk_samples = int((time_b - time_a) / DELAY_SLEW_MAX)
    print("TAPE")
    check("the pointer never moves faster than the ceiling",
          abs(tape.step_max - DELAY_SLEW_MAX) < 1e-12,
          "largest one-sample move %.6f samples, ceiling %.6f" % (tape.step_max, DELAY_SLEW_MAX))
    check("so the new time is %d samples away, %.0f ms" % (walk_samples,
                                                           walk_samples / SR * 1000.0),
          tape.step_max == DELAY_SLEW_MAX,
          "the walk is (500 - 100) ms / %.2f samples per sample" % DELAY_SLEW_MAX)
    # The window 100..300 ms after the change is inside the walk.
    seg = tape_out[int(0.100 * SR):int(0.300 * SR)]
    f_tape = peak_hz(seg)
    check("the repeats are bent down to half the tone",
          abs(f_tape - TONE_HZ * 0.5) < 6.0,
          "peak %.1f Hz against the tone's %.1f Hz and the half it should be %.1f Hz"
          % (f_tape, TONE_HZ, TONE_HZ * 0.5))

    # 2. XFADE jumps in one sample and fades for 30 ms.
    print("XFADE")
    check("the pointer reaches the new time in one sample",
          abs(xf.s_delay - time_b) == 0.0 and abs(xf.set_jump - (time_b - time_a)) < 1e-9,
          "final position %.1f samples against the %.1f asked for, moved %.0f in one step"
          % (xf.s_delay, time_b, xf.set_jump))
    fade_expected = int(DELAY_XFADE_MS * SR / 1000.0)
    check("the fade runs for the whole 30 ms",
          xf.fade_seen == fade_expected,
          "%d samples faded against the %d a 30 ms fade has" % (xf.fade_seen, fade_expected))
    check("the two taps are weighted to a constant sum",
          abs(xf.gain_sum_min - 1.0) < 1e-12 and abs(xf.gain_sum_max - 1.0) < 1e-12,
          "gain sum over the fade %.12f .. %.12f" % (xf.gain_sum_min, xf.gain_sum_max))

    # 3. XFADE does not bend: the pitch is the tone's, during and after the fade.
    seg = xf_out[int(0.040 * SR):int(0.240 * SR)]
    f_xf = peak_hz(seg)
    check("the repeats keep their pitch after the change",
          abs(f_xf - TONE_HZ) < 6.0,
          "peak %.1f Hz against the tone's %.1f Hz" % (f_xf, TONE_HZ))
    seg = xf_out[0:fade_expected]
    f_mid = peak_hz(seg)
    check("and keep it through the fade as well",
          abs(f_mid - TONE_HZ) < 12.0,
          "peak %.1f Hz over the fade's own %d samples" % (f_mid, fade_expected))

    # 4. Neither mode puts a step in the output that a hard jump would.
    natural = 2.0 * math.pi * TONE_HZ / SR      # the tone's own biggest step
    step_tape = float(np.max(np.abs(np.diff(tape_out[:int(0.05 * SR)]))))
    step_xf = float(np.max(np.abs(np.diff(xf_out[:int(0.05 * SR)]))))
    print("CLICK")
    check("TAPE stays inside the tone's own largest step",
          step_tape < natural * 1.01,
          "largest step %.5f against the tone's %.5f" % (step_tape, natural))
    check("XFADE stays inside it too, fade and all",
          step_xf < natural * 1.01,
          "largest step %.5f against the tone's %.5f" % (step_xf, natural))

    print()
    if FAILURES:
        print("FAILED: %d claims — %s" % (len(FAILURES), "; ".join(FAILURES)))
        return 1
    print("OK: the delay's two time modes behave as documented: TAPE bends the repeats to "
          "%.0f Hz over %.0f ms, XFADE replaces the tap over %d samples and holds %.0f Hz"
          % (f_tape, walk_samples / SR * 1000.0, fade_expected, f_xf))
    return 0


if __name__ == "__main__":
    sys.exit(main())
