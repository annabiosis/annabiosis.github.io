# ---------------------------------------------------------------------------
# The audio path on the desktop: build the bench and run it.
#
# The DSP sources are the firmware's own, compiled unchanged. The platform seam in
# tools/host/shim replaces ESP-IDF and FreeRTOS, and nothing else is needed — no
# ESP-IDF, no Visual Studio, only Zig: found on PATH, or named by -Zig.
#
# With no -Seconds and no -Blocks the bench runs its default budget: the full parameter
# sweep plus a random soak, so 0 means every boundary value was exercised. The same build
# then runs its boot-fade pass, which renders the first 200 blocks after the arm and
# checks the silence before it, the linear ramp and that no faded block exceeds the block
# the settled instrument makes at the same index.
#
#   pwsh -File tools/host-stress.ps1
#   pwsh -File tools/host-stress.ps1 -Seed 7 -Seconds 120
#   pwsh -File tools/host-stress.ps1 -Blocks 1000000 -Mode random
#   pwsh -File tools/host-stress.ps1 -Profile
#
# Exit code is the bench's: 0 every block finite and the sweep complete, 1 a rescue,
# an incomplete sweep or a bad invocation.
# -Profile builds tools/host/profile.cpp instead, which prices the block part by part
# and prints its report; its exit code is 0 unless it is invoked wrongly.
# ---------------------------------------------------------------------------
[CmdletBinding()]
param(
    [uint32]$Seed = 1,
    [uint64]$Blocks = 0,
    [double]$Seconds = 0,
    [string]$Zig = '',
    [ValidateSet('both', 'sweep', 'random')]
    [string]$Mode = 'both',
    [uint64]$InjectNan = 0,
    [switch]$KeepGoing,
    [switch]$Sanitize,
    [switch]$NoBuild,
    # The profile: the same DSP sources, a different driver. -ProfileBlocks is the
    # measured window in 256-sample blocks, one patch state at a time.
    [switch]$Profile,
    [int]$ProfileBlocks = 400
)

$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $PSScriptRoot
if (-not (Test-Path (Join-Path $root 'components\synth_dsp\src'))) {
    throw "host-stress: $root does not look like the firmware checkout"
}

$hostDir = Join-Path $root 'tools\host'
$benchName = if ($Profile) { 'host-profile' } else { 'host-stress' }
$buildDir = Join-Path $root "build\$benchName"
$exe = Join-Path $buildDir "$benchName.exe"
$driver = if ($Profile) { 'profile.cpp' } else { 'stress.cpp' }

if (-not $NoBuild) {
    if (-not $Zig) {
        $onPath = Get-Command zig -ErrorAction SilentlyContinue
        if ($onPath) {
            $Zig = $onPath.Source
        } else {
            $Zig = 'C:\Users\Blaq\.dsh\toolchains\zig-x86_64-windows-0.14.1\zig.exe'
        }
    }

    if (-not (Test-Path $Zig)) {
        throw "host-stress: compiler not found at $Zig; pass -Zig with the path to zig.exe"
    }

    New-Item -ItemType Directory -Force -Path $buildDir | Out-Null

    # Every audio translation unit in the component, without exception: the point of the
    # bench is that the firmware's own files are what runs. Sorted so the link order is
    # stable from one machine to the next.
    $dspSources = @(Get-ChildItem -Path (Join-Path $root 'components\synth_dsp\src') -Filter '*.cpp' |
                    Sort-Object Name |
                    ForEach-Object { $_.FullName })

    $sources = $dspSources + @(
        (Join-Path $hostDir 'platform.cpp'),
        (Join-Path $hostDir $driver)
    )

    $zigArgs = @(
        'c++',
        '-O2',
        '-std=c++17',
        '-fno-math-errno',
        '-I', (Join-Path $root 'components\synth_dsp\include'),
        '-I', (Join-Path $root 'components\synth_dsp\src'),
        '-I', (Join-Path $root 'components\synth_core\src'),
        '-I', (Join-Path $hostDir 'shim'),
        '-I', $hostDir
    ) + $sources + @('-o', $exe)

    Write-Host "$benchName`: compiling $($dspSources.Count) DSP sources + host seam with zig $( & $Zig version )"
    & $Zig @zigArgs
    if ($LASTEXITCODE -ne 0) {
        Write-Host "$benchName`: compile failed with exit code $LASTEXITCODE" -ForegroundColor Red
        exit $LASTEXITCODE
    }
}

if (-not (Test-Path $exe)) {
    throw "host-stress: $exe was not built"
}

if ($Profile) {
    # The profile has its own window length and seed; the stress arguments do not apply.
    $profileArgs = @('--seed', "$Seed", '--blocks', "$ProfileBlocks")
    & $exe @profileArgs
    exit $LASTEXITCODE
}

$runArgs = @('--seed', "$Seed", '--mode', $Mode)
if ($Blocks -gt 0) {
    $runArgs += @('--blocks', "$Blocks")
} elseif ($PSBoundParameters.ContainsKey('Seconds')) {
    # Only a requested -Seconds is forwarded; otherwise the bench's own default budget
    # applies, and the full sweep is guaranteed without this script knowing its size.
    $runArgs += @('--seconds', "$Seconds")
}
if ($InjectNan -gt 0) { $runArgs += @('--inject-nan', "$InjectNan") }
if ($KeepGoing)       { $runArgs += @('--keep-going') }
if ($Sanitize)        { $runArgs += @('--sanitize') }

& $exe @runArgs
$benchExit = $LASTEXITCODE

# The boot fade is a fixed, short pass with its own controls; a separate process is what
# gives it the clean state it needs, and its exit code is part of the gate's verdict.
& $exe --boot-fade
$bootExit = $LASTEXITCODE

if ($benchExit -ne 0 -or $bootExit -ne 0) {
    exit 1
}
exit 0
