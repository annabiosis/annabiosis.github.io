# Gate: the random draws keep their rules on every single draw.
#
# The draw's arithmetic lives in components/synth_app/src/synth_random_math.h, which the
# firmware and this test both compile — the SAME header, the same constants, a seeded
# generator. A hundred thousand draws are checked against the rules the design promises:
# no muddy patch, no wet overload, the drum always in the scale, never a second or a
# seventh against the drone, the bottom held when the corner takes it away, a pulse on
# the first step of every figure.
#
# The number is not a style opinion. tools/random-model.js argues the design; this gate
# proves the firmware implements it, and tools/host/random.cpp is what it runs.

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
Set-Location $root

$zig = 'C:\Users\Blaq\.dsh\toolchains\zig-x86_64-windows-0.14.1\zig.exe'
if (-not (Test-Path $zig)) {
    # A machine without the pinned toolchain still gets a verdict: the source is checked
    # for the rules it must contain, and the gate says so rather than passing silently.
    $h = Get-Content components/synth_app/src/synth_random_math.h -Raw
    $need = @('rr_cutoff_snapped', 'rr_drum_pitch_hz', 'rr_wet_budget', 'rr_rotation',
              'RR_CHARACTER_COUNT', 'rr_drum_pitch_hz')
    $missing = $need | Where-Object { $h -notmatch [regex]::Escape($_) }
    if ($missing) {
        Write-Host ("ПРОВАЛ: в synth_random_math.h нет " + ($missing -join ', ')) -ForegroundColor Red
        exit 1
    }
    Write-Host 'ок  зиг не найден: проверен только состав правил' -ForegroundColor Yellow
    exit 0
}

$exe = 'build/random-check/random.exe'
New-Item -ItemType Directory -Force -Path (Split-Path -Parent $exe) | Out-Null
& $zig cc -target x86_64-windows-gnu -O2 -o $exe tools/host/random.cpp -lm
if ($LASTEXITCODE -ne 0) {
    Write-Host 'ПРОВАЛ: tools/host/random.cpp не собрался' -ForegroundColor Red
    exit 1
}

# The drive is never drawn: the shaper is a decision about the recording, not the patch.
$firmware = Get-Content components/synth_app/src/synth_app.cpp -Raw
$drawBody = $firmware.Substring($firmware.IndexOf('int synth_app_random_draw('))
$drawBody = $drawBody.Substring(0, $drawBody.IndexOf('#undef RW'))
if ($drawBody -match 'SYNTH_PARAM_DRIVE') {
    Write-Host 'ПРОВАЛ: бросок трогает драйв' -ForegroundColor Red
    exit 1
}
$out = & "./$exe" 100000
$out | ForEach-Object { Write-Host $_ }
if ($LASTEXITCODE -ne 0) {
    Write-Host 'ПРОВАЛ: правила рандомизации не держатся' -ForegroundColor Red
    exit 1
}

Write-Host 'ок  сто тысяч бросков держат все правила' -ForegroundColor Green
exit 0
