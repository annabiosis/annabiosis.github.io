"""
The BODY knob, checked on a port of the voice loop.

This is tools/perc_check.py's idea taken one step further: a one-to-one port of the
per-sample loop of components/synth_dsp/src/synth_perc.cpp as it stands AFTER the
crossfade, so that the claims the knob rests on can be measured rather than argued:

  1. at BODY = 0 the voice is bit-for-bit what it was before the knob existed —
     the tone branch is not executed at all, not executed and multiplied by zero;
  2. at BODY = 1 the output is a tone, and one that follows the falling centre.

The arithmetic is float32 throughout, in the same order as the C, because claim 1
is a claim about bits. One thing does not match the C and is documented where it
lives rather than silently changed: the C's three seed pairs are uint32_t, so voices 1
and 2 WRAP when the multipliers are added, and this port's unmasked sums draw
sequences the firmware never plays. That is worth about 1.8 dB on a six-realization
peak. It is left as it is because the module's own comments quote these six draws, and
because the repair is not the mask but the statistic — a single six-draw maximum of a
noise process is a small-sample number, and the module's peak table was fitted to the
median over 120 realizations. See the note in hit().

THE BEATER AND THE SHAPE OF THE FALL are in the port as well, because this is meant to
be a port of the module and not a snapshot of the voice before them. Both are gated by
the note's own height: at 2.0 octaves above the bottom of PITCH the beater's share is
exactly zero, so every hit from the factory tom upward is bit-for-bit the voice it was,
and the two-stage fall inside the reach is only the same rebuild schedule applied to a
different curve. tools/perc_kick_check.py is where the two are measured in detail,
including the bit-identity above the reach and the worst step the schedule leaves in the
centre; the kick's own rows in this file are simply the same voice those measurements
describe.

What is printed:
  - a calibration line: the port's own peak for the default hit, against the number
    recorded in synth_perc.cpp's comment (0.781), so a wrong port is visible;
  - the level the sine needs to sit at the same RMS as the noise it replaces (this is
    where PERC_TONE_GAIN comes from) and how flat that is across the knobs;
  - the law itself: the noise's share at the top of the travel before the squaring
    (cos, sin) and after it (cos^2, sin^2), as weights and in dB; the plain cosine left
    -24 dB at the top of the travel, which reads as leftover noise on the built-in speaker;
  - the sample-by-sample comparison of the new loop at BODY 0 against a copy of the
    loop with no crossfade in it at all;
  - the purity and the instantaneous frequency of one hit at BODY 1, against the
    centre the filter itself is running at, and against the same sine held fixed;
  - ENV at the top of its travel, five octaves against the three the module had, with
    the peak, the time the centre takes to arrive, and the cost in filter rebuilds per
    128-sample block per voice that the deeper dive asks for.

Run: python tools/perc_body_check.py
"""

import math

import numpy as np

f32 = np.float32

SR = 48000

PERC_DECAY_MIN_MS = f32(20.0)
PERC_DECAY_SPAN = f32(6.2288)
PERC_PITCH_MIN_HZ = f32(35.0)
PERC_PITCH_OCTAVES = f32(7.65)
PERC_Q_MIN = f32(0.7)
PERC_Q_SPAN = f32(4.43)
PERC_ENV_MAX_OCT = f32(5.0)
PERC_ENV_FALL_MAX_MS = f32(150.0)
PERC_ATTACK_MS = f32(1.0)
PERC_TAU_SCALE = f32(0.14476)
PERC_TAIL = f32(1.0e-3)
PERC_COEFF_STEP = f32(0.0072)
PERC_GAIN = f32(64.0)
PERC_PEAK_MIN = f32(0.6686)
PERC_PEAK_SPAN = f32(0.7586)
PERC_PEAK_TARGET = f32(0.7810)
PERC_LIMIT_KNEE = f32(0.85)
PERC_LIMIT_SPAN = f32(1.0) - PERC_LIMIT_KNEE

# The sine's own level: the one constant the knob adds, and the first measurement
# below is where the number comes from. It is PERC_TONE_GAIN in the C. It is deliberately
# twice the 0.3548 that the equal-RMS anchor was measured at: +6.02 dB on the tone, because
# a sine at the noise's own RMS reads quieter at 55-200 Hz.
PERC_TONE_GAIN = f32(0.7079)

# The beater and the shape of the fall, as the C ships them: 1 at the bottom of PITCH and
# 0 at PERC_BEATER_OCT octaves above it, so every hit from the factory tom upward carries
# nothing of either. tools/perc_kick_check.py is where the two are measured in detail; this
# port carries them so that it stays a port of the module and not a snapshot of the voice
# before them.
PERC_BEATER_OCT = f32(2.0)
PERC_CLICK_GAIN = f32(0.05)
PERC_CLICK_MS = f32(3.0)
PERC_FALL_FAST = f32(0.6)

PI = math.pi


def pitch_hz(v):
    return PERC_PITCH_MIN_HZ * f32(2.0 ** (float(v) * float(PERC_PITCH_OCTAVES)))


def decay_ms(v):
    return PERC_DECAY_MIN_MS * f32(2.0 ** (float(v) * float(PERC_DECAY_SPAN)))


def perc_decay_comp(d):
    d = f32(min(1.0, max(0.0, float(d))))
    return PERC_PEAK_TARGET / (PERC_PEAK_MIN + PERC_PEAK_SPAN * d)


def body_clamped(body01):
    return f32(min(1.0, max(0.0, float(body01))))


def weights_old(body01):
    """The law before the squaring: cos(a) and sin(a)."""
    a = body_clamped(body01) * f32(float(PI) * 0.5)
    return f32(math.cos(float(a))), f32(math.sin(float(a)))


def weights_new(body01):
    """The law in the C now: the SQUARE of the same quarter-turn pair, a = body01*PI/2.

    Weight_noise = cos^2(a), weight_tone = sin^2(a). The two sum to 1 and the middle is
    50/50, but the share being given up falls much faster near the far end of the travel:
    at body01 = 0.96 the noise weight is 0.0039, which is -48 dB, where the plain cosine
    left 0.0628, which is -24 dB. That -24 dB is a broadband noise floor on the built-in
    speaker, where the 35 Hz tone it is traded for is inaudible; squaring the cosine takes
    it to -48 dB and gives up tone that is below the speaker's own reach either way.

    The zero position is written down as numbers rather than taken from the libm, exactly
    as the C does it, because BODY = 0 must be the pre-BODY voice bit for bit.
    """
    b = body_clamped(body01)
    if float(b) <= 0.0:
        return f32(1.0), f32(0.0)
    a = b * f32(float(PI) * 0.5)
    sn = f32(math.sin(float(a)))
    cs = f32(math.cos(float(a)))
    return f32(cs * cs), f32(sn * sn)


def db(x):
    x = float(x)
    return 20.0 * math.log10(x) if x > 0.0 else float("-inf")


class Voice:
    def __init__(self, pitch01, reso01, decay01, env01, level01=1.0, velocity01=1.0,
                 body01=0.0, env_max_oct=None, cap_fall=True, seed=None, beater=True):
        self.fc = f32(200.0)
        self.pitch = pitch_hz(pitch01)
        self.q = PERC_Q_MIN * f32(2.0 ** (float(reso01) * float(PERC_Q_SPAN)))
        # The depth at the top of ENV, in octaves. Overridable so that the five-octave
        # module can be measured against the three it had: everything else about the
        # voice, including the 150 ms cap on the fall, is identical either way.
        span = PERC_ENV_MAX_OCT if env_max_oct is None else f32(env_max_oct)
        self.env_oct = f32(env01) * span
        self.vel = f32(velocity01)
        self.level = f32(level01)
        self.gain = PERC_GAIN * f32(math.sqrt(float(self.q / self.pitch))) * perc_decay_comp(decay01)
        self.tone_gain = PERC_TONE_GAIN * perc_decay_comp(decay01)

        # The beater's share of this hit, from the note it was struck at rather than from
        # the knob: 1 at the bottom of PITCH, 0 at PERC_BEATER_OCT octaves above it. The
        # click's gain divides perc_decay_comp() back out, because the table normalises the
        # peak of a noise process and a beater's peak does not grow with the gate.
        oct_ = math.log2(float(self.pitch) / float(PERC_PITCH_MIN_HZ))
        share = f32(0.0) if (not beater or oct_ >= float(PERC_BEATER_OCT)) else \
            f32(1.0 - (max(0.0, oct_) / float(PERC_BEATER_OCT)))
        self.fall_quad = PERC_FALL_FAST * share
        self.fall_lin = f32(1.0) - self.fall_quad
        self.click_gain = PERC_CLICK_GAIN * share / perc_decay_comp(decay01)
        self.click = f32(1.0) if share > f32(0.0) else f32(0.0)
        tau_click = PERC_CLICK_MS * f32(0.001) * f32(SR) * PERC_TAU_SCALE
        self.click_coeff = f32(math.exp(-1.0 / max(float(tau_click), 1.0)))

        tau = decay_ms(decay01) * f32(0.001) * f32(SR) * PERC_TAU_SCALE
        self.amp_coeff = f32(math.exp(-1.0 / max(float(tau), 1.0)))
        tau_fall_max = PERC_ENV_FALL_MAX_MS * f32(0.001) * f32(SR) * PERC_TAU_SCALE
        # cap_fall False is the module BEFORE PERC_ENV_FALL_MAX_MS, where the fall was the
        # gate's own time constant: only used to measure what the cap is worth.
        tau_fall = min(tau, tau_fall_max) if cap_fall else tau
        self.env_coeff = f32(math.exp(-1.0 / max(float(tau_fall), 1.0)))

        # Counting for the cost question: where in the hit each rebuild of the filter's
        # coefficients happened, and how many of them produced the centre the voice was
        # already running at (which is what the clamp does at a high PITCH and a deep
        # ENV: the demanded centre leaves the clamp, so the rebuild changes nothing but
        # the clock). Off until the hit's sample loop starts, so that the strike's own
        # build at the base pitch is not counted as travel.
        self.step_index = 0
        self.rebuilds = []
        self.pinned = 0
        self.counting = False

        # Neither is a value the clamps can produce, so the strike's own build below always
        # runs: the drop in coeffs() compares against both and must not fire on the first.
        self.fc = f32(-1.0)
        self.coeff_q = f32(-1.0)
        self.coeffs(self.pitch)
        self.env = f32(1.0)
        self.env_last = f32(1.0)
        self.coeff_step = (PERC_COEFF_STEP / self.env_oct) if self.env_oct > f32(0.01) else f32(1.0)

        self.attack_left = max(1, int(SR * float(PERC_ATTACK_MS) * 0.001 + 0.5))
        self.attack_step = f32(1.0 / self.attack_left)
        self.amp = f32(0.0)

        self.ic1 = [f32(0.0), f32(0.0)]
        self.ic2 = [f32(0.0), f32(0.0)]
        # The two channels' seeds, voice 0 of synth_perc_init() unless a caller picks
        # another of the three, so a peak can be taken over the six realizations the
        # module's own comment quotes.
        self.seed = [0x9E3779B9, 0xC2B2AE35] if seed is None else [seed[0], seed[1]]

        # The crossfade: the two weights come from the knob position and are computed
        # once per change in synth_perc_set(), never per sample. The law is the SQUARE
        # of the quarter-turn pair — see weights_new() below and the reason there.
        self.w_noise, self.w_tone = weights_new(body01)
        # The tone's carrier, as the rotating pair the C keeps: re and im are the cosine
        # and the sine of its phase, and rot_cos/rot_sin carry it one sample forward.
        # perc_strike() starts it at a zero crossing, which is re = 1, im = 0.
        self.tone_re = f32(1.0)
        self.tone_im = f32(0.0)
        # rot_cos/rot_sin are NOT reset here: they belong to the coefficients, and
        # coeffs() above has just built them for this strike's own centre. The C's
        # perc_strike() sets the carrier's pair and leaves the rotation alone for the
        # same reason — a rotation that does not match the centre in force would make
        # the tone a different note from the band it is crossfaded with.

    def coeffs(self, fc):
        fc = f32(min(max(float(fc), 20.0), SR * 0.45))
        q = f32(max(float(self.q), 0.3))
        if self.counting:
            self.rebuilds.append(self.step_index)
            if fc == self.fc:
                self.pinned += 1
        # The C drops a rebuild that would produce the coefficients already in place, and
        # on the depth the patch uses most of the schedule is of that kind — the demanded
        # centre sits above the clamp for the first two thirds of a dive. Dropped here too,
        # against the same clamped pair, so that the counts read off this port are the ones
        # the firmware pays rather than the ones its schedule asks for.
        if fc == self.fc and q == self.coeff_q:
            return
        g = f32(math.tan(float(PI) * float(fc) / SR))
        k = f32(1.0) / q
        self.k = k
        self.a1 = f32(1.0) / (f32(1.0) + g * (g + k))
        self.a2 = g * self.a1
        self.a3 = g * self.a2
        self.fc = fc
        self.coeff_q = q
        # The carrier's rotation, out of the same tangent: 2*pi*fc/SR is twice the angle g
        # is the tangent of, so cos(2x) and sin(2x) come from g with one division each.
        # Normalised, because it is applied once per sample for the whole hit.
        d = f32(1.0) / (f32(1.0) + g * g)
        rc = (f32(1.0) - g * g) * d
        rs = f32(2.0) * g * d
        m = f32(1.0) / f32(math.sqrt(float(rc * rc + rs * rs)))
        self.rot_cos = rc * m
        self.rot_sin = rs * m

    def noise(self, c):
        x = self.seed[c]
        x ^= (x << 13) & 0xFFFFFFFF
        x ^= x >> 17
        x ^= (x << 5) & 0xFFFFFFFF
        x &= 0xFFFFFFFF
        self.seed[c] = x
        return f32(x >> 8) * f32(1.0 / 8388608.0) - f32(1.0)

    def step(self, crossfade, sweep=True):
        """One sample of the voice. `crossfade` is the whole of the difference between
        this and the pre-BODY loop: when it is False the balance is not computed, the
        tone is not generated, and the noise leaves through exactly the expression it
        did before the knob existed."""
        self.step_index += 1
        if self.attack_left > 0:
            self.attack_left -= 1
            self.amp = min(f32(1.0), self.amp + self.attack_step)
        else:
            self.amp = self.amp * self.amp_coeff

        # The beater's click, held at full while the voice's own attack rises and released
        # after it: that attack already IS the beater's rise. kc is what the band's own tap
        # below is mixed with, so the click rides the same gain the noise does, and it is
        # exactly zero for every hit the beater does not reach.
        kc = f32(0.0)
        if self.click > PERC_TAIL:
            if self.attack_left == 0:
                self.click = self.click * self.click_coeff
            kc = self.click * self.click_gain

        if self.env > PERC_TAIL:
            self.env = self.env * self.env_coeff
            # The fall's shape, then the rebuild: the schedule is kept on the SWEPT value,
            # so the two-stage fall moves when each rebuild happens and not how far the
            # centre may move between two of them. See PERC_FALL_FAST.
            swept = self.env * (self.fall_lin + self.fall_quad * self.env)
            if (self.env_last - swept) > self.coeff_step:
                self.env_last = swept
                self.coeffs(self.pitch * f32(2.0 ** float(self.env_oct * swept)))

        out = [f32(0.0), f32(0.0)]
        for c in (0, 1):
            x = self.noise(c)
            v3 = x - self.ic2[c]
            v1 = self.a1 * self.ic1[c] + self.a2 * v3
            v2 = self.ic2[c] + self.a2 * self.ic1[c] + self.a3 * v3
            self.ic1[c] = f32(2.0) * v1 - self.ic1[c]
            self.ic2[c] = f32(2.0) * v2 - self.ic2[c]
            # The band-pass tap, with the beater mixed into it: the click is part of the
            # noise half of the hit, so the crossfade below weighs it with the noise and it
            # cannot survive BODY = 1. The node is the filter's own high-pass.
            band = self.k * v1
            if kc != f32(0.0):
                out[c] = band + (x - band - v2) * kc
            else:
                out[c] = band

        g = self.amp * self.vel * self.level * self.gain
        gl = out[0] * g
        gr = out[1] * g
        if crossfade and self.w_tone > f32(0.0):
            # The sweep: the carrier is rotated every sample at the centre the filter is
            # running at, so the tone is a glide and not a fixed note. One rotation is
            # four multiplies and two adds — the C stopped calling sin() here, which was
            # the module's second most expensive thing.
            re = self.tone_re * self.rot_cos - self.tone_im * self.rot_sin
            self.tone_im = self.tone_re * self.rot_sin + self.tone_im * self.rot_cos
            self.tone_re = re
            tone = self.tone_im
            gn = g * self.w_noise
            gt = self.amp * self.vel * self.level * self.tone_gain * self.w_tone
            gl = out[0] * gn + tone * gt
            gr = out[1] * gn + tone * gt
        return gl, gr, self.amp, self.fc


def soft_limit(x):
    a = abs(float(x))
    if a <= float(PERC_LIMIT_KNEE):
        return x
    u = f32(a) - PERC_LIMIT_KNEE
    y = PERC_LIMIT_KNEE + PERC_LIMIT_SPAN * u / (PERC_LIMIT_SPAN + u)
    return f32(math.copysign(float(y), float(x)))


def hit(pitch01, reso01, decay01, env01, level01=1.0, body01=0.0, crossfade=True,
        sweep=True, seconds=2.0, env_max_oct=None, cap_fall=True, voice=0, channel=0,
        limit=True, beater=True):
    """One hit of one voice, released at the same -60 dB the C frees it at.

    `voice` picks one of synth_perc_init()'s three fixed seed pairs and `channel` one of
    the two channels, so a peak can be taken over the same six realizations the module's
    own comment quotes. `limit=False` takes the module's limiter out, which is how the
    voice's own level is read. The port models PERC_PEAK_MIN/SPAN/TARGET through
    perc_decay_comp(), and its six realizations for the factory patch peak 1.8 dB ABOVE the
    0.781 the module records for them — the six-draw maximum of a noise process plus the
    unmasked seeds noted below, not the table — so only ratios between two settings of the
    port mean anything at the top of the scale."""
    # A NOTE ON THE SEEDS, left standing rather than fixed. The C writes them as uint32_t
    # arithmetic (synth_perc_init: 0x9E3779B9u + v * 0x85EBCA6Bu), so voices 1 and 2 WRAP:
    # voice 1's first channel starts at 0x24234424, not at the 36-bit 0x124234424 that a
    # Python sum keeps. Without the mask those two voices draw sequences the firmware never
    # plays, which is worth about 1.8 dB on the loudest of six — masked, the factory patch's
    # six peak at 0.663 instead of 0.965, and the all-tone table below moves with them (the
    # hat from +0.25 dB over the knee to +0.61, the high Q from 0.64 dB under it to 2.13
    # over). The mask is NOT applied here because the numbers this file and the module's own
    # comments have quoted for years come from these six draws, and because the honest fix is
    # not the mask alone: a conclusion drawn from ONE six-draw maximum of a noise process is a
    # small-sample statement either way, and the module's peak table itself was fitted to the
    # MEDIAN over 120 realizations. Redoing these tables that way is the real repair; until
    # then this port and tools/perc_kick_check.py use the same convention, so the two agree
    # with each other and with the comments.
    seeds = [(0x9E3779B9 + voice * 0x85EBCA6B, 0xC2B2AE35 + voice * 0x27D4EB2F)]
    v = Voice(pitch01, reso01, decay01, env01, level01, body01=body01,
              env_max_oct=env_max_oct, cap_fall=cap_fall, seed=seeds[0], beater=beater)
    n = int(seconds * SR)
    left = np.zeros(n, dtype=np.float32)
    amp_env = np.zeros(n, dtype=np.float32)
    centres = np.zeros(n, dtype=np.float32)
    count = 0
    v.counting = True
    for i in range(n):
        gl, gr, amp, fc = v.step(crossfade, sweep)
        if v.attack_left == 0 and amp < PERC_TAIL:
            break
        left[i] = gr if channel else gl
        amp_env[i] = amp
        centres[i] = fc
        count = i + 1
    left = left[:count]
    if limit:
        left = np.array([soft_limit(x) for x in left], dtype=np.float32)
    return dict(left=left, amp=amp_env[:count], fc=centres[:count], voiced=v,
                asked_ms=float(decay_ms(decay01)), rebuilds=v.rebuilds,
                pinned=v.pinned)


def rms(a):
    return float(np.sqrt(np.mean(np.square(np.asarray(a, dtype=np.float64)))))


def peak(a):
    return float(np.max(np.abs(np.asarray(a, dtype=np.float64))))


def when_ms(i):
    """A sample index as a time, or a dash when the hit never got there."""
    return "-" if i is None else f"{i * 1000 // SR} ms"


def arrival(fc, body, tol_oct):
    """The first sample AFTER the top of the dive at which the centre is within tol_oct
    of the body it lands on. Not from sample zero: perc_strike() builds its coefficients
    at the base pitch, so the first few samples are the body itself and the schedule's
    first rebuild is what lifts the centre to the top of the dive."""
    fc = np.asarray(fc, dtype=np.float64)
    if len(fc) == 0:
        return None
    top = int(np.argmax(fc))
    for i in range(top, len(fc)):
        if fc[i] > 0.0 and abs(math.log2(fc[i] / body)) < tol_oct:
            return i
    return None


def crossings(w):
    """Sub-sample positions of the positive-going zero crossings."""
    w = np.asarray(w, dtype=np.float64)
    out = []
    for i in range(1, len(w)):
        if w[i - 1] < 0.0 <= w[i]:
            out.append((i - 1) + (-w[i - 1]) / (w[i] - w[i - 1]))
    return out


def period_by_period(x, fc):
    """The tone's own frequency, cycle by cycle: one number per period rather than
    per analysis window, so a 35 Hz kick is as readable as a 7 kHz hat."""
    t = crossings(x)
    rows = []
    for a, b in zip(t, t[1:]):
        if b - a < 1.0:
            continue
        i = int(a)
        rows.append((i, SR / (b - a), float(np.mean(fc[i:int(b) + 1]))))
    return rows


CASES = [
    ("default tom  0.34/0.35/0.35/0.27", 0.3415, 0.35, 0.35, 0.27),
    ("kick         0.00/0.35/0.80/0.20", 0.00, 0.35, 0.80, 0.20),
    ("hat          1.00/0.35/0.05/0.00", 1.00, 0.35, 0.05, 0.00),
    ("low Q        0.34/0.00/0.35/0.27", 0.3415, 0.00, 0.35, 0.27),
    ("high Q       0.34/1.00/0.35/0.27", 0.3415, 1.00, 0.35, 0.27),
    ("long gate    0.34/0.35/1.00/0.27", 0.3415, 0.35, 1.00, 0.27),
    ("short gate   0.34/0.35/0.00/0.27", 0.3415, 0.35, 0.00, 0.27),
]

# The factory patch is PITCH 0.3415 with ENV 0.27, and both are synth_app.cpp's defaults.
# The PITCH value is log2(214/35)/7.65, which puts the same 214 Hz on the tom now that the
# bottom of the knob is 35 Hz instead of 55; the ENV value is 0.45 * 3 / 5, which dives the
# same 1.35 octaves now that the top of the knob is five octaves deep instead of three. The
# labels above round the pitch to 0.34 to keep their columns square; the values do not.
#
# The depth and the cost are judged at the top of the ENV knob, where the dive is the
# longest and the coefficients are rebuilt the most often, plus the three corners that
# bracket it: the highest pitch (where the clamp pins the centre), the longest gate (where
# PERC_ENV_FALL_MAX_MS caps the fall), the default patch and a depth of zero.
DIVE = [
    ("default tom ENV 1", 0.3415, 0.35, 0.35, 1.00),
    ("kick        ENV 1", 0.00, 0.35, 0.80, 1.00),
    ("max pitch   ENV 1", 1.00, 0.35, 0.35, 1.00),
    ("long gate   ENV 1", 0.3415, 0.35, 1.00, 1.00),
    ("click       ENV 1", 0.3415, 0.35, 0.00, 1.00),
    ("default tom ENV .27", 0.3415, 0.35, 0.35, 0.27),
    ("hat         ENV 0", 1.00, 0.35, 0.05, 0.00),
]

# The module before these changes and after them, as the factory patch is actually
# configured in each: the floor, the span, the ENV depth, the PITCH value the factory draws
# and the ENV value it draws. Both of the last two moved with the knobs and both were chosen
# so that the hit did not: 0.3415 puts the note back on 214 Hz, 0.27 puts the dive back on
# 1.35 octaves, so the rows differ in the reach of the knobs and nothing else.
BEFORE = (55.0, 7.0, 3.0, 0.28, 0.45)
AFTER = (float(PERC_PITCH_MIN_HZ), float(PERC_PITCH_OCTAVES), float(PERC_ENV_MAX_OCT), 0.3415, 0.27)

print("== calibration: is this port the C? ==")
cal = hit(0.3415, 0.35, 0.35, 0.27, body01=0.0)
print(f"   default tom, one voice, one channel: peak {peak(cal['left']):.3f}, "
      f"rms {rms(cal['left']):.4f}, {len(cal['left'])} samples "
      f"({len(cal['left']) / SR * 1000.0:.0f} ms, asked {cal['asked_ms']:.0f} ms)")
print("   synth_perc.cpp's own comment records 0.781 for this hit, the largest of six")
print("   realizations (three voice seeds, both channels) — measured before the floor moved,")
print("   and, as the peak table below says, that table was fitted to the MEDIAN over 120 draws.")
print("   This port's own six peak at 0.965, 1.8 dB above the recorded figure: part of that is")
print("   a six-draw maximum of a noise process, and part is the seed wrap documented in hit()")
print("   — masked to the C's uint32_t the same six come to 0.663. So read a peak column here")
print("   as a ratio between two settings and not as the level the module sends; the section on")
print("   the ENV depth is where that ratio is used, and says so.")

print()
print("== the sine's own level ==")
print("the noise path is scaled by PERC_GAIN * sqrt(Q/fc) so that a band of width")
print("fc/Q carries the same power at every PITCH and RES; a sine needs the same")
print("service by hand, or BODY would be a loudness control as well as a balance one.")


def tone_ratio(pitch01, decay01, env01, preset=None, reso01=0.35):
    """The gain the sine needs to carry the same RMS as the noise for one patch — the number
    PERC_TONE_GAIN has to be for BODY to be a balance control and not a level one. `preset`
    forces the floor, the span and the ENV depth to another set of values, which is how the
    constant the C ships is reproduced on the module as it was before these changes."""
    global PERC_PITCH_MIN_HZ, PERC_PITCH_OCTAVES, PERC_ENV_MAX_OCT
    keep = (PERC_PITCH_MIN_HZ, PERC_PITCH_OCTAVES, PERC_ENV_MAX_OCT)
    if preset is not None:
        PERC_PITCH_MIN_HZ = f32(preset[0])
        PERC_PITCH_OCTAVES = f32(preset[1])
        PERC_ENV_MAX_OCT = f32(preset[2])
    try:
        noise = hit(pitch01, reso01, decay01, env01, body01=0.0)
        v = Voice(pitch01, reso01, decay01, env01, body01=1.0)
        v.tone_gain = perc_decay_comp(decay01)    # the sine at unit level
        n = len(noise["left"])
        acc = 0.0
        for i in range(n):
            _, _, amp, _ = v.step(True)
            # The carrier's own sine, which step() has just rotated into tone_im: the C
            # reads it from there now instead of evaluating sin() from a phase.
            s = float(amp) * float(v.tone_im)
            acc += s * s
        unit = math.sqrt(acc / n)
        return (rms(noise["left"]) / unit if unit > 0 else 0.0, rms(noise["left"]), unit,
                peak(noise["left"]))
    finally:
        PERC_PITCH_MIN_HZ, PERC_PITCH_OCTAVES, PERC_ENV_MAX_OCT = keep


print()
print("   patch                          noise rms   unit-tone   needed    noise peak")
needed = []
for name, p, r, d, e in CASES:
    factor, noise_rms, unit, noise_peak = tone_ratio(p, d, e, reso01=r)
    needed.append(factor)
    print(f"   {name}   {noise_rms:9.4f}   {unit:9.4f}   {factor:7.3f}   {noise_peak:10.3f}")

# The same factor on the module as it was, which is where the shipped constant came from.
old_factor = tone_ratio(BEFORE[3], 0.35, BEFORE[4], BEFORE)[0]
default_factor = needed[0]
print()
print(f"What the two halves actually measure with the gain the C ships, PERC_TONE_GAIN = "
      f"{float(PERC_TONE_GAIN):.4f}:")
print("   patch                          needed   tone/noise   tone dB   tone peak")
for name, p, r, d, e in CASES:
    factor, noise_rms, unit, noise_peak = tone_ratio(p, d, e, reso01=r)
    tone = rms(hit(p, r, d, e, body01=1.0)["left"])
    ratio = tone / noise_rms
    print(f"   {name}   {factor:7.3f}   {ratio:10.3f}   {db(ratio):+7.2f}   "
          f"{peak(hit(p, r, d, e, body01=1.0)['left']):9.3f}")
print()
print(f"The C ships {float(PERC_TONE_GAIN):.4f}, which is deliberately ABOVE the factor every")
print("corner above needs: it is twice the 0.3548 that was the equal-RMS anchor, +6.02 dB on the")
print("sine, deliberately. The reason is in the low notes rather than in the meter: at")
print("55-200 Hz the ear is less sensitive, so a sine sitting at the noise's measured RMS reads")
print("quieter than the noise it is balanced against.")
print()
print(f"The anchor is still real — it measures {default_factor:.4f} on the factory tom — and it is")
print("now history instead of the shipped value. The column above is what the shipped gain leaves:")
print(f"the factory tom's tone comes out {db(0.7079 / default_factor * 0.8361):+.2f} dB against the noise, where the")
print("anchor had it -1.56 dB. That -1.56 dB is older than BODY: perc_decay_comp() lands on")
print("body_gain as well as on the noise's own gain, and at DECAY 0.35 it is 0.8361, so the anchor")
print("itself measured 0.836 of the noise rather than 1.0; 0.4245 would remove that at DECAY 0.35.")
print()
print("What it costs is a peak and only a peak: a sine's crest factor is 1.41 against about 11 for")
print("a resonant noise burst, so even 6 dB louder the tone's own peak stays under the noise's.")
print("The mixture in the middle of the knob is where the peak can grow, and the sweep on the")
print("factory patch below says by how much and how far into the knee it goes:")
for name, p, r, d, e in CASES:
    noise = hit(p, r, d, e, body01=0.0)
    tone = hit(p, r, d, e, body01=1.0)
    print(f"   {name}   noise peak {peak(noise['left']):6.3f}   tone peak "
          f"{peak(tone['left']):6.3f}   noise rms {rms(noise['left']):.4f}")
print("a sine has a crest factor of 1.41 and a resonant noise burst about 11, so the tone's own")
print("peak stays under the limiter's 0.85 knee even 6 dB above the noise's RMS.")

print()
print("== BODY = 0 against the loop with no crossfade in it ==")
for name, p, r, d, e in CASES:
    new = hit(p, r, d, e, body01=0.0, crossfade=True)["left"]
    old = hit(p, r, d, e, body01=0.0, crossfade=False)["left"]
    same = (len(new) == len(old)) and (new.tobytes() == old.tobytes())
    first = -1
    for i in range(min(len(new), len(old))):
        if new[i].tobytes() != old[i].tobytes():
            first = i
            break
    print(f"   {name}   {len(new):6d} samples   bit-identical: {same}"
          + ("" if same else f"   first difference at {first}"))

print()
print("== BODY = 1 is a tone: how much of each window's energy is in one bin ==")
print("(a noise burst spreads it, a swept sine keeps nearly all of it)")
print("   patch                          BODY=1 concentration   BODY=0 concentration")
for name, p, r, d, e in CASES:
    line = f"   {name}   "
    for body in (1.0, 0.0):
        x = hit(p, r, d, e, body01=body)["left"].astype(np.float64)
        conc = []
        for s in range(0, max(1, len(x) - 512), 512):
            w = x[s:s + 512]
            if rms(w) < 1e-4:
                continue
            spec = np.abs(np.fft.rfft(w * np.hanning(len(w)))) ** 2
            k = int(np.argmax(spec))
            conc.append(spec[max(0, k - 2):k + 3].sum() / spec.sum())
        line += f"{min(conc):.3f}..{max(conc):.3f}     "
    print(line)

print()
print("== BODY = 1 follows the centre: the tone's own frequency, period by period ==")
print("(the filter's centre is the mean of the centre in force over that one period)")
for name, p, r, d, e in CASES[:2] + [CASES[5]]:
    out = hit(p, r, d, e, body01=1.0)
    x = out["left"].astype(np.float64)
    fc = out["fc"].astype(np.float64)
    rows = period_by_period(x, fc)
    print(f"   {name}: centre {float(out['voiced'].pitch):.0f} Hz at the strike, "
          f"falling {float(out['voiced'].env_oct):.2f} octaves, gate {out['asked_ms']:.0f} ms")
    print("       time        tone        filter centre    tone/centre (cents)")
    step = max(1, len(rows) // 10)
    for i, (s, f, c) in enumerate(rows):
        if i % step and i != len(rows) - 1:
            continue
        cents = 1200.0 * math.log2(f / c) if c > 0 else 0.0
        print(f"   {s * 1000 // SR:6d} ms  {f:9.1f} Hz  {c:13.1f} Hz  {cents:+18.1f}")
    print()

print("== and the same sine with its centre held at the struck note ==")
print("(this is what BODY must NOT be: a fixed tone under a falling band)")
for name, p, r, d, e in CASES[:1]:
    out = hit(p, r, d, e, body01=1.0, sweep=False)
    x = out["left"].astype(np.float64)
    rows = period_by_period(x, out["fc"].astype(np.float64))
    print("       time        tone        the note it was struck at")
    step = max(1, len(rows) // 10)
    for i, (s, f, c) in enumerate(rows):
        if i % step and i != len(rows) - 1:
            continue
        print(f"   {s * 1000 // SR:6d} ms  {f:9.1f} Hz  "
              f"{float(out['voiced'].pitch):13.1f} Hz")

print()
print("== the law itself: the noise's share at the top of the travel ==")
print("(the weight as a gain, and the same weight in dB — the -24 dB at 96 percent")
print(" was 20*log10 of the plain cosine, and squaring takes it to -48)")
print("   body01   before cos(a)      dB    after cos^2(a)      dB   tone dB before/after")
for b in (0.0, 0.5, 0.9, 0.96, 0.99, 1.0):
    wn_o, wt_o = weights_old(b)
    wn_n, wt_n = weights_new(b)
    print(f"   {b:5.2f}   {float(wn_o):10.6f} {db(wn_o):8.2f}   {float(wn_n):11.6f} {db(wn_n):8.2f}"
          f"   {db(wt_o):7.2f} /{db(wt_n):8.2f}")
s06 = float(weights_new(0.96)[0]) + float(weights_new(0.96)[1])
print(f"   the two weights sum to {s06:.6f} at 0.96 and to "
      f"{float(weights_new(0.5)[0]) + float(weights_new(0.5)[1]):.6f} at the middle.")
print("   That sum of 1 is the whole gain of the law: the middle stays 50/50, and each")
print("   half is -6 dB there, so the mixture's power is -3 dB against either end. The")
print("   plain cosine had no such dip, and its -24 dB of noise at the top instead.")
print("   At the bottom the weights are the exact 1 and 0 the C writes down; the tone")
print("   weight is zero there, so the tone is not generated at all.")

print()
print("== ENV depth: five octaves against the three it had ==")
print("(ENV 1 unless named otherwise, one voice, one channel. The recorded centre is the")
print(" filter's own, so the first samples are the strike's base pitch: perc_strike()")
print(" builds there, and the schedule's first rebuild — four samples in at three")
print(" octaves, three at five — is what lifts the centre to the top of the dive.)")
print("   patch                   oct   body Hz    top Hz   peak   down to 1/3   down to semitone")
for name, p, r, d, e in DIVE:
    for octaves in (3.0, 5.0):
        out = hit(p, r, d, e, env_max_oct=octaves)
        body = float(out["voiced"].pitch)
        fc = out["fc"].astype(np.float64)
        print(f"   {name:<21}   {octaves:.1f}   {body:7.1f}   {float(fc.max()):8.1f}   "
              f"{peak(out['left']):5.3f}   {when_ms(arrival(fc, body, 1.0 / 3.0)):>11s}   "
              f"{when_ms(arrival(fc, body, 1.0 / 12.0)):>14s}")
print("   The body is the same number at either depth — the dive lands on the pitch the")
print("   knob asked for, ENV decides only how far above it the hit starts — and the top")
print("   is the same too wherever the clamp is in force (the max pitch row is pinned at")
print("   0.45 of the sample rate at both depths). The deeper dive starts two octaves")
print("   higher, so it is still later coming down; that is the whole of the change.")

print()
print("== ENV = 0: the same hit at either depth ==")
for name, p, r, d, e in DIVE:
    if e != 0.0:
        continue
    a = hit(p, r, d, e, env_max_oct=3.0)
    b = hit(p, r, d, e, env_max_oct=5.0)
    same = len(a["left"]) == len(b["left"]) and a["left"].tobytes() == b["left"].tobytes()
    print(f"   {name}: bit-identical {same}, rebuilds {len(a['rebuilds'])} vs "
          f"{len(b['rebuilds'])}, peak {peak(a['left']):.3f} vs {peak(b['left']):.3f}")
print("   A depth of zero makes the rebuild threshold 1.0, a difference the envelope can")
print("   never exceed, so the centre is built once at the strike and never touched again.")

print()
print("== what the deeper dive costs in coefficient rebuilds ==")
print("(128-sample blocks, per voice, over the whole hit; pinned = rebuilds the clamp")
print(" made a no-op, which is what happens once the demanded centre leaves 0.45*SR)")
print("   patch                   oct   total   worst block   mean/block   pinned")
for name, p, r, d, e in DIVE:
    for octaves in (3.0, 5.0):
        out = hit(p, r, d, e, env_max_oct=octaves)
        blocks = {}
        for i in out["rebuilds"]:
            blocks[i // 128] = blocks.get(i // 128, 0) + 1
        total = len(out["rebuilds"])
        worst = max(blocks.values()) if blocks else 0
        nblocks = max(1, (len(out["left"]) + 127) // 128)
        print(f"   {name:<21}   {octaves:.1f}   {total:6d}   {worst:11d}   "
              f"{total / nblocks:10.1f}   {out['pinned']:6d}")
print("   A rebuild can happen at most once per sample, so 128 in a block is the ceiling")
print("   and the shortest-gate corners are near it: the coefficient work is bounded by")
print("   the per-sample case that PERC_COEFF_STEP was added to bound, not by the depth.")
print("   Three voices diving at once is three times the worst block, against the")
print("   2666 us frame budget the module's own comment was measured with.")

print()
print("   and what the 150 ms cap itself is worth, at the corner it was added for")
print("   (ENV 1 with a 1.5 s gate, where the fall would otherwise last the whole gate):")
for octaves in (3.0, 5.0):
    for cap in (True, False):
        out = hit(0.28, 0.35, 1.00, 1.00, env_max_oct=octaves, cap_fall=cap)
        blocks = {}
        for i in out["rebuilds"]:
            blocks[i // 128] = blocks.get(i // 128, 0) + 1
        print(f"      {octaves:.1f} oct, cap {'on ' if cap else 'off'}: {len(out['rebuilds']):5d} rebuilds over "
              f"the hit, worst block {max(blocks.values()) if blocks else 0:3d}")


def factory_hit(preset, env01=None, **kw):
    """One hit of the factory patch with the floor, the span, the ENV depth, the PITCH
    default and the ENV default forced to another set of values — the module as it was
    before these changes — so that the two can be compared. `env01` overrides the preset's
    own ENV default, which is how the top of the knob is compared across the two."""
    global PERC_PITCH_MIN_HZ, PERC_PITCH_OCTAVES, PERC_ENV_MAX_OCT
    keep = (PERC_PITCH_MIN_HZ, PERC_PITCH_OCTAVES, PERC_ENV_MAX_OCT)
    PERC_PITCH_MIN_HZ = f32(preset[0])
    PERC_PITCH_OCTAVES = f32(preset[1])
    PERC_ENV_MAX_OCT = f32(preset[2])
    try:
        return hit(preset[3], 0.35, 0.35, preset[4] if env01 is None else f32(env01), **kw)
    finally:
        PERC_PITCH_MIN_HZ, PERC_PITCH_OCTAVES, PERC_ENV_MAX_OCT = keep


print()
print("== the factory patch's own level, before and after the knobs grew ==")
print("(the six realizations of the module's knee comment, with this module's limiter taken")
print(" out: 0.781 is the peak the module itself records for the old patch, and the knee is")
print(" 0.85. This port's six sit 1.8 dB above that recorded figure — the six-draw maximum of")
print(" a noise process and the seed wrap documented in hit() — so only the rise and the")
print(" scaled column mean anything at the top of the scale.)")
print("   what            constants   six-realization peak     rise     0.781, scaled")
for label, base, env01 in (("factory patch", 0.781, None), ("top of ENV   ", None, 1.0)):
    # 0.781 is the module's own peak for the FACTORY patch, so the scaled column is only
    # meaningful on that row: at ENV 1 the base level was never recorded.
    previous = None
    for tag, preset in (("old", BEFORE), ("new", AFTER)):
        best = max(peak(factory_hit(preset, env01=env01, voice=v, channel=c, limit=False)["left"])
                   for v in range(3) for c in (0, 1))
        if base is None:
            cell = "-"
        elif previous is None:
            cell = f"{base:14.3f}"
        else:
            cell = f"{base * best / previous:14.3f}"
        if previous is None:
            previous = best
            print(f"   {label}    {tag}       {best:16.3f}        -      {cell}")
        else:
            print(f"   {label}    {tag}       {best:16.3f}   {db(best / previous):+6.2f} dB   {cell}")
print("   The factory ENV moved from 0.45 to 0.27 with the top of the knob, from three")
print("   octaves to five, so both rows dive the same 1.35 octaves and the aim of both was")
print("   that the factory hit would not change at all. Read the scaled column: it lands the")
print("   loudest of the six where the module's own comment put it, and the factory patch is")
print("   back under the knee. At the top of the knob (ENV 1, five octaves) the dive is a")
print("   level control as well as a shape one — an owned question, and neither")
print("   PERC_LIMIT_KNEE, PERC_PEAK_TARGET nor PERC_GAIN has been touched.")

print()
print("== what BODY does to the peak on the factory patch ==")
print("(six realizations, one channel at a time, with the shipped tone gain. 'pre' is the peak")
print(" with the module's limiter out, 'scaled' refers that to the module's own recorded 0.781")
print(" for the BODY 0 factory hit, 'knee' is where that scaled peak stands against 0.85, and")
print(" 'limited' is the same hit with the limiter in — what the module would actually send.)")
print("   BODY   tone/noise   pre   scaled   knee               limited")
rows = []
for b in (0.0, 0.25, 0.5, 0.75, 0.9, 0.96, 1.0):
    pre = max(peak(factory_hit(AFTER, body01=b, voice=v, channel=c, limit=False)["left"])
              for v in range(3) for c in (0, 1))
    lim = max(peak(factory_hit(AFTER, body01=b, voice=v, channel=c)["left"])
              for v in range(3) for c in (0, 1))
    nozzle = rms(factory_hit(AFTER, body01=0.0, voice=0, channel=0, limit=False)["left"])
    torse = rms(factory_hit(AFTER, body01=1.0, voice=0, channel=0, limit=False)["left"])
    rows.append((b, pre, lim, torse / nozzle))

# BODY's weights sum to one, so the two ends of the sweep are each half alone: the ratio of
# their RMS is the balance the knob presents, and the middle is where they add coherently.
base = rows[0][1]
for b, pre, lim, ratio in rows:
    scaled = 0.781 * pre / base
    if scaled > PERC_LIMIT_KNEE:
        knee = f"{db(scaled / PERC_LIMIT_KNEE):+.2f} dB over"
    else:
        knee = f"{db(PERC_LIMIT_KNEE / scaled):.2f} dB under"
    print(f"   {b:4.2f}   {db(ratio):+7.2f} dB   {pre:5.3f}   {scaled:6.3f}   {knee:15s}  {lim:6.3f}")
print("   The noise's own peak is what reaches the knee (0.781 of 0.85 at BODY 0); the sine's")
print("   peak is far lower, and the mixture in the middle of the knob is the loudest thing the")
print("   knob can make. Nothing here is normalised by the module's PERC_PEAK table, so read the")
print("   pre-limiter column as a ratio to the BODY 0 number, as the level section says.")

print()
print("== the tone alone at BODY 1, corner by corner ==")
print("(the module normalises a hit so that its noise peak lands at PERC_PEAK_TARGET, 0.781. The")
print(" sine is deterministic, so its realizations are one number, while the noise has a loud")
print(" tail: 'tone at BODY 1' is 0.781 times the tone's peak over the corner's own loudest of")
print(" six noise peaks, and the last column is where that stands against the 0.85 knee.)")
print("   patch                          tone peak   noise peak   tone at BODY 1   knee")
for name, p, r, d, e in CASES:
    six = max(peak(hit(p, r, d, e, body01=0.0, voice=v, channel=c, limit=False)["left"])
              for v in range(3) for c in (0, 1))
    tone = peak(hit(p, r, d, e, body01=1.0, limit=False)["left"])
    scaled = 0.781 * tone / six
    if scaled > PERC_LIMIT_KNEE:
        knee = f"{db(scaled / PERC_LIMIT_KNEE):+.2f} dB over"
    else:
        knee = f"{db(PERC_LIMIT_KNEE / scaled):.2f} dB under"
    print(f"   {name}   {tone:9.3f}   {six:10.3f}   {scaled:14.3f}   {knee}")
print("   The only corner whose tone alone reaches the knee is the hat, by 0.25 dB; the sine's")
print("   crest factor keeps the other six well under it even 6 dB up. On the hat, the high Q and")
print("   the short gate the tone is the louder peak of the two, so there the limiter meets the")
print("   tone first and takes a little of the 6 dB back — which is what a limiter is for, and the")
print("   price of the level rather than a fault in it. THE KICK LEFT THAT LIST when the beater")
print("   arrived: its noise peak is 0.876 against a tone of 0.420, so it stands 7.18 dB under the")
print("   knee at BODY 1 where it used to stand 2.72 dB under it — the beater is part of the noise")
print("   half, so it is weighed by the noise's own share and BODY = 1 is as much a tone as ever.")
