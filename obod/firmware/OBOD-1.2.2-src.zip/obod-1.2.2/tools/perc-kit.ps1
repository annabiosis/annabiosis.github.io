# ---------------------------------------------------------------------------
# The drum kit audition: build tools/host/perc_kit.cpp and render the WAV files.
#
# The DSP is the firmware's own synth_perc.cpp, compiled unchanged through the same
# platform seam as the stress bench, so what the files contain is the voice the instrument
# has — with the four roles, the clap's bursts and the hat's ring modulation applied by the
# driver, because those are the parts of the redesign that do not exist in the module yet.
#
# Nothing is flashed and nothing is committed: the files are the audition.
#
#   pwsh -File tools/perc-kit.ps1
#   pwsh -File tools/perc-kit.ps1 -Out build/perc-kit
#
# Exit code is the driver's: 0 when every file was written.
# ---------------------------------------------------------------------------
[CmdletBinding()]
param(
    [string]$Out = 'build/perc-kit',
    [string]$Zig = ''
)

$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $PSScriptRoot
$hostDir = Join-Path $root 'tools\host'
$buildDir = Join-Path $root 'build\perc-kit'

if (-not $Zig) {
    $onPath = Get-Command zig -ErrorAction SilentlyContinue
    if ($onPath) {
        $Zig = $onPath.Source
    } else {
        $Zig = 'C:\Users\Blaq\.dsh\toolchains\zig-x86_64-windows-0.14.1\zig.exe'
    }
}

if (-not (Test-Path $Zig)) {
    throw "perc-kit: compiler not found at $Zig; pass -Zig with the path to zig.exe"
}

New-Item -ItemType Directory -Force -Path $buildDir | Out-Null
$outDir = Join-Path $root $Out
New-Item -ItemType Directory -Force -Path $outDir | Out-Null

$dspSources = @(Get-ChildItem -Path (Join-Path $root 'components\synth_dsp\src') -Filter '*.cpp' |
                Sort-Object Name |
                ForEach-Object { $_.FullName })

$sources = $dspSources + @(
    (Join-Path $hostDir 'platform.cpp'),
    (Join-Path $hostDir 'perc_kit.cpp')
)

$exe = Join-Path $buildDir 'perc_kit.exe'
$zigArgs = @(
    'c++',
    '-O2',
    '-std=c++17',
    '-fno-math-errno',
    '-I', (Join-Path $root 'components\synth_dsp\include'),
    '-I', (Join-Path $root 'components\synth_dsp\src'),
    '-I', (Join-Path $root 'components\synth_core\src'),
    '-I', (Join-Path $hostDir 'shim'),
    '-I', $hostDir
) + $sources + @('-o', $exe)

Write-Host "perc-kit: compiling $($dspSources.Count) DSP sources + host seam with zig $( & $Zig version )"
& $Zig @zigArgs
if ($LASTEXITCODE -ne 0) {
    Write-Host "perc-kit: compile failed with exit code $LASTEXITCODE" -ForegroundColor Red
    exit $LASTEXITCODE
}

& $exe $outDir
exit $LASTEXITCODE
