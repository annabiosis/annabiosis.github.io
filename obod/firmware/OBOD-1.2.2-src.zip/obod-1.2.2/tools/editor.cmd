@echo off
rem Двойной щелчок: запускает редактор текстов страниц OBOD.
pwsh -NoProfile -File "%~dp0editor.ps1"
