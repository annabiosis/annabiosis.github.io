#!/usr/bin/env python3
"""Pull the text out of a PDF without a PDF library.

Vendor schematics and manuals usually carry real text objects, so decompressing the
content streams and picking out the Tj/TJ string operands is enough to read net names
and tables. Crude on purpose: it is a lookup tool for documentation, not a renderer.

    python tools/pdftext.py <file.pdf> [<file.pdf> ...]
"""

import re
import sys
import zlib

STRING = re.compile(rb"\((?:\\.|[^()\\])*\)")


def streams(data):
    for m in re.finditer(rb"stream\r?\n", data):
        start = m.end()
        end = data.find(b"endstream", start)
        if end < 0:
            continue
        raw = data[start:end]
        for candidate in (raw, raw.rstrip(b"\r\n")):
            try:
                yield zlib.decompress(candidate)
                break
            except zlib.error:
                continue


def text_of(chunk):
    out = []
    for s in STRING.findall(chunk):
        body = s[1:-1]
        body = body.replace(b"\\(", b"(").replace(b"\\)", b")").replace(b"\\\\", b"\\")
        try:
            out.append(body.decode("utf-8"))
        except UnicodeDecodeError:
            out.append(body.decode("latin-1", "replace"))
    return out


def main():
    # The console here is cp1251, and a schematic carries whatever the vendor's CAD
    # tool put in it; without this the first non-Cyrillic byte kills the run.
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

    for path in sys.argv[1:]:
        data = open(path, "rb").read()
        words = []
        for chunk in streams(data):
            words.extend(text_of(chunk))
        joined = " ".join(words)
        print("===== %s  (%d bytes, %d strings)" % (path, len(data), len(words)))
        print(joined)
        print()


if __name__ == "__main__":
    main()
