"""
The beater's click and the two-stage fall, checked on a port of the voice loop.

This is tools/perc_body_check.py's idea applied to the kick. It is a one-to-one port of the
per-sample loop of components/synth_dsp/src/synth_perc.cpp as it stands AFTER the beater and
the shaped fall, with both of them switchable, so that the claims in the module's own
comments can be measured rather than argued:

  1. what the low corner was missing: a band of noise takes Q/(pi*fc) to ring up, 18 ms at
     35 Hz against 3 ms at the factory tom's 214 Hz, so the low corner's peak sits 5.2 dB
     under the tom's and never reaches the ceiling the peak table is calibrated against;
  2. what the beater is: the filter's own high-pass node, held at full through the voice's
     own 1 ms attack and released over PERC_CLICK_MS, mixed into the band's tap so it rides
     the noise's gain and BODY's noise weight;
  3. that it makes the low corner's peak stop depending on the gate, which is what
     perc_decay_comp() promises at the default pitch and cannot deliver at 35 Hz;
  4. that the typical hit of that corner lands where the peak table aimed it — under
     PERC_PEAK_TARGET and under the limiter's knee — while the loud tail of the noise
     process is what crosses the knee;
  5. that the fall reaches the body inside the 20-50 ms a kick's pitch drop is made of,
     against 56 ms for the plain one-pole, and how long each of the two shapes takes over
     the first octave of the bend;
  6. what the rebuild schedule does when the curve under it changes: the worst step the
     centre actually takes and the count of rebuilds, before and after, corner by corner;
  7. that every hit above the beater's reach is bit-for-bit the hit it was, and that the
     click lives in the noise half of the voice — so BODY = 1 is still a tone and nothing
     else;
  8. how long the click should be, and that its level does not grow with the gate;
  9. the module's own dry sum with three voices overlapping, sent through its limiter, and
     the loudest corner of either knob with and without the beater, so that no sample
     anywhere leaves above full scale.

The arithmetic is float32 throughout, in the same order as the C, because 7 is a claim
about bits. The two halves of the crossfade are the squared quarter-turn pair, exactly as
synth_perc_set() builds them, so the BODY section here is a real test of the click's place
in the voice and not an assumption about it.

Run: python tools/perc_kick_check.py
"""

import math
import statistics

import numpy as np

f32 = np.float32

SR = 48000

PERC_DECAY_MIN_MS = f32(20.0)
PERC_DECAY_SPAN = f32(6.2288)
PERC_PITCH_MIN_HZ = f32(35.0)
PERC_PITCH_OCTAVES = f32(7.65)
PERC_Q_MIN = f32(0.7)
PERC_Q_SPAN = f32(4.43)
PERC_ENV_MAX_OCT = f32(5.0)
PERC_ENV_FALL_MAX_MS = f32(150.0)
PERC_ATTACK_MS = f32(1.0)
PERC_TAU_SCALE = f32(0.14476)
PERC_TAIL = f32(1.0e-3)
PERC_COEFF_STEP = f32(0.0072)
PERC_GAIN = f32(64.0)
PERC_PEAK_MIN = f32(0.6686)
PERC_PEAK_SPAN = f32(0.7586)
PERC_PEAK_TARGET = f32(0.7810)
PERC_TONE_GAIN = f32(0.7079)
PERC_LIMIT_KNEE = f32(0.85)
PERC_LIMIT_SPAN = f32(1.0) - PERC_LIMIT_KNEE

# The beater, as the C ships it.
PERC_BEATER_OCT = f32(2.0)
PERC_CLICK_GAIN = f32(0.05)
PERC_CLICK_MS = f32(3.0)
PERC_FALL_FAST = f32(0.6)

PI = math.pi

# The factory patch: PITCH 0.3415 and ENV 0.27 are synth_app.cpp's defaults.
FACTORY = (0.3415, 0.35, 0.35, 0.27)

# The low corner the beater is for, and the three the port quotes elsewhere.
KICK = (0.00, 0.35, 0.80, 0.20)
CORNERS = [
    ("factory tom", 0.3415, 0.35, 0.35, 0.27),
    ("low corner", 0.00, 0.35, 0.80, 0.20),
    ("kick 0.10", 0.10, 0.35, 0.65, 0.30),
    ("kick ENV 1", 0.00, 0.35, 1.00, 1.00),
    ("click gate", 0.00, 0.35, 0.00, 0.20),
    ("snare", 0.55, 0.35, 0.30, 0.10),
    ("hat", 1.00, 0.35, 0.05, 0.00),
]

BEATERS = [(0x9E3779B9 + v * 0x85EBCA6B, 0xC2B2AE35 + v * 0x27D4EB2F) for v in range(3)]
# Note: the C's seeds are uint32_t, so voices 1 and 2 WRAP when the multipliers are added and
# these sums are wider than that. tools/perc_body_check.py leaves the same mismatch standing,
# with the reason written out at its own seed line: the two ports have to agree, and the
# module's recorded peaks were quoted from these draws. The repair is the statistic (a median
# over many realizations, which is how the module's own peak table was fitted) and not the
# mask alone.


def pitch_hz(v):
    return PERC_PITCH_MIN_HZ * f32(2.0 ** (float(v) * float(PERC_PITCH_OCTAVES)))


def decay_ms(v):
    return PERC_DECAY_MIN_MS * f32(2.0 ** (float(v) * float(PERC_DECAY_SPAN)))


def decay_comp(d):
    d = f32(min(1.0, max(0.0, float(d))))
    return PERC_PEAK_TARGET / (PERC_PEAK_MIN + PERC_PEAK_SPAN * d)


def weights(body01):
    """synth_perc_set(): the SQUARE of the quarter-turn pair, exactly as the C writes it."""
    b = f32(min(1.0, max(0.0, float(body01))))
    if float(b) <= 0.0:
        return f32(1.0), f32(0.0)
    a = b * f32(float(PI) * 0.5)
    sn = f32(math.sin(float(a)))
    cs = f32(math.cos(float(a)))
    return f32(cs * cs), f32(sn * sn)


class Voice:
    def __init__(self, pitch01, reso01, decay01, env01, level01=1.0, velocity01=1.0,
                 body01=0.0, pitch_ratio=1.0, seed=None, beater=True, click_ms=None):
        self.pitch = pitch_hz(pitch01) * f32(pitch_ratio)
        self.q = PERC_Q_MIN * f32(2.0 ** (float(reso01) * float(PERC_Q_SPAN)))
        self.env_oct = f32(env01) * PERC_ENV_MAX_OCT
        self.vel = f32(velocity01)
        self.level = f32(level01)
        comp = decay_comp(decay01)
        self.gain = PERC_GAIN * f32(math.sqrt(float(self.q / self.pitch))) * comp
        self.body_gain = PERC_TONE_GAIN * comp

        oct_ = math.log2(float(self.pitch) / float(PERC_PITCH_MIN_HZ))
        share = f32(0.0) if oct_ >= float(PERC_BEATER_OCT) else \
            f32(1.0 - (max(0.0, oct_) / float(PERC_BEATER_OCT)))
        if not beater:
            share = f32(0.0)
        self.beater = share
        self.fall_quad = PERC_FALL_FAST * share
        self.fall_lin = f32(1.0) - self.fall_quad
        self.click_gain = PERC_CLICK_GAIN * share / comp
        self.click = f32(1.0) if share > f32(0.0) else f32(0.0)
        tau_click = (PERC_CLICK_MS if click_ms is None else f32(click_ms)) \
            * f32(0.001) * f32(SR) * PERC_TAU_SCALE
        self.click_coeff = f32(math.exp(-1.0 / max(float(tau_click), 1.0)))

        tau = decay_ms(decay01) * f32(0.001) * f32(SR) * PERC_TAU_SCALE
        self.amp_coeff = f32(math.exp(-1.0 / max(float(tau), 1.0)))
        tau_fall = min(tau, PERC_ENV_FALL_MAX_MS * f32(0.001) * f32(SR) * PERC_TAU_SCALE)
        self.env_coeff = f32(math.exp(-1.0 / max(float(tau_fall), 1.0)))

        self.coeffs(self.pitch)
        self.env = f32(1.0)
        self.env_last = f32(1.0)
        self.coeff_step = (PERC_COEFF_STEP / self.env_oct) if self.env_oct > f32(0.01) else f32(1.0)

        self.attack_left = max(1, int(SR * float(PERC_ATTACK_MS) * 0.001 + 0.5))
        self.attack_step = f32(1.0 / self.attack_left)
        self.amp = f32(0.0)

        self.ic1 = [f32(0.0), f32(0.0)]
        self.ic2 = [f32(0.0), f32(0.0)]
        self.seed = list(BEATERS[0] if seed is None else seed)

        self.w_noise, self.w_tone = weights(body01)
        self.phase = f32(0.0)

        self.rebuilds = []
        self.centres = [float(self.fc)]
        self.index = 0

    def coeffs(self, fc):
        fc = f32(min(max(float(fc), 20.0), SR * 0.45))
        q = max(self.q, f32(0.3))
        g = f32(math.tan(float(PI) * float(fc) / SR))
        self.k = f32(1.0) / q
        self.a1 = f32(1.0) / (f32(1.0) + g * (g + self.k))
        self.a2 = g * self.a1
        self.a3 = g * self.a2
        self.fc = fc

    def noise(self, c):
        x = self.seed[c]
        x ^= (x << 13) & 0xFFFFFFFF
        x ^= x >> 17
        x ^= (x << 5) & 0xFFFFFFFF
        x &= 0xFFFFFFFF
        self.seed[c] = x
        return f32(x >> 8) * f32(1.0 / 8388608.0) - f32(1.0)

    def step(self):
        self.index += 1
        if self.attack_left > 0:
            self.attack_left -= 1
            self.amp = min(f32(1.0), self.amp + self.attack_step)
        else:
            self.amp = self.amp * self.amp_coeff

        kc = f32(0.0)
        if self.click > PERC_TAIL:
            if self.attack_left == 0:
                self.click = self.click * self.click_coeff
            kc = self.click * self.click_gain

        if self.env > PERC_TAIL:
            self.env = self.env * self.env_coeff
            sweep = self.env * (self.fall_lin + self.fall_quad * self.env)
            if (self.env_last - sweep) > self.coeff_step:
                self.env_last = sweep
                self.coeffs(self.pitch * f32(2.0 ** float(self.env_oct * sweep)))
                self.rebuilds.append(self.index)
                self.centres.append(float(self.fc))

        out = [f32(0.0), f32(0.0)]
        for c in (0, 1):
            x = self.noise(c)
            v3 = x - self.ic2[c]
            v1 = self.a1 * self.ic1[c] + self.a2 * v3
            v2 = self.ic2[c] + self.a2 * self.ic1[c] + self.a3 * v3
            self.ic1[c] = f32(2.0) * v1 - self.ic1[c]
            self.ic2[c] = f32(2.0) * v2 - self.ic2[c]
            band = self.k * v1
            if kc != f32(0.0):
                out[c] = band + (x - band - v2) * kc
            else:
                out[c] = band

        g = self.amp * self.vel * self.level * self.gain
        gl = out[0] * g
        gr = out[1] * g
        if self.w_tone > f32(0.0):
            self.phase = self.phase + self.fc / f32(SR)
            if self.phase >= f32(1.0):
                self.phase = self.phase - f32(1.0)
            tone = f32(math.sin(float(f32(2.0 * PI) * self.phase)))
            gn = g * self.w_noise
            gt = self.amp * self.vel * self.level * self.body_gain * self.w_tone
            gl = out[0] * gn + tone * gt
            gr = out[1] * gn + tone * gt
        return gl, gr, self.amp, self.fc


def soft_limit(x):
    a = abs(float(x))
    if a <= float(PERC_LIMIT_KNEE):
        return x
    u = f32(a) - PERC_LIMIT_KNEE
    y = PERC_LIMIT_KNEE + PERC_LIMIT_SPAN * u / (PERC_LIMIT_SPAN + u)
    return f32(math.copysign(float(y), float(x)))


def hit(pitch01, reso01, decay01, env01, level01=1.0, body01=0.0, seconds=1.6, voice=0,
        channel=0, limit=True, beater=True, pitch_ratio=1.0, click_ms=None):
    """One hit of one voice, freed at the same -60 dB the C frees it at."""
    v = Voice(pitch01, reso01, decay01, env01, level01, body01=body01,
              seed=BEATERS[voice], beater=beater, pitch_ratio=pitch_ratio, click_ms=click_ms)
    n = int(seconds * SR)
    y = np.zeros(n, dtype=np.float32)
    fc = np.zeros(n, dtype=np.float32)
    count = 0
    for i in range(n):
        gl, gr, amp, centre = v.step()
        if v.attack_left == 0 and amp < PERC_TAIL:
            break
        y[i] = gr if channel else gl
        fc[i] = centre
        count = i + 1
    y = y[:count]
    if limit:
        y = np.array([soft_limit(x) for x in y], dtype=np.float32)
    return dict(y=y, fc=fc[:count], v=v)


def peak(a):
    return float(np.max(np.abs(np.asarray(a, dtype=np.float64))))


def rms(a):
    a = np.asarray(a, dtype=np.float64)
    return float(np.sqrt(np.mean(np.square(a)))) if len(a) else 0.0


def six(p, r, d, e, **kw):
    return [peak(hit(p, r, d, e, voice=v, channel=c, **kw)["y"])
            for v in range(3) for c in (0, 1)]


def t90(y):
    """The first sample at 90% of the hit's own peak, in ms."""
    y = np.asarray(y, dtype=np.float64)
    target = 0.9 * peak(y)
    for i in range(len(y)):
        if abs(y[i]) >= target:
            return i * 1000.0 / SR
    return -1.0


def band_rms(y, lo, hi, upto_ms):
    n = min(len(y), int(SR * upto_ms / 1000))
    x = np.asarray(y[:n], dtype=np.float64)
    if n == 0:
        return 0.0
    spec = np.abs(np.fft.rfft(x)) ** 2
    f = np.fft.rfftfreq(n, 1.0 / SR)
    return math.sqrt(spec[(f >= lo) & (f < hi)].sum() / (n ** 2))


def crossing_ms(fc, hz):
    """The first time after the top of the dive that the centre is at or under hz."""
    fc = np.asarray(fc, dtype=np.float64)
    top = int(np.argmax(fc))
    for i in range(top, len(fc)):
        if fc[i] <= hz:
            return i * 1000.0 / SR
    return -1.0


def first_octave_ms(fc):
    """How long the first octave of the dive takes, from the top of it."""
    fc = np.asarray(fc, dtype=np.float64)
    top = int(np.argmax(fc))
    for i in range(top, len(fc)):
        if fc[i] <= fc[top] * 0.5:
            return i * 1000.0 / SR
    return -1.0


def worst_step_cents(centres):
    """The largest step the schedule left in the centre, over a whole hit.

    centres[0] is the base pitch perc_strike() builds at and centres[1] is the first
    rebuild, which is the DIVE'S OWN LIFT to the top of the ENV travel and happens three or
    four samples in — that step is the attack, not the schedule. What the schedule is
    allowed to leave is measured between the rebuilds after it."""
    c = [x for x in centres[1:] if x > 0.0]
    if len(c) < 2:
        return 0.0
    return max(abs(1200.0 * math.log2(c[i] / c[i - 1])) for i in range(1, len(c)))


print("== is this port the C? ==")
cal = hit(*FACTORY)
print(f"   the factory patch, one voice one channel: {len(cal['y'])} samples "
      f"({len(cal['y']) / SR * 1000:.0f} ms, asked {float(decay_ms(FACTORY[2])):.0f} ms), "
      f"peak {peak(cal['y']):.3f}, rms {rms(cal['y']):.4f}")
print(f"   its six realizations peak at {max(six(*FACTORY, limit=False)):.3f} pre-limiter, median "
      f"{statistics.median(six(*FACTORY, limit=False)):.3f}.")
print("   That is the 0.965 tools/perc_body_check.py records for the same hit: the two ports read")
print("   the same seeds in the same order, so they agree to the digit. It is 1.8 dB above the")
print("   0.781 the module's own comment records, which is the six-draw maximum of a noise process")
print("   plus the seed wrap both ports document — so every peak below is read as a ratio to")
print("   PERC_PEAK_TARGET (0.781) and to the knee (0.85) and never as a level.")

print()
print("== what the low corner was missing ==")
print("   (one realization per corner, pre-limiter, plus the crest factor that says why:")
print("    a resonant noise burst's peak grows with the number of ring-up cycles the gate")
print("    gives it, and Q/(pi*fc) is 18 ms at 35 Hz against 3 ms at 214)")
print("   patch            body Hz    rms      peak    crest   ring-up")
for name, p, r, d, e in CORNERS:
    out = hit(p, r, d, e, limit=False, beater=False)
    y = out["y"]
    q = out["v"].q
    fc = float(out["v"].pitch)
    print(f"   {name:15s} {fc:8.1f}  {rms(y):7.4f}  {peak(y):6.3f}  {peak(y)/rms(y):5.2f}  "
          f"{float(q) / (PI * fc) * 1000:6.2f} ms")

print()
print("== the beater's share across PITCH, and the fall shape that rides it ==")
print("   pitch     body Hz    octaves above the floor    beater    fall_lin   fall_quad")
for p in (0.0, 0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.3415, 1.00):
    v = Voice(p, 0.35, 0.35, 0.27)
    oct_ = math.log2(float(pitch_hz(p)) / float(PERC_PITCH_MIN_HZ))
    print(f"   {p:6.4f}  {float(pitch_hz(p)):8.1f}  {oct_:22.2f}    {float(v.beater):6.3f}  "
          f"{float(v.fall_lin):8.4f}  {float(v.fall_quad):9.4f}")
print("   ... so the factory tom (214 Hz, 2.61 octaves) carries exactly 1 and 0, and the whole")
print("   hit above the reach is the voice it was before any of this: see the bit test below.")

print()
print("== the low corner, every realization, before and after the beater ==")
print("   (pre-limiter peak of the six realizations, their median, and where the loudest of")
print("    them stands against PERC_PEAK_TARGET 0.781 and the 0.85 knee)")
print("   variant      " + "".join(f"  v{v}c{c} " for v in range(3) for c in (0, 1)) +
      "   median   max   dB vs target   dB vs knee")
for name, kw in (("no beater", dict(beater=False)), ("beater", dict(beater=True))):
    pk = six(*KICK, limit=False, **kw)
    med = float(np.median(pk))
    print(f"   {name:11s}  " + "".join(f"{x:6.3f} " for x in pk) +
          f"  {med:6.3f} {max(pk):6.3f}   {20 * math.log10(med / 0.781):+8.2f}      "
          f"{20 * math.log10(max(pk) / 0.85):+8.2f}")

print()
print("== and what the beater does to the shape of the hit ==")
print("   patch            variant     peak    rms     t90 ms   5 ms rms  20 ms rms  1-8 kHz/5ms")
for name, p, r, d, e in (CORNERS[1], CORNERS[2]):
    for tag, kw in (("no beater", dict(beater=False)), ("beater", dict(beater=True))):
        out = hit(p, r, d, e, limit=False, **kw)
        y = out["y"]
        n5, n20 = int(SR * 0.005), int(SR * 0.020)
        print(f"   {name:15s}  {tag:10s} {peak(y):6.3f}  {rms(y):6.4f}  {t90(y):7.2f}  "
              f"{rms(y[:n5]):8.4f}  {rms(y[:n20]):9.4f}  {band_rms(y, 1000, 8000, 5.0):10.5f}")
print("   the low corner gains its attack where the band cannot make one, and the hit's own")
print("   rms over the whole gate barely moves: the beater is a transient, not a level.")

print()
print("== how long the click should be ==")
print("   (PERC_CLICK_MS, one realization of the low corner, pre-limiter. A click long")
print("    enough to outlive the attack would smear into the band's own ring-up; the peak")
print("    is set by the click's level and not by its length, so length is a shape question)")
print("   click ms    peak    t90 ms   5 ms rms   20 ms rms   1-8 kHz/5ms")
for ms in (1.0, 2.0, 3.0, 5.0, 8.0):
    out = hit(*KICK, limit=False, click_ms=ms)
    y = out["y"]
    n5, n20 = int(SR * 0.005), int(SR * 0.020)
    print(f"   {ms:8.1f}  {peak(y):6.3f}  {t90(y):7.2f}  {rms(y[:n5]):8.4f}  "
          f"{rms(y[:n20]):9.4f}  {band_rms(y, 1000, 8000, 5.0):10.5f}")

print()
print("== the click does not grow with the gate: perc_decay_comp() divided back out ==")
print("   (the low corner, one realization, pre-limiter, at the three DECAYs above)")
print("   DECAY    gate ms    no beater    beater      ratio dB")
for d in (0.00, 0.80, 1.00):
    a = peak(hit(0.00, 0.35, d, 0.20, limit=False, beater=False)["y"])
    b = peak(hit(0.00, 0.35, d, 0.20, limit=False, beater=True)["y"])
    print(f"   {d:5.2f}  {float(decay_ms(d)):9.1f}  {a:11.3f}  {b:8.3f}  "
          f"{20 * math.log10(b / a):+9.2f}")

print()
print("== the filter falls over the hit: the canon's own window ==")
print("   (PITCH at the floor with ENV 0.50 is a 197 Hz top over a 35 Hz body, which is the")
print("    150-200 Hz to 40-60 Hz a kick's bend is made of; the times are when the centre")
print("    first reaches a frequency, and the first octave is the whole of the fastest part)")
for p, d, e, name in ((0.00, 0.80, 0.50, "canon 197->35"), (0.00, 0.80, 0.20, "shallow 70->35"),
                      (0.00, 0.80, 1.00, "deep 1113->35")):
    for tag, kw in (("no beater", dict(beater=False)), ("beater", dict(beater=True))):
        out = hit(p, 0.35, d, e, limit=False, **kw)
        fc = out["fc"]
        cells = "  ".join(f"{crossing_ms(fc, hz):5.0f}" for hz in (100.0, 60.0, 45.0, 40.0))
        first_oct = first_octave_ms(fc)
        shown = "-" if first_oct < 0.0 else f"{first_oct:.2f}"
        print(f"   {name:15s} {tag:10s} top {float(np.max(fc)):7.1f} Hz   ms to "
              f"100/60/45/40 Hz: {cells}   1st octave {shown:>5} ms   "
              f"peak {peak(out['y']):5.3f}")
    print("                   the canon's window is 20-50 ms: the beater's shaped fall lands")
    print("                   the bend inside it where the plain fall spent 55 ms on the last")
    print("                   of it.")

print()
print("== the rebuild accounting: the same step, the same count ==")
print("   patch            variant      octaves   rebuilds   worst 128-block   bound   worst step")
for name, p, r, d, e in (CORNERS[0], CORNERS[1], CORNERS[4], CORNERS[3]):
    for tag, kw in (("no beater", dict(beater=False)), ("beater", dict(beater=True))):
        out = hit(p, r, d, e, limit=False, **kw)
        v = out["v"]
        blocks = {}
        for i in v.rebuilds:
            blocks[i // 128] = blocks.get(i // 128, 0) + 1
        step_cents = 1200.0 * float(v.env_oct) * float(v.coeff_step)
        print(f"   {name:15s}  {tag:10s} {float(v.env_oct):7.2f}   {len(v.rebuilds):8d}   "
              f"{max(blocks.values()) if blocks else 0:15d}   {step_cents:6.2f}   "
              f"{worst_step_cents(v.centres):7.2f} cents")
print("   The threshold is on the swept value, not on the envelope, so the two-stage fall")
print("   moves WHEN each rebuild happens and never lets the centre move further between two")
print("   of them: the bound is PERC_COEFF_STEP per octave, and the worst step the schedule")
print("   actually leaves is printed beside it. The count moves by a few percent, because a")
print("   rebuild fires when the travel since the last one EXCEEDS the threshold and the")
print("   shaped fall travels further per sample at the top of the dive — where the plain one")
print("   under-shoots it and emits a larger step less often. A rebuild costs one rebuild per")
print("   sample at most, so 128 in a block is the ceiling the shortest gates already reach.")

print()
print("== bit-identity above the beater's reach ==")
print("   (the whole loop, crossfade and all, with the beater and without it)")
for name, p, r, d, e in (("factory tom", 0.3415, 0.35, 0.35, 0.27), ("high tom", 0.30, 0.35, 0.35, 0.50),
                         ("snare", 0.55, 0.35, 0.30, 0.10), ("hat", 1.00, 0.35, 0.05, 0.00)):
    a = hit(p, r, d, e, limit=False, beater=False)["y"]
    b = hit(p, r, d, e, limit=False, beater=True)["y"]
    same = len(a) == len(b) and a.tobytes() == b.tobytes()
    first = next((i for i in range(min(len(a), len(b))) if a[i].tobytes() != b[i].tobytes()), -1)
    print(f"   {name:15s} bit-identical {same}" + ("" if same else f"  first difference at {first}"))

print()
print("== BODY: the click lives in the noise half, so the top of the knob is still a tone ==")
print("   (the click is switched ON for every row; concentration is the share of a 512-sample")
print("    window's energy in its loudest five bins, so a tone is near 1 and noise is not)")
for name, p, r, d, e in (CORNERS[1], CORNERS[0]):
    line = f"   {name:15s} "
    for body in (0.0, 0.5, 1.0):
        y = hit(p, r, d, e, body01=body, beater=True)["y"].astype(np.float64)
        conc = []
        for s in range(0, max(1, len(y) - 512), 512):
            w = y[s:s + 512]
            if rms(w) < 1e-4:
                continue
            spec = np.abs(np.fft.rfft(w * np.hanning(len(w)))) ** 2
            k = int(np.argmax(spec))
            conc.append(spec[max(0, k - 2):k + 3].sum() / spec.sum())
        line += f"BODY {body:.1f}: {min(conc):.3f}..{max(conc):.3f}   "
    print(line)
print("   At BODY = 1 the click is scaled by the noise's own weight, which is cos^2 of the")
print("   quarter turn: of the order of 1e-15, so what is left is a tone and nothing else.")

print()
print("== the module's dry sum: three voices on a sixteenth grid, one channel ==")
print("   (the sum as the module sends it, after its own limiter, and the share of samples")
print("    the limiter rounds on the way)")
step = int(SR * 0.125)
for name, p, d, e in (("low corner", 0.00, 0.80, 0.20), ("long gate", 0.00, 1.00, 0.20)):
    for tag, kw in (("no beater", dict(beater=False)), ("beater", dict(beater=True))):
        n = step * 3 + int(SR * 0.5)
        raw = np.zeros(n, dtype=np.float32)
        for k in range(3):
            y = hit(p, 0.35, d, e, voice=k, channel=0, limit=False, **kw)["y"]
            seg = min(len(y), n - k * step)
            raw[k * step:k * step + seg] += y[:seg]
        sent = np.array([soft_limit(x) for x in raw], dtype=np.float32)
        share = float(np.mean(np.abs(np.asarray(raw, dtype=np.float64)) > float(PERC_LIMIT_KNEE)))
        print(f"   {name:11s} {tag:10s} pre-sum peak {peak(raw):6.3f}   sent peak "
              f"{peak(sent):6.3f}   limiter share {share * 100:5.2f}%   sent rms {rms(sent):.4f}"
              f"   above full scale: {peak(sent) > 1.0}")

print()
print("== the loudest corners of both knobs, sent, beater and all ==")
print("   (the limiter approaches full scale without reaching it, so nothing can be flat")
print("    topped: the check is that no corner reports above full scale, with or without")
print("    the beater, since a corner that only clipped because of the click would be a")
print("    corner the module did not have before)")
print("   patch                     pre-limit   sent no beater   sent beater   above full scale")
for name, p, r, d, e in CORNERS + [("lowest gate", 0.00, 0.35, 0.00, 1.00),
                                   ("canon ENV .5", 0.00, 0.35, 0.80, 0.50),
                                   ("highest pitch", 1.00, 0.35, 0.35, 1.00),
                                   ("high Q", 0.3415, 1.00, 0.35, 1.00)]:
    pre = max(six(p, r, d, e, limit=False, beater=False))
    was = max(six(p, r, d, e, limit=True, beater=False))
    now = max(six(p, r, d, e, limit=True, beater=True))
    print(f"   {name:22s} {pre:9.3f} {was:14.3f} {now:14.3f}   {now > 1.0}")
