<#
.SYNOPSIS
    Reset the board and capture its serial boot log to a file.

.DESCRIPTION
    idf.py monitor needs an interactive console and truncates its log file, so
    it is a poor fit for "show me what the device printed on this boot".
    This script does the one job: reset the chip with esptool, then read the
    console port for a fixed number of seconds and write everything to a file.

    The reset is issued first, and then the port is waited for and opened:
    on this board the console is the ESP32-S3's built-in USB-Serial-JTAG, and
    a reset makes that device re-enumerate on the host. A port opened before
    the reset is therefore closed underneath the reader, which loses exactly
    the lines the capture exists to collect.

    The reader also reopens the port if it drops mid-capture, so a reset or a
    re-enumeration during the read window does not abort the run.

.PARAMETER Port
    Serial port, e.g. COM4.

.PARAMETER Seconds
    How long to read after the reset. Default 20.

.PARAMETER OutFile
    Destination for the captured text. Default build/boot.log.

.PARAMETER NoReset
    Just read; do not reset the board first. Use this to watch a running device.

.PARAMETER Baud
    Console baud rate. Default 115200, which is what sdkconfig.defaults sets.

.EXAMPLE
    pwsh -File tools/capture_boot.ps1 -Port COM4 -Seconds 25

.EXAMPLE
    # Watch the knob live while turning it
    pwsh -File tools/capture_boot.ps1 -Port COM4 -NoReset -Seconds 30
#>
#Requires -Version 5.1

param(
    [Parameter(Mandatory = $true)][string] $Port,
    [int]    $Seconds = 20,
    [string] $OutFile = 'build/boot.log',
    [int]    $Baud    = 115200,
    [switch] $NoReset
)

$ErrorActionPreference = 'Stop'

. (Join-Path $PSScriptRoot '_idf_env.ps1')
$repoRoot = Get-RepoRoot
$idfPath  = Initialize-IdfEnvironment -RepoRoot $repoRoot
if (-not $idfPath) { exit 3 }

if (-not [System.IO.Path]::IsPathRooted($OutFile)) {
    $OutFile = Join-Path $repoRoot $OutFile
}
$outDir = Split-Path -Parent $OutFile
if ($outDir -and -not (Test-Path -LiteralPath $outDir)) {
    New-Item -ItemType Directory -Path $outDir -Force | Out-Null
}

# The console is USB-Serial-JTAG, so the device can vanish from the host for a
# moment around a reset. Wait for it rather than racing it.
function Wait-ForPort {
    param([string] $Name, [int] $TimeoutSec = 15)

    $deadline = (Get-Date).AddSeconds($TimeoutSec)
    while ((Get-Date) -lt $deadline) {
        if ([System.IO.Ports.SerialPort]::GetPortNames() -contains $Name) {
            return $true
        }
        Start-Sleep -Milliseconds 200
    }
    return $false
}

function Open-Console {
    param([string] $Name, [int] $Rate)

    $sp = New-Object System.IO.Ports.SerialPort $Name, $Rate, 'None', 8, 'One'
    $sp.ReadTimeout  = 500
    $sp.WriteTimeout = 500
    # Do not let the host's control lines reset the chip while we read it.
    $sp.DtrEnable = $false
    $sp.RtsEnable = $false
    $sp.Open()
    return $sp
}

$bytes = New-Object System.Collections.Generic.List[byte]

if (-not $NoReset) {
    Write-Host "==> resetting the chip on $Port" -ForegroundColor Cyan

    Push-Location $repoRoot
    try {
        # A watchdog reset leaves the ROM in run mode. A plain hard reset parks
        # this chip in DOWNLOAD(USB/UART0) on the USB-Serial-JTAG, where the
        # application never starts and the capture collects nothing.
        & python -m esptool --chip esp32s3 --port $Port --before default-reset `
            --after watchdog-reset chip-id *> $null
    }
    finally {
        Pop-Location
    }

    # esptool's own error after a watchdog reset is expected here: the device
    # re-enumerates while it still holds the port. Only the reset matters.
    Start-Sleep -Milliseconds 500
}

if (-not (Wait-ForPort -Name $Port -TimeoutSec 15)) {
    Write-Host "ERROR: $Port did not come back after the reset" -ForegroundColor Red
    exit 4
}

Write-Host "==> reading $Port at $Baud for $Seconds s -> $OutFile" -ForegroundColor Cyan

$serial = $null
try { $serial = Open-Console -Name $Port -Rate $Baud }
catch {
    Write-Host "ERROR: could not open ${Port}: $($_.Exception.Message)" -ForegroundColor Red
    exit 4
}

$deadline = (Get-Date).AddSeconds($Seconds)
while ((Get-Date) -lt $deadline) {
    try {
        if (-not $serial.IsOpen) { throw 'closed' }

        $chunk = $serial.ReadExisting()
        if ($chunk.Length -gt 0) {
            foreach ($ch in $chunk.ToCharArray()) { $bytes.Add([byte]$ch) }
            Write-Host -NoNewline $chunk
        }
    }
    catch [System.TimeoutException] {
        # Nothing arrived in the read window; normal between log lines.
    }
    catch {
        # Port went away — wait for it and pick the stream back up.
        try { if ($serial -and $serial.IsOpen) { $serial.Close() } } catch { }
        if (Wait-ForPort -Name $Port -TimeoutSec 10) {
            try { $serial = Open-Console -Name $Port -Rate $Baud } catch { }
        }
    }
    Start-Sleep -Milliseconds 50
}

try { if ($serial -and $serial.IsOpen) { $serial.Close() } } catch { }

# The ROM loader's banner is not UTF-8 (it is raw bytes), so decode leniently
# rather than losing the line that proves the chip restarted.
$text = [System.Text.Encoding]::UTF8.GetString($bytes.ToArray())
Set-Content -LiteralPath $OutFile -Value $text -Encoding UTF8

Write-Host ''
Write-Host "==> captured $($bytes.Count) bytes" -ForegroundColor Cyan
