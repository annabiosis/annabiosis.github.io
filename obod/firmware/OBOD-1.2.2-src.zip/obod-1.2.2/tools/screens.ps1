<#
.SYNOPSIS
    Снять экраны OBOD по кабелю и разложить их в web/assets/screens/.

.DESCRIPTION
    Прибор должен быть прошит сборкой с включённым OBOD_SCREENSHOTS: тогда после запуска
    интерфейса он сам обходит все страницы и отдаёт каждую в порт. Скрипт перезапускает плату
    тем же способом, каким заканчивается прошивка — средствами esptool, — ждёт, пока прибор
    загрузится и заново перечислит встроенный USB-Serial-JTAG, читает поток, раскладывает
    кадры во временные файлы и превращает их в PNG 360x360 через Python с Pillow.

    Перезапуск здесь не украшение. Снятие идёт один раз, через восемь секунд после запуска
    интерфейса, поэтому его надо успеть услышать: открытый до перезапуска порт после
    перечисления становится мёртвым (чтение возвращает «The port is closed»), а переключение
    линий DTR/RTS через .NET до встроенного USB-Serial-JTAG не доходит вовсе — прибор не
    перезапускается, и в порту не появляется ничего.

    Если после перезапуска в порту ничего не появилось, скрипт говорит об этом и просит нажать
    RESET на приборе: тогда снятие работает и с ручной перезагрузкой кнопкой.

    Прочие строки порта печатаются полностью — в них приходит и отчёт самого модуля снятия
    («snapshots done» или причина, по которой он остановился), и строки загрузки.

    Имена файлов берутся из метки экрана в справочнике. Соответствие «номер страницы прошивки
    → метка экрана» считает tools/lib/screens.js по самой прошивке и таблице REF; он же пишет
    web/assets/screens/screens.json, из которого страницы документации берут картинку.

    Один экран снимается дважды, и это делает прошивка: страница EUCLID идёт с включённым
    арпеджиатором, а сразу за ней — второй кадр с выключенным, под именем LEAD EUCLID ARP OFF.
    Состояние ставится только на эти два кадра, и то, что было на приборе, возвращается.

    После страниц в том же потоке идут состояния поверх экрана: шторка, транспорт и два
    состояния макроса. Прошивка открывает их тем же вызовом, каким их открывает жест или долгое
    нажатие на сектор, и в заголовке кадра стоит не номер страницы, а имя состояния — DRAWER,
    TRANSPORT, MACRO, MACRO INV, LEAD EUCLID ARP OFF. Их имена файлов заданы там же, в
    tools/lib/screens.js, и второй выписки имён в проекте нет.

    Ключ -Extra «МЕТКА=файл.png» сохраняет уже снятый кадр ещё раз, под другим именем. Это для
    разовой съёмки: состояние выставляется на приборе ЗАРАНЕЕ, и подпись к снимку даёт тот, кто
    его заказал.

    Порядок работы описан в разделе «Снимки экранов» файла web/README.md.

.EXAMPLE
    pwsh -File tools/screens.ps1
    pwsh -File tools/screens.ps1 -Port COM7
    pwsh -File tools/screens.ps1 -Python C:\Python310\python.exe
    pwsh -File tools/screens.ps1 -Extra 'DRONE=drone-flat.png'
#>
#Requires -Version 5.1
param(
    [string]   $Port = 'COM4',
    [string]   $Python = '',
    [int]      $TimeoutSec = 90,
    [string[]] $Extra = @()
)

$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.Encoding]::UTF8

$Root    = Split-Path -Parent $PSScriptRoot
$OutDir  = Join-Path $Root 'web\assets\screens'
$JobsDir = Join-Path ([IO.Path]::GetTempPath()) 'obod-screens'

# Точка в кадре: два байта. Числа те же, что называет прибор в заголовке, и проверяются они
# здесь, а не принимаются на веру — у снимка, снятого не тем экраном, размер бы не сошёлся.
$WantWidth  = 360
$WantHeight = 360

# Сколько ждать строк загрузки, прежде чем предложить нажать RESET, и сколько ждать, пока
# устройство вернётся в список портов после перезапуска.
$BootWaitSec = 15
$PortBackSec = 12

function Get-Python {
    param([string] $Given)

    $candidates = @()
    if ($Given) { $candidates += $Given }
    elseif ($env:OBOD_PYTHON) { $candidates += $env:OBOD_PYTHON }
    $candidates += 'python'

    foreach ($candidate in $candidates) {
        try {
            & $candidate -c 'import PIL' 2>&1 | Out-Null
            if ($LASTEXITCODE -eq 0) { return $candidate }
        }
        catch { }
    }

    throw 'не найден Python с Pillow; укажите его ключом -Python <путь к python.exe>'
}

# Сброс прибора средствами esptool — тем же способом, каким заканчивается прошивка, и это
# единственный проверенный на этом приборе путь. Переключение DTR/RTS через .NET до
# встроенного USB-Serial-JTAG не доходит: прибор не перезапускается вовсе, и порт ничего не
# отдаёт, потому что снятие к тому времени давно прошло.
#
# Запасной путь — те же линии, если окружение ESP-IDF не нашлось: тогда прибор придётся
# перезапустить кнопкой RESET, о чём скрипт и скажет ниже.
function Reset-Board {
    param([string] $Name, [string] $RepoRoot)

    try {
        . (Join-Path $PSScriptRoot '_idf_env.ps1')
        $null = Initialize-IdfEnvironment -RepoRoot $RepoRoot

        if (Get-Command esptool.py -ErrorAction SilentlyContinue) {
            Write-Host 'перезапускаю прибор через esptool'
            & esptool.py --chip esp32s3 -p $Name --before default-reset --after hard-reset --no-stub flash_id 2>&1 |
                Select-Object -Last 2 | ForEach-Object { '  | ' + $_ }
            return $true
        }
    }
    catch {
        Write-Host ('  esptool не сработал: ' + $_.Exception.Message)
    }

    return $false
}

# Запасной сброс: те же линии, в том же порядке, что у esptool (класс USBJTAGSerialReset).
function Reset-Lines {
    param([System.IO.Ports.SerialPort] $Serial)

    $Serial.RtsEnable = $false
    $Serial.DtrEnable = $false
    Start-Sleep -Milliseconds 100

    $Serial.DtrEnable = $true
    $Serial.RtsEnable = $false
    Start-Sleep -Milliseconds 100

    $Serial.RtsEnable = $true
    $Serial.DtrEnable = $false
    Start-Sleep -Milliseconds 100

    $Serial.DtrEnable = $false
    $Serial.RtsEnable = $false
}

function Open-Port {
    param([string] $Name, [int] $Seconds)

    $deadline = (Get-Date).AddSeconds($Seconds)

    while ($true) {
        $serial = New-Object System.IO.Ports.SerialPort
        $serial.PortName       = $Name
        $serial.BaudRate       = 115200
        $serial.Parity         = [System.IO.Ports.Parity]::None
        $serial.DataBits       = 8
        $serial.StopBits       = [System.IO.Ports.StopBits]::One
        $serial.Handshake      = [System.IO.Ports.Handshake]::None
        $serial.ReadBufferSize = 65536
        $serial.ReadTimeout    = 2000
        $serial.WriteTimeout   = 2000
        $serial.DtrEnable      = $false
        $serial.RtsEnable      = $false

        try {
            $serial.Open()
            return $serial
        }
        catch {
            if ((Get-Date) -ge $deadline) { throw }
            Start-Sleep -Milliseconds 300
        }
    }
}

if (-not (Test-Path $JobsDir)) { New-Item -ItemType Directory -Path $JobsDir | Out-Null }
if (-not (Test-Path $OutDir))   { New-Item -ItemType Directory -Path $OutDir | Out-Null }

# Список кадров — из одного места: tools/lib/screens.js читает прошивку и справочник, пишет
# screens.json рядом со снимками и задание для этого скрипта во временный каталог.
Write-Host 'соответствие страниц и экранов:'
$jobListPath = Join-Path $JobsDir 'frames.json'
& node (Join-Path $PSScriptRoot 'lib\screens.js') $jobListPath
if ($LASTEXITCODE -ne 0) {
    throw 'соответствие «номер страницы → метка экрана» не сходится, снимать нечего'
}

$jobList  = Get-Content $jobListPath -Encoding UTF8 -Raw | ConvertFrom-Json
$pages    = @($jobList.screens)
$overlays = @($jobList.overlays)
$pythonExe = Get-Python -Given $Python

# Разбор -Extra: «МЕТКА=файл.png». Проверяется сразу, до съёмки: опечатка в метке должна
# стоить секунды, а не полной пересъёмки.
$extraJobs = @()
foreach ($item in $Extra) {
    if ($item -notmatch '^\s*(.+?)\s*=\s*([^=\\]+\.png)\s*$') {
        throw ('-Extra ждёт «МЕТКА=файл.png», а получил «' + $item + '»')
    }

    $extraLabel = $Matches[1]
    $extraFile  = $Matches[2]

    $known = @($pages | Where-Object { $_.label -eq $extraLabel })
    if ($known.Count -eq 0) {
        throw ('-Extra: метки «' + $extraLabel + '» нет среди страниц прибора')
    }

    $taken = @($pages + $overlays | Where-Object { $_.file -eq $extraFile })
    if ($taken.Count -ne 0) {
        throw ('-Extra: файл ' + $extraFile + ' занят другим кадром')
    }

    $extraJobs += @{ label = $known[0].label; file = $extraFile }
}

if (@($extraJobs).Count -gt 0) {
    Write-Host ('вторые кадры: ' + ((@($extraJobs) | ForEach-Object {
        [string]$_.label + ' -> ' + [string]$_.file }) -join ', '))
}

Write-Host ("порт {0}, страниц {1}, состояний {2}, python {3}" -f `
            $Port, $pages.Count, $overlays.Count, $pythonExe)

$frames  = @{}
$pending = @{}
$order   = New-Object System.Collections.ArrayList
$noise   = 0
$current = $null
$buffer  = New-Object System.Text.StringBuilder
$recent  = New-Object System.Collections.ArrayList
$noiseLines = New-Object System.Collections.ArrayList
$done    = $false
$serial  = $null

try {
    if (-not (Reset-Board -Name $Port -RepoRoot $Root)) {
        $serial = Open-Port -Name $Port -Seconds 5
        Write-Host 'перезапускаю прибор по линиям DTR/RTS'
        Reset-Lines -Serial $serial
        $serial.Close()
        $serial = $null
    }

    # Прибору нужно время, чтобы загрузиться и заново перечислить встроенный USB-Serial-JTAG:
    # открытый раньше порт после этого мёртв, а снятие начинается через восемь секунд после
    # запуска интерфейса и идёт один раз.
    Start-Sleep -Seconds 4
    $serial = Open-Port -Name $Port -Seconds $PortBackSec
    Write-Host 'жду строки прибора'

    $bootDeadline = (Get-Date).AddSeconds($BootWaitSec)
    $deadline     = (Get-Date).AddSeconds($TimeoutSec)
    $heard        = $false
    $hinted       = $false
    $shotSeen     = $false

    while (-not $done -and (Get-Date) -lt $deadline) {
        if (-not $heard -and -not $hinted -and (Get-Date) -gt $bootDeadline) {
            Write-Host ("  за {0} секунд в порту ничего не появилось." -f $BootWaitSec)
            Write-Host '  нажми RESET на приборе — слушаю дальше'
            $hinted = $true
        }

        $line = $null
        try { $line = $serial.ReadLine() }
        catch [System.TimeoutException] { continue }
        if ($null -eq $line) { continue }

        $line = $line.Trim()
        if ($line.Length -eq 0) { continue }

        $heard = $true
        [void]$recent.Add($line)
        if ($recent.Count -gt 12) { $recent.RemoveAt(0) }

        if ($line.StartsWith('@@SHOT')) {
            $parts = $line -split '\s+'
            if ($parts.Count -lt 6) {
                throw ('заголовок снимка непонятен: ' + $line)
            }

            # Имя в заголовке содержит пробелы («DRONE FLTR», «MACRO INV»), поэтому числа
            # отсчитываются от конца строки, а имя — всё, что между номером и шириной. Число
            # знаков base64 считается сразу: по нему видно, где кадр заканчивается.
            $current = @{
                index  = [int]$parts[1]
                name   = ($parts[2..($parts.Count - 4)] -join ' ')
                width  = [int]$parts[$parts.Count - 3]
                height = [int]$parts[$parts.Count - 2]
                bytes  = [int]$parts[$parts.Count - 1]
                chars  = 4 * [int][Math]::Ceiling([int]$parts[$parts.Count - 1] / 3.0)
                sent   = 0
            }
            $buffer.Clear() | Out-Null
            $shotSeen = $true
            continue
        }

        if ($line -eq '@@END') {
            if ($null -ne $current) {
                # Кадр страницы приходит с номером страницы и её именем; кадр состояния — с
                # именем состояния, которого среди страниц нет. И то и другое ищется по имени,
                # а номер страницы потом сверяется: перепутанная страница так и всплывёт.
                $page    = @($pages    | Where-Object { $_.label -eq $current.name }) | Select-Object -First 1
                $overlay = @($overlays | Where-Object { $_.key   -eq $current.name }) | Select-Object -First 1

                if ($null -ne $page) {
                    if ([int]$page.index -ne $current.index) {
                        throw ('страница «' + $current.name + '» пришла под номером ' + $current.index +
                               ', а в списке она под номером ' + $page.index)
                    }
                    $label = $page.label
                    $file  = $page.file
                }
                elseif ($null -ne $overlay) {
                    $label = $overlay.key
                    $file  = $overlay.file
                }
                else {
                    throw ('прибор прислал кадр «' + $current.name +
                           '», которого нет ни среди страниц, ни среди состояний')
                }

                if ($current.width -ne $WantWidth -or $current.height -ne $WantHeight) {
                    throw ('кадр ' + $label + ': размер ' + $current.width + 'x' +
                           $current.height + ', ожидается ' + $WantWidth + 'x' + $WantHeight)
                }

                if ($buffer.Length -ne $current.chars) {
                    throw ('кадр ' + $label + ': знаков base64 ' + $buffer.Length + ', ожидается ' +
                           $current.chars + ' — в кадр попала чужая строка')
                }

                # Разбор и запись кадра откладываются до конца потока: пока хост разбирает
                # предыдущий кадр, прибор выдаёт следующий, а его буфер передачи вмещает 4 КБ —
                # пауза в десятки миллисекунд стоит начала следующего кадра.
                $pending[$file] = @{ label = $label; index = $current.index; bytes = $current.bytes
                                     text = $buffer.ToString() }
                [void]$order.Add($file)
            }

            $current = $null
            continue
        }

        if ($line -eq '@@DONE') {
            $done = $true
            continue
        }

        if ($null -ne $current) {
            # Прибор режет кадр на куски по 57 байт и начинает счёт заново на каждой строке
            # экрана. Поэтому длины строк чередуются: двенадцать по 76 знаков и тринадцатая, на
            # остаток строки, — 48. Ожидаемая длина следующей строки считается по тому же
            # правилу: чужая строка в кадр не пролезет, а своя не потеряется.
            $rowBytes = $current.width * 2
            $rowLeft  = $rowBytes - ($current.sent % $rowBytes)
            $chunk    = [Math]::Min(57, $rowLeft)
            $take     = 4 * [int][Math]::Ceiling($chunk / 3.0)

            if ($line.Length -eq $take -and $line -match '^[A-Za-z0-9+/=]+$') {
                $buffer.Append($line) | Out-Null
                $current.sent = $current.sent + $chunk
            }
            else {
                $noise++
                [void]$noiseLines.Add('(внутри кадра) ' + $line)
            }
        }
        else {
            # Строка мимо протокола: строки загрузки и отчёт самого модуля снятия. Копится и
            # печатается целиком после чтения — по ней и видно, что снятие не пошло и почему.
            $noise++
            [void]$noiseLines.Add($line)
        }
    }

    # Последнее слово модуль снятия говорит уже после @@DONE: в нём число кадров и то, сколько
    # параметров было в макросе до и после. Читаем ещё немного, чтобы это не потерялось.
    if ($done) {
        $tail = (Get-Date).AddSeconds(3)
        while ((Get-Date) -lt $tail) {
            $line = $null
            try { $line = $serial.ReadLine() }
            catch [System.TimeoutException] { continue }
            if ($null -eq $line) { continue }

            $line = $line.Trim()
            if ($line.Length -eq 0 -or $line.StartsWith('@@')) { continue }
            $noise++
            [void]$noiseLines.Add($line)
        }
    }
}
finally {
    if ($null -ne $serial -and $serial.IsOpen) { $serial.Close() }
}

# Кадры разбираются только теперь, когда порт закрыт и спешить уже некуда.
foreach ($file in @($order)) {
    $stored = $pending[$file]
    $raw = [Convert]::FromBase64String($stored.text)

    if ($raw.Length -ne $stored.bytes) {
        throw ('кадр ' + $stored.label + ': байтов ' + $raw.Length + ', прибор обещал ' + $stored.bytes)
    }

    $rawPath = Join-Path $JobsDir ('{0:D2}-{1}.raw' -f $stored.index, $file.Replace('.png', ''))
    [IO.File]::WriteAllBytes($rawPath, $raw)

    $frames[$file] = @{ label = $stored.label; raw = $rawPath; png = Join-Path $OutDir $file
                        bytes = $raw.Length }
    Write-Host ('  {0,-12} {1}  {2} байт' -f $stored.label, $stored.index, $raw.Length)
}

# Строки прибора печатаются здесь же. Во время чтения на консоль не пишется ничего: у
# встроенного USB-Serial-JTAG нет управления потоком, и медленный читатель стоит кадров.
if ($noiseLines.Count -gt 0) {
    Write-Host ('строки прибора ({0}):' -f $noiseLines.Count)
    foreach ($one in $noiseLines) { Write-Host ('  | ' + $one) }
}

$wantCount = $pages.Count + $overlays.Count

if (-not $done) {
    Write-Host 'поток снимков не завершился:'
    Write-Host ('  кадров принято {0} из {1}, посторонних строк {2}' -f $frames.Count, $wantCount, $noise)
    if (-not $shotSeen) {
        Write-Host '  заголовка @@SHOT не было ни разу: снятие не начиналось'
    }
    if ($recent.Count) {
        Write-Host '  последние принятые строки:'
        $recent | ForEach-Object { "    | " + $_ }
    }
    exit 1
}

if ($frames.Count -ne $wantCount) {
    $missing = @($pages + $overlays) | Where-Object { -not $frames.ContainsKey($_.file) }
    $names   = @($missing | ForEach-Object { if ($_.label) { $_.label } else { $_.key } })
    Write-Host ('не снялись: ' + ($names -join ', '))
    exit 1
}

Write-Host 'преобразование в PNG:'
$jobFrames = @($order | ForEach-Object {
    $frame = $frames[$_]
    @{ raw = $frame.raw; png = $frame.png; width = $WantWidth; height = $WantHeight; label = $frame.label }
})

# Второй кадр экрана: тот же сырой кадр, другое имя файла. Переменная цикла названа не
# «extra»: у параметра $Extra то же имя, а он объявлен как [string[]] — присваивание в него
# хеш-таблицы превратило бы её в строку, и метка потерялась бы.
foreach ($spec in @($extraJobs)) {
    $asLabel = [string]$spec.label
    $asFile  = [string]$spec.file

    if (-not $asLabel -or -not $asFile) {
        throw '-Extra: задание на второй кадр разобралось пустым'
    }

    $frame = @($frames.Values | Where-Object { $_.label -eq $asLabel }) | Select-Object -First 1
    if ($null -eq $frame) {
        throw ('-Extra: кадра «' + $asLabel + '» в потоке не было')
    }

    Write-Host ('  {0,-12} ещё раз как {1}' -f $asLabel, $asFile)
    $jobFrames += @{ raw = $frame.raw; png = (Join-Path $OutDir $asFile);
                     width = $WantWidth; height = $WantHeight; label = ($asLabel + ' (другой кадр)') }
}

$job = @{ frames = $jobFrames }

$jobPath = Join-Path $JobsDir 'job.json'
$utf8 = New-Object System.Text.UTF8Encoding($false)
[IO.File]::WriteAllText($jobPath, ($job | ConvertTo-Json -Depth 5), $utf8)

& $pythonExe (Join-Path $PSScriptRoot 'screens-to-png.py') $jobPath
if ($LASTEXITCODE -ne 0) {
    throw 'преобразование в PNG не прошло'
}

Write-Host ('готово: {0} кадров в {1}' -f $jobFrames.Count, $OutDir)
Write-Host ('сырые кадры остались в {0}' -f $JobsDir)
Write-Host 'проверка набора: node tools/screens-check.js'
