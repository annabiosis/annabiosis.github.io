<#
.SYNOPSIS
    Mirror a SquareLine Studio export into the firmware's UI component.

.DESCRIPTION
    SquareLine Studio writes its generated C sources into a folder you choose
    at export time. This script copies that folder into
    components/ui/generated/, which is what the build actually compiles.

    Why a copy instead of building straight out of the export folder:
      * the firmware keeps building from a known-good snapshot even if Studio
        is closed, mid-edit, or re-exported into a different folder;
      * the export can live outside the repository (OneDrive, a network share,
        a scratch directory) without the build depending on it;
      * the hand-written bridge in components/ui/src/ stays untouched, because
        only generated/ is ever overwritten.

    Generated output is committed on purpose: a fresh clone builds without
    needing SquareLine Studio installed.

.PARAMETER Source
    Folder holding the SquareLine export (the one containing ui.c / ui.h).
    Defaults to <repo>/ui/export. Remember to set the same path as the
    "Export directory" inside SquareLine Studio.

.PARAMETER Destination
    Target folder. Defaults to <repo>/components/ui/generated.

.PARAMETER DryRun
    Report what would change without writing anything.

.EXAMPLE
    pwsh -File tools/squareline_sync.ps1
    pwsh -File tools/squareline_sync.ps1 -Source D:\sq\knob_export -DryRun
#>
#Requires -Version 5.1
[CmdletBinding()]
param(
    [string] $Source,
    [string] $Destination,
    [switch] $DryRun
)

$ErrorActionPreference = 'Stop'

function Write-Step { param([string] $m) Write-Host "==> $m" -ForegroundColor Cyan }
function Write-Warn { param([string] $m) Write-Host "WARN: $m" -ForegroundColor Yellow }
function Write-Fail { param([string] $m) Write-Host "ERROR: $m" -ForegroundColor Red }

$repoRoot = Split-Path -Parent $PSScriptRoot

if (-not $Source)      { $Source      = Join-Path $repoRoot 'ui/export' }
if (-not $Destination) { $Destination = Join-Path $repoRoot 'components/ui/generated' }

# --- Validate the source ----------------------------------------------------
if (-not (Test-Path -LiteralPath $Source -PathType Container)) {
    Write-Fail "SquareLine export folder not found: $Source"
    Write-Host ''
    Write-Host 'In SquareLine Studio:'
    Write-Host '  File > Project Settings > Export directory'
    Write-Host "  set it to: $Source"
    Write-Host '  then File > Export > Export UI Files (LVGL 9).'
    Write-Host ''
    Write-Host 'Or pass a different folder:'
    Write-Host '  pwsh -File tools/squareline_sync.ps1 -Source <folder>'
    exit 2
}

$sourceFull = (Resolve-Path -LiteralPath $Source).Path

# SquareLine always emits ui.c + ui.h. Their absence means either the wrong
# folder or a failed export, and copying it in would break the build in a
# confusing way later.
foreach ($required in @('ui.c', 'ui.h')) {
    if (-not (Test-Path -LiteralPath (Join-Path $sourceFull $required))) {
        Write-Fail "Missing $required in $sourceFull — this does not look like a SquareLine export."
        exit 3
    }
}

# --- Guard the destination before deleting anything -------------------------
$destinationFull = [System.IO.Path]::GetFullPath($Destination)
$expectedSuffix  = [System.IO.Path]::Combine('components', 'ui', 'generated')

if (-not $destinationFull.EndsWith($expectedSuffix, [System.StringComparison]::OrdinalIgnoreCase)) {
    Write-Fail "Refusing to clear '$destinationFull': it is not components/ui/generated."
    Write-Host 'Only the generated UI snapshot may be overwritten.'
    exit 4
}
if (-not $destinationFull.StartsWith($repoRoot, [System.StringComparison]::OrdinalIgnoreCase)) {
    Write-Fail "Refusing to clear '$destinationFull': it is outside the repository ($repoRoot)."
    exit 4
}
if ($destinationFull -eq $repoRoot -or $destinationFull -eq (Split-Path -Parent $repoRoot)) {
    Write-Fail 'Refusing to clear the repository root.'
    exit 4
}

# --- Collect the file list --------------------------------------------------
$files = Get-ChildItem -LiteralPath $sourceFull -Recurse -File |
         Where-Object { $_.Extension -in @('.c', '.h') }

if (-not $files) {
    Write-Fail "No .c/.h files found in $sourceFull."
    exit 5
}

$totalBytes = ($files | Measure-Object -Property Length -Sum).Sum

Write-Step "Source:      $sourceFull"
Write-Step "Destination: $destinationFull"
Write-Step ("Files:       {0} ({1:N1} KB)" -f $files.Count, ($totalBytes / 1KB))

if ($DryRun) {
    Write-Host ''
    Write-Host 'Dry run — nothing written. Would copy:' -ForegroundColor Yellow
    $files | ForEach-Object {
        $rel = $_.FullName.Substring($sourceFull.Length).TrimStart('\', '/')
        Write-Host "  $rel"
    }
    exit 0
}

# --- Replace the snapshot ---------------------------------------------------
if (Test-Path -LiteralPath $destinationFull) {
    Write-Step 'Clearing previous snapshot'
    Get-ChildItem -LiteralPath $destinationFull -Force | Remove-Item -Recurse -Force
} else {
    New-Item -ItemType Directory -Path $destinationFull -Force | Out-Null
}

foreach ($file in $files) {
    $relative  = $file.FullName.Substring($sourceFull.Length).TrimStart('\', '/')
    $targetPath = Join-Path $destinationFull $relative
    $targetDir  = Split-Path -Parent $targetPath

    if (-not (Test-Path -LiteralPath $targetDir)) {
        New-Item -ItemType Directory -Path $targetDir -Force | Out-Null
    }
    Copy-Item -LiteralPath $file.FullName -Destination $targetPath -Force
}

# --- Manifest ---------------------------------------------------------------
# Written into the snapshot so `git log` on this folder shows when the UI last
# came out of Studio, and so a stale snapshot is obvious.
$manifest = @()
$manifest += "# Generated by tools/squareline_sync.ps1 — do not edit by hand."
$manifest += "#"
$manifest += "# SquareLine Studio export snapshot."
$manifest += "# Source folder: $sourceFull"
$manifest += "# Synced at:     $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss K')"
$manifest += "# Files:         $($files.Count)"
$manifest += "#"
$manifest += "# To update: re-export from SquareLine Studio, then run the"
$manifest += "# VS Code task 'UI: Sync SquareLine export' (or tools/squareline_sync.ps1)."
$manifest += ""
$manifest += ($files |
    ForEach-Object { $_.FullName.Substring($sourceFull.Length).TrimStart('\', '/') } |
    Sort-Object)

Set-Content -LiteralPath (Join-Path $destinationFull 'SYNC_MANIFEST.txt') -Value $manifest -Encoding utf8

# Touch the component's CMakeLists.txt so CMake re-runs its source glob on the
# next build. The glob there cannot use CONFIGURE_DEPENDS — ESP-IDF evaluates
# component files in CMake script mode, which rejects the keyword — so this
# timestamp bump is what makes a freshly exported screen show up without a
# manual `idf.py reconfigure`.
$uiCmakeLists = Join-Path $repoRoot 'components/ui/CMakeLists.txt'
if (Test-Path -LiteralPath $uiCmakeLists) {
    (Get-Item -LiteralPath $uiCmakeLists).LastWriteTime = Get-Date
} else {
    Write-Warn "components/ui/CMakeLists.txt not found — new screens may need 'idf.py reconfigure'"
}

Write-Step 'Done.'
Write-Host ''
Write-Host 'Next: build with the VS Code task "IDF: Build".' -ForegroundColor Green
