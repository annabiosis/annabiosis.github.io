#!/usr/bin/env node
/**
 * Сверка размера и хеша образа прошивки.
 *
 * Проверяет, что манифест, страница записи, страница «Под капотом» и
 * docs/RELEASE.md называют одно и то же число, и что это число — размер
 * файла tools/webflash/firmware/OBOD.bin, посчитанный по самому файлу.
 *
 * Зачем отдельная проверка. Раньше страница брала размер из заголовка
 * Content-Length ответа на HEAD. На GitHub Pages ответ сжатый, и на странице
 * стояло 701 697 байт вместо 1 176 144 — ошибки при этом не было ни в одном
 * файле, потому что числа просто нигде не сверялись. Хеш в RELEASE.md уже
 * один раз разошёлся с образом по той же причине: он жил отдельной строкой.
 *
 * Запуск: node tools/image-meta-check.js
 */

'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const root = path.join(__dirname, '..');
const manifestPath = path.join(root, 'tools', 'webflash', 'manifest.json');
const imagePath = path.join(root, 'tools', 'webflash', 'firmware', 'OBOD.bin');
const flashPath = path.join(root, 'web', 'flash.html');
const localFlashPath = path.join(root, 'tools', 'webflash', 'index.html');
const underPath = path.join(root, 'web', 'under.html');
const releasePath = path.join(root, 'docs', 'RELEASE.md');
const lockPath = path.join(root, 'tools', 'webflash', 'lock.json');
const sealedPath = path.join(root, 'tools', 'webflash', 'firmware', 'OBOD.bin.enc');
const unlockPath = path.join(root, 'web', 'assets', 'unlock.js');
const featuresPaths = [path.join(root, 'FEATURES.md'), path.join(root, 'FEATURES.en.md')];

const problems = [];
function fail(text) { problems.push(text); }
function rel(p) { return path.relative(root, p).replace(/\\/g, '/'); }

/* Проверять надо код, а не пояснения к нему: в страницах рядом с исправлением
   написано, почему Content-Length для размера не годится, и поиск по слову
   находил бы собственный комментарий. */
function stripComments(text) {
  return text
    .replace(/<!--[\s\S]*?-->/g, ' ')
    .replace(/\/\*[\s\S]*?\*\//g, ' ')
    .replace(/^[ \t]*\/\/.*$/gm, ' ');
}

// --- сам образ -------------------------------------------------------------

if (!fs.existsSync(imagePath)) {
  fail('нет образа ' + rel(imagePath) + ' — сначала pwsh -File tools/webflash/merge.ps1');
} else {
  const raw = fs.readFileSync(imagePath);
  const size = raw.length;
  const hash = crypto.createHash('sha256').update(raw).digest('hex').toUpperCase();

  // Число в текстах пишется с пробелом между разрядами, и пробел этот бывает
  // обычным, неразрывным или тонким. Сравниваем без них: важно число, а не
  // то, чем его разделили.
  const squash = (text) => text.replace(/[\s\u00A0\u2009\u202F]/g, '');
  const spaced = size.toLocaleString('ru-RU').replace(/\u00A0/g, ' ');

  // --- манифест ---
  let manifest = null;
  if (!fs.existsSync(manifestPath)) {
    fail('нет ' + rel(manifestPath));
  } else {
    try {
      manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
    } catch (error) {
      fail('не читается ' + rel(manifestPath) + ': ' + error.message);
    }
  }

  if (manifest) {
    const buildPart = manifest.builds && manifest.builds[0] &&
      manifest.builds[0].parts && manifest.builds[0].parts[0];
    if (!buildPart) {
      fail('в ' + rel(manifestPath) + ' нет builds[0].parts[0] — странице нечего прошивать');
    }

    const image = manifest.image;
    if (!image) {
      fail('в ' + rel(manifestPath) + ' нет поля image — страница не узнает размер и хеш');
    } else {
      if (image.size !== size) {
        fail('манифест: image.size ' + image.size + ', файл ' + size +
          ' — пересоберите образ (pwsh -File tools/webflash/merge.ps1)');
      }
      if (String(image.sha256 || '').toUpperCase() !== hash) {
        fail('манифест: image.sha256 ' + String(image.sha256 || '—').slice(0, 16) +
          '…, файл ' + hash.slice(0, 16) + '…');
      }
      if (buildPart && image.path !== buildPart.path) {
        fail('манифест: image.path «' + image.path + '» не совпадает с builds[0].parts[0].path «' +
          buildPart.path + '» — два разных пути к одному образу');
      }
    }

    if (!manifest.version) {
      fail('в ' + rel(manifestPath) + ' нет поля version');
    }
  }

  // --- страница записи: только манифест, никаких заголовков ответа ---
  for (const page of [flashPath, localFlashPath]) {
    if (!fs.existsSync(page)) {
      fail('нет ' + rel(page));
      continue;
    }
    const text = stripComments(fs.readFileSync(page, 'utf8'));
    if (/content-length/i.test(text)) {
      fail(rel(page) + ': размер берётся из Content-Length — на GitHub Pages ответ сжат, ' +
        'и число занижено; берите image.size из манифеста');
    }
    if (/method:\s*['"]HEAD['"]/.test(text)) {
      fail(rel(page) + ': остался запрос HEAD за размером — размер уже есть в манифесте');
    }
    /* Размер нужен странице, чтобы назвать образ до записи. У страницы на сайте это
       делает assets/unlock.js (разметка держит только пути), у локальной — свой скрипт
       в самой странице. Поэтому ищем число в обоих местах и требуем, чтобы оно
       нашлось хотя бы в одном: правила «только в разметке» здесь больше нет, но и
       потерять строку с размером нельзя. */
    const scriptPath = path.join(root, 'web', 'assets', 'unlock.js');
    const script = fs.existsSync(scriptPath) ? stripComments(fs.readFileSync(scriptPath, 'utf8')) : '';
    if (!/image\.size/.test(text) && !/image\.size/.test(script)) {
      fail(rel(page) + ': не читает image.size из манифеста');
    }
  }

  /* --- замок выпуска --- */
  let lock = null;
  if (!fs.existsSync(lockPath)) {
    fail('нет замка ' + rel(lockPath) + ' — страница записи не расшифрует образ');
  } else {
    try {
      lock = JSON.parse(fs.readFileSync(lockPath, 'utf8'));
    } catch (error) {
      fail('не читается ' + rel(lockPath) + ': ' + error.message);
    }
  }

  if (!fs.existsSync(sealedPath)) {
    fail('нет запечатанного образа ' + rel(sealedPath) + ' — pwsh -File tools/webflash/seal.ps1');
  }

  if (lock) {
    const sealedRaw = fs.existsSync(sealedPath) ? fs.readFileSync(sealedPath) : null;
    const sealedSize = sealedRaw ? sealedRaw.length : 0;
    const sealedHash = sealedRaw
      ? crypto.createHash('sha256').update(sealedRaw).digest('hex').toUpperCase()
      : '';

    if (!lock.cipher || decodeURIComponent(lock.cipher.name || '') !== 'AES-256-GCM') {
      fail('замок: шифр не AES-256-GCM');
    }
    if (!lock.kdf || lock.kdf.name !== 'PBKDF2-SHA256') {
      fail('замок: вывод ключа не PBKDF2-SHA256');
    } else if (!(lock.kdf.iterations >= 200000)) {
      fail('замок: итераций ' + lock.kdf.iterations + ', мало — нужно не меньше 200 000');
    }
    if (!lock.kdf || !lock.kdf.salt) {
      fail('замок: нет соли');
    }
    if (!lock.cipher || !lock.cipher.iv) {
      fail('замок: нет вектора');
    }

    if (!lock.plain || lock.plain.size !== size) {
      fail('замок: plain.size ' + (lock.plain && lock.plain.size) + ', образ ' + size);
    }
    if (!lock.plain || String(lock.plain.sha256 || '').toUpperCase() !== hash) {
      fail('замок: plain.sha256 не тот, что у образа — перезапечатайте (seal.ps1)');
    }
    if (sealedRaw) {
      if (lock.sealed && lock.sealed.size !== sealedSize) {
        fail('замок: sealed.size ' + lock.sealed.size + ', файл ' + sealedSize);
      }
      if (lock.sealed && String(lock.sealed.sha256 || '').toUpperCase() !== sealedHash) {
        fail('замок: sealed.sha256 не тот, что у файла — перезапечатайте (seal.ps1)');
      }
      if (sealedSize !== size + 16) {
        fail('запечатанный файл ' + sealedSize + ' байт при образе ' + size +
          ': ждали образ и шестнадцать байт тега');
      }
    }
  }

  /* Страница обязана брать замок и образ из разметки, а не из литералов в скрипте:
     пути в скрипте остались бы репозиторными на сайте. */
  if (fs.existsSync(flashPath)) {
    const flash = fs.readFileSync(flashPath, 'utf8');
    if (!/data-lock=/.test(flash) || !/data-sealed=/.test(flash)) {
      fail(rel(flashPath) + ': нет data-lock и data-sealed — скрипту неоткуда взять пути');
    }
  }
  if (fs.existsSync(unlockPath)) {
    const script = fs.readFileSync(unlockPath, 'utf8');
    if (!/getAttribute\(\s*'data-lock'\s*\)/.test(script)) {
      fail(rel(unlockPath) + ': путь к замку не из разметки');
    }
  } else {
    fail('нет ' + rel(unlockPath));
  }

  // --- «Под капотом» и RELEASE.md называют то же число ---
  if (fs.existsSync(underPath)) {
    const under = fs.readFileSync(underPath, 'utf8');
    if (!squash(under).includes(String(size))) {
      fail(rel(underPath) + ': не называет размер образа ' + spaced + ' байт');
    }
  } else {
    fail('нет ' + rel(underPath));
  }

  if (fs.existsSync(releasePath)) {
    const release = fs.readFileSync(releasePath, 'utf8');
    if (!squash(release).includes(String(size))) {
      fail(rel(releasePath) + ': не называет размер образа ' + spaced + ' байт');
    }
    if (!release.toUpperCase().includes(hash)) {
      fail(rel(releasePath) + ': не называет SHA-256 ' + hash.slice(0, 16) + '…');
    }
  } else {
    fail('нет ' + rel(releasePath));
  }

  /* FEATURES называют размер образа прозой, и эти два числа отставали от
     выпуска: стояли 1 172 112 и 1 041 040 из прошлой сборки. Строка без
     проверки стареет молча, поэтому сверяем и её. */
  for (const features of featuresPaths) {
    if (!fs.existsSync(features)) {
      fail('нет ' + rel(features));
      continue;
    }
    if (!squash(fs.readFileSync(features, 'utf8')).includes(String(size))) {
      fail(rel(features) + ': не называет размер образа ' + spaced + ' байт');
    }
  }

  if (problems.length) {
    console.error('FAIL: размер и хеш образа расходятся');
    for (const problem of problems) console.error('  - ' + problem);
    process.exit(1);
  }

  const sealedBytes = fs.existsSync(sealedPath) ? fs.readFileSync(sealedPath).length : 0;
  console.log('OK: образ ' + rel(imagePath) + ' — ' + spaced + ' байт, SHA-256 ' +
    hash.slice(0, 16) + '…; манифест, обе страницы записи, «Под капотом» и RELEASE.md ' +
    'называют то же самое, размер берётся из манифеста, а не из заголовка ответа; ' +
    'замок — AES-256-GCM на PBKDF2-SHA256, запечатанный файл ' +
    sealedBytes.toLocaleString('ru-RU') + ' байт');
}
