'use strict';

/*
 * Пересчёт вертикальных метрик в шрифте LVGL, собранном сторонним экспортёром.
 *
 * Экспортёр пишет ofs_y как расстояние ОТ базовой линии ДО ВЕРХА глифа, а LVGL читает его
 * как расстояние до НИЗА: в lv_draw_label.c стоит
 *
 *     letter_coords.y1 = pos->y + (line_height - base_line) - g.box_h - g.ofs_y;
 *
 * то есть ofs_y — это минус вынос глифа под базовую линию, а не высота над ней. При
 * подстановке "высоты сверху" цифры сдвигаются на собственную высоту глифа: заглавная
 * девятипиксельной высоты в строке высотой десять садится на девятую строку и уезжает за
 * нижний край надписи — на экране это выглядит как обрезанный или пропавший текст.
 *
 * Кроме того line_height и base_line в LVGL означают: line_height — вся строка, ascent плюс
 * descent, а base_line — ИМЕННО descent, расстояние от базовой линии до низа строки.
 *
 * Скрипт читает таблицу глифов, восстанавливает по ofs_y высоту над базовой линией
 * (top = -ofs_y), считает настоящие ascent и descent по всем глифам, переписывает ofs_y как
 * -(descent глифа) и ставит правильные line_height и base_line. Горизонтальные метрики,
 * битмапы, cmap и кернинг не трогаются.
 *
 * Запуск: node tools/font_metrics_fix.js <файл.c> [--check]
 *   --check  только показать, что получится, файл не менять.
 */

const fs = require('fs');
const path = process.argv[2];

if (!path) {
    console.error('нужен путь к .c шрифта');
    process.exit(2);
}

const checkOnly = process.argv.includes('--check');
const text = fs.readFileSync(path, 'utf8');

/* Каждая строка таблицы глифов: box_w, box_h, ofs_x, ofs_y. */
const glyphRe = /\.box_w = (\d+), \.box_h = (\d+), \.ofs_x = (-?\d+), \.ofs_y = (-?\d+)/g;

let ascent = 0;
let descent = 0;
let count = 0;
let match;

while ((match = glyphRe.exec(text)) !== null) {
    const boxH = Number(match[2]);
    const ofsY = Number(match[4]);

    if (boxH === 0) {
        continue;
    }

    /* Сколько пикселей глиф стоит над базовой линией, по метрике экспортёра. */
    const top = -ofsY;
    const bottom = boxH - top;

    if (top > ascent) {
        ascent = top;
    }
    if (bottom > descent) {
        descent = bottom;
    }
    count++;
}

if (count === 0) {
    console.error('таблица глифов не найдена');
    process.exit(2);
}

/*
 * Скрипт не идемпотентен, и это опасно: во второй прогон он принял бы уже исправленные
 * ofs_y за прежние и вывернул метрики наизнанку. Признак испорченной подстановки видно
 * сразу — у любого начертания над базовой линией стоит больше, чем под ней. Если проверка
 * сработала, файл уже в соглашении LVGL и трогать его нечего.
 */
if (descent > ascent) {
    console.log('  глифов: ' + count);
    console.log('  ascent ' + ascent + ' меньше descent ' + descent +
                ': файл уже в соглашении LVGL, метрики не трогаю');
    process.exit(0);
}

const lineHeight = ascent + descent;

console.log('  глифов: ' + count);
console.log('  ascent: ' + ascent + ', descent: ' + descent + ', line_height: ' + lineHeight);

/* Переписать ofs_y: -(descent глифа) = -(box_h - top) = top - box_h. */
const fixed = text.replace(glyphRe, (all, boxW, boxH, ofsX, ofsY) => {
    const h = Number(boxH);

    if (h === 0) {
        return all;
    }

    const top = -Number(ofsY);
    const newOfs = top - h;

    return all.replace('.ofs_y = ' + ofsY, '.ofs_y = ' + newOfs);
});

/* line_height и base_line в описании шрифта: base_line — это descent. */
const structRe = /(\.line_height = )(\d+)(,\s*\n\s*\.base_line = )(\d+)/;
const before = fixed.match(structRe);

if (!before) {
    console.error('описание шрифта (line_height/base_line) не найдено');
    process.exit(2);
}

const out = fixed.replace(structRe, (all, a, lh, b) => a + lineHeight + b + descent);

if (before[2] !== String(lineHeight) || before[4] !== String(descent)) {
    console.log('  было: line_height ' + before[2] + ', base_line ' + before[4]);
} else {
    console.log('  метрики уже верные');
}

if (checkOnly) {
    console.log('  проверка: файл не изменён');
} else {
    fs.writeFileSync(path, out);
    console.log('  записано: ' + path);
}
