#!/usr/bin/env python3
"""WCAG contrast ratios for the synth_ui colour tables.

Every figure this prints is checked against one already written down in the source,
so the method is validated before it is used on a new colour. Run it whenever the
palette changes; the comments in synth_ui.c quote these numbers.

    python tools/contrast.py
"""

BG = 0x04100D        # COL_BG
COL_TEXT = 0xD4F5F0  # COL_TEXT, the ink a VALUE is drawn in
TINT_BODY = 96       # the fill of the selected sector
PAGE_DOT_TINT = 192  # a page dot you are not on


def _lin(c):
    c = c / 255.0
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4


def lum(h):
    return (0.2126 * _lin((h >> 16) & 255)
            + 0.7152 * _lin((h >> 8) & 255)
            + 0.0722 * _lin(h & 255))


def cr(a, b):
    la, lb = lum(a), lum(b)
    hi, lo = max(la, lb), min(la, lb)
    return (hi + 0.05) / (lo + 0.05)


def tint(rgb, num):
    """synth_ui.c's tint(): every channel scaled by the same factor."""
    return ((((rgb >> 16) & 255) * num // 256) << 16
            | (((rgb >> 8) & 255) * num // 256) << 8
            | ((rgb & 255) * num // 256))


# GROUP_COLOR verbatim: name, tile, fill, text, ink. The generators' row is given
# both as the gold it was and the teal it is now.
FAMILIES = [
    ("blue",     0x0D47A1, 0x1565C0, 0x90CAF9, 0x90CAF9),
    ("violet",   0x4A148C, 0x9C27B0, 0xCE93D8, 0xCE93D8),
    ("gold",     0x5C4908, 0x7E6309, 0xFFD54F, 0xFFD54F),
    ("teal",     0x004D40, 0x00695C, 0x80CBC4, 0x80CBC4),
    ("green",    0x1B5E20, 0x1B5E20, 0xA5D6A7, 0xA5D6A7),
    ("pink",     0x880E4F, 0xC2185B, 0xF48FB1, 0xF8BBD0),
    ("brown",    0x3E2723, 0x4E342E, 0xBCAAA4, 0xBCAAA4),
    ("grey-900", 0x263238, 0x546E7A, 0x90A4AE, 0xCFD8DC),
    ("grey-700", 0x455A64, 0x37474F, 0xCFD8DC, 0xCFD8DC),
]

print("1. CHIP and its LABEL (the ink) — doc: blue 2.3/4.9, violet 1.7/5.0, gold 2.3/6.2,")
print("   green 2.6/4.8, pink 2.1/5.9, brown 1.5/6.2, grey 1.5/9.1 and 2.8/5.0")
for nm, tile, fill, text, ink in FAMILIES:
    print("   %-9s chip %4.1f:1   label %4.1f:1" % (nm, cr(tile, BG), cr(ink, tile)))

print()
print("2. INK on the selected fill, tint(fill, %d) — doc: worst NAME 6.62 (violet) and"
      % TINT_BODY)
print("   worst VALUE 13.12 (blue) at 96; the same pair was 5.62 / 11.06 at 128")
for tb in (TINT_BODY, 128):
    print("   at %3d:" % tb)
    for nm, tile, fill, text, ink in FAMILIES:
        print("     %-9s name %6.2f:1   value %6.2f:1"
              % (nm, cr(text, tint(fill, tb)), cr(COL_TEXT, tint(fill, tb))))
    wn = min((cr(text, tint(fill, tb)), nm) for nm, tile, fill, text, ink in FAMILIES)
    wv = min((cr(COL_TEXT, tint(fill, tb)), nm) for nm, tile, fill, text, ink in FAMILIES)
    print("     => worst name %.2f:1 (%s)   worst value %.2f:1 (%s)"
          % (wn[0], wn[1], wv[0], wv[1]))

print()
print("3. PAGE DOTS — NOT REPRODUCED. The dots sit on the transport curtain, not on")
print("   COL_BG, so the source's 1.97 / 3.31 / 6.26 / 5.36 cannot be derived from here.")
print("   Printed against COL_BG for reference only; the source's figures are measured.")
for nm, tile, fill, text, ink in FAMILIES:
    print("   %-9s @192 %5.2f:1   full %5.2f:1"
          % (nm, cr(tint(tile, PAGE_DOT_TINT), BG), cr(tile, BG)))

print()
print("4. THE INVERSION MARK — doc: the teal rim it replaced read 6.5:1")
for nm, v in [("yellow-800 rim", 0xF9A825), ("yellow-600 value", 0xFDD835),
              ("yellow-900 name", 0xF57F17), ("red rim", 0xB32E00),
              ("red value", 0xFF4D00), ("old teal rim", 0x26A69A)]:
    print("   %-17s %5.2f:1" % (nm, cr(v, BG)))
print("   yellow-100 on the dark olive tint 0x4A3B00: %.2f:1" % cr(0xFFF9C4, 0x4A3B00))
