# -*- coding: utf-8 -*-
"""
Прототип раскладки плитки по Вороному — не для прибора, только чтобы посмотреть.

Считает ячейки как диаграмму Вороного (при желании — с весами, то есть power diagram)
внутри диска радиуса R_ZONE, ставит подпись каждой ручки в ЧЕБЫШЁВСКИЙ ЦЕНТР своей ячейки
(точку, максимально удалённую от её краёв) и рисует кадр в цветах прибора.

Что даёт на выходе:
  out/<page>-<variant>.png   кадр 720x720 (2x от прибора)
  out/hit-<page>.png         карта попаданий: каждый пиксель — цвет ближайшей ручки
  отчёт в stdout             площади ячеек, запас до края, стоимость отрисовки в пикселях

Запуск: python tools/voronoi-prototype/prototype.py
"""

import math
import os

from PIL import Image, ImageDraw, ImageFont

# --- геометрия прибора (та же, что в synth_ui.c) -----------------------------

SIZE = 360                      # кадр прибора
S = 2                           # масштаб картинки для просмотра
C = SIZE / 2.0                  # центр
R_RIM_IN = 162                  # обод: 162..176
R_RIM_OUT = 176
R_HUB = 52                      # диск с именем страницы
R_ZONE = 150                    # докуда достаёт раскладка плитки
PANEL_W, PANEL_H = 112, 48      # сколько места резервирует плитка сегодня

COL_BG = (4, 16, 13)
COL_TRACK = (12, 43, 36)
COL_FAINT = (30, 68, 59)
COL_TEXT = (214, 238, 232)
COL_DIM = (120, 160, 152)
COL_ACCENT = (127, 209, 192)
COL_SEL = (24, 74, 64)

FONT_DIR = r"C:\Windows\Fonts"
FONT_MONO = os.path.join(FONT_DIR, "consola.ttf")
FONT_MONO_B = os.path.join(FONT_DIR, "consolab.ttf")


def font(path, px):
    try:
        return ImageFont.truetype(path, px)
    except OSError:
        return ImageFont.load_default()


# --- геометрия Вороного ------------------------------------------------------


def disc_polygon(r, steps=144):
    return [(r * math.cos(2 * math.pi * k / steps), r * math.sin(2 * math.pi * k / steps))
            for k in range(steps)]


def clip_halfplane(poly, a, b, c):
    """Оставить в выпуклом многоугольнике часть a*x + b*y <= c."""
    out = []
    n = len(poly)
    for i in range(n):
        p = poly[i]
        q = poly[(i + 1) % n]
        dp = a * p[0] + b * p[1] - c
        dq = a * q[0] + b * q[1] - c
        if dp <= 0.0:
            out.append(p)
        if (dp < 0.0 < dq) or (dq < 0.0 < dp):
            t = dp / (dp - dq)
            out.append((p[0] + t * (q[0] - p[0]), p[1] + t * (q[1] - p[1])))
    return out


def voronoi(sites, weights=None, r=R_ZONE):
    """
    Ячейка каждой точки: пересечение диска с полуплоскостями «ближе к своей, чем к чужой».

    С весами это power diagram: граница смещается на (w_i - w_j)/2, но остаётся прямой, так
    что ячейка остаётся выпуклой — и попадание в неё остаётся одним сравнением расстояний.
    """
    w = weights or [0.0] * len(sites)
    cells = []
    for i, si in enumerate(sites):
        poly = disc_polygon(r)
        for j, sj in enumerate(sites):
            if i == j:
                continue
            # 2*(sj - si)*p <= |sj|^2 - |si|^2 + wi - wj
            a = 2.0 * (sj[0] - si[0])
            b = 2.0 * (sj[1] - si[1])
            c = (sj[0] ** 2 + sj[1] ** 2) - (si[0] ** 2 + si[1] ** 2) + w[i] - w[j]
            poly = clip_halfplane(poly, a, b, c)
            if len(poly) < 3:
                break
        cells.append(poly)
    return cells


def area(poly):
    s = 0.0
    for i in range(len(poly)):
        x1, y1 = poly[i]
        x2, y2 = poly[(i + 1) % len(poly)]
        s += x1 * y2 - x2 * y1
    return abs(s) / 2.0


def inside(poly, x, y):
    sgn = 0
    for i in range(len(poly)):
        x1, y1 = poly[i]
        x2, y2 = poly[(i + 1) % len(poly)]
        d = (x2 - x1) * (y - y1) - (y2 - y1) * (x - x1)
        if abs(d) < 1e-9:
            continue
        s = 1 if d > 0 else -1
        if sgn == 0:
            sgn = s
        elif s != sgn:
            return False
    return True


def edge_distance(poly, x, y):
    best = 1e9
    for i in range(len(poly)):
        x1, y1 = poly[i]
        x2, y2 = poly[(i + 1) % len(poly)]
        dx, dy = x2 - x1, y2 - y1
        L = math.hypot(dx, dy)
        if L < 1e-9:
            continue
        d = abs(dx * (y1 - y) - dy * (x1 - x)) / L
        best = min(best, d)
    return best


def chebyshev_centre(poly, step=3.0):
    """Точка внутри, максимально удалённая от краёв: там подпись читается и не лезет на край."""
    xs = [p[0] for p in poly]
    ys = [p[1] for p in poly]
    best = (None, -1.0)
    x = min(xs)
    while x <= max(xs):
        y = min(ys)
        while y <= max(ys):
            if inside(poly, x, y):
                d = edge_distance(poly, x, y)
                if d > best[1]:
                    best = ((x, y), d)
            y += step
        x += step
    if best[0] is None:
        return (0.0, 0.0), 0.0

    # уточнение вокруг найденной точки
    bx, by = best[0]
    fine = (best[0], best[1])
    x = bx - step
    while x <= bx + step:
        y = by - step
        while y <= by + step:
            if inside(poly, x, y):
                d = edge_distance(poly, x, y)
                if d > fine[1]:
                    fine = ((x, y), d)
            y += 0.5
        x += 0.5
    return fine


def polygon_perimeter(poly):
    return sum(math.hypot(poly[(i + 1) % len(poly)][0] - poly[i][0],
                          poly[(i + 1) % len(poly)][1] - poly[i][1])
               for i in range(len(poly)))


# --- отрисовка ---------------------------------------------------------------


def px(v):
    return int(round((v + C) * S))


def draw_ring(d, bright):
    """Обод: дорожка 162..176, яркая часть — значение. bright: список (a0, a1, col)."""
    box = [(-R_RIM_OUT) * S + SIZE * S / 2, (-R_RIM_OUT) * S + SIZE * S / 2,
           R_RIM_OUT * S + SIZE * S / 2, R_RIM_OUT * S + SIZE * S / 2]
    d.ellipse(box, outline=COL_TRACK, width=(R_RIM_OUT - R_RIM_IN) * S)
    for a0, a1, col in bright:
        d.arc(box, a0, a1, fill=col, width=(R_RIM_OUT - R_RIM_IN + 0) * S)


def draw(draw_fn):
    img = Image.new("RGB", (SIZE * S, SIZE * S), COL_BG)
    d = ImageDraw.Draw(img)
    draw_fn(img, d)
    return img


def arrows():
    """Разделители секторов 2 px цветом фона: как на приборе сейчас."""
    pass


def render_voronoi(page, knobs, sites, weights=None, hit=False, show_cells=True):
    """
    knobs: [(имя, значение, угол_сектора), ...]
    sites: координаты центров (в системе прибора, от центра)
    """
    cells = voronoi(sites, weights)
    centres = [chebyshev_centre(poly) for poly in cells]

    f_name = font(FONT_MONO, 15 * S)
    f_val = font(FONT_MONO_B, 22 * S)

    def body(img, d):
        # ячейки: заливка выбранной, края — тонкой линией
        for i, poly in enumerate(cells):
            pts = [(px(x), px(y)) for x, y in poly]
            sel = i == 0
            if sel:
                d.polygon(pts, fill=COL_SEL)
            if show_cells:
                d.line(pts + [pts[0]], fill=COL_FAINT if not sel else COL_ACCENT, width=1 * S)

        # диск страницы и обод
        d.ellipse([px(-R_HUB), px(-R_HUB), px(R_HUB), px(R_HUB)], fill=COL_BG)
        draw_ring(d, [(0, 90, COL_ACCENT), (90, 180, COL_TRACK), (180, 270, COL_TRACK), (270, 360, COL_TRACK)])

        # подписи в чебышёвских центрах
        for i, (name, val, a) in enumerate(knobs):
            (cx, cy), room = centres[i]
            nm = name
            d.text((px(cx), px(cy) - 13 * S), nm, font=f_name, fill=COL_DIM, anchor="mm")
            d.text((px(cx), px(cy) + 8 * S), val, font=f_val, fill=COL_TEXT, anchor="mm")

        d.text((px(0), px(0)), page, font=font(FONT_MONO_B, 20 * S), fill=COL_TEXT, anchor="mm")
        return img

    return draw(body), cells, centres


def render_current(page, knobs, r_anchor=96):
    """Сегодняшняя раскладка: подписи на выносках радиуса 96, место под плитку 112x48."""
    f_name = font(FONT_MONO, 15 * S)
    f_val = font(FONT_MONO_B, 22 * S)

    def body(img, d):
        box = [(-R_RIM_OUT) * S + SIZE * S / 2, (-R_RIM_OUT) * S + SIZE * S / 2,
               R_RIM_OUT * S + SIZE * S / 2, R_RIM_OUT * S + SIZE * S / 2]
        d.ellipse(box, outline=COL_TRACK, width=(R_RIM_OUT - R_RIM_IN) * S)
        d.arc(box, 0, 90, fill=COL_ACCENT, width=(R_RIM_OUT - R_RIM_IN) * S)
        d.ellipse([px(-R_HUB), px(-R_HUB), px(R_HUB), px(R_HUB)], fill=COL_BG)

        n = len(knobs)
        for i, (name, val, a) in enumerate(knobs):
            ax = r_anchor * math.cos(math.radians(a))
            ay = r_anchor * math.sin(math.radians(a))
            # занятое плиткой место
            d.rectangle([px(ax - PANEL_W / 2), px(ay - PANEL_H / 2),
                         px(ax + PANEL_W / 2), px(ay + PANEL_H / 2)],
                        outline=COL_TRACK, width=1)
            d.line([px(R_HUB * math.cos(math.radians(a))), px(R_HUB * math.sin(math.radians(a))),
                    px(ax), px(ay)], fill=COL_TRACK, width=1)
            d.text((px(ax), px(ay) - 12 * S), name, font=f_name, fill=COL_DIM, anchor="mm")
            d.text((px(ax), px(ay) + 8 * S), val, font=f_val, fill=COL_TEXT, anchor="mm")

        d.text((px(0), px(0)), page, font=font(FONT_MONO_B, 20 * S), fill=COL_TEXT, anchor="mm")
        return img

    return draw(body)


def render_hit(knobs, sites, weights=None):
    """Карта попаданий: цвет пикселя — ближайший центр. Дыр быть не может по построению."""
    cells = voronoi(sites, weights)
    palette = [(127, 209, 192), (214, 168, 92), (140, 160, 235), (200, 120, 200),
               (120, 200, 120), (230, 130, 120), (160, 220, 220), (220, 220, 120)]

    img = Image.new("RGB", (SIZE * S, SIZE * S), COL_BG)
    d = ImageDraw.Draw(img)
    for i, poly in enumerate(cells):
        pts = [(px(x), px(y)) for x, y in poly]
        d.polygon(pts, fill=palette[i % len(palette)], outline=COL_BG, width=S)
    d.ellipse([px(-R_HUB), px(-R_HUB), px(R_HUB), px(R_HUB)], fill=(60, 60, 60))

    # сетка точек: каждая точка — пиксель прибора, цвет её ячейки уже показан заливкой,
    # поэтому здесь только подтверждение, что заливка и «ближайший центр» совпадают
    bad = 0
    for y in range(-SIZE // 2, SIZE // 2, 4):
        for x in range(-SIZE // 2, SIZE // 2, 4):
            if x * x + y * y > R_ZONE * R_ZONE:
                continue
            best, bi = 1e18, -1
            for i, (sx, sy) in enumerate(sites):
                dd = (x - sx) ** 2 + (y - sy) ** 2 - (weights[i] if weights else 0.0)
                if dd < best:
                    best, bi = dd, i
            if not inside(cells[bi], x, y):
                bad += 1
    return img, bad


def report(name, cells, centres):
    print("  " + name)
    need = math.hypot(PANEL_W / 2.0, PANEL_H / 2.0)   # половина диагонали плитки
    total = 0.0
    perim = 0.0
    for i, poly in enumerate(cells):
        a = area(poly)
        total += a
        perim += polygon_perimeter(poly)
        (cx, cy), room = centres[i]
        fit = "влезает" if room >= need else "ТЕСНО"
        print("    ячейка %d: %6.0f px2  запас до края %5.1f px (нужно %.1f)  %s  центр (%+.1f, %+.1f)"
              % (i, a, room, need, fit, cx, cy))
    print("    всего %.0f px2, краёв %.0f px, контур всей раскладки ~%.0f px"
          % (total, perim, perim / 2.0))
    return total, perim


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    out = os.path.join(here, "out")
    os.makedirs(out, exist_ok=True)

    # шесть ручек: углы секторов при RIM_6 (360/6)
    drone6 = [("WAVE", "SAW", 270), ("WIDTH", "50 %", 330), ("LOW", "40 %", 30),
              ("MID", "28 %", 90), ("HIGH", "22 %", 150), ("PITCH", "-12 st", 210)]
    lead4 = [("SCALE", "AEOLIAN", 270), ("ROOT", "C4", 0), ("DENSITY", "31 %", 90),
             ("OCTAVE", "24 %", 180)]

    def circle_sites(n, r, phase=0.0):
        return [(r * math.cos(math.radians(phase + 360.0 * k / n)),
                 r * math.sin(math.radians(phase + 360.0 * k / n))) for k in range(n)]

    print("  6 ручек, центры на радиусе 96 (как сейчас):")
    img, cells, cen = render_voronoi("OBOD", drone6, circle_sites(6, 96, 270))
    img.save(os.path.join(out, "drone6-r96.png"))
    report("drone6-r96", cells, cen)

    print("  6 ручек, центры на радиусе 112:")
    img, cells, cen = render_voronoi("OBOD", drone6, circle_sites(6, 112, 270))
    img.save(os.path.join(out, "drone6-r112.png"))
    report("drone6-r112", cells, cen)

    print("  4 ручки, центры на радиусе 100:")
    img, cells, cen = render_voronoi("LEAD", lead4, circle_sites(4, 100, 270))
    img.save(os.path.join(out, "lead4-r100.png"))
    report("lead4-r100", cells, cen)

    print("  6 ручек, веса: длинным подписям больше места:")
    w = [0, 0, 0, 0, 0, 2400]
    img, cells, cen = render_voronoi("OBOD", drone6, circle_sites(6, 100, 270), weights=w)
    img.save(os.path.join(out, "drone6-weighted.png"))
    report("drone6-weighted", cells, cen)

    print("  сегодняшняя раскладка, для сравнения:")
    render_current("OBOD", drone6).save(os.path.join(out, "current.png"))

    hit, bad = render_hit(drone6, circle_sites(6, 100, 270))
    hit.save(os.path.join(out, "hit-6.png"))
    print("  карта попаданий: расхождений между «ближайшим центром» и ячейкой: %d" % bad)

    print("  кадры в " + out)


if __name__ == "__main__":
    main()
