"""Cell areas for the map's Voronoi mosaic, and two ways of evening them out.

The mosaic covers the whole round screen, so the cells' shares of it are what the eye reads as
"equal". Plain Voronoi --- equal weights, points only --- cannot get them equal: the cells on the
rim are cut by the screen's edge, and moving a point does not change how much of the disc its cell
is allowed. Weights can: a point with a larger weight takes area without moving.

    python tools/voronoi-prototype/areas.py            # what the map has now
    python tools/voronoi-prototype/areas.py --lloyd     # and after 300 Lloyd steps
    python tools/voronoi-prototype/areas.py --weights   # and with weights solved for equal areas
"""

import math
import sys

CELL_R = 180.0
GON = 64

# The table as it stands in nav_measure(), in tenths of a pixel.
SITES = [(2, 0), (2, -662), (518, -412), (645, 148), (287, 595), (-286, 596), (-643, 148),
         (-514, -411), (-2, -1246), (523, -1085), (976, -774), (1175, -263), (1214, 283),
         (938, 754), (537, 1124), (-2, 1204), (-541, 1123), (-941, 751), (-1214, 279),
         (-1173, -265), (-976, -773), (-525, -1083)]
NAMES = ["PERC", "TONE", "ENV", "PSEQ", "ARP", "EUCL", "GEN", "LEAD", "DRONE", "FLTR", "MOD",
         "MSTR", "LVLS", "REVS", "CHRS", "DELS", "SYS", "OPT", "PRST", "CHOR", "DLY", "REV"]


def clip(poly, a, b, c):
    out = []
    n = len(poly)
    for i in range(n):
        p = poly[i]
        q = poly[(i + 1) % n]
        dp = a * p[0] + b * p[1] - c
        dq = a * q[0] + b * q[1] - c
        if dp <= 0:
            out.append(p)
        if (dp < 0 < dq) or (dq < 0 < dp):
            t = dp / (dp - dq)
            out.append((p[0] + t * (q[0] - p[0]), p[1] + t * (q[1] - p[1])))
    return out


def simplify(poly, tol=0.5):
    n = len(poly)
    keep = []
    for i in range(n):
        ax, ay = poly[i - 1]
        bx, by = poly[i]
        cx, cy = poly[(i + 1) % n]
        ex, ey = cx - ax, cy - ay
        ln = math.hypot(ex, ey)
        if ln > 0.01 and abs(ex * (by - ay) - ey * (bx - ax)) / ln <= tol:
            continue
        keep.append((bx, by))
    return keep


def build(points, weights=None):
    weights = weights or [0.0] * len(points)
    out = []
    for i, s in enumerate(points):
        poly = [(CELL_R * math.cos(2 * math.pi * k / GON),
                 CELL_R * math.sin(2 * math.pi * k / GON)) for k in range(GON)]
        for j, t in enumerate(points):
            if i == j:
                continue
            a = 2 * (t[0] - s[0])
            b = 2 * (t[1] - s[1])
            c = (t[0] ** 2 + t[1] ** 2) - (s[0] ** 2 + s[1] ** 2) + weights[j] - weights[i]
            poly = clip(poly, a, b, c)
        out.append(simplify(poly))
    return out


def area(poly):
    a = 0.0
    for i in range(len(poly)):
        x0, y0 = poly[i]
        x1, y1 = poly[(i + 1) % len(poly)]
        a += x0 * y1 - x1 * y0
    return a / 2.0


def centroid(poly):
    a = area(poly)
    if abs(a) < 1.0:
        return None
    mx = my = 0.0
    for i in range(len(poly)):
        x0, y0 = poly[i]
        x1, y1 = poly[(i + 1) % len(poly)]
        cr = x0 * y1 - x1 * y0
        mx += (x0 + x1) * cr
        my += (y0 + y1) * cr
    return (mx / (6 * a), my / (6 * a))


def clearance(poly, c):
    best = 1e9
    for i in range(len(poly)):
        ax, ay = poly[i]
        bx, by = poly[(i + 1) % len(poly)]
        ex, ey = bx - ax, by - ay
        ln = math.hypot(ex, ey)
        if ln < 0.01:
            continue
        best = min(best, (ex * (c[1] - ay) - ey * (c[0] - ax)) / ln)
    return best


def report(tag, points, weights=None, show=False):
    cs = build(points, weights)
    ars = [abs(area(p)) for p in cs]
    clr = []
    for p in cs:
        c = centroid(p)
        if c:
            clr.append(clearance(p, c))
    print("%-10s cells %2d  area %4d..%4d px2  spread %.0f%%  clearance %d..%d px"
          % (tag, len(ars), min(ars), max(ars), 100.0 * (max(ars) - min(ars)) / (sum(ars) / len(ars)),
             min(clr), max(clr)))
    if show:
        for n, a, c in zip(NAMES, ars, clr):
            print("   %-6s %5d px2  %3d px" % (n, a, c))
    return ars, clr, cs


def lloyd(points, steps):
    pts = list(points)
    for _ in range(steps):
        cs = build(pts)
        for i, p in enumerate(cs):
            c = centroid(p)
            if c is None:
                continue
            x = 0.9 * pts[i][0] + 0.1 * c[0]
            y = 0.9 * pts[i][1] + 0.1 * c[1]
            # The points stay where the sections are, but not further out than the mosaic's field.
            r = math.hypot(x, y)
            if r > CELL_R * 0.78:
                x *= CELL_R * 0.78 / r
                y *= CELL_R * 0.78 / r
            pts[i] = (x, y)
    return pts


def solve_weights(points, steps=30, verbose=False):
    """Solve the weights so that every cell has the same area.

    A weight is an addition to the squared distance, so raising one shrinks its own cell and grows
    its neighbours': the areas are a coupled system. The Jacobian is taken numerically \u2014 twenty-two
    extra builds an iteration, which is nothing at this size \u2014 and the step is the Newton one,
    damped because a cell can lose a vertex and the answer jumps.
    """
    n = len(points)
    w = [0.0] * n
    target = math.pi * CELL_R * CELL_R / n

    for it in range(steps):
        ars = [abs(area(p)) for p in build(points, w)]
        err = [target - a for a in ars]
        worst = max(abs(e) for e in err)
        if verbose:
            print("    iter %2d  worst %6.1f px2" % (it, worst))
        if worst < 1.0:
            break

        # Only the DIFFERENCES of the weights mean anything: adding one constant to all of them
        # moves every seam by nothing. So the first weight is pinned and the rest are solved for.
        # dA_i/dw_j by a two-sided difference; a weight is in px2, an area too.
        h = 20.0
        J = []
        for j in range(1, n):
            wp = list(w)
            wm = list(w)
            wp[j] += h
            wm[j] -= h
            ap = [abs(area(p)) for p in build(points, wp)]
            am = [abs(area(p)) for p in build(points, wm)]
            J.append([(ap[i] - am[i]) / (2 * h) for i in range(1, n)])

        A = [[J[j][i] for j in range(n - 1)] for i in range(n - 1)]
        step = gauss(A, err[1:])
        if step is None:
            break

        # Damped: a full Newton step overshoots while cells are still changing shape.
        lam = 0.8
        for i in range(1, n):
            w[i] += lam * step[i - 1]

    # Centred, so that the table carries small numbers; the mosaic does not notice.
    m = sum(w) / n
    return [x - m for x in w]


def gauss(A, b):
    n = len(b)
    M = [row[:] + [b[i]] for i, row in enumerate(A)]
    for c in range(n):
        p = max(range(c, n), key=lambda r: abs(M[r][c]))
        if abs(M[p][c]) < 1e-9:
            return None
        M[c], M[p] = M[p], M[c]
        for r in range(n):
            if r == c:
                continue
            f = M[r][c] / M[c][c]
            for k in range(c, n + 1):
                M[r][k] -= f * M[c][k]
    return [M[i][n] / M[i][i] for i in range(n)]


def main():
    pts = [(x / 10.0, y / 10.0) for x, y in SITES]
    report("now", pts)

    if "--lloyd" in sys.argv:
        pts2 = lloyd(pts, 300)
        report("lloyd", pts2)
        print()
        for n, p in zip(NAMES, pts2):
            print("   %-6s %6.1f %7.1f" % (n, p[0], p[1]))

    if "--weights" in sys.argv:
        w = solve_weights(pts, verbose=True)
        ars, clr, cs = report("weights", pts, w, show=True)
        print()
        print("    table with weights, tenths and px2:")
        order = ["PERC", "TONE", "ENV", "PSEQ", "ARP", "EUCL", "GEN", "LEAD", "DRONE", "FLTR",
                 "MOD", "MSTR", "LVLS", "REVS", "CHRS", "DELS", "SYS", "OPT", "PRST", "CHOR",
                 "DLY", "REV"]
        idx = {n: i for i, n in enumerate(NAMES)}
        for n in order:
            i = idx[n]
            print("    [%-6s] = { %5d, %6d, %6d },"
                  % (n, round(pts[i][0] * 10), round(pts[i][1] * 10), round(w[i])))
        print()
        print("    weights %d..%d px2" % (round(min(w)), round(max(w))))


if __name__ == "__main__":
    main()
