/*
 * Runs editor.html's own script outside a browser, so that the editor's solver can be checked
 * against the numbers the device reports.
 *
 * The page is read, its <script> lifted out, and the handful of DOM things it touches are stubbed
 * with objects that swallow everything. Then the solver is asked for the weights of the shipped
 * arrangement, and the areas it produces are printed next to the ones nav_measure() logs.
 *
 *     node tools/voronoi-prototype/editor-check.js
 */

const fs = require("fs");
const path = require("path");
const vm = require("vm");

const file = path.join(__dirname, "editor.html");
const html = fs.readFileSync(file, "utf8");
const m = html.match(/<script>([\s\S]*?)<\/script>/);
if (!m) {
  console.error("no <script> in " + file);
  process.exit(1);
}

function stubEl() {
  return {
    textContent: "",
    onclick: null,
    style: {},
    getContext: () => ctx,
    getBoundingClientRect: () => ({ left: 0, top: 0, width: 720, height: 720 }),
    addEventListener: () => {},
    setPointerCapture: () => {},
    toDataURL: () => ""
  };
}

const ctx = new Proxy({}, {
  get: (t, k) => {
    if (k === "measureText") return () => ({ width: 40 });
    return () => {};
  },
  set: () => true
});

const sandbox = {
  document: { getElementById: () => stubEl(), createElement: () => stubEl() },
  window: { addEventListener: () => {} },
  console,
  Math,
  String,
  Array,
  Number
};
sandbox.globalThis = sandbox;

vm.createContext(sandbox);
vm.runInContext(m[1], sandbox, { filename: "editor.html" });

const out = [];
sandbox.__report = (line) => out.push(line);

vm.runInContext(`
  __report("shipped: " + areasOf(weights).map((a) => Math.round(a)).sort((a, b) => a - b)
    .filter((a, i, all) => i === 0 || i === all.length - 1).join("..") + " px2");
  const before = weights.slice();
  solveAreas();
  __report("solved:  " + areasOf(weights).map((a) => Math.round(a)).sort((a, b) => a - b)
    .filter((a, i, all) => i === 0 || i === all.length - 1).join("..") + " px2");
  const diff = Math.max(...weights.map((w, i) => Math.abs(w - before[i])));
  __report("weights moved by at most " + diff.toFixed(1) + " px2 from the shipped table");
  const clears = cells.map((p, i) => clearance(p, labelAt[i][0], labelAt[i][1]));
  __report("label room " + Math.min(...clears).toFixed(1) + ".." + Math.max(...clears).toFixed(1) + " px");
`, sandbox, { filename: "check" });

console.log(out.join("\n"));
