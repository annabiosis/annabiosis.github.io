"""Put the map on one palette ladder: cell 800, the cell you are on 600, its name 400.

Before this the mosaic took its cell colour from the instrument's `tile` step (900 for most
families, 700 for the presets) and its names from `ink` (200, sometimes 100), and the section you
were standing on was marked by a frame inside the cell. Three things follow from the ladder that
this replaces them with:

  * the cells are one Material step brighter than they were (800 against 900), so they sit less
    harshly on the near-black surface;
  * the names drop from 200 to 400, three steps down from their cell instead of six, which is the
    loudness that was being complained about;
  * the section you are on is its whole cell at 600 rather than a frame around it, which is a
    change of fill and not one more line to read.

The rhythm's flash has to move too: it was painted with the instrument's `rim` step, and for the
green family `rim` IS the new cell colour (both 800), so a flash would have been invisible on the
percussion. It goes to 900, one step BELOW the cell: the name stays legible on it (400 on 900 is
about five to one), which a bright flash would not allow.

Run from the repository root:
    python tools/voronoi-prototype/apply_tones.py
"""

import io
import os
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
SRC = os.path.join(ROOT, "components", "synth_ui", "src", "synth_ui.c")

MARKS_OLD = """/*
 * The marks inside a cell. Nothing in a mosaic can grow, so the frame that used to mark the
 * current section by growing its tile to the full cell is now a frame inside the cell; the macro's
 * red keeps the outer ring and the current section takes the one inside it, so one cell can wear
 * both marks and neither can hide the other.
 */
#define NAV_MARK_INSET      3   /* px inside the cell's edge, where the macro's ring sits */
#define NAV_MARK_GAP        3   /* and how far the current section's frame is inside that */
#define NAV_MARK_W          2   /* the macro's ring, the rim's own mark thickness */
#define NAV_SELF_W          3   /* the current section's frame, wider: it is the place you are */
"""

MARKS_NEW = """/*
 * The macro's ring: a border in COL_MACRO_RIM red, three pixels inside the cell's own edge.
 *
 * It is the only frame left on the map. The section you are standing on is marked by filling its
 * whole cell one palette step lighter (see MAP_TONE), which says "here" with the tile itself
 * instead of with one more line drawn on it; the macro's ring answers a different question — "is
 * this section wired into the macro" — and a cell can be both, because a fill and a border do not
 * compete for the same pixels.
 */
#define NAV_MARK_INSET      3   /* px inside the cell's edge, where the macro's ring sits */
#define NAV_MARK_W          2   /* the ring, the rim's own mark thickness */
"""

TONES = """/*
 * The map's own three steps of each family's palette: the cell, the cell you are standing on, and
 * the name on it. This is where the mosaic takes every colour it uses, and the instrument's table
 * above is left alone — the rim, the sectors and the page dots keep the steps they were measured
 * with.
 *
 * One ladder, three depths: 800 for a cell, 600 for the one you are on, 400 for its name, and 900
 * for the rhythm's flash. The names are DARKER than the 200 they used to be, on purpose: six steps
 * between a cell and its name was the loudest thing on the map. Three steps still reads at 14 px
 * and stops competing with the cells.
 *
 * The flash goes one step BELOW the cell rather than above it. Two reasons, both measured: the
 * green family's rim (the step the flash used to take) is 800, which is the new cell colour, so a
 * flash would have been invisible on the percussion; and a flash bright enough to see (500) leaves
 * 400-on-500 at about one and a fifth to one, which would wipe the name out for the length of every
 * hit. A dip to 900 keeps the name at about five to one and still changes the cell for the beat.
 *
 * The presets keep their own ramp, one step lighter than the settings' grey — 700/500/300 against
 * 800/600/400 — so a place you go still reads as a different kind of tile from a page you tune.
 */
typedef struct {
    uint32_t cell;   /* 800: the tile */
    uint32_t here;   /* 600: the tile you are standing on */
    uint32_t tag;    /* 400: the name on it */
    uint32_t flash;  /* 900: the tile while its part is sounding */
} nav_map_tone_t;

static const nav_map_tone_t MAP_TONE[GRP_COUNT] = {
    /* cell      here      tag       flash */
    { 0x1565C0, 0x1E88E5, 0x42A5F5, 0x0D47A1 },   /* blue    800 / 600 / 400 / 900 */
    { 0x6A1B9A, 0x8E24AA, 0xAB47BC, 0x4A148C },   /* violet  800 / 600 / 400 / 900 */
    { 0x00695C, 0x00897B, 0x26A69A, 0x004D40 },   /* teal    800 / 600 / 400 / 900 */
    { 0x2E7D32, 0x43A047, 0x66BB6A, 0x1B5E20 },   /* green   800 / 600 / 400 / 900 */
    { 0xAD1457, 0xD81B60, 0xEC407A, 0x880E4F },   /* pink    800 / 600 / 400 / 900 */
    { 0x4E342E, 0x6D4C41, 0x8D6E63, 0x3E2723 },   /* brown   800 / 600 / 400 / 900 */
    { 0x37474F, 0x546E7A, 0x78909C, 0x263238 },   /* grey    800 / 600 / 400 / 900 */
    { 0x455A64, 0x607D8B, 0x90A4AE, 0x37474F },   /* presets 700 / 500 / 300 / 800 */
};
"""

TONES_ANCHOR = """};

/*
 * The family colour is needed on five different surfaces"""

OVERLAY_OLD = """/*
 * The map's moving parts: the rhythm's flash, the macro's rings and the frame of the section you
 * are standing on, painted OVER the baked image.
 *
 * They are not baked because they change: a page change would then cost a full bake, and the flash
 * would cost one on every hit. Drawn, a flash is three cells and a page change is two, and the clip
 * decides which of them are touched — a cell whose box misses it is skipped before anything is
 * built.
 */"""

OVERLAY_NEW = """/*
 * The map's moving parts: the rhythm's flash, the section you are standing on, and the macro's
 * rings, painted OVER the baked image.
 *
 * They are not baked because they change: a page change would then cost a full bake, and the flash
 * would cost one on every hit. Drawn, a flash is three cells and a page change is two, and the clip
 * decides which of them are touched — a cell whose box misses it is skipped before anything is
 * built.
 *
 * A cell painted here is painted with the cell itself, not with a mark on it: the fill follows the
 * cell's own polygon, pushed a pixel out past its edges so that the fan of triangles it is drawn as
 * has no hairline, and the cut is drawn back over that pixel afterwards. What the fill covers is
 * the baked image, which means the cell it leaves behind needs nothing done to it: repainting that
 * box shows the picture again and the cell is its own colour once more.
 */"""

FILL_OLD = """    /*
     * The flash: the cell filled with its family's rim — the step a turned sector's hairline is
     * drawn in — so that "this part is sounding" is said in a colour the map already uses.
     *
     * Filled with a fan of triangles, which is the one thing LVGL can fill without the vector
     * renderer, and every triangle is pushed a pixel out past its own edges: two triangles that
     * share a chord each composite on their own, and without the overlap their two antialiased
     * coverages add up to less than one, which is the hairline a fan is known for. The cell's own
     * cut is drawn again afterwards, because that pixel of overlap lands in it.
     */
    for (int i = 0; i < (int)PAGE_COUNT; i++) {
        if (!s_nav_glow[i] || !nav_cell_screen_box(i, &box)) {
            continue;
        }
        if (!viz_area_hits(&box, &clip)) {
            continue;
        }

        const int n = s_nav_cell_n[i];
        const nav_group_color_t *g = &GROUP_COLOR[PAGES[i].group];

        for (int k = 0; k < n; k++) {
            in[k * 2] = (float)cx + s_nav_cell[i][k * 2];
            in[k * 2 + 1] = (float)cy + s_nav_cell[i][k * 2 + 1];
        }

        lv_draw_triangle_dsc_t tri;
        lv_draw_triangle_dsc_init(&tri);
        tri.opa = LV_OPA_COVER;
        tri.color = lv_color_hex(g->rim);
"""

FILL_NEW = """    /*
     * The cells that are not their own colour at the moment: the three the rhythm is sounding, and
     * the one you are standing on. A flash wins over "here", because it is the momentary thing.
     *
     * Filled with a fan of triangles, which is the one thing LVGL can fill without the vector
     * renderer, and every triangle is pushed a pixel out past its own edges: two triangles that
     * share a chord each composite on their own, and without the overlap their two antialiased
     * coverages add up to less than one, which is the hairline a fan is known for. The cell's own
     * cut is drawn again afterwards, because that pixel of overlap lands in it.
     */
    for (int i = 0; i < (int)PAGE_COUNT; i++) {
        const bool flash = s_nav_glow[i];
        const bool here = (i == (int)s_page);

        if ((!flash && !here) || !nav_cell_screen_box(i, &box)) {
            continue;
        }
        if (!viz_area_hits(&box, &clip)) {
            continue;
        }

        const int n = s_nav_cell_n[i];
        const nav_map_tone_t *tone = &MAP_TONE[PAGES[i].group];

        for (int k = 0; k < n; k++) {
            in[k * 2] = (float)cx + s_nav_cell[i][k * 2];
            in[k * 2 + 1] = (float)cy + s_nav_cell[i][k * 2 + 1];
        }

        lv_draw_triangle_dsc_t tri;
        lv_draw_triangle_dsc_init(&tri);
        tri.opa = LV_OPA_COVER;
        tri.color = lv_color_hex(flash ? tone->flash : tone->here);
"""

MARKS_LOOP_OLD = """    /*
     * The two marks, each inside its own cell. The questions they answer are different ones — "is
     * this section wired into the macro" and "am I standing here" — so they are two frames and not
     * two shades of one, and a section can wear both at once.
     */
    for (int i = 0; i < (int)PAGE_COUNT; i++) {
        const bool macros = page_has_macro(&PAGES[i]);
        const bool self = (i == (int)s_page);

        if (!macros && !self) {
            continue;
        }
        if (!nav_cell_screen_box(i, &box)) {
            continue;
        }
        if (!viz_area_hits(&box, &clip)) {
            continue;
        }

        if (macros) {
            nav_ring(layer, i, cx, cy, NAV_MARK_INSET, NAV_MARK_W, COL_MACRO_RIM);
        }

        if (self) {
            nav_ring(layer, i, cx, cy, NAV_MARK_INSET + NAV_MARK_GAP, NAV_SELF_W,
                     GROUP_COLOR[PAGES[i].group].ink);
        }
    }
}"""

MARKS_LOOP_NEW = """    /* The macro's red, in the cells that are wired into it: the one frame the map still draws. */
    for (int i = 0; i < (int)PAGE_COUNT; i++) {
        if (!page_has_macro(&PAGES[i])) {
            continue;
        }
        if (!nav_cell_screen_box(i, &box)) {
            continue;
        }
        if (!viz_area_hits(&box, &clip)) {
            continue;
        }

        nav_ring(layer, i, cx, cy, NAV_MARK_INSET, NAV_MARK_W, COL_MACRO_RIM);
    }
}"""

DOC_OLD = '''/*
 * The current section, the sections wired into the macro, and the family's colour behind the whole
 * curtain.
 *
 * The mosaic draws the tiles, so what is left here is what the tiles are painted FROM: the curtain
 * takes the current family's tint, the names take their family's ink, and the two marks — the
 * current section's frame and the macro's red — are painted by nav_marks_draw_cb(), which reads
 * s_page and page_has_macro() itself rather than a copy of either. Repainting the mosaic is
 * therefore the whole of "the marks moved".'''

DOC_NEW = '''/*
 * The names, the family's colour behind the whole curtain, and a flash left over from last time.
 *
 * The mosaic draws the cells themselves, so what is left here is their colour: the curtain takes
 * the current family's tint and the names take their family's name step. The two things that move
 * — the cell you are standing on and the macro's red — are painted by nav_marks_draw_cb(), which
 * reads s_page and page_has_macro() itself rather than a copy of either, so repainting two cells is
 * the whole of "the mark moved".'''

BAKE_OLD = "        nav_fill(&all, in, n, GROUP_COLOR[PAGES[i].group].tile);\n"
BAKE_NEW = "        nav_fill(&all, in, n, MAP_TONE[PAGES[i].group].cell);\n"

LABEL_OLD = """    for (int i = 0; i < (int)PAGE_COUNT; i++) {
        const nav_group_color_t *g = &GROUP_COLOR[PAGES[i].group];

        /* A tile is a solid cell of its family's colour and nothing else: no rim of its own. The
         * colour IS the tile, which is the only way six hues stay nameable at this size — six
         * outlines of six hues would read as six kinds of border rather than as six colours. */
        if (s_nav_label[i] != NULL) {
            text_color(s_nav_label[i], g->ink);
        }
"""
LABEL_NEW = """    for (int i = 0; i < (int)PAGE_COUNT; i++) {
        /* A cell is one solid step of its family's colour and nothing else: no rim of its own. The
         * colour IS the cell, which is the only way six hues stay nameable at this size — six
         * outlines of six hues would read as six kinds of border rather than as six colours. The
         * name is the next step down from the cell (400 against 800), which is the whole of its
         * contrast. */
        if (s_nav_label[i] != NULL) {
            text_color(s_nav_label[i], MAP_TONE[PAGES[i].group].tag);
        }
"""


def one(text, old, new, label):
    n = text.count(old)
    if n != 1:
        raise SystemExit("%s: %d occurrences" % (label, n))
    print("%-9s %5d -> %5d bytes" % (label, len(old), len(new)))
    return text.replace(old, new)


def main():
    with io.open(SRC, "r", encoding="utf-8", newline="\n") as fh:
        text = fh.read()

    text = one(text, MARKS_OLD, MARKS_NEW, "marks")
    text = one(text, TONES_ANCHOR, TONES + TONES_ANCHOR, "tones")
    text = one(text, OVERLAY_OLD, OVERLAY_NEW, "overlay")
    text = one(text, FILL_OLD, FILL_NEW, "fill")
    text = one(text, MARKS_LOOP_OLD, MARKS_LOOP_NEW, "rings")
    text = one(text, BAKE_OLD, BAKE_NEW, "bake")
    text = one(text, DOC_OLD, DOC_NEW, "doc")
    text = one(text, LABEL_OLD, LABEL_NEW, "labels")

    for dead in ("NAV_MARK_GAP", "NAV_SELF_W"):
        if dead in text:
            raise SystemExit("leftover %s" % dead)

    # The family's colour is no longer read on the map; the loop's `g` was kept for the label ink.
    if "const nav_group_color_t *g = &GROUP_COLOR[PAGES[i].group];" in text:
        print("note: a GROUP_COLOR read is still in the map's loop")

    with io.open(SRC, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(text)

    print("written:", SRC)
    return 0


if __name__ == "__main__":
    sys.exit(main())
