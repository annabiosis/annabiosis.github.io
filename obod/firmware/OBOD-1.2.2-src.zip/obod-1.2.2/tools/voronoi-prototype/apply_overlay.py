"""Third pass: bake the cells once, draw the moving marks over the image.

Run from the repository root after apply_bake.py:
    python tools/voronoi-prototype/apply_overlay.py
"""

import io
import os
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
SRC = os.path.join(ROOT, "components", "synth_ui", "src", "synth_ui.c")

BAKE = """/*
 * Bake the cells, once, into the image.
 *
 * The surface and the cells, and nothing else. The cut needs no drawing of its own: the surface is
 * filled first and every cell a pixel short of its own edge, so the gap between two cells is what
 * falls out \u2014 which is why the mosaic has no outline anywhere, and why a cell reads as a tile lying
 * on the surface rather than as a shape with a border.
 *
 * Both are FIXED. A cell's colour is its family's and never changes, so this runs once at boot and
 * what the map draws afterwards is one image: a full bake is 160 ms of rasterising and one cell of
 * it is seven, neither of which belongs in a frame.
 *
 * The surface is COL_BG rather than the current family's tint, because the mosaic covers the whole
 * screen: the one place the surface shows is the cut between two cells, and a colour that followed
 * the family would mean baking all of it again on every page change.
 */
static void nav_mosaic(void)
{
    if (s_nav_buf == NULL) {
        return;
    }

    lv_area_t all;
    all.x1 = 0;
    all.y1 = 0;
    all.x2 = NAV_SCREEN - 1;
    all.y2 = NAV_SCREEN - 1;

    const uint16_t bg = lv_color_to_u16(lv_color_hex(COL_BG));
    const int stride = (int)s_nav_buf->header.stride;

    for (int y = 0; y < NAV_SCREEN; y++) {
        uint16_t *row = (uint16_t *)(s_nav_buf->data + (size_t)y * (size_t)stride);

        for (int x = 0; x < NAV_SCREEN; x++) {
            row[x] = bg;
        }
    }

    float in[NAV_CELL_V_MAX * 2];

    for (int i = 0; i < (int)PAGE_COUNT; i++) {
        const int n = s_nav_cell_n[i];

        if (n < 3) {
            continue;
        }

        for (int k = 0; k < n; k++) {
            in[k * 2] = (float)(NAV_SCREEN / 2) + s_nav_cell[i][k * 2];
            in[k * 2 + 1] = (float)(NAV_SCREEN / 2) + s_nav_cell[i][k * 2 + 1];
        }

        nav_offset(in, n, (float)NAV_SEAM_W * 0.5f, in);

        nav_fill(&all, in, n, GROUP_COLOR[PAGES[i].group].tile);
    }
}

/*
 * A frame along a cell's edge, `inset` pixels inside it, in screen coordinates around (cx, cy).
 */
static void nav_ring(lv_layer_t *layer, int page, int32_t cx, int32_t cy,
                     int inset, int width, uint32_t color)
{
    const int n = s_nav_cell_n[page];

    if (n < 3) {
        return;
    }

    float in[NAV_CELL_V_MAX * 2];
    float out[NAV_CELL_V_MAX * 2];

    for (int k = 0; k < n; k++) {
        in[k * 2] = (float)cx + s_nav_cell[page][k * 2];
        in[k * 2 + 1] = (float)cy + s_nav_cell[page][k * 2 + 1];
    }

    nav_offset(in, n, (float)inset, out);

    lv_draw_line_dsc_t line;
    lv_draw_line_dsc_init(&line);
    line.color = lv_color_hex(color);
    line.width = width;
    line.opa = LV_OPA_COVER;

    for (int k = 0; k < n; k++) {
        const int q = (k + 1 == n) ? 0 : (k + 1);

        line.p1.x = (int32_t)lroundf(out[k * 2]);
        line.p1.y = (int32_t)lroundf(out[k * 2 + 1]);
        line.p2.x = (int32_t)lroundf(out[q * 2]);
        line.p2.y = (int32_t)lroundf(out[q * 2 + 1]);
        lv_draw_line(layer, &line);
    }
}

/* A cell's box in screen coordinates, for a clip test or for a repaint. */
static bool nav_cell_screen_box(int page, lv_area_t *out)
{
    if (!nav_cell_box(page, out)) {
        return false;
    }

    if (s_nav_marks == NULL) {
        return false;
    }

    lv_area_t obj;
    lv_obj_get_coords(s_nav_marks, &obj);

    out->x1 += obj.x1;
    out->x2 += obj.x1;
    out->y1 += obj.y1;
    out->y2 += obj.y1;

    return true;
}

/* Ask for one cell's moving parts to be painted again: the whole of what a flash costs. */
static void nav_cell_repaint(int page)
{
    lv_area_t box;

    if (s_nav_marks != NULL && nav_cell_screen_box(page, &box)) {
        lv_obj_invalidate_area(s_nav_marks, &box);
    }
}

/*
 * The map's moving parts: the rhythm's flash, the macro's rings and the frame of the section you
 * are standing on, painted OVER the baked image.
 *
 * They are not baked because they change: a page change would then cost a full bake, and the flash
 * would cost one on every hit. Drawn, a flash is three cells and a page change is two, and the clip
 * decides which of them are touched \u2014 a cell whose box misses it is skipped before anything is
 * built.
 */
static void nav_marks_draw_cb(lv_event_t *e)
{
    if (lv_event_get_target(e) != s_nav_marks) {
        return;
    }

    lv_layer_t *layer = lv_event_get_layer(e);
    const lv_area_t clip = layer->_clip_area;

    lv_area_t obj;
    lv_obj_get_coords(s_nav_marks, &obj);

    const int32_t cx = obj.x1 + NAV_SCREEN / 2;
    const int32_t cy = obj.y1 + NAV_SCREEN / 2;

    lv_area_t box;
    float in[NAV_CELL_V_MAX * 2];
    float out[NAV_CELL_V_MAX * 2];

    /*
     * The flash: the cell filled with its family's rim \u2014 the step a turned sector's hairline is
     * drawn in \u2014 so that "this part is sounding" is said in a colour the map already uses.
     *
     * Filled with a fan of triangles, which is the one thing LVGL can fill without the vector
     * renderer, and every triangle is pushed a pixel out past its own edges: two triangles that
     * share a chord each composite on their own, and without the overlap their two antialiased
     * coverages add up to less than one, which is the hairline a fan is known for. The cell's own
     * cut is drawn again afterwards, because that pixel of overlap lands in it.
     */
    for (int i = 0; i < (int)PAGE_COUNT; i++) {
        if (!s_nav_glow[i] || !nav_cell_screen_box(i, &box)) {
            continue;
        }
        if (!viz_area_hits(&box, &clip)) {
            continue;
        }

        const int n = s_nav_cell_n[i];
        const nav_group_color_t *g = &GROUP_COLOR[PAGES[i].group];

        for (int k = 0; k < n; k++) {
            in[k * 2] = (float)cx + s_nav_cell[i][k * 2];
            in[k * 2 + 1] = (float)cy + s_nav_cell[i][k * 2 + 1];
        }

        lv_draw_triangle_dsc_t tri;
        lv_draw_triangle_dsc_init(&tri);
        tri.opa = LV_OPA_COVER;
        tri.color = lv_color_hex(g->rim);

        for (int k = 1; k + 1 < n; k++) {
            float tv[6];

            tv[0] = in[0];
            tv[1] = in[1];
            tv[2] = in[k * 2];
            tv[3] = in[k * 2 + 1];
            tv[4] = in[(k + 1) * 2];
            tv[5] = in[(k + 1) * 2 + 1];

            nav_offset(tv, 3, -1.0f, out);

            tri.p[0].x = (int32_t)lroundf(out[0]);
            tri.p[0].y = (int32_t)lroundf(out[1]);
            tri.p[1].x = (int32_t)lroundf(out[2]);
            tri.p[1].y = (int32_t)lroundf(out[3]);
            tri.p[2].x = (int32_t)lroundf(out[4]);
            tri.p[2].y = (int32_t)lroundf(out[5]);
            lv_draw_triangle(layer, &tri);
        }

        lv_draw_line_dsc_t edge;
        lv_draw_line_dsc_init(&edge);
        edge.color = lv_color_hex(COL_BG);
        edge.width = NAV_SEAM_W;
        edge.opa = LV_OPA_COVER;

        for (int k = 0; k < n; k++) {
            const int q = (k + 1 == n) ? 0 : (k + 1);

            edge.p1.x = (int32_t)lroundf(in[k * 2]);
            edge.p1.y = (int32_t)lroundf(in[k * 2 + 1]);
            edge.p2.x = (int32_t)lroundf(in[q * 2]);
            edge.p2.y = (int32_t)lroundf(in[q * 2 + 1]);
            lv_draw_line(layer, &edge);
        }
    }

    /*
     * The two marks, each inside its own cell. The questions they answer are different ones \u2014 "is
     * this section wired into the macro" and "am I standing here" \u2014 so they are two frames and not
     * two shades of one, and a section can wear both at once.
     */
    for (int i = 0; i < (int)PAGE_COUNT; i++) {
        const bool macros = page_has_macro(&PAGES[i]);
        const bool self = (i == (int)s_page);

        if (!macros && !self) {
            continue;
        }
        if (!nav_cell_screen_box(i, &box)) {
            continue;
        }
        if (!viz_area_hits(&box, &clip)) {
            continue;
        }

        if (macros) {
            nav_ring(layer, i, cx, cy, NAV_MARK_INSET, NAV_MARK_W, COL_MACRO_RIM);
        }

        if (self) {
            nav_ring(layer, i, cx, cy, NAV_MARK_INSET + NAV_MARK_GAP, NAV_SELF_W,
                     GROUP_COLOR[PAGES[i].group].ink);
        }
    }
}
"""

BAKE_OLD_START = "/*\n * Bake the mosaic into the image: the surface, the cells and the two marks.\n"
BAKE_OLD_END = "    lv_obj_invalidate_area(s_nav_cells, &scr);\n}\n"

STATE_ADD_OLD = """static lv_obj_t      *s_nav_cells; /* the mosaic: an image over s_nav_buf, baked by nav_bake() */
static lv_draw_buf_t *s_nav_buf;   /* and its pixels, 253 KB in PSRAM */
"""

STATE_ADD_NEW = """static lv_obj_t      *s_nav_cells; /* the mosaic: an image over s_nav_buf, baked once at boot */
static lv_draw_buf_t *s_nav_buf;   /* and its pixels, 253 KB in PSRAM */
static lv_obj_t      *s_nav_marks; /* the flash and the two frames, painted over that image */
static int            s_nav_marked = -1;  /* which page's frame is painted at the moment */
"""

MARK_OLD = """    /* The marks and the surface are the bake's, so this is where the whole mosaic is painted. */
    nav_bake(NULL);

    if (s_nav_cells != NULL) {
        lv_obj_invalidate(s_nav_cells);
    }
}
"""
MARK_NEW = """    /*
     * The frame has moved, and only the cells it moved between have to be painted again: the mosaic
     * itself is a picture that a page change does not touch.
     */
    if (s_nav_marked >= 0 && s_nav_marked != (int)s_page) {
        nav_cell_repaint(s_nav_marked);
    }

    nav_cell_repaint((int)s_page);
    s_nav_marked = (int)s_page;

    if (s_nav_cells != NULL) {
        lv_obj_invalidate(s_nav_cells);
    }
}
"""

GLOW_OLD = """        /* A flash left over from the last time the map was up is put back here, or a tile caught
         * mid-flash would stay bright for as long as the map is. */
        s_nav_glow[i] = false;
"""
GLOW_NEW = """        /* A flash left over from the last time the map was up is put back here, or a cell caught
         * mid-flash would stay bright for as long as the map is. */
        if (s_nav_glow[i]) {
            s_nav_glow[i] = false;
            nav_cell_repaint(i);
        }
"""

LAYOUT_OLD = """    /* The current section's frame and the macro marks are painted with the mosaic, so a page
     * change is a repaint of it and of nothing else. */
    if (s_nav_cells != NULL) {
        lv_obj_invalidate(s_nav_cells);
    }
}
"""
LAYOUT_NEW = """}
"""

BUILD_OLD = """    } else {
        s_nav_cells = lv_image_create(s_nav);
        lv_image_set_src(s_nav_cells, s_nav_buf);
        lv_obj_set_pos(s_nav_cells, 0, 0);
        lv_obj_clear_flag(s_nav_cells, LV_OBJ_FLAG_SCROLLABLE);
        lv_obj_set_clickable(s_nav_cells, false);
        lv_obj_set_click_focusable(s_nav_cells, false);

        /* Painted before the first frame that could show it, so the map never appears as garbage,
         * and timed while it is the only one in the boot log: a full bake is the most this ever
         * costs, it happens on a page change and on the map opening, and the number is what says
         * whether that is a frame's worth of work or a slide's. */
        const int64_t bake_at = esp_timer_get_time();
        nav_bake(NULL);
        ESP_LOGI(TAG, "map: %d px cells baked in %d us",
                 NAV_SCREEN, (int)(esp_timer_get_time() - bake_at));
    }
"""

BUILD_NEW = """    } else {
        s_nav_cells = lv_image_create(s_nav);
        lv_image_set_src(s_nav_cells, s_nav_buf);
        lv_obj_set_pos(s_nav_cells, 0, 0);
        lv_obj_clear_flag(s_nav_cells, LV_OBJ_FLAG_SCROLLABLE);
        lv_obj_set_clickable(s_nav_cells, false);
        lv_obj_set_click_focusable(s_nav_cells, false);

        /* The moving parts over the picture, and created before the names so that the names are
         * painted over them. A tap falls through both of them to the curtain. */
        s_nav_marks = lv_obj_create(s_nav);
        lv_obj_remove_style_all(s_nav_marks);
        lv_obj_set_size(s_nav_marks, NAV_SCREEN, NAV_SCREEN);
        lv_obj_set_pos(s_nav_marks, 0, 0);
        lv_obj_set_style_opa(s_nav_marks, LV_OPA_COVER, LV_PART_MAIN);
        lv_obj_clear_flag(s_nav_marks, LV_OBJ_FLAG_SCROLLABLE);
        lv_obj_set_clickable(s_nav_marks, false);
        lv_obj_set_click_focusable(s_nav_marks, false);
        suppress_theme_focus_decoration(s_nav_marks);
        lv_obj_add_event_cb(s_nav_marks, nav_marks_draw_cb, LV_EVENT_DRAW_MAIN, NULL);

        /* Baked before the first frame that could show it, and timed while it is the only one in
         * the boot log: this is the whole rasterising the map ever does. */
        const int64_t bake_at = esp_timer_get_time();
        nav_mosaic();
        ESP_LOGI(TAG, "map: %d px mosaic baked in %d us",
                 NAV_SCREEN, (int)(esp_timer_get_time() - bake_at));
    }
"""


def apply(text, start, end, new, label):
    i = text.find(start)
    if i < 0:
        raise SystemExit("%s: start anchor not found" % label)
    if text.count(start) != 1:
        raise SystemExit("%s: start anchor occurs %d times" % (label, text.count(start)))
    j = text.find(end, i)
    if j < 0:
        raise SystemExit("%s: end anchor not found after start" % label)
    j += len(end)
    span = text[i:j]
    if span.count(end) != 1:
        raise SystemExit("%s: end anchor is ambiguous inside the span" % label)
    print("%-10s replaced %5d -> %5d bytes" % (label, len(span), len(new)))
    return text[:i] + new + text[j:]


def main():
    with io.open(SRC, "r", encoding="utf-8", newline="\n") as fh:
        text = fh.read()

    text = apply(text, BAKE_OLD_START, BAKE_OLD_END, BAKE, "bake")
    text = apply(text, STATE_ADD_OLD, STATE_ADD_OLD, STATE_ADD_NEW, "state")
    text = apply(text, MARK_OLD, MARK_OLD, MARK_NEW, "mark")
    text = apply(text, GLOW_OLD, GLOW_OLD, GLOW_NEW, "glow")
    text = apply(text, LAYOUT_OLD, LAYOUT_OLD, LAYOUT_NEW, "layout")
    text = apply(text, BUILD_OLD, BUILD_OLD, BUILD_NEW, "build")

    old = "painted by nav_bake(), which reads"
    if text.count(old) != 1:
        raise SystemExit("mark comment: %d occurrences" % text.count(old))
    text = text.replace(old, "painted by nav_marks_draw_cb(), which reads")

    old = "therefore the whole of \"the marks moved\", and nothing can fall out of step with them."
    if text.count(old) != 1:
        raise SystemExit("mark comment 2: %d occurrences" % text.count(old))
    text = text.replace(old, "therefore the whole of \"the marks moved\".")
    print("mark-comm  replaced the painter's name")

    with io.open(SRC, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(text)

    print("written:", SRC)
    return 0


if __name__ == "__main__":
    sys.exit(main())
