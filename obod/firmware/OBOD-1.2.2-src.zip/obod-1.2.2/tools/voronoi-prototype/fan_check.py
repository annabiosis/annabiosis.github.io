"""How far the flash's fan of triangles sticks out of its own cell.

The fan is drawn a pixel wide of its edges so that two triangles sharing a side overlap and their
antialiased coverages add up to one instead of leaving a hairline. That overlap is what makes the
triangle's OWN corners move: pushing the sides of a triangle out by a pixel moves a sharp corner by
1/sin(half the angle) pixels, which is three or four at the angles a Voronoi cell has.

The pivot decides how sharp those corners are. A fan spread from the cell's first vertex has
triangles whose two sides are both edges of the cell, so a corner of the cell is a corner of the
triangle. A fan spread from the middle gives each triangle ONE edge of the cell and two of the
fan's own, whose meeting angle is wide, so a corner can only move about a pixel.

    python tools/voronoi-prototype/fan_check.py
"""

import importlib.util
import math
import os

HERE = os.path.dirname(__file__)
FACTOR = 1.0


def load_cells():
    spec = importlib.util.spec_from_file_location("check_cracks", os.path.join(HERE, "check_cracks.py"))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod.cells()


def offset(poly, d):
    """Each edge moved outward (away from the middle of the polygon) by d, edges joined."""
    n = len(poly)
    out = []
    for k in range(n):
        ax, ay = poly[k]
        bx, by = poly[(k + 1) % n]
        ex, ey = bx - ax, by - ay
        L = math.hypot(ex, ey)
        # Inward normal for a counter-clockwise polygon is (-ey, ex); outward is the opposite.
        nx, ny = ey / L, -ex / L
        out.append((ax + nx * d, ay + ny * d))
        out.append((bx + nx * d, by + ny * d))
    return out


def tri_offset(tri, d):
    """A triangle's three sides moved outward by d, as the draw callback does."""
    n = 3
    lines = []
    for k in range(n):
        ax, ay = tri[k]
        bx, by = tri[(k + 1) % n]
        ex, ey = bx - ax, by - ay
        L = math.hypot(ex, ey)
        nx, ny = ey / L, -ex / L
        lines.append((ax + nx * d, ay + ny * d, ex, ey))

    pts = []
    for k in range(n):
        x1, y1, ex1, ey1 = lines[k - 1]
        x2, y2, ex2, ey2 = lines[k]
        det = ex1 * (-ey2) - ey1 * (-ex2)
        if abs(det) < 1e-9:
            pts.append(tri[k])
            continue
        rx, ry = x2 - x1, y2 - y1
        u = (rx * (-ey2) - ry * (-ex2)) / det
        pts.append((x1 + ex1 * u, y1 + ey1 * u))
    return pts


def outside(poly, p):
    """How far p sits outside the convex polygon, in pixels (0 when inside)."""
    worst = 0.0
    for k in range(len(poly)):
        ax, ay = poly[k]
        bx, by = poly[(k + 1) % len(poly)]
        ex, ey = bx - ax, by - ay
        L = math.hypot(ex, ey)
        nx, ny = -ey / L, ex / L            # inward for a counter-clockwise cell
        dist = (p[0] - ax) * nx + (p[1] - ay) * ny
        worst = max(worst, -dist)
    return worst


def centroid(poly):
    a = cx = cy = 0.0
    for i in range(len(poly)):
        p, q = poly[i], poly[(i + 1) % len(poly)]
        cross = p[0] * q[1] - q[0] * p[1]
        a += cross
        cx += (p[0] + q[0]) * cross
        cy += (p[1] + q[1]) * cross
    a *= 0.5
    return (cx / (6 * a), cy / (6 * a))


def clamp(poly, p):
    """The firmware's nav_clamp(): pull a point back onto the cell grown by one pixel."""
    x, y = p
    for k in range(len(poly)):
        ax, ay = poly[k]
        bx, by = poly[(k + 1) % len(poly)]
        ex, ey = bx - ax, by - ay
        L = math.hypot(ex, ey)
        if L < 0.01:
            continue
        nx, ny = -ey / L, ex / L            # inward for a counter-clockwise cell
        out = (x - ax) * nx + (y - ay) * ny + FACTOR
        if out < 0.0:
            x -= out * nx
            y -= out * ny
    return (x, y)


def worst_for(poly, pivot, skip_pivot_vertex=False, with_clamp=True):
    far = 0.0
    n = len(poly)
    for k in range(n):
        tri = [pivot, poly[k], poly[(k + 1) % n]]
        if skip_pivot_vertex and k == 0:
            continue                       # a fan from the first vertex starts at the second
        if any(math.hypot(tri[a][0] - tri[b][0], tri[a][1] - tri[b][1]) < 1e-9
               for a, b in ((0, 1), (1, 2), (2, 0))):
            continue
        for p in tri_offset(tri, FACTOR):
            if with_clamp:
                p = clamp(poly, p)
            far = max(far, outside(poly, p))
    return far


def main():
    cells = load_cells()
    print("%-5s %10s %10s %10s" % ("cell", "from v0", "from mid", "clamped"))
    a = b = c = 0.0
    for i, poly in enumerate(cells):
        if len(poly) < 3:
            continue
        from_v0 = worst_for(poly, poly[0], skip_pivot_vertex=True, with_clamp=False)
        from_mid = worst_for(poly, centroid(poly), with_clamp=False)
        clamped = worst_for(poly, centroid(poly))
        a = max(a, from_v0)
        b = max(b, from_mid)
        c = max(c, clamped)
        print("%-5d %10.2f %10.2f %10.2f" % (i, from_v0, from_mid, clamped))
    print("worst: from v0 %.2f px, from the middle %.2f px, clamped %.2f px" % (a, b, c))


if __name__ == "__main__":
    main()
