"""Look for cracks inside the mosaic's cells in a captured frame.

Rebuilds the cells exactly as nav_measure() does (same table, same weights, same 64-gon, same
clipping, same half-pixel simplification) and then, for every cell, reports pixels
of the interior that are not the cell's own colour. The marks are expected on two
pages at most; anything else is a seam that should not be there.
"""

import io
import math
import os
import re
import sys
from collections import Counter

from PIL import Image

CELL_R = 180.0
GON = 64

HERE = os.path.dirname(os.path.abspath(__file__))
SOURCE = os.path.join(os.path.dirname(os.path.dirname(HERE)),
                      "components", "synth_ui", "src", "synth_ui.c")

# Read from the firmware, not copied: this script exists to cut the cells the way the device cuts
# them, and a table kept here by hand would be a second answer to that question.
ROW = re.compile(r"\[(PAGE_[A-Z0-9_]+)\s*\]\s*=\s*\{\s*(-?\d+)\s*,\s*(-?\d+)\s*,\s*(-?\d+)\s*\}")

SHORT = {
    "PAGE_PERC": "PERC", "PAGE_TONE": "TONE", "PAGE_ENV": "ENV",
    "PAGE_PERC_SEQ": "PSEQ", "PAGE_ARP": "ARP", "PAGE_EUCLID": "EUCL",
    "PAGE_GEN": "GEN", "PAGE_LEAD": "LEAD", "PAGE_DRONE": "DRONE",
    "PAGE_FILTER": "FLTR", "PAGE_MOD": "MOD", "PAGE_MASTER": "MSTR",
    "PAGE_MIX": "LVLS", "PAGE_SEND_REV": "REVS", "PAGE_SEND_CHR": "CHRS",
    "PAGE_SEND_DLY": "DELS", "PAGE_SYS": "SYS", "PAGE_SYS2": "OPT",
    "PAGE_PRESET": "PRST", "PAGE_CHORUS": "CHOR", "PAGE_DELAY": "DLY",
    "PAGE_VERB": "REV",
}


def table():
    text = io.open(SOURCE, encoding="utf-8").read()
    start = text.index("NAV_SITES[PAGE_COUNT][3]")
    end = text.index("};", start)
    return [(m.group(1), int(m.group(2)), int(m.group(3)), int(m.group(4)))
            for m in ROW.finditer(text[start:end])]


_TABLE = table()
SITES = [(x, y, w) for _, x, y, w in _TABLE]
NAMES = [SHORT.get(ident, ident) for ident, _, _, _ in _TABLE]


def clip(poly, a, b, c):
    out = []
    n = len(poly)
    for i in range(n):
        p = poly[i]
        q = poly[(i + 1) % n]
        dp = a * p[0] + b * p[1] - c
        dq = a * q[0] + b * q[1] - c
        if dp <= 0:
            out.append(p)
        if (dp < 0 < dq) or (dq < 0 < dp):
            t = dp / (dp - dq)
            out.append((p[0] + t * (q[0] - p[0]), p[1] + t * (q[1] - p[1])))
    return out


def simplify(poly, tol=0.5):
    n = len(poly)
    keep = []
    for i in range(n):
        ax, ay = poly[i - 1]
        bx, by = poly[i]
        cx, cy = poly[(i + 1) % n]
        ex, ey = cx - ax, cy - ay
        ln = math.hypot(ex, ey)
        if ln > 0.01 and abs(ex * (by - ay) - ey * (bx - ax)) / ln <= tol:
            continue
        keep.append((bx, by))
    return keep


def cells():
    S = [(x / 10.0, y / 10.0) for x, y, _ in SITES]
    W = [w for _, _, w in SITES]
    out = []
    for i, s in enumerate(S):
        poly = [(CELL_R * math.cos(2 * math.pi * k / GON),
                 CELL_R * math.sin(2 * math.pi * k / GON)) for k in range(GON)]
        for j, t in enumerate(S):
            if i == j:
                continue
            a = 2 * (t[0] - s[0])
            b = 2 * (t[1] - s[1])
            c = (t[0] ** 2 + t[1] ** 2) - (s[0] ** 2 + s[1] ** 2) + (W[j] - W[i])
            poly = clip(poly, a, b, c)
        out.append(simplify(poly))
    return out


def inside(poly, x, y):
    n = len(poly)
    for i in range(n):
        ax, ay = poly[i]
        bx, by = poly[(i + 1) % n]
        if (bx - ax) * (y - ay) - (by - ay) * (x - ax) < 0:
            return False
    return True


def edge_dist(poly, x, y):
    best = 1e9
    n = len(poly)
    for i in range(n):
        ax, ay = poly[i]
        bx, by = poly[(i + 1) % n]
        ex, ey = bx - ax, by - ay
        ln = math.hypot(ex, ey)
        best = min(best, (ex * (y - ay) - ey * (x - ax)) / ln)
    return best


def main(path, page_hint=None):
    img = Image.open(path).convert("RGB")
    w, h = img.size
    cx, cy = w / 2.0, h / 2.0
    px = img.load()

    total_bad = 0
    for name, poly in zip(NAMES, cells()):
        inner = [(cx + x, cy + y) for x, y in poly]
        xs = [p[0] for p in inner]
        ys = [p[1] for p in inner]
        counts = Counter()
        deep = []
        for y in range(int(min(ys)) - 1, int(max(ys)) + 2):
            for x in range(int(min(xs)) - 1, int(max(xs)) + 2):
                if not (0 <= x < w and 0 <= y < h):
                    continue
                if not inside(inner, x + 0.5, y + 0.5):
                    continue
                counts[px[x, y]] += 1
                if edge_dist(inner, x + 0.5, y + 0.5) > 4.0:
                    deep.append((x, y, px[x, y]))
        if not counts:
            print("%-6s no pixels" % name)
            continue
        mode = counts.most_common(1)[0][0]
        bad = [(x, y, c) for (x, y, c) in deep if c != mode]
        total_bad += len(bad)
        if bad:
            show = Counter(c for _, _, c in bad).most_common(3)
            print("%-6s fill %s  %4d deep px, %4d not the fill, colours %s  first %s"
                  % (name, mode, len(deep), len(bad), show, bad[:2]))
    print("total stray pixels inside cells:", total_bad)


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "web/assets/screens/drawer.png")
