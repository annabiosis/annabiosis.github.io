"""Second pass: bake the mosaic into an image instead of drawing triangles.

Run from the repository root after apply_mosaic.py:
    python tools/voronoi-prototype/apply_bake.py
"""

import io
import os
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
SRC = os.path.join(ROOT, "components", "synth_ui", "src", "synth_ui.c")

CONST_NEW = """/*
 * The navigator: the map of sections, laid out as a Voronoi mosaic.
 *
 * Every section owns one CELL, and a point of the glass belongs to the section whose point is
 * nearest to it \u2014 that is the whole rule, and it is the rule the finger obeys as well. The cells
 * therefore tile the disc by construction: there is no sliver between two of them for a tap to
 * fall through and no overlap for two to claim, and no packing arithmetic to keep in step, because
 * nothing is packed. A seam follows one neighbour rather than a ring.
 *
 * NAV_CELL_R is the mosaic's own edge and it is the screen's: the drawer covers the whole panel, so
 * the map covers it too, and a mosaic that stopped short of the bezel read as a smaller map with a
 * ring of empty surface around it.
 *
 * NAV_GON is the shape a cell is cut from, as a polygon. At 64 sides a chord sits 0.22 px inside the
 * true circle \u2014 a fifth of a pixel at the very edge of the glass \u2014 and the arc is where most of an
 * outer cell's vertices come from, so the number is not free.
 */
#define NAV_SCREEN        360
#define NAV_CELL_R        180
#define NAV_GON            64
/*
 * The most vertices a cell has come out with (measured over the table in nav_measure(): ten), and
 * the room the cut works in. The work buffer cannot overflow: clipping a convex polygon by one
 * half-plane adds at most one vertex, so NAV_GON plus the number of sites is the ceiling and
 * NAV_WORK_V_MAX is above it with room to spare.
 */
#define NAV_CELL_V_MAX     16
#define NAV_WORK_V_MAX     96
/*
 * The cut between two cells: two pixels, which is the width the rim uses between two sectors. The
 * mosaic has no outline anywhere \u2014 the cut is what falls out of filling the surface first and every
 * cell a pixel short of its own edge \u2014 so this number is a gap and not a line.
 */
#define NAV_SEAM_W          2
/*
 * How far a finger may land outside the mosaic and still mean its edge. The reach is wider than the
 * drawing by this much, so a tap aimed at the outermost cell is not turned into a tap on nothing by
 * a couple of pixels.
 */
#define NAV_TAP_SLACK       8
/*
 * The marks inside a cell. Nothing in a mosaic can grow, so the frame that used to mark the
 * current section by growing its tile to the full cell is now a frame inside the cell; the macro's
 * red keeps the outer ring and the current section takes the one inside it, so one cell can wear
 * both marks and neither can hide the other.
 */
#define NAV_MARK_INSET      3   /* px inside the cell's edge, where the macro's ring sits */
#define NAV_MARK_GAP        3   /* and how far the current section's frame is inside that */
#define NAV_MARK_W          2   /* the macro's ring, the rim's own mark thickness */
#define NAV_SELF_W          3   /* the current section's frame, wider: it is the place you are */
/*
 * The bake's antialiasing: four sub-scanlines to a pixel row, and the exact end of every span
 * across it. Enough for a cell that is sixty pixels wide, and the cost of a bake is paid on a page
 * change and on a flash, never on a frame of a slide.
 */
#define NAV_AA_SUB          4
#define NAV_PI 3.14159265f
"""

CONST_OLD_START = "/*\n * The navigator: the map of sections, laid out as a Voronoi mosaic.\n"
CONST_OLD_END = "#define NAV_PI 3.14159265f\n"

STATE_NEW = """/*
 * The cells, cut once at boot from the table in nav_measure(): px offsets from the middle of the
 * image, at most NAV_CELL_V_MAX of them to a page. s_nav_lx/ly is where that section's name sits,
 * which is the cell's own centroid \u2014 measured, the nearest edge is 30 px away from it at the worst,
 * against the 45 px of the longest name.
 *
 * s_nav_glow[i] is the rhythm's flash: the bake gives that cell the family's rim instead of its
 * chip, and nav_rhythm_refresh() is the only thing that sets it.
 */
static float     s_nav_cell[PAGE_COUNT][NAV_CELL_V_MAX * 2];
static uint8_t   s_nav_cell_n[PAGE_COUNT];
static int16_t   s_nav_lx[PAGE_COUNT];
static int16_t   s_nav_ly[PAGE_COUNT];
static bool      s_nav_glow[PAGE_COUNT];
/* The bake's coverage for one pixel row: 0..256 a pixel, four sub-scanlines' worth. */
static uint16_t  s_nav_row[NAV_SCREEN];
"""

STATE_OLD_START = "/*\n * The cells, cut once at boot from the table in nav_measure(): px offsets from the middle of the\n"
STATE_OLD_END = "static bool      s_nav_glow[PAGE_COUNT];\n"

GEOM = """/*
 * THE LAYOUT: one point per section, in tenths of a pixel from the middle of the screen.
 *
 * These points ARE the map. A section's cell is every point of the glass that is nearer to its
 * point than to any other's, so one number here moves one seam and no other, and there is no
 * packing arithmetic to keep in step with it. The arrangement can be dragged into shape and read
 * back as a table, which is what this one was: it came out of
 * tools/voronoi-prototype/editor.html, where the points were moved by hand against the measured
 * cell areas and the room each name needs.
 *
 * The table is keyed by PAGE and not by position: the arrangement and the page numbering are two
 * different things \u2014 the numbering is what the knob walks and what every address in this file uses,
 * and moving a tile must not be able to renumber a page.
 *
 * Tenths, because the table came out of a drag. Rounding it to whole pixels would move a seam by up
 * to half a pixel for no reason, and a cell is only sixty pixels across.
 */
static const int32_t NAV_SITES[PAGE_COUNT][2] = {
    [PAGE_PERC]     = {     2,     0 },   /* the middle: the percussion, which is struck */
    [PAGE_TONE]     = {     2,  -662 },   /* the lead family around it */
    [PAGE_ENV]      = {   518,  -412 },
    [PAGE_PERC_SEQ] = {   645,   148 },   /* the drum's figure, beside the percussion */
    [PAGE_ARP]      = {   287,   595 },
    [PAGE_EUCLID]   = {  -286,   596 },
    [PAGE_GEN]      = {  -643,   148 },
    [PAGE_LEAD]     = {  -514,  -411 },
    [PAGE_DRONE]    = {    -2,  -1246 },  /* then the body, at twelve o'clock */
    [PAGE_FILTER]   = {   523,  -1085 },
    [PAGE_MOD]      = {   976,   -774 },
    [PAGE_MASTER]   = {  1175,   -263 },  /* the mixers, down the right-hand side */
    [PAGE_MIX]      = {  1214,    283 },
    [PAGE_SEND_REV] = {   938,    754 },
    [PAGE_SEND_CHR] = {   537,   1124 },
    [PAGE_SEND_DLY] = {    -2,   1204 },
    [PAGE_SYS]      = {  -541,   1123 },  /* the settings, down the left, into the presets */
    [PAGE_SYS2]     = {  -941,    751 },
    [PAGE_PRESET]   = { -1214,    279 },
    [PAGE_CHORUS]   = { -1173,   -265 },  /* and the rack, up the left-hand side */
    [PAGE_DELAY]    = {  -976,   -773 },
    [PAGE_VERB]     = {  -525,  -1083 },
};
_Static_assert(sizeof(NAV_SITES) / sizeof(NAV_SITES[0]) == PAGE_COUNT,
               "every page needs a point on the map");

/*
 * The cut's working room, and the file's rather than the stack's: nav_measure() runs once and needs
 * a buffer per clip, and a hundred floats twice over is not something to put on a task's stack.
 */
static float s_nav_v[NAV_WORK_V_MAX * 2];
static float s_nav_cut[NAV_WORK_V_MAX * 2];

/*
 * Clip a convex polygon by the half-plane a*x + b*y <= c, in place.
 *
 * The clip of a convex polygon by a half-plane is convex, and it adds at most one vertex per
 * crossing, so the buffer above can never overflow. A vertex that lands exactly on the line is kept
 * rather than dropped: a corner shared by three cells has to stay in all three, or the mosaic grows
 * a pinhole.
 */
static int nav_clip(float *v, int n, float a, float b, float c)
{
    int m = 0;

    for (int k = 0; k < n; k++) {
        const int j = (k + 1 == n) ? 0 : (k + 1);
        const float px = v[k * 2];
        const float py = v[k * 2 + 1];
        const float qx = v[j * 2];
        const float qy = v[j * 2 + 1];
        const float dp = a * px + b * py - c;
        const float dq = a * qx + b * qy - c;

        if (dp <= 0.0f) {
            s_nav_cut[m * 2] = px;
            s_nav_cut[m * 2 + 1] = py;
            m++;
        }

        if ((dp < 0.0f && dq > 0.0f) || (dq < 0.0f && dp > 0.0f)) {
            const float t = dp / (dp - dq);
            s_nav_cut[m * 2] = px + t * (qx - px);
            s_nav_cut[m * 2 + 1] = py + t * (qy - py);
            m++;
        }
    }

    for (int k = 0; k < m * 2; k++) {
        v[k] = s_nav_cut[k];
    }

    return m;
}

/*
 * The same convex polygon with every edge moved `d` pixels toward its middle (d > 0) or away from it
 * (d < 0), and the vertices put back where the moved edges cross.
 *
 * Both are always defined because the polygon is convex, and the inward normal of an edge is
 * (-dy, dx) because nav_measure() leaves every cell wound the same way. A pair of edges crossing at
 * a very shallow angle \u2014 two nearly-collinear points of an arc \u2014 is left where it is: the crossing
 * point would be far away, and the vertex is within a pixel of where moving it by `d` puts it.
 */
static void nav_offset(const float *v, int n, float d, float *out)
{
    float nx[NAV_CELL_V_MAX], ny[NAV_CELL_V_MAX], nc[NAV_CELL_V_MAX];

    for (int k = 0; k < n; k++) {
        const int q = (k + 1 == n) ? 0 : (k + 1);
        const float ax = v[k * 2];
        const float ay = v[k * 2 + 1];
        const float ex = v[q * 2] - ax;
        const float ey = v[q * 2 + 1] - ay;
        const float len = sqrtf(ex * ex + ey * ey);

        out[k * 2] = ax;
        out[k * 2 + 1] = ay;

        if (len < 0.01f) {
            nx[k] = 0.0f;
            ny[k] = 0.0f;
            nc[k] = 0.0f;
            continue;
        }

        nx[k] = -ey / len;
        ny[k] = ex / len;
        /* The edge in normal form, n.p = c: moved by `d`, c moves by exactly that much. */
        nc[k] = nx[k] * ax + ny[k] * ay + d;
    }

    for (int k = 0; k < n; k++) {
        const int p = (k + n - 1) % n;
        const float det = nx[p] * ny[k] - ny[p] * nx[k];

        if (fabsf(det) < 0.2f) {
            out[k * 2] += d * nx[k];
            out[k * 2 + 1] += d * ny[k];
            continue;
        }

        out[k * 2] = (nc[p] * ny[k] - nc[k] * ny[p]) / det;
        out[k * 2 + 1] = (nx[p] * nc[k] - nx[k] * nc[p]) / det;
    }
}

/*
 * Cut the cells, once, at boot.
 *
 * Each cell starts as the screen's own disc and is cut by one half-plane per other section: the
 * points at least as near to this section's point as to that one form a single half-plane, and its
 * boundary is the seam the two cells share. Twenty-one of those on at most ten vertices, for
 * twenty-two sections, is a few hundred multiplications spent once and never again.
 *
 * A vertex within half a pixel of the line through its neighbours is dropped: on the arc it is one
 * more edge and no shape, and the chord it leaves is under a pixel off the circle.
 */
static void nav_measure(void)
{
    int v_max = 0;
    int area_lo = 0;
    int area_hi = 0;
    int clear_lo = 0;

    for (int i = 0; i < (int)PAGE_COUNT; i++) {
        s_nav_cell_n[i] = 0;

        if (!PAGES[i].tile) {
            continue;
        }

        const float xi = (float)NAV_SITES[i][0] * 0.1f;
        const float yi = (float)NAV_SITES[i][1] * 0.1f;

        for (int k = 0; k < NAV_GON; k++) {
            const float ang = 2.0f * NAV_PI * (float)k / (float)NAV_GON;
            s_nav_v[k * 2] = (float)NAV_CELL_R * cosf(ang);
            s_nav_v[k * 2 + 1] = (float)NAV_CELL_R * sinf(ang);
        }

        int n = NAV_GON;

        for (int j = 0; j < (int)PAGE_COUNT; j++) {
            if (j == i || !PAGES[j].tile) {
                continue;
            }

            const float xj = (float)NAV_SITES[j][0] * 0.1f;
            const float yj = (float)NAV_SITES[j][1] * 0.1f;

            n = nav_clip(s_nav_v, n,
                         2.0f * (xj - xi), 2.0f * (yj - yi),
                         (xj * xj + yj * yj) - (xi * xi + yi * yi));

            if (n < 3) {
                break;
            }
        }

        if (n < 3) {
            continue;
        }

        /* The straight ones out, the corners kept. */
        int keep = 0;

        for (int k = 0; k < n; k++) {
            const int p = (k + n - 1) % n;
            const int q = (k + 1) % n;
            const float ax = s_nav_v[p * 2], ay = s_nav_v[p * 2 + 1];
            const float bx = s_nav_v[k * 2], by = s_nav_v[k * 2 + 1];
            const float cx = s_nav_v[q * 2], cy = s_nav_v[q * 2 + 1];
            const float ex = cx - ax, ey = cy - ay;
            const float len = sqrtf(ex * ex + ey * ey);

            if (len > 0.01f && fabsf(ex * (by - ay) - ey * (bx - ax)) / len <= 0.5f) {
                continue;
            }

            if (keep < NAV_CELL_V_MAX) {
                s_nav_cut[keep * 2] = bx;
                s_nav_cut[keep * 2 + 1] = by;
            }

            keep++;
        }

        if (keep < 3 || keep > NAV_CELL_V_MAX) {
            /* Only reachable if the table is changed into something the buffer cannot hold. The
             * page then has no cell and the mosaic shows the hole, which is the honest failure. */
            ESP_LOGE(TAG, "map: page %d needs %d vertices, NAV_CELL_V_MAX is %d",
                     i, keep, NAV_CELL_V_MAX);
            continue;
        }

        /* The cell's own middle, and the room a name gets there: the nearest edge, which is what
         * decides whether a fourteen-pixel word fits across the cell. Both read off one walk. */
        float area = 0.0f, mxs = 0.0f, mys = 0.0f;

        for (int k = 0; k < keep; k++) {
            const int q = (k + 1 == keep) ? 0 : (k + 1);
            const float x0 = s_nav_cut[k * 2], y0 = s_nav_cut[k * 2 + 1];
            const float x1 = s_nav_cut[q * 2], y1 = s_nav_cut[q * 2 + 1];
            const float cr = x0 * y1 - x1 * y0;

            area += cr;
            mxs += (x0 + x1) * cr;
            mys += (y0 + y1) * cr;
        }

        area *= 0.5f;

        float lx = xi;
        float ly = yi;

        if (fabsf(area) > 1.0f) {
            lx = mxs / (6.0f * area);
            ly = mys / (6.0f * area);
        }

        int clr = 1000;

        for (int k = 0; k < keep; k++) {
            const int q = (k + 1 == keep) ? 0 : (k + 1);
            const float x0 = s_nav_cut[k * 2], y0 = s_nav_cut[k * 2 + 1];
            const float x1 = s_nav_cut[q * 2], y1 = s_nav_cut[q * 2 + 1];
            const float ex = x1 - x0, ey = y1 - y0;
            const float len = sqrtf(ex * ex + ey * ey);

            if (len < 0.01f) {
                continue;
            }

            const float d = (ex * (ly - y0) - ey * (lx - x0)) / len;
            if (d < (float)clr) {
                clr = (int)d;
            }
        }

        for (int k = 0; k < keep; k++) {
            s_nav_cell[i][k * 2] = s_nav_cut[k * 2];
            s_nav_cell[i][k * 2 + 1] = s_nav_cut[k * 2 + 1];
        }

        s_nav_cell_n[i] = (uint8_t)keep;
        s_nav_lx[i] = (int16_t)lroundf(lx);
        s_nav_ly[i] = (int16_t)lroundf(ly);

        if (keep > v_max) {
            v_max = keep;
        }

        const int ar = (int)(area + 0.5f);
        if (area_lo == 0 || ar < area_lo) {
            area_lo = ar;
        }
        if (ar > area_hi) {
            area_hi = ar;
        }
        if (clear_lo == 0 || clr < clear_lo) {
            clear_lo = clr;
        }
    }

    /* Said out loud once: the area of a cell is what a tap aims at and the clearance is what a
     * name lives in, and both are decided by the table above and by nothing else. */
    ESP_LOGI(TAG, "map: %d cells of %d..%d px2 on r %d, %d vertices at most, %d px of label room",
             (int)PAGE_COUNT, area_lo, area_hi, NAV_CELL_R, v_max, clear_lo);
}

/* The box a cell covers, in the image's own coordinates: false when the page has no cell. */
static bool nav_cell_box(int page, lv_area_t *out)
{
    const int n = s_nav_cell_n[page];

    if (n < 3) {
        return false;
    }

    int32_t x1 = 32000, y1 = 32000, x2 = -32000, y2 = -32000;

    for (int k = 0; k < n; k++) {
        const int32_t x = (int32_t)lroundf(s_nav_cell[page][k * 2]);
        const int32_t y = (int32_t)lroundf(s_nav_cell[page][k * 2 + 1]);

        if (x < x1) {
            x1 = x;
        }
        if (x > x2) {
            x2 = x;
        }
        if (y < y1) {
            y1 = y;
        }
        if (y > y2) {
            y2 = y;
        }
    }

    const int32_t c = NAV_SCREEN / 2;
    out->x1 = x1 + c - NAV_SEAM_W;
    out->y1 = y1 + c - NAV_SEAM_W;
    out->x2 = x2 + c + NAV_SEAM_W;
    out->y2 = y2 + c + NAV_SEAM_W;

    return true;
}

/*
 * Which cell a point of the glass belongs to, or -1 for "not the map".
 *
 * The answer is the nearest point, which is exactly what the cells are: the bake cuts them from
 * these numbers and this reads the same numbers back, so a tap cannot land on a tile other than the
 * one it was shown. The distances are taken in tenths, where the table is, so the comparison is
 * exact and needs no division by ten that could round two neighbours into a tie.
 */
static int nav_page_at(const lv_point_t *p)
{
    if (s_nav_cells == NULL) {
        return -1;
    }

    lv_area_t obj;
    lv_obj_get_coords(s_nav_cells, &obj);

    const int32_t dx = p->x - (obj.x1 + obj.x2) / 2;
    const int32_t dy = p->y - (obj.y1 + obj.y2) / 2;
    const int32_t reach = NAV_CELL_R + NAV_TAP_SLACK;

    if (dx * dx + dy * dy > reach * reach) {
        return -1;
    }

    int best = -1;
    int32_t best_d2 = 0;

    for (int i = 0; i < (int)PAGE_COUNT; i++) {
        if (!PAGES[i].tile) {
            continue;
        }

        const int32_t sx = NAV_SITES[i][0] - dx * 10;
        const int32_t sy = NAV_SITES[i][1] - dy * 10;
        const int32_t d2 = sx * sx + sy * sy;

        if (best < 0 || d2 < best_d2) {
            best = i;
            best_d2 = d2;
        }
    }

    return best;
}

/*
 * Fill one convex polygon into the baked image, antialiased, and nothing outside `area`.
 *
 * WHY THIS EXISTS AT ALL: LVGL has no filled polygon unless the vector renderer is compiled in, and
 * it is not \u2014 a polygon there is a fan of triangles, each composited on its own, and where two of
 * them share an edge the two antialiased coverages add up to less than one, so the surface behind
 * shows through as a hairline straight across the tile. Every cell is therefore rasterised here,
 * once: four sub-scanlines for the vertical coverage and the exact end of every span for the
 * horizontal one. A cell sixty pixels across gets about five thousand samples, and what the map
 * draws afterwards is one image.
 */
static void nav_fill(const lv_area_t *area, const float *v, int n, uint32_t color)
{
    if (n < 3 || s_nav_buf == NULL) {
        return;
    }

    float fx1 = v[0], fx2 = v[0], fy1 = v[1], fy2 = v[1];

    for (int k = 1; k < n; k++) {
        const float x = v[k * 2], y = v[k * 2 + 1];

        if (x < fx1) {
            fx1 = x;
        }
        if (x > fx2) {
            fx2 = x;
        }
        if (y < fy1) {
            fy1 = y;
        }
        if (y > fy2) {
            fy2 = y;
        }
    }

    int x1 = (int)floorf(fx1);
    int x2 = (int)ceilf(fx2) - 1;
    int y1 = (int)floorf(fy1);
    int y2 = (int)ceilf(fy2) - 1;

    if (area != NULL) {
        if (x1 < area->x1) {
            x1 = area->x1;
        }
        if (y1 < area->y1) {
            y1 = area->y1;
        }
        if (x2 > area->x2) {
            x2 = area->x2;
        }
        if (y2 > area->y2) {
            y2 = area->y2;
        }
    }

    if (x1 < 0) {
        x1 = 0;
    }
    if (y1 < 0) {
        y1 = 0;
    }
    if (x2 > NAV_SCREEN - 1) {
        x2 = NAV_SCREEN - 1;
    }
    if (y2 > NAV_SCREEN - 1) {
        y2 = NAV_SCREEN - 1;
    }
    if (x2 < x1 || y2 < y1) {
        return;
    }

    const int w = x2 - x1 + 1;
    const int sr = (int)((color >> 16) & 0xFF);
    const int sg = (int)((color >> 8) & 0xFF);
    const int sb = (int)(color & 0xFF);
    const uint16_t s565 = lv_color_to_u16(lv_color_hex(color));
    const int stride = (int)s_nav_buf->header.stride;

    for (int y = y1; y <= y2; y++) {
        memset(s_nav_row, 0, (size_t)w * sizeof(s_nav_row[0]));

        for (int s = 0; s < NAV_AA_SUB; s++) {
            const float sy = (float)y + ((float)s + 0.5f) / (float)NAV_AA_SUB;
            float xs[NAV_CELL_V_MAX];
            int m = 0;

            for (int k = 0; k < n; k++) {
                const int q = (k + 1 == n) ? 0 : (k + 1);
                const float ay = v[k * 2 + 1];
                const float by = v[q * 2 + 1];

                /* Half open, so a vertex that two edges share is counted by one of them. */
                if ((ay <= sy && by > sy) || (by <= sy && ay > sy)) {
                    const float ax = v[k * 2];
                    const float bx = v[q * 2];
                    xs[m++] = ax + (sy - ay) * (bx - ax) / (by - ay);
                }
            }

            /* Sorted, because a crossing list arrives in the polygon's own order. Ten at most. */
            for (int a = 1; a < m; a++) {
                const float t = xs[a];
                int b = a - 1;

                while (b >= 0 && xs[b] > t) {
                    xs[b + 1] = xs[b];
                    b--;
                }
                xs[b + 1] = t;
            }

            for (int a = 0; a + 1 < m; a += 2) {
                float xa = xs[a];
                float xb = xs[a + 1];

                if (xa < (float)x1) {
                    xa = (float)x1;
                }
                if (xb > (float)(x2 + 1)) {
                    xb = (float)(x2 + 1);
                }
                if (xb <= xa) {
                    continue;
                }

                const int xa_i = (int)floorf(xa);
                const int xb_i = (int)ceilf(xb);

                for (int x = xa_i; x <= xb_i && x <= x2; x++) {
                    if (x < x1) {
                        continue;
                    }

                    const float lo = (xa > (float)x) ? xa : (float)x;
                    const float hi = (xb < (float)(x + 1)) ? xb : (float)(x + 1);

                    if (hi > lo) {
                        s_nav_row[x - x1] += (uint16_t)((hi - lo) * (float)(256 / NAV_AA_SUB));
                    }
                }
            }
        }

        uint16_t *row = (uint16_t *)(s_nav_buf->data + (size_t)y * (size_t)stride);

        for (int x = x1; x <= x2; x++) {
            const int a = (int)s_nav_row[x - x1];

            if (a <= 0) {
                continue;
            }
            if (a >= 256) {
                row[x] = s565;
                continue;
            }

            const uint16_t d = row[x];
            const int dr = (int)((d >> 11) & 0x1F);
            const int dg = (int)((d >> 5) & 0x3F);
            const int db = (int)(d & 0x1F);
            const int r = ((sr * a) + (((dr << 3) | (dr >> 2)) * (256 - a))) >> 8;
            const int g = ((sg * a) + (((dg << 2) | (dg >> 4)) * (256 - a))) >> 8;
            const int b = ((sb * a) + (((db << 3) | (db >> 2)) * (256 - a))) >> 8;

            row[x] = (uint16_t)(((r >> 3) << 11) | ((g >> 2) << 5) | (b >> 3));
        }
    }
}

/*
 * Bake the mosaic into the image: the surface, the cells and the two marks.
 *
 * The cut needs no drawing of its own. The surface is filled with the curtain's colour and every
 * cell is filled a pixel short of its own edge, so the gap between two cells is what falls out \u2014
 * which is why the mosaic has no outline anywhere, and why a cell reads as a tile lying on the
 * surface rather than as a shape with a border.
 *
 * `area` limits the work to a strip of the image, which is what a rhythm flash needs: one cell
 * changed, one cell's box baked. NULL bakes the whole screen, which happens when the map opens and
 * when the page behind it changes.
 */
static void nav_bake(const lv_area_t *area)
{
    if (s_nav_buf == NULL) {
        return;
    }

    lv_area_t clip;
    clip.x1 = 0;
    clip.y1 = 0;
    clip.x2 = NAV_SCREEN - 1;
    clip.y2 = NAV_SCREEN - 1;

    if (area != NULL) {
        if (area->x1 > clip.x1) {
            clip.x1 = area->x1;
        }
        if (area->y1 > clip.y1) {
            clip.y1 = area->y1;
        }
        if (area->x2 < clip.x2) {
            clip.x2 = area->x2;
        }
        if (area->y2 < clip.y2) {
            clip.y2 = area->y2;
        }
    }

    if (clip.x2 < clip.x1 || clip.y2 < clip.y1) {
        return;
    }

    /* The surface, and the colour of the air between the cells: the family's tint, which is what the
     * curtain behind the map is, so a cut reads as the surface showing through. */
    const uint16_t bg = lv_color_to_u16(
        lv_color_hex(tint(GROUP_COLOR[PAGES[s_page].group].fill, TINT_BG)));
    const int stride = (int)s_nav_buf->header.stride;

    for (int y = clip.y1; y <= clip.y2; y++) {
        uint16_t *row = (uint16_t *)(s_nav_buf->data + (size_t)y * (size_t)stride);

        for (int x = clip.x1; x <= clip.x2; x++) {
            row[x] = bg;
        }
    }

    float in[NAV_CELL_V_MAX * 2];
    float out[NAV_CELL_V_MAX * 2];
    const float c = (float)(NAV_SCREEN / 2);

    for (int i = 0; i < (int)PAGE_COUNT; i++) {
        const int n = s_nav_cell_n[i];

        if (n < 3) {
            continue;
        }

        lv_area_t box;
        if (!nav_cell_box(i, &box)) {
            continue;
        }
        if (box.x2 < clip.x1 || box.x1 > clip.x2 || box.y2 < clip.y1 || box.y1 > clip.y2) {
            continue;
        }

        const nav_group_color_t *g = &GROUP_COLOR[PAGES[i].group];
        const uint32_t lit = s_nav_glow[i] ? g->rim : g->tile;

        /* The cell as the screen sees it, so that the fill and the offset work in one space. */
        for (int k = 0; k < n; k++) {
            in[k * 2] = c + s_nav_cell[i][k * 2];
            in[k * 2 + 1] = c + s_nav_cell[i][k * 2 + 1];
        }

        nav_offset(in, n, (float)NAV_SEAM_W * 0.5f, out);
        nav_fill(&clip, out, n, lit);

        /*
         * The marks, each drawn as a frame and then put back with the tile's own colour inside it:
         * a ring is a filled polygon minus a smaller one, and both of them are already here.
         */
        if (page_has_macro(&PAGES[i])) {
            nav_offset(in, n, (float)NAV_MARK_INSET, out);
            nav_fill(&clip, out, n, COL_MACRO_RIM);
            nav_offset(in, n, (float)(NAV_MARK_INSET + NAV_MARK_W), out);
            nav_fill(&clip, out, n, lit);
        }

        if (i == (int)s_page) {
            nav_offset(in, n, (float)(NAV_MARK_INSET + NAV_MARK_GAP), out);
            nav_fill(&clip, out, n, g->ink);
            nav_offset(in, n, (float)(NAV_MARK_INSET + NAV_MARK_GAP + NAV_SELF_W), out);
            nav_fill(&clip, out, n, lit);
        }
    }
}

/* Bake one cell, and ask for it to be shown: what the rhythm's flash needs and the whole of it. */
static void nav_cell_repaint(int page)
{
    lv_area_t box;

    if (!nav_cell_box(page, &box)) {
        return;
    }

    nav_bake(&box);

    if (s_nav_cells == NULL) {
        return;
    }

    lv_area_t at;
    lv_obj_get_coords(s_nav_cells, &at);

    lv_area_t scr;
    scr.x1 = box.x1 + at.x1;
    scr.y1 = box.y1 + at.y1;
    scr.x2 = box.x2 + at.x1;
    scr.y2 = box.y2 + at.y1;

    lv_obj_invalidate_area(s_nav_cells, &scr);
}

"""

GEOM_OLD_START = "/*\n * THE LAYOUT: one point per section, in tenths of a pixel from the middle of the disc."
GEOM_OLD_END = """        if (i == (int)s_page) {
            nav_cell_frame(layer, i, ox, oy, NAV_MARK_INSET + NAV_MARK_GAP, NAV_SELF_W, g->ink);
        }
    }
}
"""

MARK_OLD = """        s_nav_glow[i] = false;
    }

    if (s_nav_cells != NULL) {
        lv_obj_invalidate(s_nav_cells);
    }
}
"""
MARK_NEW = """        s_nav_glow[i] = false;
    }

    /* The marks and the surface are the bake's, so this is where the whole mosaic is painted. */
    nav_bake(NULL);

    if (s_nav_cells != NULL) {
        lv_obj_invalidate(s_nav_cells);
    }
}
"""

FLASH_OLD = """        if (s_nav_glow[i] != on) {
            s_nav_glow[i] = on;
            nav_cell_invalidate(i);
        }
"""
FLASH_NEW = """        if (s_nav_glow[i] != on) {
            s_nav_glow[i] = on;
            nav_cell_repaint(i);
        }
"""

BUILD_NEW = """    /*
     * The mosaic, as one image: a 360x360 draw buffer, baked on a page change and on a flash, and
     * blitted as it is.
     *
     * It used to be drawn from the cells on every pass \u2014 a hundred-odd triangles and twice as many
     * cut lines for a full paint \u2014 which is a slide's worth of draw tasks for a picture that only
     * changes when the page or the rhythm does. In PSRAM, and it has to be: 253 KB is not in what is
     * left of the internal heap, and the drawer's own snapshots live there for the same reason.
     */
    s_nav_buf = lv_draw_buf_create(NAV_SCREEN, NAV_SCREEN, LV_COLOR_FORMAT_RGB565, 0);

    if (s_nav_buf == NULL) {
        ESP_LOGE(TAG, "map: no room for the %d KB mosaic",
                 (NAV_SCREEN * NAV_SCREEN * 2) / 1024);
    } else {
        s_nav_cells = lv_image_create(s_nav);
        lv_image_set_src(s_nav_cells, s_nav_buf);
        lv_obj_set_pos(s_nav_cells, 0, 0);
        lv_obj_clear_flag(s_nav_cells, LV_OBJ_FLAG_SCROLLABLE);
        lv_obj_set_clickable(s_nav_cells, false);
        lv_obj_set_click_focusable(s_nav_cells, false);

        /* Painted before the first frame that could show it, so the map never appears as garbage. */
        nav_bake(NULL);
    }

    for (int i = 0; i < (int)PAGE_COUNT; i++) {
        /*
         * A page without a cell gets no name either: nav_measure() has already left its cell at
         * zero vertices, and the bake draws nothing for it.
         */
        if (!PAGES[i].tile) {
            continue;
        }

        /* The SHORT name, in the same 14 px it had on the chip: the cell is bigger, and the answer
         * to a bigger cell was the layout, not a larger face. See ui_page_t for why every page
         * carries two names. */
        s_nav_label[i] = make_label(s_nav, PAGES[i].tile_label, &lv_font_anbscreen_14, COL_TEXT,
                                    LV_ALIGN_CENTER, s_nav_lx[i], s_nav_ly[i]);
        text_condensed(s_nav_label[i], -1);
    }
"""

BUILD_OLD_START = """    /*
     * The mosaic, on an object of its own: transparent, not clickable, and created before the names
     * so that the names are painted over it. A tap falls through it to the curtain, which owns the
     * click and answers it by the nearest point"""
BUILD_OLD_END = """        s_nav_label[i] = make_label(s_nav, PAGES[i].tile_label, &lv_font_anbscreen_14, COL_TEXT,
                                    LV_ALIGN_CENTER, s_nav_lx[i], s_nav_ly[i]);
        text_condensed(s_nav_label[i], -1);
    }
"""

STATE_B_NEW = """/* The navigator. */
static lv_obj_t      *s_nav;
static lv_obj_t      *s_nav_cells; /* the mosaic: an image over s_nav_buf, baked by nav_bake() */
static lv_draw_buf_t *s_nav_buf;   /* and its pixels, 253 KB in PSRAM */
/*
 * One slot per PAGE, not one per tile: a page that answers false to ui_page_t.tile leaves its cell
 * at zero vertices, and every page in the table today answers true. The page index is the only key
 * anything here needs \u2014 the sites, the cells, the names and the bake are all addressed by it \u2014 so a
 * compacted list would need a second mapping to get back to the page, and that mapping would exist
 * only to save one wasted pointer.
 */
static lv_obj_t *s_nav_label[PAGE_COUNT];
"""

STATE_B_OLD_START = "/* The navigator. */\nstatic lv_obj_t *s_nav;\n"
STATE_B_OLD_END = "static lv_obj_t *s_nav_label[PAGE_COUNT];\n"


def apply(text, start, end, new, label):
    i = text.find(start)
    if i < 0:
        raise SystemExit("%s: start anchor not found" % label)
    if text.count(start) != 1:
        raise SystemExit("%s: start anchor occurs %d times" % (label, text.count(start)))
    j = text.find(end, i)
    if j < 0:
        raise SystemExit("%s: end anchor not found after start" % label)
    j += len(end)
    span = text[i:j]
    if span.count(end) != 1:
        raise SystemExit("%s: end anchor is ambiguous inside the span" % label)
    print("%-10s replaced %5d -> %5d bytes" % (label, len(span), len(new)))
    return text[:i] + new + text[j:]


def main():
    with io.open(SRC, "r", encoding="utf-8", newline="\n") as fh:
        text = fh.read()

    text = apply(text, CONST_OLD_START, CONST_OLD_END, CONST_NEW, "constants")
    text = apply(text, STATE_B_OLD_START, STATE_B_OLD_END, STATE_B_NEW, "state")
    text = apply(text, STATE_OLD_START, STATE_OLD_END, STATE_NEW, "cells")
    text = apply(text, GEOM_OLD_START, GEOM_OLD_END, GEOM, "geometry")
    text = apply(text, MARK_OLD, MARK_OLD, MARK_NEW, "mark")
    text = apply(text, FLASH_OLD, FLASH_OLD, FLASH_NEW, "flash")
    text = apply(text, BUILD_OLD_START, BUILD_OLD_END, BUILD_NEW, "build")

    old = "painted by nav_cells_draw_cb(), which reads"
    if text.count(old) != 1:
        raise SystemExit("mark comment: %d occurrences" % text.count(old))
    text = text.replace(old, "painted by nav_bake(), which reads")
    print("mark-comm  replaced the painter's name")

    for dead in ("nav_cells_draw_cb", "nav_cell_frame", "nav_cell_invalidate",
                 "lv_draw_triangle", "nav_poly_offset"):
        n = text.count(dead)
        if n:
            raise SystemExit("leftover %r: %d occurrences" % (dead, n))

    with io.open(SRC, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(text)

    print("written:", SRC)
    return 0


if __name__ == "__main__":
    sys.exit(main())
