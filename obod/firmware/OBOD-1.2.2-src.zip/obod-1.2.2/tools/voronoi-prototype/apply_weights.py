"""Give every point on the map a weight, so that the cells' areas can be equal.

A weight is an addition to the squared distance: the cell of a point with a larger weight reaches
further, and one with a smaller weight reaches less far. That is a power diagram, and it still tiles
the screen exactly --- the seam between two cells is still one straight line and every pixel is still
claimed by exactly one cell, which is what the tap reads.

Without weights the cells cannot be equal: the mosaic fills the round screen, so the outer cells are
cut by the screen's own edge and a point cannot be moved to give them less of it. Measured on the
table as it stood, the outer cells were 5359 px2 and the middle one 3309; with the weights solved,
4426..4627, which is 4% either side of the share.

Run from the repository root after apply_overlay.py:
    python tools/voronoi-prototype/apply_weights.py
"""

import io
import os
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
SRC = os.path.join(ROOT, "components", "synth_ui", "src", "synth_ui.c")

LAYOUT = """/*
 * THE LAYOUT: one point per section, in tenths of a pixel from the middle of the screen, and a
 * weight in px2.
 *
 * These points ARE the map. A section's cell is every point of the screen that the section's point
 * claims, and the claim is `|p - s|^2 - w` against every other section's --- with the weight left at
 * zero that is the nearest point, and the weights are what make the cells' areas equal. One number
 * here moves one seam and no other, and there is no packing arithmetic to keep in step with it. The
 * arrangement can be dragged into shape and read back as a table, which is what this one was: it
 * came out of tools/voronoi-prototype/editor.html, where the points were moved by hand against the
 * measured cell areas and the room each name needs.
 *
 * WHY WEIGHTS AND NOT JUST POINTS. The mosaic covers the whole round screen, so the cells on the rim
 * are cut by the screen's own edge: they were 5359 px2 against the middle cell's 3309, and moving a
 * point only makes one cell larger at a neighbour's expense without changing how much of the disc is
 * there. A weight does: it moves that cell's seams and nothing else's. Measured, the weights below
 * bring the same arrangement to 4426..4627 px2, which is 4% either side of the share. They were
 * solved by tools/voronoi-prototype/areas.py, which is also where a new arrangement gets solved.
 *
 * The table is keyed by PAGE and not by position: the arrangement and the page numbering are two
 * different things --- the numbering is what the knob walks and what every address in this file uses,
 * and moving a cell must not be able to renumber a page.
 *
 * Tenths, because the table came out of a drag. Rounding it to whole pixels would move a seam by up
 * to half a pixel for no reason, and a cell is only sixty pixels across.
 */
static const int32_t NAV_SITES[PAGE_COUNT][3] = {
    [PAGE_PERC]     = {     2,     0, -1554 },  /* the middle: the percussion, which is struck */
    [PAGE_TONE]     = {     2,  -662, -1101 },  /* the lead family around it */
    [PAGE_ENV]      = {   518,  -412, -1112 },
    [PAGE_PERC_SEQ] = {   645,   148, -1138 },  /* the drum's figure, beside the percussion */
    [PAGE_ARP]      = {   287,   595, -1158 },
    [PAGE_EUCLID]   = {  -286,   596, -1154 },
    [PAGE_GEN]      = {  -643,   148, -1138 },
    [PAGE_LEAD]     = {  -514,  -411, -1117 },
    [PAGE_DRONE]    = {    -2, -1246,   739 },  /* then the body, at twelve o'clock */
    [PAGE_FILTER]   = {   523, -1085,   713 },
    [PAGE_MOD]      = {   976,  -774,   723 },
    [PAGE_MASTER]   = {  1175,  -263,   675 },  /* the mixers, down the right-hand side */
    [PAGE_MIX]      = {  1214,   283,   679 },
    [PAGE_SEND_REV] = {   938,   754,   632 },
    [PAGE_SEND_CHR] = {   537,  1124,   650 },
    [PAGE_SEND_DLY] = {    -2,  1204,   618 },
    [PAGE_SYS]      = {  -541,  1123,   652 },  /* the settings, down the left, into the presets */
    [PAGE_SYS2]     = {  -941,   751,   634 },
    [PAGE_PRESET]   = { -1214,   279,   676 },
    [PAGE_CHORUS]   = { -1173,  -265,   663 },  /* and the rack, up the left-hand side */
    [PAGE_DELAY]    = {  -976,  -773,   714 },
    [PAGE_VERB]     = {  -525, -1083,   705 },
};
_Static_assert(sizeof(NAV_SITES) / sizeof(NAV_SITES[0]) == PAGE_COUNT,
               "every page needs a point on the map");

/* The points are in tenths and the weights in px2, so a weight is a hundred tenths of a tenth. */
#define NAV_W_UNIT 100
"""

LAYOUT_OLD_START = "/*\n * THE LAYOUT: one point per section, in tenths of a pixel from the middle of the screen.\n"
LAYOUT_OLD_END = """               "every page needs a point on the map");
"""

CLIP_OLD = """            n = nav_clip(s_nav_v, n,
                         2.0f * (xj - xi), 2.0f * (yj - yi),
                         (xj * xj + yj * yj) - (xi * xi + yi * yi));
"""
CLIP_NEW = """            /* The same half-plane as before, with the weights added: a point's claim is
             * |p - s|^2 - w against every other's, so the seam between two of them is where
             * 2p(sj - si) = |sj|^2 - |si|^2 + (wj - wi). */
            n = nav_clip(s_nav_v, n,
                         2.0f * (xj - xi), 2.0f * (yj - yi),
                         ((xj * xj + yj * yj) - (xi * xi + yi * yi)) + (float)(wj - wi));
"""

TAP_OLD = """        const int32_t sx = NAV_SITES[i][0] - dx * 10;
        const int32_t sy = NAV_SITES[i][1] - dy * 10;
        const int32_t d2 = sx * sx + sy * sy;
"""
TAP_NEW = """        const int32_t sx = NAV_SITES[i][0] - dx * 10;
        const int32_t sy = NAV_SITES[i][1] - dy * 10;
        /* The same claim the cut used, and in the same units: tenths of a pixel for the distance,
         * px2 for the weight, one weight being a hundred of them. */
        const int32_t d2 = sx * sx + sy * sy - NAV_SITES[i][2] * NAV_W_UNIT;
"""


def apply(text, start, end, new, label):
    i = text.find(start)
    if i < 0:
        raise SystemExit("%s: start anchor not found" % label)
    if text.count(start) != 1:
        raise SystemExit("%s: start anchor occurs %d times" % (label, text.count(start)))
    j = text.find(end, i)
    if j < 0:
        raise SystemExit("%s: end anchor not found after start" % label)
    j += len(end)
    span = text[i:j]
    if span.count(end) != 1:
        raise SystemExit("%s: end anchor is ambiguous inside the span" % label)
    print("%-8s replaced %5d -> %5d bytes" % (label, len(span), len(new)))
    return text[:i] + new + text[j:]


def main():
    with io.open(SRC, "r", encoding="utf-8", newline="\n") as fh:
        text = fh.read()

    text = apply(text, LAYOUT_OLD_START, LAYOUT_OLD_END, LAYOUT, "table")
    text = apply(text, CLIP_OLD, CLIP_OLD, CLIP_NEW, "clip")
    text = apply(text, TAP_OLD, TAP_OLD, TAP_NEW, "tap")

    # The weights have to reach the cut: the measure loop reads them per pair.
    old = """        const float xi = (float)NAV_SITES[i][0] * 0.1f;
        const float yi = (float)NAV_SITES[i][1] * 0.1f;
"""
    new = """        const float xi = (float)NAV_SITES[i][0] * 0.1f;
        const float yi = (float)NAV_SITES[i][1] * 0.1f;
        const int32_t wi = NAV_SITES[i][2];
"""
    if text.count(old) != 1:
        raise SystemExit("site read: %d occurrences" % text.count(old))
    text = text.replace(old, new)
    print("wi       added the section's own weight")

    old = """            const float xj = (float)NAV_SITES[j][0] * 0.1f;
            const float yj = (float)NAV_SITES[j][1] * 0.1f;
"""
    new = """            const float xj = (float)NAV_SITES[j][0] * 0.1f;
            const float yj = (float)NAV_SITES[j][1] * 0.1f;
            const int32_t wj = NAV_SITES[j][2];
"""
    if text.count(old) != 1:
        raise SystemExit("neighbour read: %d occurrences" % text.count(old))
    text = text.replace(old, new)
    print("wj       added the neighbour's weight")

    with io.open(SRC, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(text)

    print("written:", SRC)
    return 0


if __name__ == "__main__":
    sys.exit(main())
