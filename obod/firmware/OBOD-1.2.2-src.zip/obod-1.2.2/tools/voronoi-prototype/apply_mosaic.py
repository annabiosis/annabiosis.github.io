"""Replace the round-chip map with the Voronoi mosaic, in place, with anchors checked.

Run from the repository root:
    python tools/voronoi-prototype/apply_mosaic.py

Every anchor must occur exactly once at the moment its block is applied, so a
silent no-op or a double replacement is impossible. The file is rewritten with LF
line endings; the sources are LF-only by convention.
"""

import io
import os
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
SRC = os.path.join(ROOT, "components", "synth_ui", "src", "synth_ui.c")

A_CONST = """/*
 * The navigator: the map of sections, laid out as a Voronoi mosaic.
 *
 * Every section owns one CELL, and a point of the glass belongs to the section whose point is
 * nearest to it \u2014 that is the whole rule, and it is the rule the finger obeys as well. The cells
 * therefore tile the disc by construction: there is no sliver between two of them for a tap to
 * fall through and no overlap for two to claim, and no packing arithmetic to keep in step, because
 * nothing is packed. A seam follows one neighbour rather than a ring.
 *
 * NAV_CELL_R is the mosaic's own edge. The rim's inner stroke is at 162 px, so 150 leaves twelve
 * pixels of air between the map and the rim: the map has to be read at a glance, and a cell
 * touching the rim would read as part of it.
 *
 * NAV_GON is the disc a cell is cut from, as a polygon. At 48 sides a chord sits 0.32 px inside the
 * true circle \u2014 under a pixel on a 360 px panel \u2014 and the arc is where most of an outer cell's
 * vertices come from, so the number is not free.
 */
#define NAV_CELL_R        150
#define NAV_GON            48
/*
 * The most vertices a cell has come out with (measured over the table in nav_measure(): eight),
 * and the room the cut works in. The work buffer cannot overflow: clipping a convex polygon by one
 * half-plane adds at most one vertex, so NAV_GON plus the number of sites is the ceiling and
 * NAV_WORK_V_MAX is above it with room to spare.
 */
#define NAV_CELL_V_MAX     12
#define NAV_WORK_V_MAX     96
/*
 * The cut between two cells: two pixels in the curtain's own colour, the same width the rim uses
 * between two sectors. A map read at arm's length needs its tiles separated by a gap rather than by
 * an outline, and an outline in a family colour would read as a seventh family.
 */
#define NAV_SEAM_W          2
/*
 * How far a finger may land outside the mosaic and still mean its edge. The reach is wider than
 * the drawing by this much, so a tap aimed at the outermost cell is not turned into a tap on the
 * curtain by a couple of pixels.
 */
#define NAV_TAP_SLACK       8
/*
 * The marks inside a cell. Nothing in a mosaic can grow, so the frame that used to mark the
 * current section by growing its tile to the full cell is now a frame inside the cell; the macro's
 * red keeps the outer ring and the current section takes the one inside it, so one cell can wear
 * both marks and neither can hide the other.
 */
#define NAV_MARK_INSET      3   /* px inside the cell's edge, where the macro's ring sits */
#define NAV_MARK_GAP        3   /* and how far the current section's frame is inside that */
#define NAV_MARK_W          2   /* the macro's ring, the rim's own mark thickness */
#define NAV_SELF_W          3   /* the current section's frame, wider: it is the place you are */
#define NAV_PI 3.14159265f
"""

A_CONST_OLD_START = "/*\n * The navigator: round buttons packed on a hex grid, panned by touch and zoomed\n"
A_CONST_OLD_END = "#define NAV_PI 3.14159265f\n"

B_STATE = """/* The navigator. */
static lv_obj_t *s_nav;
static lv_obj_t *s_nav_cells;      /* the mosaic: one object, painted by nav_cells_draw_cb() */
/*
 * One slot per PAGE, not one per tile: a page that answers false to ui_page_t.tile leaves its cell
 * at zero vertices, and every page in the table today answers true. The page index is the only key
 * anything here needs \u2014 the sites, the cells, the names and the painter are all addressed by it \u2014
 * so a compacted list would need a second mapping to get back to the page, and that mapping would
 * exist only to save one wasted pointer.
 */
static lv_obj_t *s_nav_label[PAGE_COUNT];
"""

B_OLD_START = "/* The navigator. */\nstatic lv_obj_t *s_nav;\n"
B_OLD_END = "static lv_obj_t *s_nav_btn_text[PAGE_COUNT];\n"

C_NOTE = """/*
 * The map's geometry is a TABLE now, not a modelled packing: NAV_SITES gives every page a point and
 * the cells are cut from those points once at boot (see nav_measure()). Nothing is sized for a page
 * count any more \u2014 a page without a point simply has no cell, and the hole in the mosaic is plainer
 * than an assertion would be. What is asserted is that the table covers the pages, and it is
 * asserted beside the table itself.
 */
"""

C_OLD_START = "/*\n * The map's numbers were modelled for the page table as it stands: twenty-one pages, every"
C_OLD_END = """#define NAV_PAGES_MODELLED 22
_Static_assert(PAGE_COUNT == NAV_PAGES_MODELLED,
               "the map's layout numbers were modelled for 21 pages \u2014 re-model them");
"""

D_STATE = """/*
 * The cells, cut once at boot from the table in nav_measure(): px offsets from the middle of the
 * disc, at most NAV_CELL_V_MAX of them to a page. s_nav_lx/ly is where that section's name sits,
 * which is the cell's own centroid \u2014 measured, the nearest edge is 25 px away from it at the worst,
 * against the 45 px of the longest name.
 *
 * s_nav_glow[i] is the rhythm's flash: the painter gives that cell the family's rim instead of its
 * chip, and nav_rhythm_refresh() is the only thing that sets it.
 */
static int16_t   s_nav_cell[PAGE_COUNT][NAV_CELL_V_MAX * 2];
static uint8_t   s_nav_cell_n[PAGE_COUNT];
static int16_t   s_nav_lx[PAGE_COUNT];
static int16_t   s_nav_ly[PAGE_COUNT];
static bool      s_nav_glow[PAGE_COUNT];
"""

D_OLD_START = "static int32_t   s_nav_ux[PAGE_COUNT];   /* layout positions, in tenths of a unit */"
D_OLD_END = "static float     s_nav_fit = 1.0f;       /* measured so the blob always fits */\n"

E_GEOM = """/*
 * THE LAYOUT: one point per section, in tenths of a pixel from the middle of the disc.
 *
 * These points ARE the map. A section's cell is every point of the glass that is nearer to its
 * point than to any other's, so one number here moves one seam and no other, and there is no
 * packing arithmetic to keep in step with it. The arrangement can be dragged into shape and read
 * back as a table, which is what this one was: it came out of
 * tools/voronoi-prototype/editor.html, where the points were moved by hand against the measured
 * cell areas and the room each name needs.
 *
 * The table is keyed by PAGE and not by position: the arrangement and the page numbering are two
 * different things \u2014 the numbering is what the knob walks and what every address in this file uses,
 * and moving a tile must not be able to renumber a page.
 *
 * Tenths, because the table came out of a drag. Rounding it to whole pixels would move a seam by up
 * to half a pixel for no reason, and a cell is only sixty pixels across.
 */
static const int32_t NAV_SITES[PAGE_COUNT][2] = {
    [PAGE_PERC]     = {     2,     0 },   /* the middle: the percussion, which is struck */
    [PAGE_TONE]     = {     2,  -662 },   /* the lead family around it */
    [PAGE_ENV]      = {   518,  -412 },
    [PAGE_PERC_SEQ] = {   645,   148 },   /* the drum's figure, beside the percussion */
    [PAGE_ARP]      = {   287,   595 },
    [PAGE_EUCLID]   = {  -286,   596 },
    [PAGE_GEN]      = {  -643,   148 },
    [PAGE_LEAD]     = {  -514,  -411 },
    [PAGE_DRONE]    = {    -2,  -1246 },  /* then the body, at twelve o'clock */
    [PAGE_FILTER]   = {   523,  -1085 },
    [PAGE_MOD]      = {   976,   -774 },
    [PAGE_MASTER]   = {  1175,   -263 },  /* the mixers, down the right-hand side */
    [PAGE_MIX]      = {  1214,    283 },
    [PAGE_SEND_REV] = {   938,    754 },
    [PAGE_SEND_CHR] = {   537,   1124 },
    [PAGE_SEND_DLY] = {    -2,   1204 },
    [PAGE_SYS]      = {  -541,   1123 },  /* the settings, down the left, into the presets */
    [PAGE_SYS2]     = {  -941,    751 },
    [PAGE_PRESET]   = { -1214,    279 },
    [PAGE_CHORUS]   = { -1173,   -265 },  /* and the rack, up the left-hand side */
    [PAGE_DELAY]    = {  -976,   -773 },
    [PAGE_VERB]     = {  -525,  -1083 },
};
_Static_assert(sizeof(NAV_SITES) / sizeof(NAV_SITES[0]) == PAGE_COUNT,
               "every page needs a point on the map");

/*
 * The cut's working room, and the file's rather than the stack's: nav_measure() runs once and needs
 * a buffer per clip, and a hundred floats twice over is not something to put on a task's stack.
 */
static float s_nav_v[NAV_WORK_V_MAX * 2];
static float s_nav_cut[NAV_WORK_V_MAX * 2];

/*
 * Clip a convex polygon by the half-plane a*x + b*y <= c, in place.
 *
 * The clip of a convex polygon by a half-plane is convex, and it adds at most one vertex per
 * crossing, so the buffer above can never overflow. A vertex that lands exactly on the line is kept
 * rather than dropped: a corner shared by three cells has to stay in all three, or the mosaic grows
 * a pinhole.
 */
static int nav_clip(float *v, int n, float a, float b, float c)
{
    int m = 0;

    for (int k = 0; k < n; k++) {
        const int j = (k + 1 == n) ? 0 : (k + 1);
        const float px = v[k * 2];
        const float py = v[k * 2 + 1];
        const float qx = v[j * 2];
        const float qy = v[j * 2 + 1];
        const float dp = a * px + b * py - c;
        const float dq = a * qx + b * qy - c;

        if (dp <= 0.0f) {
            s_nav_cut[m * 2] = px;
            s_nav_cut[m * 2 + 1] = py;
            m++;
        }

        if ((dp < 0.0f && dq > 0.0f) || (dq < 0.0f && dp > 0.0f)) {
            const float t = dp / (dp - dq);
            s_nav_cut[m * 2] = px + t * (qx - px);
            s_nav_cut[m * 2 + 1] = py + t * (qy - py);
            m++;
        }
    }

    for (int k = 0; k < m * 2; k++) {
        v[k] = s_nav_cut[k];
    }

    return m;
}

/*
 * Cut the cells, once, at boot.
 *
 * Each cell starts as the mosaic's own disc and is cut by one half-plane per other section: the
 * points at least as near to this section's point as to that one form a single half-plane, and its
 * boundary is the seam the two cells share. Twenty-one of those on at most nine vertices, for
 * twenty-two sections, is a few hundred multiplications spent once and never again \u2014 which is why
 * the cells are stored and the paint only draws.
 *
 * A vertex within half a pixel of the line through its neighbours is dropped: on the arc it is one
 * more triangle and no shape, and the chord it leaves is under a pixel off the circle.
 */
static void nav_measure(void)
{
    int v_max = 0;
    int area_lo = 0;
    int area_hi = 0;
    int clear_lo = 0;

    for (int i = 0; i < (int)PAGE_COUNT; i++) {
        s_nav_cell_n[i] = 0;

        if (!PAGES[i].tile) {
            continue;
        }

        const float xi = (float)NAV_SITES[i][0] * 0.1f;
        const float yi = (float)NAV_SITES[i][1] * 0.1f;

        for (int k = 0; k < NAV_GON; k++) {
            const float ang = 2.0f * NAV_PI * (float)k / (float)NAV_GON;
            s_nav_v[k * 2] = (float)NAV_CELL_R * cosf(ang);
            s_nav_v[k * 2 + 1] = (float)NAV_CELL_R * sinf(ang);
        }

        int n = NAV_GON;

        for (int j = 0; j < (int)PAGE_COUNT; j++) {
            if (j == i || !PAGES[j].tile) {
                continue;
            }

            const float xj = (float)NAV_SITES[j][0] * 0.1f;
            const float yj = (float)NAV_SITES[j][1] * 0.1f;

            n = nav_clip(s_nav_v, n,
                         2.0f * (xj - xi), 2.0f * (yj - yi),
                         (xj * xj + yj * yj) - (xi * xi + yi * yi));

            if (n < 3) {
                break;
            }
        }

        if (n < 3) {
            continue;
        }

        /* The straight ones out, the corners kept. */
        int keep = 0;

        for (int k = 0; k < n; k++) {
            const int p = (k + n - 1) % n;
            const int q = (k + 1) % n;
            const float ax = s_nav_v[p * 2], ay = s_nav_v[p * 2 + 1];
            const float bx = s_nav_v[k * 2], by = s_nav_v[k * 2 + 1];
            const float cx = s_nav_v[q * 2], cy = s_nav_v[q * 2 + 1];
            const float ex = cx - ax, ey = cy - ay;
            const float len = sqrtf(ex * ex + ey * ey);

            if (len > 0.01f && fabsf(ex * (by - ay) - ey * (bx - ax)) / len <= 0.5f) {
                continue;
            }

            if (keep < NAV_CELL_V_MAX) {
                s_nav_cut[keep * 2] = bx;
                s_nav_cut[keep * 2 + 1] = by;
            }

            keep++;
        }

        if (keep < 3 || keep > NAV_CELL_V_MAX) {
            /* Only reachable if the table is changed into something the buffer cannot hold. The
             * page then has no cell and the mosaic shows the hole, which is the honest failure. */
            ESP_LOGE(TAG, "map: page %d needs %d vertices, NAV_CELL_V_MAX is %d",
                     i, keep, NAV_CELL_V_MAX);
            continue;
        }

        /* The cell's own middle, and the room a name gets there: the nearest edge, which is what
         * decides whether a fourteen-pixel word fits across the cell. Both read off the same walk. */
        float area = 0.0f, mxs = 0.0f, mys = 0.0f;

        for (int k = 0; k < keep; k++) {
            const int q = (k + 1 == keep) ? 0 : (k + 1);
            const float x0 = s_nav_cut[k * 2], y0 = s_nav_cut[k * 2 + 1];
            const float x1 = s_nav_cut[q * 2], y1 = s_nav_cut[q * 2 + 1];
            const float cr = x0 * y1 - x1 * y0;

            area += cr;
            mxs += (x0 + x1) * cr;
            mys += (y0 + y1) * cr;
        }

        area *= 0.5f;

        float lx = xi;
        float ly = yi;

        if (fabsf(area) > 1.0f) {
            lx = mxs / (6.0f * area);
            ly = mys / (6.0f * area);
        }

        int clr = 1000;

        for (int k = 0; k < keep; k++) {
            const int q = (k + 1 == keep) ? 0 : (k + 1);
            const float x0 = s_nav_cut[k * 2], y0 = s_nav_cut[k * 2 + 1];
            const float x1 = s_nav_cut[q * 2], y1 = s_nav_cut[q * 2 + 1];
            const float ex = x1 - x0, ey = y1 - y0;
            const float len = sqrtf(ex * ex + ey * ey);

            if (len < 0.01f) {
                continue;
            }

            const float d = (ex * (ly - y0) - ey * (lx - x0)) / len;
            if (d < (float)clr) {
                clr = (int)d;
            }
        }

        for (int k = 0; k < keep; k++) {
            s_nav_cell[i][k * 2] = (int16_t)lroundf(s_nav_cut[k * 2]);
            s_nav_cell[i][k * 2 + 1] = (int16_t)lroundf(s_nav_cut[k * 2 + 1]);
        }

        s_nav_cell_n[i] = (uint8_t)keep;
        s_nav_lx[i] = (int16_t)lroundf(lx);
        s_nav_ly[i] = (int16_t)lroundf(ly);

        if (keep > v_max) {
            v_max = keep;
        }

        const int ar = (int)(area + 0.5f);
        if (area_lo == 0 || ar < area_lo) {
            area_lo = ar;
        }
        if (ar > area_hi) {
            area_hi = ar;
        }
        if (clear_lo == 0 || clr < clear_lo) {
            clear_lo = clr;
        }
    }

    /* Said out loud once: the area of a cell is what a tap aims at and the clearance is what a
     * name lives in, and both are decided by the table above and by nothing else. */
    ESP_LOGI(TAG, "map: %d cells of %d..%d px2 on r %d, %d vertices at most, %d px of label room",
             (int)PAGE_COUNT, area_lo, area_hi, NAV_CELL_R, v_max, clear_lo);
}

/* The screen box a cell covers, cut side included: false when the page has no cell. */
static bool nav_cell_box(int page, lv_area_t *out)
{
    const int n = s_nav_cell_n[page];

    if (n < 3 || s_nav_cells == NULL) {
        return false;
    }

    lv_area_t obj;
    lv_obj_get_coords(s_nav_cells, &obj);

    const int32_t cx = (obj.x1 + obj.x2) / 2;
    const int32_t cy = (obj.y1 + obj.y2) / 2;

    int32_t x1 = 32000, y1 = 32000, x2 = -32000, y2 = -32000;

    for (int k = 0; k < n; k++) {
        const int32_t x = cx + s_nav_cell[page][k * 2];
        const int32_t y = cy + s_nav_cell[page][k * 2 + 1];

        if (x < x1) {
            x1 = x;
        }
        if (x > x2) {
            x2 = x;
        }
        if (y < y1) {
            y1 = y;
        }
        if (y > y2) {
            y2 = y;
        }
    }

    out->x1 = x1;
    out->y1 = y1;
    out->x2 = x2;
    out->y2 = y2;

    /* A seam is two pixels wide and straddles the boundary; the margin only has to cover it. */
    lv_area_increase(out, NAV_SEAM_W + 1, NAV_SEAM_W + 1);

    return true;
}

/* Paint one cell again, and only its box. */
static void nav_cell_invalidate(int page)
{
    lv_area_t box;

    if (nav_cell_box(page, &box)) {
        lv_obj_invalidate_area(s_nav_cells, &box);
    }
}

/*
 * Which cell a point of the glass belongs to, or -1 for "not the map".
 *
 * The answer is the nearest point, which is exactly what the cells are: the painter cuts them from
 * these numbers and this reads the same numbers back, so a tap cannot land on a tile other than the
 * one it was shown. The reach is the mosaic's own radius plus NAV_TAP_SLACK; past that the tap
 * belongs to the curtain, which closes the map.
 *
 * The distances are taken in tenths, where the table is, so the comparison is exact and needs no
 * division by ten that could round two neighbours into a tie.
 */
static int nav_page_at(const lv_point_t *p)
{
    if (s_nav_cells == NULL) {
        return -1;
    }

    lv_area_t obj;
    lv_obj_get_coords(s_nav_cells, &obj);

    const int32_t dx = p->x - (obj.x1 + obj.x2) / 2;
    const int32_t dy = p->y - (obj.y1 + obj.y2) / 2;
    const int32_t reach = NAV_CELL_R + NAV_TAP_SLACK;

    if (dx * dx + dy * dy > reach * reach) {
        return -1;
    }

    int best = -1;
    int32_t best_d2 = 0;

    for (int i = 0; i < (int)PAGE_COUNT; i++) {
        if (!PAGES[i].tile) {
            continue;
        }

        const int32_t sx = NAV_SITES[i][0] - dx * 10;
        const int32_t sy = NAV_SITES[i][1] - dy * 10;
        const int32_t d2 = sx * sx + sy * sy;

        if (best < 0 || d2 < best_d2) {
            best = i;
            best_d2 = d2;
        }
    }

    return best;
}

/*
 * A frame along a cell's edge, `inset` pixels inside it: the cell's own polygon with every edge
 * pushed toward the middle, and the vertices put back where the pushed edges cross.
 *
 * Both of those are always defined because a cell is convex, and the inward normal of an edge is
 * (-dy, dx) because nav_measure() leaves every cell wound the same way. A pair of edges crossing at
 * a very shallow angle \u2014 two nearly-collinear points of an arc \u2014 is left where it is: the crossing
 * point would be far away, and the vertex is within the line's own width anyway.
 */
static void nav_cell_frame(lv_layer_t *layer, int page, int32_t ox, int32_t oy,
                           int inset, int width, uint32_t color)
{
    const int n = s_nav_cell_n[page];

    if (n < 3) {
        return;
    }

    float nx[NAV_CELL_V_MAX], ny[NAV_CELL_V_MAX], nc[NAV_CELL_V_MAX];
    float rx[NAV_CELL_V_MAX], ry[NAV_CELL_V_MAX];

    for (int k = 0; k < n; k++) {
        const int q = (k + 1 == n) ? 0 : (k + 1);
        const float ax = (float)s_nav_cell[page][k * 2];
        const float ay = (float)s_nav_cell[page][k * 2 + 1];
        const float ex = (float)s_nav_cell[page][q * 2] - ax;
        const float ey = (float)s_nav_cell[page][q * 2 + 1] - ay;
        const float len = sqrtf(ex * ex + ey * ey);

        if (len < 0.01f) {
            nx[k] = 0.0f;
            ny[k] = 0.0f;
            nc[k] = 0.0f;
            continue;
        }

        nx[k] = -ey / len;
        ny[k] = ex / len;
        /* The edge in normal form, n.p = c: pushed in by `inset`, c moves by exactly that much. */
        nc[k] = nx[k] * ax + ny[k] * ay + (float)inset;
        rx[k] = ax;
        ry[k] = ay;
    }

    for (int k = 0; k < n; k++) {
        const int p = (k + n - 1) % n;
        const float det = nx[p] * ny[k] - ny[p] * nx[k];

        if (fabsf(det) < 0.2f) {
            rx[k] = rx[k] + (float)inset * nx[k];
            ry[k] = ry[k] + (float)inset * ny[k];
            continue;
        }

        rx[k] = (nc[p] * ny[k] - nc[k] * ny[p]) / det;
        ry[k] = (nx[p] * nc[k] - nx[k] * nc[p]) / det;
    }

    lv_draw_line_dsc_t line;
    lv_draw_line_dsc_init(&line);
    line.color = lv_color_hex(color);
    line.width = width;
    line.opa = LV_OPA_COVER;

    for (int k = 0; k < n; k++) {
        const int q = (k + 1 == n) ? 0 : (k + 1);

        line.p1.x = ox + (int32_t)lroundf(rx[k]);
        line.p1.y = oy + (int32_t)lroundf(ry[k]);
        line.p2.x = ox + (int32_t)lroundf(rx[q]);
        line.p2.y = oy + (int32_t)lroundf(ry[q]);
        lv_draw_line(layer, &line);
    }
}

/*
 * The mosaic, painted on one object and on nothing else.
 *
 * A cell is a polygon, and LVGL has no polygon widget that is not a vector \u2014 so the cells are drawn
 * with the two primitives that do exist: a triangle fan for the fill, which a convex cell allows by
 * construction, and lv_draw_line for the cut between two cells and for the marks. Twenty-two cells
 * of at most nine vertices is a hundred-odd triangles for a full paint, and a full paint happens
 * when the map opens and when the page behind it changes \u2014 never while a value moves.
 *
 * THE CLIP IS WHAT MAKES THE RHYTHM CHEAP. A cell whose box misses the layer's clip area is skipped
 * before a single triangle is built, so three flashing tiles repaint three cells a frame while the
 * other nineteen are not touched. The rim's marks use the same trick for the same reason.
 */
static void nav_cells_draw_cb(lv_event_t *e)
{
    if (lv_event_get_target(e) != s_nav_cells) {
        return;
    }

    lv_layer_t *layer = lv_event_get_layer(e);
    const lv_area_t clip = layer->_clip_area;

    lv_area_t obj;
    lv_obj_get_coords(s_nav_cells, &obj);

    const int32_t ox = (obj.x1 + obj.x2) / 2;
    const int32_t oy = (obj.y1 + obj.y2) / 2;

    /*
     * The cut, and the air around the mosaic, are the curtain's own colour: the cells are read as
     * lying ON it, and a seam in any other colour would read as a family of its own.
     */
    const lv_color_t seam =
        lv_color_hex(tint(GROUP_COLOR[PAGES[s_page].group].fill, TINT_BG));

    lv_area_t box;
    lv_draw_triangle_dsc_t tri;
    lv_draw_line_dsc_t line;

    /* The fills first, all of them: a cut drawn inside its own cell's turn is painted over by the
     * next cell's fill wherever the two share an edge. */
    for (int i = 0; i < (int)PAGE_COUNT; i++) {
        if (!nav_cell_box(i, &box) || !viz_area_hits(&box, &clip)) {
            continue;
        }

        const int n = s_nav_cell_n[i];
        const nav_group_color_t *g = &GROUP_COLOR[PAGES[i].group];

        lv_draw_triangle_dsc_init(&tri);
        tri.opa = LV_OPA_COVER;
        /* A flashing cell is its family's rim \u2014 the step a turned sector's hairline is drawn in \u2014 so
         * the flash says "this part is sounding" in a colour the map already uses. */
        tri.color = lv_color_hex(s_nav_glow[i] ? g->rim : g->tile);

        for (int k = 1; k + 1 < n; k++) {
            tri.p[0].x = ox + s_nav_cell[i][0];
            tri.p[0].y = oy + s_nav_cell[i][1];
            tri.p[1].x = ox + s_nav_cell[i][k * 2];
            tri.p[1].y = oy + s_nav_cell[i][k * 2 + 1];
            tri.p[2].x = ox + s_nav_cell[i][(k + 1) * 2];
            tri.p[2].y = oy + s_nav_cell[i][(k + 1) * 2 + 1];
            lv_draw_triangle(layer, &tri);
        }
    }

    /* Then the cuts, in one pass: two cells share an edge, so most of them are drawn twice, over
     * each other, in the same colour and in the same place. */
    lv_draw_line_dsc_init(&line);
    line.color = seam;
    line.width = NAV_SEAM_W;
    line.opa = LV_OPA_COVER;

    for (int i = 0; i < (int)PAGE_COUNT; i++) {
        if (!nav_cell_box(i, &box) || !viz_area_hits(&box, &clip)) {
            continue;
        }

        const int n = s_nav_cell_n[i];

        for (int k = 0; k < n; k++) {
            const int q = (k + 1 == n) ? 0 : (k + 1);

            line.p1.x = ox + s_nav_cell[i][k * 2];
            line.p1.y = oy + s_nav_cell[i][k * 2 + 1];
            line.p2.x = ox + s_nav_cell[i][q * 2];
            line.p2.y = oy + s_nav_cell[i][q * 2 + 1];

            lv_area_t seg;
            seg.x1 = ((line.p1.x < line.p2.x) ? line.p1.x : line.p2.x) - NAV_SEAM_W;
            seg.x2 = ((line.p1.x > line.p2.x) ? line.p1.x : line.p2.x) + NAV_SEAM_W;
            seg.y1 = ((line.p1.y < line.p2.y) ? line.p1.y : line.p2.y) - NAV_SEAM_W;
            seg.y2 = ((line.p1.y > line.p2.y) ? line.p1.y : line.p2.y) + NAV_SEAM_W;

            if (!viz_area_hits(&seg, &clip)) {
                continue;
            }

            lv_draw_line(layer, &line);
        }
    }

    /*
     * The marks, last and each inside its own cell.
     *
     * The two questions a mark answers are different ones \u2014 "is this section wired into the macro"
     * and "am I standing here" \u2014 so they are two frames rather than two shades of one, and a
     * section can wear both at once. The macro keeps the outer ring in its own red, the same red a
     * sector's arc turns when it joins a macro.
     */
    for (int i = 0; i < (int)PAGE_COUNT; i++) {
        if (!nav_cell_box(i, &box) || !viz_area_hits(&box, &clip)) {
            continue;
        }

        const nav_group_color_t *g = &GROUP_COLOR[PAGES[i].group];

        if (page_has_macro(&PAGES[i])) {
            nav_cell_frame(layer, i, ox, oy, NAV_MARK_INSET, NAV_MARK_W, COL_MACRO_RIM);
        }

        if (i == (int)s_page) {
            nav_cell_frame(layer, i, ox, oy, NAV_MARK_INSET + NAV_MARK_GAP, NAV_SELF_W, g->ink);
        }
    }
}

"""
E_OLD_START = "/*\n * Work out the honeycomb once, in units, and measure how big it came out."
E_OLD_END = "             (float)NAV_TILE_UNIT * s_nav_fit);\n}\n"

F_LAYOUT = """static void nav_layout(void)
{
    for (int i = 0; i < (int)PAGE_COUNT; i++) {
        if (s_nav_label[i] == NULL) {
            continue;
        }

        /*
         * The name sits at the cell's own middle and nowhere else: the cells are cut from the
         * table once and never move, so there is nothing here to fit, grow or dodge. The face is
         * the same 14 px the chips carried \u2014 the cell is bigger, and what a bigger cell bought is
         * the room around the word, not a larger word.
         */
        lv_obj_align(s_nav_label[i], LV_ALIGN_CENTER, s_nav_lx[i], s_nav_ly[i]);
    }

    /* The current section's frame and the macro marks are painted with the mosaic, so a page
     * change is a repaint of it and of nothing else. */
    if (s_nav_cells != NULL) {
        lv_obj_invalidate(s_nav_cells);
    }
}
"""
F_OLD_START = "static void nav_layout(void)\n{\n    const float scale = s_nav_fit;"
F_OLD_END = """    /*
     * Nothing hangs over the honeycomb any more: the transport is a screen of its own,
     * reached by a swipe up, so the map is chips and nothing else. s_nav_top_ut is
     * still recorded by nav_measure() and is now unread; it stays because deleting it
     * would mean editing the measurement this layout was approved from, and it costs
     * one int32_t.
     */
}
"""

G_MARK = """/*
 * The current section, the sections wired into the macro, and the family's colour behind the whole
 * curtain.
 *
 * The mosaic draws the tiles, so what is left here is what the tiles are painted FROM: the curtain
 * takes the current family's tint, the names take their family's ink, and the two marks \u2014 the
 * current section's frame and the macro's red \u2014 are painted by nav_cells_draw_cb(), which reads
 * s_page and page_has_macro() itself rather than a copy of either. Repainting the mosaic is
 * therefore the whole of "the marks moved", and nothing can fall out of step with them.
 *
 * Called when the map opens and when the page behind it changes: never while a value moves.
 */
static void nav_mark_current(void)
{
    if (s_nav == NULL) {
        return;
    }

    /* The curtain is a surface like the page behind it, and it follows the same
     * family \u2014 opening the map should not leave the colour behind. */
    lv_obj_set_style_bg_color(s_nav,
                              lv_color_hex(tint(GROUP_COLOR[PAGES[s_page].group].fill, TINT_BG)),
                              LV_PART_MAIN);

    for (int i = 0; i < (int)PAGE_COUNT; i++) {
        const nav_group_color_t *g = &GROUP_COLOR[PAGES[i].group];

        /* A tile is a solid cell of its family's colour and nothing else: no rim of its own. The
         * colour IS the tile, which is the only way six hues stay nameable at this size \u2014 six
         * outlines of six hues would read as six kinds of border rather than as six colours. */
        if (s_nav_label[i] != NULL) {
            text_color(s_nav_label[i], g->ink);
        }

        /* A flash left over from the last time the map was up is put back here, or a tile caught
         * mid-flash would stay bright for as long as the map is. */
        s_nav_glow[i] = false;
    }

    if (s_nav_cells != NULL) {
        lv_obj_invalidate(s_nav_cells);
    }
}
"""
G_OLD_START = "/* The current section: an accent ring on its button and its name spelled out, so"
G_OLD_END = """        if (s_nav_btn_text[i] != NULL) {
            text_color(s_nav_btn_text[i], ink);
        }
    }


}
"""

H_TAP = """/*
 * A tap on the map.
 *
 * There is no button per section any more, and nothing to re-aim: the mosaic covers the disc with
 * cells that are exactly "nearest to this point", so the tap IS the cell it lands in and the answer
 * cannot disagree with the drawing. Nearest centre used to be a guess that corrected a ring of round
 * tiles; here it is the definition.
 *
 * A tap outside the mosaic lands on the curtain and closes the map, which is the dismissal the map
 * has always had. A tap inside it always opens something \u2014 there is no sliver between two cells for
 * a near miss to fall into.
 */
static void nav_bg_cb(lv_event_t *e)
{
    (void)e;

    /* A finger that was swiping is not choosing a section, and the press still ends as a click on
     * whatever it started on. The curtain does not move under the finger at all, so this is the
     * only thing left that can hold a tap back. */
    if (swipe_just_happened()) {
        return;
    }

    lv_indev_t *indev = lv_indev_active();
    if (indev == NULL) {
        return;
    }

    lv_point_t p;
    lv_indev_get_point(indev, &p);

    const int idx = nav_page_at(&p);

    nav_close();

    if (idx >= 0) {
        jump_to(idx);
    }
}

"""
H_OLD_START = "static void nav_btn_cb(lv_event_t *e)\n{"
H_OLD_END = "    nav_close();\n}\n\n"

I_FLASH_NEW = """        /*
         * The flash is the mosaic's, and so is the colour: this says which cells are lit and asks
         * for those cells to be painted again. Every cell the strip of screen being painted does
         * not touch is skipped by the painter, so a frame here costs three cells and not the map.
         *
         * The lit step is the family's rim \u2014 one Material step above the chip in every family. The
         * named fill step cannot be used, because in the percussion green it IS the chip colour,
         * which is how that tile came to look dead while the page beside it pulsed.
         */
        if (s_nav_glow[i] != on) {
            s_nav_glow[i] = on;
            nav_cell_invalidate(i);
        }
"""
I_OLD_START = "        const nav_group_color_t *g = &GROUP_COLOR[PAGES[i].group];\n        /*\n         * The lit step is the family's bright colour taken down to TINT_STEP"
I_OLD_END = """        lv_obj_set_style_bg_color(s_nav_disc[i],
                                  lv_color_hex(on ? lit : g->tile),
                                  LV_PART_MAIN);
"""

I2_OLD = "        if (s_nav_disc[i] == NULL) {\n            continue;\n        }\n"
I2_NEW = "        if (s_nav_cell_n[i] < 3) {\n            continue;\n        }\n"

J_BUILD = """    /*
     * The mosaic, on an object of its own: transparent, not clickable, and created before the names
     * so that the names are painted over it. A tap falls through it to the curtain, which owns the
     * click and answers it by the nearest point \u2014 see nav_bg_cb().
     */
    s_nav_cells = lv_obj_create(s_nav);
    lv_obj_remove_style_all(s_nav_cells);
    lv_obj_set_size(s_nav_cells, 360, 360);
    lv_obj_center(s_nav_cells);
    lv_obj_set_style_opa(s_nav_cells, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_clear_flag(s_nav_cells, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_clickable(s_nav_cells, false);
    lv_obj_set_click_focusable(s_nav_cells, false);
    suppress_theme_focus_decoration(s_nav_cells);
    lv_obj_add_event_cb(s_nav_cells, nav_cells_draw_cb, LV_EVENT_DRAW_MAIN, NULL);

    for (int i = 0; i < (int)PAGE_COUNT; i++) {
        /*
         * A page without a cell gets no name either: nav_measure() has already left its cell at
         * zero vertices, and the painter draws nothing for it.
         */
        if (!PAGES[i].tile) {
            continue;
        }

        /* The SHORT name, in the same 14 px it had on the chip: the cell is bigger, and the answer
         * to a bigger cell was the layout, not a larger face. See ui_page_t for why every page
         * carries two names. */
        s_nav_label[i] = make_label(s_nav, PAGES[i].tile_label, &lv_font_anbscreen_14, COL_TEXT,
                                    LV_ALIGN_CENTER, s_nav_lx[i], s_nav_ly[i]);
        text_condensed(s_nav_label[i], -1);
    }
"""
J_OLD_START = """    for (int i = 0; i < (int)PAGE_COUNT; i++) {
        /*
         * A page without a tile gets no cell at all"""
J_OLD_END = """        s_nav_disc[i] = disc;
        s_nav_btn[i] = btn;
    }
"""


def apply(text, start, end, new, label):
    i = text.find(start)
    if i < 0:
        raise SystemExit("%s: start anchor not found" % label)
    if text.count(start) != 1:
        raise SystemExit("%s: start anchor occurs %d times" % (label, text.count(start)))
    j = text.find(end, i)
    if j < 0:
        raise SystemExit("%s: end anchor not found after start" % label)
    j += len(end)
    span = text[i:j]
    if span.count(end) != 1:
        raise SystemExit("%s: end anchor is ambiguous inside the span" % label)
    print("%-10s replaced %5d -> %5d bytes" % (label, len(span), len(new)))
    return text[:i] + new + text[j:]


def main():
    with io.open(SRC, "r", encoding="utf-8", newline="\n") as fh:
        text = fh.read()

    text = apply(text, A_CONST_OLD_START, A_CONST_OLD_END, A_CONST, "constants")
    text = apply(text, B_OLD_START, B_OLD_END, B_STATE, "state")
    text = apply(text, C_OLD_START, C_OLD_END, C_NOTE, "modelled")
    text = apply(text, D_OLD_START, D_OLD_END, D_STATE, "arrays")
    text = apply(text, E_OLD_START, E_OLD_END, E_GEOM, "geometry")
    text = apply(text, F_OLD_START, F_OLD_END, F_LAYOUT, "layout")
    text = apply(text, G_OLD_START, G_OLD_END, G_MARK, "mark")
    text = apply(text, H_OLD_START, H_OLD_END, H_TAP, "tap")
    text = apply(text, I_OLD_START, I_OLD_END, I_FLASH_NEW, "flash")
    text = apply(text, I2_OLD, I2_OLD, I2_NEW, "guard")
    text = apply(text, J_OLD_START, J_OLD_END, J_BUILD, "build")

    for dead in ("s_nav_btn", "s_nav_disc", "s_nav_ux", "s_nav_uy", "s_nav_fit",
                 "s_nav_top_ut", "nav_ring_angle", "NAV_ORDER", "NAV_TILE_UNIT",
                 "NAV_HIT_UNIT", "NAV_BTN_UNIT", "NAV_GAP_UNIT", "NAV_FIT_R",
                 "NAV_RING1_N", "NAV_TAP_EXTRA", "nav_btn_cb", "NAV_PAGES_MODELLED"):
        n = text.count(dead)
        if n:
            raise SystemExit("leftover %r: %d occurrences" % (dead, n))

    with io.open(SRC, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(text)

    print("written:", SRC)
    return 0


if __name__ == "__main__":
    sys.exit(main())
