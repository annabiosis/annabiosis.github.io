# -*- coding: utf-8 -*-
"""
Прототип ПЛИТКИ ВОРОНОГО ДЛЯ КАРТЫ РАЗДЕЛОВ (верхняя шторка) — не для прибора, только посмотреть.

Что здесь моделируется: плитка карты, а не панели подписи ручек. Карта — это шторка,
которая приходит сверху и показывает по плитке на каждую страницу (см. NAV_ORDER и
nav_measure() в synth_ui.c). Сегодняшние плитки — кружки 96 единиц на соты медовых
шестиугольников с шагом 106 единиц; здесь тот же набор разделов раскладывается
диаграммой Вороного внутри диска и меряется, что из этого выходит.

Кадры (out/):
  today.png        сегодняшняя карта, для сравнения
  vd-same.png      Вороного по сегодняшним центрам, кружки оставлены — читаются швы
  vd-cells.png     ячейка и есть плитка: подпись в центре Чебышёва, цвет семейства
  vd-spiral.png    то же, но точки по спирали (равномернее по площади)
  vd-hit.png       карта попаданий: каждый пиксель — цвет ближайшей плитки

Отчёт печатается: площади ячеек, запас под текст, площади касания против сегодняшних.
"""

import math
import os

from PIL import Image, ImageDraw, ImageFont

# --- геометрия прибора -------------------------------------------------------

SIZE = 360
S = 2                                   # кадр 720x720 для просмотра
C = SIZE / 2.0

NAV_TILE_UNIT = 96                      # кружок плитки, единиц
NAV_HIT_UNIT = 106                      # сота касания, единиц (NAV_BTN_UNIT + NAV_GAP_UNIT)
NAV_RING1_N = 7
NAV_FIT_R = 152                         # куда ставится внешний край нарисованной плитки, px

R_DISC = 150.0                          # диск, в котором живёт мозаика, px
R_RIM_IN = 162                          # внутренний край обода

COL_BG = (4, 16, 13)
COL_TRACK = (12, 43, 36)
COL_FAINT = (30, 68, 59)
COL_TEXT = (214, 238, 232)
COL_DIM = (120, 160, 152)

# GROUP_COLOR из synth_ui.c: плитка, обод, яркий, текст, чернила
GROUPS = [
    (0x0D47A1, 0x1976D2, 0x64B5F6, 0x90CAF9),   # GRP_DRONE   синий
    (0x4A148C, 0xAB47BC, 0xBA68C8, 0xCE93D8),   # GRP_LEAD    фиолетовый
    (0x004D40, 0x00796B, 0x4DB6AC, 0x80CBC4),   # GRP_GEN     бирюзовый
    (0x1B5E20, 0x2E7D32, 0x66BB6A, 0xA5D6A7),   # GRP_PERC    зелёный
    (0x880E4F, 0xE91E63, 0xF06292, 0xF48FB1),   # GRP_FX      розовый
    (0x3E2723, 0x5D4037, 0xA1887F, 0xBCAAA4),   # GRP_MIX     коричневый
    (0x263238, COL_FAINT, 0x90A4AE, 0x90A4AE),  # GRP_VIEW    серый
    (0x455A64, 0x455A64, 0x90A4AE, 0xCFD8DC),   # GRP_PRESET  светлее серый
]

# Подписи плиток карты и семейство: второй столбец PAGES[] в synth_ui.c, восьмой — группа.
# Порядок — как в NAV_ORDER, то есть как плитки раскладываются по кольцам.
NAV_TILES = [
    ("PERC", 3),
    ("TONE", 1), ("ENV", 1), ("PSEQ", 3), ("ARP", 2), ("EUCL", 2), ("GEN", 2), ("LEAD", 1),
    ("DRONE", 0), ("FLTR", 0), ("MOD", 0), ("MSTR", 5), ("LVLS", 5), ("REVS", 5),
    ("CHRS", 5), ("DELS", 5), ("SYS", 6), ("OPT", 6), ("PRST", 7), ("CHOR", 4),
    ("DLY", 4), ("REV", 4),
]

FONT_DIR = r"C:\Windows\Fonts"
FONT_MONO = os.path.join(FONT_DIR, "consola.ttf")
FONT_MONO_B = os.path.join(FONT_DIR, "consolab.ttf")


def font(path, px):
    try:
        return ImageFont.truetype(path, px)
    except OSError:
        return ImageFont.load_default()


def hex_rgb(v):
    return ((v >> 16) & 0xFF, (v >> 8) & 0xFF, v & 0xFF)


# --- сегодняшняя раскладка (nav_measure) -------------------------------------


def ring_angle(ring, m, a):
    if ring == 0:
        return 0.0
    return -math.pi / 2.0 + a * (2.0 * math.pi / m)


def honeycomb_sites(n):
    """Центры плиток в единицах, ровно как их считает nav_measure()."""
    hit_half = NAV_HIT_UNIT / 2.0
    ring_n = [1 if n > 0 else 0, min(max(n - 1, 0), NAV_RING1_N), 0]
    ring_n[2] = n - ring_n[0] - ring_n[1]

    ring_r = [0.0, 0.0, 0.0]
    ring_r[1] = (hit_half / math.sin(math.pi / (ring_n[1] + (ring_n[1] % 2 == 0)))
                 if ring_n[1] > 1 else 0.0)
    ring_r[2] = (hit_half / math.sin(math.pi / (ring_n[2] + 1)) if ring_n[2] > 0 else 0.0)

    if ring_n[2] > 0 and ring_n[1] > 1:
        for _ in range(4000):
            closest = 1.0e9
            for a in range(ring_n[1]):
                a1 = ring_angle(1, ring_n[1], a)
                x1, y1 = ring_r[1] * math.cos(a1), ring_r[1] * math.sin(a1)
                for b in range(ring_n[2]):
                    a2 = ring_angle(2, ring_n[2], b)
                    dx = ring_r[2] * math.cos(a2) - x1
                    dy = ring_r[2] * math.sin(a2) - y1
                    closest = min(closest, dx * dx + dy * dy)
            if closest >= NAV_HIT_UNIT * NAV_HIT_UNIT:
                break
            ring_r[2] += 0.5

    sites = []
    for ring in range(3):
        m, rr = ring_n[ring], ring_r[ring]
        for a in range(m):
            ang = ring_angle(ring, m, a)
            sites.append((rr * math.cos(ang), rr * math.sin(ang)))
    return sites[:n], ring_n, ring_r


def spiral_sites(n):
    """Спираль Вогеля: площадь на точку одна и та же — ячейки выходят ровнее."""
    pts = []
    for i in range(n):
        r = math.sqrt((i + 0.5) / n)
        a = i * 2.0 * math.pi * (1.0 - 1.0 / 1.61803398875)
        pts.append((r * math.cos(a), r * math.sin(a)))
    return pts


# --- диаграмма Вороного ------------------------------------------------------


def disc_polygon(r, steps=180):
    return [(r * math.cos(2 * math.pi * k / steps), r * math.sin(2 * math.pi * k / steps))
            for k in range(steps)]


def clip_halfplane(poly, a, b, c):
    out = []
    n = len(poly)
    for i in range(n):
        p, q = poly[i], poly[(i + 1) % n]
        dp = a * p[0] + b * p[1] - c
        dq = a * q[0] + b * q[1] - c
        if dp <= 0.0:
            out.append(p)
        if (dp < 0.0 < dq) or (dq < 0.0 < dp):
            t = dp / (dp - dq)
            out.append((p[0] + t * (q[0] - p[0]), p[1] + t * (q[1] - p[1])))
    return out


def voronoi(sites, weights=None, r=R_DISC):
    w = weights or [0.0] * len(sites)
    cells = []
    for i, si in enumerate(sites):
        poly = disc_polygon(r)
        for j, sj in enumerate(sites):
            if i == j:
                continue
            a = 2.0 * (sj[0] - si[0])
            b = 2.0 * (sj[1] - si[1])
            c = (sj[0] ** 2 + sj[1] ** 2) - (si[0] ** 2 + si[1] ** 2) + w[i] - w[j]
            poly = clip_halfplane(poly, a, b, c)
            if len(poly) < 3:
                break
        cells.append(poly)
    return cells


def poly_area(poly):
    s = 0.0
    for i in range(len(poly)):
        x1, y1 = poly[i]
        x2, y2 = poly[(i + 1) % len(poly)]
        s += x1 * y2 - x2 * y1
    return abs(s) / 2.0


def chebyshev(poly, iters=140):
    """Точка, максимально удалённая от краёв ячейки, и расстояние до ближайшего края."""
    best, best_d = None, -1.0
    xs = [p[0] for p in poly]
    ys = [p[1] for p in poly]
    x0, x1 = min(xs), max(xs)
    y0, y1 = min(ys), max(ys)
    step = max(x1 - x0, y1 - y0) / 2.0
    cx, cy = (x0 + x1) / 2.0, (y0 + y1) / 2.0
    for _ in range(iters):
        for dx in (-step, 0.0, step):
            for dy in (-step, 0.0, step):
                px, py = cx + dx, cy + dy
                d = min_edge_distance(poly, px, py)
                if d > best_d:
                    best_d, best = d, (px, py)
        if best is not None:
            cx, cy = best
        step *= 0.6
    return best, best_d


def min_edge_distance(poly, px, py):
    d = 1.0e9
    n = len(poly)
    for i in range(n):
        ax, ay = poly[i]
        bx, by = poly[(i + 1) % n]
        ex, ey = bx - ax, by - ay
        L = math.hypot(ex, ey)
        if L < 1e-9:
            continue
        # расстояние до ПРЯМОЙ, а не до отрезка: внутри выпуклой ячейки это и есть запас
        d = min(d, abs(ex * (py - ay) - ey * (px - ax)) / L)
    return d


# --- рисование ---------------------------------------------------------------


def base_frame():
    img = Image.new("RGB", (int(SIZE * S), int(SIZE * S)), COL_BG)
    d = ImageDraw.Draw(img)
    cx = cy = C * S
    d.ellipse([cx - R_RIM_IN * S, cy - R_RIM_IN * S, cx + R_RIM_IN * S, cy + R_RIM_IN * S],
              outline=COL_TRACK, width=2)
    return img, d


def dev(pts):
    """Точки ячейки (px прибора) в пиксели кадра."""
    return [(C * S + x * S, C * S + y * S) for x, y in pts]


def draw_text_center(d, text, x, y, px, fill):
    f = font(FONT_MONO, px)
    w = d.textlength(text, font=f)
    d.text((x - w / 2.0, y - px * 0.62), text, font=f, fill=fill)


def render_today_units(units_sites):
    """Сегодняшняя карта: кружки NAV_TILE_UNIT с шагом NAV_HIT_UNIT и подписью внутри."""
    ext = max(math.hypot(*s) for s in units_sites)
    scale = NAV_FIT_R / (ext + NAV_TILE_UNIT / 2.0)
    img, d = base_frame()
    for i, (x, y) in enumerate(units_sites):
        _, _, bright, ink = GROUPS[NAV_TILES[i][1]]
        tile = hex_rgb(GROUPS[NAV_TILES[i][1]][0])
        px = (C + x * scale) * S
        py = (C + y * scale) * S
        rr = NAV_TILE_UNIT / 2.0 * scale * S
        d.ellipse([px - rr, py - rr, px + rr, py + rr], fill=tile, outline=hex_rgb(bright))
        draw_text_center(d, NAV_TILES[i][0], px, py, 14 * S, hex_rgb(ink))
    return img, scale


def render_voronoi_over_chips(units_sites):
    """Вороного по сегодняшним центрам: кружки на месте, ячейки только как швы."""
    ext = max(math.hypot(*s) for s in units_sites)
    scale = NAV_FIT_R / (ext + NAV_TILE_UNIT / 2.0)
    cells = voronoi([(x * scale, y * scale) for x, y in units_sites])
    img, d = base_frame()
    for poly in cells:
        d.polygon([(C + p[0], C + p[1]) for p in poly], outline=COL_FAINT)
    for i, (x, y) in enumerate(units_sites):
        _, _, bright, ink = GROUPS[NAV_TILES[i][1]]
        px, py = (C + x * scale) * S, (C + y * scale) * S
        rr = NAV_TILE_UNIT / 2.0 * scale * S
        d.ellipse([px - rr, py - rr, px + rr, py + rr], fill=hex_rgb(GROUPS[NAV_TILES[i][1]][0]),
                  outline=hex_rgb(bright))
        draw_text_center(d, NAV_TILES[i][0], px, py, 14 * S, hex_rgb(ink))
    return img, cells, scale


def render_cells(sites_px, label_scale=1.0):
    """Ячейка и есть плитка: заливка семейства, шов фоном, подпись в центре Чебышёва."""
    cells = voronoi(sites_px)
    img, d = base_frame()
    stats = []
    for i, poly in enumerate(cells):
        fill = hex_rgb(GROUPS[NAV_TILES[i][1]][0])
        d.polygon(dev(poly), fill=fill, outline=COL_BG)
        cen, clear = chebyshev(poly)
        stats.append((poly_area(poly), clear, cen))
    for i, (poly, (area, clear, cen)) in enumerate(zip(cells, stats)):
        _, _, bright, ink = GROUPS[NAV_TILES[i][1]]
        px, py = (C + cen[0]) * S, (C + cen[1]) * S
        f = font(FONT_MONO, 14 * S)
        w = d.textlength(NAV_TILES[i][0], font=f) / S
        need = w / 2.0
        if need < clear:
            draw_text_center(d, NAV_TILES[i][0], px, py, 14 * S, hex_rgb(ink))
    return img, cells, stats


def render_hit(sites_px):
    """Карта попаданий: каждый пиксель диска — ближайшая плитка; считаем непокрытые."""
    img = Image.new("RGB", (SIZE, SIZE), (0, 0, 0))
    px = img.load()
    bad = 0
    for y in range(SIZE):
        for x in range(SIZE):
            dx, dy = x + 0.5 - C, y + 0.5 - C
            if dx * dx + dy * dy > R_DISC * R_DISC:
                continue
            best, bi = 1e18, -1
            for i, (sx, sy) in enumerate(sites_px):
                d2 = (dx - sx) ** 2 + (dy - sy) ** 2
                if d2 < best:
                    best, bi = d2, i
            if bi < 0:
                bad += 1
                continue
            px[x, y] = hex_rgb(GROUPS[NAV_TILES[bi][1]][2])
    return img.resize((SIZE * S, SIZE * S), Image.NEAREST), bad


# --- отчёт -------------------------------------------------------------------


def report_cells(tag, cells, stats):
    areas = [a for a, _, _ in stats]
    clears = [c for _, c, _ in stats]
    lo, hi = min(areas), max(areas)
    avg = sum(areas) / len(areas)
    print("  %-12s площади %.0f..%.0f px2 (средняя %.0f, разброс x%.2f), запас под текст %.1f..%.1f px"
          % (tag, lo, hi, avg, hi / lo, min(clears), max(clears)))
    tight = [(NAV_TILES[i][0], round(c, 1)) for i, (_, c, _) in enumerate(stats) if c < 16]
    if tight:
        print("               тесно: " + ", ".join("%s %.1f" % t for t in tight))
    # сколько подписей влезает при 14 px моно
    fits = 0
    for i, (_, c, _) in enumerate(stats):
        w = 0.6 * 14 * len(NAV_TILES[i][0])
        fits += 1 if w / 2.0 <= c else 0
    print("               подпись 14 px влезает у %d из %d" % (fits, len(stats)))


def main():
    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "out")
    os.makedirs(out, exist_ok=True)

    units, ring_n, ring_r = honeycomb_sites(len(NAV_TILES))
    ext = max(math.hypot(*s) for s in units)
    scale = NAV_FIT_R / (ext + NAV_TILE_UNIT / 2.0)
    print("сегодня: %d плиток, кольца %s, радиусы %.1f/%.1f единиц, масштаб %.4f, кружок %.1f px"
          % (len(units), "/".join(str(x) for x in ring_n), ring_r[1], ring_r[2], scale,
             NAV_TILE_UNIT * scale))
    today_r = NAV_TILE_UNIT / 2.0 * scale
    print("  площадь касания одной плитки сегодня: круг %.1f px радиусом = %.0f px2"
          % (today_r, math.pi * today_r * today_r))

    img, scale_today = render_today_units(units)
    img.save(os.path.join(out, "today.png"))

    img, cells_same, _ = render_voronoi_over_chips(units)
    img.save(os.path.join(out, "vd-same.png"))

    # мозаика из тех же центров: точки сжимаются так, чтобы диск оставался в 150 px
    shrink = 118.0 / ext
    sites_same = [(x * shrink, y * shrink) for x, y in units]
    img, cells, stats = render_cells(sites_same)
    img.save(os.path.join(out, "vd-cells.png"))
    report_cells("vd-cells", cells, stats)

    spir = spiral_sites(len(NAV_TILES))
    sites_spir = [(x * 118.0, y * 118.0) for x, y in spir]
    img, cells2, stats2 = render_cells(sites_spir)
    img.save(os.path.join(out, "vd-spiral.png"))
    report_cells("vd-spiral", cells2, stats2)

    hit, bad = render_hit(sites_same)
    hit.save(os.path.join(out, "vd-hit.png"))
    print("карта попаданий: непокрытых пикселей внутри диска %d" % bad)
    print("кадры в " + out)


if __name__ == "__main__":
    main()
