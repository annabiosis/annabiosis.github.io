"""The same mosaic at three cell depths, side by side, so the seam can be judged off the device.

The seam is the surface showing through between two cells, so how loudly it reads is set by how far
a cell's fill sits below it: at its palette step the cell is a bright tile in a black net, and every
step down moves the whole mosaic towards the line instead of away from it.

The cells and the weights come from check_cracks.py, which builds them exactly as nav_measure()
does; the colours come out of MAP_TONE in the firmware, so this strip cannot drift from what is
flashed.

    python tools/voronoi-prototype/sink_strip.py [build/sink-strip.png]
"""

import importlib.util
import io
import os
import re
import sys

from PIL import Image, ImageDraw, ImageFont

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
SRC = os.path.join(ROOT, "components", "synth_ui", "src", "synth_ui.c")

FACTORS = (256, 176, 140, 110)   # of 256; 256 is the palette step itself, unsunk
SIZE = 360
SS = 3
SEAM = 2
BG = (0x04, 0x10, 0x0D)


def load_cells():
    path = os.path.join(os.path.dirname(__file__), "check_cracks.py")
    spec = importlib.util.spec_from_file_location("check_cracks", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod.cells()


def load_tones():
    text = io.open(SRC, encoding="utf-8", newline="\n").read()
    block = text[text.index("static const nav_map_tone_t MAP_TONE"):]
    block = block[:block.index("};")]
    rows = re.findall(r"\{\s*0x([0-9A-Fa-f]{6}),\s*0x([0-9A-Fa-f]{6}),\s*0x([0-9A-Fa-f]{6}),"
                      r"\s*0x([0-9A-Fa-f]{6})\s*\}", block)
    if len(rows) != 8:
        raise SystemExit("MAP_TONE: %d rows" % len(rows))
    return [tuple(int(v, 16) for v in row) for row in rows]


def rgb(v):
    return ((v >> 16) & 255, (v >> 8) & 255, v & 255)


def sink(col, factor):
    return tuple(c * factor // 256 for c in col)


NAMES = ["PERC", "TONE", "ENV", "PSEQ", "ARP", "EUCL", "GEN", "LEAD", "DRONE", "FLTR", "MOD",
         "MSTR", "LVLS", "REVS", "CHRS", "DELS", "SYS", "OPT", "PRST", "CHOR", "DLY", "REV"]
GROUPS = [3, 1, 1, 3, 2, 2, 2, 1, 0, 0, 0, 5, 5, 5, 5, 5, 6, 6, 7, 4, 4, 4]


def centroid(poly):
    a = cx = cy = 0.0
    for i in range(len(poly)):
        p, q = poly[i], poly[(i + 1) % len(poly)]
        cross = p[0] * q[1] - q[0] * p[1]
        a += cross
        cx += (p[0] + q[0]) * cross
        cy += (p[1] + q[1]) * cross
    a *= 0.5
    return (cx / (6 * a), cy / (6 * a))


def panel(polys, tones, factor, font):
    img = Image.new("RGB", (SIZE * SS, SIZE * SS), BG)
    d = ImageDraw.Draw(img)

    for i, poly in enumerate(polys):
        if len(poly) < 3:
            continue
        cell, here, tag, _flash = tones[GROUPS[i]]
        col = sink(rgb(cell), factor)
        pts = [((SIZE / 2 + x) * SS, (SIZE / 2 + y) * SS) for x, y in poly]
        d.polygon(pts, fill=col, outline=BG)
        # Шов той же ширины, что в прошивке: две точки на пиксель меньше по краю.
        d.line(pts + [pts[0]], fill=BG, width=int(SEAM * SS), joint="curve")

    for i, poly in enumerate(polys):
        if len(poly) < 3:
            continue
        _cell, _here, tag, _flash = tones[GROUPS[i]]
        x, y = centroid(poly)
        label = NAMES[i]
        w = d.textlength(label, font=font)
        d.text(((SIZE / 2 + x) * SS - w / 2, (SIZE / 2 + y) * SS - 14 * SS / 2),
               label, font=font, fill=rgb(tag))

    return img


def main():
    out = sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, "build", "sink-strip.png")
    polys = load_cells()
    tones = load_tones()

    font = None
    for path in ("C:/Windows/Fonts/consola.ttf", "C:/Windows/Fonts/arial.ttf"):
        if os.path.exists(path):
            font = ImageFont.truetype(path, 14 * SS)
            break

    strip = Image.new("RGB", (SIZE * SS * len(FACTORS) + 8 * (len(FACTORS) - 1),
                              SIZE * SS + 22), (0x06, 0x1A, 0x15))
    for k, f in enumerate(FACTORS):
        strip.paste(panel(polys, tones, f, font), (k * (SIZE * SS + 8), 22))
        ImageDraw.Draw(strip).text((k * (SIZE * SS + 8) + 6, 3),
                                   "NAV_CELL_DARK %d" % f, fill=(0xD6, 0xEE, 0xE8))
    strip.save(out)
    print("saved", out, strip.size)


if __name__ == "__main__":
    main()
