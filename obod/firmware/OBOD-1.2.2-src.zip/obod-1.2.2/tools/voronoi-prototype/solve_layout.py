"""Solve the map's weights for the points in the firmware's table, and print the table back.

The points decide WHERE the seams are and the weights decide how much of the disc each cell gets.
Only the points are worth dragging: a point moved on its own takes area from its neighbours and
leaves the rim as stretched as it was, because how much of the disc exists does not change. A weight
moves that one cell's seams and nothing else's, so a layout dragged by hand is finished by solving
twenty-two weights for equal areas.

The solver is a damped Newton step on the areas, with one weight pinned: adding the same constant to
every weight changes no cell, so the level is not part of the answer. The Jacobian is taken
numerically, which is honest here — a cell's area against a weight is monotone but not smooth at the
moment a vertex appears, and a finite difference is what the map actually does.

    python tools/voronoi-prototype/solve_layout.py            # the table, solved again
    python tools/voronoi-prototype/solve_layout.py --check    # only the report, no table

The clipping below is nav_measure()'s, down to the half-pixel simplification, and the claim is the
one it cuts by: a cell is where `|p - s|^2 + w` is smallest, so a LARGER WEIGHT IS A SMALLER CELL.
"""

import math
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
SOURCE = os.path.join(ROOT, "components", "synth_ui", "src", "synth_ui.c")

CELL_R = 180.0
GON = 64

ROW = re.compile(r"\[(PAGE_[A-Z0-9_]+)\s*\]\s*=\s*\{\s*(-?\d+)\s*,\s*(-?\d+)\s*,\s*(-?\d+)\s*\}")


def read_table():
    """The table as it stands, so a drag never has to be typed in twice."""
    text = open(SOURCE, encoding="utf-8").read()
    start = text.index("NAV_SITES[PAGE_COUNT][3]")
    end = text.index("};", start)
    rows = []
    for m in ROW.finditer(text[start:end]):
        rows.append((m.group(1), int(m.group(2)), int(m.group(3)), int(m.group(4))))
    if not rows:
        raise SystemExit("no rows found in %s" % SOURCE)
    return rows


def clip(poly, a, b, c):
    out = []
    n = len(poly)
    for i in range(n):
        p = poly[i]
        q = poly[(i + 1) % n]
        dp = a * p[0] + b * p[1] - c
        dq = a * q[0] + b * q[1] - c
        if dp <= 0:
            out.append(p)
        if (dp < 0 < dq) or (dq < 0 < dp):
            t = dp / (dp - dq)
            out.append((p[0] + t * (q[0] - p[0]), p[1] + t * (q[1] - p[1])))
    return out


def simplify(poly, tol=0.5):
    keep = []
    for i in range(len(poly)):
        ax, ay = poly[i - 1]
        bx, by = poly[i]
        cx, cy = poly[(i + 1) % len(poly)]
        ex, ey = cx - ax, cy - ay
        ln = math.hypot(ex, ey)
        if ln > 0.01 and abs(ex * (by - ay) - ey * (bx - ax)) / ln <= tol:
            continue
        keep.append((bx, by))
    return keep


def cells(points, weights):
    out = []
    for i, s in enumerate(points):
        poly = [(CELL_R * math.cos(2 * math.pi * k / GON), CELL_R * math.sin(2 * math.pi * k / GON))
                for k in range(GON)]
        for j, t in enumerate(points):
            if i == j:
                continue
            a = 2 * (t[0] - s[0])
            b = 2 * (t[1] - s[1])
            c = (t[0] ** 2 + t[1] ** 2) - (s[0] ** 2 + s[1] ** 2) + (weights[j] - weights[i])
            poly = clip(poly, a, b, c)
        out.append(simplify(poly) if len(poly) >= 3 else [])
    return out


def area(poly):
    a = 0.0
    for i in range(len(poly)):
        x0, y0 = poly[i]
        x1, y1 = poly[(i + 1) % len(poly)]
        a += x0 * y1 - x1 * y0
    return abs(a) * 0.5


def centroid(poly):
    a = cx = cy = 0.0
    for i in range(len(poly)):
        x0, y0 = poly[i]
        x1, y1 = poly[(i + 1) % len(poly)]
        cr = x0 * y1 - x1 * y0
        a += cr
        cx += (x0 + x1) * cr
        cy += (y0 + y1) * cr
    a *= 0.5
    return (cx / (6 * a), cy / (6 * a))


def label_room(poly):
    """The narrowest way out of the middle: the room a fourteen-pixel name has across the cell."""
    cx, cy = centroid(poly)
    best = 1e9
    for i in range(len(poly)):
        ax, ay = poly[i]
        bx, by = poly[(i + 1) % len(poly)]
        ex, ey = bx - ax, by - ay
        ln = math.hypot(ex, ey)
        if ln < 0.01:
            continue
        best = min(best, abs(ex * (cy - ay) - ey * (cx - ax)) / ln)
    return best


def gauss(A, b):
    n = len(b)
    A = [row[:] + [b[i]] for i, row in enumerate(A)]
    for c in range(n):
        p = max(range(c, n), key=lambda r: abs(A[r][c]))
        if abs(A[p][c]) < 1e-12:
            return None
        A[c], A[p] = A[p], A[c]
        for r in range(n):
            if r != c:
                f = A[r][c] / A[c][c]
                for k in range(c, n + 1):
                    A[r][k] -= f * A[c][k]
    return [A[i][n] / A[i][i] for i in range(n)]


def solve(points, iters=60, damp=1e-6, h=0.5):
    n = len(points)
    w = [0.0] * n
    free = list(range(1, n))          # the level is not part of the answer
    for _ in range(iters):
        ar = [area(p) for p in cells(points, w)]
        tgt = sum(ar) / n
        res = [ar[i] - tgt for i in free]
        if max(abs(r) for r in res) < 0.5:
            break
        J = [[0.0] * len(free) for _ in free]
        for col, j in enumerate(free):
            wp = list(w)
            wp[j] += h
            arp = [area(p) for p in cells(points, wp)]
            for row, i in enumerate(free):
                J[row][col] = (arp[i] - ar[i]) / h
        M = [[sum(J[r][k] * J[c][k] for k in range(len(free))) for c in range(len(free))]
             for r in range(len(free))]
        v = [-sum(J[r][k] * res[k] for k in range(len(free))) for r in range(len(free))]
        for r in range(len(free)):
            M[r][r] += damp * max(1.0, abs(M[r][r]))
        step = gauss(M, v)
        if step is None:
            break
        worst = max(abs(s) for s in step)
        if worst > 600.0:
            step = [s * 600.0 / worst for s in step]
        for col, j in enumerate(free):
            w[j] += step[col]
    return [round(x) for x in w]


def report(points, weights, tag):
    c = cells(points, [float(x) for x in weights])
    ar = [area(p) for p in c]
    room = [label_room(p) for p in c if len(p) > 2]
    empty = [i for i, p in enumerate(c) if len(p) < 3]
    print("%-10s area %4.0f..%4.0f (x%.3f), label room %4.1f..%4.1f px, vertices %d..%d%s"
          % (tag, min(ar), max(ar), max(ar) / min(ar), min(room), max(room),
             min(len(p) for p in c), max(len(p) for p in c),
             ", EMPTY %s" % empty if empty else ""))
    return c


def main():
    rows = read_table()
    points = [(x / 10.0, y / 10.0) for _, x, y, _ in rows]
    have = [w for _, _, _, w in rows]
    report(points, have, "as shipped")
    if "--check" in sys.argv:
        return
    solved = solve(points)
    cells_solved = report(points, solved, "solved")

    if "--write" in sys.argv:
        text = open(SOURCE, encoding="utf-8").read()
        for (ident, _, _, _), w in zip(rows, solved):
            pat = re.compile(r"(\[%s\s*\]\s*=\s*\{\s*-?\d+\s*,\s*-?\d+\s*,\s*)(-?\d+)(\s*\})" % ident)
            if not pat.search(text):
                raise SystemExit("row %s not found while writing" % ident)
            text = pat.sub(lambda m: m.group(1) + "%6d" % w + m.group(3), text, count=1)
        open(SOURCE, "w", encoding="utf-8", newline="\n").write(text)
        print("\nwritten to %s" % os.path.relpath(SOURCE, ROOT))
        return

    print()
    for (ident, x, y, _), w, poly in zip(rows, solved, cells_solved):
        cx, cy = centroid(poly) if len(poly) > 2 else (0.0, 0.0)
        print("    [%-15s] = {%5d, %5d, %5d },   /* middle %5.1f,%5.1f */"
              % (ident, x, y, w, cx, cy))


if __name__ == "__main__":
    main()
