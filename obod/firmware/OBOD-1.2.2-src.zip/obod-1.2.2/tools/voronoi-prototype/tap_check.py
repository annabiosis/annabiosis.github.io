"""Does the tap answer with the cell that is drawn under the finger?

The cells are cut once, in nav_measure(), from the table's points and weights. A tap has to answer
with the same cell, which means the same comparison in the same direction: a point belongs to the
cell whose claim is smallest, and the claim the cut uses is dist^2 + w — that is what the
half-plane 2p(sj - si) <= |sj|^2 - |si|^2 + (wj - wi) describes. A tap that reads dist^2 - w
answers with the mirror image of the whole map: the cells with a negative weight, which are the
inner ones, get smaller instead of bigger, and a press on one of them lands in its outer neighbour.

    python tools/voronoi-prototype/tap_check.py
"""

import importlib.util
import os

HERE = os.path.dirname(__file__)


def load():
    spec = importlib.util.spec_from_file_location("check_cracks", os.path.join(HERE, "check_cracks.py"))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def main():
    m = load()
    sites = [(x / 10.0, y / 10.0) for x, y, w in m.SITES]
    weights = [w for _, _, w in m.SITES]
    names = m.NAMES
    real = m.cells()

    def nearest(px, py, sign):
        best, best_d = -1, 0.0
        for i, (sx, sy) in enumerate(sites):
            d = (sx - px) ** 2 + (sy - py) ** 2 + sign * weights[i]
            if best < 0 or d < best_d:
                best, best_d = i, d
        return best

    wrong = {1: 0, -1: 0}
    pairs = {}
    total = 0
    for py in range(0, 360, 3):
        for px in range(0, 360, 3):
            lx, ly = px - 180, py - 180
            if lx * lx + ly * ly > 174 * 174:
                continue
            owner = -1
            for i, poly in enumerate(real):
                if len(poly) > 2 and m.inside(poly, lx, ly):
                    owner = i
                    break
            if owner < 0:
                continue
            total += 1
            for sign in (1, -1):
                got = nearest(lx, ly, sign)
                if got != owner:
                    wrong[sign] += 1
                    pairs.setdefault((names[owner], names[got]), 0)
                    pairs[(names[owner], names[got])] += 1

    print("points inside a cell: %d" % total)
    for sign, label in ((1, "dist^2 + w  (the way the cells were cut)"),
                        (-1, "dist^2 - w  (the opposite way)")):
        print("%-40s wrong at %4d points (%.1f%%)" % (label, wrong[sign], 100.0 * wrong[sign] / total))

    worst = sorted(pairs.items(), key=lambda kv: -kv[1])[:8]
    if worst:
        print("most common mismatches, drawn -> opened:")
        for (drawn, opened), n in worst:
            print("  %-5s -> %-5s  %d points" % (drawn, opened, n))

    for name in ("PSEQ", "ARP"):
        i = names.index(name)
        print("%s: the cell is drawn with weight %d, so a tap on it must read %.0f + w"
              % (name, weights[i], 0.0))


if __name__ == "__main__":
    main()
