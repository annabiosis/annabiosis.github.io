"""Render the mosaic as the firmware would bake it, with or without the area weights.

Takes the fills out of a captured frame (so the colours are the ones the device uses), draws the
cells inset by a pixel with the seams showing the surface, and puts the two candidates side by side:

    python tools/voronoi-prototype/preview.py web/assets/screens/drawer.png build/mosaic-compare.png
"""

import math
import sys
from collections import Counter

from PIL import Image, ImageDraw

import areas

CELL_R = 180
SS = 4
INSET = 1.0

# Solved by areas.py --weights: the outer band shrinks, the inner seven grow, and every cell ends up
# within 4% of its share of the disc.
WEIGHTS = {
    "PERC": -1554, "TONE": -1101, "ENV": -1112, "PSEQ": -1138, "ARP": -1158, "EUCL": -1154,
    "GEN": -1138, "LEAD": -1117, "DRONE": 739, "FLTR": 713, "MOD": 723, "MSTR": 675,
    "LVLS": 679, "REVS": 632, "CHRS": 650, "DELS": 618, "SYS": 652, "OPT": 634,
    "PRST": 676, "CHOR": 663, "DLY": 714, "REV": 705,
}


def offset(poly, d):
    n = len(poly)
    lines = []
    for i in range(n):
        ax, ay = poly[i]
        bx, by = poly[(i + 1) % n]
        ex, ey = bx - ax, by - ay
        ln = math.hypot(ex, ey)
        if ln < 0.01:
            lines.append((0.0, 0.0, 0.0))
            continue
        nx, ny = -ey / ln, ex / ln
        lines.append((nx, ny, nx * ax + ny * ay + d))

    out = []
    for k in range(n):
        nxp, nyp, cp = lines[k - 1]
        nx, ny, c = lines[k]
        det = nxp * ny - nyp * nx
        if abs(det) < 0.2:
            out.append((poly[k][0] + d * nx, poly[k][1] + d * ny))
        else:
            out.append(((cp * ny - c * nyp) / det, (nxp * c - nx * cp) / det))
    return out


def fills(img, old_cells):
    """The colour of each cell, read off the frame it was baked into."""
    px = img.load()
    w, h = img.size
    cx, cy = w / 2.0, h / 2.0
    out = []
    for poly in old_cells:
        counts = Counter()
        x1 = int(min(p[0] for p in poly) + cx)
        x2 = int(max(p[0] for p in poly) + cx)
        y1 = int(min(p[1] for p in poly) + cy)
        y2 = int(max(p[1] for p in poly) + cy)
        for y in range(y1 - 1, y2 + 2):
            for x in range(x1 - 1, x2 + 2):
                if not (0 <= x < w and 0 <= y < h):
                    continue
                if areas.clearance(poly, (x + 0.5 - cx, y + 0.5 - cy)) > 5.0:
                    counts[px[x, y]] += 1
        out.append(counts.most_common(1)[0][0] if counts else (0, 0, 0))
    return out


def panel(cells, cols, bg, names, label_pts):
    img = Image.new("RGB", (CELL_R * 2 * SS + 8, CELL_R * 2 * SS + 8), bg)
    draw = ImageDraw.Draw(img)
    cx = cy = (CELL_R * SS) + 4

    for poly, col in zip(cells, cols):
        pts = [((cx + x * SS), (cy + y * SS)) for x, y in offset(poly, INSET)]
        draw.polygon(pts, fill=col)

    font = None
    for path in ("C:/Windows/Fonts/consola.ttf", "C:/Windows/Fonts/arial.ttf"):
        try:
            from PIL import ImageFont
            font = ImageFont.truetype(path, 14 * SS)
            break
        except Exception:
            continue

    for (x, y), name in zip(label_pts, names):
        tw = draw.textlength(name, font=font) if font else len(name) * 3 * SS
        draw.text((cx + x * SS - tw / 2, cy + y * SS - 7 * SS), name, font=font,
                  fill=(230, 245, 240))

    return img.resize((CELL_R * 2 + 8, CELL_R * 2 + 8), Image.LANCZOS)


def main(src, dst):
    img = Image.open(src).convert("RGB")
    pts = [(x / 10.0, y / 10.0) for x, y in areas.SITES]

    old = areas.build(pts)
    cols = fills(img, old)

    w = [WEIGHTS[n] for n in areas.NAMES]
    new = areas.build(pts, w)

    labels = []
    for poly in old:
        c = areas.centroid(poly)
        labels.append(c)

    a = panel(old, cols, (0x04, 0x10, 0x0D), areas.NAMES, labels)
    b = panel(new, cols, (0x04, 0x10, 0x0D), areas.NAMES, labels)

    out = Image.new("RGB", (a.width * 2 + 12, a.height), (0x04, 0x10, 0x0D))
    out.paste(a, (0, 0))
    out.paste(b, (a.width + 12, 0))
    out.save(dst)
    print("wrote", dst)

    for tag, cells in (("now", old), ("eq", new)):
        ars = [abs(areas.area(p)) for p in cells]
        print("  %-4s %4d..%4d px2" % (tag, min(ars), max(ars)))


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "web/assets/screens/drawer.png",
         sys.argv[2] if len(sys.argv) > 2 else "build/mosaic-compare.png")
