/*
 * synth_ui — the instrument's control surface.
 *
 * One screen, five pages, and the encoder drives exactly one thing at a time.
 * See the note in synth_ui.c for why that is a hardware constraint rather than a
 * design choice.
 */
#pragma once

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Build the instrument screen on the active screen.
 *
 * Runs under the LVGL lock, inside ui_app_init_with_screen(), which is also what
 * puts the screen's focusable control under the knob:
 *
 *     ESP_ERROR_CHECK(ui_app_init_with_screen(NULL, synth_ui_build));
 */
void synth_ui_build(void);

/*
 * Take the LED ring over for a moment: the whole ring goes `color` for hold_ms,
 * then the drone display resumes on its own.
 *
 * The ring belongs to the drone — it is the one output that can be read from
 * across the room, and it shows where the three registers sit in the stereo
 * field. Network state still has to be able to interrupt that, so it borrows the
 * ring rather than owning it, and gives it back. A permanent writer per
 * subsystem would leave the ring showing whichever spoke last.
 *
 * Safe to call from any task, including before synth_ui_build(); it only stores
 * state.
 */
void synth_ui_ring_notify(uint8_t r, uint8_t g, uint8_t b, uint32_t hold_ms);

#ifdef __cplusplus
}
#endif
