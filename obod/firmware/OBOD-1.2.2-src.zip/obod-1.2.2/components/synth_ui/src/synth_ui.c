/*
 * synth_ui — the instrument's control surface.
 *
 * THE SHAPE IS FORCED BY THE HARDWARE
 *   There is no push button, so LVGL never receives an ENTER. The BSP therefore
 *   holds the input group in edit mode permanently, and an encoder in edit mode
 *   changes the value of the focused widget and nothing else.
 *
 *   So the screen carries EXACTLY ONE focusable widget on every page, and
 *   everything else is reached by touch. Tappable things are plain lv_obj rather
 *   than lv_button, which keeps them out of the knob's path while leaving them
 *   tappable.
 *
 * THE SECTORS
 *   Several parameters share a page and one knob has to move whichever is
 *   selected. The screen is a circle, so the natural division is sectors of the
 *   rim: each parameter owns one, its arc hugs the rim, and its value is printed
 *   inside it. Nothing is hidden behind a mode — every value on the page is on
 *   screen at once, which is the whole reason to divide the rim rather than
 *   stack pages.
 *
 *   How many sectors there are decides where they start, and the rim is always
 *   divided into EQUAL parts:
 *
 *     4  quarters from 9 o'clock: 9, 12, 3 and 6, tiling the rim exactly
 *     3  thirds from 12 o'clock: 12, 4 and 8, the three points of a Mercedes
 *        star
 *     2  halves from 9 o'clock: the top half, then the bottom half
 *     1  the whole rim, because a single parameter has nothing to be separated
 *        from
 *
 *   Equal parts rather than a fixed 90 degrees each, because two parameters have
 *   no reason to share the rim with a quarter of it left empty — and a wider
 *   sector is a longer arc, which is a finer readout for the same knob travel.
 *   The starting points differ because each is a named position, not because
 *   the arithmetic wants them to.
 *
 *   The arcs fill clockwise, always. On a circle there is no such thing as
 *   "left to right" for the lower half, so the invariant that survives is
 *   rotation: more is always further clockwise, which reads left to right in the
 *   top sector and is consistent everywhere else. Reversing per sector would
 *   make the same gesture mean opposite things on different parameters.
 *
 * THE FOCUS PROXY
 *   The knob's target and the visible arcs are deliberately different objects.
 *
 *   Four visible arcs cannot be the knob's target: ui_app builds the focus group
 *   from widget classes and lv_arc is one of them, so they would put four
 *   candidates in the group, break the BSP's "exactly one" rule and make taps
 *   fight the focus. Worse, an lv_arc's hit test is its 352x352 bounding box,
 *   not the drawn ring, so four of them would swallow every tap on the screen.
 *
 *   So the visible arcs are INDICATORS: not clickable, which makes ui_app's
 *   is_eligible() reject them and keeps their huge bounding boxes out of the hit
 *   test. Selection is handled by separate touch areas, which are plain lv_obj —
 *   not a focusable class, so never collected.
 *
 *   What the knob drives is one small transparent arc at the centre: the focus
 *   proxy. It is the group's only member on every page, which also means the
 *   group is never empty — that is what silences bsp_encoder's "nothing
 *   focusable is in the group" complaint on pages that have no controls.
 *
 * TAP AND LONG PRESS
 *   A tap selects the sector the knob will move. A long press selects it AND
 *   toggles its membership in the macro — the set of parameters that move
 *   together on one turn, so LEVEL and CUTOFF and stereo width can be tilted as
 *   a group. The macro is global: its members can live on different pages, which
 *   is the point, and the count is shown at the centre.
 *
 *   Only LV_EVENT_LONG_PRESSED is registered, never LONG_PRESSED_REPEAT. LVGL
 *   repeats that event every 100 ms while the finger stays down, so handling it
 *   would toggle membership ten times a second.
 *
 *   The centre of the dial is the one region a hand never lands on — the sector
 *   blocks stop 40 px short of it and the rim's own hit layer starts at 64 — so
 *   nothing is placed there and nothing answers there. A long press in the middle
 *   does nothing at all and a tap does nothing either: it is a dead zone rather
 *   than a hidden control, and the page name it carries can be read without being
 *   in anybody's way.
 *
 * PAGE NAVIGATION BY SWIPE
 *   Buttons cost the two widest, most usable points on the rim; a horizontal
 *   swipe costs nothing and leaves the whole equator to the arcs. LVGL walks up
 *   from the pressed object while LV_OBJ_FLAG_GESTURE_BUBBLE is set, so the
 *   tappable objects set it and the screen — which must NOT set it, or the walk
 *   continues past the screen and finds nothing — carries the handler.
 *
 *   A swipe still releases as a CLICKED on whatever it started on, so the tap
 *   and long-press handlers ignore the click that ends a gesture. Without that
 *   guard, turning a page would also re-select the sector the finger happened to
 *   land on. The window it uses is one frame, because that click arrives from the
 *   same call that sent the gesture; anything longer starts eating the next tap.
 *
 *   The carousel is the INSTRUMENT: every page a performance gesture can reach,
 *   and no settings page. SYS and SYS 2 keep their place in PAGES[] and their tiles
 *   on the curtain, and a swipe steps over them in both directions — including the
 *   swipe that leaves one of them, which returns you to the instrument rather than
 *   to the other one. Setup is a deliberate visit, never a flick.
 *
 *   One page takes the swipe for itself. On PRESET a horizontal swipe walks the list
 *   of stored sounds by eight rows, because 128 names are not crossed eight times a
 *   screen — and it is taken only while the list can still move that way, so the two
 *   ends of the store turn the page instead and the carousel keeps its whole set.
 *   Nothing is loaded by the walk: see the note on the preset page.
 *
 * THE CURTAIN
 *   A swipe down lays the sections out as a honeycomb of coloured chips. It is a
 *   MAP rather than a menu: every chip carries the same colour as the page it
 *   opens, so the colour code can be learned by looking at it. The transport hangs
 *   over the top of the honeycomb as an object of its own — twice the size of a chip
 *   and outside the layout's arithmetic — and the name of the section you are on is
 *   printed at the foot of the screen.
 *
 *   It carries a tile for every page: the curtain is a map of everywhere you can
 *   go, and every page in PAGES is somewhere the swipe can take you.
 *
 *   A chip carries a SHORT word rather than the page's own name: it is a disc 44 px
 *   across, which is four or five characters. The full name is in the middle of the
 *   dial, on the page itself, and at the bottom of the curtain — see ui_page_t.
 *
 * THE ROUND SCREEN
 *   The panel is 360 px across. The arcs live in the outer ring (stroke between
 *   162 and 176 px), each sector's name and value sit in a block at 96 px from
 *   the centre, and the page name and macro count are in the middle. Every block
 *   is sized so that even its corners stay inside the circle: at the diagonals a
 *   wider panel would poke out through the rim.
 *
 * THE STEREO FIELD AND THE RING
 *   The stereo drift is designed in tens of seconds. That is right for the sound
 *   and impossible to judge by ear in a short listen, so it is drawn where it can
 *   be read from across the room: the LED ring carries the three panned registers
 *   as three coloured dots. It also had three tracks on screen on a page of its
 *   own; the page went, because the ring says the same thing and a section that is
 *   nothing but an indicator is a section the swipe should not have to cross. Both
 *   read synth_layer_pan(), which the capture FX updates every block.
 */

#include "synth_ui.h"

#include <stdio.h>
#include <math.h>

/* The turning picture: the geometry lives in its own file, the object and the
 * two-second rule live here. See synth_ui_preview.h for why it is a bit mask. */
#include "synth_ui_preview.h"

#include "esp_app_desc.h"
#include "esp_attr.h"
#include "esp_log.h"
#include "esp_random.h"
#include "esp_timer.h"

#include "freertos/FreeRTOS.h"

#include "bsp/bsp.h"

#include "synth_app.h"
#include "synth_dsp.h"

#include "app_settings.h"
/* The note input's on/off switch. This page is the only caller of it while the instrument
 * runs — main() makes the same call once at boot — and it is here rather than in app_settings
 * because app_settings cannot reach components/midi without a cycle. See apply_setting(). */
#include "midi_in.h"

#include "ui_app.h"

/*
 * The preset page arbitrates its enlarged touch areas itself, and that needs the
 * lv_hit_test_info_t definition that the public headers only forward declare unless
 * LV_USE_PRIVATE_API is on, plus lv_area_is_point_on(), which is declared in the same
 * private layer. The component exports src/ as an include directory, so both are
 * reachable without turning the private API on for the whole firmware.
 */
#include "core/lv_obj_event_private.h"
#include "misc/lv_area_private.h"

#if CONFIG_OBOD_SCREENSHOTS
/*
 * The service mode that takes this file's pages as images for the documentation: see
 * screenshots.c, which is not in the build at all when the flag is off. What it needs from
 * here is the page table and the page turn, and the header says which four questions it asks.
 */
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "lvgl.h"

#include "synth_ui_screenshots.h"

#endif

/* Контуры озёр и плиток: запечены из obod/nav_lakes.h, полупиксели, начало —
 * левый верхний угол панели. Рисуются тем же nav_fill(), что и прежняя мозаика. */
#include "nav_lakes.h"

/*
 * THE FACES: the project's own, drawn for this screen and generated by tools/gen_lvgl_font.py —
 * 14 px for secondary text, 20 px for values and headings. Both are proportional, so an
 * advance is per glyph, and both come from the same hand as the layout below, which is why
 * the numbers there can be reasoned about instead of measured on a sample somebody else set.
 *
 * Their metrics, for the constants further down:
 *   14 px  line_height 10, base_line 1, caps box_h 9,  advances 6..9 px, 72 glyphs
 *   20 px  line_height 14, base_line 1, caps box_h 12, advances 6..12 px, 87 glyphs
 * The widest advance of the 20 px face is 12 px and that is a cap; lower case and digits are
 * narrower, so the widths in the layout notes below are stated per string where it matters.
 */
LV_FONT_DECLARE(lv_font_anbscreen_14);
LV_FONT_DECLARE(lv_font_anbscreen_20);


static const char *TAG = "synth_ui";

/* -------------------------------------------------------------------------- */
/* Layout                                                                     */
/* -------------------------------------------------------------------------- */

/*
 * The most sectors any page asks for. Six is asked by five pages: OPTIONS, the settings
 * page whose sixth entry is the wave morph time, appended like the two settings entries
 * before it (see KNOBS_SYS2), the three send pages — LEAD, PERC, MIC, LOW, MID and HIGH on
 * each — and the lead's figure page, LEAD EUCLID, which keeps its six: STEPS, PULSES,
 * ROTATE, ACCENT, SCATTER and the lead's own RESET. Five is asked by seven
 * others: LEVELS, SYSTEM, MASTER, DRONE MOD, DELAY, PERC and PERC SEQ. It is the whole
 * reason this is not four: the rim tables, the panels and every per-sector array below
 * are sized by it, and a page asking for one more than this would silently lose its last
 * knob. The levels moved off the voice pages and onto LEVELS, and the drum's ENV off
 * PERC SEQ and onto PERC, so no page carries the same handle twice any more.
 */
#define SECTOR_MAX 6

/*
 * How many entries a table actually holds, taken from the table itself.
 *
 * This exists because the count and the table can drift apart in a way no compiler
 * checks: a page's knob count was a NUMBER in PAGES[] and its knobs were a POINTER, so
 * the moment a table gained or lost an entry the page kept the number it was typed
 * with and every walk of the table (refresh_sectors(), sector_at_angle()) went one past
 * the end and read whatever followed as a `const char *`. That reached
 * lv_label_set_text() and crashed at boot on the start page.
 *
 * NK(KNOBS_DRONE) cannot disagree with KNOBS_DRONE: the count is derived, so a table
 * that gains or loses an entry moves the page with it, and there is nothing left that
 * can be out of step.
 *
 * What NK() does not bound is the count itself. A seven-knob page would be honest about
 * being seven and there is no RIM_7 — see rim_t: the rim carries its own length and
 * every walk of it is clamped to that, so such a page draws no sectors and logs the
 * mismatch instead of reading past a table. RIM_6 exists because five pages ask for six —
 * OPTIONS, the three send pages and LEAD EUCLID — and SECTOR_MAX is
 * where that stops: six is the widest rim the file describes, and the layout
 * arithmetic behind it is in the note over RIM_6. The count is checked from outside this
 * file instead: tools/check_ui_tables.ps1 fails on a page whose count disagrees with the table
 * it points at, and on a rim whose length disagrees with its name. That is why there is no
 * _Static_assert beside these tables — the check exists, it just lives in the tool that
 * also reads the rim layouts. The count's own upper bound stays a run-time answer.
 */
#define NK(t) ((int)(sizeof(t) / sizeof((t)[0])))

/*
 * The arc object is larger than the panel it draws on, because LVGL insets the
 * stroke by half its width: a 352 px object with a 14 px stroke puts the centre
 * line at 176 - 7 = 169 px and the outer edge at 176, four pixels clear of the
 * 180 px rim.
 */
#define ARC_OBJ_SIZE 352
#define ARC_W_IDLE   14

/* There used to be an ARC_W_SEL 18: a selected rim was also thicker. It cost a
 * full-screen repaint on every tap — any style change on an lv_arc invalidates its
 * whole 352x352 box — so selection is carried by the panel and the words instead. */

/* Parameter resolution. 1000 steps over a 90-degree sweep is finer than the
 * encoder can address by hand, so the knob never feels notchy. */
#define PARAM_STEPS 1000

/*
 * A swipe releases as a click on the object it started on, so the click that ends a gesture has
 * to be ignored — but only that one.
 *
 * LVGL sends the gesture and the CLICKED of the same release from one indev_proc_release()
 * call, a few lines apart. What sits between them is the catch: the gesture handler does the
 * whole page turn first, and a turn is two page snapshots of 30 to 55 ms each. Marked at the top
 * of the handler, the window of one frame had expired long before the click arrived, and the
 * turn also tapped the sector under the finger — measured on the instrument as an unguarded tap
 * 97 to 142 ms after every gesture. Marked at the end of the handler, sixteen clicks out of
 * seventeen were caught and one came 53 ms late, because the click of a release is not always
 * dispatched by the call that sent the gesture. A window, then, is the wrong instrument: any
 * window can be stepped over by a long enough frame.
 *
 * So the test is not a moment at all. The BSP counts every finger that lands, the swipe
 * remembers the number of its own, and the click is refused while that number is still the last
 * one on the glass. A count cannot be overtaken by a slow frame, and it cannot leak into the next
 * tap, because the next tap is a different finger. A plain flag was tried for this once and
 * stuck: it has to be cleared by a press, and presses do not all pass through one object — the
 * tiles, the rows and the transport keep their own.
 */
#define SWIPE_CONTACT_NONE 0u   /* no swipe taken since the screen was built */

/*
 * Where a sector's name and value sit, and the highlight behind them.
 *
 * 96 px is a compromise the round screen forces. Further out and the panel's
 * corners leave the circle at the diagonal positions (the three-sector layout
 * puts two blocks at 30 and 150 degrees), further in and the blocks crowd the
 * page name. 112 x 48 keeps every corner inside 157 px of the centre, which
 * leaves clear air between the text and the arc stroke at 162.
 *
 * Measured, layout by layout, as the worst corner of any panel and the air left
 * inside the 162 px stroke: two 132.4 (29.6), three 156.7 (5.3), four 153.9 (8.1),
 * five 156.8 (5.2), six 156.5 (5.5). Five is therefore as tight as three already is, and
 * six is a third of a pixel easier than five — the corner that binds is the one nearest
 * twelve o'clock, and sixty degrees a side puts the six anchors exactly on the axes and
 * the diagonals of the integer trig rather than beside them. What is used up at six is the
 * gap BETWEEN panels, and five had already used it up: the nearest pair of the five is
 * 0.0 px apart, edge to edge, and the six are the same. Neither overlaps. tools/ring_clearance.py
 * prints that gap beside the corner for every layout, so the day a sixth sector is asked
 * for on a page that fills panels, the number is there rather than a surprise.
 *
 * The width cannot be traded away for that: the widest value any page prints is
 * MIXOLYDIAN, ten characters, 111 px in the large face, so 112 is already the
 * floor and a five-knob page had to be fitted without narrowing anything.
 */
#define ANCHOR_R 96
#define PANEL_W  112
#define PANEL_H  48
#define NAME_DY  (-11)
#define VALUE_DY 12

/*
 * The polar tap layer's annulus, in pixels from the centre of the rim.
 *
 * INNER is the dividers' inner end, so the tappable ring and the drawn sector begin
 * together: every drawn pixel of a sector can be tapped and no pixel outside one can.
 * That is also what keeps the very middle inert, which is what this radius is really
 * for — the page name and the macro count live there (their worst ink corner is
 * 39.5 px; see CENTRE_BG_R), and neither is a sector, so a tap between two text blocks
 * should do nothing rather than pick whichever wedge the angle happens to fall in.
 *
 * OUTER is beyond the rim's stroke — the arc is 352 across with a 14 px stroke, so the band
 * ends at 176 and 182 leaves a few pixels of margin — which also puts the screen's corners
 * outside every sector,
 * where they belong.
 *
 * The number is typed here rather than referenced, because the dividers are defined
 * below this point, and the link is asserted beside them instead: RIM_HIT_INNER ==
 * DIV_R_IN. An assertion says what the two things mean to each other; moving the
 * definitions around would only say where they happen to sit in the file.
 */
#define RIM_HIT_INNER 52
#define RIM_HIT_OUTER 182

/*
 * The divider spokes, drawn in the gap between neighbouring sectors. They start
 * clear of the middle so the page name stays legible, and their band is where a
 * sector's own surface begins — which is why the selected sector's fill is derived from
 * its inner end rather than typed in again.
 *
 * The outer end is 151, and it is LONGER than the fill, which stops at 140 (see
 * SEL_BODY_OUT). The two were the same number until the meters and the modulation dots
 * moved out to 150..152: a fill that reached 151 would have sat on the circle they ride,
 * and the meter had to be painted around instead of across — which left a black ring
 * through the wedge of every selected sector, on pages with meters and on pages without.
 * A fill that stops short of the circle leaves the meter on the background by
 * construction. The spokes keep their full stretch because they are the sector's
 * boundary and have to stay visible beside the meters; the fill is the sector's surface
 * and has to stay clear of them. The rim is farther out than either and unrelated to
 * them — its band is 162..176.
 */
#define DIV_R_IN   52
#define DIV_R_OUT  151
#define DIV_MAX    SECTOR_MAX

/*
 * The tap layer and the drawn sector have to begin at the same radius, or the result is
 * either a wedge that is drawn and cannot be hit or a ring that can be hit and is not drawn.
 * RIM_HIT_INNER is typed above because it is needed there; this is where the two meet.
 */
_Static_assert(RIM_HIT_INNER == DIV_R_IN,
               "the tap layer and the dividers no longer meet at the same radius");

/*
 * The fill of the SELECTED sector, and the value mark that rides on it.
 *
 * A sector is a wedge, so its fill has to be one. The block behind the words was a
 * fixed 112 x 48 rectangle at ANCHOR_R, and that is the thing that "touches the edges"
 * at five parameters: its two inner corners sit at 37.9 degrees from the sector's
 * centre line where the sector itself is only 36 degrees wide, so each of them reaches
 * 3.0 px past the spoke into the neighbour's half. At four parameters the half-angle is
 * 45 degrees and the same corner is comfortably inside — which is exactly why this was
 * only ever reported on a five-knob page.
 *
 * So the fill is an arc, and only an arc's edges are the sector's own: the same start
 * and end angle as the rim, and a stroke whose two RADII are the dividers' own — a fill
 * that ends where the spokes end is the only reading of "the sector's own surface" that
 * survives being looked at on the panel.
 *
 * The numbers come from the renderer, and the renderer is not symmetric. lv_arc.c reads
 * the radius of a square object as (size - pads) / 2 (lv_arc.c:984-985) and hands it to
 * the draw descriptor; lv_draw_arc() then builds the area from that radius alone
 * (lv_draw_arc.c:64-68). The stroke is made by three masks in lv_draw_sw_arc.c: an
 * angular one, an outer circle over that area, and an INVERTED inner circle over the same
 * area shrunk by the stroke's width on every side (lv_draw_sw_arc.c:80-85 and :106-124).
 * So the band is [radius - width, radius] — it grows INWARD — and the library says so in
 * one line of its own: `int32_t rin = radius - w;` (lv_draw_arc.c:121).
 *
 * Two things follow, and this file had both wrong. The radius is the stroke's OUTER edge
 * and not its centre line, so the rim's radius is 176 — the 352 px object with no padding
 * at all — and the rim is drawn over 162..176. ARC_R_MID is therefore the band's MIDDLE
 * and not its edge, 169. And a stroke as wide
 * as its own radius is not a very wide ring: area_in collapses and the inner mask is
 * dropped (lv_draw_sw_arc.c:116), or the width is clamped first
 * (lv_draw_sw_arc.c:59-60), and either way the wedge comes out as a solid pie out to the
 * radius. That is what the panel showed: a fill that reached 105 — the radius —
 * and stopped 46 px short of the spokes, with the middle looking right because the hub
 * disc happens to hide everything inside 52 anyway.
 *
 * So the padding sets the OUTER radius and the width is the band. One correction to the
 * brief this came from: the drawn band cannot be 52..158 as well, because 158 is three
 * pixels PAST the rim's inner edge.
 *
 * The outer radius used to be 151, the dividers' own outer end, and is now 140: see
 * SEL_BODY_OUT below for why the fill gave up those eleven pixels.
 *
 * The band is ASSERTED below against the renderer's own expression rather than against
 * the same expression rearranged, and the two separate ways a ring can silently become a
 * pie are asserted separately too. The previous version asserted its own inputs, which is
 * why a 46 px error could sit in this file and be found by eye on the panel instead of by
 * the compiler.
 */

/*
 * The visualisation track and the dot that rides it — and, on the same circle, the meter
 * that shows a modulation's own level.
 *
 * Both sit at 151 px, which is a compromise measured against three things at once:
 *
 *   in from the rim   the rim's band is 162..176, so the circle keeps 10 px of background
 *                     between itself and the first notch, and a meter cannot be read as
 *                     part of the value arc;
 *   out from the fill the selected sector's fill stops at 140 (SEL_BODY_OUT), so the circle
 *                     rides the same 10 px outside it, on the page's own background, and a meter is
 *                     never painted over by a wedge that was painted later;
 *   inside the blocks the sector blocks' outer corners reach 156.5 px at their worst
 *                     (tools/ring_clearance.py, the note over ANCHOR_R), so the circle
 *                     passes under a block only in a corner, where the block is
 *                     transparent anyway.
 *
 * The circle was at 143 until the notch ladder arrived: with the fill reaching 151, a
 * meter at 142..144 lay INSIDE the fill and was painted around instead of across, and the
 * hole that left was a black ring through the wedge of every selected sector. Moving the
 * circle out and pulling the fill in is what removed the hole, rather than patching it.
 */
#define VIZ_R           151
#define VIZ_W           2
/*
 * The radius an lv_arc or lv_obj has to be to draw a band on VIZ_R.
 *
 * The library reads a radius as the stroke's OUTER edge and lays the band inward from it
 * (lv_draw_arc.c:121), so an object of VIZ_R * 2 draws at VIZ_R - 1 .. VIZ_R and not centred
 * on VIZ_R at all. That one pixel never mattered while the track was the only thing out
 * there; now that the meter's pixels are laid at RIM_TRACK_IN..RIM_TRACK_OUT, a track beside
 * a meter on the same page would sit a pixel in from it, and the two circles would meet at a
 * step. The objects are built half a width larger, and the three places that recover the
 * centre from a box use this instead of VIZ_R.
 */
#define VIZ_OBJ_R      (VIZ_R + VIZ_W / 2)               /* 152 */
#define VIZ_DOT         8
/* The dot is 8 px across, so the track gives up 8 px at each end: at 151 px that is 3.0
 * degrees, rounded up, and the dot's edge never crosses the sector's boundary. */
#define VIZ_INSET_DEG   4


/*
 * The ring's radii: three circles with EQUAL gaps between them.
 *
 *   the notch ladder   RIM_INNER..RIM_OUTER     162..176
 *   the meter circle   RIM_TRACK_IN..RIM_TRACK_OUT  150..152
 *   the fill           SEL_BODY_IN..SEL_BODY_OUT  52..140
 *
 * The two gaps are the same ten pixels, and the fill's outer radius is DERIVED from the
 * other two rather than typed in: move the meter band and the fill moves with it, and the
 * ring stays three concentric bands instead of two bands and a leftover.
 */
#define RIM_ORIGIN     DIV_ORIGIN                        /* 180 */
#define RIM_INNER      (ARC_OBJ_SIZE / 2 - ARC_W_IDLE)   /* 162 */
#define RIM_OUTER      (ARC_OBJ_SIZE / 2)                /* 176 */
#define RIM_TRACK_IN   (VIZ_R - VIZ_W / 2)               /* 150 */
#define RIM_TRACK_OUT  (VIZ_R + VIZ_W / 2)               /* 152 */
#define RIM_GAP        (RIM_INNER - RIM_TRACK_OUT)       /* 10 */

#define ARC_R_MID     (ARC_OBJ_SIZE / 2 - ARC_W_IDLE / 2)  /* 169, the rim band's MIDDLE */
#define SEL_BODY_IN   DIV_R_IN                                    /* 52 */
/*
 * The selected sector's fill ends one gap inside the meter circle, NOT at the spokes' outer
 * end, which is 151.
 *
 * The fill and the circle were one number apart while the meters rode at 142: the fill
 * covered the circle they sit on, so the body had to be painted AROUND the meter — two
 * spans, 52..141 and 145..151 — and the pixels the spans left behind were a two-pixel
 * background ring drawn through the wedge of every selected sector. On a page whose sector
 * has no meter, that ring was an artefact with nothing to explain it.
 *
 * A fill that simply stops short of the circle has no ring and no ordering rule: the meter
 * is on the background because the fill never reaches it, whichever is painted first. The
 * ten pixels given up are the same ten the ladder above keeps, and the block behind the
 * words does not notice them — its farthest corner is at 156.5 but it is transparent except
 * under a macro, where the selected sector's block is transparent as well.
 */
#define SEL_BODY_OUT   (RIM_TRACK_IN - RIM_GAP)                   /* 140 */
#define SEL_BODY_W    (SEL_BODY_OUT - SEL_BODY_IN)                /* 88 */
#define SEL_BODY_PAD  (ARC_OBJ_SIZE / 2 - SEL_BODY_OUT)           /* 36 */

/* The rule itself, asserted: two gaps, equal, and the fill derived from them. */
_Static_assert(RIM_GAP == 10, "the three circles: re-measure the gaps on the panel");
_Static_assert(SEL_BODY_OUT + RIM_GAP == RIM_TRACK_IN,
               "the fill is not one gap inside the meter circle");
_Static_assert(RIM_TRACK_OUT + RIM_GAP == RIM_INNER,
               "the meter circle is not one gap inside the notch ladder");

/*
 * The band lv_draw_sw_arc lays down, written the way it computes it: the radius the
 * padding leaves is the OUTER edge, and the stroke extends inward by its width. Both
 * edges have their own macro so the assertions below read like the renderer.
 */
#define ARC_DRAWN_OUT(R)    (R)
#define ARC_DRAWN_IN(R, W)  ((R) - (W))
#define SEL_BODY_R          ((ARC_OBJ_SIZE - 2 * SEL_BODY_PAD) / 2)  /* 140 */

_Static_assert(ARC_R_MID == 169,
               "the rim moved: re-measure the sector fill against its drawn band");
_Static_assert(ARC_DRAWN_IN(SEL_BODY_R, SEL_BODY_W) == SEL_BODY_IN &&
               ARC_DRAWN_OUT(SEL_BODY_R) == SEL_BODY_OUT,
               "the fill does not draw the band the dividers bound");
_Static_assert(SEL_BODY_W <= SEL_BODY_R,
               "width > radius: lv_draw_sw_arc.c:59-60 clamps the stroke");
_Static_assert(SEL_BODY_W < SEL_BODY_R,
               "width == radius: lv_draw_sw_arc.c:116 drops the inner mask and the "
               "sector is filled as a solid pie instead of a ring");

/*
 * The hub disc: the page's own background, drawn OVER the two selection arcs and UNDER
 * the spokes and every label, so the middle of the screen is a guaranteed clean circle
 * to write the page's name in.
 *
 * Its radius is the dividers' inner end, and that is what makes the guarantee hold by
 * construction: the fill starts at exactly that radius, so nothing the wedge draws can
 * appear inside this circle at all. The circle in the middle is the design, and the same
 * geometry already puts the fill's inner edge here.
 *
 * 52 px against the widest name. A two-line title is 2 x 14 = 28 px of box (the 20 px
 * face's line_height), set in caps whose ink sits at -14..+12 once the box is centred on
 * the middle (lv_draw_label.c:671 places a glyph at line top + line_height - base_line -
 * box_h - ofs_y, and this face has base_line 1 and caps of box_h 12 with ofs_y 1). The
 * widest line a title ever puts there is SYSTEM, CHORUS, REVERB, MASTER or PRESET at
 * 72 px, so the worst ink corner is sqrt(36^2 + 12^2) = 37.9 px from the centre, leaving
 * 14 px of air.
 *
 * This radius is also the tap layer's inner radius, by an assertion beside the dividers
 * (RIM_HIT_INNER == DIV_R_IN), so the circle the fill stops at is exactly the circle
 * inside which nothing is tappable: there is no drawn pixel of a sector that cannot be
 * tapped, and no tappable pixel that is not drawn as part of one.
 */
#define CENTRE_BG_R DIV_R_IN  /* 52 */

/* The middle column: page name and macro count, between the sector blocks. */
/*
 * The centre column.
 *
 * The page's name sits exactly on the middle of the display, so the one piece of text
 * that says where you are never moves — and that is now true of BOTH of its forms. A
 * two-line name used to be lifted to -21 to keep the macro count clear, and that lift
 * is what reads as "a little above the middle": it moved the block's box, and
 * the ink is what the eye centres. Centred on the middle, the two forms agree exactly,
 * because the caps of both put their ink centre at +0.5 px: with anbscreen_20 a one-line
 * block is 14 px of box with its ink at -7..+5, a two-line one is 28 px with ink at
 * -14..+12.
 *
 * So the two-line form keeps the exact middle as well, and the MACRO COUNT is what
 * steps aside for it. At MACRO_Y the count's ink (the 14 px face: base_line 1, caps of
 * box_h 9, ofs_y 0) runs MACRO_Y - 5 .. MACRO_Y + 4, so at 26 it runs 21..30 — clear of a
 * two-line name's ink bottom of +12 by 9 px. At MACRO_Y_TWO it runs 23..32 and keeps
 * 11 px, while the count's own ink corners stay inside the hub disc: "MACRO 10" is the
 * widest the count can be, 64 px, so its corner is sqrt(32^2 + 32^2) = 45.3 px against
 * the disc's 52.
 *
 * The two-line form cannot be checked by eye on the panel, so both forms are asserted
 * below against the font's own metrics. See CENTRE_BG_R and apply_page().
 *
 * TITLE_BIG_CHARS is the character budget of the larger face: seven. It is a count and not
 * a width because the page names are words, and a word of capitals is what the middle column
 * holds; the widths that count has to stay inside are measured — the widest LINE any title
 * is drawn with is 72 px (CHORUS, PRESET) of the 80 px the sector blocks leave between them,
 * and OPTIONS, the only word of seven, measures exactly 80 px and therefore comes right up
 * against both blocks. It used to be the reason the budget stopped at six: it went to the
 * smaller face, where it measures 71 px. The owner's verdict was the other way — OPTIONS is
 * set in the larger face like every other title, and if a letter rides onto a block, it
 * rides. One word of seven and no other changes: the widest remaining title is six.
 *
 * The budget was seven once before, while the large face was set at letter_space -1:
 * OPTIONS measured 74 px then and had 6 px to spare, and the count came down by the one word
 * that did not fit. At 0 it fits by touching, which is what the panel shows now.
 */
#define PAGE_NAME_Y     0
#define MACRO_Y        26
/*
 * The caption's line on a two-line name. The title's ink ends at +12, so the count at 28
 * begins at 23 and leaves 11 px of air between them; at 26 the same count would leave 9.
 * It cannot be 28.5 because a position is whole pixels.
 */
#define MACRO_Y_TWO    28
/*
 * The leading of a two-line title, in pixels. The 20 px face's line box is 14 px against
 * 12 px of cap ink with ofs_y 1, so 0 already leaves 2 px between the two lines of ink;
 * a negative leading would pitch them onto each other, which is what the face showed
 * first when this constant was still the old face's -11.
 * The centre does not move, and the reason is spelled out in apply_page().
 */
#define TITLE_LINE_SPACE 0
#define TITLE_BIG_CHARS       7

/*
 * The focus proxy. Small enough that a tap landing on it can only be deliberate
 * aim at the centre of the screen, where nothing is tappable anyway. */
#define PROXY_SIZE 8

/* How many panned registers there are. The stereo display on the ring and the ring
 * colours below are the only things left that are sized by it. */
#define ORBIT_ROWS    3

#define ANIM_PERIOD_MS     40    /* 25 fps; the drift is slow, this is for touch latency */

/*
 * The sequencer display: a ring of dots around the middle of the screen, drawn on
 * the pages that carry a figure — the lead's on EUCLID, the percussion's on
 * PERC SEQ.
 *
 * THE ARITHMETIC, written once here and read whenever a string has to fit beside this
 * ring: a dot's centre is exactly SEQ_RING_R from the middle and the largest dot is
 * SEQ_DOT_ON across, so its inner edge is 142 - 8 = 134 px out. A sector's name and
 * value are auto-sized lv_labels CENTRED on ANCHOR_R, so each is as wide as its own
 * text — the faces are proportional, so that width is the sum of the advances of the
 * glyphs in the string, not a count of characters times one advance — and as tall as the
 * font's own line_height, 14 and 10, not the 12 px of cap ink inside. LVGL rounds an
 * auto-sized box to whole pixels.
 *
 * 142 is as far in as the ring can sit without touching a word. The two pages that draw it
 * no longer ask for the same count: LEAD EUCLID keeps SIX controls on RIM_6, PERC SEQ keeps
 * FIVE on RIM_5. What the drum's figure page lost is ENV, the second copy of the value that
 * lives on PERC where the sound of the hit is made; a page of figures is a page of figures,
 * and the voice's articulation belongs on the voice's page. The two pages therefore hold
 * the same five controls — STEPS, PULSES, ROTATE, ACCENT and their own RESET — and the lead
 * adds SCATTER. RESET is last on both tables, as it is the last decision each figure
 * needed; see SYNTH_PARAM_SEQ_RESET and SYNTH_PARAM_PERC_RESET.
 *
 * NEITHER PAGE IS TURNED, AND THERE IS ONLY ONE TABLE PER COUNT. The six of LEAD EUCLID is
 * the straight RIM_6 star the settings pages use — anchors at 270, 330, 30, 90, 150 and 210
 * degrees — and the five of PERC SEQ is the ordinary RIM_5 — 270, 342, 54, 126 and 198.
 * STEPS, the main control, is at twelve o'clock on both. The seven-degree figure rim is
 * gone: PERC SEQ is no longer a six, and the lead's six did not need turning once the accent
 * values were printed short. Nothing on either page was moved to rescue a word.
 *
 * WHAT DID NOT FIT ON RIM_5 WAS A WORD, NOT A SEAT. On the drum's page ACCENT is the fourth
 * seat, at 126 degrees, where the old "QUARTER" — 84 px in the 20 px face — leaves -3.5 px:
 * a 16 px dot crosses the value box. The answer is the panel forms in ACCENT_NAME: "1/4",
 * "OFFB", "FUNK", "RMB", "BOS", at most 46 px for the widest. That seat now clears by
 * 9.8 px, and the dot never leaves the text. On the lead's page the same seat is at 90
 * degrees, where even the long word would clear (11.0), but one table of names prints on
 * both pages and it is five forms rather than eight long ones. The lead's SCATTER keeps its
 * own "50 %". Nothing on either page is moved to rescue a word, and the order is not chosen
 * by the widths: it is the order the pages took when RESET arrived, with ACCENT moved up
 * to the fourth seat to make room for it.
 *
 * SWEEPING ALL 130 DOT POSITIONS THE RING CAN EVER TAKE — every position of every step
 * count from 4 to 16 — against every name and value box of every seat gives, in pixels of
 * air before a 16 px dot touches the text, positive for air and negative for overlap.
 * LEAD EUCLID's six seats, at 270, 330, 30, 90, 150 and 210 degrees:
 *
 *   sector  labels                    slot0  slot1  slot2  slot3  slot4  slot5
 *   STEPS   "STEPS"/"16"               22.0   11.3   20.3   19.0   20.4   11.3
 *   PULSES  "PULSES"/"16/16"           22.0    7.7   10.4   16.0    9.5    7.7
 *   ROTATE  "ROTATE"/"15"              22.0    6.8   16.6   19.0   15.4    5.9
 *   ACCENT  "ACCENT"/"3-3-2"           22.0    7.7    8.5   15.8    8.5    7.7
 *   SCATTER "SCATTER"/"50 %"           21.8    3.4   12.4   17.1   12.4    3.4
 *   RESET   "RESET"/"256"              22.0   11.3   15.9   18.9   16.3   11.3
 *
 * PERC SEQ's five, at 270, 342, 54, 126 and 198:
 *
 *   sector  labels                    slot0  slot1  slot2  slot3  slot4
 *   STEPS   "STEPS"/"16"               22.0   12.6   18.2   17.5   12.6
 *   PULSES  "PULSES"/"16/16"           22.0    9.2   11.0   10.6    9.0
 *   ROTATE  "ROTATE"/"15"              22.0    8.4   18.2   17.5    7.3
 *   ACCENT  "ACCENT"/"3-3-2"           22.0    9.2   10.4    9.8    9.0
 *   RESET   "RESET"/"256"              22.0   12.6   13.6   13.6   12.6
 *
 * The ACCENT row is measured on the widest string in ACCENT_NAME — "3-3-2" and "FUNK" tie
 * at 46 px — and tools/ring_clearance.py takes that string from the table rather than
 * copying it, so a longer panel form added later moves the row and fails the check instead
 * of quietly reaching the ring.
 *
 * The cells the pages actually use are STEPS' 22.0 on both, then the lead's PULSES 7.7,
 * ROTATE 16.6, ACCENT 15.8, SCATTER 12.4 and RESET 11.3; and the drum's PULSES 9.2,
 * ROTATE 18.2, ACCENT 9.8 and RESET 12.6. Every one of them is air. The tightest cell on
 * either page is the lead's PULSES: 7.7 px between its name box and the ring, and it is a
 * known number rather than the reason the order is what it is. There is no negative cell
 * left in either table — the two that used to exist were ENV's, and ENV is no longer on a
 * page that draws dots; the short accent forms took the other long value off the rim.
 *
 * THE ORDER IS THE PAGE'S HABIT. STEPS is the main control and keeps twelve o'clock on both
 * pages, PULSES is beside it because a Euclidean figure is two numbers before it is
 * anything else, ROTATE is third and ACCENT fourth — the same seat on both pages. Then the
 * lead keeps SCATTER fifth and both put RESET last: the least frequent thing a page does
 * sits where a hand arrives last. This is the order the pages took when RESET arrived:
 * ACCENT had been last and moved to the fourth seat, which is where a long accent word
 * still clears the ring, and RESET took the end. The drum's fifth was ENV; it has gone back
 * to PERC, so the drum's five close on RESET. The two pages share five controls and differ
 * in one, which is what "one figure read twice" means.
 *
 * THE TANGENT THAT WAS HERE IS GONE, measured rather than assumed. On the old five-sector
 * star ACCENT's "QUARTER" met the 16 px dot of step 11 of 14 at 198 degrees — -2.0 px in the
 * sweep, 0.0 with the kerning the word carries — and ENV paid 3.7 px at 126. The accent
 * sector now prints the short forms and the drum's ACCENT seat at 126 degrees clears by
 * 9.8 px; the lead's at 90 by 15.8. The ring's radius did not move: 142 is still as far in
 * as the ring can sit without touching a word.
 *
 * The words keep more air than they did on the turned star: the tightest label-against-label
 * pair is 41.1 px on the lead's page (SCATTER's name against a neighbouring value, at the
 * 90/150 boundary) and 60.0 px on the drum's, against 35.4 and 26.8 before. The farthest a
 * label box reaches from the middle is 125.5 px on the lead's page and 124.4 on the drum's,
 * against the rim's ink at 155. The panels keep their own geometry: the table over ANCHOR_R
 * quotes 156.5 px on RIM_6 and 156.8 on RIM_5, and ring_clearance.py's own model lands
 * within half a pixel of both, with neighbours tangent at 0.0 px.
 *
 * Both tables are tools/ring_clearance.py's own output, to the tenth of a pixel, and it
 * sweeps exactly this and knows nothing the file does not: RIM_5's and RIM_6's spans,
 * rim_anchor()'s own rounding, lv_trigo_sin()'s table, lv_font_anbscreen_14 and
 * lv_font_anbscreen_20, text_condensed(0), ACCENT_NAME's strings, and every dot position of
 * every step count. The one thing it models rather than copies is LVGL's integer centring
 * of an auto-sized box, which can move an edge by half a pixel, so a cell that moves by a
 * whole pixel there is a change in the layout and not in the measurement. The check is a
 * GUARD, not a design tool: it does not choose an order and it is not a reason to turn a
 * star or move a control. Re-run it after any edit to the geometry, the fonts or a readout's
 * format; it fails rather than agreeing quietly when a cell a page binds on stops being
 * true, so a long value added later is caught here instead of on the panel.
 *
 * THE VALUE FACES ARE SWEPT AS THEY ARE DRAWN (letter space 0), and the pair kerning is not
 * in the model, which is why a value cell here is at most 2 px more air than the drawn box.
 * The name boxes are the one place the sweep is still generous: they are set at +2 in the
 * 14 px face, a letter space the sweep does not model, so STEPS' 22.0 and PULSES' 7.7 are
 * 2-4 px more air than the drawn boxes have. build\kern_plus1.py is the model that includes
 * both faces' letter spaces and the pairs.
 *
 * THE SETTINGS PAGE IS NOT IN THIS SWEEP AND DOES NOT NEED TO BE: it draws no ring —
 * page_has_figure() answers for EUCLID and PERC SEQ and for nothing else — so the clearance
 * to measure there is between its own words, and tools/ring_clearance.py's second section
 * measures exactly that. The eight-character NAME on the instrument lives there, on WEAK
 * VEL, which is the length that once made a value touch a dot; see the note over KNOBS_SYS2
 * for why it costs nothing on a page with no dots.
 *
 * ENV's "5.0 OCT" IS NO LONGER A FIGURE PAGE'S PROBLEM. It sits on PERC, which draws no
 * ring, and the widest value either figure page prints is now "16/16" at 43 px, with the
 * widest ACCENT form at 46. The eight-character values the pages once carried are gone —
 * DOWNBEAT and BACKBEAT were 96 px each, and ENV's "+1.0 OCT" lost its sign when the range
 * became 0..5 octaves upwards (see synth_app_param_text()) — and the panel forms in
 * ACCENT_NAME took the longest accent names down to five characters.
 *
 * Do not fix a tight seat by moving STEPS or by turning the star: the order is the owner's
 * and the page's main handle is at twelve for a reason. If a readout is too wide, shorten
 * the readout where it is formatted, then publish the new cells in tools/ring_clearance.py
 * in the same commit.
 */
/*
 * Every one of these is even, and that is load-bearing rather than tidy.
 *
 * LVGL centres an object with an integer division of its width, so an odd width
 * puts the object's centre half a pixel off the point it was aligned to. A 13 px
 * dot and a 20 px cursor would then sit a half pixel apart, which is exactly the
 * misalignment that shows up as the cursor not being centred on the step it is
 * pointing at. Even widths divide exactly, so the dot and the cursor share a
 * centre to the pixel. Radii come out even as well: 8, 6, 4 and 12.
 */
#define SEQ_RING_R       142
#define SEQ_DOT_MAX       16
#define SEQ_DOT_ON        16
/*
 * The dot of an onset that is NOT accented, on a figure that has an accent: between
 * the accented dot and a silent step, so the ring shows the accent as a difference in
 * the pattern rather than as a mark on top of it. A step the chosen figure marks keeps
 * SEQ_DOT_ON — the size every onset has always had — so choosing a figure never makes
 * a dot smaller; what it does is take the other onsets down, exactly as the velocity
 * does, and exactly the same way on both pages that draw a figure. The lead's ring is
 * not a special case: its dots are sized by the accent the line is played at, which is
 * its own parameter and the same rule, asked of the lead's own STEPS.
 */
#define SEQ_DOT_MID       12
#define SEQ_DOT_OFF        8
/*
 * THE DRUM'S RING IS THE PART, so its dots answer a different question from the lead's: not
 * "is this step sounding" but "what is sounding on it". One size per lane, in the order the
 * ear ranks them — the kick is the bar, the snare is the answer to it, the tom is the answer
 * to both, and the hats are the surface. A ghost note, which is a quiet hat between the
 * written ones, is the smallest mark the ring can make above silence; a step with nothing on
 * it keeps SEQ_DOT_OFF.
 *
 * Four sizes rather than four colours, because the ring has one hue: the part's amber, taken
 * down. Size is what the eye reads at a glance around a circle, and brightness is what
 * carries the second channel — a hat is dimmer than a kick at the same size.
 */
#define SEQ_DOT_KICK      18
#define SEQ_DOT_SNARE     14
#define SEQ_DOT_TOM       12
#define SEQ_DOT_HAT       10
#define SEQ_DOT_GHOST      6
#define SEQ_DOT_SILENT     6
/* How far a lane's mark comes down when the accent does not mark the step: four pixels, so
 * the difference is visible at arm's length and not a guess. Two when the mark is already a
 * hat, and the parity is kept either way — a circle of an odd diameter is drawn a pixel off
 * centre, and a ring of them is drawn wobbling. */
#define SEQ_DOT_ACCENT_CUT 4
#define SEQ_CURSOR_D      24
/* 40 Hz. The playhead moves up to about thirty times a second at the top of the
 * tempo range, and a slower poll would show it skipping positions. */
#define SEQ_PERIOD_MS     25

/*
 * The page turn: 200 ms, and the number is a constraint rather than a tuning knob. A turn
 * that takes longer than a flick feels like a wait, and lengthening it was tried and
 * rejected for that reason.
 *
 * What the duration cannot do is decide how many positions the turn is drawn in. That is
 * the frame cost, and the frame cost was measured: the whole page — rim, sectors, panels,
 * text — lives inside the sliding container (`screen` is reassigned to s_content before any
 * of it is built), so a frame that moves that container re-renders the entire screen, and
 * that render takes 40 to 50 ms. At 200 ms that is four or five drawn positions, which the
 * eye reads as a jump rather than as movement: `slide: 4 steps in 206 ms, worst gap 103 ms`.
 *
 * So the positions are bought by making a position cheap instead. See the buffer in
 * slide_to(): the page is taken into PSRAM at the start of the turn and the turn moves the
 * PICTURE, which is the only way a 200 ms turn can be drawn twenty times.
 */
#define PAGE_SLIDE_MS    200
#define SLIDE_HALF       420    /* of 1000: the page swaps at this point */

/*
 * The navigator: the map of sections, laid out as a Voronoi mosaic.
 *
 * Every section owns one CELL, and a point of the glass belongs to the section whose point is
 * nearest to it — that is the whole rule, and it is the rule the finger obeys as well. The cells
 * therefore tile the disc by construction: there is no sliver between two of them for a tap to
 * fall through and no overlap for two to claim, and no packing arithmetic to keep in step, because
 * nothing is packed. A seam follows one neighbour rather than a ring.
 *
 * NAV_CELL_R is the mosaic's own edge and it is the screen's: the drawer covers the whole panel, so
 * the map covers it too, and a mosaic that stopped short of the bezel read as a smaller map with a
 * ring of empty surface around it.
 *
 * NAV_GON is the shape a cell is cut from, as a polygon. At 64 sides a chord sits 0.22 px inside the
 * true circle — a fifth of a pixel at the very edge of the glass — and the arc is where most of an
 * outer cell's vertices come from, so the number is not free.
 */
#define NAV_SCREEN        360
#define NAV_CELL_R        180
#define NAV_GON            64
/*
 * The most vertices a cell has come out with (measured over the table in nav_measure(): ten), and
 * the room the cut works in. The work buffer cannot overflow: clipping a convex polygon by one
 * half-plane adds at most one vertex, so NAV_GON plus the number of sites is the ceiling and
 * NAV_WORK_V_MAX is above it with room to spare.
 */
#define NAV_CELL_V_MAX     16
#define NAV_WORK_V_MAX     96
/*
 * How far a cell's box reaches past its own edge, for a repaint: a flash invalidates that box, and a
 * box tight to the polygon would leave the antialiased edge of the cell next to it half painted.
 *
 * There is no gap between the cells any more. There used to be — every cell was painted a pixel
 * short of its own edge and the surface showed through the two-pixel cut, which is a line drawn by
 * omission and the cheapest way to separate two dark fills. What it also did was put the darkest
 * thing on the screen between every pair of neighbours, so at this depth of fill the map read as
 * plates in a net of black rather than as a mosaic. The cells now reach their own edges and overlap
 * each other by half a pixel, which is all the antialiasing needs.
 */
#define NAV_BOX_MARGIN      2
/*
 * How far a cell's fill is sunk below its palette step: 80 of 256, just over three tenths.
 * The white of the ladder is the seam, and the cell has to sit near it or the net of cuts is the
 * brightest thing on the glass. At this depth the seam is gone as a boundary (1.00 to 1.10 to one)
 * and the name carries the tile, which is what was asked for: the map reads as dark plates with lit
 * words, and the one cell you are standing on is the only filled shape on it. Going below this is
 * where the six hues stop being nameable — the plate is grey-black and the family colour lives only
 * in the word. See MAP_TONE for what the whole ladder is and why.
 */
#define NAV_CELL_DARK     80
/*
 * How far a finger may land outside the mosaic and still mean its edge. The reach is wider than the
 * drawing by this much, so a tap aimed at the outermost cell is not turned into a tap on nothing by
 * a couple of pixels.
 */
#define NAV_TAP_SLACK       8
/*
 * The macro's ring: a border in COL_MACRO_RIM red, three pixels inside the cell's own edge.
 *
 * It is the only frame left on the map. The section you are standing on is marked by filling its
 * whole cell one palette step lighter (see MAP_TONE), which says "here" with the tile itself
 * instead of with one more line drawn on it; the macro's ring answers a different question — "is
 * this section wired into the macro" — and a cell can be both, because a fill and a border do not
 * compete for the same pixels.
 */
#define NAV_MARK_INSET      3   /* px inside the cell's edge, where the macro's ring sits */
#define NAV_MARK_W          2   /* the ring, the rim's own mark thickness */
/*
 * The bake's antialiasing: four sub-scanlines to a pixel row, and the exact end of every span
 * across it. Enough for a cell that is sixty pixels wide, and the cost of a bake is paid on a page
 * change and on a flash, never on a frame of a slide.
 */
#define NAV_AA_SUB          4
#define NAV_PI 3.14159265f
/*
 * The pagination dots: the answer to "how many sections are in this family and which one
 * am I on", drawn in the centre disc above the title. The row has a FIXED height that
 * clears the taller of the two title forms — a two-line name reaches 14.5 px above the
 * centre — so the row never jumps as pages change. A family of one page gets no dots at
 * all: one dot would say "there is only this", which the title already says.
 */
#define PAGE_DOT_D           6   /* a page you are not on */
#define PAGE_DOT_CUR        10   /* the page you are on: same hue, brighter and bigger */
#define PAGE_DOT_PITCH      16   /* centre to centre, so marking one does not reflow */
#define PAGE_DOT_Y         -30   /* the row's centre, px above the centre of the disc */

/*
 * The macro mark on a tile: a BORDER in COL_MACRO_RIM red, inside the tile's own edge.
 * It began as an outline outside the disc, and that needed the disc to shrink by the
 * pad PLUS the width just to stay inside the tile's cell — cells touch, and the selected
 * tile already grows to fill its own. A border has none of that arithmetic: it is drawn
 * inside the edge, so it cannot reach a neighbour at any size, and two pixels of it read
 * cleanly at arm's length. One pixel read as too thin.
 */
#define MACRO_RING_W         2   /* the mark's thickness, in COL_MACRO_RIM red */
/*
 * A dot you are not on is the family's own chip taken to three quarters of its brightness
 * rather than the half the tile frame uses. At TINT_SEL 128 it measures 1.97:1 against the
 * page behind it (the pink), which is too faint at 6 px; at 192 the worst family is
 * still the pink at 3.31:1, and the best is the darkest chip. The dot you ARE on is the
 * chip at full brightness — 5.36:1 against the page at worst — and 10 px against 6, so
 * the mark is carried by SIZE as well as by brightness and never depends on reading a hue.
 *
 * "The best is the darkest chip" stands where a figure for the amber used to: the amber
 * was the generators' family until they took the teal, the amber's 6.26:1 is not the
 * teal's, and the top of this spread has not been re-measured. The worst did not move,
 * because the pink is untouched, and the worst is the number the 192 was chosen for.
 *
 * These dots sit on the transport curtain rather than on COL_BG, which is why
 * tools/contrast.py cannot reproduce 1.97, 3.31 or 5.36 and prints them for reference
 * only. The figures above are the measured ones; trust them over the script.
 */
#define PAGE_DOT_TINT       192
#define TRANSPORT_BTN_D   160   /* the one button on the transport screen */
#define TRANSPORT_BAT_Y   116   /* the preset button, under that button */
#define TRANSPORT_BAT_X    66   /* the battery, beside the tempo, this far right */
#define TRANSPORT_BPM_Y  (-116) /* the tempo readout, above it, symmetric */
#define TRANSPORT_PRESET_W 112  /* the preset button on the curtain */
#define TRANSPORT_PRESET_H  34

/*
 * The tempo's resolution on the transport screen: one detent of the wheel is one step of
 * this, and the acceleration curve is the same one every other knob uses. It is a constant
 * of its own rather than the page's step count, because the page behind the curtain could
 * have the delay's SYNC list selected — twelve entries now — and a tempo that moved in
 * twelve jumps between 30 and 300 would be a tempo nobody could set.
 *
 * It is PARAM_STEPS, and it used to be 255. At 255 the grid missed 79 of the 271 whole
 * BPMs in 30..300 — 120 among them, its neighbours being 119.4322 and 120.5155 — because
 * 255 is not what a knob's own resolution is here; PARAM_STEPS is. At 1000 every whole
 * value in the range is on the grid, and the step is 0.2766 BPM at 120 and 0.6908 at 300.
 */
#define TRANSPORT_TEMPO_STEPS PARAM_STEPS

/* The transport's ring starts at twelve o'clock and runs a whole turn clockwise, which is
 * what lv_arc_set_rotation(270) made the arc it replaces do. */
#define TEMPO_RING_START 270.0f
#define TEMPO_RING_SWEEP 360.0f
#define TRANSPORT_MARK_D      46   /* the side of the stop square */
#define TRANSPORT_TRI_W       38   /* the play triangle, and the sixth that centres it */
#define TRANSPORT_TRI_H       46
#define TRANSPORT_TRI_STROKE   5

#define NAV_SCREEN_R      180   /* the panel is 360 across: the visible circle's edge */
#define NAV_SLIDE_MS      220
#define RING_EVERY_N_TICKS 3     /* the ring at ~8 fps: enough for a 20 s drift */

/*
 * The ring's geometry, as two numbers to be corrected on the bench.
 *
 * RING_CLOCK is the index of the LED that sits at twelve o'clock, and RING_CW is
 * 1 when a rising index goes clockwise seen from the front. Neither can be known
 * from here: the ring has been used as a linear stereo axis until now, so its
 * physical orientation has never mattered. Step 0 and the start of every fill
 * both begin at twelve and grow the way RING_CW says.
 */
#define RING_CLOCK          0
#define RING_CW             1

/*
 * The preset list: a column of names with the selected one in the middle, and the
 * three action chips around it.
 *
 * It is a WINDOW of seven rows and not the whole store. The store holds up to 128
 * slots, the screen holds seven names at a readable size, and the one thing the
 * list must never do is lose the marker: so the selection is always the middle row
 * and the rows move under it.
 *
 * Seven because the middle needs a middle, and because the column is bounded below by
 * the chips and above by the page's own name. The pitch is 27 px, which is what is
 * left once the chips have their 48: the outermost row's box ends 94.5 px from the
 * middle and its INK at 88.5, and the chips' top edge is at 90 — 1.5 px under that ink
 * and no pitch left to give. Adjacent row BOXES therefore touch, which costs nothing —
 * only the selected row is filled, and two neighbours' ink is still 15 px apart: the line
 * box of the 20 px face is 14 px, not the 27 the pitch was first cut from, so the ink is
 * 12 px of caps and the rows breathe.
 *
 * The row itself is read as three columns: a 6 px indent, the slot number, a gap, and
 * then the longest name the store can draw — eleven characters, 126 px in the large
 * face. It is 160 px wide and aligned 5 px left of centre, and that asymmetry is
 * deliberate: a 150 px row centred on the screen has 6 px of indent, 22 px of
 * three-digit number, and less name than the store can produce. The extra 10 px on the
 * left buy the name its 126 px while leaving the number's indent and the name's screen
 * position exactly where they are for one, two and three digits alike. The highlight a
 * selected row draws is therefore also 10 px wider on the left than the screen's centre —
 * which is right: the text column is not centred (LOAD owns the right), so a highlight
 * that is centred frames nothing, and this one has the same padding behind "1" as
 * behind "128".
 *
 * The column is measured, not hoped for: the widest name the store can make at eleven
 * characters is BURNT SHORE at 126 px at text_condensed(0), the name starts 34 px into
 * the row, and LOAD's left edge is at +78 from the middle — so the ink ends 3 px clear of
 * the chip. A twelve-character name (HOLLOW SHORE, 135 px) drops to the smaller face
 * instead, where it is 120 px. The letter space the large face took back costs this
 * column 1 px per gap and it had 3 to spend, which is why PRESET_NAME_BIG stays at
 * eleven: at +1 the same name would be 136 px and the count would have had to fall to ten.
 */
#define PRESET_ROWS        7     /* -3..+3 about the selection */
#define PRESET_ROW_DY     27
#define PRESET_ROW_W     160
#define PRESET_ROW_X      -5     /* left of centre: see the note above */
#define PRESET_ROW_H      27     /* the row's pitch: its box is as tall as the step */
#define PRESET_NO_X        6     /* the slot number's indent from the row's left edge */
#define PRESET_NAME_X     34     /* where the name starts, past the slot number and its gap */
#define PRESET_NAME_BIG   11     /* characters that still fit the large face */
#define PRESET_FREE_TEXT "EMPTY"  /* what the one slot past the store says */

/*
 * INIT: THE ROW BEFORE THE FIRST SLOT, AND THE ONLY ROW THAT IS NOT A SLOT.
 *
 * It is the factory sound — every patch parameter at synth_app_param_default() — and it
 * exists because "put it back the way it was" is the one thing a library cannot offer: a
 * store of 128 presets has no room reserved for a sound that is not one of them, and a
 * player who has overwritten the factory patch has no way back to it.
 *
 * It is drawn as row 00, it is always first, and it cannot be deleted because it is not
 * stored: nothing writes it, no slot holds it, and SAVE is hidden while it is selected so a
 * slip of the finger cannot turn it into a preset. The store's own slots are numbered from
 * one and the selection is the slot number minus one, which is why this constant is -1.
 */
#define PRESET_SEL_INIT (-1)
#define PRESET_INIT_NO   "00"
#define PRESET_INIT_TEXT "INIT"

/*
 * Where the ink sits in a row, rather than where the label's box does.
 *
 * LVGL centres a label by its LINE BOX, and neither face puts its ink in the middle of that
 * box: the 20 px face is 14 tall and its capitals occupy the top 12 rows (none above, two
 * below), the 14 px face is 10 tall and its ink the top 9 (none above, one below). Centred as
 * boxes in the 27 px row the large name therefore lands 6 px under the row's top edge and 9
 * above its bottom, and the number 8 and 10 — the skew the owner saw. The two spare rows of the
 * large face sit under the baseline, which is what makes the box look centred while the caps
 * are not.
 *
 * The ink is 12 px in the large face and 9 in the small one: 27 - 12 = 15 cannot be halved,
 * 27 - 9 = 18 can. The small face is 9 + 9 at this offset; the large one is 7 + 8, so half a
 * pixel of the remainder goes below the caps. Both labels take the same +1, and it is the only
 * integer offset at which BOTH are within half a pixel of even: +0 leaves the large name 6 + 9
 * and the number 8 + 10, +2 makes the number 10 + 8 and the small face a full pixel low.
 *
 * The odd pixel belongs BELOW the large name because the face itself already leaves its air
 * there: all of its ink starts at row 0 of the line box and the two empty rows are under the
 * baseline. Putting the extra pixel above the caps would contradict the drawing of the face.
 *
 * These offsets also survive the name's switch to the small face: LVGL recomputes the label's
 * y from its height when the font changes, so the row stays 27 and the line box shrinks from
 * 14 to 10 around the same +1. The ink centre moves from 13.0 to 13.5 px from the row's top —
 * half a pixel, the very remainder the large face carries at either offset, so nothing jumps.
 */
#define PRESET_INK_DY      1     /* label offset that centres the ink, not the line box */

/*
 * The master's waveform, on the preset page's equator.
 *
 * The page has no sectors and no level, and it is the page a sound is chosen on — so it gets
 * the one thing that says what the sound IS: the shape of the master's own output, drawn
 * straight across the middle of the dial. Behind the list, dim, because it is a background to
 * a choice rather than a meter to be read.
 *
 * It runs from one edge of the glass to the other. It used to stop at 280 px, forty short at
 * each end, on the reasoning that a curve with margins is a curve and not a rule — but the
 * right-hand end then fell under the LOAD chip and what was left of the line was one stub
 * hanging beside the list, which reads as a line that broke rather than as a line that ended.
 * The band is 358 px wide, so the two ends of the stroke sit a pixel inside the glass and the
 * curve crosses the whole dial; the list covers its middle and the LOAD chip its right third,
 * which is what "behind the list" means.
 *
 * Forty-one points over that width is the whole resolution of the band: a block decimated to
 * this many samples still reads as a curve at this size. The band is 120 px tall, so an update
 * invalidates a third of the screen rather than all of it.
 */
#define WAVE_POINTS 41
#define WAVE_W      358
#define WAVE_H      120
#define WAVE_AMP    56              /* full scale above and below the equator */
#define WAVE_GAIN   1.8f            /* display gain: the line has to be readable, not accurate */
#define WAVE_EVERY_N_TICKS 2        /* ~12 fps */
/*
 * The chips are sized for a fingertip and not for a mouse: 48 px is the floor every
 * one of them clears (Apple's 44 pt), and the two at the bottom of the page now reach
 * it as well; only LOAD has nothing above or below it to argue with. A name row is
 * 27 px, so a chip is deliberately larger than the thing it acts on.
 *
 * The two at the bottom are the constrained pair: they share the last band of the
 * screen and their corners must stay inside the arc's inner stroke at 162 px. At
 * y = 114 and 48 px tall the far corner is 138 px below centre, which leaves |x| ≤ 80
 * for the 2 px of air the rest of the page keeps — so 72 px is the widest they can be
 * at ±44, and at 72 both of them are.
 *
 * SAVE and RND are the same width deliberately: they are the same kind of thing, one
 * button each, and a pair whose widths differ reads as having different weights. RND
 * is not sized by its word — it is labelled RND, 34 px of ink in the large face — and
 * neither chip is: a button that shrank to its label would be the mouse target this
 * page was just enlarged to get away from. All three labels are in that face, because
 * these chips are the first place on this page where it fits.
 */
#define PRESET_LOAD_W     64
#define PRESET_LOAD_H     48
#define PRESET_CHIP_H     48
#define PRESET_CHIP_Y    114
#define PRESET_SAVE_W     72
#define PRESET_RANDOM_W   72
/*
 * The field of reaction around the list and the chips.
 *
 * The panel is 360 px across 1.85 in — 194.6 dpi, so one pixel is 0.131 mm and one
 * millimetre is 7.66 px. The chips are 48 px tall, 6.3 mm, under the 7 mm a fingertip
 * wants even though their widths already clear it; a row is 27 px, 3.5 mm. Eight
 * pixels is 1.05 mm of forgiveness per side: a chip's field is 64 px (8.4 mm) tall;
 * LOAD becomes 80 x 64 and SAVE/RND 88 x 64, a row 176 x 43. The bottom pair is
 * 16 px apart, so at 8 their areas still leave the one-pixel column between them
 * (179 and 180) and at 9 they overlap; the list's pitch is 27, so the split between
 * two rows stays at the 13.5 px midpoint either way and the pad only widens the
 * column and its two outer ends. SAVE and RND stand directly under the bottom row,
 * and the top 8 px of their field fall inside that row's box: those pixels go to the
 * row (see preset_ext_hit_cb), so their effective field is 56 px (7.3 mm) tall by 88
 * wide.
 *
 * The farthest corner of any enlarged area is 169.8 px from the centre of the glass,
 * so nothing reaches the 180 px edge: a touch outside the visible circle stays inert.
 */
#define PRESET_EXT_CLICK_PX 8
/*
 * Where the chips sit, in screen-relative pixels. All of them are fixed, including
 * the one beside the selection: a chip that chased the name it belongs to would move
 * sideways under the finger as the list scrolled, and the row it belongs to is always
 * the same row anyway.
 */
#define PRESET_LOAD_X     110
#define PRESET_SAVE_X     -44
#define PRESET_RANDOM_X    44
/*
 * SAVE blinks while the sound disagrees with the slot: eight animation ticks of 40 ms are
 * 320 ms lit and 320 ms dimmed.
 */
#define PRESET_BLINK_EVERY_N_TICKS 8
/*
 * What SAVE and RND wear under a finger.
 *
 * The palette block has no entry at Material's TEAL400 (0x26A69A) or TEAL600
 * (0x00897B): the teal family in GROUP_COLOR holds 900 / 800 / 700 and 300 / 200,
 * and the step COL_ACCENT_DIM calls its teal-400 is 0x009988. The pressed pair is
 * therefore written here, at the two steps of that ramp nearest those two names:
 * 0x009988, the value the palette itself calls teal-400, within 38/255 of #26A69A on
 * its worst channel, and 0x00796B, the ramp's teal-700, within 16/255 of #00897B —
 * rather than at the Material values themselves, so that a
 * pressed chip is made of the colours the rest of the page is made of. They are
 * literals and not COL_ACCENT_DIM because that constant means "a rim that is not
 * selected": a surface and a rim have to be free to move apart.
 *
 * At rest a chip is the grey tile at half depth, 0x13191C — 1.1:1 against the page,
 * its ink 15.3:1 on top of it. Under the finger the fill becomes 0x009988, 5.3:1
 * against the page and 4.8:1 against the grey it was, and the word goes to 0x00796B,
 * 1.4:1 on that fill: the pair is a colour change and not a reading contrast, and
 * the fill is what carries the state.
 */
#define PRESET_CHIP_PRESS_FILL 0x009988
#define PRESET_CHIP_PRESS_INK  0x00796B
#define PRESET_SWIPE        8   /* rows a horizontal swipe walks */
/*
 * How far each row's ink is turned down by its distance from the selection: at the
 * selection, one row away, and two or more. Against this near-black page those
 * opacities measure about 17:1, 6:1 and 3:1, so the falloff is plainly visible and
 * no row of the seven becomes a row that cannot be read.
 */
#define PRESET_OPA_SEL    255
#define PRESET_OPA_NEAR   150
#define PRESET_OPA_FAR     95
/*
 * The randomiser draws inside the middle of every range rather than end to end:
 * a random cutoff from 0 to 1 is as likely to be a closed filter as an open one,
 * and both ends of most of these controls are places the voicing does not live.
 * The window is the central 60 percent, and a parameter with discrete positions
 * lands on whichever of them that window contains.
 */
#define PRESET_RAND_FLO  0.2f
#define PRESET_RAND_SPAN 0.6f

/*
 * Two of the lists are long enough that the central 60 percent is no longer a musical
 * window. The delay's SYNC holds twelve entries, eight of which fall inside it, and the
 * slow end of those is 1/2. — a three-second echo at 60 bpm on a part nobody placed there;
 * the arp's SPEED holds thirteen, which brings 1/1 inside the window, a note to the bar.
 *
 * So those two are drawn from a window of their own, chosen the way the old window was:
 * the divisions a draw could reach before the lists were widened, plus the dotted entries
 * that now fall between them. A list position is round(v * (count - 1)), so a window that
 * starts and ends exactly on an entry position cannot round off it:
 *
 *   DELAY SYNC  1/4 … 1/8T  = entries 5..9  of 12  ->  [5/11, 9/11]  = [0.4545, 0.8182]
 *   ARP SPEED   1/8 … 1/16  = entries 8..11 of 13  ->  [8/12, 11/12] = [0.6667, 0.9167]
 *
 * Each keeps the span in time its own five-entry list used to be drawn over — 3:1 for the
 * delay, 2:1 for the arp — so a drawn patch still sounds like a patch. At 60 bpm the
 * slowest echo a draw can now produce is 1/4, one second, and the slowest arp note an
 * eighth; the central window read against the same lists reaches a three-second echo and,
 * on the arp, 1/1.
 *
 * Only the randomiser of a whole patch uses these: a tap in the middle of the page draws
 * one control, and for a list it draws one of that list's entries, all of them.
 */
static float preset_rand_flo(synth_param_t param)
{
    switch (param) {
    case SYNTH_PARAM_DELAY_SYNC: return 5.0f / 11.0f;
    case SYNTH_PARAM_ARP_SPEED:  return 8.0f / 12.0f;
    default:                     return PRESET_RAND_FLO;
    }
}

static float preset_rand_span(synth_param_t param)
{
    switch (param) {
    case SYNTH_PARAM_DELAY_SYNC: return 4.0f / 11.0f;
    case SYNTH_PARAM_ARP_SPEED:  return 3.0f / 12.0f;
    default:                     return PRESET_RAND_SPAN;
    }
}
/* A draw in [0,1) out of the hardware generator: its top 24 bits, which is more
 * resolution than any parameter here has positions. Used by the single-control tap in
 * the middle of a page; the patch-wide draws own their own arithmetic in the app. */
static float preset_random_unit(void)
{
    return (float)(esp_random() >> 8) / 16777216.0f;
}

/*
 * Ring colours, at full scale.
 *
 * These used to be small numbers, and that was the bug behind "the ring is too
 * dim": bsp_led_set() scales every channel by CONFIG_BSP_LED_BRIGHTNESS_LIMIT /
 * 255, so a value of 28 reaches the strip as 7. The ring was lit at under three
 * percent of what it can do.
 *
 * Expressed at full scale instead, and attenuated in exactly one place —
 * bsp_led_set_brightness(), driven by the RING setting — the same colours come
 * out around nine times brighter at the default brightness, the ceiling still
 * decides the maximum, and the brightness control can only take away, which is
 * what a brightness control should do.
 *
 * Two of the ring's colours belong to the PAGE and three belong to the INSTRUMENT,
 * and the split is the same one the screen makes:
 *
 *   the value arc, the pattern steps and the resting anchor take the current
 *   section's family colour, in the same two steps the screen uses — the bright
 *   one for the value the knob is standing on, a third of it for the context
 *   around that value. Turning to a blue page turns the ring blue, and the colour
 *   on the ring is the colour of the tile you tapped to get there.
 *
 *   the playhead stays amber, because time is the one thing that is true on every
 *   page; the macro stays the macro red; a stopped instrument stays red. Those are
 *   states, and a state that changed colour as you turned the page would stop being
 *   a state.
 *
 * The playhead is the brightest thing the ring can draw: the pattern is context and
 * says what the sequence is, the playhead is the news and says where it is. Two
 * levels of the same idea, so the eye reads the beat without having to count LEDs.
 */
#define RING_CUR_R        170   /* the playhead, between notes: above every step */
#define RING_CUR_G        158
#define RING_CUR_B         74
#define RING_HOT_R        255   /* and brightest of all on the note it is playing */
#define RING_HOT_G        241
#define RING_HOT_B        118
#define RING_STOP_R       150   /* stopped: the whole ring, and nothing else */
#define RING_STOP_G         0
#define RING_STOP_B         0
/* The instrument's slow timer: the transport's readouts and the remembered sound. */
#define HOUSEKEEP_PERIOD_MS 500

/*
 * Colour tokens.
 *
 * The palette supplies seven hue ramps and no neutrals, and a dark theme needs
 * neutrals far more than it needs seven hues — so the greys here are the teal
 * ramp taken down towards black rather than greys from some other family. Every
 * surface keeps a trace of the accent, which is what stops a dark UI looking
 * like two unrelated designs stacked on top of each other.
 *
 * Three things are allowed to be said with colour, and each of them owns its own
 * CHANNEL rather than its own private hue. That is the rule that lets a coloured
 * map and a macro mark sit on the same sector without either being lost:
 *
 *   which FAMILY of controls you are in ... the thin rim, and the name (see
 *                                           GROUP_COLOR below)
 *   which value the knob is standing on ... the fill, and the rim's width
 *   which values the macro is riding ....... a red fill and a red rim, which win
 *                                           over both of the above
 *
 * The accent teal is not one of the three. It is what a VALUE is drawn in — the
 * filled part of a rim, the digits on the page — and it stays teal on every page,
 * so "this is a number" is one constant thing on a screen that is otherwise a map.
 *
 * Nothing is coloured for decoration, so a colour on screen always says something.
 */
#define COL_BG        0x04100D   /* teal-600, taken almost to black */
#define COL_MUTED     0x4E8C7E   /* secondary text: teal-400 desaturated */
#define COL_FAINT     0x1E443B   /* dividers and hairlines */
#define COL_TEXT      0xD4F5F0   /* teal-100: primary text */
#define COL_ARC_BG    0x0C2B24   /* the unfilled part of a rim */
#define COL_VIZ_CLIP  0xF0B429   /* a meter within a tenth of its ceiling */
#define COL_SEL_BG    0x0B3A32   /* background of the selected sector */
#define COL_ACCENT    0x00FFCC   /* teal-200: the one accent colour */
#define COL_ACCENT_DIM 0x009988  /* teal-400: a rim that is not selected */

/*
 * The sequencer gets its own hue, and it is the only part of the instrument
 * that does.
 *
 * Everything else on the screen is teal because it is a VALUE being edited, and
 * the macro red when it is a value being ridden from elsewhere. The ring is
 * neither: it is a picture of time, and it has to be readable at a glance while
 * the eye is not on it. Amber is far enough from teal to never be confused with
 * selection, and far enough from the macro red to survive both being on screen
 * at once — the red is always a filled sector or a rim and the amber is always
 * small round dots, so shape separates them even where hue is close.
 *
 * Contrast against the background, which is very dark teal:
 *   step on   13.9:1   the steps the pattern sounds
 *   cursor     8.1:1   the cursor between notes
 *   cursor    16.8:1   the cursor on the note that is sounding
 *   step off   2.3:1   a grid position the pattern leaves silent
 * The sounding cursor is deliberately the brightest thing on the page: it is the
 * one answer the ears cannot give you.
 */
#define COL_STEP_ON    0xFFD54F  /* amber-300: a step the pattern sounds */
#define COL_STEP_OFF   0x5C4A18  /* the same hue taken far down: a silent position */
#define COL_STEP_DIM   0xC9A227  /* the cursor between notes */
#define COL_STEP_HOT   0xFFF176  /* the cursor while a note sounds */

/*
 * A macro sector is red all the way through — but in SHADES of one red rather
 * than one flat colour, and contrast decides which shade goes where. Measured
 * against this screen's near-black background:
 *
 *   red-500 as text is about 1.95:1, which is unreadable at 14 px. It is not
 *   used for anything that has to be read.
 *   red-400 reaches 3.0:1, which is exactly the requirement for a graphical
 *   element, so it is the rim of a sector that rides along but is not being
 *   turned.
 *   red-300 reaches 4.6:1 and red-200 5.8:1, so those carry the name and the
 *   value.
 *   red-600 is a tint: it is there to make a surface red, not to be read.
 *
 * On the solid red fill the text steps up to red-100 (10:1), because red-200 on
 * red-600 is only 3.9:1 and that is not enough at 14 px either.
 */
#define COL_MACRO_RIM      0xB32E00  /* red-400: a rim that rides along */
#define COL_MACRO_RIM_SEL  0xFF4D00  /* red-200: the rim being turned */
#define COL_MACRO_TINT     0x5C1800  /* red-600: the sector's fill and wash */
#define COL_MACRO_TEXT     0xE63E00  /* red-300: the sector's name */
#define COL_MACRO_VALUE    0xFF4D00  /* red-200: the sector's value */
#define COL_MACRO_ON_TINT  0xFDE0D9  /* red-100: anything on the red fill */

/*
 * The same roles again for a member that rides the macro BACKWARDS, in yellow.
 *
 * This block was teal, on the argument that teal was the one hue no family owned. The
 * generators have since taken the teal — they had amber, which the sequencer's
 * ring also uses — and that freed the amber ramp for this. The argument is unchanged,
 * only the hue it is made about: yellow is now the one hue no family owns, and the
 * families are blue, violet, teal, green, pink, brown and grey.
 *
 * The yellow ramp is far brighter than the red it mirrors, and that is not a choice:
 * there is no dark yellow that is still yellow. Against the page, the rim measures
 * 9.8:1 where the macro's red measures 3.1, and the value 13.9 where the red's is 5.8
 * — so this is the loudest mark on the screen whenever it is drawn. The cost is that
 * red-orange and yellow are neighbours, where the teal was red's opposite: on a page
 * carrying both marks the two are now told apart by 33 degrees of hue rather than by
 * half the wheel. A player who cannot separate those two has the readout and the
 * darker/lighter pair inside each mark to go on, but it is a real loss next to what
 * the teal bought, and it is written down here rather than discovered later.
 */
#define COL_INV_RIM        0xF9A825  /* yellow-800: a rim that rides along backwards */
#define COL_INV_RIM_SEL    0xFDD835  /* yellow-600: the rim being turned */
#define COL_INV_TINT       0x4A3B00  /* dark olive: the sector's fill and wash */
#define COL_INV_TEXT       0xF57F17  /* yellow-900: the sector's name */
#define COL_INV_VALUE      0xFDD835  /* yellow-600: the sector's value */
#define COL_INV_ON_TINT    0xFFF9C4  /* yellow-100: anything on the yellow fill */

/*
 * The transport button is the one control on this screen that is not a value, so
 * it is the one control coloured for what it DOES rather than for what it is:
 * green while it reads PLAY, red while it reads STOP.
 *
 * Both families are built the same way as the accent teal — the ramp taken almost
 * to black for the fill, a mid step for the rim, a light step for the label — so
 * the button belongs to the same design as everything else while still being the
 * only green and the only true red on the instrument.
 *
 * The macro red is deliberately an ORANGE-red (0xFF4D00) so that these two can
 * never be confused: a macro is a fill or a rim on a sector, the transport is a
 * filled circle, and shape separates them even where hue is close. That is the
 * same trick the sequencer's amber already relies on.
 *
 * Contrast against the near-black background: the green rim is 6.9:1 and the red
 * rim 3.9:1, both past the 3:1 a graphical element needs, and the labels are
 * 15.6:1 and 12.4:1.
 */
#define COL_RUN_BG     0x0A2E14  /* green-900 taken almost to black */
#define COL_RUN_RIM    0x66BB6A  /* green-400 */
#define COL_RUN_TEXT   0xC8E6C9  /* green-100 */
#define COL_STOP_BG    0x3A0C0C  /* red-900, taken down to match */
#define COL_STOP_RIM   0xEF5350  /* red-400 */
#define COL_STOP_TEXT  0xFFCDD2  /* red-100 */

/* The battery's two states, as Material 600 steps, the depth the rest of this palette quotes.
 * Hue carries the state now that the text does not: red is the cell running the instrument,
 * green is the charger holding it up. */
#define COL_BAT_LOW    0xE53935  /* red-600 */
#define COL_BAT_CHG    0x43A047  /* green-600 */

/* The selected sector is marked two ways at once, and the two marks answer
 * different questions: the fill says "this is what the knob moves", and the width
 * of the rim says it too. Neither can hide the other. */
#define COL_SEC_IDLE  COL_ACCENT_DIM
#define COL_SEC_SEL   COL_ACCENT

/*
 * The families of controls, and the hue each one owns.
 *
 * The pages are ordered so that a family is CONTIGUOUS — all of the body, then all
 * of the voice, then all of the time, then the percussion, then the rack, then the
 * mixers — because a colour code is only a code if you can see it without counting.
 * On the curtain that comes out as six bands of colour and then the greys.
 *
 * The hues are chosen by what is left, not by what is pretty. Three things on this
 * instrument already mean something else and cannot be reused:
 *
 *   red/orange the macro, as a fill, and green/red on the transport
 *   amber     time, on the sequencer's ring
 *   the greys a readout, or a place you go rather than play
 *
 * That leaves blue, violet, teal, green, pink and brown for the six played families.
 * Nothing overlaps now. It used to: the generators wore amber, the same amber as the
 * ring's step dots, on the argument that the generators ARE the time pages and that
 * saying so twice on two surfaces is not a collision. It has since been replaced, and the
 * place that argument stopped paying is easy to name — on EUCLID the family and the
 * playhead were one colour separated only by brightness. The teal the generators took
 * is the hue this file's inversion mark used to hold, which is why that mark is yellow
 * now: one of the two had to be the marker, and the marker is the one that must not be
 * readable as a family.
 *
 * Teal is a compromise worth naming rather than hiding. It is the accent hue — the
 * colour a VALUE is drawn in on every page — so a generator page's own colour is also
 * the colour its numbers are written in, and on those three pages colour answers
 * "which page is this" less quickly than it does elsewhere. The rim, the tile and the
 * title still answer it. If it proves too quiet in the hand, cyan-700 (0x0097A7) is
 * one line away, is nobody's hue, and is a clear step from the accent.
 *
 * The percussion needed a family of its own rather than a hue borrowed from one of
 * the others, because it is a new PART and not a new page of an old one: it is not
 * the body, which never stops; not the voice, which plays a line; not a generator
 * deciding which notes the line uses; not an effect the others pass through; and
 * not a readout. Its green is the blue ramp shifted in hue — tile green-600, fill
 * green-900, rim green-800, bright green-400, text green-200 — so it is built
 * exactly like the other five.
 *
 * Green is also the transport's colour, and that overlap is deliberate and paid for
 * the way the macro's orange-red is: the transport is ONE filled disc in a cell of
 * its own with PLAY or STOP written on it, and it is coloured for what it DOES,
 * while a percussion tile is one of twenty chips and on a page the family green is
 * only ever a hairline rim or a word. Hue says which family, shape says which
 * control, and no two controls that share a hue share a shape.
 *
 * Two surfaces, two channels, and the numbers for each one.
 *
 * A SECTOR on a page is a hairline: the family colour is its rim, and it has to
 * clear 3:1 against the dark page as a graphical element. A TILE on the curtain is
 * a solid disc: the family colour is the whole chip, and the label lying on that
 * chip has to clear 4.5:1 as text.
 *
 * The chips are DARK and the words on them are LIGHT, in the family's own hue. Both are
 * deliberate: bright chips were competing with the macro's red rim for the same
 * attention, the pink family in particular reading as one more red mark on the map, and a
 * label of plain white would have spent the family's colour to buy nothing.
 *
 * The label is the most saturated shade of the family that still clears 4.5:1 on its own
 * chip. The 400 does not: on these chips it measures 1.85:1 to
 * 3.74:1. So each family takes the deepest shade that does clear the number — a 200 for
 * most of them, amber's 300, pink's 100 because its 200 lands at 4.2:1 — and every one of
 * them is visibly its own hue. The page's own text is unchanged and is measured against
 * the PAGE, not the chip: 4.2:1 at worst, 13:1 at best.
 *
 * Measured: the chip against the page as a shape, then the label on the chip as text.
 *
 *   blue-900    2.3:1        blue-200   4.9:1
 *   violet-900  1.7:1       violet-200  5.0:1
 *   teal-900    2.0:1       teal-200    5.3:1
 *   green-900   2.6:1       green-200   4.8:1
 *   pink-900    2.1:1        pink-100   5.9:1
 *   brown-900   1.5:1       brown-200   6.2:1
 *   grey-900    1.5:1        grey-100   9.1:1
 *   grey-700    2.8:1        grey-100   5.0:1
 *
 * ПОДПИСЬ НА ПЛИТКЕ — ШАГ 400, а не пастельный 200: по чёрной шторке плитки различают
 * цветом раньше, чем словом, и пастель на тёмной заливке читалась как один и тот же
 * светлый тон. Шаг 400 — тот же набор, тот же порядок, только насыщеннее; заливки плиток
 * не менялись.
 *
 * The chip as a SHAPE is the quietest it has been: 1.5:1 to 2.8:1 against the page, where
 * the bright chips once reached 5:1 and better and the 800 chips held 1.8:1 to 3.9:1. The
 * cost of that step is the number above: the darker chips were taken anyway, and the
 * reasoning survives it — a tile is found by its word, and every word in the right-hand
 * column reads. Going back up a step is a one-line change if the map looks too faint.
 *
 * The page's own surfaces stay dark, in separate fields, because they are read
 * differently: a rim, the page behind it and the panel under a sector's name are
 * context, and context should be quiet. The page still gets the family's hue — tile
 * and page are one colour at two depths, which is what makes a family a family. The
 * rim figures are unchanged — blue-700 4.2:1, violet-400 4.0:1, teal-700 3.6:1,
 * green-800 3.8:1, pink-500 4.5:1, and the greys exactly as they already were, with
 * brown-700 joining them. Darkening a hue until it hits a contrast number is how a
 * palette stops being one.
 *
 * The fill is deliberately NOT used on the sectors. There the fill already means two
 * other things — "the knob is standing on this sector" and "the macro is riding it"
 * — and a third meaning would cost both of them.
 *
 * The greys mean "this is not played", which is what a readout and a settings page
 * are. The MIXERS used to be grey with them, on the argument that a mixer spans every
 * family at once and therefore belongs to none — a true observation and the wrong
 * conclusion, because the curtain is a MAP: a section you visit while playing needs a
 * colour you can find without reading, and grey told the eye that nothing was there.
 * Brown is not owned by any played part either, so the mixers are a family like every
 * other now — the sixth, and the first defined by what the page is FOR rather than by
 * which circuit it sits on.
 */
typedef enum {
    GRP_DRONE = 0,      /* blue: the body, which is always sounding */
    GRP_LEAD,           /* violet: the voice, which is played */
    GRP_GEN,            /* teal: time, which decides the notes */
    GRP_PERC,           /* green: the percussion, which is neither of those */
    GRP_FX,             /* pink: the rack, which everything goes through */
    GRP_MIX,            /* brown: the mixers, which put the families against each other */
    GRP_VIEW,           /* grey: readouts and setup, which are not played at all */
    GRP_PRESET,         /* dark grey: the presets, which are places rather than parts */
    GRP_COUNT
} nav_group_t;

typedef struct {
    uint32_t tile;      /* the TILE's chip: a dark shade, with a light label on it */
    uint32_t fill;      /* the family at surface depth: the page, the rim tracks */
    uint32_t rim;       /* the SECTOR hairline: this family, dark enough for a page */
    uint32_t bright;    /* the same hue, brighter: the sector the knob is on, and the ring */
    uint32_t text;      /* the family's name, at reading contrast on the dark page */
    uint32_t ink;       /* the TILE's label, and the frame on the current tile */
} nav_group_color_t;

static const nav_group_color_t GROUP_COLOR[GRP_COUNT] = {
    /* tile      fill      rim       bright    text      ink */
    { 0x0D47A1, 0x1565C0, 0x1976D2, 0x64B5F6, 0x90CAF9, 0x42A5F5 },   /* blue-900 / 800 / 700 / 300 / 200 / 400 */
    { 0x4A148C, 0x9C27B0, 0xAB47BC, 0xBA68C8, 0xCE93D8, 0xAB47BC },   /* violet-900 / 500 / 400 / 300 / 200 / 400 */
    { 0x004D40, 0x00695C, 0x00796B, 0x4DB6AC, 0x80CBC4, 0x26A69A },   /* teal-900 / 800 / 700 / 300 / 200 / 400 */
    { 0x1B5E20, 0x1B5E20, 0x2E7D32, 0x66BB6A, 0xA5D6A7, 0x4CAF50 },   /* green-900 x2 / 800 / 400 / 200 / 500 */
    { 0x880E4F, 0xC2185B, 0xE91E63, 0xF06292, 0xF48FB1, 0xEC407A },   /* pink-900 / 600 / 500 / 300 / 200 / 400 */
    { 0x3E2723, 0x4E342E, 0x5D4037, 0xA1887F, 0xBCAAA4, 0x8D6E63 },   /* brown-900 / 800 / 700 / 300 / 200 / 400 */
    { 0x263238, 0x546E7A, COL_FAINT, 0x90A4AE, 0x90A4AE, 0x90A4AE }, /* blue-grey-900 / 600, faint rim, 300 x3 */
    /* The presets, one step LIGHTER than the settings' grey, so a place you go still reads
     * as a different kind of tile from a page you tune. */
    { 0x455A64, 0x37474F, 0x455A64, 0x90A4AE, 0xCFD8DC, 0xB0BEC5 },   /* blue-grey-700 / 800 / 700 / 300 / 100 / 200 */
};

/*
 * The map's own three steps of each family's palette: the cell, the cell you are standing on, and
 * the name on it. This is where the mosaic takes every colour it uses, and the instrument's table
 * above is left alone — the rim, the sectors and the page dots keep the steps they were measured
 * with.
 *
 * One ladder: the cell is its family's darkest step sunk to NAV_CELL_DARK of its brightness, the
 * cell you are on is 600, the name is 400, and the flash is 800.
 *
 * The cells are sunk because of the seam. The cut is the surface showing through between two cells
 * — a near black — and a cell at its palette depth measured about two and a half to one against it,
 * so the map read as bright tiles in a black net: the line was the loudest thing on the screen
 * because everything around it was bright. Sunk to NAV_CELL_DARK the cell measures about one and a
 * half to one against the same line, which is what makes the seam recede, and the family is then
 * carried by the name (400, about six to one on the sunk cell) rather than by the fill.
 *
 * A name on the cell you are on is the one weak pair in this ladder: 600 is a bright step and 400
 * sits on it at about one and a half to one. It is legible as a shape and not as a reading, which
 * is the price of a fill that says "here" this plainly; if it reads as washed out, the name on that
 * one cell is what to move, not the fill.
 *
 * The presets keep their own ramp, one step lighter than the settings' grey — 700/500/300 against
 * 800/600/400 — so a place you go still reads as a different kind of tile from a page you tune.
 */
typedef struct {
    uint32_t cell;   /* 800: the tile */
    uint32_t here;   /* 600: the tile you are standing on */
    uint32_t tag;    /* 400: the name on it */
    uint32_t flash;  /* 900: the tile while its part is sounding */
} nav_map_tone_t;

static const nav_map_tone_t MAP_TONE[GRP_COUNT] = {
    /* cell      here      tag       flash */
    { 0x0D47A1, 0x1E88E5, 0x42A5F5, 0x1565C0 },   /* blue    900 / 600 / 400 / 800 */
    { 0x4A148C, 0x8E24AA, 0xAB47BC, 0x6A1B9A },   /* violet  900 / 600 / 400 / 800 */
    { 0x004D40, 0x00897B, 0x26A69A, 0x00695C },   /* teal    900 / 600 / 400 / 800 */
    { 0x1B5E20, 0x43A047, 0x66BB6A, 0x2E7D32 },   /* green   900 / 600 / 400 / 800 */
    { 0x880E4F, 0xD81B60, 0xEC407A, 0xAD1457 },   /* pink    900 / 600 / 400 / 800 */
    { 0x3E2723, 0x6D4C41, 0x8D6E63, 0x4E342E },   /* brown   900 / 600 / 400 / 800 */
    { 0x263238, 0x546E7A, 0x78909C, 0x37474F },   /* grey    900 / 600 / 400 / 800 */
    { 0x37474F, 0x607D8B, 0x90A4AE, 0x455A64 },   /* presets 800 / 500 / 300 / 700 */
};

/*
 * The family colour is needed on five different surfaces — the tile's disc, a
 * sector's rim, the page behind everything, the recessed track of a rim, and the
 * LEDs on the ring — and every one of them wants the same hue at a different depth.
 *
 * The near-black constants would drift apart the first time one of them was
 * edited, so they are derived instead: scaling every channel by the same factor
 * preserves the hue exactly, and the factors below were picked to land on the
 * luminance of the teal surfaces they replace. That is why every contrast figure
 * measured before this change still holds — the page is the same black, it is just
 * a different black.
 */
#define TINT_BG      26    /* the page behind everything */
#define TINT_TRACK   96    /* the unfilled part of a rim */
#define TINT_SEL    128    /* a surface depth: the preset window's frame, the tile row */
#define TINT_ANCHOR  56    /* the ring: where the scale starts */
#define TINT_STEP   110    /* the ring: a step the pattern sounds */

/*
 * The selected sector's fill is a SURFACE, not a highlight, so it is the family's own
 * hue taken further down than the 128 that the window frame and the preset list use.
 * The fill is a little darker, within the palette: 96 is exactly a quarter
 * less of the same hue. Measured over every row in GROUP_COLOR it moves the worst ink on
 * the fill from 4.73:1 to 5.74:1 for the name and from 10.58:1 to 12.82:1 for the value,
 * both of them the settings grey's — the grey is the worst on the fill, not the violet
 * and the blue the earlier note named, because that note counted only the played
 * families. 5.74:1 still clears the 4.5:1 a label needs. The wedge stays 1.20:1 against
 * the page behind it, so it is still an obvious surface and no longer as bright as one.
 * 112 and 88 are one number away if it reads too dark or too light on the panel.
 *
 * The generators' teal was checked into this set when they took it and sits inside both
 * worsts (its name 8.57:1 and its value 13.80:1 at 96). tools/contrast.py recomputes the
 * whole table from GROUP_COLOR, and validates itself against the figures in this file.
 */
#define TINT_BODY    96    /* the fill of the selected sector */

/*
 * THE SELECTED SECTOR'S FILLED NOTCHES ARE NEARLY WHITE.
 *
 * The filled part of the ring is what says how far the knob has been turned, and on the sector
 * the knob is standing on it is the one thing that has to be read first. It used to be the
 * family's brightest tone, which on a dark page is bright only relative to the family: at this
 * size a fill of notches in a mid tone still competes with the unlit notches beside it. Taken to
 * within a twentieth of white, with the family's own cast kept in it, the fill separates from the
 * track by brightness alone and the family is still legible on it — the hue says which page this
 * is, the lightness says how far the knob has gone.
 *
 * The macro's red and the inversion's yellow are NOT touched: an area of that colour is how this
 * instrument says "this knob is in the macro", and a member's fill has to stay that colour.
 *
 * 16/256 is one number. Lower it and the fill goes white on every family; raise it and the
 * page starts to lose its colour.
 */
#define TINT_TICK_LIGHT 16

static uint32_t tint(uint32_t rgb, int num)
{
    const uint32_t r = ((rgb >> 16) & 0xFFu) * (uint32_t)num / 256u;
    const uint32_t g = ((rgb >> 8) & 0xFFu) * (uint32_t)num / 256u;
    const uint32_t b = (rgb & 0xFFu) * (uint32_t)num / 256u;
    return (r << 16) | (g << 8) | b;
}

/* The same easing, but towards white instead of towards black: num/256 of the family in a white
 * ground. This is the wedge of the selected sector — see TINT_BODY_LIGHT. */
static uint32_t tint_light(uint32_t rgb, int num)
{
    const uint32_t n = (uint32_t)num;
    const uint32_t r = (255u * (256u - n) + ((rgb >> 16) & 0xFFu) * n) / 256u;
    const uint32_t g = (255u * (256u - n) + ((rgb >> 8) & 0xFFu) * n) / 256u;
    const uint32_t b = (255u * (256u - n) + (rgb & 0xFFu) * n) / 256u;
    return (r << 16) | (g << 8) | b;
}

/* The three panned registers' colours on the ring: cool to hot, matching low to
 * high, and distinct from the teal accent and from each other at a glance.
 *
 * They used to be the legend for the orbit page's tracks as well, so that a colour
 * meant the same register in both places. The page is gone and the ring is the only
 * surface left, which makes this the register's colour rather than a key to one.
 *
 * At the same full scale as the rest — see the note above RING_STEP_R. They used to
 * be pre-divided for the old ceiling, which is why they look like odd numbers; these
 * are the colours themselves, and the ceiling and the brightness setting take them
 * down from here. */
static const uint8_t REG_RING[ORBIT_ROWS][3] = {
    {  66, 165, 245 },  /* blue-400  */
    { 102, 187, 106 },  /* green-400 */
    { 239,  83,  80 },  /* red-400   */
};

/* -------------------------------------------------------------------------- */
/* Rim layouts                                                                */
/* -------------------------------------------------------------------------- */

typedef struct {
    int16_t start, end;     /* rim span, clockwise from start to end */
} rim_span_t;

/*
 * A rim table AND its length, so that the two cannot be separated — the same disease
 * as the page counts, one level down. `layout_sectors()` walks a page's knob count and
 * reads `rim[i]` for each; with only a pointer in hand the size is gone at the point of
 * use, and a table that had lost an entry would have been walked off its end. Here the
 * length is taken from the array and travels with it, and every walk is clamped to it.
 */
typedef struct {
    const rim_span_t *spans;
    int               count;
} rim_t;

/* A table paired with its own length. */
#define RIM_OF(t) ((rim_t){ (t), NK(t) })

/*
 * The tables are declared WITHOUT a size on purpose. `RIM_4[4]` would make the
 * assertion below vacuous — sizeof() would report 4 whatever the list held — and, worse,
 * a short initialiser list against an explicit size is not even an error: the compiler
 * pads the rest with zeros, every missing sector silently becomes the span { 0, 0 }, and
 * `lv_arc_set_bg_angles(arc, 0, 0)` draws nothing. Letting the size be deduced and then
 * asserting what was deduced is the only version of this check that can fail.
 */

/* Four quarters from 9 o'clock: 9, 12, 3 and 6, in that order. Equal parts tile
 * the rim exactly, so neighbouring sectors share an edge and the divider is
 * simply that edge. */
static const rim_span_t RIM_4[] = {
    { 135, 225 }, { 225, 315 }, { 315, 45 }, { 45, 135 },
};
_Static_assert(NK(RIM_4) == 4, "RIM_4 must hold exactly 4 spans");

/* Three thirds from 12 o'clock: 12, 4 and 8, the points of a Mercedes star. */
static const rim_span_t RIM_3[] = {
    { 210, 330 }, { 330, 90 }, { 90, 210 },
};
_Static_assert(NK(RIM_3) == 3, "RIM_3 must hold exactly 3 spans");

/* Two halves from 9 o'clock: the top half first, then the bottom. */
static const rim_span_t RIM_2[] = {
    { 180, 360 }, { 0, 180 },
};
_Static_assert(NK(RIM_2) == 2, "RIM_2 must hold exactly 2 spans");

/* One parameter gets the whole rim. LVGL accepts 0..360 as a full circle
 * explicitly, so this is a supported value and not an accident of wrapping. */
static const rim_span_t RIM_1[] = {
    { 0, 360 },
};
_Static_assert(NK(RIM_1) == 1, "RIM_1 must hold exactly 1 span");

/*
 * Five fifths, as a five-pointed star with a point at twelve: 12, then the two
 * below it and the two above, clockwise — 270, 342, 54, 126 and 198 degrees.
 *
 * The first sector starts at 12 rather than at 9 as the four-quarter layout does,
 * and that is a measurement rather than a preference. A fifth of the rim is 72
 * degrees, so no rotation can put every block clear of the horizontal: sweeping
 * all 36 distinct rotations with the real 112 x 48 panels, only the ones within a
 * few degrees of this one keep all five panels off each other. Pinned at nine
 * o'clock, the two pairs that straddle it overlap by 4.7 x 13.1 px; here they
 * clear, and the worst corner of the five is 156.8 against the three-sector
 * layout's 156.7 — and the block at twelve is where that is spent. The page's title
 * used to be a second thing crowding it: MIX LEVELS was 71 px in the small face, and
 * its line came within 0.2 px of that panel's left edge. Now the title is the single
 * word LEVELS, 67 px in the big face, so nothing on this page is tighter than the
 * layout itself — which leaves the measurement above as the whole reason the star
 * points at twelve rather than at nine.
 *
 * The first knob of a five-sector page lives at twelve o'clock, where the one-, two- and
 * three-sector layouts already put their first knob: LEAD on LEVELS, SCREEN on SYSTEM,
 * VOL on MASTER, DEST on DRONE MOD, SYNC on DELAY, PITCH on PERC and STEPS on PERC SEQ.
 * RIM_2's first sector is the whole top half, centred at twelve, which is where DRONE's
 * WAVE sits.
 */
static const rim_span_t RIM_5[] = {
    { 234, 306 }, { 306, 18 }, { 18, 90 }, { 90, 162 }, { 162, 234 },
};
_Static_assert(NK(RIM_5) == 5, "RIM_5 must hold exactly 5 spans");

/*
 * Six sixtieths, as a six-pointed star with a point at twelve: 12, then 330, 30, 90, 150
 * and 210 degrees — the same star RIM_5 and RIM_3 draw, one point more, so the first sector
 * of a six-sector page is at twelve o'clock exactly as it is on every other page whose count
 * is odd. The first knob of each six-sector page stays where that page has always had it:
 * the LEAD fader of the three send pages, OPTIONS' PATCH (see KNOBS_SYS2) and LEAD EUCLID's
 * STEPS.
 *
 * THE ONLY SIX-SECTOR TABLE, AND EVERY SIX-SECTOR PAGE DRAWS IT. OPTIONS and the three send
 * pages use it without a ring; LEAD EUCLID draws the same star under the sequencer's dot
 * ring. There is no second six-way layout and no turn: the page's main handle is at twelve
 * o'clock wherever six sectors are asked for, and the ring's dots meet the same seats the
 * settings page uses. The drum's figure page is a five now — its ENV lives on PERC — so
 * only the lead's figure page meets this star, and it fits it by its order and by its
 * readouts, not by rotating it. See the note over SEQ_RING_R, which is where that was
 * settled and where the cells are printed.
 *
 * The anchor at twelve is a measurement here too, and this time it is the integer trig
 * rather than the panels that decides it. Sixty degrees a side means the six anchors land on
 * 270, 330, 30, 90, 150 and 210, which are the axes and the diagonals of lv_trigo_sin()'s
 * table: every one of the six is an exact table entry, where RIM_5's five fall between them
 * (270, 342, 54, 126, 198) and are rounded to the pixel. The worst panel corner is 156.5 px,
 * in the same table as the other layouts — it sits in the note over ANCHOR_R — and the words
 * keep 28.2 px: PATCH's value against MORPH's name, the pair that shares the 240 degrees
 * boundary. tools/ring_clearance.py
 * measures all of it in the same arithmetic this file draws with; that file's OPTIONS
 * section is where the six-sector column lives.
 *
 * What six does NOT change is the gap between neighbouring panels: 112 x 48 boxes whose
 * anchors are one radius and sixty degrees apart are tangent, edge to edge — and so are
 * five's, whose nearest pair is already 0.0 px apart. Six is the tighter ring by the corner
 * (156.5 against 156.8) and the same by the gap, and no pair overlaps in either. A macro
 * may be armed on a sector of any page, so the panel geometry is the same question on the
 * figure pages as on the settings ones; the numbers above are all of them, and the block
 * never leaves the circle.
 */
static const rim_span_t RIM_6[] = {
    { 240, 300 }, { 300, 0 }, { 0, 60 }, { 60, 120 }, { 120, 180 }, { 180, 240 },
};
_Static_assert(NK(RIM_6) == 6, "RIM_6 must hold exactly 6 spans");

/* rim_dividers() writes one angle per span into s_divider_pts[DIV_MAX], so the widest
 * rim in the file has to fit that array. */
_Static_assert(NK(RIM_6) <= DIV_MAX, "the widest rim must fit the divider table");

/*
 * The rim for a given number of sectors — every value the instrument can ask for,
 * spelled out.
 *
 * There is no `default:` that quietly hands back one of the tables. That is what the
 * old version did — anything that was not 1, 2, 3 or 5 got the four-way rim, including
 * 4 itself, which is to say the mapping was complete by accident and said so nowhere.
 * A count with no rim now gets an empty one, which every caller clamps against, so a
 * page that ever asks for more sectors than the rim tables describe draws nothing and
 * says so in the log instead of reading past a table.
 */
static rim_t rim_for(int count)
{
    switch (count) {
    case 1:  return RIM_OF(RIM_1);
    case 2:  return RIM_OF(RIM_2);
    case 3:  return RIM_OF(RIM_3);
    case 4:  return RIM_OF(RIM_4);
    case 5:  return RIM_OF(RIM_5);
    case 6:  return RIM_OF(RIM_6);
    default: break;
    }

    return (rim_t){ NULL, 0 };
}

/* How far a span travels, always positive. */
static int32_t rim_sweep(const rim_span_t *s)
{
    int32_t sweep = (int32_t)s->end - (int32_t)s->start;
    if (sweep <= 0) {
        sweep += 360;
    }
    return sweep;
}

/*
 * The point a sector's name and value are centred on, at 96 px from the middle.
 *
 * A full circle has no midpoint, so the single-parameter layout is pinned to the
 * top rather than left to land wherever the arithmetic happens to fall.
 */
static void rim_anchor(const rim_span_t *s, int *x, int *y)
{
    int32_t sweep = rim_sweep(s);
    int32_t mid;

    if (sweep >= 360) {
        mid = 270;
    } else {
        mid = ((int32_t)s->start + sweep / 2) % 360;
    }

    *x = (int)((int32_t)ANCHOR_R * lv_trigo_cos(mid) / 32767);
    *y = (int)((int32_t)ANCHOR_R * lv_trigo_sin(mid) / 32767);
}

/*
 * The angles to draw divider spokes at, written into out[].
 *
 * Because the sectors are equal parts they are also edge to edge, so every
 * divider is exactly a sector boundary and the whole computation is the list of
 * ends. There is no gap to measure and no empty stretch of rim to avoid.
 *
 * The walk is over the rim's own length, so out[] cannot be written past its end —
 * see the RIM_6 assert above, which is what keeps the widest rim inside DIV_MAX.
 */
static int rim_dividers(rim_t rim, int *out)
{
    if (rim.count < 2) {
        return 0;
    }

    for (int i = 0; i < rim.count; i++) {
        out[i] = (int)(rim.spans[i].end % 360);
    }
    return rim.count;
}

/* -------------------------------------------------------------------------- */
/* Pages                                                                      */
/* -------------------------------------------------------------------------- */

/*
 * The order here IS the order of the tiles on the curtain and the order the swipe
 * walks, with the two settings pages at the end excepted: those the swipe steps over
 * rather than landing on, and every other page keeps the neighbours it has here. It is
 * grouped by family on
 * purpose: everything that colours the body, then the voice, then time, then the
 * percussion, then the rack, then the mixers, then the greys. A colour code you
 * have to hunt for is not a code.
 *
 * The arp sits next to the sequencer because it is the same question asked a
 * different way: what does the lead play next. They are the two generators, and
 * they hand the voice back and forth — SPEED at OFF is the sequencer's, anything
 * else is the arp's.
 *
 * The percussion follows them because it answers the same question for a part that
 * is not the lead: its figure runs on the sequencer's clock — two tempos would be
 * two grids that never quite agree — but it keeps its own STEPS and PULSES, so the
 * two patterns are a polyrhythm rather than a copy.
 */
typedef enum {
    PAGE_DRONE = 0,     /* the body */
    PAGE_FILTER,
    PAGE_MOD,
    PAGE_LEAD,          /* the voice */
    PAGE_TONE,
    PAGE_ENV,
    PAGE_SCALE,         /* time */
    PAGE_EUCLID,
    PAGE_ARP,
    PAGE_PERC,          /* the percussion: a part of its own, and the only
                         * family that is not one of the five originals */
    PAGE_PERC_SEQ,
    PAGE_PERC_MIX,      /* микшер дорожек: стоит рядом с перкуссией, потому что это её
                         * часть; плитку он берёт у пресетов, а место на карте у них же */
    PAGE_CHORUS,        /* the rack, in the order they are thought of:
                         * chorus, then delay, then reverb */
    PAGE_DELAY,
    PAGE_VERB,
    PAGE_MASTER,        /* the one control that is not a part of the sound: what
                         * everything is heard through */
    PAGE_MIX,           /* the mixers, cyan: the one family defined by what a
                         * page is FOR rather than by which circuit it is */
    PAGE_SEND_REV,      /* the mixers' other half: what goes to each effect */
    PAGE_SEND_CHR,
    PAGE_SEND_DLY,
    PAGE_PRESET,        /* the store: a list of sounds rather than a set of knobs */
    PAGE_SYS,
    PAGE_SYS2,
    PAGE_COUNT
} page_id_t;

/*
 * The two pages that carry a sequencer figure — and therefore the dot ring and a RESET of
 * their own. This is the only question left to ask: page_rim() answers from the sector count
 * alone, because there is one rim per count now and no figure rim separate from the settings
 * one. Six sectors is RIM_6 for every page that has six of them; the drum's page is a five
 * and draws RIM_5 like any other five. Keep this function and page_has_figure() as the
 * single answer to "does this page draw a figure": the ring, the transport notice and the
 * value ladder all read it, and two answers could disagree.
 */
static bool page_draws_figure(page_id_t id)
{
    return id == PAGE_EUCLID || id == PAGE_PERC_SEQ;
}

typedef struct {
    const char   *sector;    /* label inside the sector */
    synth_param_t param;
} ui_knob_t;

/*
 * What a sector's track shows, if anything.
 *
 * A track belongs to a PARAMETER rather than to a slot, which is what keeps it in step with
 * the layout: the layout editor writes the order of the page's knobs, and the track is
 * placed by the same span the knob's text and touch area get. Reorder a page, flash it, and
 * the dot moves with the knob without anything being told about the move.
 *
 * Only things that MOVE are listed. A cutoff that is not being swept has no dot, and a
 * parameter with a fixed value gets no track at all — an empty decoration teaches nothing.
 */
typedef enum {
    VIZ_NONE = 0,
    VIZ_DRONE_LFO,   /* the drone filter's own sweep, -1..1 */
    VIZ_PAN_LFO,     /* the stereo drift of the drone, -1..1 */
    VIZ_METER,       /* what the part is putting out, drawn as a fill rather than a dot */
    VIZ_DUCK,        /* how far the drum is holding the low end down, drawn the same way */
    VIZ_PERC_MIX,    /* одна дорожка микшера: своё показание на свою ручку */
} viz_kind_t;

typedef struct {
    synth_param_t param;
    uint8_t       kind;
} viz_entry_t;

static const viz_entry_t VIZ[] = {
    { SYNTH_PARAM_CUTOFF,       VIZ_DRONE_LFO },

    /* Where the drift is going rather than how it is set: the page has one thing moving
     * and it belongs on the sector that names the receiver, not on the two knobs that
     * describe the motion. WIDTH keeps its own, on the drone's page, because that is the
     * knob the drift actually reaches. */
    { SYNTH_PARAM_MOD_DEST,     VIZ_PAN_LFO },
{ SYNTH_PARAM_MOD_DEST2,    VIZ_PAN_LFO },
    { SYNTH_PARAM_MOTION_DEPTH, VIZ_PAN_LFO },


    /* The mixers: a fill is the reading, because a level is a quantity rather than a
     * position — the knob already shows where it is set, and the track shows what leaves. */
    /* Микшер дорожек: у каждой ручки свой индикатор, поэтому вид у них свой. */
    { SYNTH_PARAM_PERC_MIX_KICK,  VIZ_PERC_MIX },
    { SYNTH_PARAM_PERC_MIX_SNARE, VIZ_PERC_MIX },
    { SYNTH_PARAM_PERC_MIX_HAT,   VIZ_PERC_MIX },
    { SYNTH_PARAM_PERC_MIX_TOM,   VIZ_PERC_MIX },

    { SYNTH_PARAM_LEAD_LEVEL,   VIZ_METER },
    { SYNTH_PARAM_PERC_LEVEL,   VIZ_METER },
    { SYNTH_PARAM_DRONE_LOW,    VIZ_METER },
    { SYNTH_PARAM_DRONE_MID,    VIZ_METER },
    { SYNTH_PARAM_DRONE_HIGH,   VIZ_METER },
    { SYNTH_PARAM_SEND_LEAD,    VIZ_METER },
    { SYNTH_PARAM_SEND_PERC,    VIZ_METER },
    { SYNTH_PARAM_SEND_LOW,     VIZ_METER },
    { SYNTH_PARAM_SEND_MID,     VIZ_METER },
    { SYNTH_PARAM_SEND_HIGH,    VIZ_METER },
    { SYNTH_PARAM_CHR_SEND_LEAD, VIZ_METER },
    { SYNTH_PARAM_CHR_SEND_PERC, VIZ_METER },
    { SYNTH_PARAM_CHR_SEND_LOW,  VIZ_METER },
    { SYNTH_PARAM_CHR_SEND_MID,  VIZ_METER },
    { SYNTH_PARAM_CHR_SEND_HIGH, VIZ_METER },
    { SYNTH_PARAM_DLY_SEND_LEAD, VIZ_METER },
    { SYNTH_PARAM_DLY_SEND_PERC, VIZ_METER },
    { SYNTH_PARAM_DLY_SEND_LOW,  VIZ_METER },
    { SYNTH_PARAM_DLY_SEND_MID,  VIZ_METER },
    { SYNTH_PARAM_DLY_SEND_HIGH, VIZ_METER },
    { SYNTH_PARAM_MASTER_DUCK,  VIZ_DUCK },
};

/*
 * What a page is made of. There are two, and the ones that are gone went with the
 * pages they belonged to: the orbit view drew the stereo field as three moving
 * tracks, which is the same information the ring already shows in colour, and the
 * status view was a readout rather than a set of controls. The RGB indication itself
 * stays — see ring_orbit(), which is what the pages with no value of their own still
 * fall back to.
 */
typedef enum {
    VIEW_KNOBS = 0,          /* sectors on the rim */
    VIEW_PRESET              /* the stored sounds, as a list */
} view_t;

/*
 * A page has TWO names, because the two places its name is shown have nothing in
 * common except the name.
 *
 * The TITLE is the one in the middle of the dial — the one piece of text that always
 * says where you are — and it is drawn in whichever of the two faces fits the middle
 * column. That column is 80 px wide on a page with four sectors: the blocks' nearest
 * edges are 96 - 112/2 = 40 px either side of the centre. lv_font_anbscreen_20 sets a glyph
 * every 12 px, so six characters is 67 px and seven would be 79 and sit on both
 * blocks; lv_font_anbscreen_14 sets one every 8, so ten fit in 71. Every title below is written
 * to fit that, and the room is spent on saying WHICH PART the page belongs to —
 * DRONE FLTR, LEAD ENV, LEAD EUCLID, PERC SEQ — which is the one thing a page name
 * could not say before. The same string is the log line and the label at the bottom of the curtain,
 * where the circle is 180 px across and there is room for the longer of the two.
 *
 * The TILE LABEL is the word on the curtain's chip, set inside a disc 44 px across:
 * five characters at lv_font_anbscreen_14 is 36 px and six would be 43 against a chord of 43
 * across the glyph band, which is to say touching the rim. So a tile label is three
 * to five, and that is not a compromise on the map but the point of it — a chip is
 * read with its colour, at a glance, and the title is one tap away. See nav_measure()
 * for where the 44 px comes from.
 */
typedef struct {
    const char      *title;      /* full name: the dial centre, and the log */
    const char      *tile_label; /* the word on the curtain's chip */
    const ui_knob_t *knobs;
    int              knob_count;
    view_t           view;
    /*
     * True for the settings pages. One thing follows from it: a page turn never
     * LANDS on one of them, from anywhere — the swipe carousel is the instrument —
     * so setup is reached from the curtain and left by swiping back into it. The
     * ring reads their values like any other page's.
     */
    bool             settings;
    /*
     * Whether this page gets a TILE on the curtain. Every page in the table answers true.
     *
     * It stays a field rather than becoming an assumption because the map is built by asking
     * the question in three separate walks of PAGES[], and a page that must not be offered on
     * the curtain — a readout, say, that the swipe passes through but a tap should not open —
     * answers false here and nowhere else.
     *
     * The field reads positively because that is the question being asked: "does this page
     * have a tile". A negative field would put a double negative in all three walks. The name
     * is the same word as the tile's COLOUR in nav_group_color_t, deliberately: both are about
     * the chip on the curtain and nothing else.
     */
    bool             tile;
    /*
     * Which family of controls the section belongs to — see GROUP_COLOR. The pages
     * are ordered so that a family is contiguous, so this reads as bands of colour
     * on the curtain rather than as confetti.
     */
    uint8_t          group;
} ui_page_t;

/*
 * The drone's own page: six sectors, where it had two before the rework.
 *
 * THE THREE SHAPES FIRST, clockwise from the top and in the order the registers sound —
 * H.OSC, M.OSC, L.OSC. Each is the same six-entry list the part used to have, one per
 * register, and they sit together because they are one decision made three times; a page
 * that put WIDTH between them would read as three unrelated knobs. The names are three
 * letters and a dot rather than HIGH/MID/LOW because a label is drawn on the arc and the
 * dot says "register" in one character where the word would cost four.
 *
 * K.TRCK IS THE FOURTH, next to the shapes because it is about the drone's pitch as well:
 * how far its filter's cutoff follows the note, 0..100 percent. Then WIDTH and FOLLOW on the
 * bottom and the left. WIDTH is how far the panorama and the filter sweep wander, and FOLLOW
 * — SCALE, FULL, CONS — is whether the drone follows the lead at all. FOLLOW is last because
 * it is a decision about the part rather than a colour, and the sector order above is the one
 * the owner asked for: the six seats are H.OSC, M.OSC, L.OSC, K.TRCK, WIDTH, FOLLOW.
 *
 * THE THREE REGISTER LEVELS ARE NOT HERE, and that has not changed. LOW, MID and HIGH are
 * still one fader per register, they still default to the levels the registers were voiced
 * at, and all three at their defaults is still the sound that was tuned by ear. But a level
 * is a balance between parts, and the balance lives on LEVELS with the lead and the
 * percussion, where the numbers are read together. The same handle drawn on two pages was
 * two places to set one number, and the copy here could only disagree with the copy there;
 * the parameter did not move — a preset carries it and the ring still meters it — only its
 * sector did. The rack's MASTER gain used to sit first here for the same reason and left for
 * the mixers long ago.
 *
 * The shapes, K.TRCK and WIDTH belong here rather than on FILTER or MOD because the shapes
 * are what the drone IS, its tracker is what keeps its filter in step with that, and WIDTH is
 * how far it drifts; FOLLOW is the one thing that is none of those, and it is here because it
 * is about this part and only this part.
 *
 * WHAT IT COSTS THE LAYOUT, MEASURED RATHER THAN FELT. The page drew two sectors on RIM_2,
 * five on RIM_5 and draws six on RIM_6. There is no ring of dots on it, so the words have to
 * clear the neighbouring words: tools/ring_clearance.py, which uses the same constants and
 * the same integer trig as this file, measures every pair of boxes. The tightest pair is
 * 42.1 px — H.OSC's value against FOLLOW's name, and FOLLOW's value against H.OSC's name,
 * the two ends of the ring facing each other — and the farthest label corner is 126.4 px,
 * which is 28.6 px inside the rim's drawn inner edge at 155. Both are air, both are published
 * there as numbers this note is checked against, and nothing here is rotated or tilted to buy
 * the room.
 *
 * WHICH KNOB THE PAGE OPENS ON is seed_selection()'s: the first entry, H.OSC. It is the
 * shape of the register the player hears most, and it is the sector WAVE stood on, so the
 * page still opens where it always did.
 */
static const ui_knob_t KNOBS_DRONE[] = {
    { "H.OSC",  SYNTH_PARAM_DRONE_OSC_HIGH },
    { "M.OSC",  SYNTH_PARAM_DRONE_OSC_MID },
    { "L.OSC",  SYNTH_PARAM_DRONE_OSC_LOW },
    { "WIDTH",  SYNTH_PARAM_MOTION_DEPTH },
    { "FOLLOW", SYNTH_PARAM_DRONE_FOLLOW },
};

/*
 * Cutoff in the TOP sector, where LEAD TONE puts it too. The four-sector rim (RIM_4) counts
 * its sectors from 9 o'clock, so the top sector is the SECOND entry of this table and the
 * page therefore begins with RES: the cutoff, which stood on the left, took the top sector,
 * and RES took the left one it left behind. RATE and DEPTH did not move — right and bottom
 * — and the page has as many knobs and as many detents as before, because this is two
 * entries exchanged rather than a new parameter. That the cutoff is still the knob the page
 * is entered on, although it is not the first entry, is said where the selection lives: see
 * seed_selection().
 *
 * The cutoff is the control that decides whether the instrument sounds like a drone or like
 * a machine. RATE is what makes the filter audible as a filter at all — at its designed
 * 0.05 Hz the sweep takes twenty seconds and the ear reads it as a texture rather than as a
 * moving cutoff.
 */
static const ui_knob_t KNOBS_FILTER[] = {
    { "RATE",    SYNTH_PARAM_FILTER_RATE },
    { "CUTOFF",  SYNTH_PARAM_CUTOFF },
    { "RES",     SYNTH_PARAM_RESONANCE },
    { "DEPTH",   SYNTH_PARAM_FILTER_DEPTH },
    { "K.TRCK",  SYNTH_PARAM_DRONE_KTRCK },
    { "MODE",    SYNTH_PARAM_DRONE_FILTER_MODE },
};

/*
 * Named for what they do to the sound rather than after the DSP underneath:
 * "width" and "speed" say more than "motion depth" and "motion rate".
 *
 * SHAPE lives here instead of on a page of its own. It is the waveform of the
 * drone filter's LFO, whose rate and depth sit on the FILTER page next door — but
 * as a control it is one choice about movement, and a whole page holding one list
 * of five was a page the swipe had to cross for nothing.
 */
static const ui_knob_t KNOBS_MOD[] = {
{ "DEST", SYNTH_PARAM_MOD_DEST },
{ "DEST2", SYNTH_PARAM_MOD_DEST2 },
    { "SHAPE", SYNTH_PARAM_LFO_SHAPE },
    { "DEPTH", SYNTH_PARAM_MOD_DEPTH },
    { "SPEED", SYNTH_PARAM_MOTION_RATE },
{ "TRIG", SYNTH_PARAM_MOD_TRIG },
};

/*
 * The layout divides whatever it is given, so the count in this table is the count on the
 * screen.
 *
 * LEVEL IS NOT HERE ANY MORE. The lead's level is the first of the five faders on LEVELS,
 * where it is compared with the percussion and the three registers of the drone instead of
 * being set against nothing; a level that can be reached from two pages is two numbers to
 * keep in step, and the mixer is the one place a balance is read. The parameter is
 * untouched — a preset still carries it, the ring still meters it — only its sector moved.
 *
 * What is left is what the lead is played with: GATE, PORTA, OSC and VOICE. GATE and PORTA
 * have no engine value behind them; the sequencer reads the first at the top of each step, and
 * the glide is read at the moment a note is chosen. They appear here anyway because a control
 * you cannot see is a control you cannot set.
 *
 * VOICE IS THE FOURTH: POLY or MONO, four groups or one. It belongs beside GATE and PORTA
 * for the same reason they do — it is articulation, not tone — and it is the switch that says
 * what GATE and the releases are worth. In POLY a step that arrives while the previous note is
 * still ringing takes another group, so a long release is heard under the next steps; in MONO
 * every note retriggers the same group and the note after it cuts its release. The readout is
 * the word, because two states have nothing to measure, and the knob has one detent between
 * them. See SYNTH_PARAM_LEAD_VOICE and apply_lead_voice().
 *
 * OSC IS THE SHAPE, and it is called OSC rather than WAVE because the word WAVE went away
 * from every knob on the instrument: the six entries are not all waveforms — SPR is a detune
 * and NSE is a source — and OSC is the word that covers all six. The parameter, its list and
 * its stored byte did not change; only the label.
 *
 * TEMPO used to sit here and has moved to the transport screen, where the wheel is the one
 * control on the instrument with nothing to turn. It is the same parameter it always was,
 * so a synced delay still follows it and a preset still stores it.
 *
 * PORTA belongs on this page rather than with the envelope: it is articulation, and
 * articulation is something you change while playing. The page is four sectors — how long,
 * how it moves between notes, what the lead is made of, and how many voices it has — because
 * the level went to the mixers and the tempo to the transport screen, and neither left a
 * handle to sit here doing nothing. Four sectors is RIM_4, the quarters from nine o'clock, so
 * GATE sits on the left, PORTA at the top, OSC on the right and VOICE at the bottom.
 *
 * WHAT IT COSTS THE LAYOUT, MEASURED. Four sectors on RIM_4 is the roomiest arrangement on the
 * instrument: tools/ring_clearance.py measures the tightest pair of words at 75.8 px and the
 * farthest label corner at 117.5 px, which is 37.5 px inside the drawn inner edge at 155.
 * The page has been three sectors and four, and both times the four-sector arrangement was
 * the roomier one: six words on a quarter each leave more between neighbours than five on a
 * fifth. VOICE took the seat K.TRCK left when the tracker moved to the TONE page, and the
 * numbers did not move — a five-letter name and a four-letter value are no wider than the
 * six and four that stood there.
 */
static const ui_knob_t KNOBS_LEAD[] = {
    { "GATE",   SYNTH_PARAM_SEQ_GATE },
    { "PORTA",  SYNTH_PARAM_LEAD_PORTA },
    { "OSC",    SYNTH_PARAM_LEAD_WAVE },
    { "VOICE",  SYNTH_PARAM_LEAD_VOICE },
};

/*
 * The lead's filter and the envelope that opens it, on two pages rather than one.
 *
 * Seven parameters do not fit four sectors, and the split is the one the
 * instrument already makes everywhere else: TONE is what you play with, ENV is
 * what you find once and leave. CUTOFF, resonance and the envelope amount are
 * performance controls — the amount above all, since it is the one knob that
 * decides whether the line is plucked or bowed. The four stages are a shape, and
 * a shape is set by ear in one sitting.
 *
 * Named for what they do to the sound rather than after the DSP underneath, the
 * same rule the MOD page follows. "TONE" says more than "lead low-pass with
 * envelope", and there is already a page called FILTER holding the drone's slow
 * sweep — two pages named after the same circuit would be two pages nobody could
 * tell apart from the map.
 */
static const ui_knob_t KNOBS_TONE[] = {
    { "CUTOFF", SYNTH_PARAM_LEAD_CUTOFF },
    { "RES",    SYNTH_PARAM_LEAD_RESO },
    { "ENV",    SYNTH_PARAM_LEAD_ENV },
    { "SHAPE",  SYNTH_PARAM_LEAD_FENV_SHAPE },
    { "K.TRCK", SYNTH_PARAM_LEAD_KTRCK },
    { "MODE",   SYNTH_PARAM_LEAD_FILTER_MODE },
};

/*
 * Four sectors, and the first time the four-sector layout has been an exact fit
 * for anything: an ADSR is four controls in a fixed order, and a quarter each is
 * what a quarter each is for.
 */
static const ui_knob_t KNOBS_ENV[] = {
    { "ATTACK",   SYNTH_PARAM_LEAD_ATTACK },
    { "DECAY",    SYNTH_PARAM_LEAD_DECAY },
    { "RELEASE",  SYNTH_PARAM_LEAD_RELEASE },
    { "SUSTAIN",  SYNTH_PARAM_LEAD_SUSTAIN },
};

/*
 * The device's own settings, on two pages.
 *
 * They appear in the navigator like any other section but are deliberately NOT
 * in the swipe carousel: turning a page is a performance gesture, and a section
 * that can be reached by accident mid-phrase is a section that will be. Reaching
 * them deliberately — swipe down, tap the tile — also matches what they are,
 * which is setup rather than playing. Leaving is the same door, and it is the only
 * one: a swipe from a settings page turns to the instrument's next page rather
 * than to the other settings page, so setup is never one gesture from the things
 * being played in either direction.
 *
 * Four and three, then five and four, then five and six: MIC joined SCREEN, RING, RING FX
 * and RESET on the first page, and the microphone is the way the instrument LISTENS, which is
 * the same kind of fact about the device: a property of the room it is standing in rather
 * than of the sound it is making. RESET has since left again — see below — so the first page
 * holds SCREEN, RING, RING FX and MIC today. The second page is then what it keeps —
 * the sound, how long new values take to arrive, whether a random draw may move the delay
 * time, how hard the weak half of an accented hit lands — plus, last, the switch that decides
 * whether the instrument is a USB MIDI device at all.
 *
 * RESET LEFT THE HAPTIC SLOT AND THEN LEFT THIS PAGE, and the slot is still EMPTY. It was the
 * realignment period of the step generators, it replaced the vibration motor when that was
 * removed, and the owner's decision is that a realignment period belongs to the sound rather
 * than to the device: it is a patch parameter, so a preset carries its own and changing the
 * preset changes it. It has since become TWO parameters, one per sequencer, and each one sits
 * on the page that owns its figure — SYNTH_PARAM_SEQ_RESET on LEAD EUCLID,
 * SYNTH_PARAM_PERC_RESET on PERC SEQ — so this page has nothing to do with either period.
 * Nothing took the slot back and nothing will: the motor is not returning, and the first page
 * therefore has FOUR sectors (SCREEN, RING, RING FX and MIC), where it briefly had six. The
 * freed sectors are the point rather than a gap to fill.
 *
 * THE FIFTH WENT WITH THE DRIVE. DRIVE was the position of the drive stage, BEFORE FX or
 * AFTER FX, and the stage itself is gone — see KNOBS_MASTER — so the page is back on RIM_4, the
 * four equal quarters from nine o'clock that ENV, VERB, GEN and ARP already use. The device
 * settings are then exactly the four facts about the room: how bright the screen is, how bright
 * the ring is, what the ring does, and how hard the microphone listens.
 *
 * WEAK VEL was the fourth sector of that second page and MIDI IN is the fifth, and both were
 * appended for the same reason: a setting is a fact about the device, so it goes at the end of
 * the page's list and no entry above it moves. WEAK VEL is the velocity a hit the accent does
 * not mark is struck at (see SYNTH_PARAM_SET_WEAKVEL), which is a property of how the
 * instrument is played rather than of the sound in a slot — the same distinction that keeps it
 * off PERC SEQ, next to the figure that marks the onsets: the figure is part of the rhythm the
 * player sets up per patch, and how hard the weak half of it lands is a device-wide taste.
 *
 * FIVE SECTORS, and the fifth is the note input: MIDI IN is the setting that makes the
 * instrument a USB MIDI device, appended after WEAK VEL so the four entries above keep their
 * order and their values — see SYNTH_PARAM_SET_MIDIIN. It is a setting twice over: the write
 * goes to app_settings under its own key, and its effect belongs to another component
 * (midi_in_set_enabled(), see apply_setting() below), which is why it is on this page rather
 * than anywhere near the sound. Its two positions do not make it a button: the encoder moves
 * it OFF/ON like every other entry on this page, because a tap here would be one control on
 * the instrument reading a gesture that no other control reads.
 *
 * SIX SECTORS, and the sixth is the wave morph time: MORPH is how long the engine takes to
 * move a voice from one waveform to another — the crossfade in setWaveSmooth(), which is
 * what keeps a change of WAVE from stepping the shape and clicking. It belongs on this page
 * for the same reason as WEAK VEL: the sound it governs is not in the patch. A preset does
 * not carry it, the random draw does not move it, and the same milliseconds apply to every
 * patch; what it is instead is a device-wide answer to "how would you like a shape change to
 * arrive", which is a taste rather than a parameter of a sound. The engine's own list is
 * eleven values — OFF, then 5, 10, 15, 20, 25, 30, 40, 60, 80 and 100 ms, see
 * SYNTH_PARAM_SET_WAVEMORPH — and OFF is the old behaviour exactly: the shape changes in one
 * sample, as every list on this instrument does. The factory value is 25 MS. It is a
 * setting and not a patch parameter, so it writes to app_settings under APP_SET_WAVE_MORPH
 * and travels through SETTINGS_MAP like the two above it. Appended, as they were, so that
 * nothing on the page moves for it.
 *
 * SIX SECTORS MOVES EVERY SECTOR OF THAT SECOND PAGE, which is the price of the count and
 * not an accident of the table: RIM_3 put PATCH at twelve o'clock, SLIDE low right and RND
 * DEL low left; RIM_4 put the same three at nine, twelve and three with WEAK VEL at six;
 * RIM_5 is the five-pointed star — twelve, then 342, 54, 126 and 198 degrees — which both
 * figure pages drew before they were sixes; the drum's is a five again now that its ENV
 * lives on PERC, and the lead's is a six. RIM_6 keeps that star and gives it a sixth point —
 * twelve, then 330, 30, 90, 150 and 210, every one of them an exact entry in
 * lv_trigo_sin()'s table. The entries keep their order and their values and only the anchors
 * move, because the rim belongs to the page, and this is the one six-sector rim in the file:
 * OPTIONS, the three send pages and LEAD EUCLID draw it, unrotated, as the note over
 * SEQ_RING_R explains.
 *
 * AND IT IS MEASURED RATHER THAN EYEBALLED, because this page draws no ring of dots to bind
 * on while its labels are the longest words on the instrument. tools/ring_clearance.py
 * sweeps every name and value box of the six sectors against every other, in the same
 * integer trig this file lays them out with, and against the rim itself:
 *
 *   sector    anchor      name       value     air to its nearest neighbour
 *   PATCH     (0,-96)     "PATCH"    "RANDOM"  28.2 px, MORPH's name
 *   SLIDE     (83,-48)    "SLIDE"    "0.5 S"   30.0 px, PATCH's value
 *   RND DEL   (83,48)     "RND DEL"  "OFF"     37.3 px, PATCH's value
 *   WEAK VEL  (0,96)      "WEAK VEL" "127"     36.4 px, PATCH's value
 *   MIDI IN   (-83,48)    "MIDI IN"  "OFF"     36.4 px, RND DEL's value
 *   MORPH     (-83,-48)   "MORPH"    "100 MS"  28.2 px, PATCH's value
 *
 * The tightest pair of words is 28.2 px — PATCH's "RANDOM" at twelve o'clock against
 * MORPH's name a sector anticlockwise of it, sharing the 240 degrees boundary, and MORPH's
 * "100 MS" against PATCH's value on the other side — and it is the closest this page has
 * ever put two words: RIM_5's tightest is 43.2 and RIM_4's 66.7. 28 px is still air, and
 * it is more than the two figure pages bind on, where the tightest cell is PULSES' 7.7 px
 * against the dot ring. The
 * farthest a label box reaches from the middle is 123.0 px, against the rim's ink at 155:
 * 32.0 px of air, which is more than RIM_5's 28.7. The panel an armed sector draws behind
 * those words is a different question and a pre-existing one; the six-sector corner is
 * 156.5 px, between RIM_5's 156.8 and RIM_4's 153.9, and the gap between neighbouring
 * panels is the 0.0 px RIM_5 already has — five's nearest pair is edge to edge too, so six
 * takes nothing away that five had left. This page never draws a panel: only a macro fills
 * one, and no entry here is in a macro. Nothing here is a new geometry: the fonts,
 * the 96 px anchor and the ±11/±12 readout offsets are unchanged, which is exactly why the
 * numbers above had to be taken rather than assumed.
 *
 * RING FX is the ring's effect, which is what SYNTH_PARAM_SET_RINGMODE is; it was
 * labelled MODE, four characters naming the mechanism rather than what it does.
 * Seven characters in the small face is 54 px of ink in a 112 px panel — exactly
 * what RELEASE and SUSTAIN already take on the ENV page, and what RND DEL takes on
 * the other settings page. WEAK VEL is the first eight-character name on a rim and so
 * the widest label on the instrument: 65 px in the small face, which leaves 23 px of the
 * panel on either side of it, and it is not the pair the layout binds on — what binds there
 * is the pair of neighbouring words, and with six sectors the tightest of those is PATCH's
 * value against MORPH's at 28.2 px, not WEAK VEL's name. The note over SEQ_RING_R is why that
 * can be said so plainly: the clearance that
 * mattered when an eight-character label touched a dot was on the two pages that draw the
 * figure's ring, and OPTIONS is not one of them.
 *
 * ONE DETENT PER WHOLE VELOCITY, and never accelerated: the setting is a list of 128 — the
 * engine's own range, 0..127 — so proxy_load() sets the arc's own range to 0..127 and the
 * knob moves the number by one on every click. That is the same reading of a list the
 * preset page takes of its 128 rows, and the direction is the one a person turning a
 * velocity knob wants: precise everywhere, and no click that overshoots. The whole of it
 * is 127 detents, which is a lot of wrist and is stated rather than hidden — see
 * SYNTH_PARAM_SET_WEAKVEL for the continuous alternative that was measured and rejected.
 */
static const ui_knob_t KNOBS_SYS[] = {
    { "SCREEN",  SYNTH_PARAM_SET_SCREEN },
    { "RING",    SYNTH_PARAM_SET_RING },
    { "RING FX", SYNTH_PARAM_SET_RINGMODE },
    { "MIC",     SYNTH_PARAM_SET_MIC     },
};

static const ui_knob_t KNOBS_SYS2[] = {
    { "PATCH",    SYNTH_PARAM_SET_PATCH    },
    { "SLIDE",    SYNTH_PARAM_SET_SLIDE    },
    { "RND DEL",  SYNTH_PARAM_SET_RNDDELAY },
    { "WEAK VEL", SYNTH_PARAM_SET_WEAKVEL  },
    { "MIDI IN",  SYNTH_PARAM_SET_MIDIIN   },
    { "MORPH",    SYNTH_PARAM_SET_WAVEMORPH },
};

/*
 * The effects, laid out in the order the rack runs them.
 *
 * DELAY takes five sectors. Four of them are one effect's TIME: SYNC picks one of twelve
 * divisions of the beat, and TIME is what the delay does when SYNC is FREE, so whichever is
 * in force the TIME readout shows the delay that is actually being heard — clamped to the
 * four seconds the effect's line holds, because a synced 1/1 below 60 bpm asks for longer
 * than that — and the knob never lies about the tempo's decision. The fifth is not an
 * amount but a BEHAVIOUR, and it is last because it arrived last: MODE says how a change of
 * that time arrives, TAPE — the pointer braking, and the default — or XFADE, the old tap
 * crossed out over thirty milliseconds. See SYNTH_PARAM_DELAY_TIMEMODE.
 *
 * The chorus takes three: it has no time of its own to argue about. The reverb takes
 * four — ALGO for the mode, then the room (SIZE, DAMP) and the amount (MIX); how much of
 * each part is IN the room is a mixer's question rather than a reverb's, so those four
 * controls live with the levels they belong beside, on SENDS and DRONE SENDS.
 */
static const ui_knob_t KNOBS_DELAY[] = {
    { "MIX",   SYNTH_PARAM_DELAY_MIX },
    { "FDBK",  SYNTH_PARAM_DELAY_FEEDBACK },
    { "TIME",  SYNTH_PARAM_DELAY_TIME },
    { "SYNC",  SYNTH_PARAM_DELAY_SYNC },
    { "MODE",  SYNTH_PARAM_DELAY_TIMEMODE },
};

static const ui_knob_t KNOBS_CHORUS[] = {
    { "MIX",   SYNTH_PARAM_CHORUS_MIX },
    { "RATE",  SYNTH_PARAM_CHORUS_RATE },
    { "DEPTH", SYNTH_PARAM_CHORUS_DEPTH },
};

static const ui_knob_t KNOBS_VERB[] = {
    { "ALGO",  SYNTH_PARAM_VERB_MODE },
    { "MIX",   SYNTH_PARAM_VERB_MIX },
    { "SIZE",  SYNTH_PARAM_VERB_SIZE },
    { "DAMP",  SYNTH_PARAM_VERB_DAMP },
};

/*
 * THE MIXERS. Three pages, and every control on them is the only place its parameter is
 * drawn: the five part levels are here, and so are the sends. The interface still resolves
 * a control by PARAMETER ID and never by position — synth_app_get_param() reads one table
 * entry, s_macro[] is indexed by parameter, and a page change re-reads every value from
 * synth_app rather than trusting what was last on screen — so a control can move between
 * pages without carrying a copy of its state. What the mixers no longer do is use that to
 * show one number in two places.
 *
 * Three pages because a mix is three questions, and they are asked in this order.
 *
 * LEVELS is how loud the things that are always sounding are against each other: the
 * percussion, the drone's three registers and the lead's own level. A balance is a
 * decision about a whole picture, so all of it belongs on one page; when the lead's level
 * had a page of its own, taking that decision meant walking a swipe back and forth to
 * compare two numbers that only mean something together.
 *
 * MASTER used to be the fifth knob here. It has a section of its own now, one swipe
 * earlier, because it is the one control that is not a balance between parts: it is
 * what everything is heard through, and the transport in the curtain gates exactly it.
 * It carries two sectors rather than one — the output level and the master bus
 * compressor — so its rim is RIM_2.
 *
 * Its place in the page order is deliberate: MASTER sits between VERB and LEVELS, so a
 * swipe from the rack into the mixers passes through the master on the way in. That
 * breaks the rule the rest of the table keeps — a family is contiguous, and this page
 * belongs to the mixer family — without breaking anything that depends on it, because
 * the mixer's band is still unbroken: MASTER is simply its first page, one step later
 * than the pink rack ends.
 *
 * The percussion's LEVEL is here and only here: it left PERC, where the rest of the drum is
 * built, because a part's level is what a mixer sets and a balance is read as a whole. The
 * two pages used to differ on purpose — PITCH and DECAY there against the other parts'
 * levels here — and now the drum page simply no longer answers the level question.
 *
 * SENDS is WHERE THE PARTS GO: LEAD and PERC are the two parts with a reverb send of
 * their own. The microphone's used to be the third and is gone — see the note over
 * KNOBS_SEND_REV. Four would need a fourth parameter that does not exist.
 *
 * DRONE SENDS is the drone's three sends, together for the reason they are sends at
 * all: they hang off a bus rather than sitting in the chain, so it is one room with
 * three different amounts of it, and taking the low register out of the room without
 * the mid and the high takes the voice apart. The low one is the driest of the three,
 * which is the wrong way round only if what you wanted was a cathedral.
 *
 * There used to be a SEND page holding all four sends. It went because the split by
 * WHICH PART OWNS THEM is the split that matches how they are used — the drone's
 * three set against each other at one end, the lead and the drum each against the
 * levels of the rest at the other — and nothing was lost with it: the four
 * SYNTH_PARAM_SEND_* parameters are the same parameters. The microphone's send was
 * appended after all of it, so the old four keep the places they had.
 */
/*
 * THREE, and the two that left are the drive.
 *
 * The drive was two knobs — how hard, and with which shape — and it is out of the
 * instrument: the owner's decision, made after living with it, and it takes both the stage in
 * the rack and this page's pair with it. What remains is the part of MASTER that was never
 * optional: the output level, the compressor everything is heard through, and the duck that
 * lets the drum push the drone's low end away. Three sectors put the layout on RIM_3, the same
 * star the LEAD and CHORUS pages use, with VOL at twelve o'clock where the first knob of a
 * three-sector page belongs.
 *
 * The parameters themselves are NOT deleted. They keep their slots in the enum, because a
 * parameter is an index into every stored preset and into the patch blob: taking one out of
 * the middle would give every value after it to a different control, and a stored sound would
 * come back as a different instrument. DRIVE AMOUNT and DRIVE ALGO are dead slots now, their
 * appliers do nothing, and nothing offers them — the same arrangement the drum's PITCH, QUANT
 * and the rest already have.
 */
static const ui_knob_t KNOBS_MASTER[] = {
    { "VOL",  SYNTH_PARAM_LEVEL },
    { "COMP", SYNTH_PARAM_MASTER_COMP },
    { "DUCK", SYNTH_PARAM_MASTER_DUCK },
    { "SRC",  SYNTH_PARAM_MASTER_DUCK_SRC },
    { "REL",  SYNTH_PARAM_MASTER_DUCK_REL },
};

static const ui_knob_t KNOBS_MIX[] = {
    { "LEAD",   SYNTH_PARAM_LEAD_LEVEL },
    { "PERC",   SYNTH_PARAM_PERC_LEVEL },
    { "LOW",    SYNTH_PARAM_DRONE_LOW },
    { "MID",    SYNTH_PARAM_DRONE_MID },
    { "HIGH",   SYNTH_PARAM_DRONE_HIGH },
};

/*
 * The three SENDS pages: one per effect, FIVE parts each, in the same order on all three —
 * LEAD, PERC, LOW, MID, HIGH. Three pages rather than one with fifteen sectors, because a page
 * moves one effect's five knobs at a time and fifteen would be three pages' worth of meaning
 * collapsed into five sectors of nothing.
 *
 * The parts keep their places across the pages on purpose: after the first one, the hand knows
 * where the lead's send is and finds it on the chorus and the delay without reading.
 *
 * THE SIXTH WAS THE MICROPHONE, and it is gone: the owner took the input out of the effects
 * entirely and kept it as a modulation source only, which is where it was always the more
 * interesting of the two jobs — a room's movement moving the filter rather than a room's noise
 * going into the reverb. The three MIC sends are dead slots in the enum (see
 * SYNTH_PARAM_SEND_MIC) and the AUX bus they fed carries nothing. Five sectors put all three
 * pages on RIM_5, whose star is the one PERC SEQ and the SCALE page draw.
 */
static const ui_knob_t KNOBS_SEND_REV[] = {
    { "LEAD",  SYNTH_PARAM_SEND_LEAD },
    { "PERC",  SYNTH_PARAM_SEND_PERC },
    { "LOW",   SYNTH_PARAM_SEND_LOW },
    { "MID",   SYNTH_PARAM_SEND_MID },
    { "HIGH",  SYNTH_PARAM_SEND_HIGH },
};

static const ui_knob_t KNOBS_SEND_CHR[] = {
    { "LEAD",  SYNTH_PARAM_CHR_SEND_LEAD },
    { "PERC",  SYNTH_PARAM_CHR_SEND_PERC },
    { "LOW",   SYNTH_PARAM_CHR_SEND_LOW },
    { "MID",   SYNTH_PARAM_CHR_SEND_MID },
    { "HIGH",  SYNTH_PARAM_CHR_SEND_HIGH },
};

static const ui_knob_t KNOBS_SEND_DLY[] = {
    { "LEAD",  SYNTH_PARAM_DLY_SEND_LEAD },
    { "PERC",  SYNTH_PARAM_DLY_SEND_PERC },
    { "LOW",   SYNTH_PARAM_DLY_SEND_LOW },
    { "MID",   SYNTH_PARAM_DLY_SEND_MID },
    { "HIGH",  SYNTH_PARAM_DLY_SEND_HIGH },
};

/*
 * FIVE SECTORS, and the page is called SCALE — and the tonic is two of them.
 *
 * SCALE and the tonic are what matter most. A mode changes the intervals, and that is the
 * largest single difference one setting can make to a melody — bigger than anything the
 * texture controls can do. DENSITY is what turns a stream of notes into a phrase, and OCTAVE
 * decides whether the line stays in one register or uses two.
 *
 * NOTE AND OCT ARE THE TONIC, split. ROOT was ONE knob across eighty-five semitones, and that
 * was a sweep: finding D minor meant eight detents of guessing between the note you wanted and
 * the note you landed on, with the readout as the only witness. The two things a player aims at
 * are the note it is on and the octave it is in, so they are two sectors — twelve positions and
 * seven — and the pair is four or five clicks from anywhere. The pair sits together after
 * SCALE because the note is the one most often moved.
 *
 * NOTE is SYNTH_PARAM_ROOT, keeping its name in code and losing it on the panel: the page prints
 * the word the sector holds. The word OCTAVE belongs to the register probability further round
 * the rim, which is a different question — how freely the line takes the far register — and two
 * words that differ by three letters are a hazard, so the readouts keep them apart: "A" against
 * "3" against "50%", and the first two are the tonic.
 *
 * RESET IS NOT HERE ANY MORE. It left for the two pages that own a figure — the lead's gesture
 * on LEAD EUCLID and the drum's on PERC SEQ — so this page kept the sectors it had before it
 * arrived, and the octave took the fifth seat the reset gave back. Two gestures with two periods
 * need two seats, and a page that owns no figure is the wrong place for either. The periods a
 * preset carries are still one per part: see SYNTH_PARAM_SEQ_RESET and SYNTH_PARAM_PERC_RESET.
 *
 * WHY THE PAGE IS CALLED SCALE. SCALE is the first sector, it is the control the page is entered
 * on, and it is the only one of the five whose name is also the name of the page's whole question.
 * The previous name, LEAD GEN, spent the title on the family ("LEAD") and the vague half ("GEN")
 * while the knob that does the work went unnamed in it. As a one-word title it also fits the
 * larger face in ONE line: "SCALE" measures 58 px at letter space 0, against the 80 px the sector
 * blocks leave between them — 22 px of air — where "LEAD SCL" is 87 px and "LEAD SCALE" is 110 px
 * and both would have to split into two lines. The budget is TITLE_BIG_CHARS (7), so five letters
 * keep the larger face; the chip on the map is SCL, because three characters is what a tile holds
 * (GEN was three too).
 *
 * THE MEASUREMENTS, because this page draws NO ring of dots — page_has_figure() answers for
 * EUCLID and PERC SEQ and for nothing else — so what has to clear is the words against the words,
 * not against a dot. tools/ring_clearance.py's SCALE section measures the five seats of RIM_5
 * with the faces in components/synth_ui/src/fonts, and the numbers here are what it prints:
 *
 *   SCALE   at 270: name 41 px, value 108 px ("DIMINISHED"; "MIXOLYDIAN" is the same width),
 *           33.8 px of air to OCTAVE's boxes — the page's tightest pair;
 *   NOTE    at 342: name 34 px, value 24 px ("C#"), 37.7 px;
 *   OCT     at  54: name 26 px, value 10 px ("7"), 70.0 px;
 *   DENSITY at 126: name 58 px, value 39 px ("100%"), 70.0 px;
 *   OCTAVE  at 198: name 52 px, value 32 px ("50%"), 33.8 px to SCALE's.
 *
 * The two readouts the split added are the shortest words on the rim — "C#" is four glyph
 * advances, "7" is one — so what the fifth sector costs this page is geometry and not words: the
 * tightest pair went from 63.1 px to 33.8 px and the farthest corner came IN, from 151.2 px to
 * 125.4 px, because RIM_5 turns the star and no label points straight down any more. Against the
 * rim's drawn inner edge at 155 px that is 29.6 px of air, and the panel a macro fills is RIM_5's
 * own corner, in the table over ANCHOR_R.
 */
static const ui_knob_t KNOBS_GEN[] = {
    { "SCALE",   SYNTH_PARAM_SCALE },
    { "NOTE",    SYNTH_PARAM_ROOT },
    { "OCT",     SYNTH_PARAM_ROOT_OCT },
    { "DENSITY", SYNTH_PARAM_DENSITY },
    { "OCTAVE",  SYNTH_PARAM_OCTAVE },
};

/*
 * SIX SECTORS. STEPS and PULSES are the n and k of the Euclidean pattern, and
 * they are the two that decide whether this sounds like a metronome or like a
 * rhythm: four out of four is every beat, three out of eight is the tresillo.
 *
 * ROTATE moves the figure against the beat, and SCATTER is what stops it being a
 * loop — a fixed pattern repeats exactly, and a note that wanders a few percent
 * off its grid line never quite does.
 *
 * ACCENT is FOURTH and it is the LEAD'S OWN accent figure. The drum has a separate one,
 * SYNTH_PARAM_PERC_ACCENT, and the two are independent on purpose: the drum wants its own
 * emphasis and the lead wants its own, and one shared figure moved both hits. Both pages
 * print the same eight panel forms from ACCENT_NAME, so the sector reads the same way on
 * each of them, but each shows its own figure. It is the figure's velocity that makes it a
 * contrast rather than a second rhythm — see SYNTH_PARAM_PERC_ACCENT — and it is applied
 * here to the level each lead voice is opened at, once per note. It sits after ROTATE,
 * the seat it took when RESET arrived, and its readout is one of the panel forms in
 * ACCENT_NAME: the widest of them is 46 px, so the 90-degree seat clears it by 15.8 px.
 * The long "QUARTER" would still clear this seat (11.0), but the drum's page puts its
 * ACCENT in the same fourth seat at 126 degrees, where the same word would overlap the ring
 * by 3.5; one table of panel forms prints on both pages, so both read short. See the note
 * over SEQ_RING_R.
 *
 * RESET IS THE LAST SECTOR, and it is the LEAD'S reset: after that many steps of THIS
 * grid the lead's phrase begins again on its first step, and the arpeggiator — which plays
 * instead of the lead and keeps its own origin — is put back with it. Its period is a patch
 * parameter, and the percussion has a separate one on the page next door; neither gesture
 * can move the other part, by construction. See SYNTH_PARAM_SEQ_RESET and
 * SYNTH_PARAM_PERC_RESET.
 *
 * WHY THIS ORDER: STEPS, PULSES, ROTATE, ACCENT, SCATTER, RESET, clockwise from twelve
 * o'clock on 270, 330, 30, 90, 150 and 210 degrees — the order this page took when RESET
 * arrived. ACCENT had been last, where "QUARTER" could not sit, and moved to the fourth;
 * SCATTER took the fifth and RESET the sixth. Measured against the dot ring:
 * STEPS keeps 22.0 px of air, PULSES 7.7 (its name against the ring — the page's tightest
 * cell), ROTATE 16.6, ACCENT 15.8, SCATTER 12.4 and RESET 11.3. The drum's page is these
 * five controls without SCATTER, on RIM_5; the whole sweep of both layouts is in the note
 * above SEQ_RING_R, which is where the order of both tables was settled. The star this page
 * sits on is RIM_6, the same one the settings pages draw.
 */
static const ui_knob_t KNOBS_EUCLID[] = {
    { "STEPS",   SYNTH_PARAM_SEQ_STEPS },
    { "PULSES",  SYNTH_PARAM_SEQ_PULSES },
    { "ROTATE",  SYNTH_PARAM_SEQ_ROTATE },
    { "ACCENT",  SYNTH_PARAM_SEQ_ACCENT },
    { "SCATTER", SYNTH_PARAM_SEQ_SCATTER },
    { "RESET",   SYNTH_PARAM_SEQ_RESET },
};

/*
 * The arpeggiator, and the one page whose controls are all questions about shape
 * rather than about sound.
 *
 * Five sectors, and four of them change what the figure IS: SPEED how fast it walks,
 * DIR which way, LEN how many notes it takes to cross the range and RANGE how far
 * that crossing goes. LEN and RANGE are deliberately separate — three notes across
 * two octaves and eight notes across the same two are the same interval span and a
 * completely different line — and SPEED carries OFF at the bottom, which is how the
 * Euclidean sequencer gets its voice back.
 *
 * ACCENT IS THE FIFTH, and it is the arp's OWN figure. There are three figures on the
 * instrument now — the lead's, the drum's and this one — and that is one more than the two
 * the split into parts needed, so the argument has to be made. The arp borrowed the lead's
 * while it played, on the reading that a part has one figure; but the arp's notes come from a
 * HELD CHORD and its accents land on the arp's own step of the bar, and the knob that decided
 * them sat two tiles away on a page about the lead's Euclidean grid. The owner asked for the
 * sector, and the sector is right: what the arp does with an accent is a question about the
 * arp. The rule behind the eight figures is the same one on all three pages, and one figure
 * still never moves another part. OFF is the factory position: every step at the key's own
 * velocity, which is what the instrument did before this existed.
 *
 * The fifth sector moved this page from RIM_4 to RIM_5, so the star turns: DIR at twelve,
 * SPEED at 342, LEN at 54, RANGE at 126 and ACCENT at 198 degrees. Its readout is one of the
 * panel forms in ACCENT_NAME and the widest of them is 46 px, so the seat at 198 takes it with
 * more air than the three-eighths of the rim around it.
 *
 * Note that DENSITY is not here. That is the point of the difference between the
 * two generators: the sequencer is asked to be sparse or busy, and an arpeggiator
 * that skipped notes at random would stop being an arpeggiator.
 */
static const ui_knob_t KNOBS_ARP[] = {
    { "DIR",    SYNTH_PARAM_ARP_DIR },
    { "SPEED",  SYNTH_PARAM_ARP_SPEED },
    { "LEN",    SYNTH_PARAM_ARP_LEN },
    { "RANGE",  SYNTH_PARAM_ARP_RANGE },
    { "ACCENT", SYNTH_PARAM_ARP_ACCENT },
};

/*
 * The percussion, which is a part of the instrument in its own right: it is not the
 * body, which never stops; not the voice, which plays a line; and not a generator
 * deciding which notes the line uses.
 *
 * Five sectors, and the split is the one an analogue drum voice makes. PITCH is the
 * band-pass centre, which is the note of the hit; QUANT decides whether that pitch snaps to
 * the current scale; ENV is how far the centre falls over the hit; DECAY is the gate, which
 * is how long the hit lasts; BODY is the balance between the noise the hit is made of and a
 * tone at that same centre.
 *
 * LEVEL IS NOT HERE ANY MORE. The part's own gain is one of the five faders on LEVELS,
 * beside the lead and the three drone registers, where a balance is read as a whole; the
 * same handle on two pages was two numbers to keep in step. The parameter is untouched — a
 * preset still carries it, the ring still meters it — only its sector moved. The other copy
 * to go in this change was ENV's: it was shown on PERC SEQ as well and now lives only here,
 * so this page is the one place the drum's articulation is set.
 *
 * With no carried control left there is no row rule to obey, and the order is the voice's
 * own: the hit's pitch, how that pitch is quantised, its fall, its length, its body. The
 * page is entered on PITCH, which is its first entry; see seed_selection().
 *
 * PITCH and DECAY are the two that decide whether the voice is a tom or a hat — and a
 * short decay at any pitch is a click, which is a corner of the range worth knowing about
 * rather than avoiding.
 *
 * RES used to have the last sector. It is a fixed value now, and it stayed in the
 * parameter list rather than being deleted, because a parameter's number is what a
 * saved patch and a preset are indexed by.
 */
static const ui_knob_t KNOBS_PERC[] = {
    { "KIT",    SYNTH_PARAM_PERC_KIT },
    { "TONE",   SYNTH_PARAM_PERC_TONE },
    { "DECAY",  SYNTH_PARAM_PERC_LENGTH },
    { "PUNCH",  SYNTH_PARAM_PERC_BODY_TRIM },
    { "TIMBRE", SYNTH_PARAM_PERC_TIMBRE },
    { "TUNE",   SYNTH_PARAM_PERC_TUNE },
};

/*
 * The figure the percussion plays, and the controls that shape how it is played.
 *
 * STEPS and PULSES are the n and k of its Euclidean pattern and ROTATE moves the
 * figure against the beat, exactly as on the sequencer next door — but these are the
 * percussion's OWN numbers, so what it plays is a polyrhythm against the lead rather
 * than a copy of it. One clock, two grids.
 *
 * ENV USED TO BE HERE AND IS NOT ANY MORE. It is the drum's articulation — how far the
 * filter falls over the hit — and the drum's voice page, PERC, is where the rest of that
 * voice is set; showing it on this page as well was the same number in two places. The
 * parameter is untouched and a preset still carries it; only its second sector went. What
 * is left here is the FIGURE and nothing else, which is why the page is five sectors on
 * RIM_5 and no longer a six.
 *
 * ACCENT is the fourth sector, the same seat it holds on the lead's page: it is how the
 * FIGURE is played — which steps are struck strong — and a judgement about a rhythm is made
 * against the rhythm. It is struck through the engine's velocity, so it is a level and not
 * a second envelope: the accent is made by taking the steps the figure does not mark down,
 * never by raising the marked ones into the limiter. See SYNTH_PARAM_PERC_ACCENT. Its value
 * is one of the panel forms in ACCENT_NAME, and the widest of them is 46 px; the 126-degree
 * seat clears that by 9.8 px, where the untruncated "QUARTER" would overlap the ring by
 * 3.5. The numbers are in the note above SEQ_RING_R, which is where the order of this table
 * was settled.
 *
 * ACCENT APPEARS ON TWO PAGES, and this one is its home: the parameter's name says PERC_
 * because it is the drum whose velocity it was written for. The lead's EUCLID page has its
 * own accent figure — SYNTH_PARAM_SEQ_ACCENT — with the same eight panel forms from
 * ACCENT_NAME, so the two sectors read alike and are not the same setting; see the note
 * over that parameter in synth_app.h for why the figures were split. Nothing in the
 * interface is keyed by parameter and page together, so a second page costs one table
 * entry — see the note over page_seq_is_accent() for the two places this page's own
 * behaviour is decided by which page it is on. Nothing else on this page is shown
 * elsewhere: STEPS, PULSES and ROTATE are the drum's own numbers and RESET is its own
 * gesture.
 *
 * RESET IS THE LAST SECTOR, and it is the DRUM'S OWN reset: after that many steps of THIS
 * grid the percussion phrase begins again on its first step, and only the percussion moves.
 * The lead's period is a separate parameter on its own page and the two never touch each
 * other — see SYNTH_PARAM_PERC_RESET, where the wait for the previous hit to ring out is
 * explained, and SYNTH_PARAM_SEQ_RESET.
 *
 * THE ORDER IS THE ONE THIS PAGE TOOK WHEN RESET ARRIVED — STEPS, PULSES, ROTATE, ACCENT,
 * ENV, RESET — with the voice's ENV lifted out to PERC: STEPS, PULSES, ROTATE, ACCENT,
 * RESET, clockwise from twelve o'clock on RIM_5's seats — 270, 342, 54, 126 and 198
 * degrees. ACCENT stays fourth, where RESET's arrival put it, and the page closes on
 * RESET. It is the lead's order with the lead's SCATTER left out, because the two pages
 * read the same figure — a control that sat in a different place on each of them would be
 * a different control. STEPS keeps the
 * first seat because that is where a page's main control sits everywhere else in the
 * instrument. Measured against the dot ring: STEPS keeps 22.0 px of air, PULSES 9.2,
 * ROTATE 18.2, ACCENT 9.8 and RESET 12.6. The whole sweep is in the note above SEQ_RING_R.
 * PULSES stays beside STEPS although it is a tighter cell than ROTATE's: it is the second
 * control of every Euclidean page and the order is the one the instrument has always shown.
 */
/*
 * Микшер дорожек. Четыре ручки и ничего больше: индикатор у каждой — своё показание
 * (см. VIZ_PERC_MIX), а значения показывает сама ручка.
 */
static const ui_knob_t KNOBS_PERC_MIX[] = {
    { "KICK",  SYNTH_PARAM_PERC_MIX_KICK },
    { "SNARE", SYNTH_PARAM_PERC_MIX_SNARE },
    { "HAT",   SYNTH_PARAM_PERC_MIX_HAT },
    { "TOM",   SYNTH_PARAM_PERC_MIX_TOM },
};

static const ui_knob_t KNOBS_PERC_SEQ[] = {
    { "GROOVE", SYNTH_PARAM_PERC_GROOVE },
    { "VAR",    SYNTH_PARAM_PERC_VARIATION },
    { "FILL",   SYNTH_PARAM_PERC_FILL },
    { "SWING",  SYNTH_PARAM_PERC_SWING },
    { "SPEED",  SYNTH_PARAM_PERC_SPEED },
    { "ACCENT", SYNTH_PARAM_PERC_ACCENT },
};

/*
 * The count field is NK(KNOBS_X), never a typed number. It is the length of the table
 * named two fields to its left, computed at compile time, so a table that gains or loses
 * an entry moves its page with it — see NK() for what the typed number cost once.
 *
 * Every entry with knobs is therefore two lines instead of one: the derived count made
 * the row 15 characters longer than the 100-column rule allows. The split is the honest
 * one — the first line is the page's IDENTITY (names and the table its sectors come
 * from), the second is how it behaves (view, the two flags, the family). The two pages
 * with no knobs stay on one line and say 0, which is what they have, so a one-line entry
 * here means a page with no sectors at all.
 */
static const ui_page_t PAGES[PAGE_COUNT] = {
    /* The body: what is sounding the whole time. Blue. */
    [PAGE_DRONE]     = {"DRONE", "DRN", KNOBS_DRONE, NK(KNOBS_DRONE),
                        VIEW_KNOBS, false, true, GRP_DRONE },
    [PAGE_FILTER]    = {"DRONE FLTR", "DFL", KNOBS_FILTER, NK(KNOBS_FILTER),
                        VIEW_KNOBS, false, true, GRP_DRONE },
    [PAGE_MOD]       = {"LFO", "LFO", KNOBS_MOD, NK(KNOBS_MOD),
                        VIEW_KNOBS, false, true, GRP_DRONE },
    /* The voice: what plays the line. Violet. */
    [PAGE_LEAD]      = {"LEAD", "LD", KNOBS_LEAD, NK(KNOBS_LEAD),
                        VIEW_KNOBS, false, true, GRP_LEAD },
    [PAGE_TONE]      = {"LEAD TONE", "LTN", KNOBS_TONE, NK(KNOBS_TONE),
                        VIEW_KNOBS, false, true, GRP_LEAD },
    [PAGE_ENV]       = {"LEAD ENV", "ENV", KNOBS_ENV, NK(KNOBS_ENV),
                        VIEW_KNOBS, false, true, GRP_LEAD },
    /* Time: what decides the notes. Teal — the hue the inversion mark held before this
     * family took it; see the note above GROUP_COLOR. */
    [PAGE_SCALE]     = {"SCALE", "SCL", KNOBS_GEN, NK(KNOBS_GEN),
                        VIEW_KNOBS, false, true, GRP_GEN },
    [PAGE_EUCLID]    = {"LEAD EUCLID", "EUCL", KNOBS_EUCLID, NK(KNOBS_EUCLID),
                        VIEW_KNOBS, false, true, GRP_GEN },
    [PAGE_ARP]       = {"LEAD ARP", "ARP", KNOBS_ARP, NK(KNOBS_ARP),
                        VIEW_KNOBS, false, true, GRP_GEN },
    /* The percussion: played, but neither the body nor the voice. The one family
     * that is not one of the five originals, and green because it is the blue ramp
     * shifted in hue. */
    [PAGE_PERC]      = {"PERC", "PRC", KNOBS_PERC, NK(KNOBS_PERC),
                        VIEW_KNOBS, false, true, GRP_PERC },
    [PAGE_PERC_SEQ]  = {"PERC SEQ", "SEQ", KNOBS_PERC_SEQ, NK(KNOBS_PERC_SEQ),
                        VIEW_KNOBS, false, true, GRP_PERC },
    [PAGE_PERC_MIX]  = {"PERC MIX", "PMX", KNOBS_PERC_MIX, NK(KNOBS_PERC_MIX),
                        VIEW_KNOBS, false, true, GRP_PERC },
    /* The rack everything goes through. Pink. */
    [PAGE_CHORUS]    = {"CHORUS", "CHR", KNOBS_CHORUS, NK(KNOBS_CHORUS),
                        VIEW_KNOBS, false, true, GRP_FX },
    [PAGE_DELAY]     = {"DELAY", "DLY", KNOBS_DELAY, NK(KNOBS_DELAY),
                        VIEW_KNOBS, false, true, GRP_FX },
    [PAGE_VERB]      = {"REVERB", "REV", KNOBS_VERB, NK(KNOBS_VERB),
                        VIEW_KNOBS, false, true, GRP_FX },
    /* The master: the output level and the compressor everything is heard through, and
     * the only page whose neighbours break the family bands — it sits between the pink
     * rack and the cyan mixers on purpose, and belongs to the mixers. See the note above
     * KNOBS_MIX for why. */
    [PAGE_MASTER]    = {"MASTER", "MST", KNOBS_MASTER, NK(KNOBS_MASTER),
                        VIEW_KNOBS, false, true, GRP_MIX },
    /* The mixers: one family of their own, and cyan because a mixer is played and
     * a map needs to be readable without reading. Five knobs on the first one —
     * see RIM_5 — and the order they are read in is level, sends, drone sends:
     * see KNOBS_MIX.
     *
     * Neither name repeats MIX. The titles are the single words LEVELS and SENDS, and
     * the chips are LVLS, SNDS and DRMX: the family's cyan and the page's own sectors
     * already say which family this is, so the prefix was re-reading what the reader
     * had read before the word — and on a five-sector page the middle column is the
     * tightest text on the instrument. DRONE SENDS is the exception and keeps its
     * prefix, because there the word names the PART rather than the bus: those three
     * sends are the drone's own, and that is the one thing the page is about. Each
     * chip still fits the 44 px disc: the names are three letters, which is what the 20 px face
     * of the tile needs to leave the disc's rim clear. */
    [PAGE_MIX]       = {"LEVELS", "LVL", KNOBS_MIX, NK(KNOBS_MIX),
                        VIEW_KNOBS, false, true, GRP_MIX },
    [PAGE_SEND_REV]  = {"REV SENDS", "RVS", KNOBS_SEND_REV, NK(KNOBS_SEND_REV),
                        VIEW_KNOBS, false, true, GRP_MIX },
    [PAGE_SEND_CHR]  = {"CHR SENDS", "CHS", KNOBS_SEND_CHR, NK(KNOBS_SEND_CHR),
                        VIEW_KNOBS, false, true, GRP_MIX },
    [PAGE_SEND_DLY]  = {"DEL SENDS", "DLS", KNOBS_SEND_DLY, NK(KNOBS_SEND_DLY),
                        VIEW_KNOBS, false, true, GRP_MIX },
    /* Grey, because none of these are played. The presets are a place you go rather
     * than a part of the instrument, so they are a family of their own — a dark grey,
     * with a tile like every other page — and the settings dots no longer count them. */
    [PAGE_PRESET]    = {"PRESET", "PRS", NULL, 0, VIEW_PRESET, false, false, GRP_PRESET },
    [PAGE_SYS]       = {"SYSTEM", "SYS", KNOBS_SYS, NK(KNOBS_SYS),
                        VIEW_KNOBS, true, true, GRP_VIEW },
    [PAGE_SYS2]      = {"OPTIONS", "OPT", KNOBS_SYS2, NK(KNOBS_SYS2),
                        VIEW_KNOBS, true, true, GRP_VIEW },
};

/* -------------------------------------------------------------------------- */
/* State                                                                      */
/* -------------------------------------------------------------------------- */

static page_id_t s_page = PAGE_DRONE;

/* Selection is remembered per page: coming back to FILTER should return to the
 * control you were last adjusting, not to the first one. It starts at zero, which is the
 * page's first table entry; the pages that arrive on another knob name it by parameter
 * instead — see seed_selection() and its call in synth_ui_build(). */
static uint8_t s_sel[PAGE_COUNT];

/* The macro is global on purpose — its whole use is combining parameters from
 * different pages, such as level and cutoff and stereo width. */
static bool s_macro[SYNTH_PARAM_COUNT];
/* The same membership, turned around: the macro pushes this parameter the other way.
 * Per PARAMETER and not per moment, so it survives the parameter ceasing to be the
 * one the knob is standing on. */
static bool s_macro_inv[SYNTH_PARAM_COUNT];

/*
 * The parameters a double tap has silenced — the part levels and the reverb sends — and
 * the value each one had when it went quiet.
 *
 * Indexed by PARAMETER, like the macro above and for the same class of reason: the mute
 * has to be found from the WRITE side as well as from the page. A knob detent, a macro
 * member, a preset load and a draw all move one of these values, and all any of them has
 * in hand is the parameter — see the clear in write_param() and mute_clear_all(). The
 * remembered value is the one that comes back on the second tap, and it is this array
 * alone that is the mute; the parameter itself is honestly at zero, which is what the
 * value and the arc draw.
 *
 * Both live and die with the session on purpose: a mute is a gesture on the panel, not
 * part of the sound, so it is neither stored with a preset nor restored with one.
 */
static bool  s_mute_on[SYNTH_PARAM_COUNT];
static float s_mute_val[SYNTH_PARAM_COUNT];

static bool     s_ready;
static uint32_t s_tick;
static uint32_t s_swipe_contact = SWIPE_CONTACT_NONE;   /* which finger took the last swipe */
static int32_t  s_proxy_value;  /* where the parameter actually is */
static int32_t  s_arc_last;     /* where the arc was at the last change */
static int32_t  s_mult = 1;     /* what one detent is currently worth */
static int32_t  s_steps = PARAM_STEPS;  /* the current parameter's resolution */
/* How many positions the proxy was last ranged for, when it is on a parameter at all: zero
 * while it belongs to the navigator, the preset list or the transport. One list on the
 * instrument changes length under the hand — PULSES follows STEPS — and this is what lets
 * refresh_values() notice. */
static int      s_proxy_positions;
static bool     s_discrete;     /* chosen from a list: accelerates, but no further than three */
static bool     s_syncing;

/* The sequencer display. */
static lv_obj_t *s_seq_dot[SEQ_DOT_MAX];
static lv_obj_t *s_seq_cursor;
static int       s_seq_shown_steps = -1;
static int       s_seq_shown_pulses = -1;
static int       s_seq_shown_rot = -1;
/*
 * The accent the ring was last drawn with, as its parameter's own 0..1 quantised to the
 * byte: which steps are accented is a property of the FIGURE and of this knob, and the
 * dots' sizes have to be redrawn when either moves. It is the parameter and not a
 * figure's index because the dots are redrawn from the same queue the audio task reads,
 * so quantising the stored number here would be a second copy of that mapping — see
 * synth_app_seq_is_accent() and synth_app_perc_is_accent(), which are asked per dot, one
 * per page. Zero means the figure is OFF and no accent exists, which is what hides the
 * difference entirely. One memo and not one per page: the page is forced back to the
 * sentinel whenever either figure page is entered, so the value is re-read from that
 * page's own parameter and a single "what the ring last saw" is enough — see
 * seq_display_show().
 */
static int       s_seq_shown_accent = -1;
static uint32_t  s_seq_shown_msig;      /* the drum's bar, as the dots were last drawn from it */
static int       s_seq_shown_pos = -1;
static int       s_seq_shown_sound = -1;

/* The page turn. */
static lv_obj_t *s_content;
static int32_t   s_slide_pct;
static int       s_slide_dir;
static bool      s_sliding;

/*
 * The hand that made the gesture, for the length of the turn it asked for.
 *
 * A flick crosses the screen in a fifth of a second and a deliberate swipe takes three or
 * four times that, and at any fixed duration one of the two is wrong: fast enough for the
 * flick is unreadably quick for the draw, and slow enough for the draw is a wait after a
 * flick. So the press is remembered and the turn is given the time the page would need to
 * travel its 360 px at the speed the finger was already moving.
 *
 * The floor is PAGE_SLIDE_MS: sooner than that is a cut and not a turn, whatever the hand
 * did. The ceiling is where the wait becomes the thing being noticed.
 */
#define PAGE_SLIDE_MS_MAX 300   /* было 600: медленная рука получала треть секунды хвоста */

static int64_t    s_press_us;
static lv_coord_t s_press_x;
static lv_coord_t s_press_y;
/* A press the screen has heard and the release has not yet ended: the origin a long press is
 * measured against. */
static bool       s_press_point_valid;
static uint32_t   s_slide_ms = PAGE_SLIDE_MS;
static lv_anim_t s_slide_anim;
/* Which page the turn is leaving, and whether it is being put back rather than finished.
 * A turn that the finger never carried far enough has to undo the rebuild it did at the
 * start, so the page being left is remembered for the length of the turn. */
static int        s_slide_from;
static bool       s_slide_cancelled;

/*
 * The turn under the finger.
 *
 * The gesture arrives only once LVGL has already recognised it, which is after the hand has
 * travelled its own threshold, and only when the finger has left the glass. So a turn built
 * on it cannot show the page moving while the hand moves: it starts as a 200 ms animation
 * from a standing start, and there is nothing under the finger while it is down.
 *
 * The drag closes that gap with the cheapest picture there is. As soon as the hand has gone
 * DRAG_START_PX sideways, the turn is set up exactly as slide_to() sets it up — the page it
 * is leaving into one buffer, the page it is going to into another — and then both pictures
 * are placed at that travel instead of on an animation's clock. The first few frames are
 * late: the two snapshots cost what they cost, and the pictures cannot be there before they
 * exist. After that the pair is under the hand and stays there.
 *
 * A hand that is already at a flick's speed does not wait for DRAG_START_PX: see
 * drag_flick_taken(), which answers it on the first poll.
 *
 * On release the turn is finished or undone by the same rule the eye already uses: a quarter
 * of the width is a decision, and so is a flick fast enough to carry the rest of the way.
 * Anything less and the page returns, which is what keeps a stray 20 px of a tap from
 * turning anything.
 */
#define DRAG_START_PX      8    /* sideways travel before the page starts to come */
#define DRAG_COMMIT_MILLI 250   /* of 1000 of the width: past this the turn completes */
#define DRAG_FLICK_PX_MS  0.6f  /* px per millisecond: a flick completes on speed alone */
/*
 * The travel that has to accompany that speed before the poll will call it a flick.
 *
 * The speed alone is measured over one poll (8 ms), and 6 px is below the distance a real
 * 0.6 px/ms hand covers in that time (5 px), while a resting finger's twitch is 1–2 px.
 * Without the floor a two-pixel sample delivered in a short interval could pass 0.6 and turn
 * a page under a hand that was only settling. Six is also most of the 8 px drag threshold, so
 * the answer still comes before the drag would have started.
 */
#define FLICK_MIN_PX        6
/*
 * The longest a turn answered as a flick is allowed to take.
 *
 * slide_ms_for_speed() is the gesture's rule and it goes up to PAGE_SLIDE_MS_MAX (600 ms) for
 * a slow hand — right for a drag that is still being carried, wrong for a flick that has
 * already committed. A hand at the 0.6 px/ms threshold would otherwise get the slowest turn
 * in the file. At 360 ms the page still moves at a readable speed and lands while the flick
 * is still a gesture rather than a wait.
 */
#define FLICK_SLIDE_MS_MAX 240
#define LONG_PRESS_SLOP_PX  5   /* travel that ends a long press before its clock fires */
#define DRAG_POLL_MS       8    /* было 15: картинка шла за пальцем шагами по четыре кадра */

static bool       s_drag_watch;   /* finger is down, the turn has not started yet */
static bool       s_drag_on;      /* the turn is under the finger right now */
static lv_coord_t s_drag_x0;
static lv_coord_t s_drag_travel;  /* 0..360, how far the arriving page has come */
static lv_coord_t s_drag_x_last;
static int64_t    s_drag_us_last;
static float      s_drag_vx;      /* px per ms, smoothed, signed like x */
/* A turn taken by the hand is still a swipe: the gesture that follows it must not take a
 * second one. */
static bool       s_drag_ate_gesture;
static lv_indev_t *s_drag_indev;

/*
 * How fast the finger itself is going, measured on every poll and not only while a drag runs.
 *
 * A drag begins by building a picture and a stall of one or two renders, and the finger does
 * not wait for it. The speed that matters is the one the hand had WHEN the drag began, before
 * the build hid it: the release may arrive inside that stall, with no new point and no path,
 * and a speed measured across the stall would call a flick a drift. So the poll keeps the
 * finger's own last sample, and the drag is handed that speed rather than zero.
 */
static lv_coord_t s_touch_x_last;
static lv_coord_t s_touch_y_last;
static int64_t    s_touch_us_last;
/* Where the finger was when the poll first saw it, and whether it has since gone far enough
 * for the press to be a drag rather than a long press. */
static lv_coord_t s_touch_x0;
static lv_coord_t s_touch_y0;
static bool       s_finger_moved;

/*
 * What the gesture said this finger meant, kept until the release that ends it.
 *
 * LVGL declares a swipe part-way through the press, not on the release, and the drag is
 * already following the finger by then. Its verdict is remembered rather than acted on: a
 * release here would finish the turn while the finger was still down. The release reads it,
 * which is what a flick that ends inside a build needs.
 */
static bool       s_drag_carry;
static bool       s_sheet_carry;
static int        s_sheet_carry_dir;   /* +1: the committing travel is down, -1: up */

/*
 * The drawer under the finger: the map and the transport.
 *
 * These are the other half of the same idea and they cost nothing, because both are live
 * objects whose contents were built when they were made — no picture has to exist before they
 * can move. So the hand moves the object itself, and a frame of that costs what a frame of the
 * animation cost. The picture the animation uses is made by drawer_setup() at the press and is
 * driven from here while the finger is down (drawer_place()), so the two paths share one body
 * of code and end in the same place.
 *
 * Which drawer the hand means is settled by which is up: with one up, the drag is what takes it
 * away; with none up, the direction of the drag is what brings one in. A vertical drag that goes
 * the other way does nothing, exactly as the gesture did before.
 */
#define SHEET_START_PX     20   /* vertical travel before a drawer starts to follow */
#define SHEET_COMMIT_MILLI 250  /* of 1000 of the height: past this the drawer completes */

static bool       s_sheet_watch;    /* finger down, no drawer following yet */
static bool       s_sheet_on;       /* a drawer is under the finger right now */
static bool       s_sheet_opening;  /* this drag brings the drawer in, rather than takes it away */
static bool       s_sheet_nav;      /* the map, rather than the transport */
static lv_coord_t s_sheet_y0;       /* where this finger first showed itself */
static lv_coord_t s_sheet_from;     /* -360, 0 or 360: where this drawer's travel starts */
static lv_coord_t s_sheet_last_y;
static int64_t    s_sheet_us_last;
static float      s_sheet_vy;       /* px per ms, smoothed */
static bool       s_sheet_ate_gesture;
static bool       s_contact_seen;   /* the poll has a point for this finger */

static bool drawer_in_flight(void);
static void drawer_retarget(int32_t to);

static void sheet_begin(int nav, bool opening, lv_coord_t dy);
static void sheet_place(lv_coord_t dy);
static void sheet_release(bool carry);

/*
 * The page as it was, held in a buffer, and the image that shows it.
 *
 * The page — rim, sectors, panels, text, the lot — lives inside s_content, so moving that
 * container makes LVGL re-render the whole screen for every drawn position. Measured, that
 * render is 40 to 50 ms, which is why a turn could only ever be four or five positions
 * long and why lengthening it to 480 ms produced nine positions with a 110 ms worst gap:
 * the duration decides how many positions there are, and the render decides what a
 * position costs.
 *
 * So the page is taken into a buffer at the start of the turn and the turn moves the
 * BUFFER. A position is then a copy of 360x360 pixels out of PSRAM instead of a full
 * software render of the rim and its arcs, and the copy is cheap enough that the refresh
 * period, not the render, is what bounds the frame rate.
 *
 * The buffer is 360 * 360 * 2 = 259200 bytes, which is larger than the whole of the
 * internal RAM that is free, and it is the malloc threshold in sdkconfig
 * (SPIRAM_MALLOC_ALWAYSINTERNAL) that puts it in PSRAM: lv_draw_buf_create() goes through
 * the standard malloc, LVGL is built with LV_USE_STDLIB_MALLOC, and anything above 16 KB
 * is served from PSRAM by configuration.
 */
static lv_obj_t      *s_slide_img;         /* the arriving page, and it is the one that moves */
static lv_draw_buf_t *s_slide_snap;
static lv_obj_t      *s_slide_still;      /* the page being left, in place, not moving */
static lv_draw_buf_t *s_slide_still_snap;

/*
 * The page as it was when the finger went down.
 *
 * The page being left has to be a picture before the turn can start, and taking that picture is
 * the largest single step of the turn's setup — a full render of the rim, its arcs and its
 * labels. Taking it at the press cost that whole step on every touch, tap included: 30.7 ms and
 * 253 KB in PSRAM for a finger that was only choosing a sector. So it is taken on the first
 * movement instead, at 5 px and before either turning threshold — late enough that a tap never
 * pays for it, early enough that a deliberate drag has the picture in hand before it reaches
 * 12 px. A flick that is answered on speed alone (see drag_flick_taken()) starts its turn
 * before that point and pays for the picture inside turn_setup instead.
 *
 * Only a page turn uses it. A press that opens a drawer drops it first (the drawer needs its
 * own picture and the memory is not worth holding twice), and so does the poll once it is
 * clear this finger is not going to turn anything.
 */
static lv_draw_buf_t *s_press_snap;
static bool           s_press_snap_armed;   /* one attempt per finger, not one per poll */
static void press_snap_drop(void);

/* The navigator. */
static lv_obj_t      *s_nav;
static lv_obj_t      *s_nav_cells; /* the mosaic: an image over s_nav_buf, baked once at boot */
static lv_draw_buf_t *s_nav_buf;   /* and its pixels, 253 KB in PSRAM */
static lv_obj_t      *s_nav_marks; /* the flash and the two frames, painted over that image */
static int            s_nav_marked = -1;  /* which page's frame is painted at the moment */
/*
 * One slot per PAGE, not one per tile: a page that answers false to ui_page_t.tile leaves its cell
 * at zero vertices, and every page in the table today answers true. The page index is the only key
 * anything here needs — the sites, the cells, the names and the bake are all addressed by it — so a
 * compacted list would need a second mapping to get back to the page, and that mapping would exist
 * only to save one wasted pointer.
 */
static lv_obj_t *s_nav_label[PAGE_COUNT];
/*
 * The map's geometry is a TABLE now, not a modelled packing: NAV_SITES gives every page a point and
 * the cells are cut from those points once at boot (see nav_measure()). Nothing is sized for a page
 * count any more — a page without a point simply has no cell, and the hole in the mosaic is plainer
 * than an assertion would be. What is asserted is that the table covers the pages, and it is
 * asserted beside the table itself.
 */
/*
 * The transport screen: the play/stop control, on a layer of its own.
 *
 * It used to be a disc hanging over the map's top edge, and at the fitted size it
 * covered the chips it sat above. It is a screen now — reached by a swipe up, left by
 * a swipe down — exactly as the map is reached by a swipe down and left by a swipe
 * up. Nothing about the map's fit changes with it: the disc was never fed into the
 * measurement, only placed against it, so the chips keep the size they had.
 */
static lv_obj_t *s_transport;
static lv_obj_t *s_transport_btn;
static lv_obj_t *s_transport_stop;   /* the square: the action is stop */
static lv_obj_t *s_transport_play;   /* the triangle: the action is play */
static lv_obj_t *s_tempo_arc;
static lv_obj_t *s_battery_label;
static lv_obj_t *s_transport_preset;  /* пресеты: кнопка на транспортной шторке */
static int       s_battery_shown = -2;  /* nothing yet: -1 and 0..100 are all real readings */
static bool      s_battery_usb_shown;

static lv_obj_t *s_tempo_label;
static char      s_tempo_shown[16];     /* the text on the label, to avoid rewriting it */
static lv_obj_t *s_page_dot[PAGE_COUNT];  /* one per page: a family shows its own */
/*
 * The cells, cut once at boot from the table in nav_measure(): px offsets from the middle of the
 * image, at most NAV_CELL_V_MAX of them to a page. s_nav_lx/ly is where that section's name sits,
 * which is the cell's own centroid — measured, the nearest edge is 30 px away from it at the worst,
 * against the 45 px of the longest name.
 *
 * s_nav_glow[i] is the rhythm's flash: the bake gives that cell the family's rim instead of its
 * chip, and nav_rhythm_refresh() is the only thing that sets it.
 */
static float     s_nav_cell[PAGE_COUNT][NAV_CELL_V_MAX * 2];
static uint8_t   s_nav_cell_n[PAGE_COUNT];
static int16_t   s_nav_lx[PAGE_COUNT];
static int16_t   s_nav_ly[PAGE_COUNT];
static bool      s_nav_glow[PAGE_COUNT];
/*
 * The cell the finger is down on, or -1 for none.
 *
 * Lit exactly as the cell you are standing on is lit, because it says the same thing one step
 * earlier: this is the cell the tap is about to take. A still map has no other way to say where a
 * cell ends — the cells are separated by a gap in the picture, and the gap is the colour the whole
 * map is painted on.
 */
static int       s_nav_press = -1;
/* The bake's coverage for one pixel row: 0..256 a pixel, four sub-scanlines' worth. */
static uint16_t  s_nav_row[NAV_SCREEN];
static bool      s_nav_open;
static bool      s_transport_open;

static lv_obj_t *s_sector_arc[SECTOR_MAX];
static lv_obj_t *s_viz_arc[SECTOR_MAX];
static lv_obj_t *s_viz_dot[SECTOR_MAX];
static lv_obj_t *s_sector_touch[SECTOR_MAX];
static lv_obj_t *s_sector_panel[SECTOR_MAX];
static lv_obj_t *s_sector_name[SECTOR_MAX];
static lv_obj_t *s_sector_value[SECTOR_MAX];
static lv_obj_t *s_rim_hit;              /* the polar tap layer, under the text */

/*
 * The selected sector's fill and its brighter value mark: two arcs that MOVE from
 * sector to sector rather than being restyled, so a tap costs the swept wedge and not a
 * repaint of a 352 px box. See refresh_sectors() and the note above refresh_arcs().
 */
static lv_obj_t *s_sel_body;
static lv_obj_t *s_sel_rim;
/* The cursor of a list's rim: one lit segment per list sector, drawn by one object laid over the
 * whole ring. See rim_marks_draw_cb(). */
static lv_obj_t *s_rim_marks;
/* Which position of each list sector is lit at this moment. The repaint of the cursor follows
 * a CHANGE of this number, so a refresh of a value that has not moved costs nothing; 255 is
 * "nothing drawn yet", which is what a page change writes back. */
static uint8_t s_cursor_pos[SECTOR_MAX];

/*
 * How many positions each of those sectors had WHEN ITS CURSOR WAS DRAWN.
 *
 * A segment's colour is not enough to repaint it later: its two angles come from the number of
 * positions, and two lists on the instrument — PULSES and ROTATE — take their length from
 * STEPS. Rebuilding the old segment from the new table is what left a sliver of the previous
 * cursor on the rim when STEPS moved; with the number kept, the sector that was drawn at
 * another length is repainted over its whole span instead of being guessed at.
 */
static uint8_t s_cursor_steps[SECTOR_MAX];


/* Which position of a list a value stands on: defined with refresh_values(), read by the
 * cursor and by cursor_invalidate(). */
static int list_index_for(synth_param_t param, float v);
/* Repaints one position of one sector's cursor and nothing else: defined below, used by
 * refresh_values(). */
static void cursor_move(int sector, int old_idx, int old_positions, bool have_old,
                        int new_idx, int new_positions);
/* Re-points the wheel at a parameter at that parameter's own resolution: defined with the
 * knob's own code, called by refresh_values() when a list changes length under the hand. */
static void proxy_load(synth_param_t param);
static int s_sel_key = -1;   /* the (family, macro, inverted) triple the two are for */
static uint32_t s_tap_ms;    /* when a sector was last tapped */
static int s_tap_idx = -1;   /* which sector, for the double tap */

/* When the finger last landed, on any layer that takes a tap. The double tap is measured from
 * here and not from the CLICKED that follows: a click arrives on the release, and the release
 * is dispatched by whichever frame gets to it — up to a frame late, which is a fifth of the
 * window. Two taps a hand's width apart then measured anywhere between 200 and 600 ms
 * depending on where the frame boundaries fell, and the gesture worked or not by chance. The
 * press is stamped in the same frame on both taps of a pair far more often than the releases
 * are, so the interval below is the one the fingers made. */
static uint32_t s_press_ms;
static bool s_press_valid;

/* The middle: the page's own background over the fills, under the spokes and the text.
 * See CENTRE_BG_R. */
static lv_obj_t *s_hub;

/* Defined with the other tap handlers, but the text block's handler reaches it and
 * sits above it in the file. */
static void sector_activate(int idx, bool toggle_macro);

/* The draw in the middle of the page stands above these definitions. */
static void write_param(synth_param_t param, float v01);
static float preset_random_unit(void);

/* Defined after refresh_sectors(), but the rim's colours are part of laying the rim
 * out, so layout_sectors() reaches it. */
static void refresh_arcs(void);
static lv_obj_t *s_divider[DIV_MAX];

/* lv_line keeps the pointer it is given rather than copying the points, so the
 * storage has to outlive the call — hence file scope. Two points per divider,
 * in the line object's own coordinates, which is why the origin below is the
 * screen centre expressed in a 360x360 object. */
static lv_point_precise_t s_divider_pts[DIV_MAX][2];
#define DIV_ORIGIN 180

static lv_obj_t *s_proxy;
static lv_obj_t *s_page_name;
static lv_obj_t *s_macro_label;
static lv_obj_t *s_arp_label;    /* shares the macro count's line, and outranks it */
static lv_obj_t *s_dim;          /* the wash under the arp notice, over the page */

/*
 * The turning picture: the object, the 392-byte mask, the key of the mask that is
 * on the screen, and the moment the middle goes back to the page's name.
 *
 * The key is what keeps a knob that moves inside one screen pixel from redrawing
 * anything: the picture is built from values quantised to the grid it is drawn on,
 * so a new key means a different picture and an equal key means the 392 bytes
 * would be identical. See synth_ui_preview.h.
 */
static lv_obj_t *s_preview;
static uint8_t   s_preview_mask[SYNTH_PREVIEW_BYTES];
static uint32_t  s_preview_key;
static uint32_t  s_preview_until;
static bool      s_preview_on;
static int       s_preview_y0;   /* first mask row with ink */
static int       s_preview_y1 = SYNTH_PREVIEW_H - 1;   /* last mask row with ink */

/* How long the picture keeps the middle after the last value change. */
#define PREVIEW_HOLD_MS 2000

/*
 * TEMPORARY frame-cost probe. 0 in every build that ships: the block it guards
 * exists only to measure the two halves of a frame on the instrument and is
 * removed once the numbers are written down.
 */

/* Temporary, for tools/screens.ps1: every page turns the picture on with the figure
 * of its number and holds it, so the page walk captures it. Removed with the probe. */


/*
 * The preset list. The rows are a WINDOW on the store and are rebuilt whenever the
 * selection moves; the selection itself is a slot index and is the only thing the
 * chips act on. It survives leaving the page, because going to look at a parameter
 * and coming back should not lose your place in the list.
 */
static lv_obj_t *s_preset;
static lv_obj_t *s_preset_row[PRESET_ROWS];
static lv_obj_t *s_preset_no[PRESET_ROWS];
static lv_obj_t *s_preset_name[PRESET_ROWS];
static lv_obj_t *s_preset_empty;
static lv_obj_t *s_preset_load;
static lv_obj_t *s_preset_save;
static lv_obj_t *s_preset_random;
static int       s_preset_sel = -1;     /* the slot LOAD and SAVE act on */

static lv_obj_t             *s_wave;
static lv_point_precise_t    s_wave_pts[WAVE_POINTS];
static int       s_preset_count;        /* slots in the store, at the last refresh */
static bool      s_preset_dirty;        /* the sound has moved since the last load or save */

/* The ring's override, written by whatever task reports network state and read
 * by the animation timer. Plain 32-bit and 8-bit values, so no lock is needed;
 * the deadline is written LAST so the colour is always in place before it can
 * take effect. */
static volatile uint32_t s_ring_until_ms;
static volatile uint8_t  s_ring_r;
static volatile uint8_t  s_ring_g;
static volatile uint8_t  s_ring_b;

static bool swipe_just_happened(void);
static void swipe_was_taken(void);   /* the click that ends a swipe must not fire */
static void nav_open(void);
static void nav_close(void);
static void transport_open(void);
static void transport_close(void);

static void goto_page(int page);
static void apply_page(int page_idx);
static void turn_to(int page_idx, int dir);


static void seq_display_show(int on);
static void nav_repaint_all(void);   /* the whole map, painted again */
static void nav_mark_current(void);
static void refresh_page_dots(void);   /* the page dots, further down this file */
static void preset_refresh(void);
static void preset_select(int slot);
static bool preset_swipe(int delta);

/* -------------------------------------------------------------------------- */
/* Small builders                                                             */
/* -------------------------------------------------------------------------- */

static uint32_t now_ms(void)
{
    return (uint32_t)(esp_timer_get_time() / 1000);
}

/* -------------------------------------------------------------------------- */
/* Last actions: a ring in RTC memory that survives the reset                 */
/* -------------------------------------------------------------------------- */
/*
 * A reset leaves no log when the console is not being read, so the instrument
 * keeps its own short history where the reset cannot clear it. The ring sits in
 * RTC slow memory (`RTC_NOINIT_ATTR`): it survives a panic, a watchdog and a
 * brownout, and is only lost when the RTC domain itself loses power.
 *
 * A cold boot is indistinguishable from garbage without a marker, so the
 * header carries a magic and its complement. On the first boot after power-on
 * neither matches and the ring is simply initialised; after any other reset the
 * header is valid and the records are from the session that just ended.
 *
 * `synth_ui_build()` prints the previous session before it creates a widget and
 * then clears the ring. Clearing last is deliberate: a reset during the dump
 * prints it again next time rather than losing it. Events written during the
 * current boot replace the old ones in ring order.
 *
 * Only interface and application paths write here — page turns, drawers, the
 * knob, effect parameters, presets, the MIDI switch. The audio callback does
 * not, and must not: a critical section around RTC memory in that path would
 * be a deadline miss waiting to happen.
 */
#define DIAG_MAGIC       0x4F424F44u  /* "OBOD" */
#define DIAG_SLOTS       64
#define DIAG_DUMP_SLOTS  20
#define DIAG_KNOB_GAP_MS 100u
#define DIAG_FX_GAP_MS   250u

typedef enum {
    DIAG_EVT_PAGE = 1,
    DIAG_EVT_DRAWER,
    DIAG_EVT_KNOB,
    DIAG_EVT_FX,
    DIAG_EVT_PRESET,
    DIAG_EVT_MIDI,
} diag_evt_t;

typedef struct {
    uint32_t ms;
    int16_t  a;
    int16_t  b;
    uint8_t  type;
    uint8_t  reserved[3];
} diag_rec_t;

typedef struct {
    uint32_t magic;
    uint32_t magic_inv;
    uint32_t head;
    uint32_t count;
    diag_rec_t rec[DIAG_SLOTS];
} diag_ring_t;

RTC_NOINIT_ATTR static diag_ring_t s_diag;
static portMUX_TYPE s_diag_lock = portMUX_INITIALIZER_UNLOCKED;
static bool     s_diag_dumped;
static uint32_t s_diag_knob_ms;
static uint32_t s_diag_fx_ms;

static bool diag_ring_ok(void)
{
    return s_diag.magic == DIAG_MAGIC &&
           s_diag.magic_inv == ~DIAG_MAGIC &&
           s_diag.head < DIAG_SLOTS;
}

static void diag_ring_clear(void)
{
    portENTER_CRITICAL(&s_diag_lock);
    s_diag.magic = DIAG_MAGIC;
    s_diag.magic_inv = ~DIAG_MAGIC;
    s_diag.head = 0;
    s_diag.count = 0;
    portEXIT_CRITICAL(&s_diag_lock);
}

static void diag_record(diag_evt_t type, int a, int b)
{
    portENTER_CRITICAL(&s_diag_lock);
    if (!diag_ring_ok()) {
        s_diag.magic = DIAG_MAGIC;
        s_diag.magic_inv = ~DIAG_MAGIC;
        s_diag.head = 0;
        s_diag.count = 0;
    }

    diag_rec_t *r = &s_diag.rec[s_diag.head];
    r->ms = now_ms();
    r->a = (int16_t)a;
    r->b = (int16_t)b;
    r->type = (uint8_t)type;
    r->reserved[0] = 0;
    r->reserved[1] = 0;
    r->reserved[2] = 0;

    s_diag.head = (s_diag.head + 1u) % DIAG_SLOTS;
    s_diag.count++;
    portEXIT_CRITICAL(&s_diag_lock);
}

static void diag_knob(int page, int param)
{
    const uint32_t t = now_ms();
    if ((int32_t)(t - s_diag_knob_ms) < (int32_t)DIAG_KNOB_GAP_MS) {
        return;
    }
    s_diag_knob_ms = t;
    diag_record(DIAG_EVT_KNOB, page, param);
}

static void diag_fx(synth_param_t param, float v01)
{
    const uint32_t t = now_ms();
    if ((int32_t)(t - s_diag_fx_ms) < (int32_t)DIAG_FX_GAP_MS) {
        return;
    }
    s_diag_fx_ms = t;
    diag_record(DIAG_EVT_FX, (int)param, (int)(v01 * 1000.0f + 0.5f));
}

static bool diag_param_is_fx(synth_param_t param)
{
    for (int i = 0; i < (int)PAGE_COUNT; i++) {
        const ui_page_t *p = &PAGES[i];
        if (p->group != GRP_FX || p->knobs == NULL) {
            continue;
        }
        for (int k = 0; k < p->knob_count; k++) {
            if (p->knobs[k].param == param) {
                return true;
            }
        }
    }
    return false;
}

static const char *diag_page_title(int page)
{
    return (page >= 0 && page < (int)PAGE_COUNT) ? PAGES[page].title : "?";
}

static const char *diag_knob_name(int page, int param)
{
    if (param == (int)SYNTH_PARAM_SEQ_TEMPO) {
        return "TEMPO";
    }
    if (page >= 0 && page < (int)PAGE_COUNT && PAGES[page].knobs != NULL) {
        const ui_page_t *p = &PAGES[page];
        for (int k = 0; k < p->knob_count; k++) {
            if ((int)p->knobs[k].param == param) {
                return p->knobs[k].sector;
            }
        }
    }
    return "?";
}

static const char *diag_fx_name(int param)
{
    for (int i = 0; i < (int)PAGE_COUNT; i++) {
        const ui_page_t *p = &PAGES[i];
        if (p->knobs == NULL) {
            continue;
        }
        for (int k = 0; k < p->knob_count; k++) {
            if ((int)p->knobs[k].param == param) {
                return p->knobs[k].sector;
            }
        }
    }
    return "?";
}

static void diag_print_record(const diag_rec_t *r)
{
    const unsigned sec = (unsigned)(r->ms / 1000u);
    const unsigned msec = (unsigned)(r->ms % 1000u);

    switch ((diag_evt_t)r->type) {
    case DIAG_EVT_PAGE:
        ESP_LOGW(TAG, "  %4u.%03us  page   %s", sec, msec, diag_page_title(r->a));
        break;
    case DIAG_EVT_DRAWER:
        ESP_LOGW(TAG, "  %4u.%03us  %-6s %s", sec, msec,
                 r->a == 1 ? "map" : "transport", r->b ? "open" : "close");
        break;
    case DIAG_EVT_KNOB:
        if (r->b < 0) {
            ESP_LOGW(TAG, "  %4u.%03us  knob   %s", sec, msec, diag_page_title(r->a));
        } else {
            ESP_LOGW(TAG, "  %4u.%03us  knob   %s / %s", sec, msec,
                     diag_page_title(r->a), diag_knob_name(r->a, r->b));
        }
        break;
    case DIAG_EVT_FX:
        ESP_LOGW(TAG, "  %4u.%03us  fx     %s (%d) = %u%%", sec, msec,
                 diag_fx_name(r->a), (int)r->a,
                 (unsigned)((r->b < 0 ? 0 : r->b) / 10));
        break;
    case DIAG_EVT_PRESET:
        /* b is the kind of the action: a load, a save, the factory sound from the INIT
         * row, or a random draw. The INIT row is not a slot, so its number is 0 and the
         * word is what tells the two apart in the dump. */
        ESP_LOGW(TAG, "  %4u.%03us  preset %d %s", sec, msec, (int)r->a,
                 r->b == 1 ? "load" : r->b == 2 ? "save" : r->b == 3 ? "init" : "random");
        break;
    case DIAG_EVT_MIDI:
        ESP_LOGW(TAG, "  %4u.%03us  MIDI in %s%s", sec, msec,
                 r->a ? "on" : "off", r->b ? "" : " (failed)");
        break;
    default:
        ESP_LOGW(TAG, "  %4u.%03us  event %u (%d,%d)", sec, msec,
                 (unsigned)r->type, (int)r->a, (int)r->b);
        break;
    }
}

static void diag_dump_previous(void)
{
    if (s_diag_dumped) {
        return;
    }
    s_diag_dumped = true;

    if (!diag_ring_ok() || s_diag.count == 0) {
        diag_ring_clear();
        return;
    }

    const uint32_t total = s_diag.count;
    const uint32_t n = total < DIAG_DUMP_SLOTS ? total : DIAG_DUMP_SLOTS;
    const uint32_t first = (s_diag.head + DIAG_SLOTS - n) % DIAG_SLOTS;

    ESP_LOGW(TAG, "last actions before reset: %u recorded, showing the last %u",
             (unsigned)total, (unsigned)n);
    for (uint32_t i = 0; i < n; i++) {
        diag_print_record(&s_diag.rec[(first + i) % DIAG_SLOTS]);
    }

    /* Clear only after every line has been handed to the log. */
    diag_ring_clear();
    ESP_LOGW(TAG, "event ring cleared");
}

/* Signed difference, so the comparison survives the 32-bit wrap in 49 days. */
static bool ring_override_active(void)
{
    return (int32_t)(s_ring_until_ms - now_ms()) > 0;
}

static lv_obj_t *make_panel(lv_obj_t *parent, int w, int h, uint32_t bg,
                            lv_align_t align, int x_ofs, int y_ofs)
{
    lv_obj_t *o = lv_obj_create(parent);
    lv_obj_set_size(o, w, h);
    lv_obj_align(o, align, x_ofs, y_ofs);
    lv_obj_set_scrollable(o, false);
    lv_obj_set_style_radius(o, 10, LV_PART_MAIN);
    lv_obj_set_style_bg_color(o, lv_color_hex(bg), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(o, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_set_style_border_width(o, 0, LV_PART_MAIN);
    lv_obj_set_style_pad_all(o, 0, LV_PART_MAIN);

    /* Nothing here is ever focused: the focus proxy is the only focusable widget
     * on any page, and a container that steals focus would break the knob. */
    lv_obj_set_clickable(o, false);
    lv_obj_set_click_focusable(o, false);
    return o;
}

static lv_obj_t *make_label(lv_obj_t *parent, const char *text,
                            const lv_font_t *font, uint32_t color,
                            lv_align_t align, int x_ofs, int y_ofs)
{
    lv_obj_t *l = lv_label_create(parent);
    lv_label_set_text(l, text);
    lv_obj_set_style_text_font(l, font, LV_PART_MAIN);
    lv_obj_set_style_text_color(l, lv_color_hex(color), LV_PART_MAIN);
    lv_obj_align(l, align, x_ofs, y_ofs);
    lv_obj_set_click_focusable(l, false);
    return l;
}

static void text_color(lv_obj_t *l, uint32_t color)
{
    lv_obj_set_style_text_color(l, lv_color_hex(color), LV_PART_MAIN);
}

/*
 * Condensed, out of a face that is not.
 *
 * The faces on this screen are proportional, so a letter space is a nudge rather than a
 * cure: negative space is what pulls a run of capitals together when a row needs a few
 * pixels back, and the calls that pass it are the ones whose width was checked against a
 * measured string. Nothing is added for weight: the faces are already drawn at the weight
 * they are used at, and at these sizes one extra pixel per side would close the counters
 * of 'e' and 'a' and turn the text into a smear.
 *
 * THE TWO FACES WANT DIFFERENT NUMBERS, because a capital is not the same fraction of the
 * em in either. The large face is set at 0 and used to be -1: at 20 px a capital is 10 px
 * of ink inside a 12 px advance, so -1 left exactly one pixel between every pair of
 * letters in a word. 0 leaves two, which is what the face was drawn for. The small face
 * keeps +2 — at 14 px the ink is 8 px inside a 10 px advance, so +2 is the same two pixels
 * rather than a smear.
 *
 * The pixel the large face took back costs width, 1 px per gap, and four strings are
 * measured against a budget rather than admired: the page title (80 px of middle column),
 * the preset name (129 px of row), a sector value (the ring's cells) and a chip's word.
 * Two of them needed paying for, and neither by shrinking the letter space back:
 *
 *   - QUARTER was the longest value on the two figure pages while the panel still printed
 *     it: at letter space 0 it went from 78 to 84 px against a cell it may only be 80 px
 *     wide — the dot on the ring. The four pairs added to lv_font_anbscreen_20's kerning
 *     table give back the four that mattered (AR, ER, RT, TE, one pixel each) and left it
 *     at exactly 80 px, a tangent; OFFBEAT, the second longest, landed on the same edge
 *     without a pair of its own. The panel no longer prints either word — the accent
 *     readouts are now the short forms in ACCENT_NAME — and the pairs stay in the generated
 *     font: they cost nothing there, and removing them would mean editing a generated table
 *     to buy nothing. Every gap in those words was still the 1 px it is today, so no two
 *     inks were closer than the owner already saw them. Two pixels on RT or TE would have
 *     closed the ink completely — RT and TE are the pairs whose inks meet, checked by
 *     rendering the glyphs rather than by eye.
 *   - OPTIONS, the one title of seven characters, measures exactly 80 px, which is the
 *     column and therefore touches both sector blocks. It takes the larger face anyway,
 *     by the owner's order: see TITLE_BIG_CHARS.
 *
 * The measure is build\kern_plus1.py in the working tree, which reads adv_w, the kerning
 * table and kern_scale out of the two font files and applies lv_text.c's arithmetic.
 */
static void text_condensed(lv_obj_t *l, int letter_space)
{
    lv_obj_set_style_text_letter_space(l, letter_space, LV_PART_MAIN);
}

/* -------------------------------------------------------------------------- */
/* Start-up screen                                                            */
/* -------------------------------------------------------------------------- */

/*
 * The name and the version, on screen from the first frame and taken down after
 * SPLASH_MS.
 *
 * It is a cover rather than a page. Everything under it is already built and the
 * interface is already standing on DRONE by the time this appears, so the two
 * seconds cost the wait and nothing else: no page is built late, no setting is
 * applied late, and the knob answers the moment the cover goes. The cover is
 * opaque COL_BG — the colour the screen is cleared to — so what follows it is the
 * page appearing rather than a page flashing in.
 *
 * The version is the running image's own, out of esp_app_get_description(): the
 * same string the OTA check compares, so the number on the screen is the number
 * the device reports when asked.
 *
 * NOT DRAWN IN THE SNAPSHOT BUILD. The walk in screenshots.c begins as soon as the
 * interface is built and takes the first pages inside those two seconds, so a cover
 * left on top would be photographed into whatever it happened to be hiding.
 */
#if !CONFIG_OBOD_SCREENSHOTS

#define SPLASH_MS 2000

static lv_obj_t *s_splash;

static void splash_done_cb(lv_timer_t *t)
{
    (void)t;
    if (s_splash) {
        lv_obj_delete(s_splash);
        s_splash = NULL;
        /* The pair of these lines is the boot record's timing of the cover. */
        ESP_LOGI(TAG, "splash: down");
    }
}

static void splash_build(lv_obj_t *screen)
{
    /* NAV_SCREEN_R is half the panel, and the cover has to be the whole of it. */
    s_splash = make_panel(screen, NAV_SCREEN_R * 2, NAV_SCREEN_R * 2, COL_BG,
                          LV_ALIGN_CENTER, 0, 0);
    lv_obj_set_style_radius(s_splash, 0, LV_PART_MAIN);

    lv_obj_t *name = make_label(s_splash, "OBOD", &lv_font_anbscreen_20, COL_ACCENT,
                                LV_ALIGN_CENTER, 0, -16);
    text_condensed(name, 8);

    const esp_app_desc_t *app = esp_app_get_description();
    make_label(s_splash, app->version, &lv_font_anbscreen_14, COL_MUTED, LV_ALIGN_CENTER, 0, 16);

    /*
     * Logged rather than left to the eye: this is the version the screen is showing
     * and the time it is up for, and the two lines together time the cover on the
     * record instead of by stopwatch.
     */
    ESP_LOGI(TAG, "splash: OBOD %s, up for %d ms", app->version, SPLASH_MS);

    /* One shot: LVGL deletes the timer itself once this call has run. */
    lv_timer_set_repeat_count(lv_timer_create(splash_done_cb, SPLASH_MS, NULL), 1);
}

#endif /* !CONFIG_OBOD_SCREENSHOTS */

/*
 * Kill the theme's focus decoration on a widget.
 *
 * The theme draws a 2 px #F44336 outline on FOCUS_KEY/EDITED. Because the BSP
 * holds the group in edit mode permanently, that state is this UI's normal
 * condition, so the outline would be permanent furniture rather than feedback.
 *
 * These are LOCAL style properties, not lv_obj_add_style and not the
 * lv_obj_set_style_* helpers. Both of those insert a NORMAL style, and normal
 * styles are inserted at the FRONT of the object's list while get_prop_core()
 * prefers the earliest-added among equal candidates — so the theme's, added when
 * the widget was created, would win. A local style is consulted ahead of all
 * normal styles.
 *
 * Both EDITED and FOCUS_KEY are needed: the encoder sets FOCUSED|FOCUS_KEY,
 * other input devices set FOCUSED alone, and precedence prefers an exact state
 * match over a partial one.
 */
static void suppress_theme_focus_decoration(lv_obj_t *obj)
{
    static const lv_state_t states[] = {
        LV_PART_MAIN | LV_STATE_EDITED,
        LV_PART_MAIN | LV_STATE_FOCUSED,
        LV_PART_MAIN | LV_STATE_FOCUS_KEY,
    };

    for (size_t i = 0; i < sizeof(states) / sizeof(states[0]); i++) {
        lv_obj_set_local_style_prop(obj, LV_STYLE_OUTLINE_WIDTH,
                                    (lv_style_value_t){ .num = 0 }, states[i]);
        lv_obj_set_local_style_prop(obj, LV_STYLE_BORDER_WIDTH,
                                    (lv_style_value_t){ .num = 0 }, states[i]);
    }
}

/*
 * A tappable area the knob must not reach.
 *
 * Deliberately an lv_obj and not an lv_button: the group builder in ui_app.c
 * only collects interactive classes, so a plain clickable object stays out of
 * the encoder's path while remaining tappable.
 *
 * Staying out of the GROUP is not enough on its own. LVGL's pointer handling
 * moves the focus to whatever click-focusable object was tapped, and doing so
 * clears the group's edit mode — after which the knob only shuffles focus and
 * changes no values. Clearing LV_OBJ_FLAG_CLICK_FOCUSABLE keeps the area fully
 * tappable while making it invisible to the focus system. lv_obj_create() sets
 * that flag by default, so it has to be turned off explicitly.
 *
 * GESTURE_BUBBLE is what lets a swipe that starts on this area still turn the
 * page: LVGL walks up from the pressed object while the flag is set, so the
 * gesture ends up at the screen, which is where the handler lives.
 *
 * PRESSED STATES — the rule for the whole instrument.
 *
 * Every tappable object answers a finger while the finger is down, in one of two
 * ways and nothing else: a filled button keeps its colour and drops to LV_OPA_70
 * (the chips, the transport, the honeycomb discs), and a surface that has no fill at
 * rest lights up in its family's BRIGHT colour at LV_OPA_20 instead, which is the
 * only fill it can have without stealing a meaning (the sector blocks, whose fill
 * already means "the knob is here" and "the macro is riding this"). The hue in that
 * wash is not decoration either: it is the family the block belongs to, so the press
 * confirms which page you are on at the same time as it confirms the tap.
 *
 * Nothing moves and nothing resizes. Every other control on this screen would have to
 * be re-laid out to keep its distance from a button that grew, and the tile pitch is
 * already down to 4.6 px of drawn gap at 20 tiles.
 *
 * Four tappable surfaces deliberately have none, and the reason is the same for all
 * four: LVGL's gesture path does not clear PRESSED while a finger is still down (the
 * state is dropped on release, in lv_obj.c), so anything that also takes a DRAG is
 * lit for the whole of every swipe. Filling those would not be feedback about a tap,
 * it would be a flash on a gesture that is not one:
 *
 *   the full-screen catcher      no CLICKED handler at all, so a tap on it is
 *                                nothing; it is the object under every swipe
 *   the polar tap layer          the whole display, and a wash across all of it says
 *                                nothing about which sector the finger found — that
 *                                sector already answers by filling its own block and
 *                                moving the knob
 *   the curtain's background     a pan surface: held for all of every pan, and it
 *                                would fight the slide animation as well
 *   the focus proxy              not a button: it is where the encoder's focus lives,
 *                                and it only answers a long press
 */
static lv_obj_t *make_touch_area(lv_obj_t *parent, int w, int h,
                                 lv_align_t align, int x_ofs, int y_ofs)
{
    lv_obj_t *o = lv_obj_create(parent);
    lv_obj_set_size(o, w, h);
    lv_obj_align(o, align, x_ofs, y_ofs);
    lv_obj_set_scrollable(o, false);
    lv_obj_set_style_bg_opa(o, LV_OPA_TRANSP, LV_PART_MAIN);
    lv_obj_set_style_border_width(o, 0, LV_PART_MAIN);
    lv_obj_set_style_pad_all(o, 0, LV_PART_MAIN);
    lv_obj_set_clickable(o, true);
    lv_obj_set_click_focusable(o, false);
    lv_obj_set_gesture_bubble(o, true);
    /*
     * And the press goes up with the gesture.
     *
     * A gesture bubble carries only the gesture; the press that begins the finger does not
     * travel with it. Every touch area covers part of the screen — the rim layer covers all of
     * it — so without this the screen never hears a press at all, and the drag that follows the
     * finger has nothing to start from: no starting point, no speed, and no snapshot taken
     * while the hand is still deciding. That is the whole reason a fast swipe could sometimes
     * do nothing at all.
     */
    lv_obj_add_flag(o, LV_OBJ_FLAG_EVENT_BUBBLE);
    return o;
}

/* -------------------------------------------------------------------------- */
/* Page helpers                                                               */
/* -------------------------------------------------------------------------- */

static const ui_page_t *page(void)
{
    return &PAGES[s_page];
}

/*
 * The rim of the page being drawn. The count alone decides it: every six-sector page —
 * OPTIONS, the three send pages and LEAD EUCLID — draws RIM_6, and every five-sector page
 * draws RIM_5, so there is no second table to choose and no argument to get wrong. page()
 * is the page that is on screen.
 */
static rim_t page_rim(void)
{
    return rim_for(page()->knob_count);
}

static int sel_index(void)
{
    const int n = page()->knob_count;
    if (n == 0) {
        return 0;
    }
    const int k = s_sel[s_page];
    return (k < n) ? k : 0;
}

static int macro_count(void)
{
    int n = 0;
    for (int i = 0; i < SYNTH_PARAM_COUNT; i++) {
        if (s_macro[i]) {
            n++;
        }
    }
    return n;
}

/*
 * Whether any knob on a page rides the macro — the question the curtain's red mark
 * answers, so it is asked of the page and not of the one you are standing on.
 *
 * It reads s_macro[], the same flag refresh_sectors() reads to turn a sector red, so
 * there is no second copy of "what is in the macro" to keep in step: assign or clear
 * one and both surfaces already agree about it.
 */
static bool page_has_macro(const ui_page_t *p)
{
    for (int i = 0; i < p->knob_count; i++) {
        if (s_macro[p->knobs[i].param]) {
            return true;
        }
    }

    return false;
}

/* -------------------------------------------------------------------------- */
/* Drawing the state of things                                                */
/* -------------------------------------------------------------------------- */

/*
 * Place the rim for this page: spans, anchors, highlight panels and divider
 * spokes. Called on a page change, because the whole geometry depends on how
 * many sectors that page uses.
 */
/* Declared here because the meters below weigh a part the same way the ring does. */
static float part_output_gain(float level, float send, bool send_is_post_fader);

/*
 * What the track on this sector should show. A parameter that is not in VIZ[] has no
 * track: the arc, the dot and the state are all hidden, so a page with one modulator
 * costs one dot and nothing else.
 */
static viz_kind_t viz_for(synth_param_t param)
{
    for (size_t i = 0; i < sizeof(VIZ) / sizeof(VIZ[0]); i++) {
        if (VIZ[i].param == param) {
            return (viz_kind_t)VIZ[i].kind;
        }
    }

    return VIZ_NONE;
}

/* A fill and a dot are drawn from the same source but not the same way. */
/* True where the reading swings both ways about zero, which only the LFOs do. */
static bool viz_is_bipolar(viz_kind_t kind)
{
    return (kind == VIZ_DRONE_LFO || kind == VIZ_PAN_LFO);
}

static bool viz_is_meter(viz_kind_t kind)
{
    return kind == VIZ_METER || kind == VIZ_DUCK || kind == VIZ_PERC_MIX;
}

/*
 * The part a parameter belongs to, as a layer, or -1 for the percussion: the drum is not an
 * engine layer at all — it is summed into the rack's dry mix — so it has its own envelope.
 */
static int viz_layer(synth_param_t param)
{
    switch (param) {
    case SYNTH_PARAM_LEAD_LEVEL:
    case SYNTH_PARAM_SEND_LEAD:
    case SYNTH_PARAM_CHR_SEND_LEAD:
    case SYNTH_PARAM_DLY_SEND_LEAD:
        return SYNTH_LAYER_LEAD;

    case SYNTH_PARAM_DRONE_LOW:
    case SYNTH_PARAM_SEND_LOW:
    case SYNTH_PARAM_CHR_SEND_LOW:
    case SYNTH_PARAM_DLY_SEND_LOW:
        return SYNTH_LAYER_DRONE_LOW;

    case SYNTH_PARAM_DRONE_MID:
    case SYNTH_PARAM_SEND_MID:
    case SYNTH_PARAM_CHR_SEND_MID:
    case SYNTH_PARAM_DLY_SEND_MID:
        return SYNTH_LAYER_DRONE_MID;

    case SYNTH_PARAM_DRONE_HIGH:
    case SYNTH_PARAM_SEND_HIGH:
    case SYNTH_PARAM_CHR_SEND_HIGH:
    case SYNTH_PARAM_DLY_SEND_HIGH:
        return SYNTH_LAYER_DRONE_HIGH;

    default:
        return -1;
    }
}

/*
 * Which effect a send parameter asks for, as an index: 1 reverb, 2 chorus, 3 delay, 0 not a
 * send at all. The eighteen send knobs are otherwise identical — same part names, same
 * percentages — and the only thing that separates them is whose return level weighs them.
 */
static int viz_send_fx(synth_param_t param)
{
    switch (param) {
    case SYNTH_PARAM_SEND_LEAD:
    case SYNTH_PARAM_SEND_PERC:
    case SYNTH_PARAM_SEND_LOW:
    case SYNTH_PARAM_SEND_MID:
    case SYNTH_PARAM_SEND_HIGH:
    case SYNTH_PARAM_SEND_MIC:
        return 1;

    case SYNTH_PARAM_CHR_SEND_LEAD:
    case SYNTH_PARAM_CHR_SEND_PERC:
    case SYNTH_PARAM_CHR_SEND_LOW:
    case SYNTH_PARAM_CHR_SEND_MID:
    case SYNTH_PARAM_CHR_SEND_HIGH:
    case SYNTH_PARAM_CHR_SEND_MIC:
        return 2;

    case SYNTH_PARAM_DLY_SEND_LEAD:
    case SYNTH_PARAM_DLY_SEND_PERC:
    case SYNTH_PARAM_DLY_SEND_LOW:
    case SYNTH_PARAM_DLY_SEND_MID:
    case SYNTH_PARAM_DLY_SEND_HIGH:
    case SYNTH_PARAM_DLY_SEND_MIC:
        return 3;

    default:
        return 0;
    }
}

/* The layer's fader and send, by index rather than by enum arithmetic. */
static const synth_param_t VIZ_LEVEL_OF[3] = {
    SYNTH_PARAM_DRONE_LOW, SYNTH_PARAM_DRONE_MID, SYNTH_PARAM_DRONE_HIGH,
};
static const synth_param_t VIZ_SEND_OF[3] = {
    SYNTH_PARAM_SEND_LOW, SYNTH_PARAM_SEND_MID, SYNTH_PARAM_SEND_HIGH,
};

/* Defined further down, beside the rule it states; the meter below is one of its readers. */
static bool output_open(void);

/*
 * Показание одной дорожки микшера, для её индикатора.
 *
 * Считается в звуковом такте, в момент удара (см. perc_strike() и
 * perc_lane_env_tick() в synth_app.cpp): это сила удара вместе с ручкой дорожки, а
 * не звук голоса. Здесь оно только читается, поэтому страница PERC MIX ничего не
 * стоит тракту, пока на неё не смотрят.
 */
static float viz_perc_mix(synth_param_t param)
{
    switch (param) {
    case SYNTH_PARAM_PERC_MIX_KICK:  return synth_app_perc_lane_level(0);
    case SYNTH_PARAM_PERC_MIX_SNARE: return synth_app_perc_lane_level(1);
    case SYNTH_PARAM_PERC_MIX_HAT:   return synth_app_perc_lane_level(2);
    case SYNTH_PARAM_PERC_MIX_TOM:   return synth_app_perc_lane_level(3);
    default:                         return 0.0f;
    }
}

/*
 * What the part is producing right now, 0..1, for the meter.
 *
 * The same weighing the ring uses: the layer's own envelope, then its fader and its send,
 * with the percussion measured after its fader because that is where the engine applies it.
 * A send parameter measures what leaves for the reverb instead of what is heard, because
 * that is the quantity the knob is about.
 */
static float viz_meter(synth_param_t param)
{
    /*
     * Nothing a part makes leaves the box while the transport is stopped or the master is at
     * zero: the rack's gate is shut on the dry path and on all three send buses at once. A
     * fill that kept rising would be a reading of a sound nobody can hear — the drone's
     * registers especially, because they are the parts that never stop running of their own
     * accord, so their envelopes stay at full while the gate holds them back.
     */
    if (!output_open()) {
        return 0.0f;
    }

    const int   fx = viz_send_fx(param);
    const bool  is_send = (fx != 0);
    const int   layer = viz_layer(param);

    /* The return level of the effect this knob feeds: a send of nothing is a track of
     * nothing, and the track is about what comes back, not only about what leaves. */
    const float mix = (fx == 2) ? synth_app_get_param(SYNTH_PARAM_CHORUS_MIX)
                    : (fx == 3) ? synth_app_get_param(SYNTH_PARAM_DELAY_MIX)
                                : synth_app_get_param(SYNTH_PARAM_VERB_MIX);

    float env;
    float amount;

    if (layer < 0) {
        env = synth_perc_env_published();
        amount = is_send
            ? synth_app_get_param(param) * mix
            : synth_app_get_param(SYNTH_PARAM_PERC_LEVEL);
    } else {
        env = synth_layer_env(layer);

        /* The three drone registers are the only layers with a table slot; the lead has its
         * own pair of parameters and the microphone's are the sensitivity and its send, which
         * is the branch below. A slot of -1 keeps the index inside VIZ_LEVEL_OF. */
        const int slot = (layer >= SYNTH_LAYER_DRONE_LOW && layer <= SYNTH_LAYER_DRONE_HIGH)
                           ? layer - SYNTH_LAYER_DRONE_LOW
                           : -1;

        const float level = (layer == SYNTH_LAYER_LEAD)
            ? synth_app_get_param(SYNTH_PARAM_LEAD_LEVEL)
            : ((slot >= 0) ? synth_app_get_param(VIZ_LEVEL_OF[slot]) : 0.0f);
        const float send = is_send
            ? synth_app_get_param(param)
            : ((layer == SYNTH_LAYER_LEAD)
                   ? synth_app_get_param(SYNTH_PARAM_SEND_LEAD)
                   : ((slot >= 0) ? synth_app_get_param(VIZ_SEND_OF[slot]) : 0.0f));

        amount = is_send ? send * mix : level;
    }

    float v = env * amount;
    if (v < 0.0f) {
        v = 0.0f;
    } else if (v > 1.0f) {
        v = 1.0f;
    }

    return v;
}

/* The source's value, always 0..1, so every track reads the same way round. */
/*
 * В -1..1, КАК ЕСТЬ.
 *
 * Здесь стояло 0.5 * (lfo + 1), то есть перевод в 0..1, — а refresh_viz() переводит
 * биполярную величину в 0..1 ещё раз, своим `0.5 * (v + 1)`. Двойной перевод и был той
 * ошибкой, которую видно глазом: точка модуляции в покое стояла не в середине своей дуги, а
 * на трёх четвертях, и всю дорогу качалась между половиной и концом — ровно «всегда ближе к
 * концу». Перевод в 0..1 должен быть ОДИН, и он в refresh_viz(), рядом с местом, где решается,
 * биполярна величина или нет.
 */
static float viz_value(viz_kind_t kind)
{
    switch (kind) {
    case VIZ_DRONE_LFO:
        return synth_drone_lfo();

    case VIZ_PAN_LFO:
        return synth_layer_lfo(SYNTH_LAYER_DRONE_LOW);

    default:
        return 0.0f;
    }
}


/* Spans of the tracks, kept from the last layout so refresh_viz() has no geometry to do. */
static int16_t       s_viz_start[SECTOR_MAX];
static int16_t       s_viz_sweep[SECTOR_MAX];
static uint8_t       s_viz_kind[SECTOR_MAX];
static int16_t       s_viz_angle[SECTOR_MAX];
static synth_param_t s_viz_param[SECTOR_MAX];
static bool          s_viz_clip[SECTOR_MAX];
static float         s_viz_disp[SECTOR_MAX];

/* The band a meter fills, and what it is filled to, in half degrees of its own sector. */
static lv_obj_t     *s_viz_band[SECTOR_MAX];
static int16_t       s_viz_band_half[SECTOR_MAX];   /* what the band already shows */
static int16_t       s_viz_half[SECTOR_MAX];        /* what it is meant to show */
static lv_color_t    s_viz_band_empty[SECTOR_MAX];
static lv_color_t    s_viz_band_full[SECTOR_MAX];


/*
 * A meter's band, drawn rather than given to an lv_arc.
 *
 * The widget would be the obvious thing and it is the wrong one here: lv_draw_sw_arc builds a
 * circular mask over the widget's whole 286x286 px box before it looks at what is actually
 * dirty, and strokes a full circle border beside it. A fill that moved by one degree therefore
 * cost the same as a fill that appeared from nothing — 2-3 ms measured on this board, five
 * fills on a page. That is what the fills used to be spread over several ticks for, and why
 * they moved at a twelfth of a second while the dots moved at twenty-five.
 *
 * A band is two concentric circles cut by two rays, which is a row of short radial strokes; the
 * renderer draws a stroke without any mask, and only the strokes the refresh area touches are
 * emitted. What a per-frame update costs is then the sliver that changed at both ends, not the
 * sector it lives in.
 */
/* Whether two areas touch: lv_area_intersect lives in LVGL's private headers, and this is the
 * whole of what the band needs from it. */
static bool viz_area_hits(const lv_area_t *a, const lv_area_t *b)
{
    return (a->x1 <= b->x2 && a->x2 >= b->x1 && a->y1 <= b->y2 && a->y2 >= b->y1);
}

/*
 * The same band, drawn as ONE arc instead of a row of strokes.
 *
 * viz_band_span() below paints a pixel of travel at a time, which is the cheap way to repaint
 * the sliver of a band that moved and the expensive way to repaint a whole sector: 72 degrees
 * of a 151 px radius is 190 strokes, and a page of five fills is 1900 of them. Wanted on every
 * frame, that cost is invisible; wanted ONCE, in full, it is what a page snapshot asks for, and
 * it is where the turn spent its time — 50 ms of the 133 ms it takes to turn onto LEVELS and
 * 55 of the 179 to turn from LEVELS to the sends.
 *
 * The geometry is the band's own: the same radius, the same width, the same two colours, so the
 * picture in the snapshot is the picture on the page. The arc is anti-aliased and the strokes
 * are rounded, so a pixel here and there differs between the two ways of drawing it; a snapshot
 * lasts a fifth of a second and is not compared with the original.
 */
static void viz_band_arc(lv_layer_t *layer, int32_t cx, int32_t cy, float from, float to,
                         lv_color_t color)
{
    if (to - from < 0.2f) {
        return;
    }

    while (from < 0.0f) {
        from += 360.0f;
        to += 360.0f;
    }
    while (from >= 360.0f) {
        from -= 360.0f;
        to -= 360.0f;
    }

    lv_draw_arc_dsc_t dsc;
    lv_draw_arc_dsc_init(&dsc);
    dsc.base.layer = layer;
    dsc.color = color;
    dsc.center.x = cx;
    dsc.center.y = cy;
    /* The renderer reads a radius as the stroke's OUTER edge and lays the band inward from
     * it, while this band sits centred on VIZ_R — as the strokes that draw it every frame do.
     * Half a width out, so a snapshot of the band and the band agree. */
    dsc.radius = VIZ_R + VIZ_W / 2;
    dsc.width = VIZ_W;
    dsc.rounded = false;
    dsc.opa = LV_OPA_COVER;

    if (to <= 360.0f) {
        dsc.start_angle = from;
        dsc.end_angle = to;
        lv_draw_arc(layer, &dsc);
        return;
    }

    dsc.start_angle = from;
    dsc.end_angle = 360.0f;
    lv_draw_arc(layer, &dsc);

    dsc.start_angle = 0.0f;
    dsc.end_angle = to - 360.0f;
    lv_draw_arc(layer, &dsc);
}

static void viz_band_span(lv_layer_t *layer, const lv_area_t *clip, int32_t cx, int32_t cy,
                          float from, float to, lv_color_t color)
{
    if (to - from < 0.2f) {
        return;
    }

    /* One pixel of travel along the band's own radius: closer than the eye can separate, and
     * fine enough that a rounded two-pixel stroke overlaps the next one. */
    const float step = 57.29578f / (float)VIZ_R;
    const float step_rad = step * 0.01745329f;
    const float cos_step = cosf(step_rad);
    const float sin_step = sinf(step_rad);

    float c = cosf(from * 0.01745329f);
    float s = sinf(from * 0.01745329f);

    int32_t x_prev = cx + (int32_t)lroundf(c * (float)VIZ_R);
    int32_t y_prev = cy + (int32_t)lroundf(s * (float)VIZ_R);

    lv_draw_line_dsc_t dsc;
    lv_draw_line_dsc_init(&dsc);
    dsc.color = color;
    dsc.width = VIZ_W;
    dsc.opa = LV_OPA_COVER;
    dsc.round_start = 1;
    dsc.round_end = 1;

    const int steps = (int)((to - from) / step + 0.5f);

    for (int k = 0; k < steps; k++) {
        const float nc = c * cos_step - s * sin_step;
        const float ns = s * cos_step + c * sin_step;
        c = nc;
        s = ns;

        const int32_t x = cx + (int32_t)lroundf(c * (float)VIZ_R);
        const int32_t y = cy + (int32_t)lroundf(s * (float)VIZ_R);

        lv_area_t seg;
        seg.x1 = (x < x_prev ? x : x_prev) - VIZ_W;
        seg.x2 = (x > x_prev ? x : x_prev) + VIZ_W;
        seg.y1 = (y < y_prev ? y : y_prev) - VIZ_W;
        seg.y2 = (y > y_prev ? y : y_prev) + VIZ_W;

        if (viz_area_hits(&seg, clip)) {
            dsc.p1.x = x_prev;
            dsc.p1.y = y_prev;
            dsc.p2.x = x;
            dsc.p2.y = y;
            lv_draw_line(layer, &dsc);
        }

        x_prev = x;
        y_prev = y;
    }
}

static void viz_band_draw_cb(lv_event_t *e)
{
    lv_obj_t *obj = lv_event_get_target(e);
    lv_layer_t *layer = lv_event_get_layer(e);

    int i = -1;
    for (int k = 0; k < SECTOR_MAX; k++) {
        if (s_viz_band[k] == obj) {
            i = k;
            break;
        }
    }
    if (i < 0) {
        return;
    }

    lv_area_t box;
    lv_obj_get_coords(obj, &box);

    /* The clip area of the refresh this draw belongs to: the layer carries it while an
     * object's own draw event runs, and every stroke outside it would be thrown away. */
    const lv_area_t clip = layer->_clip_area;
    if (!viz_area_hits(&clip, &box)) {
        return;
    }

    /* The centre the same way lv_arc's get_center() puts it: the radius in from the box's
     * top left, with no padding anywhere — and it is VIZ_OBJ_R, the radius these objects are
     * built at, not VIZ_R, the circle the band is centred on. */
    const int32_t cx = box.x1 + VIZ_OBJ_R;
    const int32_t cy = box.y1 + VIZ_OBJ_R;

    const float a0 = (float)s_viz_start[i];
    const float cut = a0 + (float)s_viz_band_half[i] * 0.5f;
    const float a1 = a0 + (float)s_viz_sweep[i];

    /*
     * A refresh that covers the whole band is a snapshot, or the first frame of a page, and
     * there is nothing to be gained from drawing it a pixel at a time — see viz_band_arc().
     * A refresh of a sliver keeps the strokes, which is what makes a moving fill cheap.
     */
    const bool whole = (clip.x1 <= box.x1 && clip.y1 <= box.y1 &&
                        clip.x2 >= box.x2 && clip.y2 >= box.y2);

    if (whole) {
        viz_band_arc(layer, cx, cy, a0, cut, s_viz_band_full[i]);
        viz_band_arc(layer, cx, cy, cut, a1, s_viz_band_empty[i]);
        return;
    }

    viz_band_span(layer, &clip, cx, cy, a0, cut, s_viz_band_full[i]);
    viz_band_span(layer, &clip, cx, cy, cut, a1, s_viz_band_empty[i]);
}


/*
 * One band of the rim between two angles, drawn straight into the layer: the same primitive an
 * lv_arc is made of, with the radius and the width the arcs themselves use, so the cursor lands
 * on the ring and not near it. An lv_arc cannot draw this — its indicator always starts at the
 * arc's own start angle — which is why the cursor is a draw call here.
 *
 * An angle past 360 means the band crosses the top of the ring, and that is two calls.
 */
static void seg_band_draw(lv_layer_t *layer, int32_t cx, int32_t cy, float a0, float a1, lv_color_t col)
{
    while (a0 >= 360.0f) {
        a0 -= 360.0f;
        a1 -= 360.0f;
    }
    while (a0 < 0.0f) {
        a0 += 360.0f;
        a1 += 360.0f;
    }

    lv_draw_arc_dsc_t dsc;
    lv_draw_arc_dsc_init(&dsc);
    dsc.base.layer = layer;
    dsc.color = col;
    dsc.center.x = cx;
    dsc.center.y = cy;
    dsc.radius = ARC_R_MID + ARC_W_IDLE / 2;
    dsc.width = ARC_W_IDLE;
    dsc.rounded = false;
    dsc.opa = LV_OPA_COVER;

    if (a1 <= 360.0f) {
        dsc.start_angle = a0;
        dsc.end_angle = a1;
        lv_draw_arc(layer, &dsc);
        return;
    }

    dsc.start_angle = a0;
    dsc.end_angle = 360.0f;
    lv_draw_arc(layer, &dsc);

    dsc.start_angle = 0.0f;
    dsc.end_angle = a1 - 360.0f;
    lv_draw_arc(layer, &dsc);
}

/*
 * THE CURSOR OF A LIST, drawn over the rim of every sector that holds one.
 *
 * A LIST IS A CHOICE, NOT A LENGTH. One segment of its sector is lit — the position the knob
 * stands on — and the rest of the ring keeps its plain dark track. Lighting every segment from
 * the start up to the cursor was the first shape of this, and it read as a level meter: "nine
 * sixteenths of the scale" is a quantity that does not exist, and OFF of a two-position knob
 * looked like a half-turned knob.
 *
 * No dividers, either. They were tried at two pixels on the segment edges, and on the panel the
 * ring came out looking bitten rather than ruled: at six sectors the eye reads the rim as one
 * continuous stroke, and the notches of the neighbouring lists turned that stroke into a row of
 * tick marks. The cursor carries the position on its own — its width IS one position — and a
 * list with two positions needs nothing at all, because its cursor is half the sector and half
 * the sector is unmistakable.
 *
 * One object for the whole ring, and a draw call per list sector, only where the paint is
 * going: the geometry comes from the sector table, so there is nothing to add or destroy when
 * the page changes.
 */
static void list_angles(const rim_t *rim, int sector, int idx, int positions,
                        float *a0, float *a1);

static void rim_marks_draw_cb(lv_event_t *e)
{
    lv_obj_t *obj = lv_event_get_target(e);
    if (obj != s_rim_marks) {
        return;
    }

    const ui_page_t *p = page();
    if (!p) {
        return;
    }

    lv_layer_t *layer = lv_event_get_layer(e);

    lv_area_t box;
    lv_obj_get_coords(obj, &box);

    const lv_area_t clip = layer->_clip_area;
    if (!viz_area_hits(&clip, &box)) {
        return;
    }

    const rim_t rim = page_rim();
    const int sel = sel_index();
    const int32_t cx = box.x1 + ARC_OBJ_SIZE / 2;
    const int32_t cy = box.y1 + ARC_OBJ_SIZE / 2;

    /*
     * The cursor of a list is NOT drawn here any more. It is a colour of the ladder in the page's
     * own buffer — the notches the position covers are painted in the value's colour by the same
     * function that paints every other notch — so a cursor cannot land on top of the ladder or
     * outlive it. Only the cuts between sectors are left to this layer.
     */
    (void)rim;
    (void)sel;

    /*
     * The cut between two sectors, drawn last so that a cursor standing at the start of its
     * sector cannot paint over it. Same band as the rings, same two pixels, in the screen's
     * background colour — the colour a gap has to be to show on a lit rim and on a dark one.
     */
    lv_draw_line_dsc_t line;
    lv_draw_line_dsc_init(&line);
    line.color = lv_color_hex(COL_BG);
    line.width = 2;
    line.opa = LV_OPA_COVER;

    const int32_t r_in = ARC_R_MID - ARC_W_IDLE / 2;
    const int32_t r_out = ARC_R_MID + ARC_W_IDLE / 2;

    for (int i = 0; i < rim.count; i++) {
        const float a = (float)rim.spans[i].start * 0.01745329f;
        const float ca = cosf(a);
        const float sa = sinf(a);

        line.p1.x = cx + (int32_t)lroundf(ca * (float)r_in);
        line.p1.y = cy + (int32_t)lroundf(sa * (float)r_in);
        line.p2.x = cx + (int32_t)lroundf(ca * (float)r_out);
        line.p2.y = cy + (int32_t)lroundf(sa * (float)r_out);

        lv_area_t at;
        at.x1 = (line.p1.x < line.p2.x ? line.p1.x : line.p2.x) - 2;
        at.x2 = (line.p1.x > line.p2.x ? line.p1.x : line.p2.x) + 2;
        at.y1 = (line.p1.y < line.p2.y ? line.p1.y : line.p2.y) - 2;
        at.y2 = (line.p1.y > line.p2.y ? line.p1.y : line.p2.y) + 2;

        if (!viz_area_hits(&at, &clip)) {
            continue;
        }

        lv_draw_line(layer, &line);
    }
}

/* Does the sweep from `from` to `to`, clockwise, pass the angle `at`? All in degrees. */
static bool viz_band_crosses(float from, float to, float at)
{
    while (from >= 360.0f) {
        from -= 360.0f;
    }
    while (to >= 360.0f) {
        to -= 360.0f;
    }
    while (from < 0.0f) {
        from += 360.0f;
    }
    while (to < 0.0f) {
        to += 360.0f;
    }

    float span = to - from;
    if (span < 0.0f) {
        span += 360.0f;
    }

    float d = at - from;
    while (d < 0.0f) {
        d += 360.0f;
    }

    return (d > 0.0f && d < span);
}

/* -------------------------------------------------------------------------- */
/* The rim, as pixels                                                         */
/* -------------------------------------------------------------------------- */
/*
 * WHY THE RIM IS A BUFFER AND NOT A SET OF ARCS.
 *
 * A full repaint of a knob page measured 181 ms, and 115 of it were the ring: 85 ms for the
 * six meter fills and 30 for the six sector arcs. Neither number is about pixels — 1800 thin
 * strokes and 12 anti-aliased arcs came out the same — it is the renderer's price per call,
 * about 40 us, plus a 286x286 mask built inside every arc whatever part of it changed.
 *
 * The same ring written straight into a 360x360 buffer is a few thousand stores to memory: no
 * call, no mask, no anti-aliasing to pay for. The buffer is then one picture, and a picture of
 * the whole page blits in 27 ms — less than the ring alone used to cost to draw.
 *
 * The arcs and the bands are not removed, they are demoted: they keep the geometry, the
 * colours and the values, and the functions that always wrote them still do. They are hidden,
 * and everything below reads their state back out of them. That is deliberate — a second copy
 * of the angle arithmetic would be a second place for the picture to drift from the widget.
 */
static lv_draw_buf_t *s_rim_buf;   /* the ring and its meters: 253 KB in PSRAM */
static lv_obj_t      *s_rim_img;   /* the picture over them, under every other child */

/* The transport's ring, a second picture of the same size and the same PSRAM. It is the
 * fallback's replacement, not its partner: when this buffer exists the old lv_arc is hidden,
 * and when it does not the arc is the ring and nothing here runs. */
static lv_draw_buf_t *s_tempo_buf;
static lv_obj_t      *s_tempo_img;       /* under the button, the readouts and the BPM */
static int            s_tempo_drawn = -1; /* lit notches in that picture, -1 before the first */
static uint16_t       s_tempo_bg;         /* the curtain tint the picture was painted over */
static bool           s_tempo_bg_known;

/*
 * One row of a 360x360 RGB565 surface, from x_from to x_to inclusive.
 *
 * The buffer and its stride belong to the caller. The page's ring and the transport's are the
 * same size and are written by the same code, and nothing below this line may know which one
 * it is painting.
 */
static void rim_row_fill_buf(uint16_t *data, size_t stride, int32_t y,
                             int32_t x_from, int32_t x_to, uint16_t px)
{
    if (data == NULL || y < 0 || y >= 360) {
        return;
    }

    if (x_from < 0) {
        x_from = 0;
    }
    if (x_to > 359) {
        x_to = 359;
    }
    if (x_to < x_from) {
        return;
    }

    uint16_t *row = (uint16_t *)((uint8_t *)data + (size_t)y * stride);
    uint32_t *row32 = (uint32_t *)row;
    const uint32_t pair = ((uint32_t)px << 16) | (uint32_t)px;

    /* Two pixels to a store: a clear is the one thing here that writes a lot of PSRAM, and
     * the row starts and the stride are both even, so a half-word store is never needed
     * beyond the two ends. */
    int32_t x = x_from;

    if ((x & 1) != 0) {
        row[x++] = px;
    }
    while (x + 1 <= x_to) {
        row32[x >> 1] = pair;
        x += 2;
    }
    if (x <= x_to) {
        row[x] = px;
    }
}

/* The page's own ring: the same row, in the buffer the page owns. */
static void rim_row_fill(int32_t y, int32_t x_from, int32_t x_to, uint16_t px)
{
    if (s_rim_buf == NULL) {
        return;
    }

    rim_row_fill_buf((uint16_t *)s_rim_buf->data, s_rim_buf->header.stride,
                     y, x_from, x_to, px);
}

/*
 * One annulus sector, filled a scanline at a time.
 *
 * A wedge of less than half a turn is the intersection of two half-planes with the band
 * between two radii, and on a fixed row a half-plane is one comparison on x. The narrowing is
 * two divisions per row and the edge directions are worked out once: nothing here is
 * trigonometric per pixel, and nothing is anti-aliased.
 *
 * A wider wedge cannot be written this way — past half a turn the intersection of the two
 * half-planes is the far side of the circle — so rim_paint_band() splits and never calls this
 * with one.
 */
/*
 * Tuned by eye, and measured where the eye measures it: in pixels of arc at the middle of the
 * band, not in degrees.
 *
 * Degrees are the wrong unit and the reason is on the screen. A pitch fixed in degrees is a
 * pitch fixed along the arc, and where the arc runs across the rows — at the top and the bottom
 * of the ring — the row that carries a notch and the row that carries the next one are a whole
 * pitch apart vertically, so the strokes read as separate. Where the arc runs down the rows, at
 * the sides, the same pitch buys fewer rows and the strokes crowd into each other, which is the
 * moire the equatorial part of the ring showed. A pitch in pixels along the middle radius is
 * the same distance everywhere on the ring, so the ladder looks the same all the way round.
 *
 * TICK_PITCH_PX is the notch and its gap together; TICK_BODY_PX is the stroke itself. The gap
 * is the difference and is never allowed below one pixel, because half a pixel of background is
 * blended away by the panel and the strokes run together again.
 */
#define TICK_PITCH_PX 6
#define TICK_BODY_PX  2

/* The middle radius of the band, where the pitch in pixels is measured. */
#define RIM_TICK_R    ((RIM_INNER + RIM_OUTER) / 2)   /* 169 */

/* Degrees that one pixel of arc is worth at that radius. */
#define RIM_PX_DEG    (57.29578f / (float)RIM_TICK_R)

/*
 * A wedge's two edges, resolved once for a whole row walk.
 *
 * On a row, the x at which a ray meets it is origin + slope * dy, so an edge is one multiply per
 * row — provided its slope and the bound it sets are worked out before the walk rather than
 * inside it. They were divisions inside it, four per row over 352 rows, and that alone was most
 * of the cost of a notch.
 */
typedef struct {
    float  slope[2];
    int8_t role[2];        /* +1 bounds x from below, -1 from above, 0 no bound */
    bool   reject_row;      /* an edge parallel to the rows that this wedge bounds entirely */
    bool   reject_positive; /* the row is out when dy has this sign */
} rim_edges_t;

static rim_edges_t rim_edges_for(float a0, float a1)
{
    const float rad = 0.01745329f;
    const float c[2] = { cosf(a0 * rad), cosf(a1 * rad) };
    const float s[2] = { sinf(a0 * rad), sinf(a1 * rad) };

    rim_edges_t e = { { 0.0f, 0.0f }, { 0, 0 }, false, false };

    for (int k = 0; k < 2; k++) {
        if (fabsf(s[k]) < 1.0e-6f) {
            if (!e.reject_row) {
                e.reject_row = true;
                e.reject_positive = (k == 0) ? (c[k] < 0.0f) : (c[k] > 0.0f);
            }
            continue;
        }

        /*
         * WHICH WAY AN EDGE BOUNDS DEPENDS ON WHICH SIDE OF THE X AXIS IT POINTS TO, not on
         * whether it is the wedge's start or its end.
         *
         * The old rule read the start edge as a lower bound and the end edge as an upper one,
         * and kept one slope per direction: the second ray to claim a direction OVERWROTE the
         * first instead of tightening it. That is only wrong for a wedge whose two rays both
         * bound the same way — which is every stretch that reaches across the three o'clock
         * line, and there are four such spans among the rim tables alone ({300,0} and {315,45}
         * and their images). There the bound came from the wrong ray, and the fill ran past its
         * own sector: painting a sector whose span crosses the x axis erased the notches of its
         * neighbours, which is exactly "the indication disappears from some sectors when the
         * focus moves".
         *
         * Both rays are kept now and both are applied, the tighter bound winning row by row.
         * Two multiplies a row instead of one, and a wedge cannot paint outside itself.
         */
        const int lower = (k == 0) ? (s[k] < 0.0f) : (s[k] > 0.0f);

        e.slope[k] = c[k] / s[k];
        e.role[k] = lower ? 1 : -1;
    }

    return e;
}

static bool rim_edge_bounds(const rim_edges_t *e, float dy, float *lo, float *hi)
{
    const float big = 1.0e9f;

    if (e->reject_row) {
        if (e->reject_positive ? (dy > 0.0f) : (dy < 0.0f)) {
            return false;
        }
    }

    *lo = -big;
    *hi = big;

    for (int k = 0; k < 2; k++) {
        if (e->role[k] == 0) {
            continue;
        }

        const float edge = (float)RIM_ORIGIN + e->slope[k] * dy;

        if (e->role[k] > 0) {
            if (edge > *lo) {
                *lo = edge;
            }
        } else if (edge < *hi) {
            *hi = edge;
        }
    }

    return *hi > *lo;
}

/*
 * One annulus sector, filled a scanline at a time.
 *
 * A wedge of less than half a turn is the intersection of two half-planes with the band
 * between two radii, and on a fixed row a half-plane is one comparison on x. The narrowing is
 * two divisions per row and the edge directions are worked out once: nothing here is
 * trigonometric per pixel, and nothing is anti-aliased.
 *
 * A wider wedge cannot be written this way — past half a turn the intersection of the two
 * half-planes is the far side of the circle — so rim_paint_band() splits and never calls this
 * with one.
 */
/* The pixel ranges of one row inside the annulus and inside [lo, hi] on x: two of them when the
 * row crosses the inner circle, one when it only crosses the outer. */
static int rim_row_spans(float dy, float lo, float hi, int32_t r_in, int32_t r_out,
                         int32_t out[2][2])
{
    /*
     * The radii are the caller's, and they have to be: this used to read the rim band's own
     * 162..176 whatever it was asked for, so every band in the picture came out fourteen pixels
     * wide at the rim. The playhead meters, which are two pixels at 142..144, painted the rim
     * solid over the notches, and the body of the selected sector, the wedge from 52 to 151,
     * landed on the rim instead of behind the middle of the dial.
     */
    const float r_out2 = (float)r_out * (float)r_out;
    const float r_in2 = (float)r_in * (float)r_in;
    const float d2 = dy * dy;

    if (d2 > r_out2) {
        return 0;
    }

    const float x_out = sqrtf(r_out2 - d2);
    const float x_in = (d2 < r_in2) ? sqrtf(r_in2 - d2) : -1.0f;

    int n = 0;

    for (int side = 0; side < 2; side++) {
        float xl;
        float xr;

        if (x_in < 0.0f) {
            if (side > 0) {
                break;
            }
            xl = (float)RIM_ORIGIN - x_out;
            xr = (float)RIM_ORIGIN + x_out;
        } else if (side == 0) {
            xl = (float)RIM_ORIGIN - x_out;
            xr = (float)RIM_ORIGIN - x_in;
        } else {
            xl = (float)RIM_ORIGIN + x_in;
            xr = (float)RIM_ORIGIN + x_out;
        }

        /* A span that misses the wedge entirely stays out, but the test has to be made before
         * the clipping below, which can pinch a span to nothing. */
        if (xr < lo || xl > hi) {
            continue;
        }

        if (xl < lo) {
            xl = lo;
        }
        if (xr > hi) {
            xr = hi;
        }

        out[n][0] = (int32_t)ceilf(xl - 0.5f);
        out[n][1] = (int32_t)floorf(xr - 0.5f);
        n++;
    }

    return n;
}

/*
 * One annulus sector, filled a scanline at a time.
 *
 * A wedge of less than half a turn is the intersection of two half-planes with the band
 * between two radii, and on a fixed row a half-plane is one comparison on x. The narrowing is
 * two divisions per row and the edge directions are worked out once: nothing here is
 * trigonometric per pixel, and nothing is anti-aliased.
 *
 * A wider wedge cannot be written this way — past half a turn the intersection of the two
 * half-planes is the far side of the circle — so rim_paint_band() splits and never calls this
 * with one.
 */
static void rim_wedge_fill_buf(uint16_t *data, size_t stride,
                               int32_t r_in, int32_t r_out, float a0, float a1, uint16_t px)
{
    const rim_edges_t edges = rim_edges_for(a0, a1);

    for (int32_t y = RIM_ORIGIN - RIM_OUTER; y <= RIM_ORIGIN + RIM_OUTER - 1; y++) {
        const float dy = (float)y + 0.5f - (float)RIM_ORIGIN;

        float lo;
        float hi;
        if (!rim_edge_bounds(&edges, dy, &lo, &hi)) {
            continue;
        }

        int32_t spans[2][2];
        const int n = rim_row_spans(dy, lo, hi, r_in, r_out, spans);

        for (int s = 0; s < n; s++) {
            if (spans[s][1] < spans[s][0]) {
                const int32_t mid = (spans[s][0] + spans[s][1] + 1) / 2;

                /*
                 * A ROW NARROWER THAN A PIXEL STILL GETS ITS PIXEL, BUT ONLY INSIDE THE BAND.
                 *
                 * The pinch sits between two ray bounds, and those bounds are straight lines:
                 * where a wedge is thinner than one pixel the middle of the pinch can land half
                 * a pixel OUTSIDE the annulus. That pixel was written anyway, and because every
                 * later pass — the erase of a meter's freed stretch included — is clipped to the
                 * band, nothing could ever paint over it again. It stayed there as a bright speck
                 * behind the falling head of the meter, one per step, along the whole arc the
                 * level had left.
                 *
                 * So the pixel is written only when its own centre is inside the band. The
                 * pinch is then a hairline that is one pixel of the band, not one pixel of the
                 * page next to it.
                 */
                const float dxm = (float)mid + 0.5f - (float)RIM_ORIGIN;
                const float dm2 = dxm * dxm + dy * dy;

                if (dm2 >= (float)r_in * (float)r_in && dm2 < (float)r_out * (float)r_out) {
                    rim_row_fill_buf(data, stride, y, mid, mid, px);
                }
            } else {
                rim_row_fill_buf(data, stride, y, spans[s][0], spans[s][1], px);
            }
        }
    }
}

/* The band between two radii over an angular stretch, in pieces the wedge test can hold. */
static void rim_paint_band_buf(uint16_t *data, size_t stride, float from, float to,
                               int32_t r_in, int32_t r_out, uint16_t px)
{
    if (data == NULL || to - from < 0.15f) {
        return;
    }

    while (to - from > 119.0f) {
        rim_wedge_fill_buf(data, stride, r_in, r_out, from, from + 119.0f, px);
        from += 119.0f;
    }

    rim_wedge_fill_buf(data, stride, r_in, r_out, from, to, px);
}

static void rim_paint_band_u16(float from, float to, int32_t r_in, int32_t r_out, uint16_t px)
{
    if (s_rim_buf == NULL) {
        return;
    }

    rim_paint_band_buf((uint16_t *)s_rim_buf->data, s_rim_buf->header.stride,
                       from, to, r_in, r_out, px);
}

static void rim_paint_band(float from, float to, int32_t r_in, int32_t r_out, lv_color_t colour)
{
    rim_paint_band_u16(from, to, r_in, r_out, lv_color_to_u16(colour));
}

/* The box a stretch of a band covers: its ends sampled along both radii, every cardinal angle
 * it crosses, and the margin a stroke needs. */
static void rim_band_area(float from, float to, int32_t r_in, int32_t r_out, lv_area_t *area)
{
    const float rad = 0.01745329f;

    int32_t x1 = 0;
    int32_t y1 = 0;
    int32_t x2 = 0;
    int32_t y2 = 0;
    bool first = true;

    for (float a = from;; a += 8.0f) {
        const float at = (a > to) ? to : a;

        for (int r = 0; r < 2; r++) {
            const int32_t rr = (r == 0) ? r_in : r_out;
            const int32_t px = RIM_ORIGIN + (int32_t)lroundf(cosf(at * rad) * (float)rr);
            const int32_t py = RIM_ORIGIN + (int32_t)lroundf(sinf(at * rad) * (float)rr);

            if (first) {
                x1 = x2 = px;
                y1 = y2 = py;
                first = false;
            } else {
                if (px < x1) {
                    x1 = px;
                }
                if (px > x2) {
                    x2 = px;
                }
                if (py < y1) {
                    y1 = py;
                }
                if (py > y2) {
                    y2 = py;
                }
            }
        }

        if (at >= to) {
            break;
        }
    }

    if (viz_band_crosses(from, to, 0.0f)) {
        x2 = RIM_ORIGIN + r_out;
    }
    if (viz_band_crosses(from, to, 90.0f)) {
        y2 = RIM_ORIGIN + r_out;
    }
    if (viz_band_crosses(from, to, 180.0f)) {
        x1 = RIM_ORIGIN - r_out;
    }
    if (viz_band_crosses(from, to, 270.0f)) {
        y1 = RIM_ORIGIN - r_out;
    }

    area->x1 = x1 - 2;
    area->y1 = y1 - 2;
    area->x2 = x2 + 2;
    area->y2 = y2 + 2;
}

/* Hands one box of the picture to the panel. The page is the picture, so the box is the whole
 * of the work. */
static void rim_flush(const lv_area_t *area)
{
    if (s_rim_img != NULL) {
        lv_obj_invalidate_area(s_rim_img, area);
    }
}

/*
 * The angle a sector's value has reached, in the frame its background spans.
 *
 * Read back from the arc rather than computed from the value: lv_arc_set_value() maps the
 * value through lv_map() over the arc's own range and keeps the angle, and a second
 * implementation of that mapping is a second thing that can disagree with the widget.
 */
static float rim_indicator_angle(lv_obj_t *arc)
{
    const float start = (float)lv_arc_get_bg_angle_start(arc);
    float cut = (float)lv_arc_get_angle_end(arc);

    while (cut < start) {
        cut += 360.0f;
    }
    while (cut > start + 360.0f) {
        cut -= 360.0f;
    }

    return cut;
}

/*
 * Paints [from, to] of one sector's band: the family's track past the value, the value's own
 * colour up to the angle it has reached. The two ranges meet and never overlap.
 *
 * The START is carried a fraction of a degree back past the sector's own edge, and that overlap
 * is the point: two neighbours share a boundary angle, and a fill that stops exactly on it leaves
 * the boundary column to neither of them — a hairline of the page's background down the joint
 * between every pair of sectors. A fifth of a degree is a pixel and a bit at this radius.
 *
 * THE OVERLAP GOES BACKWARD, NOT FORWARD, and that is not a detail either. Forward, a sector's
 * fill lands on the first pixels of the one painted after it and is overwritten in a full repaint
 * — but a repaint of ONE sector (a tap, a step) has no such successor to clean up: the spill sits
 * in the picture outside the box that was handed to the panel, is not drawn, and shows up later
 * as a wedge of the wrong colour at a sector's edge the moment anything else repaints that area.
 * Backward, the overlap always lands on pixels that were painted before it and are covered by the
 * box this call flushes, so a repaint of one sector can never leave anything behind outside it.
 */
/* How far past the stretch that moved the panel is asked to re-read. The pixels under it are
 * already right in the buffer, so this is slack for the rounding of the box, not for the fill:
 * a degree is four pixels of arc at this radius and covers any edge that lands on a boundary. */
#define STEP_FLUSH_DEG 2.0f

#define RIM_SEAM_DEG 0.4f

/*
 * THE BAND IS A LADDER OF NOTCHES, NOT A CONTINUOUS STRETCH.
 *
 * A continuous fill has an edge that lands wherever the value puts it, which is almost never on a
 * pixel centre: the edge rounds one way or the other, and a stretch narrower than a pixel paints
 * a different set of rows than its neighbour did. Grew in steps, the band therefore accumulated
 * whatever each step managed to cover, and the rows no step reached kept the colour of an older
 * value — the comb, which no amount of overlap, tail or widened window cured, because the picture
 * was the history of the knob rather than a function of it.
 *
 * Quantised, there is no edge to round: the value picks a whole number of notches, the notches
 * sit on a fixed grid of angles, and the state is that number. A step repaints the notches that
 * changed and nothing else, so the cost falls back to what a step should cost, and the picture
 * cannot drift from the value no matter how long the knob is turned.
 *
 * The pitch is in pixels of arc at the middle of the band, and the sweep is divided into a WHOLE
 * number of notches, so the last one ends exactly on the sector's edge and the ladder never
 * sticks out of it.
 */

static void rim_paint_sector(int i, bool ink);

/* rim_bg() is defined further down; the notches below need it. */
static uint16_t rim_bg(void);

/* The notches of one sector: where they start, how wide they are, how many there are. */
typedef struct {
    float start;
    float pitch;
    float body;
    int   count;
} rim_ticks_t;

/* How many notches fit a sweep, counted in pixels along the middle radius. The count is
 * floored, so the notches are never squeezed: what is left over widens the pitch a little
 * instead of shortening the last stroke. */
static int rim_ticks_count(float sweep)
{
    const float sweep_px = sweep * 0.01745329f * (float)RIM_TICK_R;

    int count = (int)floorf(sweep_px / (float)TICK_PITCH_PX);
    if (count < 1) {
        count = 1;
    }

    return count;
}

/* The notch grid of a sweep: where it starts, how wide a notch body is and how many there are.
 *
 * Shared by the page rings and the transport's, so a tick means the same size everywhere. */
static rim_ticks_t rim_ticks_make(float start, float sweep, int count)
{
    rim_ticks_t t;

    t.start = start;
    t.count = count;
    t.pitch = sweep / (float)count;

    /* The stroke is its own size in pixels, and the gap is whatever the pitch leaves over, with
     * one pixel kept back so two strokes can never touch. */
    const float sweep_px = sweep * 0.01745329f * (float)RIM_TICK_R;
    const float pitch_px = sweep_px / (float)count;
    float body_px = (float)TICK_BODY_PX;

    if (body_px > pitch_px - 1.0f) {
        body_px = pitch_px - 1.0f;
    }
    if (body_px < 1.0f) {
        body_px = 1.0f;
    }

    t.body = body_px * RIM_PX_DEG;

    /* On an arc so short that a stroke would be a pixel with no gap at all, the sector is
     * painted solid: a visible band with no strokes beats strokes that erase the band. */
    if (t.body >= t.pitch) {
        t.body = t.pitch;
    }

    return t;
}

static rim_ticks_t rim_ticks_for(const rim_t *rim, int i)
{
    const float sweep = (float)rim_sweep(&rim->spans[i]);

    return rim_ticks_make((float)rim->spans[i].start, sweep, rim_ticks_count(sweep));
}

/* How many notches an angle is worth. This is the whole mapping from the knob to the picture:
 * a rounding to a notch boundary, and no pixel arithmetic anywhere below it. */
static int rim_ticks_at(const rim_ticks_t *t, float angle)
{
    const float sweep = t->pitch * (float)t->count;

    if (sweep <= 0.0f) {
        return 0;
    }

    const float frac = (angle - t->start) / sweep;

    if (!(frac > 0.0f)) {
        return 0;
    }
    if (frac >= 1.0f) {
        return t->count;
    }

    return (int)lroundf(frac * (float)t->count);
}

/*
 * The notches one position of a list covers: [*k0, *k1).
 *
 * A position is a share of the arc, so the mark is as wide as that share, floored to two notches
 * so a long list still leaves a mark that can be seen. The painter and the invalidation both come
 * through here, so a mark cannot be drawn in one place and taken back in another.
 */
static void rim_cursor_ticks(const rim_ticks_t *t, int idx, int positions, int *k0, int *k1)
{
    if (t->count <= 0 || positions <= 1) {
        *k0 = -1;
        *k1 = -1;
        return;
    }

    float frac = (float)idx / (float)positions;
    frac = (frac < 0.0f) ? 0.0f : ((frac > 1.0f) ? 1.0f : frac);

    int k = (int)floorf(frac * (float)t->count);
    if (k < 0) {
        k = 0;
    }
    if (k >= t->count) {
        k = t->count - 1;
    }

    int width = (int)lroundf((float)t->count / (float)positions);
    if (width < 2) {
        width = 2;
    }
    if (k + width > t->count) {
        width = t->count - k;
    }

    *k0 = k;
    *k1 = k + width;
}

/*
 * THE SECTOR AS THE STATE SAYS IT LOOKS, one pixel at a time.
 *
 * The colour of a pixel is a function of where it is and what the instrument is showing, and of
 * nothing else: the body of the selected sector, the notches of the ladder, the stretch the value
 * holds, the stretch a list's cursor holds and the gaps between the notches all come out of this
 * one loop. There is no primitive to get wrong, no band to overlap, no gap to cut back out of a
 * solid stretch, and no memory of the previous frame.
 *
 * This is deliberately the plain way to draw a ring. The clever way — paint the band, paint the
 * fill over it, cut the gaps out of that, and trust that the wedge maths works at every angle —
 * was faster and wrong three times over: the gaps landed only on the sector the maths happened to
 * suit, the playhead meters, which are two pixels at 142..144, painted the whole rim band solid
 * over the notches, and the body of the selected sector landed on the rim instead of behind the
 * middle of the dial. A sector is thirty thousand pixels; a loop that costs a square root and an
 * angle each is a millisecond, and it cannot be right for one sector and wrong for the next.
 */
/*
 * One wedge of a band, filled inside its own box.
 *
 * A pixel is in the wedge when its squared radius is inside the band and it lies between the two
 * boundary rays, and both tests are two products each: no square root, no angle, nothing that
 * could be right for one quadrant and wrong for another. The box comes from the wedge's ends, so
 * the loop never visits more than a few dozen pixels for a notch.
 */
/* The rectangle a write has actually touched. x2 < x1 means nothing was written. */
static void rim_dirty_reset(lv_area_t *area)
{
    area->x1 = 360;
    area->y1 = 360;
    area->x2 = -1;
    area->y2 = -1;
}

static bool rim_dirty_empty(const lv_area_t *area)
{
    return area->x2 < area->x1;
}

static void rim_dirty_add(lv_area_t *area, int32_t x, int32_t y)
{
    if (x < area->x1) {
        area->x1 = (lv_coord_t)x;
    }
    if (y < area->y1) {
        area->y1 = (lv_coord_t)y;
    }
    if (x > area->x2) {
        area->x2 = (lv_coord_t)x;
    }
    if (y > area->y2) {
        area->y2 = (lv_coord_t)y;
    }
}

/*
 * One wedge of a band, filled inside its own box.
 *
 * A pixel is in the wedge when its squared radius is inside the band and it lies between the two
 * boundary rays, and both tests are two products each: no square root, no angle, nothing that
 * could be right for one quadrant and wrong for another. The box comes from the wedge's ends, so
 * the loop never visits more than a few dozen pixels for a notch.
 *
 * `written`, when given, collects the exact rectangle the pixels landed in. The box is only the
 * search area; the panel is asked to re-read what was really written, not what might have been.
 */
static void rim_wedge_px_buf(uint16_t *data, size_t stride,
                             float a0, float a1, int32_t r_in, int32_t r_out,
                             uint16_t px, lv_area_t *written)
{
    if (data == NULL || a1 <= a0) {
        return;
    }

    const float rad = 0.01745329f;

    lv_area_t box;
    rim_band_area(a0, a1, r_in, r_out, &box);

    if (box.x1 < 0) {
        box.x1 = 0;
    }
    if (box.y1 < 0) {
        box.y1 = 0;
    }
    if (box.x2 > (lv_coord_t)(RIM_ORIGIN * 2 - 1)) {
        box.x2 = (lv_coord_t)(RIM_ORIGIN * 2 - 1);
    }
    if (box.y2 > (lv_coord_t)(RIM_ORIGIN * 2 - 1)) {
        box.y2 = (lv_coord_t)(RIM_ORIGIN * 2 - 1);
    }

    const float u0x = cosf(a0 * rad);
    const float u0y = sinf(a0 * rad);
    const float u1x = cosf(a1 * rad);
    const float u1y = sinf(a1 * rad);

    const float ri2 = (float)r_in * (float)r_in;
    const float ro2 = (float)r_out * (float)r_out;

    for (int32_t y = box.y1; y <= box.y2; y++) {
        const float dy = (float)y + 0.5f - (float)RIM_ORIGIN;
        uint8_t *row = (uint8_t *)data + (uint32_t)y * stride;

        for (int32_t x = box.x1; x <= box.x2; x++) {
            const float dx = (float)x + 0.5f - (float)RIM_ORIGIN;
            const float r2 = dx * dx + dy * dy;

            if (r2 < ri2 || r2 >= ro2) {
                continue;
            }

            if ((u0x * dy - u0y * dx) < 0.0f || (dx * u1y - dy * u1x) < 0.0f) {
                continue;
            }

            *(uint16_t *)(row + (uint32_t)x * 2) = px;

            if (written != NULL) {
                rim_dirty_add(written, x, y);
            }
        }
    }
}

/* One notch of a ladder, by index. */
static void rim_tick_paint(uint16_t *data, size_t stride, const rim_ticks_t *t, int k,
                           int32_t r_in, int32_t r_out, uint16_t px, lv_area_t *dirty)
{
    if (data == NULL || t == NULL || k < 0 || k >= t->count) {
        return;
    }

    const float b0 = t->start + t->pitch * (float)k;

    rim_wedge_px_buf(data, stride, b0, b0 + t->body, r_in, r_out, px, dirty);
}

/*
 * THE LADDER OF NOTCHES, in any 360x360 RGB565 surface.
 *
 * This is the whole of the ladder: a pitch in pixels of arc, a body in pixels, and the state
 * deciding the colour of each notch. The callers differ only in the buffer they hand over, the
 * radii and the angular range; the page rings and the transport ring therefore cannot drift
 * apart in pitch, body or gap.
 *
 * Notches [lit_from, lit_to) take the value's colour, the rest take the track's. The gaps are
 * left exactly as they were, which is why the caller must have cleared the band to the colour
 * the gaps are meant to have before calling.
 *
 * `dirty` collects the exact pixels written, for a caller that repaints only a slice.
 */
static void rim_paint_ticks(uint16_t *data, size_t stride,
                            int32_t r_in, int32_t r_out,
                            float start, float sweep, int count,
                            int lit_from, int lit_to,
                            uint16_t lit_px, uint16_t track_px,
                            lv_area_t *dirty)
{
    if (data == NULL || count <= 0) {
        return;
    }

    const rim_ticks_t t = rim_ticks_make(start, sweep, count);

    if (lit_from < 0) {
        lit_from = 0;
    }
    if (lit_to > count) {
        lit_to = count;
    }

    for (int k = 0; k < count; k++) {
        const uint16_t px = (k >= lit_from && k < lit_to) ? lit_px : track_px;

        rim_tick_paint(data, stride, &t, k, r_in, r_out, px, dirty);
    }
}

/*
 * THE SECTOR AS THE STATE SAYS IT LOOKS.
 *
 * The body of the selected sector, then its notches, each notch in the colour the state gives it:
 * the track, the value's colour, or — on a list — the value's colour where the knob's position
 * stands. The gaps between notches are never painted at all; they are the page's own background,
 * left by the clear that precedes this, so there is nothing to cut back out and nothing that can
 * disagree with itself.
 *
 * The colour of every pixel is a function of the value and the selection and of nothing else —
 * not of what the previous frame held, not of which path drew it, not of the order of the calls.
 * The clever way (paint the band, paint the fill over it, cut the gaps out of that) was faster and
 * wrong three times over: the gaps landed only on the sector its maths happened to suit, the
 * playhead meters at 142..144 painted the rim solid over the notches, and the body of the selected
 * sector landed on the rim instead of behind the middle of the dial.
 */
static void rim_paint_sector_state(int i, bool ink)
{
    if (s_rim_buf == NULL || i < 0 || i >= SECTOR_MAX || s_sector_arc[i] == NULL) {
        return;
    }

    const ui_page_t *p = page();
    if (p == NULL || i >= p->knob_count) {
        return;
    }

    const rim_t rim = page_rim();
    if (i >= rim.count) {
        return;
    }

    lv_obj_t *arc = s_sector_arc[i];
    const rim_ticks_t t = rim_ticks_for(&rim, i);

    const float end = t.start + t.pitch * (float)t.count;

    const uint16_t track = lv_color_to_u16(lv_obj_get_style_arc_color(arc, LV_PART_MAIN));
    const uint16_t value = lv_color_to_u16(
        ink ? lv_obj_get_style_arc_color(s_sel_rim, LV_PART_INDICATOR)
            : lv_obj_get_style_arc_color(arc, LV_PART_INDICATOR));

    if (ink) {
        const uint16_t body =
            lv_color_to_u16(lv_obj_get_style_arc_color(s_sel_body, LV_PART_MAIN));

        /*
         * THE WEDGE IS ONE SPAN, AND IT STOPS BEFORE THE METER CIRCLE.
         *
         * It used to reach 151, across the meter's track at 142..144, and was therefore painted
         * as two spans around it. The meter is repainted only when its own level moves, so the
         * pixels the spans skipped stayed background until the level next changed: a
         * half-drawn meter, and a two-pixel ring drawn through the wedge of every selected
         * sector on pages that had no meter to explain it.
         *
         * The circle moved out to 150..152 and the fill stops at 140, so a single span cannot
         * reach a meter at all and there is no ordering rule between the two: whichever is
         * painted last, both are right.
         */
        rim_wedge_px_buf((uint16_t *)s_rim_buf->data, s_rim_buf->header.stride,
                         t.start, end, SEL_BODY_IN, SEL_BODY_OUT, body, NULL);
    }

    /* A LIST IS A CHOICE, NOT A LENGTH: its band is the track, and only the stretch of the
     * position the knob stands on is lit. A value fills from the start of its sector. */
    int filled = 0;
    int cur0 = -1;
    int cur1 = -1;

    const int positions = synth_app_param_steps(p->knobs[i].param);

    if (positions > 1) {
        const int idx = list_index_for(p->knobs[i].param, synth_app_get_param(p->knobs[i].param));
        rim_cursor_ticks(&t, idx, positions, &cur0, &cur1);
    } else {
        filled = rim_ticks_at(&t, rim_indicator_angle(arc));
    }

    /* A value fills [0, filled), a list lights [cur0, cur1); the painter takes the one range
     * either way, so the two are the same ladder with a different pair of ends. */
    const int lit_from = (positions > 1) ? cur0 : 0;
    const int lit_to = (positions > 1) ? cur1 : filled;

    rim_paint_ticks((uint16_t *)s_rim_buf->data, s_rim_buf->header.stride,
                    RIM_INNER, RIM_OUTER,
                    (float)rim.spans[i].start, (float)rim_sweep(&rim.spans[i]), t.count,
                    lit_from, lit_to, value, track, NULL);
}

static void rim_paint_sector(int i, bool ink)
{
    rim_paint_sector_state(i, ink);
}
/* The sector whose body the pixels hold, or -1 when none is. */
static int s_sel_painted = -1;
/* The (family, macro, inverted) triple the painted body was drawn for. The sector alone is
 * not enough: a macro turning on recolours the body without moving it, and a comparison on
 * the index would call that no change and leave the previous tint on the rim. */
static int s_sel_painted_key = -1;

static void rim_paint_sel_body(int i);
static void rim_paint_sector_whole(int i, int sel);

/*
 * A value moved.
 *
 * The band is written FROM THE VALUE, not appended to. Every pixel between the sector's own
 * edges is recomputed from the angle the knob now holds, by the same call the tap and the page
 * change use, so the picture is whatever that value looks like and nothing else. This is the
 * whole difference from the version that grew the band in steps: a step there painted its own
 * narrow dolly and trusted that everything before it was already right, which made the picture
 * an accumulation of steps — and any step that missed a row left that row wrong for good. That
 * is what the comb was, and no amount of overlap, tail or widened window could cure it, because
 * the state itself was the history rather than the value.
 *
 * The cost of not accumulating is that the stretch is a band and not a dolly: about two
 * milliseconds of pixels instead of a tenth of one. The panel, though, is only handed the
 * stretch that actually moved, because outside it the pixels were rewritten with the colours
 * they already had and the panel's copy is still true.
 */
static void rim_paint_sector_step(int i, float was)
{
    if (s_rim_buf == NULL || i < 0 || i >= SECTOR_MAX || s_sector_arc[i] == NULL) {
        return;
    }

    const ui_page_t *p = page();
    if (p == NULL || i >= p->knob_count) {
        return;
    }

    const rim_t rim = page_rim();
    if (i >= rim.count) {
        return;
    }

    const float now = rim_indicator_angle(s_sector_arc[i]);

    if (fabsf(now - was) < 0.05f) {
        return;
    }

    const rim_ticks_t t = rim_ticks_for(&rim, i);

    /*
     * A detent that does not fill one more notch changes nothing on the ring, and that is the
     * common case: a percent of a six-sector ring is a quarter of a notch. Nothing is repainted
     * and nothing is sent to the panel.
     */
    if (rim_ticks_at(&t, now) == rim_ticks_at(&t, was)) {
        return;
    }

    /*
     * Otherwise the sector is written from the state, exactly as a page change writes it. It used
     * to paint the notches that had changed, which made the picture a sum of steps — and a step
     * that missed a row left that row wrong for good. The whole sector is about a millisecond.
     */
    rim_paint_sector_state(i, i == s_sel_painted);

    const float start = (float)rim.spans[i].start;
    lv_area_t area;
    rim_band_area(start - RIM_SEAM_DEG, start + (float)rim_sweep(&rim.spans[i]), SEL_BODY_IN,
                  RIM_OUTER, &area);
    rim_flush(&area);
}

/* The same for a meter: the empty track past the cut, the fill up to it. */
static void rim_paint_meter(int i, float from, float to)
{
    if (s_rim_buf == NULL || i < 0 || i >= SECTOR_MAX) {
        return;
    }

    const viz_kind_t kind = (viz_kind_t)s_viz_kind[i];
    if (kind == VIZ_NONE || !viz_is_meter(kind)) {
        return;
    }

    const float a0 = (float)s_viz_start[i];
    const float a1 = a0 + (float)s_viz_sweep[i];
    const int half = (s_viz_half[i] < 0) ? 0 : s_viz_half[i];
    const float cut = a0 + (float)half * 0.5f;

    if (from < a0) {
        from = a0;
    }
    if (to > a1) {
        to = a1;
    }
    if (to - from < 0.05f) {
        return;
    }

    if (to > cut) {
        rim_paint_band((from > cut) ? from : cut, to, RIM_TRACK_IN, RIM_TRACK_OUT,
                       s_viz_band_empty[i]);
    }
    if (cut > from) {
        rim_paint_band(from, (to < cut) ? to : cut, RIM_TRACK_IN, RIM_TRACK_OUT,
                       s_viz_band_full[i]);
    }
}

/* The page's own background, which is the family's tint and not a constant — see
 * apply_page(). Everything the rim does not paint is this colour. */
static uint16_t s_rim_bg;
static bool     s_rim_bg_known;

static uint16_t rim_bg(void)
{
    return lv_color_to_u16(lv_obj_get_style_bg_color(lv_screen_active(), LV_PART_MAIN));
}


/*
 * THE SELECTION GOES INTO THE PICTURE, NOT ONTO IT.
 *
 * Its body is a wedge from 52 px out to 140, and the meters ride at 150..152 — so a body drawn
 * OVER the picture, which is what the two arcs did while they were visible objects, covered the
 * meter of the very sector it selected and the meter vanished from the panel. Drawn into the
 * picture in the right order it cannot, and since the circle moved outside the wedge the two no
 * longer meet even if the order were wrong: the body goes down first, the meters last.
 *
 * Both pieces stay arcs. They still hold the angles (lv_arc_set_bg_angles) and the colours
 * (arc_color of the main part, and of the indicator for the mark), and the mark still carries the
 * selected sector's value. Nothing here recomputes any of that; it is read back.
 */
static void rim_paint_sel_body(int i)
{
    if (s_rim_buf == NULL || s_sel_body == NULL) {
        return;
    }

    const ui_page_t *p = page();
    if (p == NULL || i < 0 || i >= p->knob_count) {
        return;
    }

    const rim_t rim = page_rim();
    if (i >= rim.count) {
        return;
    }

    const float start = (float)rim.spans[i].start;

    /* No seam overlap here, unlike the band: only one body exists at a time, so the wedge has the
     * page's background on both sides and nothing to meet.
     *
     * One span, ending at SEL_BODY_OUT — the same call rim_paint_sector_state() makes, and the
     * reason that call is now a single span rather than two either side of the meter. */
    const float stop = start + (float)rim_sweep(&rim.spans[i]);
    const lv_color_t body = lv_obj_get_style_arc_color(s_sel_body, LV_PART_MAIN);

    rim_paint_band(start, stop, SEL_BODY_IN, SEL_BODY_OUT, body);
}

/*
 * One sector from the page's background out to the rim.
 *
 * This is what moving the selection costs, and it is the only thing that can erase a body: the
 * wedge reaches in to SEL_BODY_IN, well inside the stretch the ring's own repaint covers, so the
 * body of the sector a tap just left has to be painted over with the background before a new one
 * goes down. Two sectors per tap, never the whole picture.
 */
static void rim_paint_sector_whole(int i, int sel)
{
    if (s_rim_buf == NULL) {
        return;
    }

    const ui_page_t *p = page();
    if (p == NULL || i < 0 || i >= p->knob_count) {
        return;
    }

    const rim_t rim = page_rim();
    if (i >= rim.count) {
        return;
    }

    const float start = (float)rim.spans[i].start;
    const float end = start + (float)rim_sweep(&rim.spans[i]);

    rim_paint_band_u16(start, end, SEL_BODY_IN, RIM_OUTER, rim_bg());

    (void)start;
    (void)end;
    rim_paint_sector(i, i == sel);

    rim_paint_meter(i, (float)s_viz_start[i], (float)s_viz_start[i] + (float)s_viz_sweep[i]);

    lv_area_t area;
    rim_band_area(start - RIM_SEAM_DEG, end, SEL_BODY_IN, RIM_OUTER, &area);
    rim_flush(&area);
}

/*
 * The whole page: the background and nothing else. Built once, and again whenever the family
 * tint behind the ring changes, because then every pixel of the buffer is stale.
 */
static void rim_clear(void)
{
    if (s_rim_buf == NULL) {
        return;
    }

    s_rim_bg = rim_bg();
    s_rim_bg_known = true;

    for (int32_t y = 0; y < 360; y++) {
        rim_row_fill(y, 0, 359, s_rim_bg);
    }
}

/*
 * How far out the ring reaches, and how far in.
 *
 * Out: the outer edge of the sector band at 176, plus two pixels of slack. In: the selected
 * sector's body, which starts at 52 — NOT the meter track at 150, which was the first guess and
 * would have left the body of the previously selected sector lying in the buffer, a wedge of the
 * wrong colour under the next page's cells.
 *
 * Everything between the two radii is background no other part of the picture writes, so a
 * repaint that is not a change of background has no reason to fill the rest of the buffer.
 */
#define RIM_CLEAR_IN   (SEL_BODY_IN - 2)     /* 50 */
#define RIM_CLEAR_OUT  (RIM_OUTER + 2)       /* 178 */

static void rim_clear_ring(void)
{
    if (s_rim_buf == NULL) {
        return;
    }

    const uint16_t px = rim_bg();
    const float out2 = (float)RIM_CLEAR_OUT * (float)RIM_CLEAR_OUT;
    const float in2 = (float)RIM_CLEAR_IN * (float)RIM_CLEAR_IN;

    for (int32_t y = RIM_ORIGIN - RIM_CLEAR_OUT; y <= RIM_ORIGIN + RIM_CLEAR_OUT; y++) {
        const float dy = (float)y + 0.5f - (float)RIM_ORIGIN;
        const float d2 = dy * dy;

        if (d2 > out2) {
            continue;
        }

        const float xo = sqrtf(out2 - d2);

        if (d2 >= in2) {
            rim_row_fill(y, RIM_ORIGIN - (int32_t)ceilf(xo), RIM_ORIGIN + (int32_t)ceilf(xo),
                         px);
            continue;
        }

        const float xi = sqrtf(in2 - d2);

        rim_row_fill(y, RIM_ORIGIN - (int32_t)ceilf(xo), RIM_ORIGIN - (int32_t)floorf(xi), px);
        rim_row_fill(y, RIM_ORIGIN + (int32_t)floorf(xi), RIM_ORIGIN + (int32_t)ceilf(xo), px);
    }
}

/*
 * The ring from nothing: the page's background, every sector's band, every meter's.
 *
 * Called from refresh_arcs(), the one function a page change and a macro change both come
 * through — the same two callers that used to pay for a full screen of arc drawing. The
 * picture is repainted whole and invalidated whole, because a page change is a page repaint.
 */
static void rim_repaint_all(void)
{
    if (s_rim_buf == NULL) {
        return;
    }

    const uint16_t bg = rim_bg();

    if (!s_rim_bg_known || bg != s_rim_bg) {
        rim_clear();
    } else {
        rim_clear_ring();
    }

    const ui_page_t *p = page();

    if (p != NULL) {
        const rim_t rim = page_rim();
        const int n = (p->knob_count < rim.count) ? p->knob_count : rim.count;

        for (int i = 0; i < n; i++) {
            rim_paint_sector(i, i == s_sel_painted);
        }

        const int count = (p->knob_count < SECTOR_MAX) ? p->knob_count : SECTOR_MAX;

        for (int i = 0; i < count; i++) {
            rim_paint_meter(i, (float)s_viz_start[i],
                            (float)s_viz_start[i] + (float)s_viz_sweep[i]);
        }

        /*
         * The pixels now hold the target. Saying so is what keeps the first tick after a
         * landing from painting the band again as if nothing had been drawn: the fill it
         * wants is the fill that is already there, so only a real change costs anything.
         */
        for (int i = 0; i < SECTOR_MAX; i++) {
            s_viz_band_half[i] = (i < count) ? s_viz_half[i] : -1;
        }

        /*
         * The selection is NOT drawn here, and the count says none is: refresh_sectors() runs
         * right after this on both paths that reach it, and it is the function that sets the
         * body's angles for the new page. Painting a body from the angles of the page being
         * left, into a picture that already belongs to the page being entered, would put a
         * wedge of it in the wrong sector for one frame.
         */
        s_sel_painted = -1;
        s_sel_painted_key = -1;
    }

    if (s_rim_img != NULL) {
        lv_obj_invalidate(s_rim_img);
    }
}

/* The transport's ladder: the whole rim, a notch grid of the same pitch and body as a page's. */
static rim_ticks_t tempo_ticks(void)
{
    return rim_ticks_make(TEMPO_RING_START, TEMPO_RING_SWEEP,
                          rim_ticks_count(TEMPO_RING_SWEEP));
}

/* The knob's value, quantised the same way the arc quantised it. */
static int32_t tempo_value_of(float tempo)
{
    int32_t value = (int32_t)(tempo * (float)TRANSPORT_TEMPO_STEPS + 0.5f);

    if (value < 0) {
        value = 0;
    } else if (value > TRANSPORT_TEMPO_STEPS) {
        value = TRANSPORT_TEMPO_STEPS;
    }

    return value;
}

/* How many notches that value lights, by the same rounding the page rings use. */
static int tempo_filled_ticks(const rim_ticks_t *t, int32_t value)
{
    const float angle = t->start
                        + TEMPO_RING_SWEEP * (float)value / (float)TRANSPORT_TEMPO_STEPS;

    return rim_ticks_at(t, angle);
}

static void tempo_ring_set_value(int32_t value);

/* The picture outside the band, repainted in a new curtain tint.
 *
 * The band itself does not depend on that tint: its gaps are COL_BG and its notches are the
 * track and the accent, all three independent of the family behind the curtain. So a family
 * change only has to rewrite what lies outside the annulus, and the notches stay as they are.
 */
static void tempo_ring_fill_outside(uint16_t *data, size_t stride, uint16_t bg)
{
    const float ro2 = (float)RIM_OUTER * (float)RIM_OUTER;
    const float ri2 = (float)RIM_INNER * (float)RIM_INNER;

    for (int y = 0; y < 360; y++) {
        const float dy = (float)y + 0.5f - (float)RIM_ORIGIN;
        const float dy2 = dy * dy;

        if (dy2 >= ro2) {
            rim_row_fill_buf(data, stride, y, 0, 359, bg);
            continue;
        }

        const float wo = sqrtf(ro2 - dy2);

        /* Pixel centres, not pixel corners: x is outside when x + 0.5 is beyond the circle. */
        const int32_t out_end = (int32_t)ceilf(179.5f - wo) - 1;
        const int32_t out_start = (int32_t)floorf(179.5f + wo) + 1;

        if (out_end >= 0) {
            rim_row_fill_buf(data, stride, y, 0, out_end, bg);
        }
        if (out_start <= 359) {
            rim_row_fill_buf(data, stride, y, out_start, 359, bg);
        }

        if (dy2 >= ri2) {
            continue;
        }

        const float wi = sqrtf(ri2 - dy2);
        const int32_t in_start = (int32_t)floorf(179.5f - wi) + 1;
        const int32_t in_end = (int32_t)ceilf(179.5f + wi) - 1;

        if (in_end >= in_start) {
            rim_row_fill_buf(data, stride, y, in_start, in_end, bg);
        }
    }
}

/* Column of a value: the whole picture, from the background up. */
static void tempo_ring_paint_all(void)
{
    if (s_tempo_buf == NULL || s_tempo_img == NULL || s_transport == NULL) {
        return;
    }

    uint16_t *data = (uint16_t *)s_tempo_buf->data;
    const size_t stride = s_tempo_buf->header.stride;

    /* The picture covers the whole transport, so what is outside the band has to be the
     * curtain's own colour — the family tint the old arc was drawn over. The gaps are the
     * page's background, as they are on every page ring. */
    const uint16_t bg = lv_color_to_u16(
        lv_obj_get_style_bg_color(s_transport, LV_PART_MAIN));
    const uint16_t gap = lv_color_to_u16(lv_color_hex(COL_BG));
    const uint16_t track = lv_color_to_u16(lv_color_hex(COL_ARC_BG));
    const uint16_t lit = lv_color_to_u16(lv_color_hex(COL_ACCENT));
    const int32_t value = tempo_value_of(synth_app_tempo_now(NULL));

    /* A tint the picture already wears costs nothing: the notches are the only thing that
     * can have moved, and only between the value they show and the one asked for. */
    if (s_tempo_bg_known && bg == s_tempo_bg && s_tempo_drawn >= 0) {
        tempo_ring_set_value(value);
        return;
    }

    if (s_tempo_bg_known && s_tempo_bg != bg && s_tempo_drawn >= 0) {
        tempo_ring_fill_outside(data, stride, bg);
        s_tempo_bg = bg;
        tempo_ring_set_value(value);
        return;
    }

    for (int y = 0; y < 360; y++) {
        rim_row_fill_buf(data, stride, y, 0, 359, bg);
    }

    rim_paint_band_buf(data, stride, TEMPO_RING_START, TEMPO_RING_START + TEMPO_RING_SWEEP,
                       RIM_INNER, RIM_OUTER, gap);

    const rim_ticks_t t = tempo_ticks();
    const int filled = tempo_filled_ticks(&t, value);

    rim_paint_ticks(data, stride, RIM_INNER, RIM_OUTER,
                    TEMPO_RING_START, TEMPO_RING_SWEEP, t.count,
                    0, filled, lit, track, NULL);

    s_tempo_drawn = filled;
    s_tempo_bg = bg;
    s_tempo_bg_known = true;

    lv_obj_invalidate(s_tempo_img);
}

/* Repaint only the notches the value moved between, and hand the panel exactly the rectangle
 * those notches wrote. */
static void tempo_ring_set_value(int32_t value)
{
    if (s_tempo_buf == NULL || s_tempo_img == NULL || s_tempo_drawn < 0) {
        return;
    }

    const rim_ticks_t t = tempo_ticks();
    const int now = tempo_filled_ticks(&t, value);

    if (now == s_tempo_drawn) {
        return;
    }

    const int lo = (now < s_tempo_drawn) ? now : s_tempo_drawn;
    const int hi = (now > s_tempo_drawn) ? now : s_tempo_drawn;

    uint16_t *data = (uint16_t *)s_tempo_buf->data;
    const size_t stride = s_tempo_buf->header.stride;
    const uint16_t track = lv_color_to_u16(lv_color_hex(COL_ARC_BG));
    const uint16_t lit = lv_color_to_u16(lv_color_hex(COL_ACCENT));

    lv_area_t dirty;
    rim_dirty_reset(&dirty);

    for (int k = lo; k < hi; k++) {
        const uint16_t px = (k < now) ? lit : track;

        rim_tick_paint(data, stride, &t, k, RIM_INNER, RIM_OUTER, px, &dirty);
    }

    s_tempo_drawn = now;

    if (!rim_dirty_empty(&dirty)) {
        lv_obj_invalidate_area(s_tempo_img, &dirty);
    }
}

/*
 * The area a stretch of the band covers, in absolute coordinates.
 *
 * Worked out here rather than handed to lv_draw_arc_get_area(), which reads its radius as the
 * OUTER edge of a stroke with the band lying inward from it. This band is centred on the
 * arc's radius, so the outer half of every stroke fell outside every area the widget asked to
 * have repainted: those pixels were never painted over, and a fill that had fallen left the
 * bright outer edge of its old peak sitting on the rim.
 *
 * The corner rays bound the stretch; a cardinal angle inside it puts a bulge of the circle
 * into the box, and those are added one by one.
 */
static void viz_band_area(int32_t cx, int32_t cy, float from, float to, lv_area_t *area)
{
    const int32_t r_in  = VIZ_R - VIZ_W / 2 - 2;
    const int32_t r_out = VIZ_R + VIZ_W / 2 + 2;

    const float angles[2] = { from * 0.01745329f, to * 0.01745329f };
    const int32_t radii[2] = { r_in, r_out };

    int32_t x1 = 0;
    int32_t y1 = 0;
    int32_t x2 = 0;
    int32_t y2 = 0;
    bool first = true;

    for (int a = 0; a < 2; a++) {
        for (int r = 0; r < 2; r++) {
            const int32_t px = cx + (int32_t)lroundf(cosf(angles[a]) * (float)radii[r]);
            const int32_t py = cy + (int32_t)lroundf(sinf(angles[a]) * (float)radii[r]);

            if (first) {
                x1 = x2 = px;
                y1 = y2 = py;
                first = false;
            } else {
                if (px < x1) {
                    x1 = px;
                }
                if (px > x2) {
                    x2 = px;
                }
                if (py < y1) {
                    y1 = py;
                }
                if (py > y2) {
                    y2 = py;
                }
            }
        }
    }

    if (viz_band_crosses(from, to, 0.0f)) {
        x2 = cx + r_out;
    }
    if (viz_band_crosses(from, to, 90.0f)) {
        y2 = cy + r_out;
    }
    if (viz_band_crosses(from, to, 180.0f)) {
        x1 = cx - r_out;
    }
    if (viz_band_crosses(from, to, 270.0f)) {
        y1 = cy - r_out;
    }

    /* A stroke is a line two pixels wide with rounded ends and its edge pixels are blended,
     * so the corner rays are not quite the whole of it. Two pixels of margin each way is
     * cheaper than the arithmetic that would prove it exact. */
    area->x1 = x1 - 2;
    area->y1 = y1 - 2;
    area->x2 = x2 + 2;
    area->y2 = y2 + 2;
}

/* Fills the band of sector i to `half` half-degrees, repainting only what that changed. */
static void viz_band_set(int i, int half)
{
    if (i < 0 || i >= SECTOR_MAX) {
        return;
    }

    s_viz_half[i] = (int16_t)half;

    const int old = s_viz_band_half[i];
    if (half == old) {
        return;
    }
    s_viz_band_half[i] = (int16_t)half;

    const float a0 = (float)s_viz_start[i];
    const float a1 = a0 + (float)s_viz_sweep[i];

    /*
     * The pixels of the page come first and the panel second: the band is written into the
     * page's own buffer, and what the panel is asked for is only the stretch that changed —
     * the same sliver the strokes used to be emitted for.
     */
    if (s_rim_buf != NULL) {
        lv_area_t area;

        if (old < 0) {
            /* Nothing painted yet: the whole band is new, here and on the panel. */
            rim_paint_meter(i, a0, a1);
            viz_band_area(RIM_ORIGIN, RIM_ORIGIN, a0, a1, &area);
        } else {
            const int lo = (old < half) ? old : half;
            const int hi = (old < half) ? half : old;
            const float from = a0 + (float)lo * 0.5f;
            const float to = a0 + (float)hi * 0.5f;

            rim_paint_meter(i, from, to);
            viz_band_area(RIM_ORIGIN, RIM_ORIGIN, from, to, &area);
        }

        rim_flush(&area);
        return;
    }

    /* No buffer: the band is a visible object again and draws itself. */
    if (old < 0) {
        lv_obj_invalidate(s_viz_band[i]);
        return;
    }

    const int lo = (old < half) ? old : half;
    const int hi = (old < half) ? half : old;

    lv_area_t box;
    lv_obj_get_coords(s_viz_band[i], &box);

    lv_area_t area;
    viz_band_area(box.x1 + VIZ_OBJ_R, box.y1 + VIZ_OBJ_R,
                  (float)s_viz_start[i] + (float)lo * 0.5f,
                  (float)s_viz_start[i] + (float)hi * 0.5f,
                  &area);
    lv_obj_invalidate_area(s_viz_band[i], &area);
}

/*
 * Places the track on sector i: the sector's span, less the dot's own width at each end,
 * and hidden when the parameter has no source. Called from layout_sectors(), which runs on
 * a page change — the one moment the geometry is known to have changed.
 */
static void viz_place(int i, synth_param_t param, const rim_span_t *span)
{
    const viz_kind_t kind = viz_for(param);
    const bool used = (kind != VIZ_NONE);

    /* A dot rides an arc; a fill is its own band and needs no track under it. */
    lv_obj_set_hidden(s_viz_arc[i], !used || viz_is_meter(kind));
    lv_obj_set_hidden(s_viz_dot[i], !used || viz_is_meter(kind));

    /* A fill lives in the page's buffer when there is one and is never a visible object;
     * without a buffer it is the band object that draws it again. */
    if (s_rim_buf == NULL) {
        lv_obj_set_hidden(s_viz_band[i], !used || !viz_is_meter(kind));
    }

    s_viz_kind[i] = (uint8_t)kind;
    s_viz_param[i] = param;
    if (!used) {
        return;
    }

    const int sweep = rim_sweep(span);
    int start = span->start;
    int end = span->end;

    /* A sector narrower than the two insets keeps its whole span: better a dot that touches
     * the boundary than a track that has gone on holiday. */
    if (sweep > 2 * VIZ_INSET_DEG + 2) {
        start = (start + VIZ_INSET_DEG) % 360;
        end = (end - VIZ_INSET_DEG + 360) % 360;
    }

    /*
     * The track belongs to the section it sits in. Its empty part is the family's own
     * hairline colour at background depth — the same colour the rim's thin line and the
     * curtain's chips use — and its fill and its dot are the family's bright step. On a
     * violet page the motion reads violet; nothing here has to be taught which page it is on.
     */
    const nav_group_color_t *gc = &GROUP_COLOR[page()->group];

    lv_arc_set_bg_angles(s_viz_arc[i], start, end);
    lv_arc_set_value(s_viz_arc[i], 0);
    lv_obj_set_style_arc_color(s_viz_arc[i], lv_color_hex(tint(gc->rim, 96)), LV_PART_MAIN);
    lv_obj_set_style_arc_color(s_viz_arc[i], lv_color_hex(gc->bright), LV_PART_INDICATOR);
    lv_obj_set_style_bg_color(s_viz_dot[i], lv_color_hex(gc->bright), LV_PART_MAIN);

    s_viz_band_empty[i] = lv_color_hex(tint(gc->rim, 96));
    s_viz_band_full[i] = lv_color_hex(gc->bright);

    s_viz_start[i] = (int16_t)start;
    s_viz_sweep[i] = (int16_t)((end - start + 360) % 360);
    if (s_viz_sweep[i] <= 0) {
        s_viz_sweep[i] = (int16_t)sweep;
    }

    s_viz_angle[i] = -1;   /* force the first refresh to move the dot */
    s_viz_half[i] = 0;     /* nothing has been asked of the band yet */
    s_viz_band_half[i] = -1;   /* and the band to paint itself whole */
    s_viz_clip[i] = false;
    s_viz_disp[i] = 0.0f;

    /* The band is repainted from the page's own repaint, which follows this function —
     * layout_sectors() ends in refresh_arcs(). Only the object path has to ask. */
    if (s_rim_buf == NULL) {
        lv_obj_invalidate(s_viz_band[i]);
    }
}

/*
 * Moves every dot to where its source is now, and fills every meter.
 *
 * Angles rather than a full redraw: the dot is an 8 px object aligned by offset, so a move
 * invalidates the old square and the new one and nothing else, and a fill is a stretch of its
 * own band, invalidated between the angle it had and the angle it has. Nothing is touched
 * when nothing changed, which is
 * the common case on a slow drift.
 */
static void refresh_viz(void)
{
    const ui_page_t *p = page();
    const nav_group_color_t *gc = &GROUP_COLOR[p->group];
    const int count = (p->knob_count < SECTOR_MAX) ? p->knob_count : SECTOR_MAX;

    /*
     * EVERY FILL EVERY TICK, the same rate as the dots.
     *
     * The fills used to take turns, one per two ticks, because each of them was an lv_arc and
     * every redraw of an lv_arc costs a full 286x286 px mask inside the renderer whatever part
     * of it changed. With the band drawn by hand (see viz_band_draw_cb()) that reason is gone:
     * a fill that moves by half a degree emits the two or three strokes that changed. Measured
     * on this board with all five fills of LEVELS moving at once: 8-15 ms a frame and 22-31 %
     * of the display core before, 3-4 ms and 7-10 % now.
     *
     * The step below is what keeps this from being work for nothing: a band that has not moved
     * by half a degree is not repainted at all, which is the common case for a steady drone.
     */
    for (int i = 0; i < count; i++) {
        const viz_kind_t kind = (viz_kind_t)s_viz_kind[i];
        if (kind == VIZ_NONE) {
            continue;
        }

        if (viz_is_meter(kind)) {
            /*
             * The number the part produces is a sequence of block peaks, and a peak is not
             * a motion: drawn as it arrives, a fill jumps in whatever steps the blocks give
             * it. So the reading is given a body. A rise is taken at once — a hit has to
             * arrive on the hit — and a fall follows a one-pole curve, which is what a level
             * physically does when the sound stops and what the eye reads as settling rather
             * than as a stutter.
             */
            /*
             * The duck is the one fill that does not read a part's level: what it shows is
             * how far the drum is holding the low end down right now, so a player can put
             * the shape he sees against the shape he hears. At zero the fill is empty by
             * itself, which is the honest picture of a knob that is doing nothing.
             */
            const float target = (kind == VIZ_DUCK) ? synth_rack_duck_depth()
                                : (kind == VIZ_PERC_MIX)
                                    ? viz_perc_mix(s_viz_param[i])
                                    : viz_meter(s_viz_param[i]);
            float disp = s_viz_disp[i];

            /*
             * Both directions are rate-limited, and the limit is what keeps a fill cheap as
             * well as readable: a rise takes at most a tenth of the sector in a tick, so the
             * area to repaint is a few degrees whatever the signal did, and a fill that
             * jumped from nothing to full would otherwise repaint its whole sector in one
             * frame. A tenth per tick is full scale in ten ticks, a third of a second, which
             * is faster than a hit needs to be believed.
             */
            if (target > disp) {
                float rise = target - disp;
                if (rise > 0.10f) {
                    rise = 0.10f;
                }
                disp += rise;
            } else {
                float fall = (disp - target) * 0.30f;
                if (fall > 0.06f) {
                    fall = 0.06f;
                }
                disp -= fall;
            }
            s_viz_disp[i] = disp;

            /* Half degrees of the sector: one and a quarter pixels out here, which is the
             * finest step the band can show, so a fill moves as smoothly as a dot. */
            const int sweep2 = s_viz_sweep[i] * 2;
            int half = (int)(disp * (float)sweep2 + 0.5f);
            if (half < 0) {
                half = 0;
            } else if (half > sweep2) {
                half = sweep2;
            }
            viz_band_set(i, half);

            /* Recoloured only when the fill changes side of the ceiling: that one repaints
             * the whole band, and the colour is the same for most of the rise. */
            const bool clip = (disp > 0.9f);
            if (clip != s_viz_clip[i]) {
                s_viz_clip[i] = clip;
                s_viz_band_full[i] = lv_color_hex(clip ? COL_VIZ_CLIP : gc->bright);

                /* The colour belongs to the whole band, so the whole band is painted again. */
                if (s_rim_buf != NULL) {
                    const float a0 = (float)s_viz_start[i];
                    const float a1 = a0 + (float)s_viz_sweep[i];
                    lv_area_t area;

                    rim_paint_meter(i, a0, a1);
                    viz_band_area(RIM_ORIGIN, RIM_ORIGIN, a0, a1, &area);
                    rim_flush(&area);
                } else {
                    lv_obj_invalidate(s_viz_band[i]);
                }
            }
            continue;
        }

        float v = viz_value(kind);

        /*
         * The LFOs are bipolar and the envelopes are not. A dot travels the sector from one
         * end to the other, so a dot driven by a sine has to be mapped from -1..1 onto that
         * travel; clamped instead of mapped, the whole negative half of every cycle sat
         * against the start of the sector and the dot looked frozen.
         */
        if (viz_is_bipolar(kind)) {
            v = 0.5f * (v + 1.0f);
        }

        if (v < 0.0f) {
            v = 0.0f;
        } else if (v > 1.0f) {
            v = 1.0f;
        }

        /*
         * ТОЧКА НА WIDTH ХОДИТ ПО ШИРИНЕ, А НЕ ПО ВСЕЙ ДУГЕ.
         *
         * У остальных адресатов точка показывает саму величину, и полная дуга — правда. У
         * WIDTH величина — это ГЛУБИНА, с которой качается дрон: при нуле он стоит, при
         * единице проходит дугу целиком. Точка, которая качается от края до края при WIDTH в
         * нуле, показывала модуляцию, которой нет, — владелец это и увидел.
         *
         * Поэтому размах умножается на саму ручку: середина дуги — покой, и от неё точка
         * расходится ровно на столько, на сколько её отпустила WIDTH.
         */
        if (s_viz_param[i] == SYNTH_PARAM_MOTION_DEPTH) {
            const float width = synth_app_get_param(SYNTH_PARAM_MOTION_DEPTH);
            v = 0.5f + (v - 0.5f) * ((width < 0.0f) ? 0.0f : ((width > 1.0f) ? 1.0f : width));
        }

        int angle = (int)s_viz_start[i] + (int)((float)s_viz_sweep[i] * v);
        angle %= 360;
        if (angle < 0) {
            angle += 360;
        }
        if (angle == s_viz_angle[i]) {
            continue;
        }
        s_viz_angle[i] = (int16_t)angle;

        const int x = (int)((int32_t)VIZ_R * lv_trigo_cos(angle) / 32767);
        const int y = (int)((int32_t)VIZ_R * lv_trigo_sin(angle) / 32767);
        lv_obj_align(s_viz_dot[i], LV_ALIGN_CENTER, x, y);
    }
}
/*
 * One frame of the waveform: the master's block as a line, DC where the signal is.
 *
 * The samples are the rack's own output after the master level and the compressor, so a
 * silent instrument draws a flat line on the equator and nothing else: no idle animation
 * pretending to be sound. The points are written in place — lv_line keeps the array — and the
 * vertical scale is fixed, which makes the height of the line mean something.
 */
static void wave_advance(void)
{
    static float samples[WAVE_POINTS];

    const int n = synth_rack_scope(samples, WAVE_POINTS);

    for (int i = 0; i < WAVE_POINTS; i++) {
        float v = (i < n) ? samples[i] * WAVE_GAIN : 0.0f;

        if (v > 1.0f) {
            v = 1.0f;
        } else if (v < -1.0f) {
            v = -1.0f;
        }

        s_wave_pts[i].x = (lv_value_precise_t)((int32_t)i * WAVE_W / (WAVE_POINTS - 1));
        s_wave_pts[i].y = (lv_value_precise_t)(WAVE_H / 2 - (int)(v * (float)WAVE_AMP));
    }

    lv_line_set_points(s_wave, s_wave_pts, WAVE_POINTS);
}

static void layout_sectors(void)
{
    const ui_page_t *p = page();
    const rim_t rim = page_rim();

    /*
     * Bounded by the rim's own length rather than by the page's count. The two are
     * equal for every page the instrument has — NK() takes the count from the table and
     * each rim is asserted to its own length — and this is the line that still holds if
     * they ever are not. The per-sector widgets are sized SECTOR_MAX, so the loop bound
     * stays that; a page with no rim at all draws nothing.
     */
    const int count = (p->knob_count < rim.count) ? p->knob_count : rim.count;
    if (count != p->knob_count) {
        ESP_LOGE(TAG, "%s asks for %d sectors and the rim holds %d — drawing %d",
                 p->title, p->knob_count, rim.count, count);
    }

    /* The selection's fill and value mark are ONE pair rather than one per sector, so
     * they are hidden with the sectors: a page with no sectors has nothing to select.
     * Their angles are set in refresh_sectors(), which is where the selection lives. */
    /*
     * The two selection arcs are carriers only while the page has a picture: they hold the
     * angles, the colours and the mark's value, and rim_paint_sel_body() turns them into
     * pixels. A visible arc here would draw a second, identical wedge over the one in the
     * picture — and, being above it, would cover the meter of the sector it selects, which is
     * the fault this whole arrangement exists to fix. Without a buffer they are the picture.
     */
    const bool sel_hidden = (count == 0) || (s_rim_buf != NULL);

    lv_obj_set_hidden(s_sel_body, sel_hidden);
    lv_obj_set_hidden(s_sel_rim, sel_hidden);

    for (int i = 0; i < SECTOR_MAX; i++) {
        const bool used = (i < count);

        /* The rim is pixels when the page has a buffer; the arcs stay as its geometry and are
         * never shown. Without a buffer they are the drawing again — see rim_paint_band(). */
        if (s_rim_buf == NULL) {
            lv_obj_set_hidden(s_sector_arc[i], !used);
        }

        lv_obj_set_hidden(s_sector_touch[i], !used);
        lv_obj_set_hidden(s_sector_panel[i], !used);
        lv_obj_set_hidden(s_sector_name[i], !used);
        lv_obj_set_hidden(s_sector_value[i], !used);

        if (!used) {
            /*
             * The visualisation objects are shared by every page, so a slot this page does
             * not use has to be cleared here as well. Without this the tracks of a page with
             * five sectors stay on screen under a page with two — which is what a thin arc
             * halfway across the master page was.
             */
            lv_obj_set_hidden(s_viz_arc[i], true);
            lv_obj_set_hidden(s_viz_band[i], true);
            lv_obj_set_hidden(s_viz_dot[i], true);
            s_viz_kind[i] = VIZ_NONE;
            s_viz_half[i] = 0;
            s_viz_band_half[i] = -1;
            continue;
        }

        const rim_span_t *s = &rim.spans[i];
        int ax, ay;
        rim_anchor(s, &ax, &ay);

        lv_arc_set_bg_angles(s_sector_arc[i], s->start, s->end);
        lv_obj_align(s_sector_panel[i], LV_ALIGN_CENTER, ax, ay);
        lv_obj_align(s_sector_name[i], LV_ALIGN_CENTER, ax, ay + NAME_DY);
        lv_obj_align(s_sector_value[i], LV_ALIGN_CENTER, ax, ay + VALUE_DY);

        /* The touch area follows the block rather than covering the whole
         * wedge. A hand-sized target centred on the text is easier to hit than
         * a polar region, and it leaves the rest of the rim free for swipes. */
        lv_obj_align(s_sector_touch[i], LV_ALIGN_CENTER, ax, ay);

        viz_place(i, p->knobs[i].param, s);
    }

    int angles[DIV_MAX];
    const int n = rim_dividers(rim, angles);

    for (int i = 0; i < DIV_MAX; i++) {
        if (i >= n) {
            lv_obj_set_hidden(s_divider[i], true);
            continue;
        }

        const int32_t c = lv_trigo_cos(angles[i]);
        const int32_t s = lv_trigo_sin(angles[i]);

        s_divider_pts[i][0].x = DIV_ORIGIN + (int32_t)DIV_R_IN * c / 32767;
        s_divider_pts[i][0].y = DIV_ORIGIN + (int32_t)DIV_R_IN * s / 32767;
        s_divider_pts[i][1].x = DIV_ORIGIN + (int32_t)DIV_R_OUT * c / 32767;
        s_divider_pts[i][1].y = DIV_ORIGIN + (int32_t)DIV_R_OUT * s / 32767;

        lv_line_set_points(s_divider[i], s_divider_pts[i], 2);
        lv_obj_set_hidden(s_divider[i], false);
    }

    /* The ribbon belongs to the preset page alone, and to no sector. */
    lv_obj_set_hidden(s_wave, (p->view != VIEW_PRESET));

    /*
     * The colours are NOT set here. A new page means a new family hue, and the rim's colours
     * are what says so — but every caller of this function is apply_page(), and apply_page()
     * goes on to refresh_macro(), which ends in refresh_arcs(). Painting the ring here as well
     * painted it twice for every page change: two full fills of the ring, 13 and 10 ms, on the
     * one path where a page turn is already paying for two snapshots. A third caller would
     * have to end in refresh_arcs() too, or the ring would keep the previous page's colours.
     */
}

/*
 * The rims: the family's hue, and the macro's red.
 *
 * Deliberately NOT part of refresh_sectors(). Setting ANY style of an lv_arc
 * invalidates its whole 352x352 bounding box, so restyling four arcs means repainting
 * the entire screen — about 80 ms, measured on this panel. Selection happens on every
 * tap, so it must not come near here; what selection changes is the panel and the two
 * labels, all of them small. Pages and macro membership change rarely enough to pay
 * for a full screen, and those are the only two callers.
 *
 * The consequence, accepted on purpose: a rim no longer says which sector the knob is
 * on, and a selected rim is not thicker. The panel behind the words and the brighter
 * words are what say it. What the rim carries is identity — and that, plus the
 * macro's red, is exactly what is worth a repaint.
 */
/*
 * The selection into the picture: the sector the fill left, the sector it went to, and nothing
 * else. It compares before it paints, so a knob step costs a comparison.
 *
 * Its own function because it belongs to BOTH paths and lived in the wrong one. The body's
 * angles and colours are set in refresh_sectors(), while the painting sat at the end of
 * refresh_values(), which a macro change never reaches: refresh_macro() ends in
 * refresh_arcs() + refresh_sectors(), and rim_repaint_all() clears the ring from radius
 * SEL_BODY_IN outward on its way through. Turning a macro on therefore erased the fill and
 * nothing put it back until the next tap went through select_sector(), which does call
 * refresh_values() — the fill vanished on every macro change and came back on the next touch.
 *
 * The key covers the colour as well as the sector: a macro turning on recolours the same
 * wedge, and the number alone cannot see that.
 */
static void refresh_selection_pixels(void)
{
    if (s_rim_buf == NULL) {
        return;
    }

    const ui_page_t *p = page();

    if (p == NULL) {
        return;
    }

    const int sel = sel_index();
    const int sel_now = (p->knob_count > 0 && sel < p->knob_count) ? sel : -1;

    if (sel_now == s_sel_painted && s_sel_key == s_sel_painted_key) {
        return;
    }

    const int was = s_sel_painted;

    s_sel_painted = sel_now;
    s_sel_painted_key = s_sel_key;

    if (was >= 0 && was != sel_now) {
        rim_paint_sector_whole(was, -1);
    }
    if (sel_now >= 0) {
        rim_paint_sector_whole(sel_now, sel_now);
    }
}

static void refresh_arcs(void)
{
    const ui_page_t *p = page();
    const nav_group_color_t *g = &GROUP_COLOR[p->group];

    for (int i = 0; i < SECTOR_MAX; i++) {
        if (i >= p->knob_count) {
            continue;
        }

        const bool in_macro = s_macro[p->knobs[i].param];
        const bool inverted = s_macro_inv[p->knobs[i].param];

        lv_obj_set_style_arc_width(s_sector_arc[i], ARC_W_IDLE, LV_PART_INDICATOR);
        lv_obj_set_style_arc_color(s_sector_arc[i],
                                   lv_color_hex(in_macro ? (inverted ? COL_INV_RIM
                                                                     : COL_MACRO_RIM)
                                                         : g->bright),
                                   LV_PART_INDICATOR);

        /* The unfilled part of a rim is a SURFACE, not a mark, so it takes the family
         * too — otherwise a blue page would sit inside a teal hoop. */
        lv_obj_set_style_arc_color(s_sector_arc[i], lv_color_hex(tint(g->fill, TINT_TRACK)),
                                   LV_PART_MAIN);
    }

    /* Both of this function's callers change everything the ring depends on — the page and
     * the macro — so this is where the picture is rebuilt, and it is the whole of its cost. */
    rim_repaint_all();
}

/*
 * What the mark layer is showing at this instant, recorded for the code that repaints only
 * the piece a cursor moved between.
 *
 * The records used to be cleared to "nothing drawn" here, on the reasoning that the whole
 * mark layer is invalidated on this path and everything on it is drawn again. That held while
 * the ring under the marks was a set of live arcs repainting themselves with them. It does not
 * hold now that the ring is a picture: the marks are drawn again, but the picture behind them
 * only where the marks asked for it — so the next move, believing nothing was on the rim,
 * repainted just the segment the cursor arrived at and left the stripe it left behind.
 */
static void cursor_remember_drawn(void)
{
    const ui_page_t *p = page();

    for (int i = 0; i < SECTOR_MAX; i++) {
        s_cursor_pos[i] = 0xFF;
        s_cursor_steps[i] = 0;

        if (p == NULL || i >= p->knob_count) {
            continue;
        }

        const synth_param_t param = p->knobs[i].param;
        const int idx = list_index_for(param, synth_app_get_param(param));

        if (idx >= 0) {
            s_cursor_pos[i] = (uint8_t)idx;
            s_cursor_steps[i] = (uint8_t)synth_app_param_steps(param);
        }
    }
}
/*
 * Colours, labels and highlight. Called whenever the selection, the page or the
 * macro changes.
 *
 * Two independent questions, two independent channels, so neither can hide the other:
 *
 *   the SHAPE says "this is the sector the knob is on": one whole wedge lit from the hub
 *   out to the rim, plus the value mark on that sector's rim drawn in the family's
 *   lighter member. A wedge is the sector's own figure, so a selection can neither be
 *   read as a rectangle parked inside a sector nor reach into the sector next door.
 *   a RED wedge, red words and the red rim say "this parameter rides along with the
 *   macro".
 *
 * The macro wins the hue when it is on, and that is the point of spending a whole fill
 * on it: a family colour is a hairline, so a sector that has gone red all through cannot
 * be mistaken for one that has merely got a coloured rim, even by someone who cannot
 * tell the two reds apart. What the macro does NOT get is the area: a member that is not
 * selected keeps its small red block, and the whole wedge only ever means selection. An
 * inverted member keeps the hue and gives up the block — see the note in the body.
 *
 * The family hue of a sector's rim lives in refresh_arcs(), on the page-and-macro path.
 * What this function does to the two selection arcs is move their ANGLES, which is the
 * only arc operation cheap enough to run on a tap — see the note above refresh_arcs().
 */


static void refresh_sectors(void)
{
    const ui_page_t *p = page();
    const int sel = sel_index();
    const nav_group_color_t *g = &GROUP_COLOR[p->group];

    for (int i = 0; i < SECTOR_MAX; i++) {
        if (i >= p->knob_count) {
            continue;
        }

        const bool in_macro = s_macro[p->knobs[i].param];
        const bool inverted = s_macro_inv[p->knobs[i].param];
        const bool selected = (i == sel);

        uint32_t name;
        uint32_t value;

        if (in_macro) {
            /*
             * The macro's own block: half strength when this sector is not the one the
             * knob is on, and nothing at all when it is, because then the whole sector is
             * the fill and that is red as well.
             *
             * An INVERTED member gets the colour and NOT the block. Red on a panel is how
             * this instrument says "this knob is in the macro"; yellow on a panel is not a
             * second way of saying the same thing, it is a second thing, and two filled
             * panels on one page read as two macros rather than as one macro and one
             * direction. The rim and the readout already carry the inversion — see
             * refresh_arcs() and the value's colour below — so what is dropped is the
             * area, which is the part that was ambiguous.
             */
            lv_obj_set_style_bg_color(s_sector_panel[i],
                                      lv_color_hex(inverted ? COL_INV_TINT
                                                            : COL_MACRO_TINT),
                                      LV_PART_MAIN);
            lv_obj_set_style_bg_opa(s_sector_panel[i],
                                    (selected || inverted) ? LV_OPA_TRANSP : LV_OPA_50,
                                    LV_PART_MAIN);
            name = selected ? (inverted ? COL_INV_ON_TINT : COL_MACRO_ON_TINT)
                            : (inverted ? COL_INV_TEXT : COL_MACRO_TEXT);
            value = selected ? (inverted ? COL_INV_ON_TINT : COL_MACRO_ON_TINT)
                             : (inverted ? COL_INV_VALUE : COL_MACRO_VALUE);
        } else {
            /* No block anywhere on a family page: the selected sector's fill is the
             * wedge, and a sector that is not selected has no fill at all. */
            lv_obj_set_style_bg_opa(s_sector_panel[i], LV_OPA_TRANSP, LV_PART_MAIN);

            /*
             * The VALUE keeps the neutral reading colour on every page: a number that
             * changed colour as you turned the knob would be the one thing on the
             * screen that could not be trusted.
             */
            name = selected ? g->text : COL_MUTED;
            value = selected ? COL_TEXT : COL_MUTED;
        }

        lv_label_set_text(s_sector_name[i], p->knobs[i].sector);
        text_color(s_sector_name[i], name);
        text_color(s_sector_value[i], value);

        /*
         * The press feedback for this block, in the family's bright colour at a wash.
         * It is here and not on the panel because the touch area is above the text and
         * the panel is below it: a press has to be visible on the SELECTED sector too,
         * and that sector's fill is the wedge.
         *
         * It is the family's colour and not a neutral highlight for the same reason the
         * rims are: the answer to "which page is this" should not need reading. A page
         * change is the only thing that changes it, so it costs one small invalidation
         * on a path that is already restyling the panel and the two labels above.
         */
        lv_obj_set_style_bg_color(s_sector_touch[i], lv_color_hex(g->bright),
                                  LV_PART_MAIN | LV_STATE_PRESSED);
        lv_obj_set_style_bg_opa(s_sector_touch[i], LV_OPA_20,
                                LV_PART_MAIN | LV_STATE_PRESSED);
    }

    /*
     * The selected sector's own figure: the wedge, and the value mark riding on its rim.
     * Both are MOVED BY ANGLE rather than restyled, because lv_arc_set_bg_angles()
     * invalidates only the wedge it sweeps (lv_arc.c:272-283) where a style change would
     * repaint the object's whole 352 px box. A tap between two sectors of one family
     * therefore costs two swept wedges and nothing else.
     *
     * The COLOURS are the exception, and that is what the remembered key is for: a tap
     * that crosses the macro boundary changes the hue as well, and that one tap pays for
     * the repaint. Every other tap leaves both arcs' styles alone.
     */
    const rim_t rim = page_rim();
    const int n = (p->knob_count < rim.count) ? p->knob_count : rim.count;

    if (sel < n) {
        const rim_span_t *s = &rim.spans[sel];
        const bool in_macro = s_macro[p->knobs[sel].param];
        const bool inverted = s_macro_inv[p->knobs[sel].param];
        /* Three states and not two: the remembered key has to change when a member is
         * turned around as well, or the arcs would keep the colour of the state before. */
        const int key = (int)p->group * 3 + (in_macro ? (inverted ? 2 : 1) : 0);

        lv_arc_set_bg_angles(s_sel_body, s->start, s->end);
        lv_arc_set_bg_angles(s_sel_rim, s->start, s->end);
        /* The cuts follow the page's knob table, so they are rebuilt and repainted with the
         * sectors — once per page, never while a value moves. */
        /*
         * The whole mark layer goes up for repaint here, so every cursor on the rim is drawn
         * again where it stands — a page change is what this path was written for, and the
         * cursors of the new page are not the cursors of the old one.
         */
        lv_obj_invalidate(s_rim_marks);
        cursor_remember_drawn();

        if (key != s_sel_key) {
            s_sel_key = key;

            /* The family's own fill at a surface depth, and the macro's own when the
             * sector is a member. See TINT_BODY for why it is not TINT_SEL. */
            lv_obj_set_style_arc_color(s_sel_body,
                                       lv_color_hex(in_macro
                                                        ? (inverted ? COL_INV_TINT
                                                                    : COL_MACRO_TINT)
                                                        : tint(g->fill, TINT_BODY)),
                                       LV_PART_MAIN);

            /* The family's BRIGHTEST member, so the value the knob is standing on is the
             * brightest fill on the rim as well as the filled one. It is the ink: measured
             * over all six members of every row in GROUP_COLOR it holds the highest
             * relative luminance — 0x90CAF9 (0.550) blue, 0xCE93D8 (0.389) violet,
             * 0x80CBC4 (0.513) teal, 0xA5D6A7 (0.589) green, 0xBCAAA4 (0.421) brown, where
             * the ink IS the text the old code already used, and 0xF8BBD0 (0.601) pink and
             * 0xCFD8DC (0.675) for both greys, where the text is a step down (pink 0.421,
             * the settings grey 0.355 and equal to that row's bright). The other sectors
             * keep g->bright, which is below the ink in every row, so the selected
             * sector's fill is brighter than theirs on every page. For the macro its own
             * selected-rim red, unchanged.
             *
             * On a family page it is nearly white with the family's cast rather than the
             * family's brightest tone: see TINT_TICK_LIGHT. The brightest tone was the
             * brightest of its row and is still a mid tone on the page, which at the width of
             * a notch is not enough to separate the fill from the track beside it. */
            lv_obj_set_style_arc_color(s_sel_rim,
                                       lv_color_hex(in_macro
                                                        ? (inverted ? COL_INV_RIM_SEL
                                                                    : COL_MACRO_RIM_SEL)
                                                        : tint_light(g->fill, TINT_TICK_LIGHT)),
                                       LV_PART_INDICATOR);
        }
    }

    /* Last, because it paints what the loop above has just described. */
    refresh_selection_pixels();
}

/* The rim values. Called on every knob step, so it stays to the visible page —
 * the other pages' parameters are not on screen. */
/*
 * Which position of a list the knob stands on. Returns -1 for a continuous parameter.
 *
 * A LIST IS A CHOICE, NOT A LENGTH, and the rim says so with a CURSOR: one segment is lit,
 * the position the knob is on, and the rest of the sector stays dark with its cuts showing.
 * The alternative — lighting every segment from the start up to the cursor — makes a list
 * look like a level meter, where "nine sixteenths of the scale" is a quantity that does not
 * exist, and it makes OFF of a two-position knob look like a half-turned knob.
 *
 * The index is the nearest position to the value, which is the same rounding the knob's own
 * stepping uses, so the cursor cannot disagree with the number printed under it.
 */
static int list_index_for(synth_param_t param, float v)
{
    const int positions = synth_app_param_steps(param);
    if (positions <= 1) {
        return -1;
    }

    int idx = (int)(v * (float)(positions - 1) + 0.5f);
    if (idx < 0) {
        idx = 0;
    } else if (idx > positions - 1) {
        idx = positions - 1;
    }

    return idx;
}

/*
 * The area one band of one sector's rim covers, and that area alone, put up for repaint.
 *
 * THE ANGLES COME FROM THE CALLER and not from a position index, because the band that is on
 * the screen was drawn from the table as it stood at the time: see s_cursor_steps.
 *
 * TWO OF THESE ARE NEEDED ON A STEP — the segment the cursor left and the one it arrived at —
 * and the pair is a few hundred pixels of the rim. The first version invalidated the whole mark
 * layer instead, which repaints every arc on the page: the cursor then moved in jumps at the
 * rate the frame could be redrawn, which is exactly what a lag looks like on a knob being
 * turned. A cursor is a small thing and it costs a small repaint.
 *
 * THE BAND IS SAMPLED, NOT BOXED BY ITS ENDS. A segment bulges past the rectangle its two ends
 * make: at the rim's radius the middle of a thirty-degree segment stands six pixels outside it,
 * and every one of those pixels that is not repainted stays behind as a ghost of the cursor's
 * old position — which on a two-position list is most of the mark. Eight degrees of sampling
 * keeps the chord within a pixel of the arc, and the box takes one more pixel on every side.
 *
 * The corners are used rather than lv_draw_arc_get_area() because that one reads its radius as
 * a stroke's outer edge and normalises angles past 360 into a wrap; sin/cos of 366 degrees is
 * simply the right point.
 */
/*
 * The two angles of one position of a list, snapped to a notch.
 *
 * The cursor is a mark on the same ladder the band is built from, so it stands on a notch rather
 * than on a fraction of the sector: index out of positions gives the angle the position means,
 * and that angle is then moved back to the notch it falls in. Its width is one notch — the same
 * unit the value is counted in, so a cursor and a filled band cannot disagree by a pixel.
 */
static void list_angles(const rim_t *rim, int sector, int idx, int positions,
                        float *a0, float *a1)
{
    const rim_ticks_t t = rim_ticks_for(rim, sector);

    int k = 0;
    int k1 = 0;
    rim_cursor_ticks(&t, idx, positions, &k, &k1);

    if (k1 <= k) {
        *a0 = 0.0f;
        *a1 = 0.0f;
        return;
    }

    *a0 = t.start + t.pitch * (float)k;
    *a1 = t.start + t.pitch * (float)k1;
}

/*
 * A cursor that has moved, or a cursor whose list has changed length under it.
 *
 * A STEP repaints the segment it left and the one it arrived at. A CHANGE OF LENGTH repaints
 * the sector's whole span: the segment drawn last time was laid out by another table — PULSES
 * and ROTATE take their length from STEPS — and any attempt to rebuild it from the new one is
 * a guess that leaves a sliver of the old band behind. The span is a tenth of the ring, and
 * this happens only when a list actually changed length, not on a step.
 *
 * have_old is false on the first frame after a page turn: the page's own repaint has already
 * covered the rim, and there is nothing on it to take back.
 */
static void cursor_move(int sector, int old_idx, int old_positions, bool have_old,
                        int new_idx, int new_positions)
{
    const ui_page_t *p = page();
    if (!p || s_rim_buf == NULL || sector < 0 || sector >= p->knob_count || new_positions <= 1) {
        return;
    }

    const rim_t rim = page_rim();
    if (sector >= rim.count || new_idx < 0 || new_idx >= new_positions) {
        return;
    }

    /*
     * The ladder is rewritten from the state, so a cursor step cannot leave the mark it left
     * behind: the notches it stood on are painted in the track's colour again by the same function
     * that painted them lit, and no bookkeeping about where the mark used to be has to be kept.
     * The panel is handed the two stretches — the one the mark left and the one it arrived at —
     * because outside those the pixels were rewritten with the colours they already had.
     */
    rim_paint_sector_state(sector, sector == s_sel_painted);

    lv_area_t area;
    lv_area_t part;
    bool any = false;

    if (have_old && old_positions == new_positions && old_idx >= 0 && old_idx < old_positions) {
        float o0;
        float o1;

        list_angles(&rim, sector, old_idx, old_positions, &o0, &o1);

        if (o1 > o0) {
            rim_band_area(o0, o1, RIM_INNER, RIM_OUTER, &area);
            any = true;
        }
    }

    float n0;
    float n1;
    list_angles(&rim, sector, new_idx, new_positions, &n0, &n1);

    if (n1 > n0) {
        rim_band_area(n0, n1, RIM_INNER, RIM_OUTER, &part);

        if (any) {
            area.x1 = (part.x1 < area.x1) ? part.x1 : area.x1;
            area.y1 = (part.y1 < area.y1) ? part.y1 : area.y1;
            area.x2 = (part.x2 > area.x2) ? part.x2 : area.x2;
            area.y2 = (part.y2 > area.y2) ? part.y2 : area.y2;
        } else {
            area = part;
            any = true;
        }
    }

    if (!any) {
        const float start = (float)rim.spans[sector].start;
        rim_band_area(start, start + (float)rim_sweep(&rim.spans[sector]), RIM_INNER, RIM_OUTER,
                      &area);
    }

    rim_flush(&area);
}

static void refresh_values(void)
{
    const ui_page_t *p = page();
    const int sel = sel_index();

    /*
     * A LIST'S LENGTH CAN CHANGE UNDER THE KNOB. PULSES has as many positions as STEPS has
     * steps, so turning STEPS shortens the pulses knob — and a preset, a macro or a page turn
     * can do it while the knob is standing on pulses. The wheel's range IS the list's length,
     * so it is re-pointed here: the value path is the one place every such change passes, and
     * without this a shortened list would leave the knob with travel that writes the same
     * number over and over.
     */
    if (s_proxy_positions > 1 && sel < p->knob_count) {
        const synth_param_t selp = p->knobs[sel].param;
        if (synth_app_param_steps(selp) != s_proxy_positions) {
            proxy_load(selp);
        }
    }

    for (int i = 0; i < SECTOR_MAX; i++) {
        if (i >= p->knob_count) {
            continue;
        }

        const synth_param_t param = p->knobs[i].param;
        const float v = synth_app_get_param(param);
        const int idx = list_index_for(param, v);
        /* How many positions the list has now: one cursor is one of them. */
        const int positions = synth_app_param_steps(param);

        if (idx >= 0) {
            /*
             * A list owns no fill: its rim indicator goes to zero and the one lit segment is
             * painted by the mark layer above it. What the cursor layer adds is that segment,
             * and it is invalidated separately — so the band ask below is answered with a
             * comparison of two zeroes and costs nothing. Repainting the sector here bought
             * nothing and spent the cursor's speed on an empty band.
             */
            const float was = rim_indicator_angle(s_sector_arc[i]);

            lv_arc_set_value(s_sector_arc[i], 0);

            /* The mark is painted from its own arc, so that arc has to be current first. */
            if (i == sel) {
                lv_arc_set_value(s_sel_rim, 0);
            }

            rim_paint_sector_step(i, was);

            /*
             * A step or a change of the list's length, and nothing else, moves the cursor.
             * The second one happens when STEPS moves under PULSES or ROTATE: their number of
             * positions follows it, so the band on the rim is not where the new table would
             * put it and the sector is repainted over its whole span.
             */
            const bool drawn = ((int)s_cursor_pos[i] != 0xFF);
            const bool moved = (idx != (int)s_cursor_pos[i]);
            const bool relaid = (positions != (int)s_cursor_steps[i]);

            if (moved || relaid) {
                cursor_move(i, (int)s_cursor_pos[i], (int)s_cursor_steps[i], drawn, idx,
                            positions);
                s_cursor_pos[i] = (uint8_t)idx;
                s_cursor_steps[i] = (uint8_t)positions;
            }
        } else {
            /*
             * A parameter that has stopped being a list keeps no cursor, and the one it had is
             * not in the ring's picture to be painted over: it lives in the mark layer, which
             * repaints only where it is told to. So the segment of the cursor that is no longer
             * drawn is given up here, once, on the frame the list turns into a value.
             */
            if ((int)s_cursor_pos[i] != 0xFF) {
                const rim_t rim = page_rim();
                float a0;
                float a1;

                if (i < rim.count && s_cursor_steps[i] > 1) {
                    list_angles(&rim, i, (int)s_cursor_pos[i], (int)s_cursor_steps[i], &a0, &a1);

                    /* The mark is in the ring's picture now, so giving it up is a repaint of the
                     * ladder, not an invalidation of a layer. */
                    rim_paint_sector_state(i, i == s_sel_painted);

                    lv_area_t area;
                    rim_band_area(a0, a1, RIM_INNER, RIM_OUTER, &area);
                    rim_flush(&area);
                }

                s_cursor_pos[i] = 0xFF;
                s_cursor_steps[i] = 0;
            }

            const int32_t at = (int32_t)(v * PARAM_STEPS + 0.5f);
            const float was = rim_indicator_angle(s_sector_arc[i]);
            lv_arc_set_value(s_sector_arc[i], at);

            /*
             * The selected sector's value mark is its own arc, drawn exactly over that
             * indicator, so it has to be moved by the same figure — and moved BEFORE the
             * sector goes down, because that pass is what paints the mark.
             */
            if (i == sel) {
                lv_arc_set_value(s_sel_rim, at);
            }

            rim_paint_sector_step(i, was);
        }

        /* Only when the words change: lv_label_set_text() invalidates the label even for the
         * same text, and a list whose readout repeats for several positions would repaint the
         * label on every one of them. */
        char text[32];
        synth_app_param_text(param, text, sizeof(text));
        if (strcmp(lv_label_get_text(s_sector_value[i]), text) != 0) {
            lv_label_set_text(s_sector_value[i], text);
        }
    }

    /* The mark's arc has just moved, so a selection that is waiting to be painted gets the
     * current angles. A step changes no selection and this costs one comparison. */
    refresh_selection_pixels();
}



/* True when the page holds at least one parameter that is part of the sound. Every page
 * but the settings ones does, and the settings pages hold nothing else. */
static bool page_has_patch(const ui_page_t *p)
{
    for (int i = 0; i < p->knob_count; i++) {
        if ((int)p->knobs[i].param < SYNTH_PARAM_PATCH_COUNT) {
            return true;
        }
    }
    return false;
}

/*
 * The arp has the lead's grid, so the page's own controls do nothing. That is worth
 * saying out loud: without it the page reads as broken, which is exactly how it was
 * reported. The percussion grid is untouched by the arp, so this is the lead's page only.
 *
 * The notice takes the macro count's line rather than adding a second one: one status
 * under the title is enough, and this is the one that explains the page.
 */
static bool s_arp_shown;         /* what the arp notice was last set to */

/*
 * `force` makes the notice look at the tree again even when its own answer has not moved.
 *
 * The gate below exists because this runs on the sequencer's timer, forty times a second, and
 * lifting objects to the foreground reorders the children every time it is called. That is
 * only safe while every show and hide goes through the flag — and a page turn cannot promise
 * that: see turn_setup(), which has to settle the notice before it photographs the arriving
 * page, and slide_done_cb(), which has to settle it again before the real page is seen.
 */
/*
 * Who owns the middle of the dial.
 *
 * Three things live on the same pixels: the page's name, the arpeggiator's notice
 * and the turning picture. Exactly one of them may be up, and the rule is not
 * "whoever writes last": the picture stands over the name, the notice stands over
 * both. Every writer calls this instead of setting the flag itself, so a page turn
 * or a notice going away cannot put the name back under a picture that is still up.
 */
static void refresh_page_name(void)
{
    lv_obj_set_hidden(s_page_name, s_preview_on || s_arp_shown);
}

static void refresh_arp_notice(bool force)
{
    const bool on = (s_page == PAGE_EUCLID) && synth_app_arp_active();

    /* This runs on the sequencer's timer, forty times a second, and lifting objects to
     * the foreground reorders the children every time it is called. Doing that on every
     * tick is both pointless and unkind to anything that is reading the layer order, so
     * the notice only touches the tree when its own answer changes. */
    if (!force && on == s_arp_shown) {
        return;
    }
    s_arp_shown = on;

    if (on) {
        /* The notice is a sentence and the page behind it is shapes to be read; one of
         * the two has to give way, and the notice is what the reader came for. Hence the
         * wash: everything the page draws is dimmed under it, and the sentence is lifted
         * above the wash carrying the page's own contrast.
         *
         * The wash is not clickable (make_panel leaves it so), so taps still fall
         * through it to the sectors exactly as before. */
        lv_obj_move_foreground(s_dim);
        lv_obj_move_foreground(s_arp_label);
        lv_obj_set_hidden(s_macro_label, true);
        /* The notice is set in the middle of the screen, which is exactly where the
         * page's own name is. Two 20 px lines on the same pixels are not a notice, they
         * are a mess, so the name stands down while the sentence is up. The name is never
         * hidden for any other reason — see ui_apply_page — so putting it back here is
         * all that is needed. */
        refresh_page_name();
    } else {
        refresh_page_name();
    }
    lv_obj_set_hidden(s_dim, !on);
    lv_obj_set_hidden(s_arp_label, !on);
}

/* The macro count's line, on its own, so the turning picture can put it back
 * without repainting the whole rim: the picture owns that line while it is up, and
 * giving it back is one hidden flag and one string. */
static void refresh_macro_label(void)
{
    const int n = macro_count();

    /* Hidden on pages that have nothing to put in a macro, and that includes the
     * settings pages. The count is global and survives a page change, so without this
     * the preset and settings pages would report a macro that cannot be seen or
     * edited from there.
     *
     * Hidden under the turning picture too: the picture is 56 px tall and its last
     * rows are exactly where this line's ink is, so the two cannot share the disc —
     * and the picture is the one the hand is asking about. */
    if (n == 0 || page()->knob_count == 0 || !page_has_patch(page()) || s_preview_on) {
        lv_obj_set_hidden(s_macro_label, true);
    } else {
        char text[24];
        snprintf(text, sizeof(text), "MACRO %d", n);
        lv_label_set_text(s_macro_label, text);
        lv_obj_set_hidden(s_macro_label, false);
    }
}

static void refresh_macro(void)
{
    refresh_macro_label();

    /*
     * The page and the macro are the two things the rims depend on, and this is the function
     * both of them end up in.
     *
     * Sectors FIRST. refresh_sectors() is what hands each arc of the new page its angles and
     * its colours, and refresh_arcs() is what paints the ring from those arcs — so the order
     * here decides whether the page opens with a filled band or with an empty one that only
     * appears once something is tapped. It opened empty: the ring was painted from the angles
     * of the page that had just been left, and nothing repainted it afterwards, because the
     * value had not changed and no notches were counted as different.
     */
    refresh_sectors();
    refresh_arcs();

    /* Last, because the ring's repaint clears the annulus the body sits in: the body has to be
     * laid down after the ladder it stands behind, not before it. */
    refresh_selection_pixels();

    /* И карта: красное поле плитки — заливка, а не обводка, поэтому сменившийся макрос
     * требует перерисовать её. Только когда она открыта: закрытая ничего не показывает, а
     * nav_mark_current() отметит её при открытии. */
    if (s_nav_open) {
        nav_repaint_all();
    }
}

/* -------------------------------------------------------------------------- */
/* The turning picture                                                        */
/* -------------------------------------------------------------------------- */

/*
 * Paint the mask into the layer.
 *
 * This is a DRAW_MAIN hook, so it runs before the object's own (empty) draw, on
 * the layer the refresh is building. The pixels are written straight into the
 * RGB565 buffer: no lv_image, no decoder, no allocation, and nothing for LVGL to
 * blend — a lit bit is a store.
 *
 * The clip test is the layer's own. In partial rendering mode the buffer is a
 * window onto the screen and `buf_area` is that window's origin, so a pixel's
 * address is (absolute - buf_area) inside the buffer. The mask is indexed by the
 * SAME absolute pixels, which is why the two offsets (`mx`,`my`) are taken from
 * the object's own box rather than from the screen.
 *
 * Only when the display is not RGB565 does this draw nothing: there is no second
 * format in this build, and a conversion path here would be code that never runs.
 */
static void preview_draw_cb(lv_event_t *e)
{
    lv_obj_t *obj = lv_event_get_target(e);
    lv_layer_t *layer = lv_event_get_layer(e);

    if (layer == NULL || layer->draw_buf == NULL) {
        return;
    }
    if (layer->draw_buf->header.cf != LV_COLOR_FORMAT_RGB565) {
        return;
    }

    lv_area_t box;
    lv_obj_get_coords(obj, &box);

    const int stride = (int)(layer->draw_buf->header.stride / 2);
    if (stride <= 0) {
        return;
    }

    /* Erase the whole 56x56 first. The box is transparent, so LVGL does not paint
     * the hub behind it when only the box is invalidated: without this, the bits
     * of the previous mask that the new one does not cover would stay on the
     * glass — the "double image" the owner saw. The fill is the hub's own colour,
     * tint(fill, TINT_BG), so the box does not read as a rectangle.
     */
    lv_area_t full;
    if (!lv_area_intersect(&full, &layer->_clip_area, &box)) {
        return;
    }
    const uint16_t bg = lv_color_to_u16(lv_color_hex(
        tint(GROUP_COLOR[page()->group].fill, TINT_BG)));
    uint16_t *fdst = (uint16_t *)layer->draw_buf->data
                   + (size_t)(full.y1 - layer->buf_area.y1) * (size_t)stride
                   + (size_t)(full.x1 - layer->buf_area.x1);
    const int fw = lv_area_get_width(&full);
    const int fh = lv_area_get_height(&full);
    for (int y = 0; y < fh; y++) {
        uint16_t *row = fdst + (size_t)y * (size_t)stride;
        for (int x = 0; x < fw; x++) {
            row[x] = bg;
        }
    }

    /* Only the rows the picture actually has ink on. Most figures leave the top
     * and bottom of the 56x56 empty — the reverb tail a third of it — and there is
     * no reason to scan those rows for lit bits that are not there. The band is a
     * property of the mask, measured when it was built. */
    lv_area_t band = box;
    band.y1 = box.y1 + s_preview_y0;
    band.y2 = box.y1 + s_preview_y1;

    lv_area_t a = layer->_clip_area;
    if (!lv_area_intersect(&a, &a, &band)) {
        return;
    }

    uint16_t *dst = (uint16_t *)layer->draw_buf->data
                  + (size_t)(a.y1 - layer->buf_area.y1) * (size_t)stride
                  + (size_t)(a.x1 - layer->buf_area.x1);

    /*
     * The picture wears the page's ACCENT, not its reading ink: `bright` is the
     * step the ring is filled with and the sector under the knob is lit by, so
     * the centre says which family it belongs to before the eye has read a word.
     * The contrast is measured against the page's own background —
     * tint(GROUP_COLOR[group].fill, TINT_BG) — in the table below, and every row
     * clears both the 4.5:1 a 2 px stroke needs and the contrast of the ordinary
     * sector label (COL_MUTED on the same background, 5.06..5.21:1).
     *
     *   group   accent    contrast   ordinary label
     *   DRONE   64B5F6     8.98:1        5.09:1
     *   LEAD    BA68C8     5.67:1        5.16:1
     *   GEN     4DB6AC     8.21:1        5.13:1
     *   PERC    66BB6A     8.52:1        5.15:1
     *   FX      F06292     6.60:1        5.17:1
     *   MIX     A1887F     6.14:1        5.21:1
     *   VIEW    90A4AE     7.62:1        5.06:1
     *   PRESET  90A4AE     7.79:1        5.17:1
     *
     * The greys are the case the owner named: VIEW's accent IS its light variant
     * (the row has no brighter step), and it still reads at 7.62:1. No row needed
     * a fallback, so the colour is the same one the rim and the ring use.
     */
    const uint32_t rgb = GROUP_COLOR[page()->group].bright;
    const uint16_t colour = lv_color_to_u16(lv_color_hex(rgb));

    synth_preview_blit(s_preview_mask, dst, stride,
                       a.x1 - box.x1, a.y1 - box.y1,
                       lv_area_get_width(&a), lv_area_get_height(&a), colour);
}

/*
 * The mask's ink band, for the reason the draw callback gives: a picture's ink
 * almost never reaches the frame's edges, and the band turns "scan all 56 rows"
 * into "scan the rows that can have a lit bit". The band is worked out from the
 * first and last non-zero BYTE, which can be up to seven bits wider than the real
 * ink either way — a superset is all the blit needs.
 */
static void preview_ink_rows(void)
{
    int lo = -1;
    int hi = -1;

    for (int i = 0; i < SYNTH_PREVIEW_BYTES; i++) {
        if (s_preview_mask[i] != 0) {
            if (lo < 0) {
                lo = i;
            }
            hi = i;
        }
    }

    if (lo < 0) {
        s_preview_y0 = 0;
        s_preview_y1 = SYNTH_PREVIEW_H - 1;
        return;
    }

    s_preview_y0 = (lo * 8) / SYNTH_PREVIEW_W;
    s_preview_y1 = ((hi + 1) * 8 - 1) / SYNTH_PREVIEW_W;
    if (s_preview_y1 > SYNTH_PREVIEW_H - 1) {
        s_preview_y1 = SYNTH_PREVIEW_H - 1;
    }
}

/* Build the mask for `param` into the one buffer. A function so the probe can
 * time the build in one place rather than at both call sites. */
static void preview_build(synth_param_t param)
{
    synth_preview_mask(param, s_preview_mask);
    preview_ink_rows();

}

/* The page's name, the pagination row and the macro count all live inside the
 * 56x56 box, so all three stand down while the picture is up. They come back in
 * the same handler that hides the picture, which is what makes the swap one
 * refresh rather than two: LVGL paints once, after every flag is already set. */
static void preview_hide(void);


static void preview_show(synth_param_t param)
{
    const synth_preview_kind_t kind = synth_preview_kind(param);

    /* A knob with nothing honest to draw puts the name back at once: leaving the
     * previous knob's picture up while the hand is on this one would explain the
     * wrong control. */
    if (kind == PREVIEW_NONE) {
        preview_hide();
        return;
    }
    if (s_preview == NULL || s_arp_shown) {
        return;
    }

    const uint32_t key = synth_preview_key(param);

    if (!s_preview_on) {
        s_preview_on = true;
        s_preview_key = key;
        preview_build(param);

        refresh_page_name();
        refresh_macro_label();
        refresh_page_dots();

        lv_obj_set_hidden(s_preview, false);
        lv_obj_invalidate(s_preview);
    } else if (key != s_preview_key) {
        /* Still the same burst: only the 56x56 itself is invalidated, so the hub,
         * the rim and the sectors are not repainted for a picture that changed
         * inside its own box. */
        s_preview_key = key;
        preview_build(param);
        lv_obj_invalidate(s_preview);
    }

    s_preview_until = now_ms() + PREVIEW_HOLD_MS;
}

/* Give the middle back. One handler for both reasons the picture can end — the
 * two seconds or a page turn — so the name, the dots and the count can never be
 * left in a state the other path does not know about. */
static void preview_hide(void)
{
    if (!s_preview_on) {
        return;
    }

    s_preview_on = false;
    s_preview_until = 0;

    if (s_preview != NULL) {
        lv_obj_set_hidden(s_preview, true);
    }
    /* Not simply `false`: the arp notice also owns this line, and a page turn that
     * lands on EUCLID while the notice is up must keep the name down. */
    refresh_page_name();
    refresh_macro_label();
    refresh_page_dots();
}

/* Called from the animation timer: the deadline is a stamp, not a one-shot timer,
 * because every further turn pushes it forward — a knob that is still moving must
 * not have its picture taken away under the hand. */
static void preview_tick(uint32_t now)
{
    if (s_preview_on && (int32_t)(now - s_preview_until) >= 0) {
        preview_hide();
    }
}



/* -------------------------------------------------------------------------- */
/* Selection                                                                  */
/* -------------------------------------------------------------------------- */

/*
 * Point the focus proxy at a value without letting it look like a turn.
 *
 * lv_arc_set_value() emits VALUE_CHANGED, which is the same event the encoder
 * produces, so the handler cannot tell them apart by event code. Setting this
 * flag is how it knows not to read the jump as a giant knob movement and shove
 * every macro member to its rail.
 *
 * s_arc_last has to move with it: the arc is now at iv, so that is what the next
 * detent will be measured against. Leaving the old figure behind would make the
 * next turn read the whole correction back as one enormous movement.
 */
static void proxy_sync_value(int32_t iv)
{
    if (iv < 0) {
        iv = 0;
    } else if (iv > s_steps) {
        iv = s_steps;
    }

    s_syncing = true;
    lv_arc_set_value(s_proxy, iv);
    s_proxy_value = iv;
    s_arc_last = iv;
    s_syncing = false;
}

/*
 * Point the proxy at a parameter, at that parameter's own resolution.
 *
 * A parameter that chooses from a list gets ONE arc step per entry, so a single
 * detent moves exactly one entry. The alternative — a thousand-step arc for
 * everything — makes a sixteen-entry scale a hundred detents wide, which is the
 * difference between a control and a chore.
 *
 * The resolution comes from synth_app rather than from a count kept here,
 * because the number of positions IS part of the mapping from a knob to an
 * engine value. A UI that guessed it would drift the moment a range changed, and
 * the symptom would be exactly the one this fixes.
 *
 * A list is also the one case where acceleration is wrong. It exists so a
 * thousand-step sweep can be crossed at all; on the arp's thirteen divisions it would
 * mean one brisk detent jumps six of them, and "one click, one entry" is the whole
 * expectation being met here.
 */
static void proxy_load(synth_param_t param)
{
    const int positions = synth_app_param_steps(param);

    s_discrete = (positions > 1);
    s_steps = s_discrete ? (int32_t)(positions - 1) : PARAM_STEPS;
    s_proxy_positions = positions;
    s_mult = 1;

    s_syncing = true;
    /* Setting the range clamps the value and emits VALUE_CHANGED, which is the
     * same event the encoder produces — hence the guard. */
    lv_arc_set_range(s_proxy, 0, s_steps);
    lv_arc_set_value(s_proxy,
                     (int32_t)(synth_app_get_param(param) * (float)s_steps + 0.5f));
    s_proxy_value = lv_arc_get_value(s_proxy);
    s_arc_last = s_proxy_value;
    s_syncing = false;
}

/*
 * What one detent is worth, by how fast the detents are arriving.
 *
 * A thousand steps at one per detent is an age of wrist work, and a cutoff sweep
 * has to be playable. But fine control matters most at the last few steps of a
 * setting, so nothing is scaled until the knob is already moving: below about
 * twelve detents a second every detent is still exactly one step.
 *
 * The rate is the gap between consecutive changes. LVGL hands the difference it
 * accumulated to the focused widget as a run of single steps inside one read, so
 * a fast turn arrives as a burst with near-zero gaps — those reuse the
 * multiplier the burst started with instead of each pushing it higher, which is
 * what keeps the result predictable rather than dependent on how the reads
 * happened to line up.
 *
 * The curve was made steeper and taller: the old one reached four at forty-five detents
 * a second and stopped at eight, which a turn could out-run. The slow end is
 * untouched — that is where fine control lives — but from about twenty detents a second it
 * climbs twice as fast and goes three times as far. A hundred and forty detents a second is
 * a flick, and a flick across a whole parameter is what that gesture is asking for.
 *
 * It applies to EVERY parameter, lists included: the number this returns is what one detent is
 * worth, and which parameter the detent is turning does not enter into it. See the note in
 * proxy_changed_cb for why the old exemption for lists went away.
 */
/*
 * WHAT ONE DETENT IS WORTH, from the TIME PER DETENT and not from the gap since the last read.
 *
 * Those are the same number only when a read carries one detent, and at speed it does not: LVGL
 * hands over whatever the decoder accumulated, so a fast turn arrives as a few reads of several
 * detents each. The old curve took the gap, so a burst's near-zero gaps locked it to the
 * multiplier the burst started with — a hand that began slowly and then flicked kept the slow
 * multiplier for the whole flick, which is exactly what "at very fast rotation it responds
 * worse" was. Dividing by the detents in the read gives the honest rate, and a burst now reads
 * as fast as it is.
 *
 * The top of the curve came down from twenty-four to twelve. Twenty-four detents per detent at
 * a thousand-step parameter is a fifth of the travel in one click of the wrist, which is not
 * acceleration but a jump to the rail; twelve is a flick that crosses the parameter and still
 * lands where it was aimed.
 *
 * A LIST takes at most three, and the number is chosen so that a flick of five detents crosses
 * a sixteen-position list once rather than ending at its last entry. Lists were exempt from
 * acceleration until recently; they are not any more, and this is how they are allowed to
 * accelerate without becoming a jump to the end.
 *
 * The rate is a follower on the time per detent, so it lags a gesture by a few reads rather than
 * jittering: a knob that is turned steadily reads its own speed, and a knob that stops goes back
 * to one detent per detent before the next turn — see knob_multiplier().
 */
#define ACCEL_TAU_S     0.15f   /* the accumulation window: a click counts for ~150 ms */
#define ACCEL_IDLE_MS   250u    /* longer than this between reads starts a new gesture */

/*
 * THE WHEEL, THE WAY macOS DOES IT: CLICKS ACCUMULATED OVER A UNIT OF TIME.
 *
 * The multiplier is a function of how many detents a second the hand is making, not of the
 * gap between two reads — and the accumulation is what makes the difference. A leaky bucket
 * holds the recent clicks: every detent adds one as if it had happened over the last
 * ACCEL_TAU_S, and everything in the bucket decays with the same time constant. A steady turn
 * therefore settles on its own rate within two or three reads, a flick reaches the top of the
 * curve in one, and a hand that stops empties the bucket in about a third of a second so the
 * next turn starts from one detent per detent.
 *
 * Reading the gap instead — which is what this did — cannot do that: it measures the interval
 * to the PREVIOUS read, and LVGL hands over whole batches, so the number alternates between
 * "nothing happened for 30 ms" and "four detents in one millisecond" for the same steady
 * turn. Dividing by the detents in the read fixed half of it and left the rest; the bucket
 * does not care how the clicks are bunched.
 *
 * THE CURVE, AND WHY ITS TOP IS HIGH.
 *
 * A continuous parameter has a thousand steps over the knob's travel, so at one step per click
 * the whole sweep would be fifty turns of the wrist. The curve is therefore not a gentle
 * accelerator at the top but a gearbox: below four clicks a second a click is one step and
 * nothing else, which is the setting a value by hand that has to stay possible; around twelve
 * clicks a second, an ordinary deliberate turn, a click is ten steps and the knob crosses in
 * one comfortable arc; and a hard flick, fifty clicks a second and up, is sixty to ninety steps
 * a click, so one throw of the wrist moves a good fraction of the travel and two reach either
 * end. That is the macOS wheel's behaviour, which is where the idea came from: the first
 * clicks are precise and the last are a fling.
 *
 * A list takes at most three, so a flick crosses a sixteen-entry list once instead of landing
 * on its last entry.
 */
typedef struct {
    uint32_t last_ms;   /* when the previous read arrived */
    float    cps;       /* detents per second, accumulated and decaying */
    bool     started;   /* false until the first read since boot */
} accel_state_t;

static accel_state_t s_accel;

/* Clicks a second into detents per click. */
static int32_t accel_multiplier(float cps)
{
    if (cps < 4.0f) {
        return 1;
    }
    if (cps < 7.0f) {
        return 2;
    }
    if (cps < 9.5f) {
        return 4;
    }
    if (cps < 13.0f) {
        return 10;
    }
    if (cps < 18.0f) {
        return 18;
    }
    if (cps < 25.0f) {
        return 28;
    }
    if (cps < 35.0f) {
        return 42;
    }
    if (cps < 50.0f) {
        return 60;
    }
    return 90;
}

/*
 * The multiplier for this read.
 *
 * steps is what the read carried and discrete is whether the knob is walking a list. The
 * bucket is fed by the MAGNITUDE of the read, so a batch of four counts as four clicks and a
 * single click counts as one: the rate is a property of the hand, not of how often LVGL asked.
 */
static int32_t knob_multiplier(int32_t steps, bool discrete)
{
    const uint32_t now = now_ms();
    const uint32_t gap = s_accel.started ? (now - s_accel.last_ms) : 0u;
    s_accel.last_ms = now;

    const uint32_t mag = (steps < 0) ? (uint32_t)(-steps) : (uint32_t)steps;

    if (!s_accel.started || gap > ACCEL_IDLE_MS) {
        /* A new gesture: the bucket starts empty, so the first read of a flick is read at
         * the rate of that read and not at the rate of the turn before. */
        s_accel.started = true;
        s_accel.cps = 0.0f;
    } else if (gap > 0u) {
        /* Decay over the time that has passed, so a pause empties the bucket. expf() once
         * per read costs a few microseconds in a task that has a whole frame. */
        s_accel.cps *= expf(-(float)gap * 0.001f / ACCEL_TAU_S);
    }

    if (mag > 0u) {
        s_accel.cps += (float)mag / ACCEL_TAU_S;
    }

    if (s_accel.cps < 0.0f) {
        s_accel.cps = 0.0f;
    } else if (s_accel.cps > 400.0f) {
        s_accel.cps = 400.0f;
    }

    int32_t mult = accel_multiplier(s_accel.cps);

    /*
     * A LIST DOES NOT ACCELERATE AT ALL, and this used to cap it at three.
     *
     * A list is a handful of named positions and the player is aiming at one of them, so
     * multiplying a click there is not acceleration but a miss: two detents at four steps a
     * click is a position the hand did not ask for, and the hand has no way to undo it except
     * counting backwards. Three was the cap and three was still one too many. One detent, one
     * position, always — the wheel over a list is the wheel at its slowest, whatever the wrist
     * is doing.
     */
    if (discrete) {
        return 1;
    }
    return mult;
}

static void select_sector(int idx)
{
    const ui_page_t *p = page();

    if (idx < 0 || idx >= p->knob_count) {
        return;
    }

    s_sel[s_page] = (uint8_t)idx;
    proxy_load(p->knobs[idx].param);
    refresh_sectors();
    refresh_values();
}

/*
 * The knob a page is entered on, named by PARAMETER rather than by index.
 *
 * It is normally the page's first table entry, which is what the zero in s_sel[] gives. The
 * one exception left is the drone's filter page, where CUTOFF sits second because RIM_4
 * gives the top seat to the second entry; DRONE and PERC used to be exceptions too, but the
 * levels left those pages and their first entries are now the knobs a player arrives on.
 * A parameter survives a reordering of KNOBS_* and an index does not: a quiet index left
 * behind by such a reordering would select the wrong knob. When the parameter is not on the
 * page the function leaves the zero alone, which is the first entry, and that is exactly
 * what would have happened without it.
 */
static void seed_selection(page_id_t page, synth_param_t param)
{
    const ui_page_t *p = &PAGES[page];

    for (int i = 0; i < p->knob_count; i++) {
        if (p->knobs[i].param == param) {
            s_sel[page] = (uint8_t)i;
            return;
        }
    }
}

/*
 * The longest run of characters between two spaces in a title.
 *
 * That is the widest LINE of a two-line title, and for a one-word title it is the
 * whole word. Used for the face decision, because after a split it is the longest line
 * and not the whole title that has to fit the middle column.
 */
static int title_longest_word(const char *title)
{
    int longest = 0;
    int n = 0;

    for (const char *c = title; ; c++) {
        if (*c == ' ' || *c == '\0') {
            if (n > longest) {
                longest = n;
            }
            n = 0;
            if (*c == '\0') {
                return longest;
            }
            continue;
        }
        n++;
    }
}

/*
 * Whether a title fits the middle of a four-sector page in the larger face.
 *
 * The test is a count of characters, not a width, because the faces are proportional and
 * a count is the thing a person can apply while naming a page. Seven capitals is the
 * budget: the sector blocks leave 80 px between them and the widest one-word title in
 * PAGES[] — CHORUS and PRESET — measures 72 px at lv_font_anbscreen_20, while OPTIONS
 * measures exactly 80 px on its own and so comes right up against both blocks. It is set
 * in the larger face all the same: the owner asked for it, and a title that touches a block
 * is what the panel shows. The smaller face measures 58..61 px for the same words,
 * OPTIONS 71 — which is where OPTIONS used to be drawn.
 *
 * A two-word title is set on TWO lines, so what has to fit is its longest word: DRONE
 * FLTR is 108 px as one line in the larger face and 60 + 42 as two lines. That is what
 * buys the larger face — nothing is ever made smaller to fit.
 *
 * The widths above are what the faces measure at text_condensed(0), kerning included, not
 * what a monospace face would: run build\kern_plus1.py, which reads the advances and the
 * pair table out of the C files and applies lv_text.c's own arithmetic, before changing a
 * page's name.
 */
static bool title_fits_big(const char *title)
{
    return title_longest_word(title) <= TITLE_BIG_CHARS;
}

/*
 * The page name as it is DRAWN: two lines when the title has two words and does not fit
 * the larger face as one. Returns true when it split, because a two-line block is what
 * makes the macro count move aside — see MACRO_Y_TWO.
 *
 * Both halves of the test matter. The whole title has to be too wide for the larger face,
 * or there is nothing to fix; and the longest WORD has to fit it, or splitting would not
 * help. A title that already fits stays on one line, which is what keeps SYS 2 as SYS 2,
 * and the split is only ever at the FIRST space.
 */
static bool title_two_lines(const char *title, char *out, size_t out_size)
{
    const char *sp = NULL;
    int whole = 0;

    for (const char *c = title; *c != '\0'; c++) {
        if (*c == ' ' && sp == NULL) {
            sp = c;
        }
        whole++;
    }

    if (sp != NULL && whole > TITLE_BIG_CHARS
        && title_longest_word(title) <= TITLE_BIG_CHARS) {
        snprintf(out, out_size, "%.*s\n%s", (int)(sp - title), title, sp + 1);
        return true;
    }

    snprintf(out, out_size, "%s", title);
    return false;
}

/*
 * Everything a page change does, with no animation.
 *
 * Split out because the slide has to call it at its midpoint, and because the
 * start-up path needs a page set without a transition.
 */
static void apply_page(int page_idx)
{
    if (page_idx < 0) {
        page_idx = PAGE_COUNT - 1;
    } else if (page_idx >= PAGE_COUNT) {
        page_idx = 0;
    }

    s_page = (page_id_t)page_idx;
    const ui_page_t *p = page();

    /* A page turn ends the picture before anything of the new page is set: the
     * figure belongs to the page that was left, and the arriving page's name must
     * not be laid down and then hidden in the same refresh. Only when the picture
     * is up: a page turn with no picture must not touch the name, because on EUCLID
     * the arp notice owns it and this function is not the one that settles that. */
    if (s_preview_on) {
        preview_hide();
    }

    /* One line per page change. It is the difference between "the tap did
     * nothing" and "the tap arrived and opened the wrong page", which is not a
     * distinction the screen can be asked about from the outside. The title is logged
     * as it is written in PAGES[]: the newline the name is DRAWN with is not in it. */
    ESP_LOGI(TAG, "page: %s (%d/%d)", p->title, page_idx + 1, (int)PAGE_COUNT);
    diag_record(DIAG_EVT_PAGE, page_idx, (int)p->group);

    /* Hide the list, then reveal it again on the page that has one: a page change can
     * leave it on screen, and hiding is cheap. */
    lv_obj_set_hidden(s_preset, true);

    char title[24];
    const bool two_line = title_two_lines(p->title, title, sizeof(title));

    lv_label_set_text(s_page_name, title);
    /*
     * Which face the title is set in follows the title's LENGTH rather than the page
     * or the view, because what constrains it is the middle column and nothing else. A
     * two-word title in the smaller face says more than a one-word title in the larger
     * one, and both of them fit. See title_fits_big() for the arithmetic.
     */
    lv_obj_set_style_text_font(s_page_name,
                               title_fits_big(p->title) ? &lv_font_anbscreen_20 : &lv_font_anbscreen_14,
                               LV_PART_MAIN);
    /*
     * Centred, which only shows on a split title: the two lines share the middle column
     * between them instead of each starting at the left edge of the wider one.
     */
    lv_obj_set_style_text_align(s_page_name, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN);
    /*
     * The leading of a two-line title. Harmless for a one-line one: a single line has no
     * gap to touch. See TITLE_LINE_SPACE for the numbers — with this face the line box is
     * already tight, so the value is 0 and the two lines of caps sit 2 px apart.
     *
     * The centring survives any squeeze, and that is worth the arithmetic rather than a
     * fudge factor: LVGL centres the whole text BLOCK, a line space pulls the two line
     * boxes equally towards that centre, and the ink sits the same distance into each box.
     * The ink's centre is therefore a - line_h/2 whatever the line space is — it is
     * +0.5 px with this face as it was with the one before. Only the block changed
     * length: 26 px of ink here, against the 30 px a two-line title took with the
     * monospace face. What does have to give way is the macro count below it: see
     * MACRO_Y_TWO.
     */
    lv_obj_set_style_text_line_space(s_page_name, TITLE_LINE_SPACE, LV_PART_MAIN);
    /*
     * The page's own name carries the family colour as well, and for the same
     * reason the rim does: it is on screen the whole time you are on the page, so
     * it is where the code is actually learned — the curtain is only visited.
     */
    text_color(s_page_name, GROUP_COLOR[p->group].text);
    /*
     * And the page itself is tinted with the family as well. It is the largest
     * surface on the instrument, so it is the one that makes the code felt rather
     * than read: you know which family you are in before you have read a word. All
     * five tints land within a few percent of the luminance of the one teal
     * background they replace, so nothing measured against it has moved.
     */
    lv_obj_set_style_bg_color(lv_screen_active(),
                              lv_color_hex(tint(GROUP_COLOR[p->group].fill, TINT_BG)),
                              LV_PART_MAIN);
    /*
     * The hub disc takes the page's own background, so it never reads as a shape: all
     * it ever does is stop the selected sector's fill at the dividers' inner end. See
     * CENTRE_BG_R.
     */
    lv_obj_set_style_bg_color(s_hub,
                              lv_color_hex(tint(GROUP_COLOR[p->group].fill, TINT_BG)),
                              LV_PART_MAIN);

    /*
     * The middle of the screen belongs to the sector blocks on a knob page, but
     * the preset list fills it, so there the page name steps
     * up to the top of the rim where nothing else is drawn. At -150 the circle is
     * only 78 px wide, which still clears a 20 px word — the widest one-word title,
     * SYSTEM, is 72 px in the large face. The list below is placed
     * against that: its top row is 9 px under this word, which is the other half of
     * why the window is seven rows.
     *
     * A two-line name on a knob page keeps the same middle as a one-line one, and the
     * macro count below it is what steps down — see MACRO_Y_TWO. The other two views
     * have one-word names and stay at -150; a two-line name there would run off the
     * top of the circle, and there is no page that has one.
     */
    lv_obj_align(s_page_name, LV_ALIGN_CENTER, 0,
                 p->view == VIEW_KNOBS ? PAGE_NAME_Y : -150);
    /*
     * The macro count is what gives way to a two-line name, not the other way round:
     * the name is where you are and must not drift, and the count is a caption. The
     * arithmetic is with MACRO_Y_TWO. Harmless on the two views that have no knobs:
     * the count is hidden there, and their names are one word.
     */
    lv_obj_align(s_macro_label, LV_ALIGN_CENTER, 0, two_line ? MACRO_Y_TWO : MACRO_Y);
    /* The arp notice is the one thing on a knob page that owns the middle outright: the
     * page's name stands down while it is up (see refresh_arp_notice), so the sentence
     * goes exactly where the name would have been — and in the name's own colour, so it
     * reads as the page speaking rather than as a warning from somewhere else. */
    lv_obj_align(s_arp_label, LV_ALIGN_CENTER, 0, 0);
    text_color(s_arp_label, GROUP_COLOR[p->group].text);

    switch (p->view) {
    case VIEW_KNOBS:
        layout_sectors();
        /* Re-points the proxy at this page's remembered selection. */
        select_sector(sel_index());
        break;

    case VIEW_PRESET:
        /* No sectors here either: this page is a list, and a rim of values would be
         * offering four things to turn that this page does not have. */
        layout_sectors();
        lv_obj_set_hidden(s_preset, false);
        preset_refresh();
        break;
    }

    refresh_macro();
    seq_display_show(1);
    nav_mark_current();
    refresh_page_dots();
    refresh_page_name();


    /*
     * No focus-group work here, and that is the point of the proxy.
     *
     * The proxy is on the screen rather than inside a page, so it is visible on
     * every page and the group always holds exactly the same single member. The
     * group built once at start-up therefore stays correct forever, and a page
     * change cannot leave the knob with nothing to drive.
     */
}

/*
 * The slide, driven as one 0..1000 progress rather than as two chained animations.
 *
 * Both pictures travel the same way at the same time: the one being left leaves by the same
 * distance the arriving one has still to come. That is what keeps the buffer's square edge out
 * of the picture. In the old overlap the arriving square was drawn over a page that stood
 * still, so its straight edge cut across the other page's circle and read as the shape of the
 * buffer. Now each picture's facing edge is tangent to its own circle, and the two edges stay
 * together; what shows between the circles at half-travel is the page background, which is
 * the same colour as the screen.
 *
 * Integer division rounds the two positions towards zero. They can therefore overlap by at
 * most one pixel and can never leave a gap: the visible seam is the incoming picture's own
 * left edge, not a strip of background.
 */
static void slide_place(int32_t pct)
{
    s_slide_pct = pct;

    const int32_t travel = (s_slide_dir * 360 * pct) / 1000;

    if (s_slide_still != NULL) {
        lv_obj_set_x(s_slide_still, -travel);
    }
    if (s_slide_img != NULL) {
        lv_obj_set_x(s_slide_img, (s_slide_dir * 360 * (1000 - pct)) / 1000);
    }
}

static void slide_exec(void *var, int32_t pct)
{
    (void)var;
    slide_place(pct);
}

static void slide_done_cb(lv_anim_t *a)
{
    (void)a;
    s_sliding = false;

    /*
     * The buffer has done its work and the page underneath is the real one again. Both it
     * and the pixels it was showing go back: 259 KB is the largest single allocation this
     * firmware makes, and it has no business outliving a page turn.
     */
    if (s_slide_img != NULL) {
        lv_obj_delete(s_slide_img);
        s_slide_img = NULL;
    }
    if (s_slide_snap != NULL) {
        lv_draw_buf_destroy(s_slide_snap);
        s_slide_snap = NULL;
    }
    if (s_slide_still != NULL) {
        lv_obj_delete(s_slide_still);
        s_slide_still = NULL;
    }
    if (s_slide_still_snap != NULL) {
        lv_draw_buf_destroy(s_slide_still_snap);
        s_slide_still_snap = NULL;
    }

    /*
     * A turn that was not carried through puts its page back. The rebuild at the start of
     * the turn already replaced the page with the one that was coming, so undoing is a
     * second rebuild — done here, with the content still hidden, so the swap is not seen.
     */
    if (s_slide_cancelled) {
        s_slide_cancelled = false;
        apply_page(s_slide_from);
        lv_obj_set_x(s_content, 0);
    }

    /*
     * The real page, which has been hidden behind two pictures of itself and is exactly
     * where it belongs: the pictures are gone and the content never left its own origin.
     *
     * The notice is settled once more, before the first frame it is seen in. A turn that was
     * put back has just rebuilt the page it left, and apply_page() only settles the notice on
     * the pages that carry a figure; the arp can also be switched off (or on) while the pair
     * is in flight, and the pictures cannot know. One forced pass here is what makes the
     * tree agree with the page for every one of those, with no frame in between.
     */
    refresh_arp_notice(true);
    lv_obj_clear_flag(s_content, LV_OBJ_FLAG_HIDDEN);
    lv_obj_set_x(s_content, 0);
}

/* Let go of the picture taken at the first movement, when nothing is going to use it. */
static void press_snap_drop(void)
{
    s_press_snap_armed = false;
    if (s_press_snap != NULL) {
        lv_draw_buf_destroy(s_press_snap);
        s_press_snap = NULL;
    }
}

/*
 * The two pictures a turn is made of, and the rebuild that makes them.
 *
 * Split out of slide_to() because the turn under the finger (see the drag block below)
 * needs exactly this and then drives the arriving picture itself instead of starting an
 * animation. Both callers leave s_sliding true; whoever gets here owns the cleanup in
 * slide_done_cb().
 */
static void turn_setup(int page_idx, int dir)
{
    s_slide_dir = dir;
    s_slide_from = (int)s_page;
    s_slide_cancelled = false;

    /*
     * In this order, and the order is the whole trick.
     *
     * The page as it stands is taken into a buffer first, because it is about to be
     * rebuilt. Its picture then goes down exactly where the page was, and from there it
     * travels out with the arriving one: see slide_place(). Both are pictures, so no frame
     * can fall through to a live page and pay for a render.
     *
     * That picture was usually taken at the first movement already — see s_press_snap — and
     * this takes it over rather than making another. Only a press that never moved pays for
     * it here.
     */
    s_slide_still_snap = s_press_snap;
    s_press_snap = NULL;
    s_press_snap_armed = false;
    if (s_slide_still_snap == NULL) {
        s_slide_still_snap = lv_snapshot_take(s_content, LV_COLOR_FORMAT_RGB565);
    }
    if (s_slide_still_snap != NULL) {
        s_slide_still = lv_image_create(lv_obj_get_parent(s_content));
        lv_image_set_src(s_slide_still, s_slide_still_snap);
        lv_obj_set_pos(s_slide_still, 0, 0);
        lv_obj_clear_flag(s_slide_still, LV_OBJ_FLAG_SCROLLABLE);
    }


    apply_page(page_idx);

    /*
     * The notice is settled BEFORE the arriving page is photographed, and that is the whole
     * fix for the notice that was seen twice.
     *
     * refresh_arp_notice() is normally driven by the sequencer's timer, and seq_timer_cb()
     * returns while s_sliding — so during a turn nothing looks at the notice at all. And
     * apply_page() reaches it only through seq_display_show(), which runs for the pages that
     * carry a figure and not for ARP, DRONE, LEAD and the rest. Leaving EUCLID with the arp
     * on therefore left s_dim and s_arp_label up — and the page's name down — on a page that
     * has no notice, and the picture below was taken with them: the arriving page travelled
     * in carrying the leaving page's wash and sentence, so the turn showed the pair on both
     * halves of the screen, and the flash of them on the landed page lasted until the timer
     * came round. Forcing here gives the picture the state the page it shows will really have.
     */
    refresh_arp_notice(true);

    /*
     * And the new page, also a picture — this is the one that FOLLOWS the leaving page in.
     *
     * The pair now moves as one sheet that is pushed sideways: the old page leaves by the
     * distance the new one still has to come. It reads as a push rather than as a card
     * being laid on top of another, which is what the square buffer edge used to give
     * away. The old arrangement — arriving page over a still one — was chosen when only
     * one of the two could be moved without an extra draw call; the extra call is one
     * image and costs what the exposed strip would have cost anyway.
     *
     * It has to be a picture for the frames to be cheap. A live page under a moving one is
     * re-rendered in full on every frame — 120 ms measured, three positions in a 276 ms
     * turn — because the area the moving picture has left is a spoiled region and LVGL
     * redraws what is in it.
     */
    if (s_slide_still_snap != NULL) {
        s_slide_snap = lv_snapshot_take(s_content, LV_COLOR_FORMAT_RGB565);
        if (s_slide_snap != NULL) {
            s_slide_img = lv_image_create(lv_obj_get_parent(s_content));
            lv_image_set_src(s_slide_img, s_slide_snap);
            /* Off the edge it comes in from, and created AFTER the still picture so that
             * it passes over it rather than behind it. */
            lv_obj_set_pos(s_slide_img, s_slide_dir * 360, 0);
            lv_obj_clear_flag(s_slide_img, LV_OBJ_FLAG_SCROLLABLE);

            /* The live page, out of the way. Both sides are pictures now, so nothing
             * underneath is drawn and no frame can cost a page render. */
            lv_obj_add_flag(s_content, LV_OBJ_FLAG_HIDDEN);
        }
    }

    if (s_slide_snap == NULL) {
        /* No buffer. The turn still happens; it is the old one, and it is the one the
         * counters were added to complain about. */
        lv_obj_set_x(s_content, 0);
    }

}

/* The slide itself, once the destination and the direction are settled. */
static void slide_to(int page_idx, int dir)
{
    if (!s_ready || page_idx == (int)s_page) {
        apply_page(page_idx);
        lv_obj_set_x(s_content, 0);
        return;
    }

    if (s_sliding) {
        /* One turn at a time. A second swipe while the first is in flight would
         * leave the content halfway across with two targets in mind. */
        return;
    }

    s_sliding = true;
    turn_setup(page_idx, dir);

    lv_anim_init(&s_slide_anim);
    lv_anim_set_var(&s_slide_anim, &s_slide_pct);
    lv_anim_set_values(&s_slide_anim, 0, 1000);
    lv_anim_set_duration(&s_slide_anim, s_slide_ms);
    /*
     * The same curve the drawers use, and for a reason that only shows when frames are
     * scarce. ease_in_out spends its first steps barely moving and then puts most of the
     * travel through the middle: at seven positions that is a long hesitation followed by a
     * jump, which is what the turn felt like next to a drawer of the same length. ease_out
     * moves from the first frame and decelerates into place, so a short turn reads as a
     * movement rather than as a cut with a pause before it.
     */
    lv_anim_set_path_cb(&s_slide_anim, lv_anim_path_ease_out);
    lv_anim_set_exec_cb(&s_slide_anim, slide_exec);
    lv_anim_set_completed_cb(&s_slide_anim, slide_done_cb);
    lv_anim_start(&s_slide_anim);
}

/*
 * A relative turn, from a swipe.
 *
 * The carousel is the INSTRUMENT: every page a play gesture can land on and no
 * settings page at all. The filter used to keep a turn among pages of the same
 * kind, which kept the settings off the instrument's carousel but also made the
 * two settings pages swipe into each other — and being one accidental wipe away
 * from RING MODE mid-phrase is exactly what the banner on KNOBS_SYS says must not
 * happen. So the test is on the destination alone, from wherever the turn starts:
 * a swipe off the instrument stays on the instrument, and a swipe off a settings
 * page re-enters it. Setup is reached from the curtain, deliberately, and left the
 * same way.
 */
static void turn_to(int page_idx, int dir)
{
    /* Every page in PAGES is reachable, so the turn lands on the neighbour it was
     * aimed at and there is nothing left to skip over: the only work here is the
     * wrap at either end of the list. */
    int idx = (page_idx < 0) ? PAGE_COUNT - 1
            : (page_idx >= PAGE_COUNT) ? 0
            : page_idx;

    slide_to(idx, dir);
}

/* -------------------------------------------------------------------------- */
/* The turn under the finger                                                  */
/* -------------------------------------------------------------------------- */

/*
 * Nothing here is a gesture: LVGL sends one only after the hand has already gone its
 * threshold and left the glass, which is too late to show anything under the finger.
 * These read the pointer device directly, on a timer, and move the same two pictures a
 * turn is made of. See the note over DRAG_START_PX for what the trade is.
 */
static lv_indev_t *drag_indev(void)
{
    if (s_drag_indev == NULL) {
        for (lv_indev_t *i = lv_indev_get_next(NULL); i != NULL; i = lv_indev_get_next(i)) {
            if (lv_indev_get_type(i) == LV_INDEV_TYPE_POINTER) {
                s_drag_indev = i;
                break;
            }
        }
    }
    return s_drag_indev;
}

/*
 * Where the finger is, as the device last reported it.
 *
 * The point stays valid after the finger leaves — it is the last one there was — which is what
 * makes this useful at the end of a stall of our own making: the release that happened while a
 * turn was being built is read here, not lost.
 */
static bool drag_point(lv_point_t *out)
{
    lv_indev_t *indev = drag_indev();
    if (indev == NULL) {
        return false;
    }
    lv_indev_get_point(indev, out);
    return true;
}

/*
 * The arriving picture at a given travel, 0..360 px.
 *
 * The arithmetic is slide_exec's, only with the fraction coming from the hand instead of
 * from an animation's clock: the two must agree pixel for pixel, or the picture would jump
 * when the release hands it back to the animation.
 */
static void drag_place(lv_coord_t travel)
{
    if (travel < 0) {
        travel = 0;
    } else if (travel > 360) {
        travel = 360;
    }
    s_drag_travel = travel;

    /*
     * The same function the animation drives, so the hand and the clock cannot disagree
     * about where the two pictures are at the moment one hands over to the other.
     */
    slide_place((int32_t)travel * 1000 / 360);
}

/*
 * The release: finish the turn or put the page back, whichever the hand asked for.
 *
 * `carry` is the gesture's remembered verdict: LVGL calls a fast movement a swipe, and it
 * does so part-way through the press, from the points it collects while this poll is busy
 * building the turn. Its direction is kept rather than acted on there — see s_drag_carry —
 * so a flick that ends inside a stall still finishes the turn it declared, even when the
 * release carries neither distance nor speed.
 */
static void drag_release(bool carry)
{
    const bool forward = (s_drag_vx * (float)s_slide_dir) < 0.0f;
    const float speed = fabsf(s_drag_vx);
    const bool commit = carry
                        || ((int32_t)s_drag_travel * 1000 / 360 >= DRAG_COMMIT_MILLI)
                        || (forward && speed >= DRAG_FLICK_PX_MS);
    s_drag_carry = false;

    const lv_coord_t remain = commit ? (360 - s_drag_travel) : s_drag_travel;
    const float pace = (speed > 0.2f) ? speed : 0.5f;
    int ms = (remain <= 0) ? 0 : (int)((float)remain / pace);
    if (ms < (int)PAGE_SLIDE_MS) {
        ms = (int)PAGE_SLIDE_MS;
    } else if (ms > (int)PAGE_SLIDE_MS_MAX) {
        ms = (int)PAGE_SLIDE_MS_MAX;
    }

    s_drag_on = false;
    s_drag_watch = false;
    s_slide_cancelled = !commit;

    lv_anim_init(&s_slide_anim);
    lv_anim_set_var(&s_slide_anim, &s_slide_pct);
    lv_anim_set_values(&s_slide_anim, s_slide_pct, commit ? 1000 : 0);
    lv_anim_set_duration(&s_slide_anim, (uint32_t)ms);
    lv_anim_set_path_cb(&s_slide_anim, lv_anim_path_ease_out);
    lv_anim_set_exec_cb(&s_slide_anim, slide_exec);
    lv_anim_set_completed_cb(&s_slide_anim, slide_done_cb);
    lv_anim_start(&s_slide_anim);
}

/* The hand has gone far enough sideways: build the turn and take the picture over. */
static void drag_begin(int dir, lv_coord_t travel)
{
    const int next = (int)s_page + ((dir > 0) ? 1 : -1);
    const int page_idx = (next < 0) ? PAGE_COUNT - 1 : (next >= PAGE_COUNT) ? 0 : next;

    s_sliding = true;
    s_drag_on = true;
    s_drag_carry = false;
    /* A turn taken by the hand is still a swipe: the click that ends it must not fire. */
    swipe_was_taken();

    turn_setup(page_idx, dir);

    if (s_slide_img == NULL) {
        /* No buffer to move. The page has already been rebuilt, so all that is left is the
         * ordinary turn, driven from zero. */
        s_drag_on = false;
        drag_place(0);
        lv_anim_init(&s_slide_anim);
        lv_anim_set_var(&s_slide_anim, &s_slide_pct);
        lv_anim_set_values(&s_slide_anim, 0, 1000);
        lv_anim_set_duration(&s_slide_anim, s_slide_ms);
        lv_anim_set_path_cb(&s_slide_anim, lv_anim_path_ease_out);
        lv_anim_set_exec_cb(&s_slide_anim, slide_exec);
        lv_anim_set_completed_cb(&s_slide_anim, slide_done_cb);
        lv_anim_start(&s_slide_anim);
        return;
    }

    /*
     * Building the turn took a render or two, and the hand kept going while it did. Take the
     * finger where it is now and count what it did meanwhile as travel AND as speed.
     *
     * The speed already in hand is the one measured BEFORE the build, and it wins unless the
     * reread is faster: a release that arrives inside the build leaves this point where it
     * was before the stall and the interval is the whole stall, so the reread reads as a
     * drift. The pre-build speed is the hand's real one and is what a flick is decided on.
     */
    lv_point_t p;
    if (drag_point(&p)) {
        const int64_t now = esp_timer_get_time();
        const int64_t dt = now - s_drag_us_last;
        if (dt > 0) {
            const float inst = (float)(p.x - s_drag_x_last) * 1000.0f / (float)dt;
            if (fabsf(inst) > fabsf(s_drag_vx)) {
                s_drag_vx = inst;
            }
        }
        s_drag_x_last = p.x;
        s_drag_us_last = now;
        travel = (s_slide_dir > 0) ? (s_drag_x0 - p.x) : (p.x - s_drag_x0);
        if (travel < 0) {
            travel = 0;
        } else if (travel > 360) {
            travel = 360;
        }
    }

    drag_place(travel);
}

/*
 * The duration a turn gets when the speed, not the distance, decided it.
 *
 * This is the gesture path's own rule — 360 px at the hand's speed, floored at PAGE_SLIDE_MS
 * and capped at PAGE_SLIDE_MS_MAX — written once so the early answer and the release answer
 * cannot give the same flick two different lengths.
 */
static uint32_t slide_ms_for_speed(float px_per_ms)
{
    int32_t ms = (px_per_ms > 0.05f) ? (int32_t)(360.0f / px_per_ms) : (int32_t)PAGE_SLIDE_MS;

    if (ms < (int32_t)PAGE_SLIDE_MS) {
        ms = (int32_t)PAGE_SLIDE_MS;
    } else if (ms > (int32_t)PAGE_SLIDE_MS_MAX) {
        ms = (int32_t)PAGE_SLIDE_MS_MAX;
    }
    return (uint32_t)ms;
}

/* The same rule, held down to the flick's own ceiling: see FLICK_SLIDE_MS_MAX. */
static uint32_t slide_ms_for_flick(float px_per_ms)
{
    const uint32_t ms = slide_ms_for_speed(px_per_ms);
    return (ms > FLICK_SLIDE_MS_MAX) ? FLICK_SLIDE_MS_MAX : ms;
}

/*
 * A flick answered by the first movement, without waiting for the release.
 *
 * The drag below is right for a hand that is placing a page: the picture follows the finger
 * and the release decides. It is wrong for a flick. A flick is over in 100–150 ms, and by the
 * time LVGL sends its gesture the hand has already left; worse, the two snapshots of a turn's
 * setup take about 60 ms, so the drag's first frame arrives after the gesture would have
 * fired anyway. The old gesture path at least started the turn as soon as LVGL saw the swipe.
 *
 * This is the hybrid: while the finger is still down and before either drag threshold, the
 * poll's own speed reading is compared with the same DRAG_FLICK_PX_MS the release uses. A
 * hand that is already faster than that, and is going sideways more than up or down, is not
 * placing anything — it is flicking — so the classic turn is started at once, at the speed's
 * own duration. Everything slower falls through to the drag and is decided on release.
 *
 * The guards are the drag's guards: the gesture LVGL will send later is eaten
 * (s_drag_ate_gesture), the click that ends the contact is suppressed (swipe_was_taken), and
 * the watch flags are cleared so the poll cannot also start a drag on the same finger. The
 * same rule in the vertical axis opens or closes a drawer: a drawer is an object, so it has no
 * picture to wait for, but the gesture it replaces would still have waited for the release.
 */
static bool drag_flick_taken(lv_coord_t adx, lv_coord_t ady, float raw_vx, float raw_vy)
{
    if (s_drag_watch && adx >= FLICK_MIN_PX && adx > ady
        && fabsf(raw_vx) >= DRAG_FLICK_PX_MS) {
        const int dir = (raw_vx < 0.0f) ? 1 : -1;

        s_drag_watch = false;
        s_sheet_watch = false;
        s_drag_ate_gesture = true;
        s_finger_moved = true;
        swipe_was_taken();

        s_slide_ms = slide_ms_for_flick(fabsf(raw_vx));
        turn_to((int)s_page + dir, dir);
        return true;
    }

    if (s_sheet_watch && ady >= FLICK_MIN_PX && ady > adx
        && fabsf(raw_vy) >= DRAG_FLICK_PX_MS) {
        int nav;
        bool opening;

        if (s_nav_open) {
            /* The map leaves upwards; a flick down asks for the opposite and is left to the
             * drag, which does nothing with it either. */
            if (raw_vy > 0.0f) {
                return false;
            }
            nav = 1;
            opening = false;
        } else if (s_transport_open) {
            if (raw_vy < 0.0f) {
                return false;
            }
            nav = 0;
            opening = false;
        } else if (raw_vy < 0.0f) {
            nav = 0;
            opening = true;
        } else {
            nav = 1;
            opening = true;
        }

        s_drag_watch = false;
        s_sheet_watch = false;
        s_sheet_ate_gesture = true;
        s_finger_moved = true;
        swipe_was_taken();
        /* No page turn is coming, so the picture of the page is not worth keeping. */
        press_snap_drop();

        if (nav != 0) {
            if (opening) {
                nav_open();
            } else {
                nav_close();
            }
        } else if (opening) {
            transport_open();
        } else {
            transport_close();
        }
        return true;
    }

    return false;
}

/*
 * The poll. Fifteen milliseconds is under the panel's own frame cost, so it is the frames
 * and not this that limit the movement; what it buys is that the release is noticed within
 * a frame of the finger leaving.
 *
 * It carries both things a finger can carry: a page sideways, and a drawer up or down. They
 * never run at once, and which one a finger means is decided here and only here — by the
 * direction it went in, and by whether a drawer is already up.
 */
static void drag_timer_cb(lv_timer_t *timer)
{
    (void)timer;
    lv_indev_t *indev = drag_indev();
    if (indev == NULL) {
        return;
    }

    if (lv_indev_get_state(indev) != LV_INDEV_STATE_PRESSED) {
        s_contact_seen = false;
        s_sheet_watch = false;
        s_press_point_valid = false;
        s_finger_moved = false;
        if (s_drag_on) {
            s_drag_watch = false;
            drag_release(s_drag_carry);
        } else if (s_sheet_on) {
            sheet_release(s_sheet_carry);
        } else {
            s_drag_watch = false;
            /* A tap: no picture was taken and nothing has to be dropped. */
            press_snap_drop();
        }
        return;
    }

    lv_point_t p;
    lv_indev_get_point(indev, &p);

    const int64_t now = esp_timer_get_time();

    /* A new finger: where it started, and whether it may move anything at all. */
    if (!s_contact_seen) {
        s_contact_seen = true;
        s_sheet_y0 = p.y;
        s_sheet_last_y = p.y;
        s_sheet_us_last = now;
        s_sheet_vy = 0.0f;
        s_sheet_watch = (s_ready && !s_sliding && !drawer_in_flight());
        /* The gesture of the finger before this one was answered, or it would still be
         * waiting: see screen_gesture_cb(). */
        s_sheet_ate_gesture = false;
        s_drag_carry = false;
        s_sheet_carry = false;
        s_touch_x0 = p.x;
        s_touch_y0 = p.y;
        s_finger_moved = false;
    }

    /*
     * The finger's own speed, measured every poll and kept for the moment a drag begins:
     * the build that follows hides the finger, and this is the speed the hand had before it.
     */
    float raw_vx = 0.0f;
    float raw_vy = 0.0f;
    const int64_t raw_dt = now - s_touch_us_last;
    if (raw_dt > 0) {
        /* px per MILLISECOND, which is the unit every speed in this file is written in. */
        raw_vx = (float)(p.x - s_touch_x_last) * 1000.0f / (float)raw_dt;
        raw_vy = (float)(p.y - s_touch_y_last) * 1000.0f / (float)raw_dt;
    }
    s_touch_x_last = p.x;
    s_touch_y_last = p.y;
    s_touch_us_last = now;

    /*
     * A press that has gone as far as a drag threshold is a drag, not a long press.
     *
     * LVGL's long press is a clock: 400 ms with the finger down, and it does not watch the
     * finger. Its own move check applies only while a scrolling object is being dragged, and
     * nothing here scrolls, so a slow drag would toggle a macro under the hand at 400 ms. The
     * drag starts at 12 px sideways or 20 px vertically and any hand speed worth calling a
     * drag crosses that well before 400 ms, so the long press is pushed back on every poll
     * while the finger is displaced; the handlers refuse one that still arrives. The 5 px it
     * reacts to is deliberately below both thresholds: a hand at rest jitters by a pixel or
     * two and still gets its long press, while a hand that has begun to move is a drag.
     */
    {
        const lv_coord_t mx = (p.x > s_touch_x0) ? (p.x - s_touch_x0) : (s_touch_x0 - p.x);
        const lv_coord_t my = (p.y > s_touch_y0) ? (p.y - s_touch_y0) : (s_touch_y0 - p.y);

        if (mx >= LONG_PRESS_SLOP_PX || my >= LONG_PRESS_SLOP_PX) {
            s_finger_moved = true;
        }
        if (s_finger_moved) {
            lv_indev_reset_long_press(indev);
        }
    }

    if (s_drag_on) {
        /* Under the finger: travel is how far the page has been carried, never negative and
         * never past its own width. */
        lv_coord_t travel = (s_slide_dir > 0) ? (s_drag_x0 - p.x) : (p.x - s_drag_x0);

        const int64_t dt = now - s_drag_us_last;
        if (dt > 0) {
            const float inst = (float)(p.x - s_drag_x_last) * 1000.0f / (float)dt;
            s_drag_vx = 0.5f * s_drag_vx + 0.5f * inst;
            s_drag_x_last = p.x;
            s_drag_us_last = now;
        }

        /* The gesture's verdict is for the turn it named. A hand that goes back on it is
         * asking for the page to stay, so the carry goes with the reversal. */
        if (s_drag_carry && (s_drag_vx * (float)s_slide_dir) > 0.05f) {
            s_drag_carry = false;
        }

        if (travel > 360) {
            travel = 360;
        }
        drag_place(travel);
        return;
    }

    if (s_sheet_on) {
        const int64_t dt = now - s_sheet_us_last;
        if (dt > 0) {
            const float inst = (float)(p.y - s_sheet_last_y) * 1000.0f / (float)dt;
            s_sheet_vy = 0.5f * s_sheet_vy + 0.5f * inst;
            s_sheet_last_y = p.y;
            s_sheet_us_last = now;
        }

        if (s_sheet_carry && (s_sheet_vy * (float)s_sheet_carry_dir) < -0.05f) {
            s_sheet_carry = false;
        }

        sheet_place(p.y - s_sheet_y0);
        return;
    }

    if (!s_drag_watch && !s_sheet_watch) {
        return;
    }

    const lv_coord_t dx = p.x - s_drag_x0;
    const lv_coord_t dy = p.y - s_sheet_y0;
    const lv_coord_t adx = (dx < 0) ? -dx : dx;
    const lv_coord_t ady = (dy < 0) ? -dy : dy;

    /*
     * Speed first, distance second. A hand already travelling at a flick's speed has
     * answered the question the 12 px threshold would ask, and waiting for the threshold
     * only adds the frames it takes to get there. See drag_flick_taken().
     */
    if (drag_flick_taken(adx, ady, raw_vx, raw_vy)) {
        return;
    }

    /*
     * The first movement that says this is not a tap: photograph the page being left now,
     * while the finger still has 7 px to go before a sideways drag starts and 15 px before a
     * drawer does. A tap never gets here, so it never pays the render. The horizontal has to
     * be at least the vertical: a gesture that is already going up or down is a drawer, which
     * has its own pictures, and if it later turns sideways turn_setup() takes the picture.
     */
    if (s_drag_watch && !s_press_snap_armed && adx >= LONG_PRESS_SLOP_PX && adx >= ady) {
        s_press_snap_armed = true;
        s_press_snap = lv_snapshot_take(s_content, LV_COLOR_FORMAT_RGB565);
    }

    /* Sideways dominates: the page turns. */
    if (adx >= DRAG_START_PX && adx > ady && s_drag_watch) {
        s_drag_x_last = p.x;
        s_drag_us_last = now;
        /* The hand's speed BEFORE the build, not zero: the build hides the finger and the
         * release can arrive inside it. See s_touch_x_last. */
        s_drag_vx = raw_vx;
        s_drag_ate_gesture = true;
        s_sheet_watch = false;
        drag_begin((dx < 0) ? 1 : -1, adx);
        return;
    }

    /* Up or down dominates: a drawer moves, if one can. */
    if (ady >= SHEET_START_PX && ady > adx && s_sheet_watch) {
        int nav;
        bool opening;

        if (s_nav_open) {
            /* The map leaves downwards. A drag down does nothing to it: that is what the
             * gesture did before, and the map already covers what a new one would show. */
            if (dy > 0) {
                return;
            }
            nav = 1;
            opening = false;
        } else if (s_transport_open) {
            if (dy < 0) {
                return;
            }
            nav = 0;
            opening = false;
        } else if (dy < 0) {
            nav = 0;
            opening = true;
        } else {
            nav = 1;
            opening = true;
        }

        s_sheet_last_y = p.y;
        s_sheet_us_last = now;
        s_sheet_vy = raw_vy;
        sheet_begin(nav, opening, dy);
    }
}

/*
 * An absolute jump, from the navigator, which already knows the page it wants.
 *
 * No grouping and no wrapping: a tile that says SYS opens SYS, whether or not the
 * page being left is a settings page. Sending this through turn_to() is precisely
 * the bug that made the settings tiles unreachable — the group filter dutifully
 * turned a jump to SYS into "the next musical page".
 *
 * And no SLIDE either, which is the part that is about what it looks like rather than
 * about correctness. A swipe is a gesture across the page, so the page moving is the
 * gesture being answered. A tile is a choice, and the map is already closing over the
 * page when it is made: sliding the new section in underneath that reads as the section
 * arriving out of the map, which is exactly as strange as it sounds. The page is simply
 * there when the map has gone.
 */
static void jump_to(int page_idx)
{
    if (page_idx < 0) {
        page_idx = 0;
    } else if (page_idx >= PAGE_COUNT) {
        page_idx = PAGE_COUNT - 1;
    }

    apply_page(page_idx);
    lv_obj_set_x(s_content, 0);
}

/*
 * The page turn, by index.
 *
 * The direction is derived here rather than from the index difference alone so
 * that a WRAP still travels forward: from the last page to the first the content
 * moves the same way the finger did, instead of rewinding through every page.
 * The gesture handler, which knows which way the finger went, passes it in.
 */
static void goto_page(int page_idx)
{
    jump_to(page_idx);
}

#if CONFIG_OBOD_SCREENSHOTS
/*
 * The page table, for screenshots.c. Four small answers, all of them about things only this
 * file knows: where PAGE_COUNT is, what PAGES[] calls a page, and which function turns one.
 *
 * They are the whole interface between the instrument and its snapshots, so the snapshot code
 * cannot take a page it did not ask for and cannot rename one it publishes: the title it sends
 * is the title drawn in the middle of the dial, character for character, and tools/promo-check.js
 * is what holds that name to the one the documentation uses.
 *
 * The walk covers every page in PAGES and nothing else, in the order the table lists them, and
 * the count is PAGE_COUNT rather than a number written down here: a page added to the instrument
 * is in the snapshots with nothing to remember.
 */
int synth_ui_page_count(void)
{
    return (int)PAGE_COUNT;
}

const char *synth_ui_page_title(int idx)
{
    return (idx >= 0 && idx < (int)PAGE_COUNT) ? PAGES[idx].title : "";
}

void synth_ui_page_show(int idx)
{
    if (idx >= 0 && idx < (int)PAGE_COUNT) {
        goto_page(idx);
    }
}

void synth_ui_page_pump(uint32_t ms)
{
    const TickType_t until = xTaskGetTickCount() + pdMS_TO_TICKS(ms);

    /* The slide is an LVGL animation and only moves when the timers are turned, and the timer
     * task is stopped for the duration — it wants the lock this runs under. Ten milliseconds a
     * turn is finer than any animation on the instrument needs. */
    while (xTaskGetTickCount() < until) {
        lv_timer_handler();
        vTaskDelay(pdMS_TO_TICKS(10));
    }
}
#endif

/* -------------------------------------------------------------------------- */
/* Sequencer display                                                          */
/* -------------------------------------------------------------------------- */

/*
 * Which pages carry a figure: the lead's on EUCLID, the percussion's on PERC SEQ.
 *
 * Two grids, and everything that draws or reads one asks this first — the ring of
 * dots, the LED ring, and the two timers that drive them. That way "which figure" is
 * answered in the two functions below rather than at six call sites, and a third
 * part with a figure would be a third case here and nothing else.
 */
static bool page_has_figure(void)
{
    return page_draws_figure(s_page);
}

/*
 * The figure of the page you are on, and whether one step of it is an onset.
 *
 * The two are separate calls in the app on purpose, because they are separate
 * things: the lead's grid can be taken over by the arpeggiator, and the drum plays
 * its own figure whether or not anything else is running, so anything asking for
 * "the sequencer" would have to know which one it meant. Here the PAGE decides, and
 * what a page shows is what that page plays: the lead's ring never draws the drum,
 * and the drum's never draws the lead. Both functions assume page_has_figure(); on
 * any other page they answer with the lead's, which nothing on such a page reads.
 */
static void page_seq_view(synth_app_seq_view_t *out)
{
    if (s_page == PAGE_PERC_SEQ) {
        synth_app_perc_view(out);
    } else {
        synth_app_seq_view(out);
    }
}

static int page_seq_is_onset(int position)
{
    return (s_page == PAGE_PERC_SEQ) ? synth_app_perc_is_onset(position)
                                     : synth_app_seq_is_onset(position);
}

/*
 * Whether a step of that figure is ACCENTED.
 *
 * BOTH figures can be, and that is the change: the accent used to be the drum's alone
 * because the lead had no velocity to speak of, and it has one now — the level each of
 * its three voices is opened at, multiplied once per note — so the lead's ring shows the
 * accent too. Each figure has its own accent parameter now, and each is asked about its
 * own steps: see synth_app_seq_is_accent() and synth_app_perc_is_accent().
 *
 * Asked of synth_app rather than worked out from the figure here, for the reason
 * page_seq_is_onset() gives above: the rule is how the accent is struck, and a ring that
 * recomputed it could mark a step the engine does not accent. The rule is a mask of
 * positions in the bar, so the answer is not a function of the position alone — it moves
 * when the chosen figure moves, which is exactly what this per-dot question is for.
 */
static int page_seq_is_accent(int position)
{
    return (s_page == PAGE_PERC_SEQ) ? synth_app_perc_is_accent(position)
                                     : synth_app_seq_is_accent(position);
}

/*
 * The dots are the GRID, not the onsets.
 *
 * Every one of the n positions gets a dot and the ones the pattern sounds are
 * filled. Drawing only the onsets would be the obvious thing and it would be
 * wrong: with the silent positions missing, a dense pattern and a sparse one are
 * the same set of dots, and showing the difference between them is the entire
 * reason this is on the screen.
 *
 * The cursor sweeps the ring clockwise from twelve, over the silent positions as
 * well, so you watch the pattern go past instead of watching notes appear from
 * nowhere. It is drawn only while the transport is running: the sequencer's clock does
 * not stop behind STOP, so the position this is drawn from goes on moving, and a cursor
 * that followed it would run over a bar nobody is hearing. See refresh_sequencer().
 *
 * The shape of the figure is all this needs to know: both parts report steps,
 * pulses, rotation and a position in the same terms, so the same ring draws either
 * one and only the values change.
 */
/*
 * Whether anything the instrument makes can reach the output at all.
 *
 * STOP closes the rack's input gate, so the generators stop arriving at the output even though
 * they keep running; the master at zero silences what is left, the effects' tails included.
 * Nothing about a part's own mixer can be heard while either of those is true.
 */
static bool output_open(void)
{
    return synth_app_is_running() && synth_app_get_param(SYNTH_PARAM_LEVEL) > 0.0f;
}

/*
 * How much of a part reaches the output, from the three things that decide it: its level, its
 * send, and where in the channel that send is taken.
 *
 * The reverb's MIX is a BALANCE — the rack sums dry * (1 - mix) with wet * mix — so a part
 * arrives at the output twice: once through the dry path, scaled by its level, and once through
 * the reverb, scaled by its send. Which of the two the level scales is what the pre/post
 * distinction decides, and the engine makes the parts differently:
 *
 *   the layers (the drone's three registers, and the lead) send BEFORE their faders — the rack
 *   takes the send from the raw layer, so a layer at zero level with an open send is still
 *   heard, in the reverb alone;
 *
 *   the percussion sends AFTER its fader — a hit at zero level is not struck at all, so its
 *   level scales what is sent as well as what is heard, and the whole thing comes to the level.
 *
 * This is a display gain and not the audio path's own arithmetic: it answers whether a part is
 * heard and how much of it, not what the samples are.
 */
static float part_output_gain(float level, float send, bool send_is_post_fader)
{
    const float mix = synth_app_get_param(SYNTH_PARAM_VERB_MIX);
    const float dry = 1.0f - mix;

    if (send_is_post_fader) {
        return level * (dry + send * mix);
    }
    return level * dry + send * mix;
}

/*
 * Whether the part this page draws can be heard at all.
 *
 * The engine gates its notes whatever the mixer says — the level is applied after the gate — so
 * without this the screen blinks a rhythm for a part that is turned all the way down, for one
 * whose level and send are both shut, or for any of them while the box is stopped. Both of the
 * lead's figures are the lead's part — the euclid page draws one and the arpeggiator the other —
 * and the drum's own page is the only one that asks the percussion. See part_output_gain().
 */
static bool page_part_audible(void)
{
    if (!output_open()) {
        return false;
    }
    if (s_page == PAGE_EUCLID || s_page == PAGE_ARP) {
        return part_output_gain(synth_app_get_param(SYNTH_PARAM_LEAD_LEVEL),
                                synth_app_get_param(SYNTH_PARAM_SEND_LEAD),
                                false) > 0.0f;
    }
    if (s_page == PAGE_PERC_SEQ) {
        return part_output_gain(synth_app_get_param(SYNTH_PARAM_PERC_LEVEL),
                                synth_app_get_param(SYNTH_PARAM_SEND_PERC),
                                true) > 0.0f;
    }
    return true;
}

static void refresh_sequencer(void)
{
    /* Fixed here rather than in the page-apply path: this runs on the sequencer's own
     * timer, so it catches the arp being switched on or off while the page is open, and
     * not only the moment the page is entered. */
    refresh_arp_notice(false);

    if (!s_ready || !page_has_figure() || s_seq_cursor == NULL) {
        return;
    }

    synth_app_seq_view_t v;
    page_seq_view(&v);

    if (v.steps < 1) {
        return;
    }
    if (v.steps > SEQ_DOT_MAX) {
        v.steps = SEQ_DOT_MAX;
    }

    const int pos = v.position % v.steps;

    /*
     * The accent as the ring last saw it: the parameter's own 0..1, read here rather
     * than asked of synth_app because this is a memo of "has anything the dots are
     * drawn from changed", not a judgement about the accent. Zero means the figure is
     * OFF, where no step is accented and the dots are the sizes they always were.
     * Quantised to the byte, which is finer than any step the knob can be moved by — the
     * list has eight entries, so one detent moves this by 36.
     *
     * Read on whichever figure page is on screen, against that page's own accent: the
     * drum's ring follows SYNTH_PARAM_PERC_ACCENT and the lead's SYNTH_PARAM_SEQ_ACCENT,
     * two values that never move each other. The memo is cleared when a page is entered,
     * so a figure changed on the other page still redraws when its page comes back. It is
     * read on no other page, because no other page has dots.
     */
    const synth_param_t accent_param = (s_page == PAGE_PERC_SEQ) ? SYNTH_PARAM_PERC_ACCENT
                                                                : SYNTH_PARAM_SEQ_ACCENT;
    const int accent = (int)(synth_app_get_param(accent_param) * 255.0f + 0.5f);

    /*
     * The drum's ring is drawn from the PART, so its memo is the part and not a figure: a
     * groove laid into the bar by the variation, a fill taking the second half, an open hat
     * closing the cycle — any of those can change with every bar while steps, pulses and
     * rotation stay put. A signature of the bar costs sixteen calls and says whether the
     * dots have to move at all.
     */
    const bool drum = (s_page == PAGE_PERC_SEQ);
    uint32_t msig = 0u;
    if (drum) {
        for (int i = 0; i < v.steps; i++) {
            msig = msig * 131u + (uint32_t)(synth_app_perc_step_mask(i) & 0x3F);
        }
    }

    const bool pattern_changed = (v.steps != s_seq_shown_steps)
                              || (!drum && v.pulses != s_seq_shown_pulses)
                              || (!drum && v.rotate != s_seq_shown_rot)
                              || (accent != s_seq_shown_accent)
                              || (drum && msig != s_seq_shown_msig);

    if (pattern_changed) {
        s_seq_shown_steps = v.steps;
        s_seq_shown_pulses = v.pulses;
        s_seq_shown_rot = v.rotate;
        s_seq_shown_accent = accent;
        s_seq_shown_msig = msig;
        /* The cursor's position depends on n, so it is redrawn with the ring. */
        s_seq_shown_pos = -1;

        for (int i = 0; i < SEQ_DOT_MAX; i++) {
            if (i >= v.steps) {
                lv_obj_set_hidden(s_seq_dot[i], true);
                continue;
            }

            /*
             * Two readings of one ring, and the page decides which.
             *
             * THE LEAD: three sizes around the euclid. A step the chosen figure marks keeps
             * the size every onset has always had, and what the figure changes is the OTHER
             * onsets: they come down to the middle size, exactly as their velocity comes
             * down to the base.
             *
             * THE DRUM: the part itself. The ring is the bar, so each dot says what is
             * struck on its sixteenth — the kick largest and brightest, then the snare, the
             * tom and the hats, with a ghost note the smallest mark above silence. A fill
             * takes the second half of the bar and is drawn at the snare's size on the
             * kick's brightness, because it is the loudest thing in the bar and the only
             * place the pattern leaves its own shape. Nothing here is invented: every size
             * comes from synth_app_perc_step_mask(), which is what the engine strikes.
             */
            int d = SEQ_DOT_OFF;
            uint32_t col = COL_STEP_OFF;
            bool hollow = false;

            if (drum) {
                const int m = synth_app_perc_step_mask(i);

                if (m & SYNTH_APP_PERC_STEP_FILL) {
                    /* A fill is a different event, not a louder hit: the big HOLLOW ring in
                     * the cursor's own hot colour. Nothing else in the bar is drawn hollow at
                     * that size, so the second half of a fill bar is unmistakable. */
                    d = SEQ_DOT_KICK;
                    col = COL_STEP_HOT;
                    hollow = true;
                } else if (m & SYNTH_APP_PERC_STEP_KICK) {
                    d = SEQ_DOT_KICK;
                    col = COL_STEP_ON;
                } else if (m & SYNTH_APP_PERC_STEP_SNARE) {
                    d = SEQ_DOT_SNARE;
                    col = COL_TEXT;
                } else if (m & SYNTH_APP_PERC_STEP_TOM) {
                    d = SEQ_DOT_TOM;
                    col = COL_ACCENT;
                } else if (m & SYNTH_APP_PERC_STEP_HAT) {
                    /* The surface, not a hit: a ring, so a bar of hats reads as texture
                     * around the solid marks of the drums. */
                    d = SEQ_DOT_HAT;
                    col = COL_MUTED;
                    hollow = true;
                } else if (m & SYNTH_APP_PERC_STEP_GHOST) {
                    d = SEQ_DOT_GHOST;
                    col = COL_MUTED;
                } else {
                    d = SEQ_DOT_SILENT;
                    col = COL_ARC_BG;
                }

                /* The accent, applied the way it is played: the marked steps stay full and
                 * the others come down. A silent step has nothing to take down, and a hollow
                 * mark keeps its size because its ring is what carries it. */
                if (!hollow && d > SEQ_DOT_HAT && accent > 0 && page_seq_is_accent(i) == 0) {
                    d -= (d >= SEQ_DOT_SNARE) ? SEQ_DOT_ACCENT_CUT : (SEQ_DOT_ACCENT_CUT / 2);
                }
            } else {
                const bool on = page_seq_is_onset(i) != 0;

                if (on) {
                    d = (accent > 0 && page_seq_is_accent(i) == 0) ? SEQ_DOT_MID : SEQ_DOT_ON;
                    col = COL_STEP_ON;
                }
            }

            const int angle = (i * 360) / v.steps;
            const int x = (SEQ_RING_R * lv_trigo_sin((int16_t)angle)) / 32767;
            const int y = -(SEQ_RING_R * lv_trigo_cos((int16_t)angle)) / 32767;

            lv_obj_set_hidden(s_seq_dot[i], false);
            lv_obj_set_size(s_seq_dot[i], d, d);
            lv_obj_align(s_seq_dot[i], LV_ALIGN_CENTER, x, y);
            lv_obj_set_style_bg_color(s_seq_dot[i], lv_color_hex(col), LV_PART_MAIN);
            lv_obj_set_style_bg_opa(s_seq_dot[i], hollow ? LV_OPA_TRANSP : LV_OPA_COVER,
                                    LV_PART_MAIN);
            lv_obj_set_style_border_width(s_seq_dot[i], hollow ? 2 : 0, LV_PART_MAIN);
            lv_obj_set_style_border_color(s_seq_dot[i], lv_color_hex(col), LV_PART_MAIN);
        }
    }

    /*
     * No cursor while the transport is stopped.
     *
     * The position above comes from the ENGINE, and the engine's clock does not stop behind
     * STOP: both figures keep stepping with the rack's input gate shut, on purpose, so the
     * instrument comes back into the phrase rather than restarting it (see
     * synth_app_set_running()). A cursor drawn from that position therefore sweeps a bar
     * nothing is playing — which is what the panel showed, on both figure pages alike,
     * since both are drawn from this one block.
     *
     * Hidden rather than frozen, and the two memos cleared with it: the cursor is then
     * placed from scratch on the first running frame, on the step the engine is really on.
     * There is no position kept here that could be one step behind the transport, and
     * nothing about the figure, the tempo, the accents or the gate is touched — this is
     * where the display stops drawing, nothing more.
     *
     * The dots above are NOT part of this: they are the pattern and are there to be read
     * while the box is stopped, which is when a figure is chosen.
     */
    if (!synth_app_is_running()) {
        lv_obj_set_hidden(s_seq_cursor, true);
        s_seq_shown_pos = -1;
        s_seq_shown_sound = -1;
        return;
    }

    if (pos != s_seq_shown_pos || v.sounding != s_seq_shown_sound) {
        s_seq_shown_pos = pos;
        s_seq_shown_sound = v.sounding;

        const int angle = (pos * 360) / v.steps;
        const int x = (SEQ_RING_R * lv_trigo_sin((int16_t)angle)) / 32767;
        const int y = -(SEQ_RING_R * lv_trigo_cos((int16_t)angle)) / 32767;

        lv_obj_set_hidden(s_seq_cursor, false);
        lv_obj_align(s_seq_cursor, LV_ALIGN_CENTER, x, y);
        /* Bright only while a note is actually gated, so the cursor says
         * something the ears cannot: which dot is sounding at this instant. */
        /* Held back when the part is turned down: the flash says "this step is sounding", and a
         * part at zero does not sound. See page_part_audible(). */
        lv_obj_set_style_border_color(s_seq_cursor,
                                      lv_color_hex((v.sounding && page_part_audible())
                                                       ? COL_STEP_HOT : COL_STEP_DIM),
                                      LV_PART_MAIN);
    }
}

static void seq_display_show(int on)
{
    const bool show = on && page_has_figure();

    for (int i = 0; i < SEQ_DOT_MAX; i++) {
        lv_obj_set_hidden(s_seq_dot[i], true);
    }
    lv_obj_set_hidden(s_seq_cursor, true);

    /* Forced on every page change, so coming back to either figure page redraws its
     * pattern rather than trusting dots that were hidden in the meantime — including
     * the case of walking from one figure page to the other, where the dots are the
     * right shape but the wrong pattern. */
    s_seq_shown_steps = -1;
    s_seq_shown_pulses = -1;
    s_seq_shown_rot = -1;
    s_seq_shown_accent = -1;
    s_seq_shown_msig = 0u;
    s_seq_shown_pos = -1;
    s_seq_shown_sound = -1;

    if (show) {
        refresh_sequencer();
    }
}

static void seq_timer_cb(lv_timer_t *timer)
{
    (void)timer;

    /* The dots ride on the page, so they are of no use while the page is in flight and
     * every one of them would be another area painted inside a turn's frame. */
    if (s_sliding) {
        return;
    }

    refresh_sequencer();
}

/* -------------------------------------------------------------------------- */
/* The navigator                                                              */
/* -------------------------------------------------------------------------- */

/*
 * The run of PAGES[] that shares this page's group, as a first index and a length.
 *
 * PAGES[] is ordered by family and the swipe walks it in order, so a group IS a
 * contiguous run. That is the property the wheel's step and the pagination dots rely
 * on, and it is the reason the step can stop at the ends of the run instead of
 * walking into the next family.
 */
static void nav_group_span(uint8_t page, int *first, int *count)
{
    const uint8_t grp = PAGES[page].group;
    int a = (int)page;
    int b = (int)page;

    while (a > 0 && PAGES[a - 1].group == grp) {
        a--;
    }
    while (b + 1 < (int)PAGE_COUNT && PAGES[b + 1].group == grp) {
        b++;
    }

    /* Every page of the family is a place you can stand, so the row is the whole span
     * and nothing is subtracted from it. */
    *first = a;
    *count = b - a + 1;
}

/* Where a page stands among its family. A family's pages are contiguous and all of them
 * are places you can stand, so the position is how far the page is from the first of
 * them — asked here rather than subtracted at each of the two callers. */
static int nav_group_rank(uint8_t page)
{
    const uint8_t grp = PAGES[page].group;
    int rank = 0;

    for (int i = (int)page - 1; i >= 0 && PAGES[i].group == grp; i--) {
        rank++;
    }
    return rank;
}

/*
 * Hand the knob to the map's PAGES.
 *
 * While the curtain is up the knob walks the sections of the current group and
 * reaches no parameter: turning to find a section would otherwise rewrite whatever
 * was selected before the map opened — a value the user never touched and cannot
 * even see. The arc carries the position within the group, which is what the dots
 * along the bottom are saying too.
 */
static void proxy_load_nav(void)
{
    int first = 0;
    int count = 0;
    nav_group_span(s_page, &first, &count);

    /* Hidden pages sit between the family's first page and this one, so the position on
     * the arc is not the difference of the two indices. */
    const int rank = nav_group_rank(s_page);

    s_discrete = false;
    s_steps = PARAM_STEPS;
    s_proxy_positions = 0;
    s_mult = 1;

    s_syncing = true;
    lv_arc_set_range(s_proxy, 0, (count > 1) ? count - 1 : 1);
    lv_arc_set_value(s_proxy, (int32_t)rank);
    s_proxy_value = (int32_t)rank;
    s_arc_last = s_proxy_value;
    s_syncing = false;
}

/*
 * Give the knob back to the parameter it was driving.
 *
 * A non-knob page has no parameter to return to, so the proxy is parked at zero
 * rather than left pointing at something that is not on screen.
 */
static void proxy_restore(void)
{
    const ui_page_t *p = page();

    if (p->knob_count > 0) {
        proxy_load(p->knobs[sel_index()].param);
        return;
    }

    s_discrete = false;
    s_steps = PARAM_STEPS;
    s_mult = 1;

    s_syncing = true;
    lv_arc_set_range(s_proxy, 0, PARAM_STEPS);
    lv_arc_set_value(s_proxy, 0);
    s_proxy_value = 0;
    s_arc_last = 0;
    s_syncing = false;
}

/*
 * The wheel's page step, and the one line that turns it off.
 *
 * The map shows one group of sections at a time, so a turn moves along THAT group
 * and stops at its ends rather than walking into the next family. Setting
 * NAV_WHEEL_PAGES to 0 makes the wheel do nothing on the curtain again — it is
 * checked here and nowhere else.
 */
#define NAV_WHEEL_PAGES 1

static void nav_mark_current(void);   /* the map's marks, further down this file */
static void nav_layout(void);         /* and where the names sit in the cells */

static void nav_page_step(int delta)
{
    if (delta == 0) {
        return;
    }

    int first = 0;
    int count = 0;
    nav_group_span(s_page, &first, &count);
    if (count < 2) {
        return;
    }

    const int here = nav_group_rank(s_page);
    int at = here + delta;
    if (at < 0) {
        at = 0;
    } else if (at >= count) {
        at = count - 1;
    }
    if (at == here) {
        return;
    }

    /* The position is counted among the family's pages, so walk to the nth of them. */
    int target = -1;
    int seen = 0;
    const uint8_t grp = PAGES[first].group;
    for (int i = first; i < (int)PAGE_COUNT && PAGES[i].group == grp; i++) {
        if (seen == at) {
            target = i;
            break;
        }
        seen++;
    }
    if (target < 0) {
        return;
    }

    jump_to(target);
    nav_layout();        /* the current tile grows, so the geometry follows the page */
    nav_mark_current();
    proxy_load_nav();
}

/*
 * THE LAYOUT: one point per section, in tenths of a pixel from the middle of the screen, and a
 * weight in px2.
 *
 * These points ARE the map. A section's cell is every point of the screen where that section's claim
 * is the smallest, and the claim is `|p - s|^2 + w`. With the weight at zero that is the nearest
 * point; the weights are what make the cells' areas equal, and a LARGER WEIGHT IS A SMALLER CELL.
 * That sign is the half of this that has to be read the same way in every place that touches it —
 * the cut here, the tap in nav_page_at(), and each script under tools/voronoi-prototype — and
 * nav_page_at() carries a note about what happens when one of them disagrees.
 *
 * One number here moves one seam and no other, and there is no packing arithmetic to keep in step
 * with it. The arrangement can be dragged into shape and read back as a table, which is what this
 * one is: it came out of tools/voronoi-prototype/editor.html, where the points were moved by hand
 * against the measured cell areas and the room each name needs.
 *
 * WHY WEIGHTS AND NOT JUST POINTS. The mosaic covers the whole round screen, so the cells on the rim
 * are cut by the screen's own edge: on these points alone they were 3314 px2 against 5348, and
 * moving a point only makes one cell larger at a neighbour's expense without changing how much of
 * the disc there is. A weight does: it moves that cell's seams and nothing else's. Solved for equal
 * areas these points give 4617..4619 px2, and the weights below are what that solve printed —
 * tools/voronoi-prototype/solve_layout.py, which reads this table, solves it and prints it back.
 *
 * The table is keyed by PAGE and not by position: the arrangement and the page numbering are two
 * different things — the numbering is what the knob walks and what every address in this file uses,
 * and moving a cell must not be able to renumber a page.
 *
 * Tenths, because the table came out of a drag. Rounding it to whole pixels would move a seam by up
 * to half a pixel for no reason, and a cell is only sixty pixels across.
 */
static const int32_t NAV_SITES[PAGE_COUNT][3] = {
    [PAGE_PERC      ] = { 1210,   297,       0 },
    [PAGE_TONE      ] = {   11,  -661,   -1841 },
    [PAGE_ENV       ] = {  524,  -404,   -1839 },
    [PAGE_PERC_SEQ  ] = { 1178,  -248,     -28 },
    [PAGE_ARP       ] = {  277,   600,   -1839 },
    [PAGE_EUCLID    ] = { -297,   591,   -1839 },
    [PAGE_SCALE     ] = { -647,   136,   -1839 },
    [PAGE_LEAD      ] = { -510,  -421,   -1838 },
    [PAGE_DRONE     ] = {   21, -1246,        -4 },
    [PAGE_FILTER    ] = {  540, -1076,       -33 },
    [PAGE_MOD       ] = {  987,  -761,        -2 },
    [PAGE_MASTER    ] = {    0,     0,     -2361 },
    [PAGE_MIX       ] = {  642,   158,     -1839 },
    [PAGE_SEND_REV  ] = {  929,   766,       -24 },
    [PAGE_SEND_CHR  ] = {  522,  1131,         3 },
    [PAGE_SEND_DLY  ] = {  -20,  1203,       -28 },
    [PAGE_SYS       ] = { -559,  1114,        -1 },
    [PAGE_SYS2      ] = { -953,   735,       -30 },
    [PAGE_PRESET    ] = {-1219,   257,        -1 },
    /* PERC MIX стоит ровно на месте пресетов: плитка у них одна и та же, и
     * переезд страницы не сдвинул ни одну соседнюю ячейку. */
    [PAGE_PERC_MIX  ] = {-1219,   257,        -1 },
    [PAGE_CHORUS    ] = {-1169,  -287,       -24 },
    [PAGE_DELAY     ] = { -961,  -793,         5 },
    [PAGE_VERB      ] = { -504, -1093,       -26 },
};
_Static_assert(sizeof(NAV_SITES) / sizeof(NAV_SITES[0]) == PAGE_COUNT,
               "every page needs a point on the map");

/* The points are in tenths and the weights in px2, so a weight is a hundred tenths of a tenth. */
#define NAV_W_UNIT 100

/*
 * The cut's working room, and the file's rather than the stack's: nav_measure() runs once and needs
 * a buffer per clip, and a hundred floats twice over is not something to put on a task's stack.
 */
static float s_nav_v[NAV_WORK_V_MAX * 2];
static float s_nav_cut[NAV_WORK_V_MAX * 2];

/*
 * Clip a convex polygon by the half-plane a*x + b*y <= c, in place.
 *
 * The clip of a convex polygon by a half-plane is convex, and it adds at most one vertex per
 * crossing, so the buffer above can never overflow. A vertex that lands exactly on the line is kept
 * rather than dropped: a corner shared by three cells has to stay in all three, or the mosaic grows
 * a pinhole.
 */
static int nav_clip(float *v, int n, float a, float b, float c)
{
    int m = 0;

    for (int k = 0; k < n; k++) {
        const int j = (k + 1 == n) ? 0 : (k + 1);
        const float px = v[k * 2];
        const float py = v[k * 2 + 1];
        const float qx = v[j * 2];
        const float qy = v[j * 2 + 1];
        const float dp = a * px + b * py - c;
        const float dq = a * qx + b * qy - c;

        if (dp <= 0.0f) {
            s_nav_cut[m * 2] = px;
            s_nav_cut[m * 2 + 1] = py;
            m++;
        }

        if ((dp < 0.0f && dq > 0.0f) || (dq < 0.0f && dp > 0.0f)) {
            const float t = dp / (dp - dq);
            s_nav_cut[m * 2] = px + t * (qx - px);
            s_nav_cut[m * 2 + 1] = py + t * (qy - py);
            m++;
        }
    }

    for (int k = 0; k < m * 2; k++) {
        v[k] = s_nav_cut[k];
    }

    return m;
}

/*
 * The same convex polygon with every edge moved `d` pixels toward its middle (d > 0) or away from it
 * (d < 0), and the vertices put back where the moved edges cross.
 *
 * Both are always defined because the polygon is convex, and the inward normal of an edge is
 * (-dy, dx) because nav_measure() leaves every cell wound the same way. A pair of edges crossing at
 * a very shallow angle — two nearly-collinear points of an arc — is left where it is: the crossing
 * point would be far away, and the vertex is within a pixel of where moving it by `d` puts it.
 */
static void nav_offset(const float *v, int n, float d, float *out)
{
    float nx[NAV_CELL_V_MAX], ny[NAV_CELL_V_MAX], nc[NAV_CELL_V_MAX];

    for (int k = 0; k < n; k++) {
        const int q = (k + 1 == n) ? 0 : (k + 1);
        const float ax = v[k * 2];
        const float ay = v[k * 2 + 1];
        const float ex = v[q * 2] - ax;
        const float ey = v[q * 2 + 1] - ay;
        const float len = sqrtf(ex * ex + ey * ey);

        out[k * 2] = ax;
        out[k * 2 + 1] = ay;

        if (len < 0.01f) {
            nx[k] = 0.0f;
            ny[k] = 0.0f;
            nc[k] = 0.0f;
            continue;
        }

        nx[k] = -ey / len;
        ny[k] = ex / len;
        /* The edge in normal form, n.p = c: moved by `d`, c moves by exactly that much. */
        nc[k] = nx[k] * ax + ny[k] * ay + d;
    }

    for (int k = 0; k < n; k++) {
        const int p = (k + n - 1) % n;
        const float det = nx[p] * ny[k] - ny[p] * nx[k];

        if (fabsf(det) < 0.2f) {
            out[k * 2] += d * nx[k];
            out[k * 2 + 1] += d * ny[k];
            continue;
        }

        out[k * 2] = (nc[p] * ny[k] - nc[k] * ny[p]) / det;
        out[k * 2 + 1] = (nx[p] * nc[k] - nx[k] * nc[p]) / det;
    }
}

/*
 * Put a point back inside the cell grown by half a pixel, and leave it where it is if it is already.
 *
 * This exists for the fan of triangles a marked cell is filled with. Each triangle is drawn a little
 * wide of its own edges, because two triangles that share a side each composite on their own and
 * without an overlap their antialiased coverages add up to less than one — the hairline a fan is
 * known for. But moving a triangle's sides out moves a sharp corner out by more than that by
 * 1/sin(half the angle): a Voronoi cell has corners sharp enough to send a corner of the fan several
 * pixels past the cell's edge, which used to show as a bright spur over the neighbour.
 *
 * The fan is spread from the middle of the cell, which keeps those corners wide to begin with (the
 * worst moved 2.8 px before that). Clamping finishes the job: the point is pulled back onto the
 * grown edge it fell outside of, so a triangle reaches half a pixel past the cell and no further —
 * and the fan is drawn from a cell inset by that same half pixel, so what the edge lands on is the
 * cell's own colour. Nothing is drawn over it any more: there is no cut to hide it in.
 */
static void nav_clamp(const float *cell, int n, float *p)
{
    for (int k = 0; k < n; k++) {
        const int q = (k + 1 == n) ? 0 : (k + 1);
        const float ax = cell[k * 2];
        const float ay = cell[k * 2 + 1];
        const float ex = cell[q * 2] - ax;
        const float ey = cell[q * 2 + 1] - ay;
        const float len = sqrtf(ex * ex + ey * ey);

        if (len < 0.01f) {
            continue;
        }

        /* The cell's inward normal, as in nav_offset(); the grown edge is half a pixel out from it. */
        const float nx = -ey / len;
        const float ny = ex / len;
        const float out = (p[0] - ax) * nx + (p[1] - ay) * ny + 0.5f;

        if (out < 0.0f) {
            p[0] -= out * nx;
            p[1] -= out * ny;
        }
    }
}

/*
 * Cut the cells, once, at boot.
 *
 * Each cell starts as the screen's own disc and is cut by one half-plane per other section: the
 * points at least as near to this section's point as to that one form a single half-plane, and its
 * boundary is the seam the two cells share. Twenty-one of those on at most ten vertices, for
 * twenty-two sections, is a few hundred multiplications spent once and never again.
 *
 * A vertex within half a pixel of the line through its neighbours is dropped: on the arc it is one
 * more edge and no shape, and the chord it leaves is under a pixel off the circle.
 */
static void nav_measure(void)
{
    int v_max = 0;
    int area_lo = 0;
    int area_hi = 0;
    int clear_lo = 0;

    for (int i = 0; i < (int)PAGE_COUNT; i++) {
        s_nav_cell_n[i] = 0;

        if (!PAGES[i].tile) {
            continue;
        }

        const float xi = (float)NAV_SITES[i][0] * 0.1f;
        const float yi = (float)NAV_SITES[i][1] * 0.1f;
        const int32_t wi = NAV_SITES[i][2];

        for (int k = 0; k < NAV_GON; k++) {
            const float ang = 2.0f * NAV_PI * (float)k / (float)NAV_GON;
            s_nav_v[k * 2] = (float)NAV_CELL_R * cosf(ang);
            s_nav_v[k * 2 + 1] = (float)NAV_CELL_R * sinf(ang);
        }

        int n = NAV_GON;

        for (int j = 0; j < (int)PAGE_COUNT; j++) {
            if (j == i || !PAGES[j].tile) {
                continue;
            }

            const float xj = (float)NAV_SITES[j][0] * 0.1f;
            const float yj = (float)NAV_SITES[j][1] * 0.1f;
            const int32_t wj = NAV_SITES[j][2];

            /* The same half-plane as before, with the weights added: a point's claim is
             * |p - s|^2 - w against every other's, so the seam between two of them is where
             * 2p(sj - si) = |sj|^2 - |si|^2 + (wj - wi). */
            n = nav_clip(s_nav_v, n,
                         2.0f * (xj - xi), 2.0f * (yj - yi),
                         ((xj * xj + yj * yj) - (xi * xi + yi * yi)) + (float)(wj - wi));

            if (n < 3) {
                break;
            }
        }

        if (n < 3) {
            continue;
        }

        /* The straight ones out, the corners kept. */
        int keep = 0;

        for (int k = 0; k < n; k++) {
            const int p = (k + n - 1) % n;
            const int q = (k + 1) % n;
            const float ax = s_nav_v[p * 2], ay = s_nav_v[p * 2 + 1];
            const float bx = s_nav_v[k * 2], by = s_nav_v[k * 2 + 1];
            const float cx = s_nav_v[q * 2], cy = s_nav_v[q * 2 + 1];
            const float ex = cx - ax, ey = cy - ay;
            const float len = sqrtf(ex * ex + ey * ey);

            if (len > 0.01f && fabsf(ex * (by - ay) - ey * (bx - ax)) / len <= 0.5f) {
                continue;
            }

            if (keep < NAV_CELL_V_MAX) {
                s_nav_cut[keep * 2] = bx;
                s_nav_cut[keep * 2 + 1] = by;
            }

            keep++;
        }

        if (keep < 3 || keep > NAV_CELL_V_MAX) {
            /* Only reachable if the table is changed into something the buffer cannot hold. The
             * page then has no cell and the mosaic shows the hole, which is the honest failure. */
            ESP_LOGE(TAG, "map: page %d needs %d vertices, NAV_CELL_V_MAX is %d",
                     i, keep, NAV_CELL_V_MAX);
            continue;
        }

        /* The cell's own middle, and the room a name gets there: the nearest edge, which is what
         * decides whether a fourteen-pixel word fits across the cell. Both read off one walk. */
        float area = 0.0f, mxs = 0.0f, mys = 0.0f;

        for (int k = 0; k < keep; k++) {
            const int q = (k + 1 == keep) ? 0 : (k + 1);
            const float x0 = s_nav_cut[k * 2], y0 = s_nav_cut[k * 2 + 1];
            const float x1 = s_nav_cut[q * 2], y1 = s_nav_cut[q * 2 + 1];
            const float cr = x0 * y1 - x1 * y0;

            area += cr;
            mxs += (x0 + x1) * cr;
            mys += (y0 + y1) * cr;
        }

        area *= 0.5f;

        float lx = xi;
        float ly = yi;

        if (fabsf(area) > 1.0f) {
            lx = mxs / (6.0f * area);
            ly = mys / (6.0f * area);
        }

        int clr = 1000;

        for (int k = 0; k < keep; k++) {
            const int q = (k + 1 == keep) ? 0 : (k + 1);
            const float x0 = s_nav_cut[k * 2], y0 = s_nav_cut[k * 2 + 1];
            const float x1 = s_nav_cut[q * 2], y1 = s_nav_cut[q * 2 + 1];
            const float ex = x1 - x0, ey = y1 - y0;
            const float len = sqrtf(ex * ex + ey * ey);

            if (len < 0.01f) {
                continue;
            }

            const float d = (ex * (ly - y0) - ey * (lx - x0)) / len;
            if (d < (float)clr) {
                clr = (int)d;
            }
        }

        for (int k = 0; k < keep; k++) {
            s_nav_cell[i][k * 2] = s_nav_cut[k * 2];
            s_nav_cell[i][k * 2 + 1] = s_nav_cut[k * 2 + 1];
        }

        s_nav_cell_n[i] = (uint8_t)keep;
        s_nav_lx[i] = (int16_t)lroundf(lx);
        s_nav_ly[i] = (int16_t)lroundf(ly);

        if (keep > v_max) {
            v_max = keep;
        }

        const int ar = (int)(area + 0.5f);
        if (area_lo == 0 || ar < area_lo) {
            area_lo = ar;
        }
        if (ar > area_hi) {
            area_hi = ar;
        }
        if (clear_lo == 0 || clr < clear_lo) {
            clear_lo = clr;
        }
    }

    /* Said out loud once: the area of a cell is what a tap aims at and the clearance is what a
     * name lives in, and both are decided by the table above and by nothing else. */
    ESP_LOGI(TAG, "map: %d cells of %d..%d px2 on r %d, %d vertices at most, %d px of label room",
             (int)PAGE_COUNT, area_lo, area_hi, NAV_CELL_R, v_max, clear_lo);
}

/* The box a cell covers, in the image's own coordinates: false when the page has no cell. */
static bool nav_cell_box(int page, lv_area_t *out)
{
    const int n = s_nav_cell_n[page];

    if (n < 3) {
        return false;
    }

    int32_t x1 = 32000, y1 = 32000, x2 = -32000, y2 = -32000;

    for (int k = 0; k < n; k++) {
        const int32_t x = (int32_t)lroundf(s_nav_cell[page][k * 2]);
        const int32_t y = (int32_t)lroundf(s_nav_cell[page][k * 2 + 1]);

        if (x < x1) {
            x1 = x;
        }
        if (x > x2) {
            x2 = x;
        }
        if (y < y1) {
            y1 = y;
        }
        if (y > y2) {
            y2 = y;
        }
    }

    const int32_t c = NAV_SCREEN / 2;
    out->x1 = x1 + c - NAV_BOX_MARGIN;
    out->y1 = y1 + c - NAV_BOX_MARGIN;
    out->x2 = x2 + c + NAV_BOX_MARGIN;
    out->y2 = y2 + c + NAV_BOX_MARGIN;

    return true;
}

/*
 * Which cell a point of the glass belongs to, or -1 for "not the map".
 *
 * The answer is the cell the point falls in, which is exactly what the cells are: the bake cuts
 * them from these numbers and this reads the same numbers back, so a tap cannot land on a tile
 * other than the one it was shown. The distances are taken in tenths, where the table is, so the
 * comparison is exact and needs no division by ten that could round two neighbours into a tie.
 */
static int nav_page_at(const lv_point_t *p)
{
    if (s_nav_cells == NULL) {
        return -1;
    }

    lv_area_t obj;
    lv_obj_get_coords(s_nav_cells, &obj);

    const int32_t dx = p->x - (obj.x1 + obj.x2) / 2;
    const int32_t dy = p->y - (obj.y1 + obj.y2) / 2;
    const int32_t reach = NAV_CELL_R + NAV_TAP_SLACK;

    if (dx * dx + dy * dy > reach * reach) {
        return -1;
    }

    int best = -1;
    int32_t best_d2 = 0;

    for (int i = 0; i < (int)PAGE_COUNT; i++) {
        if (!PAGES[i].tile) {
            continue;
        }

        const int32_t sx = NAV_SITES[i][0] - dx * 10;
        const int32_t sy = NAV_SITES[i][1] - dy * 10;
        /*
         * The same claim the cut used, and in the same units: tenths of a pixel for the distance,
         * px2 for the weight, one weight being a hundred of them.
         *
         * The weight is ADDED, which is the part that has to agree with nav_measure() exactly. The
         * half-plane it clips a cell by, 2p(sj - si) <= |sj|^2 - |si|^2 + (wj - wi), is the one for
         * the smallest dist^2 + w; reading dist^2 - w here answers with the mirror image of the
         * map, because the inner cells are the ones whose weight is negative and they would shrink
         * instead of growing. That is a press on the middle of a tile landing in its outer
         * neighbour, on a fifth of the disc — see tools/voronoi-prototype/tap_check.py, which
         * compares both readings against the cells as drawn.
         */
        const int32_t d2 = sx * sx + sy * sy + NAV_SITES[i][2] * NAV_W_UNIT;

        if (best < 0 || d2 < best_d2) {
            best = i;
            best_d2 = d2;
        }
    }

    return best;
}

/*
 * Fill one convex polygon into the baked image, antialiased, and nothing outside `area`.
 *
 * WHY THIS EXISTS AT ALL: LVGL has no filled polygon unless the vector renderer is compiled in, and
 * it is not — a polygon there is a fan of triangles, each composited on its own, and where two of
 * them share an edge the two antialiased coverages add up to less than one, so the surface behind
 * shows through as a hairline straight across the tile. Every cell is therefore rasterised here,
 * once: four sub-scanlines for the vertical coverage and the exact end of every span for the
 * horizontal one. A cell sixty pixels across gets about five thousand samples, and what the map
 * draws afterwards is one image.
 */
static void nav_fill(const lv_area_t *area, const float *v, int n, uint32_t color, uint8_t opa)
{
    if (n < 3 || s_nav_buf == NULL) {
        return;
    }

    float fx1 = v[0], fx2 = v[0], fy1 = v[1], fy2 = v[1];

    for (int k = 1; k < n; k++) {
        const float x = v[k * 2], y = v[k * 2 + 1];

        if (x < fx1) {
            fx1 = x;
        }
        if (x > fx2) {
            fx2 = x;
        }
        if (y < fy1) {
            fy1 = y;
        }
        if (y > fy2) {
            fy2 = y;
        }
    }

    int x1 = (int)floorf(fx1);
    int x2 = (int)ceilf(fx2) - 1;
    int y1 = (int)floorf(fy1);
    int y2 = (int)ceilf(fy2) - 1;

    if (area != NULL) {
        if (x1 < area->x1) {
            x1 = area->x1;
        }
        if (y1 < area->y1) {
            y1 = area->y1;
        }
        if (x2 > area->x2) {
            x2 = area->x2;
        }
        if (y2 > area->y2) {
            y2 = area->y2;
        }
    }

    if (x1 < 0) {
        x1 = 0;
    }
    if (y1 < 0) {
        y1 = 0;
    }
    if (x2 > NAV_SCREEN - 1) {
        x2 = NAV_SCREEN - 1;
    }
    if (y2 > NAV_SCREEN - 1) {
        y2 = NAV_SCREEN - 1;
    }
    if (x2 < x1 || y2 < y1) {
        return;
    }

    const int w = x2 - x1 + 1;
    const int sr = (int)((color >> 16) & 0xFF);
    const int sg = (int)((color >> 8) & 0xFF);
    const int sb = (int)(color & 0xFF);
    const uint16_t s565 = lv_color_to_u16(lv_color_hex(color));
    const int stride = (int)s_nav_buf->header.stride;

    for (int y = y1; y <= y2; y++) {
        memset(s_nav_row, 0, (size_t)w * sizeof(s_nav_row[0]));

        for (int s = 0; s < NAV_AA_SUB; s++) {
            const float sy = (float)y + ((float)s + 0.5f) / (float)NAV_AA_SUB;
            float xs[NAV_CELL_V_MAX];
            int m = 0;

            for (int k = 0; k < n; k++) {
                const int q = (k + 1 == n) ? 0 : (k + 1);
                const float ay = v[k * 2 + 1];
                const float by = v[q * 2 + 1];

                /* Half open, so a vertex that two edges share is counted by one of them. */
                if ((ay <= sy && by > sy) || (by <= sy && ay > sy)) {
                    const float ax = v[k * 2];
                    const float bx = v[q * 2];
                    xs[m++] = ax + (sy - ay) * (bx - ax) / (by - ay);
                }
            }

            /* Sorted, because a crossing list arrives in the polygon's own order. Ten at most. */
            for (int a = 1; a < m; a++) {
                const float t = xs[a];
                int b = a - 1;

                while (b >= 0 && xs[b] > t) {
                    xs[b + 1] = xs[b];
                    b--;
                }
                xs[b + 1] = t;
            }

            for (int a = 0; a + 1 < m; a += 2) {
                float xa = xs[a];
                float xb = xs[a + 1];

                if (xa < (float)x1) {
                    xa = (float)x1;
                }
                if (xb > (float)(x2 + 1)) {
                    xb = (float)(x2 + 1);
                }
                if (xb <= xa) {
                    continue;
                }

                const int xa_i = (int)floorf(xa);
                const int xb_i = (int)ceilf(xb);

                for (int x = xa_i; x <= xb_i && x <= x2; x++) {
                    if (x < x1) {
                        continue;
                    }

                    const float lo = (xa > (float)x) ? xa : (float)x;
                    const float hi = (xb < (float)(x + 1)) ? xb : (float)(x + 1);

                    if (hi > lo) {
                        s_nav_row[x - x1] += (uint16_t)((hi - lo) * (float)(256 / NAV_AA_SUB));
                    }
                }
            }
        }

        uint16_t *row = (uint16_t *)(s_nav_buf->data + (size_t)y * (size_t)stride);

        for (int x = x1; x <= x2; x++) {
            int a = (int)s_nav_row[x - x1];

            /* Заливка с прозрачностью: покрытие пикселя умножается на неё, поэтому
             * край остаётся сглаженным, а тон ложится на то, что под ним. */
            if (opa != 255 && a > 0) {
                a = (a * (int)opa) / 255;
            }

            if (a <= 0) {
                continue;
            }
            if (a >= 256) {
                row[x] = s565;
                continue;
            }

            const uint16_t d = row[x];
            const int dr = (int)((d >> 11) & 0x1F);
            const int dg = (int)((d >> 5) & 0x3F);
            const int db = (int)(d & 0x1F);
            const int r = ((sr * a) + (((dr << 3) | (dr >> 2)) * (256 - a))) >> 8;
            const int g = ((sg * a) + (((dg << 2) | (dg >> 4)) * (256 - a))) >> 8;
            const int b = ((sb * a) + (((db << 3) | (db >> 2)) * (256 - a))) >> 8;

            row[x] = (uint16_t)(((r >> 3) << 11) | ((g >> 2) << 5) | (b >> 3));
        }
    }
}

/*
 * THE MAP IS EIGHT LAKES, NOT TWENTY-TWO TILES.
 *
 * The owner's reference (obod/m-states-all.png) replaces the mosaic: every tile of a family
 * pours into one flat shape, the families are separated by a gap of bare background, and the
 * state of a tile — you are here, its part is sounding, it is wired into the macro — is a fill
 * of that tile's own piece of the lake and nothing else. No outline is drawn anywhere on the
 * map, and that is the whole of the change.
 *
 * The contours are not built here. obod/nav_lakes.py joins the tiles of a family, blurs the
 * union, takes it at a threshold above one half so the shape both rounds and sits down, and
 * writes the result into nav_lakes.h as half-pixel polygons: eight lakes and twenty-two pieces
 * cut from them. A piece is already clipped by its lake, so a fill can never spill into the gap
 * or reach a neighbour — which is why the fills are polygons here and not marks over a picture.
 *
 * WHAT IS BAKED AND WHAT IS NOT. The lakes never change, so they are painted once into the
 * image at boot, exactly as the mosaic was. A tile's state does change, so a tick that changes
 * one repaints that tile's box: that is a background clear, eight clipped lakes and one fill
 * over a few thousand pixels, which is one cell's worth of work and not the map's.
 */

/* The key order of nav_lakes.h: green, violet, teal, blue, brown, grey, preset, pink. */
static const uint8_t NAV_LAKE_GROUP[NAV_LAKE_COUNT] = {
    GRP_PERC, GRP_LEAD, GRP_GEN, GRP_DRONE, GRP_MIX, GRP_VIEW, GRP_PRESET, GRP_FX,
};

/*
 * Which piece belongs to which page. nav_lakes.h numbers its cells in the order the reference
 * lays them out, which is not the order of PAGES[] — the table is the translation, written out
 * rather than derived, so a page inserted anywhere in PAGES[] is a compile error here (the
 * initialiser is PAGE_COUNT long) and not a silently wrong shape.
 *
 *   PRC LTN ENV SEQ | ARP EUC SCL | LD | DRN FLT LFO | MST LVL RVS CHS DLS | SYS OPT | PRS | CHR DLY REV
 */
static const uint8_t NAV_PAGE_PIECE[PAGE_COUNT] = {
    [PAGE_PERC] = 0,  [PAGE_TONE] = 1,  [PAGE_ENV] = 2,  [PAGE_PERC_SEQ] = 3,
    [PAGE_ARP] = 4,   [PAGE_EUCLID] = 5, [PAGE_SCALE] = 6, [PAGE_LEAD] = 7,
    [PAGE_DRONE] = 8, [PAGE_FILTER] = 9, [PAGE_MOD] = 10,
    [PAGE_MASTER] = 11, [PAGE_MIX] = 12, [PAGE_SEND_REV] = 13,
    [PAGE_SEND_CHR] = 14, [PAGE_SEND_DLY] = 15,
    [PAGE_SYS] = 16, [PAGE_SYS2] = 17, [PAGE_PRESET] = 18,
    [PAGE_CHORUS] = 19, [PAGE_DELAY] = 20, [PAGE_VERB] = 21,
};

/* Самое длинное озеро — 117 точек; 128 с запасом. */
#define NAV_SHAPE_MAX 128

static void nav_shape_pts(const nav_shape_t *sh, float *out)
{
    for (uint16_t k = 0; k < sh->n; k++) {
        out[k * 2] = (float)sh->p[k * 2] * 0.5f;
        out[k * 2 + 1] = (float)sh->p[k * 2 + 1] * 0.5f;
    }
}

/*
 * THE SIX STATES, taken off the owner's sheet of them: a fill of the tile's own piece, a cover of
 * that fill, and the word's colour. The reds are the sheet's; the family steps are our own
 * ladder (600 for "here", 400 for the flash, because 400 is the brighter of the two and a flash
 * must read brighter than the tile you are standing on).
 *
 * The macro wins over the family: a tile wired into the macro is red whatever family it belongs
 * to, and on red the two momentary states are told apart by which red, not by which family.
 */
typedef struct {
    uint32_t fill;   /* the tile's fill, 0 for none */
    uint8_t opa;     /* its cover over the lake */
    uint32_t ink;    /* the word */
} nav_state_t;

#define NAV_OPA_HERE   107   /* 42 % */
#define NAV_OPA_LIT    133   /* 52 % */
#define NAV_OPA_MACRO  184   /* 72 % */
#define NAV_OPA_MIXED  158   /* 62 % */

/* Фон шторки: чёрный без примеси, чтобы озёра читались как свет на чёрном, а не на
 * зелёной подложке прибора. */
#define COL_NAV_BG      0x000000

#define COL_MACRO_FIELD 0x5C1800
#define COL_MACRO_HERE  0x8A2400
#define COL_MACRO_LIT   0xE63E00
#define COL_MACRO_INK   0xFDE0D9
#define COL_ON_FILL     0xFFFFFF

static nav_state_t nav_state_of(int page)
{
    const nav_map_tone_t *tone = &MAP_TONE[PAGES[page].group];
    const bool lit = s_nav_glow[page];
    const bool here = (page == (int)s_page) || (page == s_nav_press);

    if (page_has_macro(&PAGES[page])) {
        if (lit) {
            return (nav_state_t){ COL_MACRO_LIT, NAV_OPA_MIXED, COL_ON_FILL };
        }
        if (here) {
            return (nav_state_t){ COL_MACRO_HERE, NAV_OPA_MIXED, COL_ON_FILL };
        }
        return (nav_state_t){ COL_MACRO_FIELD, NAV_OPA_MACRO, COL_MACRO_INK };
    }

    if (lit) {
        return (nav_state_t){ tone->tag, NAV_OPA_LIT, COL_ON_FILL };
    }
    if (here) {
        return (nav_state_t){ tone->here, NAV_OPA_HERE, COL_ON_FILL };
    }
    return (nav_state_t){ 0, 0, GROUP_COLOR[PAGES[page].group].ink };
}

/* Background, the eight lakes, then the fills of the tiles that are not at rest — the whole of
 * the map inside `rect`. */
static void nav_paint_rect(const lv_area_t *rect)
{
    if (s_nav_buf == NULL) {
        return;
    }

    const uint16_t bg = lv_color_to_u16(lv_color_hex(COL_NAV_BG));
    const int stride = (int)s_nav_buf->header.stride;

    int x1 = rect->x1 < 0 ? 0 : (int)rect->x1;
    int y1 = rect->y1 < 0 ? 0 : (int)rect->y1;
    int x2 = rect->x2 >= NAV_SCREEN ? NAV_SCREEN - 1 : (int)rect->x2;
    int y2 = rect->y2 >= NAV_SCREEN ? NAV_SCREEN - 1 : (int)rect->y2;

    if (x2 < x1 || y2 < y1) {
        return;
    }

    for (int y = y1; y <= y2; y++) {
        uint16_t *row = (uint16_t *)(s_nav_buf->data + (size_t)y * (size_t)stride);
        for (int x = x1; x <= x2; x++) {
            row[x] = bg;
        }
    }

    float pts[NAV_SHAPE_MAX * 2];

    for (int i = 0; i < NAV_LAKE_COUNT; i++) {
        const nav_shape_t *sh = &nav_lake[i];

        if (sh->n < 3 || sh->n > NAV_SHAPE_MAX) {
            continue;
        }

        nav_shape_pts(sh, pts);
        /* Двенадцать процентов цвета семьи поверх фона, как в эталоне: тон озера — это
         * отмывка, а не ступень лестницы, и держит его nav_fill() своей прозрачностью. */
        nav_fill(rect, pts, sh->n, MAP_TONE[NAV_LAKE_GROUP[sh->id]].tag, 30);
    }

    for (int i = 0; i < (int)PAGE_COUNT; i++) {
        const nav_state_t st = nav_state_of(i);

        if (st.opa == 0) {
            continue;
        }

        const nav_shape_t *sh = &nav_cell[NAV_PAGE_PIECE[i]];

        if (sh->n < 3 || sh->n > NAV_SHAPE_MAX) {
            continue;
        }

        nav_shape_pts(sh, pts);
        nav_fill(rect, pts, sh->n, st.fill, st.opa);
    }
}

/* The whole map, painted again: at boot, and whenever the macro changes while the map is up —
 * the macro's red is a fill, so it is not something a draw callback can add afterwards. */
static void nav_repaint_all(void)
{
    lv_area_t all;

    all.x1 = 0;
    all.y1 = 0;
    all.x2 = NAV_SCREEN - 1;
    all.y2 = NAV_SCREEN - 1;

    nav_paint_rect(&all);

    if (s_nav_marks != NULL) {
        lv_obj_invalidate_area(s_nav_marks, &all);
    }
}

/* At boot: the whole map, once. The lakes are fixed, so this never runs again. */
static void nav_mosaic(void)
{
    nav_repaint_all();
}

/* A cell's box in screen coordinates, for a clip test or for a repaint. */
static bool nav_cell_screen_box(int page, lv_area_t *out)
{
    if (!nav_cell_box(page, out)) {
        return false;
    }

    if (s_nav_marks == NULL) {
        return false;
    }

    lv_area_t obj;
    lv_obj_get_coords(s_nav_marks, &obj);

    out->x1 += obj.x1;
    out->x2 += obj.x1;
    out->y1 += obj.y1;
    out->y2 += obj.y1;

    return true;
}

/* Ask for one cell's moving parts to be painted again: the whole of what a flash costs. */
static void nav_cell_repaint(int page)
{
    lv_area_t box;

    if (s_nav_marks == NULL || !nav_cell_screen_box(page, &box)) {
        return;
    }

    /* Плитка рисуется В буфер, а не поверх него, поэтому сначала её место собирается заново
     * (фон, озёра, заливка состояния), и только потом экран просит показать это место. Два
     * пикселя в обводке — на сглаженный край, который шире самой плитки. */
    lv_area_t grow = box;

    grow.x1 -= 2;
    grow.y1 -= 2;
    grow.x2 += 2;
    grow.y2 += 2;

    nav_paint_rect(&grow);
    lv_obj_invalidate_area(s_nav_marks, &box);
}

/*
 * THE MARK LAYER DRAWS NOTHING ANY MORE.
 *
 * It used to paint the two things that move — the cell you stand on and the macro's ring — over
 * the baked picture, because a picture cannot change. Now both are fills of the tile's own piece,
 * and a fill has to be composited over the lake it belongs to, so they are painted into the
 * buffer instead: see nav_paint_rect() and nav_cell_repaint(). The object itself stays, because
 * the screen area it covers is what gets invalidated when a tile changes.
 */

static void nav_layout(void)
{
    for (int i = 0; i < (int)PAGE_COUNT; i++) {
        if (s_nav_label[i] == NULL) {
            continue;
        }

        /*
         * The name sits at the cell's own middle and nowhere else: the cells are cut from the
         * table once and never move, so there is nothing here to fit, grow or dodge. The face is
         * the same 14 px the chips carried — the cell is bigger, and what a bigger cell bought is
         * the room around the word, not a larger word.
         */
        lv_obj_align(s_nav_label[i], LV_ALIGN_CENTER, s_nav_lx[i], s_nav_ly[i]);
    }

}

/*
 * The names, the family's colour behind the whole curtain, and a flash left over from last time.
 *
 * The mosaic draws the cells themselves, so what is left here is their colour: the curtain takes
 * the current family's tint and the names take their family's name step. The two things that move
 * — the cell you are standing on and the macro's red — are painted by nav_marks_draw_cb(), which
 * reads s_page and page_has_macro() itself rather than a copy of either, so repainting two cells is
 * the whole of "the mark moved".
 *
 * Called when the map opens and when the page behind it changes: never while a value moves.
 */
static void nav_mark_current(void)
{
    if (s_nav == NULL) {
        return;
    }

    /*
     * Nothing in here is on the glass while the map is down, and a page turned on the instrument
     * must not pay for repainting a picture nobody is looking at: apply_page() calls this on every
     * page change, and a full bake is the price of the whole mosaic. nav_open() marks it again
     * before the drawer's own first frame, so the state a closed map carries does not matter.
     */
    if (!s_nav_open) {
        return;
    }

    /* The curtain is a surface like the page behind it, and it follows the same
     * family — opening the map should not leave the colour behind. */
    lv_obj_set_style_bg_color(s_nav, lv_color_hex(COL_NAV_BG), LV_PART_MAIN);

    for (int i = 0; i < (int)PAGE_COUNT; i++) {
        /* A cell is one solid step of its family's colour and nothing else: no rim of its own. The
         * colour IS the cell, which is the only way six hues stay nameable at this size — six
         * outlines of six hues would read as six kinds of border rather than as six colours.
         *
         * The name is the palette's 400 on a cell, and the cell's own sunk colour on the cell you
         * are standing on: that one is filled with 600, where a 400 name measures about one and a
         * half to one and washes out. The sunk colour is both darker on the light fill (about four
         * to one) and the colour every other tile already is, so the name on the current tile looks
         * like a tile's name rather than like a different kind of mark. */
        if (s_nav_label[i] != NULL) {
            text_color(s_nav_label[i], nav_state_of(i).ink);
        }

        /* A flash left over from the last time the map was up is put back here, or a cell caught
         * mid-flash would stay bright for as long as the map is. */
        if (s_nav_glow[i]) {
            s_nav_glow[i] = false;
            nav_cell_repaint(i);
        }
    }

    /*
     * И карта целиком. Раньше здесь перекрашивались только две плитки — та, с которой ушли, и та,
     * на которой стоим, — потому что всё остальное было запечено и не менялось. Теперь в буфере
     * живёт и красное поле макроса, и след нажатия, поэтому при открытии карта собирается
     * заново: пятнадцать миллисекунд на открытие против залипших цветов на закрытой карте.
     */
    nav_repaint_all();
    s_nav_marked = (int)s_page;
}

/*
 * The page dots: where this page sits in its family.
 *
 * The family is the same contiguous run of PAGES[] that the wheel walks and the swipe
 * crosses, so the row and the navigation always agree about where you are. The row is
 * centred at a fixed PITCH, so the mark moving from one page to the next never reflows
 * the dots you are already reading. A family of one page gets no dots at all: one dot
 * would say "there is only this", which the title already says.
 *
 * They are drawn on the sector pages only. A list and a readout are single pages in a
 * family of four and the middle of their disc is where their own content lives, so the
 * question "which of the four am I on" is answered there by the page itself.
 */
static void refresh_page_dots(void)
{
    const nav_group_color_t *g = &GROUP_COLOR[PAGES[s_page].group];
    const uint8_t grp = PAGES[s_page].group;

    int first = 0;
    int count = 0;
    nav_group_span(s_page, &first, &count);

    /* The turning picture owns the middle of the disc, and the row sits at -30 —
     * inside its top rows. Hidden for the two seconds rather than drawn through:
     * a dot on a curve is not a picture. */
    const bool show = (PAGES[s_page].view == VIEW_KNOBS) && (count >= 2) && !s_preview_on;
    const int here = nav_group_rank(s_page);
    int ord = 0;

    for (int i = 0; i < (int)PAGE_COUNT; i++) {
        if (s_page_dot[i] == NULL) {
            continue;
        }
        /* The row is the family's pages in order, so a dot is the nth of them. */
        if (!show || PAGES[i].group != grp || ord >= count) {
            lv_obj_set_hidden(s_page_dot[i], true);
            continue;
        }
        ord++;

        const bool cur = ((ord - 1) == here);
        const int dd = cur ? PAGE_DOT_CUR : PAGE_DOT_D;

        lv_obj_set_hidden(s_page_dot[i], false);
        lv_obj_set_size(s_page_dot[i], dd, dd);
        lv_obj_set_style_bg_color(s_page_dot[i],
                                  lv_color_hex(cur ? g->tile : tint(g->tile, PAGE_DOT_TINT)),
                                  LV_PART_MAIN);
        /* The row is centred on the family's VISIBLE pages, so the position is the
         * ORDINAL and not the page index: an index pushes every family that does not
         * start at page zero off to the right, which is how the ARP page's row ended up
         * out in its LEN sector and the settings' row off the screen entirely. */
        lv_obj_align(s_page_dot[i], LV_ALIGN_CENTER,
                     ((ord - 1) * PAGE_DOT_PITCH) - (count - 1) * PAGE_DOT_PITCH / 2,
                     PAGE_DOT_Y);
    }
}

static void nav_closed_cb(lv_anim_t *a)
{
    (void)a;
    /* A reopen during the closing animation would otherwise be hidden by it. */
    if (!s_nav_open) {
        lv_obj_set_hidden(s_nav, true);
    }
}

/*
 * The slide, as one function for both layers, and on the same buffers the page turn uses.
 *
 * A drawer is a full-screen object — the map is 360x360 over twenty tiles, and the
 * transport is the same size again — so a frame that moves one re-renders the whole screen.
 * Measured with the object moving directly, a drawer frame was 31 ms at the median and 100
 * at the worst; the page turn, which moves a picture with a picture behind it, is 10 and
 * 57. The same structure is therefore used here: both sides are taken into buffers, the
 * page behind goes down as a still picture, and the drawer's picture is what travels.
 *
 * An earlier attempt at this was called worse than moving the object directly, and that
 * verdict is not usable: the two builds were made and flashed by two jobs running at once
 * against the same build directory and the same serial port, so what was tested was not
 * reliably what had been written.
 *
 * The map's own behaviour, unchanged: a slide already running on the object is deleted
 * first, so a gesture that arrives in the middle of one does not fight it — it replaces
 * it, and the animation that was interrupted never runs its completed callback. That is
 * also why the callback tests the open flag rather than trusting that it is the last one
 * to run: a reopen during a close must not be hidden by the close finishing.
 */
static lv_obj_t               *s_drawer_src;
static int32_t                 s_drawer_to;
static lv_anim_completed_cb_t  s_drawer_done;
static lv_obj_t               *s_drawer_img;
static lv_draw_buf_t          *s_drawer_snap;
static lv_obj_t               *s_drawer_page_img;
static lv_draw_buf_t          *s_drawer_page_snap;

static void drawer_exec(void *var, int32_t y)
{
    (void)var;
    if (s_drawer_img != NULL) {
        lv_obj_set_y(s_drawer_img, y);
    }
}

static void drawer_drop(void)
{
    if (s_drawer_img != NULL) {
        lv_obj_delete(s_drawer_img);
        s_drawer_img = NULL;
    }
    if (s_drawer_snap != NULL) {
        lv_draw_buf_destroy(s_drawer_snap);
        s_drawer_snap = NULL;
    }
    if (s_drawer_page_img != NULL) {
        lv_obj_delete(s_drawer_page_img);
        s_drawer_page_img = NULL;
    }
    if (s_drawer_page_snap != NULL) {
        lv_draw_buf_destroy(s_drawer_page_snap);
        s_drawer_page_snap = NULL;
    }
    if (s_content != NULL) {
        lv_obj_clear_flag(s_content, LV_OBJ_FLAG_HIDDEN);
    }
}

static void drawer_done_cb(lv_anim_t *a)
{
    drawer_drop();

    /* The real drawer, put down where its picture left it. */
    if (s_drawer_src != NULL) {
        lv_obj_set_y(s_drawer_src, s_drawer_to);
        lv_obj_clear_flag(s_drawer_src, LV_OBJ_FLAG_HIDDEN);
        s_drawer_src = NULL;
    }

    /* Last, because a callback that HIDES the drawer (the closing case) has to hide the
     * real one and not a picture that no longer exists. */
    if (s_drawer_done != NULL) {
        lv_anim_completed_cb_t d = s_drawer_done;
        s_drawer_done = NULL;
        d(a);
    }
}

static void drawer_setup(lv_obj_t *obj, int32_t from, int32_t to, lv_anim_completed_cb_t done)
{
    lv_anim_delete(obj, (lv_anim_exec_xcb_t)lv_obj_set_y);

    /* An interrupted slide takes its pictures and their pixels with it. */
    if (s_drawer_img != NULL) {
        lv_anim_delete(s_drawer_img, (lv_anim_exec_xcb_t)drawer_exec);
    }
    drawer_drop();
    if (s_drawer_src != NULL) {
        lv_obj_set_y(s_drawer_src, s_drawer_to);
        lv_obj_clear_flag(s_drawer_src, LV_OBJ_FLAG_HIDDEN);
        s_drawer_src = NULL;
    }

    s_drawer_src  = obj;
    s_drawer_to   = to;
    s_drawer_done = done;

    /*
     * Both pictures are taken with the drawer at (0,0), the one position it occupies fully
     * on screen whichever way it is going, because a snapshot renders the object where it
     * stands and half of these slides start with it off the screen entirely. The picture is
     * then placed at `from` and travels the distance the drawer was asked to travel.
     */
    lv_obj_clear_flag(obj, LV_OBJ_FLAG_HIDDEN);
    lv_obj_set_y(obj, 0);

    if (s_content != NULL) {
        s_drawer_page_snap = lv_snapshot_take(s_content, LV_COLOR_FORMAT_RGB565);
    }

    s_drawer_snap = lv_snapshot_take(obj, LV_COLOR_FORMAT_RGB565);

    lv_obj_set_y(obj, from);

    if (s_drawer_snap != NULL) {
        if (s_drawer_page_snap != NULL) {
            s_drawer_page_img = lv_image_create(lv_obj_get_parent(obj));
            lv_image_set_src(s_drawer_page_img, s_drawer_page_snap);
            lv_obj_set_pos(s_drawer_page_img, 0, 0);
            lv_obj_clear_flag(s_drawer_page_img, LV_OBJ_FLAG_SCROLLABLE);

            /* The live page out of the way. A covered object that is not hidden is still
             * walked by the refresh and still rendered wherever the drawer is not, which is
             * a full page render on every frame of the slide. */
            lv_obj_add_flag(s_content, LV_OBJ_FLAG_HIDDEN);
        }

        s_drawer_img = lv_image_create(lv_obj_get_parent(obj));
        lv_image_set_src(s_drawer_img, s_drawer_snap);
        lv_obj_set_pos(s_drawer_img, 0, from);
        lv_obj_clear_flag(s_drawer_img, LV_OBJ_FLAG_SCROLLABLE);

        /* Hidden: the picture is the drawer for the length of the slide. */
        lv_obj_add_flag(obj, LV_OBJ_FLAG_HIDDEN);
    }
}

/* The picture where the hand has put it, 0 being fully open and its edge fully closed. */
static void drawer_place(int32_t y)
{
    if (s_drawer_img != NULL) {
        lv_obj_set_y(s_drawer_img, y);
    } else if (s_drawer_src != NULL) {
        lv_obj_set_y(s_drawer_src, y);
    }
}

/* Where the drawer will be put down when the travel ends. A drag that is undone travels to
 * its own edge instead of the one drawer_setup() was told about, and drawer_done_cb() puts the
 * real object down at the value kept here — so this has to move with it. */
static void drawer_retarget(int32_t to)
{
    s_drawer_to = to;
}

static bool drawer_in_flight(void)
{
    return s_drawer_src != NULL || s_drawer_img != NULL;
}

/*
 * The travel, once the pictures exist. Split from drawer_setup() for the same reason the page
 * turn is split: the hand needs the pictures before it knows where they should end up, and it
 * has to be able to drive them itself (see the turn under the finger).
 */
static void drawer_run(int32_t from, int32_t to, lv_anim_path_cb_t path)
{
    lv_anim_t a;
    lv_anim_init(&a);
    lv_anim_set_values(&a, from, to);
    lv_anim_set_duration(&a, NAV_SLIDE_MS);
    lv_anim_set_path_cb(&a, path);
    lv_anim_set_completed_cb(&a, drawer_done_cb);

    if (s_drawer_img != NULL) {
        lv_anim_set_var(&a, s_drawer_img);
        lv_anim_set_exec_cb(&a, (lv_anim_exec_xcb_t)drawer_exec);
    } else if (s_drawer_src != NULL) {
        lv_anim_set_var(&a, s_drawer_src);
        lv_anim_set_exec_cb(&a, (lv_anim_exec_xcb_t)lv_obj_set_y);
    } else {
        return;
    }

    lv_anim_start(&a);
}

/*
 * Give the proxy back to the page behind, after the curtain has had it.
 *
 * The wheel travels in the proxy whatever it is turning, so the curtain sets the proxy's range to
 * the tempo's steps while it is up — see transport_open(). This is the other half: the page gets
 * its own job back, and which job that is depends on the page. The preset list is asked for its
 * own refresh rather than worked out here, because the list and the proxy have to agree about the
 * selection, and only that function knows both.
 */
static void proxy_restore_for_page(void)
{
    if (s_page == PAGE_PRESET) {
        preset_refresh();
        return;
    }

    const ui_page_t *p = page();
    if (p->knob_count > 0) {
        proxy_load(p->knobs[sel_index()].param);
    }
}

static void transport_closed_cb(lv_anim_t *a)
{
    (void)a;
    /* The map's rule, for the map's reason: a reopen during the close would otherwise
     * be hidden by the close finishing. */
    if (!s_transport_open) {
        lv_obj_set_hidden(s_transport, true);
        proxy_restore_for_page();
    }
}

/*
 * The button shows the ACTION, not the state: it reads STOP while the instrument
 * is sounding and PLAY while it is silent, which is how a transport control is
 * read everywhere else. The colour carries the state as well, so neither reading
 * has to be guessed from the other.
 *
 * There is deliberately no separate mute: this gates the rack's INPUT, so
 * stopping and starting returns the exact volume that was set, and stopping
 * leaves the effects to ring out. The delay repeats and the reverb tail decay
 * instead of being cut off, which is what an instrument does when a player takes
 * their hands off it. The sequencer keeps running underneath, silently, so the
 * instrument comes back into the phrase rather than restarting it. The DISPLAY does not
 * follow it down there: the grid cursor is not drawn at all while the box is stopped,
 * because a playhead is a claim about what is being heard — see refresh_sequencer().
 */
static void transport_refresh_run(void)
{
    if (s_transport_btn == NULL) {
        return;
    }

    const bool on = synth_app_is_running() != 0;

    lv_obj_set_hidden(s_transport_stop, !on);
    lv_obj_set_hidden(s_transport_play, on);
    lv_obj_set_style_border_color(s_transport_btn,
                                  lv_color_hex(on ? COL_STOP_RIM : COL_RUN_RIM),
                                  LV_PART_MAIN);
    lv_obj_set_style_bg_color(s_transport_btn,
                              lv_color_hex(on ? COL_STOP_BG : COL_RUN_BG),
                              LV_PART_MAIN);
    /* Both marks wear the 400 step of their state — the same step the button's rim already wears,
     * so the face and the mark cannot disagree — rather than the pale 100 the words used. */
    lv_obj_set_style_bg_color(s_transport_stop, lv_color_hex(COL_STOP_RIM), LV_PART_MAIN);
    lv_obj_set_style_line_color(s_transport_play, lv_color_hex(COL_RUN_RIM), LV_PART_MAIN);
}

/*
 * The battery, the only readout the transport screen carries.
 *
 * It sits UNDER the button rather than inside it: the button is the one thing on this
 * screen that is pressed, and a number a thumb can land on is a number in the way.
 *
 * The label is rewritten only when the number changes. That is not tidiness — the timer
 * runs twice a second, the BSP caches a reading for five of them, and a label set to the
 * text it already has is a redraw of the whole curtain.
 *
 * An unreadable pin and a flat cell are shown differently on purpose: "BAT --" means the
 * pin has nothing on it, "BAT 0%" means a cell that is empty.
 *
 * "USB" after the number means the cell node looks like the charger is holding it up. That
 * is inference rather than measurement — the board has no charge-status line — so it is
 * spelled as a word beside the reading, not as a symbol that would claim more than is known.
 * See bsp_battery_on_usb() for exactly how far it can be trusted.
 */
static void refresh_battery(void)
{
    if (s_battery_label == NULL || !bsp_battery_is_available()) {
        return;
    }

    const int  pct    = bsp_battery_percent();
    const bool on_usb = bsp_battery_on_usb();
    if (pct == s_battery_shown && on_usb == s_battery_usb_shown) {
        return;
    }
    s_battery_shown     = pct;
    s_battery_usb_shown = on_usb;

    /* Sized for the longest form now, "100%". */
    char buf[16];
    if (pct < 0) {
        snprintf(buf, sizeof(buf), "--");
        text_color(s_battery_label, COL_MUTED);
    } else {
        /* Clamped rather than trusted: the buffer is sized for a percentage, and a
         * caller that ever handed over something larger would otherwise be a truncated
         * string in the one place the build refuses to guess. */
        const int shown = (pct > 100) ? 100 : pct;
        snprintf(buf, sizeof(buf), "%d%%", shown);
        text_color(s_battery_label, on_usb ? COL_BAT_CHG : COL_BAT_LOW);
    }
    lv_label_set_text(s_battery_label, buf);
}

/*
 * The tempo, the second readout the transport screen carries and the only one that can be
 * changed from here.
 *
 * It is ABOVE the button, symmetric with the battery below it, and for the same reason: the
 * button is what a thumb lands on, so nothing a thumb could land on sits inside it.
 *
 * The number comes from the app, not from arithmetic done here: the tempo's mapping is
 * exponential and lives there, so asking the app for the line is the only way the readout on
 * this screen and the readout on the knob can never disagree. It asks
 * synth_app_tempo_text() rather than param_text(), which is the same line built from the
 * tempo that is actually running: a MIDI clock can be driving the instrument from a tempo
 * the wheel is not pointing at, and this screen is a readout of what is playing, not of the
 * patch. Nothing is written anywhere by that call — the wheel below still writes the
 * parameter, and the parameter is still what a preset keeps.
 *
 * The label is rewritten only when the text changes, exactly as the battery's is: the timer
 * runs twice a second, and a label set to what it already says is a redraw of the curtain.
 */
static void refresh_tempo(void)
{
    if (s_tempo_label == NULL) {
        return;
    }

    /* One read, and both halves of the readout are drawn from it: the ring and the number
     * cannot show two different tempos. While a clock is live this is the wire's tempo, and
     * the moment the clock times out the same call answers with the wheel's parameter again
     * — so the return to the knob is the snapshot's business and not a second rule here. */
    const float tempo = synth_app_tempo_now(NULL);
    const int32_t value = tempo_value_of(tempo);

    /* Moved BEFORE the text's early return below: the readout is one and the same string for
     * a whole BPM step, while the ring has to follow every detent. */
    if (s_tempo_buf != NULL) {
        /* A closed curtain keeps the picture it had; opening repaints it whole. Repainting
         * while it is down would be work nobody sees, and the wheel still has a page of its
         * own to turn. */
        if (s_transport_open) {
            tempo_ring_set_value(value);
        }
    } else if (s_tempo_arc != NULL) {
        lv_arc_set_value(s_tempo_arc, value);
    }

    char buf[16];
    synth_app_tempo_text(buf, sizeof(buf));
    if (strcmp(buf, s_tempo_shown) == 0) {
        return;
    }
    snprintf(s_tempo_shown, sizeof(s_tempo_shown), "%s", buf);
    lv_label_set_text(s_tempo_label, buf);
}

/*
 * Пресеты со шторки.
 *
 * Шторка уходит, страница встаёт на место — тем же путём, каким её открывала
 * плитка в шторке карты. Свайп, только что закончившийся на этой кнопке, — не
 * нажатие, и это единственная защита, которая здесь нужна.
 */
static void transport_preset_cb(lv_event_t *e)
{
    (void)e;

    if (swipe_just_happened()) {
        return;
    }

    goto_page(PAGE_PRESET);
    transport_close();
}

static void transport_run_cb(lv_event_t *e)
{
    (void)e;

    /* A finger that was swiping is not pressing this. The pan is gone, so this is
     * the whole guard that is left: nothing else can swallow a tap. */
    if (swipe_just_happened()) {
        return;
    }

    synth_app_set_running(synth_app_is_running() ? 0 : 1);
    transport_refresh_run();
}

/*
 * The map's two halves, each split into "put the state and the pictures down" and "travel".
 *
 * The hand that opens or closes a drawer needs the first half without the second: it has its
 * own idea of where the drawer is, and it only hands over to the animation on release (see
 * the turn under the finger). Nothing else about opening or closing changes.
 */
static void nav_begin(bool opening)
{
    diag_record(DIAG_EVT_DRAWER, 1, opening ? 1 : 0);

    if (opening) {
        s_nav_open = true;
        s_nav_press = -1;

        nav_layout();
        nav_mark_current();

        lv_obj_set_hidden(s_nav, false);
        lv_obj_set_y(s_nav, -360);
        drawer_setup(s_nav, -360, 0, NULL);

        /* The knob walks the map's own group for as long as the map is up. */
        proxy_load_nav();
    } else {
        s_nav_open = false;
        s_nav_press = -1;

        drawer_setup(s_nav, 0, -360, nav_closed_cb);
        proxy_restore();
    }
}

static void nav_open(void)
{
    if (s_nav_open || s_nav == NULL) {
        return;
    }
    nav_begin(true);
    drawer_run(-360, 0, lv_anim_path_ease_out);
}

static void nav_close(void)
{
    if (!s_nav_open || s_nav == NULL) {
        return;
    }
    nav_begin(false);
    drawer_run(0, -360, lv_anim_path_ease_in);
}

/*
 * The transport screen: opened by a swipe up, closed by a swipe down.
 *
 * It is a layer in the map's own sense — a full-screen object that is shown and
 * hidden, created after the map so that nothing on the map can reach over it. There
 * is no slide here, and that is deliberate: the map is a drawer that comes in over
 * the instrument, while the transport replaces the instrument rather than covering
 * it, so an instant swap is one less thing that can be caught half-way.
 *
 * The background takes the family's own tint at open time, the same expression
 * apply_page() gives the centre disc, so the swap does not flash a different colour.
 */
static void transport_begin(bool opening)
{
    diag_record(DIAG_EVT_DRAWER, 2, opening ? 1 : 0);

    if (!opening) {
        /*
         * The flag drops with the slide, exactly as the map's does. The layer is still up
         * and clickable while it leaves, so a finger is blocked for the whole of it; the
         * wheel is not, and that is the map's behaviour too.
         */
        s_transport_open = false;
        drawer_setup(s_transport, 0, 360, transport_closed_cb);
        return;
    }

    /*
     * Modal from the first frame of the slide, not from its end: the layer is already
     * unhidden and clickable, and the guards in proxy_changed_cb() and rim_long_cb()
     * read this flag, so nothing reaches the page for the whole of the animation.
     */
    s_transport_open = true;

    lv_obj_set_style_bg_color(s_transport,
                              lv_color_hex(tint(GROUP_COLOR[PAGES[s_page].group].fill,
                                                TINT_BG)),
                              LV_PART_MAIN);
    /*
     * Hand the wheel to the tempo for as long as this screen is up.
     *
     * The curtain is modal and the page behind cannot see the wheel while it is, but the proxy is
     * still the vehicle the wheel travels in — and its RANGE belongs to whatever the page behind
     * is doing with it. The preset list gives it the number of stored sounds, so on that section
     * the tempo could be turned only as far as the list is full and then stopped dead: the limit
     * was the range, not the tempo. The range and the value are therefore set here in the tempo's
     * own steps, the way the navigator and the preset list set them for their own jobs, and handed
     * back when the curtain closes.
     */
    s_syncing = true;
    s_proxy_positions = 0;
    lv_arc_set_range(s_proxy, 0, TRANSPORT_TEMPO_STEPS);
    const int32_t at = (int32_t)(synth_app_get_param(SYNTH_PARAM_SEQ_TEMPO)
                                 * (float)TRANSPORT_TEMPO_STEPS + 0.5f);
    lv_arc_set_value(s_proxy, at);
    s_arc_last = at;
    s_syncing = false;

    /*
     * The picture is repainted whole on the way in. It is the only time the curtain's own
     * tint is known to be current, and it is the point at which a value changed while the
     * curtain was down has to become visible.
     */
    if (s_tempo_buf != NULL) {
        tempo_ring_paint_all();
    }

    transport_refresh_run();
    refresh_battery();
    refresh_tempo();
    lv_obj_set_hidden(s_transport, false);
    /* In from below, the way the map comes in from above — the gesture that opened it
     * went up, so the screen follows the finger. Same duration and same curve as the
     * map's, because it is the same function. */
    lv_obj_set_y(s_transport, 360);
    drawer_setup(s_transport, 360, 0, NULL);
}

static void transport_open(void)
{
    if (s_transport_open || s_transport == NULL) {
        return;
    }
    transport_begin(true);
    drawer_run(360, 0, lv_anim_path_ease_out);
}

static void transport_close(void)
{
    if (!s_transport_open || s_transport == NULL) {
        return;
    }
    transport_begin(false);
    drawer_run(0, 360, lv_anim_path_ease_in);
}

/* -------------------------------------------------------------------------- */
/* The drawer under the finger                                                */
/* -------------------------------------------------------------------------- */
/*
 * The map and the transport, moved by the hand rather than by a gesture.
 *
 * Everything here is the same rule the page turn follows on release — a quarter of the
 * distance is a decision, and so is a flick — with one difference that makes the drawers much
 * cheaper: they are live objects with their contents already built, so nothing has to be
 * photographed and there is no first frame to wait for. The picture the animation uses is
 * made by drawer_setup() and driven by drawer_place() from here instead of by a clock.
 *
 * The state of the instrument follows the drag, not the release: an opening drawer is open from
 * the first frame of its travel, so the guards that keep fingers off the page underneath hold
 * for the whole drag. A drag that is given up puts that state back before anything is seen.
 */

/* The hand has gone far enough up or down: build the drawer and take the picture over. */
static void sheet_begin(int nav, bool opening, lv_coord_t dy)
{
    if ((nav != 0 && s_nav == NULL) || (nav == 0 && s_transport == NULL)) {
        return;
    }

    s_sheet_on = true;
    s_sheet_watch = false;
    s_sheet_carry = false;
    s_sheet_nav = nav != 0;
    s_sheet_opening = opening;
    s_sheet_ate_gesture = true;
    /* One movement under the finger per finger: a drawer and a page cannot both be carried. */
    s_drag_watch = false;
    /* The drawer needs its own picture, and the page's would only be held alongside it. */
    press_snap_drop();
    /* A drawer carried by the hand is still a swipe: the click that ends it must not fire. */
    swipe_was_taken();

    if (nav) {
        s_sheet_from = opening ? -360 : 0;
        nav_begin(opening);
    } else {
        s_sheet_from = opening ? 360 : 0;
        transport_begin(opening);
    }

    /*
     * The build above took two renders, and the hand kept going while it did. Read the finger
     * where it is NOW and count what it did meanwhile as travel.
     *
     * The speed already in hand was measured BEFORE the build and wins unless the reread is
     * faster. A release that arrives inside the build leaves the point where it was before the
     * stall, so the reread spans the whole stall and reads as a drift; the pre-build speed is
     * the hand's real one and is what a flick is decided on.
     */
    lv_point_t p;
    if (drag_point(&p)) {
        const int64_t now = esp_timer_get_time();
        const int64_t dt = now - s_sheet_us_last;
        if (dt > 0) {
            const float inst = (float)(p.y - s_sheet_last_y) * 1000.0f / (float)dt;
            if (fabsf(inst) > fabsf(s_sheet_vy)) {
                s_sheet_vy = inst;
            }
        }
        s_sheet_last_y = p.y;
        s_sheet_us_last = now;
        dy = p.y - s_sheet_y0;
    }

    sheet_place(dy);
}

/* The drawer where the hand has carried it, clamped to its own travel. */
static void sheet_place(lv_coord_t dy)
{
    lv_coord_t y = s_sheet_from + dy;
    if (y < -360) {
        y = -360;
    } else if (y > 360) {
        y = 360;
    }
    drawer_place(y);
}

/*
 * The release, and the same remembered carry the page turn has: when LVGL calls the hand's
 * movement a swipe, the drawer goes where the swipe pointed, whatever this poll managed to
 * measure while the drawer was being built. See drag_release() for why the two can disagree.
 */
static void sheet_release(bool carry)
{
    const lv_coord_t dy = s_sheet_last_y - s_sheet_y0;
    const lv_coord_t travel = (dy < 0) ? -dy : dy;
    const lv_coord_t to = s_sheet_opening ? 0 : (s_sheet_nav ? -360 : 360);
    const float toward = (float)(to - s_sheet_from);
    const bool forward = (s_sheet_vy * toward) > 0.0f;
    const bool commit = carry
                        || ((int32_t)travel * 1000 / 360 >= SHEET_COMMIT_MILLI)
                        || (forward && fabsf(s_sheet_vy) >= DRAG_FLICK_PX_MS);
    s_sheet_carry = false;

    lv_coord_t y = s_sheet_from + dy;
    if (y < -360) {
        y = -360;
    } else if (y > 360) {
        y = 360;
    }

    s_sheet_on = false;
    s_sheet_watch = false;

    const lv_coord_t dest = commit ? to : s_sheet_from;

    /*
     * Put the instrument in the state the release decided, before the travel finishes. The two
     * closing callbacks do the rest when it lands, and they are the ones the gestures use, so a
     * drawer arrived at by hand ends exactly where a swiped one ends.
     */
    const bool stays_open = commit ? s_sheet_opening : !s_sheet_opening;

    if (s_sheet_nav) {
        s_nav_open = stays_open;
        if (stays_open) {
            proxy_load_nav();
        } else {
            proxy_restore();
        }
    } else {
        s_transport_open = stays_open;
    }

    drawer_retarget(dest);

    if (!stays_open) {
        s_drawer_done = s_sheet_nav ? nav_closed_cb : transport_closed_cb;
    } else {
        s_drawer_done = NULL;
    }

    drawer_run(y, dest, commit ? lv_anim_path_ease_out : lv_anim_path_ease_in);
}

#if CONFIG_OBOD_SCREENSHOTS
/*
 * The two layers, for the screenshot walk only.
 *
 * Nothing is redrawn here on purpose: these are the very calls the swipe handler makes, so a
 * frame taken after one of them is the interface doing its own work and not a picture of it.
 * The hide calls are what puts the instrument back the way the walk found it. See
 * components/synth_ui/src/screenshots.c and «Снимки экранов» in web/README.md.
 */
void synth_ui_drawer_show(void)
{
    nav_open();
}

void synth_ui_drawer_hide(void)
{
    nav_close();
}

void synth_ui_transport_show(void)
{
    transport_open();
}

void synth_ui_transport_hide(void)
{
    transport_close();
}
#endif

/*
 * The cell under the finger, lit while the finger is down.
 *
 * The map answers a tap by the point alone, so which cell that will be is decided before the finger
 * lifts; this shows that decision. It is also the only feedback the map has, since it closes on the
 * tap it answered and there is no moment afterwards in which to show anything.
 */
static void nav_press_cb(lv_event_t *e)
{
    int idx = -1;

    if (lv_event_get_code(e) == LV_EVENT_PRESSED) {
        lv_indev_t *indev = lv_indev_active();

        if (indev != NULL) {
            lv_point_t p;
            lv_indev_get_point(indev, &p);
            idx = nav_page_at(&p);
        }
    }

    if (idx == s_nav_press) {
        return;
    }

    const int was = s_nav_press;
    s_nav_press = idx;

    if (was >= 0) {
        nav_cell_repaint(was);
    }
    if (idx >= 0) {
        nav_cell_repaint(idx);
    }
}

/*
 * A tap on the map.
 *
 * There is no button per section any more, and nothing to re-aim: the mosaic covers the disc with
 * cells that are exactly "nearest to this point", so the tap IS the cell it lands in and the answer
 * cannot disagree with the drawing. Nearest centre used to be a guess that corrected a ring of round
 * tiles; here it is the definition.
 *
 * A tap outside the mosaic lands on the curtain and closes the map, which is the dismissal the map
 * has always had. A tap inside it always opens something — there is no sliver between two cells for
 * a near miss to fall into.
 */
static void nav_bg_cb(lv_event_t *e)
{
    (void)e;

    /* A finger that was swiping is not choosing a section, and the press still ends as a click on
     * whatever it started on. The curtain does not move under the finger at all, so this is the
     * only thing left that can hold a tap back. */
    if (swipe_just_happened()) {
        return;
    }

    lv_indev_t *indev = lv_indev_active();
    if (indev == NULL) {
        return;
    }

    lv_point_t p;
    lv_indev_get_point(indev, &p);

    const int idx = nav_page_at(&p);

    nav_close();

    if (idx >= 0) {
        jump_to(idx);
    }
}

/* -------------------------------------------------------------------------- */
/* Live display                                                               */
/* -------------------------------------------------------------------------- */

/* True once the ring has been blanked for APP_RING_OFF. Without it, a mode that
 * says "never lit" would still cost a strip refresh eight times a second to keep
 * it dark. */
static bool s_ring_off_done;

/*
 * Which LED a step, or a fraction of a range, lands on.
 *
 * Spread rather than divided: with more steps than LEDs — sixteen against
 * thirteen — one LED has to stand for two steps and lights if either of them
 * sounds. That is the honest reading of a ring that cannot show every step
 * separately, and the screen shows the full pattern anyway.
 */
static int ring_led_for(int unit, int units, uint16_t n)
{
    const int per = (int)n;
    if (units < 1) {
        return RING_CLOCK;
    }

    int idx = unit * per / units;
    if (!RING_CW) {
        idx = -idx;
    }

    idx += RING_CLOCK;
    idx %= per;
    if (idx < 0) {
        idx += per;
    }
    return idx;
}

/*
 * The figure of the page you are on, on the ring: the steps that sound, and the
 * playhead over them. Called only from a page that has a figure.
 */
static void ring_pattern(uint16_t n)
{
    synth_app_seq_view_t v;
    page_seq_view(&v);

    bsp_led_set_all(0, 0, 0);

    /* The steps wear the PAGE's family, so the ring says which figure is playing:
     * teal on EUCLID, the time family, and green on PERC SEQ, the drum's. The playhead
     * is the fixed amber it has always been — and since the generators stopped wearing
     * amber, EUCLID's figure and its playhead separate by HUE as well as by brightness,
     * which is the one thing the old arrangement spent to make its point. */
    const uint32_t step_c = tint(GROUP_COLOR[page()->group].bright, TINT_STEP);

    if (v.steps >= 1) {
        for (int i = 0; i < v.steps && i < SEQ_DOT_MAX; i++) {
            if (!page_seq_is_onset(i)) {
                continue;
            }

            /*
             * The drum's ring says which drum, as the screen's dots do: the kick at the
             * family colour, the rest taken down by how far down the kit ranks them. The
             * screen has size to spend and the LED has one pixel, so there the second
             * channel is brightness alone. See SEQ_DOT_SNARE.
             */
            uint32_t c = step_c;
            if (s_page == PAGE_PERC_SEQ) {
                const int m = synth_app_perc_step_mask(i);
                int lit = TINT_STEP;

                if (m & SYNTH_APP_PERC_STEP_FILL) {
                    lit = TINT_STEP + 24;
                } else if (m & SYNTH_APP_PERC_STEP_KICK) {
                    lit = TINT_STEP;
                } else if (m & (SYNTH_APP_PERC_STEP_SNARE | SYNTH_APP_PERC_STEP_TOM)) {
                    lit = TINT_STEP - 20;
                } else if (m & SYNTH_APP_PERC_STEP_HAT) {
                    lit = TINT_STEP - 70;
                } else {
                    lit = TINT_STEP - 110;
                }
                c = tint(GROUP_COLOR[page()->group].bright, lit);
            }

            bsp_led_set((uint16_t)ring_led_for(i, v.steps, n),
                        (uint8_t)(c >> 16), (uint8_t)(c >> 8), (uint8_t)c);
        }

        /* Drawn last, so the note sounding now wins over the step under it. */
        const int cur = ring_led_for(v.position % v.steps, v.steps, n);
        /* Bright only while the step both sounds and can be heard: the same condition the
         * screen's cursor and the map's tiles use, so the three cannot disagree about a part
         * that is turned down or a box that is stopped. See page_part_audible(). */
        const bool hot = (v.sounding != 0) && page_part_audible();
        bsp_led_set((uint16_t)cur,
                    hot ? RING_HOT_R : RING_CUR_R,
                    hot ? RING_HOT_G : RING_CUR_G,
                    hot ? RING_HOT_B : RING_CUR_B);
    }

    bsp_led_refresh();
}

/* The value the knob is on, as a fill from twelve. */
static void ring_value(uint16_t n)
{
    /*
     * What the arc is drawn from. Normally the proxy's own record of where the knob stands.
     * While the transport curtain is up the same wheel drives the TEMPO, and the curtain's
     * branch of proxy_changed_cb() takes the detents straight into the parameter, so the proxy
     * is not the thing that moves there and the tempo's own value is read instead.
     */
    const bool transport = s_transport_open;
    const int32_t max = transport ? TRANSPORT_TEMPO_STEPS : ((s_steps > 0) ? s_steps : 1);
    const int32_t pos = transport
                            ? (int32_t)(synth_app_get_param(SYNTH_PARAM_SEQ_TEMPO) *
                                        (float)TRANSPORT_TEMPO_STEPS + 0.5f)
                            : s_proxy_value;

    int lit = (int)(((int64_t)pos * (int64_t)n + max / 2) / max);
    if (lit > (int)n) {
        lit = (int)n;
    }
    if (lit < 0) {
        lit = 0;
    }

    /*
     * The arc is the page's family colour, in the BRIGHT step — the same step the
     * screen uses for the sector the knob is standing on, so the ring and the screen
     * cannot disagree about which value is being turned. Red while the macro rides
     * it, exactly as the sector on the screen is.
     */
    const nav_group_color_t *g = &GROUP_COLOR[page()->group];
    /* The macro's red belongs to the page's parameter; with the wheel on the tempo the family
     * colour is the whole answer, and it is the family the curtain was tinted with. */
    const bool macro = !transport && s_macro[page()->knobs[sel_index()].param];
    const bool inverted = !transport && s_macro_inv[page()->knobs[sel_index()].param];
    const uint32_t val = macro ? (inverted ? COL_INV_RIM_SEL : COL_MACRO_RIM_SEL)
                               : g->bright;
    const uint8_t cr = (uint8_t)(val >> 16);
    const uint8_t cg = (uint8_t)(val >> 8);
    const uint8_t cb = (uint8_t)val;

    bsp_led_set_all(0, 0, 0);

    if (lit == 0) {
        /* Where the scale starts. Without it, a value at the bottom of its range
         * and a page with nothing to say look the same. */
        const uint32_t anchor = tint(g->bright, TINT_ANCHOR);
        bsp_led_set((uint16_t)ring_led_for(0, 1, n),
                    (uint8_t)(anchor >> 16), (uint8_t)(anchor >> 8), (uint8_t)anchor);
    }

    for (int i = 0; i < lit; i++) {
        bsp_led_set((uint16_t)ring_led_for(i, (int)n, n), cr, cg, cb);
    }

    bsp_led_refresh();
}

/*
 * The stereo field, which is what the ring has always shown.
 *
 * It stays on the pages that have no single value to show — STATUS, which is a
 * readout rather than a control, and PRESET, which is a list — because on those the
 * ring is the ambient display and there is nothing better for it to be. It is also
 * the only place the stereo field is shown at all now that the orbit page is gone,
 * which is part of why that page could go: the same three panned registers, read
 * from across the room instead of from a screen you had to swipe to.
 */
static void ring_orbit(uint16_t n)
{
    bsp_led_set_all(0, 0, 0);

    for (int r = 0; r < ORBIT_ROWS; r++) {
        float pan = synth_layer_pan(r);
        if (pan < -1.0f) {
            pan = -1.0f;
        } else if (pan > 1.0f) {
            pan = 1.0f;
        }

        /* Left of the field is the start of the ring, so the ring reads as the
         * stereo axis rather than as a clock — except that twelve o'clock is the
         * start of that axis, so panning right goes the way the fills go. */
        const int idx = ring_led_for((int)((pan + 1.0f) * 0.5f * (float)(n - 1) + 0.5f),
                                     (int)n - 1, n);
        const uint8_t cr = REG_RING[r][0];
        const uint8_t cg = REG_RING[r][1];
        const uint8_t cb = REG_RING[r][2];

        bsp_led_set((uint16_t)idx, cr, cg, cb);

        /* Dim neighbours, so a register reads as a glow with a position rather
         * than as a single lit pixel that is hard to locate at a glance. */
        const int prev = (idx == 0) ? (int)n - 1 : idx - 1;
        const int next = (idx + 1 == (int)n) ? 0 : idx + 1;
        bsp_led_set((uint16_t)prev, (uint8_t)(cr / 4), (uint8_t)(cg / 4),
                    (uint8_t)(cb / 4));
        bsp_led_set((uint16_t)next, (uint8_t)(cr / 4), (uint8_t)(cg / 4),
                    (uint8_t)(cb / 4));
    }

    bsp_led_refresh();
}

/*
 * The colours of the reactive mode: one per PART rather than one per register, so the
 * ring says which part is making the sound in the same colour the screen uses for that
 * part's family. The three drone registers share the first of them, because they are one
 * part heard three ways; the lead and the percussion have their own.
 *
 * Four hues for four parts, and the microphone is not one of them: it has no family of its
 * own on the screen either, and its light shares the drum's green because it is the one
 * source here that is not a part of the instrument. That is a decision about the colour
 * code rather than about this table, and it is written out where the microphone's own
 * branch is weighed, in ring_reactive().
 */
static const uint8_t REACT_RING[4][3] = {
    {  25, 118, 210 },  /* blue-700   — the drone */
    { 142,  36, 170 },  /* purple-600 — the lead */
    {  56, 142,  60 },  /* green-700  — the percussion, and the microphone with it */
    { 216,  27,  96 },  /* pink-600   — the delay, the rack's family colour */
};

/*
 * One source's contribution to the picture: full weight on its own LED, a third on each
 * neighbour, which is the glow the stereo picture already uses to make a position
 * findable at a glance.
 */
static void react_add(int32_t (*w)[4], uint16_t n, int idx, int weight, int part)
{
    const int side = weight / 3;
    const int prev = (idx == 0) ? (int)n - 1 : idx - 1;
    const int next = (idx + 1 == (int)n) ? 0 : idx + 1;

    w[idx][part]  += weight;
    w[prev][part] += side;
    w[next][part] += side;
}

/*
 * The sound's own picture: what is playing, where it sits, and what the delay is doing
 * with it.
 *
 * Every layer adds weight to the LEDs around its own pan position, so the picture moves
 * with the music rather than with a timer, and it moves the way the stereo drift moves,
 * which is slowly. The weight is that layer's envelope, which is instant on a strike and
 * falls away over a tenth of a second.
 *
 * TWO SOURCES ARE NOT LAYERS AND ARE ADDED BESIDE THE LOOP. The percussion is mixed into
 * the rack rather than captured from a bus, so its envelope comes from the module itself
 * and it lights the middle, where a part with no pan belongs. The delay is the other: its
 * repeats walk the stereo field by design, so they are shown as one pulse travelling around
 * the circle, one LED per repeat, with the wet envelope as its brightness. The runner is
 * the rhythm and the brightness is how much of the echo is still coming back. Its spacing
 * comes from the delay itself rather than from a detector in here — a counter driven by
 * these frames would arrive late at speed, and with feedback there is no gap between
 * repeats to count.
 *
 * ONE HUE PER LED, and this is the part that makes the colours read. Whichever source
 * carries the most weight at an LED gives that LED its colour; the others add brightness
 * at a third and no more. Summing the hues instead looks reasonable on paper and makes
 * white on the ring: blue plus green plus pink is pale, and the moment two parts overlap
 * the picture stops saying WHICH part is playing, which is the whole point of the mode.
 * With one hue in charge, a green flash over a blue drone stays green and the drone stays
 * visible as the blue it lights on either side of it.
 */
static void ring_reactive(uint16_t n)
{
    /* Where the delay's pulse is, in repeats, and when it was last advanced. Static
     * because the mode has to remember its place between frames. */
    static double   phase;
    static uint32_t phase_ms;

    int32_t w[64][4];
    const uint32_t now = lv_tick_get();

    if (n > 64) {
        return;
    }

    for (uint16_t i = 0; i < n; i++) {
        w[i][0] = 0;
        w[i][1] = 0;
        w[i][2] = 0;
        w[i][3] = 0;
    }

    /*
     * Whether a generator can reach the output at all: a stopped transport or a master at zero
     * takes every part off the ring, whatever the mixer says. The delay's pulse below is
     * deliberately not gated this way — STOP leaves its tail ringing, and a tail that is heard
     * is a tail worth showing.
     */
    const bool parts_open = output_open();

    /* The three registers of the drone share one part and one colour, but not one fader: each
     * has its own level and its own send, and what each contributes has to be weighed by its
     * own pair. */
    static const synth_param_t drone_level[3] = {
        SYNTH_PARAM_DRONE_LOW, SYNTH_PARAM_DRONE_MID, SYNTH_PARAM_DRONE_HIGH,
    };
    static const synth_param_t drone_send[3] = {
        SYNTH_PARAM_SEND_LOW, SYNTH_PARAM_SEND_MID, SYNTH_PARAM_SEND_HIGH,
    };

    for (int layer = 0; layer < SYNTH_NUM_LAYERS; layer++) {
        float env = synth_layer_env(layer);

        /* Below this a layer is either silent or decaying into silence, and the ring is
         * dark for it either way. */
        if (env < 0.02f) {
            continue;
        }

        /*
         * What the layer's own envelope cannot say. It is taken from the engine's bus, which is
         * BEFORE the rack's faders and before its gate, so on its own it glows for a part that
         * is turned down and for a box that is stopped. Its level and its send are what scale
         * it; see part_output_gain().
         */
        float level01;
        float send01;
        bool  post_fader;

        if (layer == SYNTH_LAYER_LEAD) {
            level01    = synth_app_get_param(SYNTH_PARAM_LEAD_LEVEL);
            send01     = synth_app_get_param(SYNTH_PARAM_SEND_LEAD);
            post_fader = false;
        } else if (layer == SYNTH_LAYER_AUX) {
            /*
             * The AUX bus carries the microphone and nothing else.
             *
             * This branch used to be read as a placeholder for the drum, on the assumption
             * that the drum was summed into that bus. It never was: the percussion is not an
             * engine layer at all — synth_perc_process() adds it to the rack's dry mix — so
             * the energy on this bus was always zero for it and the part's colour could not
             * light however hard it was hit. That is fixed, and not here: the drum has a
             * source of its own now, added below beside the delay's pulse, and this branch is
             * what it should have been all along — weighed by the microphone's own two
             * controls: the sensitivity, which is what makes the input live at all and is zero
             * on a device that has never been switched to listen, and the send, which is the
             * whole of the microphone's path into the mix. Weighted post-fader, like the
             * drum's, so zero on either control means dark: a microphone nobody has turned on
             * is not a part that is playing.
             *
             * IT SHARES THE DRUM'S GREEN, because the ring has four hues for four parts —
             * drone, lead, percussion, delay — and the microphone has never had one of its
             * own. A fifth would change the colour code the screen and the ring are read by,
             * and that change is not this branch's to make, so what a microphone in a
             * loud room does is brighten the same green a drum hit does. Both sit in the
             * middle: its pan is the AUX capture's own, which is centred and has no depth —
             * the microphone is not placed in the image — and the drum has no pan at all.
             */
            level01    = synth_app_get_param(SYNTH_PARAM_SET_MIC);
            send01     = synth_app_get_param(SYNTH_PARAM_SEND_MIC);
            post_fader = true;
        } else {
            level01    = synth_app_get_param(drone_level[layer]);
            send01     = synth_app_get_param(drone_send[layer]);
            post_fader = false;
        }

        env *= parts_open ? part_output_gain(level01, send01, post_fader) : 0.0f;
        if (env < 0.02f) {
            continue;
        }

        float pan = synth_layer_pan(layer);
        if (pan < -1.0f) {
            pan = -1.0f;
        } else if (pan > 1.0f) {
            pan = 1.0f;
        }

        /* The same mapping the stereo picture uses, so one pan puts a part on the same
         * LED in both modes. */
        const int idx = ring_led_for((int)((pan + 1.0f) * 0.5f * (float)(n - 1) + 0.5f),
                                     (int)n - 1, n);
        const int part = (layer == SYNTH_LAYER_LEAD) ? 1
                       : (layer == SYNTH_LAYER_AUX)  ? 2
                                                     : 0;

        react_add(w, n, idx, (int)(env * 255.0f + 0.5f), part);
    }

    /*
     * The percussion, and this is where its green comes from.
     *
     * It is not a layer of the engine and never was: synth_perc_process() adds it to the
     * rack's dry mix, so there is no bus to read an envelope from and the loop above cannot
     * see it. Its number comes from the module itself instead — synth_perc_env_published(),
     * which the audio task publishes once per block from the voices' own gate — and it is
     * drawn in the percussion's own colour, part 2, the one REACT_RING has always named for
     * the drum.
     *
     * The same two gates as everything else, in the same order: nothing while the transport
     * is stopped or the master is down (parts_open), and then the part's own fader and send
     * through part_output_gain(). POST-fader, which is what the engine does — a hit at zero
     * LEVEL is not struck at all (synth_perc_trigger() returns before it makes a voice), and
     * the send is taken from the limited sum after that fader — so this is the same
     * arithmetic page_part_audible() and the PERC SEQ map already use for the drum.
     *
     * IN THE MIDDLE, because the drum is not placed in the image: each voice's two channels
     * are independent noise streams and there is no pan control, so its average position is
     * the centre. That is the ring_led_for() mapping above evaluated at pan 0, which is also
     * where the microphone's AUX branch lands: the two share the green and both sit in the
     * middle, and the note on that branch says why the microphone has no hue of its own.
     */
    float perc_env = synth_perc_env_published();

    if (perc_env >= 0.02f) {
        perc_env *= parts_open
                  ? part_output_gain(synth_app_get_param(SYNTH_PARAM_PERC_LEVEL),
                                     synth_app_get_param(SYNTH_PARAM_SEND_PERC), true)
                  : 0.0f;

        if (perc_env >= 0.02f) {
            react_add(w, n, ring_led_for((int)(0.5f * (float)(n - 1) + 0.5f), (int)n - 1, n),
                      (int)(perc_env * 255.0f + 0.5f), 2);
        }
    }

    /*
     * The pulse. It advances by real time against the delay's own spacing, not by frames:
     * at a fast tempo a repeat arrives inside one frame interval, and a spark moved once
     * per frame would both miss repeats and drift out of time with them.
     *
     * A gap longer than a frame means the mode was not being drawn — it was off, or the
     * page was somewhere else — and the pulse restarts rather than jumping.
     */
    const uint32_t since = now - phase_ms;
    const uint32_t elapsed = (since > 200) ? 0 : since;
    phase_ms = now;

    const float spacing = synth_delay_time_samples();
    const float wet = synth_delay_env();

    /* The delay's tail outlives STOP — the gate is at the rack's input — but not the master:
     * at zero nothing is heard, the echo included. */
    const bool master_open = synth_app_get_param(SYNTH_PARAM_LEVEL) > 0.0f;

    if (spacing > 1.0f && wet > 0.02f && master_open) {
        phase += (double)elapsed * 0.001 * (double)SYNTH_SAMPLE_RATE / (double)spacing;

        const double turns = (double)(n - 1);
        while (phase >= turns) {
            phase -= turns;
        }

        react_add(w, n, ring_led_for((int)(phase + 0.5), (int)n - 1, n),
                  (int)(wet * 255.0f + 0.5f), 3);
    }

    for (uint16_t i = 0; i < n; i++) {
        int lead = 0;
        uint8_t rgb[3];

        for (int c = 1; c < 4; c++) {
            if (w[i][c] > w[i][lead]) {
                lead = c;
            }
        }

        const int32_t total = w[i][0] + w[i][1] + w[i][2] + w[i][3];
        const int32_t mag = w[i][lead] + (total - w[i][lead]) * 35 / 100;

        for (int c = 0; c < 3; c++) {
            const int32_t v = (int32_t)REACT_RING[lead][c] * mag / 255;
            rgb[c] = (uint8_t)(v > 255 ? 255 : (v < 0 ? 0 : v));
        }
        bsp_led_set(i, rgb[0], rgb[1], rgb[2]);
    }

    bsp_led_refresh();
}

/*
 * The ring, page by page.
 *
 * It used to show one thing, and that is still the right answer on the pages that
 * have no single value on them. But the ring is the only display that can be read
 * from across the room without looking at the screen, and what is worth reading
 * from there changes with the page: on a page that has a figure — EUCLID, and now
 * PERC SEQ, each showing its own — it is that pattern and the beat; on a page with a
 * value on it, it is that value.
 *
 * The whole-ring flash still outranks all of it. It marks an event, and an event
 * that a page's own display could hide would not be a signal.
 */
static void update_ring(void)
{
    if (!bsp_led_is_available()) {
        return;
    }
    const uint16_t n = bsp_led_count();
    if (n < 2) {
        return;
    }

    const app_ring_mode_t mode = (app_ring_mode_t)app_settings_get(APP_SET_RING_MODE);

    /*
     * "Off" means off: no ambient display and no flashes either. A ring that
     * still lit up for events would not be a ring the user can turn off, and
     * turning it off is the whole reason the setting exists.
     */
    if (mode == APP_RING_OFF) {
        if (!s_ring_off_done) {
            bsp_led_clear();
            s_ring_off_done = true;
        }
        return;
    }
    s_ring_off_done = false;

    if (ring_override_active()) {
        bsp_led_set_all(s_ring_r, s_ring_g, s_ring_b);
        bsp_led_refresh();
        return;
    }

    /*
     * The transport curtain owns the wheel while it is up, so it owns the arc too.
     *
     * It sits above the stop colour, which is otherwise the one state visible from anywhere:
     * the curtain IS the transport screen, with the run button on it, so the state is in front
     * of the user and the ring is free to show the value being turned. It also sits above the
     * pages that carry a figure, which would take the arc over by their own right.
     */
    if (s_transport_open) {
        ring_value(n);
        return;
    }

    /* Silence outranks the page. Stop is the one state that has to be visible
     * from anywhere, because the display might be on a page that says nothing
     * about the transport. */
    if (!synth_app_is_running()) {
        bsp_led_set_all(RING_STOP_R, RING_STOP_G, RING_STOP_B);
        bsp_led_refresh();
        return;
    }

    if (mode == APP_RING_REACTIVE) {
        ring_reactive(n);
    } else if (mode == APP_RING_STEREO) {
        ring_orbit(n);
    } else if (page_has_figure()) {
        ring_pattern(n);
    } else if (page()->knob_count > 0) {
        ring_value(n);
    } else {
        ring_orbit(n);
    }
}

/* The last figure the ring was drawn from, so it can tell whether the playhead has
 * actually moved, and the page it belonged to. -1 means "nothing drawn yet", and the
 * page is stored with it because two pages have a figure now: walking from EUCLID to
 * PERC SEQ and back can land on the same steps and the same position, and that is two
 * different pictures, not one that has not changed. */
static synth_app_seq_view_t s_ring_seq = { -1, -1, -1, -1, -1 };
static page_id_t s_ring_seq_page = PAGE_COUNT;

static bool    s_nav_gate[PAGE_COUNT];   /* the gate as last seen, so only its edge is flashed */
static uint8_t s_nav_lit[PAGE_COUNT];    /* frames of flash left */
static int     s_nav_pos[PAGE_COUNT];    /* the step each tile was last drawn at */

#define NAV_RHYTHM_EVERY_N_TICKS 1   /* every frame: a fast figure must not be missed between them */

/*
 * Whether the part behind a page's tile can be heard at all.
 *
 * The three tiles that carry a rhythm are the euclid figure, the arpeggio and the drum's own, and
 * each belongs to its part: both of the lead's figures to the lead, the drum's to the percussion.
 * A part at zero still gates its notes — the engine applies the level after the gate — so without
 * this the map would flash for music nobody hears; and the same is true of a part whose level and
 * send are both shut, and of any of them while the transport is stopped or the master is at zero.
 * The question goes through part_output_gain(), so the map, the screen and the ring answer it the
 * same way. For the drum it comes to the level: its send is taken after its fader.
 */
static bool nav_tile_audible(uint8_t p)
{
    if (!output_open()) {
        return false;
    }
    switch (p) {
    case PAGE_EUCLID:
    case PAGE_ARP:
        return part_output_gain(synth_app_get_param(SYNTH_PARAM_LEAD_LEVEL),
                                synth_app_get_param(SYNTH_PARAM_SEND_LEAD),
                                false) > 0.0f;
    case PAGE_PERC_SEQ:
        return part_output_gain(synth_app_get_param(SYNTH_PARAM_PERC_LEVEL),
                                synth_app_get_param(SYNTH_PARAM_SEND_PERC),
                                true) > 0.0f;
    default:
        return false;
    }
}

/*
 * The flash: a tile's chip goes to the family's bright step while its part sounds and back to the
 * chip colour when it stops. Both are colours the map already uses — the bright step is what a
 * turned sector's rim is drawn in, the chip is what the tile wears — so nothing new is introduced,
 * only said sooner. A part turned down is put back to the chip colour rather than skipped, or a
 * tile caught mid-flash would stay bright for as long as the map is open.
 */
static void nav_rhythm_refresh(void)
{
    if (!s_nav_open) {
        return;
    }

    for (int i = 0; i < (int)PAGE_COUNT; i++) {
        if (s_nav_cell_n[i] < 3) {
            continue;
        }
        if (i != PAGE_EUCLID && i != PAGE_PERC_SEQ && i != PAGE_ARP) {
            continue;
        }

        bool on = false;
        if (nav_tile_audible((uint8_t)i)) {
            if (i == PAGE_PERC_SEQ) {
                synth_app_seq_view_t v;
                synth_app_perc_view(&v);
                /*
                 * The drum's gate is its decay, and a decay longer than the interval between two of
                 * these passes reads as one unbroken state: the edge never comes back, and an edge
                 * is all this flashes. Its steps are what a tile can follow, so the flash is a step
                 * that is an onset — one frame per hit, as short as this rate can say it.
                 */
                on = (v.position != s_nav_pos[i])
                     && synth_app_perc_is_onset(v.position) != 0;
                s_nav_pos[i] = v.position;
            } else {
                /*
                 * Both lead tiles read the lead's own view, and that view carries whichever of the
                 * two figures is running. The arpeggiator replaces the euclid rather than playing
                 * along with it, so the tile that is not in use is held dark: without this the
                 * euclid tile pulses to an arpeggio it is not playing. The view's sounding is the
                 * note gate — "active" says only that the arpeggiator is switched on, which is true
                 * for whole bars together.
                 */
                synth_app_seq_view_t v;
                synth_app_seq_view(&v);
                const bool arp = synth_app_arp_active() != 0;
                on = ((i == PAGE_ARP) ? arp : !arp) && v.sounding != 0;
            }
        }

        /*
         * One refresh interval of light per hit, not the note's own gate.
         *
         * A percussion gate is its decay, and at a fast figure those gates run into one another
         * until the tile looks steadily lit rather than struck. Only the edge is flashed here,
         * which is what makes the light say where the hits are.
         *
         * The counter is set to two because it is decremented in this same pass: two leaves one
         * frame lit, one leaves none.
         */
        if (on && !s_nav_gate[i]) {
            s_nav_lit[i] = 2;
        }
        s_nav_gate[i] = on;
        if (s_nav_lit[i] > 0) {
            s_nav_lit[i]--;
        }
        on = (s_nav_lit[i] > 0);

        /*
         * The flash is the mosaic's, and so is the colour: this says which cells are lit and asks
         * for those cells to be painted again. Every cell the strip of screen being painted does
         * not touch is skipped by the painter, so a frame here costs three cells and not the map.
         *
         * The lit step is the family's rim — one Material step above the chip in every family. The
         * named fill step cannot be used, because in the percussion green it IS the chip colour,
         * which is how that tile came to look dead while the page beside it pulsed.
         */
        if (s_nav_glow[i] != on) {
            s_nav_glow[i] = on;
            nav_cell_repaint(i);
        }
    }
}

static void preset_blink(void);

static void anim_timer_cb(lv_timer_t *timer)
{
    (void)timer;

    s_tick++;

    /*
     * While the page is crossing the screen there is nothing on it worth updating. A turn
     * is the heaviest thing this instrument draws, and every invalidation raised during one
     * is another area to paint inside the same frame; the dots, the chip's breathing and
     * the ring all keep their state and are drawn on the first tick after the turn lands.
     * The tick itself still advances, so no rhythm loses its place.
     */
    if (s_sliding) {
        return;
    }

    /* The picture's two seconds, on the timer that is already running. A knob that
     * is still moving has pushed the stamp forward, so this is the only place the
     * middle is given back — no second timer, no one-shot to cancel. */
    preview_tick(now_ms());

    /* Ahead of every branch below, because the transport curtain returns early and the
     * chip has to keep breathing behind it as well. */
    if ((s_tick % PRESET_BLINK_EVERY_N_TICKS) == 0) {
        preset_blink();
    }

    /* The dots on their tracks, every tick: a dot that jumps a twelfth of a second at a time
     * reads as a stutter rather than as motion. Skipped while a curtain covers the page and
     * mid-turn, where nothing they draw would be seen. */
    if (!s_transport_open && !s_nav_open) {
        refresh_viz();
    }

    /* The ribbon on the preset page, at its own slow rate. */
    if (!s_transport_open && !s_nav_open && page()->view == VIEW_PRESET
        && (s_tick % WAVE_EVERY_N_TICKS) == 0) {
        wave_advance();
    }

    /*
     * The transport curtain owns the ring while it is up, so it decides the rate as well: the
     * page behind must not gate the redraw. A figure page that is not advancing — the transport
     * is stopped, which is exactly when a tempo gets set — would otherwise leave the arc frozen
     * or absent for the whole time the curtain is open.
     */
    if (s_transport_open) {
        if ((s_tick % RING_EVERY_N_TICKS) == 0) {
            update_ring();
        }
        return;
    }

    /*
     * The tiles blink with their own rhythms while the map is up, and nowhere else: the map is the
     * only place they are all visible at once, and when it is closed there is nothing to redraw. Its
     * rate is its own, because a 300 BPM pattern flashes five times a second.
     */
    if (s_nav_open && (s_tick % NAV_RHYTHM_EVERY_N_TICKS) == 0) {
        nav_rhythm_refresh();
    }

    /*
     * The ring is redrawn when there is something new on it, not on a fixed beat.
     *
     * A refresh blocks this task for the length of an RMT frame — around 400 us
     * for thirteen LEDs — and the audio task shares the core, so the rate is not
     * free. On a page with a figure the playhead is the thing to keep up with, and
     * once per step is exactly right: twice a second at 30 BPM, thirteen times at
     * 200. Everywhere else the only movement is a value being turned or a pan drift
     * designed in tens of seconds, and eight frames a second is already faster
     * than either.
     */
    if (page_has_figure()) {
        synth_app_seq_view_t v;
        page_seq_view(&v);

        if (s_page == s_ring_seq_page
            && v.steps == s_ring_seq.steps && v.position == s_ring_seq.position
            && v.sounding == s_ring_seq.sounding) {
            return;
        }
        s_ring_seq = v;
        s_ring_seq_page = s_page;
        update_ring();
    } else {
        /* Leaving the page invalidates the record, so coming back to it — or to the
         * other page that has a figure — draws on the first frame rather than waiting
         * for the step after. */
        s_ring_seq.steps = -1;
        s_ring_seq_page = PAGE_COUNT;

        if ((s_tick % RING_EVERY_N_TICKS) == 0) {
            update_ring();
        }
    }
}

/*
 * Twice a second, for the two things that change without passing through this file: the
 * transport's own readouts, and whether the sound on the panel is still the one that was
 * noted. Skipped mid-turn for the same reason as the others, and the page it belongs to is
 * redrawn when the turn lands.
 */
static void housekeeping_timer_cb(lv_timer_t *timer)
{
    (void)timer;

    if (s_sliding) {
        return;
    }

    /* The battery and the tempo live on the transport screen, so they are only worth
     * asking for while that screen is up. Both the read and the rewrite are guarded, so
     * this is a comparison in the common case. */
    if (s_transport_open) {
        refresh_battery();
        refresh_tempo();
    }

    /*
     * The remembered sound: checked, rather than hooked into every way it can change.
     *
     * write_param() notes the patch on every knob move, but a knob move is not the only way
     * the sound changes — loading a preset and the randomiser go straight into the app and
     * never pass through this file's writer. Hooking those two would fix today's two and
     * leave the third to be discovered the same way this one was: by losing a sound. So the
     * comparison itself is the hook. Every half second, is the sound still what was last
     * noted? A 240-byte read and compare, and when it differs the note is taken — which is
     * the same debounced write a knob move takes, so this cannot wear the flash out: two
     * minutes of sitting still produced no write at all, and a slide in progress simply
     * pushes the write further away.
     *
     * The copy is kept here because app_settings stores the values when the flash is
     * actually written, and this has to know what it handed over, not what survived.
     */
    if (s_ready && app_settings_get(APP_SET_PATCH) == APP_PATCH_STORE) {
        static float noted[SYNTH_PARAM_PATCH_COUNT];
        static bool  noted_valid;

        float sounding[SYNTH_PARAM_PATCH_COUNT];
        synth_app_get_params(sounding, SYNTH_PARAM_PATCH_COUNT);

        if (!noted_valid || memcmp(sounding, noted, sizeof(sounding)) != 0) {
            memcpy(noted, sounding, sizeof(noted));
            noted_valid = true;
            app_settings_patch_note(sounding, SYNTH_PARAM_PATCH_COUNT);
        }
    }
}

/* -------------------------------------------------------------------------- */
/* Events                                                                     */
/* -------------------------------------------------------------------------- */

/*
 * The knob. Only this object produces these events, because it is the only
 * focusable widget on the screen.
 *
 * LVGL moves the arc one step per detent and loops over any detents it
 * accumulated between reads, so the raw difference here is a detent count — and
 * the arc's value is NOT the parameter's position. That is s_proxy_value, which
 * this function owns and writes back through proxy_sync_value(). Treating the
 * arc as the source of truth would cap the whole thing at LVGL's own step size
 * and make acceleration impossible.
 *
 * The selected parameter follows the scaled detent count absolutely. The macro
 * members follow the CHANGE, each clamped to its own range, because they sit at
 * different places and an absolute write would slam them all to the same
 * normalised position — which is not what "move together" can possibly mean.
 *
 * Once the selected parameter reaches its rail the delta stops, so the macro
 * stops with it. That is the honest behaviour: continuing to drag members after
 * the leader has run out would make the leader's position a lie.
 */
/* -------------------------------------------------------------------------- */
/* Settings                                                                   */
/* -------------------------------------------------------------------------- */
/*
 * The settings pages run through the same machinery as the sound pages: the same
 * sectors, the same tap to select, the same long press to add to the macro. What
 * differs is only where a value ends up.
 *
 * It ends up in two places. synth_app keeps the number, because synth_app's table
 * is what every readout reads back from — the arcs, the value labels, the ring,
 * the navigator's idea of what is selected. app_settings owns the effect and the
 * flash. Writing only the first would show the user a brightness they do not
 * have; writing only the second would leave the display lying about it.
 */
static const struct {
    synth_param_t param;
    app_setting_t setting;
} SETTINGS_MAP[] = {
    { SYNTH_PARAM_SET_SCREEN,   APP_SET_SCREEN    },
    { SYNTH_PARAM_SET_RING,     APP_SET_RING      },
    { SYNTH_PARAM_SET_RINGMODE, APP_SET_RING_MODE },
    { SYNTH_PARAM_SET_PATCH,    APP_SET_PATCH     },
    { SYNTH_PARAM_SET_SLIDE,    APP_SET_SLIDE     },
    { SYNTH_PARAM_SET_RNDDELAY, APP_SET_RND_DELAY },
    { SYNTH_PARAM_SET_MIC,      APP_SET_MIC       },
    { SYNTH_PARAM_SET_WEAKVEL,  APP_SET_WEAK_VEL  },
    { SYNTH_PARAM_SET_MIDIIN,   APP_SET_MIDI_IN   },
    { SYNTH_PARAM_SET_WAVEMORPH, APP_SET_WAVE_MORPH },
    /*
     * SET_DRIVE_POS is NOT here any more. The drive left the instrument — see KNOBS_MASTER —
     * and the position of a stage that no longer exists is not a setting. Both the parameter
     * and APP_SET_DRIVE_POS keep their slots: the parameter because the patch is indexed by it,
     * the setting because app_settings' table is indexed by ITS enum and every stored value
     * after it would otherwise move one place.
     */
};

#define SETTINGS_COUNT ((int)(sizeof(SETTINGS_MAP) / sizeof(SETTINGS_MAP[0])))

/* The ones that are a percentage rather than an entry in a list. The microphone's
 * sensitivity is here for the same reason the two brightnesses are: setting_of() and
 * param_of() would otherwise work out its positions from synth_app_param_steps(), which
 * is 0 for a continuous parameter — one position short, or minus one of them — and the
 * stored number would be written as junk.
 *
 * WEAK VEL is deliberately NOT here, and it is the first setting that is neither a
 * percentage nor a small list: the engine's velocity is whole numbers 0..127, so it is
 * declared as a list of 128 and the two functions below do the right arithmetic without
 * being told anything — positions is 127, the value is round(v * 127) and the knob
 * position is value / 127, exactly, for every one of the 128. A second percent-style
 * mapping for it would be a second place to get the same sum wrong. */
static bool is_brightness(synth_param_t param)
{
    return param == SYNTH_PARAM_SET_SCREEN || param == SYNTH_PARAM_SET_RING ||
           param == SYNTH_PARAM_SET_MIC;
}

/* Knob position to setting, in the setting's own units — percent, or a list
 * index. */
static int setting_of(synth_param_t param, float v01)
{
    if (is_brightness(param)) {
        return (int)(v01 * 100.0f + 0.5f);
    }
    const int positions = synth_app_param_steps(param) - 1;
    return (int)(v01 * (float)positions + 0.5f);
}

/* And back again, for restoring what was stored at boot. */
static float param_of(synth_param_t param, int value)
{
    if (is_brightness(param)) {
        return (float)value / 100.0f;
    }
    const int positions = synth_app_param_steps(param) - 1;
    return positions > 0 ? (float)value / (float)positions : 0.0f;
}

/*
 * The settings whose effect is not the board's to apply.
 *
 * app_settings enacts the two brightnesses itself, because they are one BSP call each. What
 * is left is everything whose effect lives somewhere else — the ring mode in the ring's own
 * redraw, the slide duration inside the audio task — and now the note
 * input, whose whole effect is another COMPONENT: midi_in_set_enabled() installs or
 * uninstalls the USB device stack. app_settings cannot make that call itself, because
 * components/midi requires synth_app and synth_app requires app_settings, so the edge back
 * would be a cycle; the settings page owns it instead, which is where the write already
 * arrives.
 *
 * This is called on EVERY path a setting is restored by, and that is deliberate: the stored
 * value is applied at boot (restore_settings) and on every change, so the port the board
 * offers and the word on the screen cannot disagree. midi_in_set_enabled() is idempotent, so
 * the boot path asking for the state it is already in costs nothing.
 */
static void apply_setting(app_setting_t id, int value)
{
    if (id == APP_SET_RING_MODE) {
        /* The ring redraws on its own timer; this makes sure it draws the new
         * mode rather than the old one's last frame. */
        s_ring_off_done = false;
    }
    if (id == APP_SET_SLIDE) {
        /* The one setting whose effect is entirely inside the audio task: the index becomes
         * a duration there, where the ramp that uses it lives. */
        synth_app_slide_set_index(value);
    }
    if (id == APP_SET_MIDI_IN) {
        /*
         * The note input, on or off, NOW — that is the whole point of the setting, and the
         * only reason it is not a compile-time switch. OFF stops the reader and uninstalls
         * the USB device stack, which is what hands the USB-C port back to the debug console;
         * ON is the same call the other way. Both directions are logged by the component,
         * including what the uninstall is made of, so the log is where the trade is visible.
         *
         * The failure is logged and not fatal: the instrument is playing, the screen is up,
         * and a note input that would not come up is a cable to look at. It is also not
         * silent, because the setting and the port would then disagree — the two lines below
         * say which of them won, and the setting stays where the player put it so that a
         * second turn tries again rather than pretending the first one worked.
         */
        const esp_err_t midi_err = midi_in_set_enabled(value != 0);
        if (midi_err != ESP_OK) {
            ESP_LOGW(TAG, "MIDI in: %s — %s", value ? "could not start" : "could not stop",
                     esp_err_to_name(midi_err));
        }
        if (s_ready) {
            diag_record(DIAG_EVT_MIDI, value != 0, midi_err == ESP_OK);
        }
    }
}

/*
 * One write, from either the knob or the macro.
 *
 * Sound parameters stop at synth_app, which hands them to the audio task. The
 * settings are additionally applied and queued for flash, and anything that is
 * part of the sound is offered to the remembered patch.
 */

/*
 * The sound, offered to the remembered patch.
 *
 * Only STORE has a remembered patch to offer it to. FORGET threw it away on purpose and
 * RANDOM is about to overwrite it at the next switch-on, so in either of those the write
 * would be one flash write per detent for a value nothing will ever read. The comparison
 * is against APP_PATCH_STORE rather than on the truthiness of the setting, because RANDOM
 * is truthy as well.
 *
 * Its own function because two paths change the sound and only one of them is the wheel:
 * a preset load goes straight into the app and never passes through write_param() below.
 */
static void patch_note(void)
{
    if (app_settings_get(APP_SET_PATCH) != APP_PATCH_STORE) {
        return;
    }

    /* A copy by the time it is used: the array belongs to the audio task and will have
     * changed before the flash is written. */
    float blob[SYNTH_PARAM_PATCH_COUNT];
    synth_app_get_params(blob, SYNTH_PARAM_PATCH_COUNT);
    app_settings_patch_note(blob, SYNTH_PARAM_PATCH_COUNT);
}

static void write_param(synth_param_t param, float v01)
{
    synth_app_set_param(param, v01);

    if (diag_param_is_fx(param)) {
        diag_fx(param, v01);
    }

    for (int i = 0; i < SETTINGS_COUNT; i++) {
        if (SETTINGS_MAP[i].param != param) {
            continue;
        }
        const int value = setting_of(param, v01);
        app_settings_set(SETTINGS_MAP[i].setting, value);
        apply_setting(SETTINGS_MAP[i].setting, value);
        return;
    }

    if ((int)param >= SYNTH_PARAM_PATCH_COUNT) {
        return;
    }

    /*
     * Any hand but the mute's own lifts the mute. This is the one place every writer of a
     * parameter ends up — the knob, the macro, a draw, the tempo — so one line here covers
     * all of them, and it answers the failure that would otherwise follow a preset: a part
     * muted before a load would stay flagged, the loaded level would sound, and the next
     * double tap would push a stale remembered value over it.
     *
     * sector_mute() raises the flag after its own write and drops it before the one that
     * restores the level, so neither half of the gesture arrives here as an outside hand.
     * The remembered value is left alone and is harmless once the flag is down: only a
     * flag that is up can bring it back.
     */
    s_mute_on[param] = false;

    /*
     * The sound has moved away from the store, and this is the only place that sees it
     * happen: every knob, every macro member and the randomiser writes through here,
     * and nothing else on the device writes a parameter at all. Deliberately below the
     * settings branch above, because a setting is not part of the sound — turning the
     * screen down must not mark the patch as changed.
     *
     * Deliberately ABOVE the patch test below: the dirty mark is about the preset
     * store, and it means the same thing whatever the PATCH setting says. It used to
     * sit under that test, which meant a knob move in FORGET left the dot dark even
     * though the sound had plainly moved.
     */
    s_preset_dirty = true;

    patch_note();

    /*
     * THE CLOCK IS NOTED IN ITS OWN KEY as well as in the patch, because the two answer
     * different questions: the patch is the sound the instrument comes back to when the PATCH
     * setting says so, and the key is where the clock stood whatever the setting says. Only the
     * tempo goes to it — see app_settings_tempo_note() — and the call is a no-op when nothing
     * moved, so a preset load and a draw may pass through here freely.
     */
    if (param == SYNTH_PARAM_SEQ_TEMPO) {
        app_settings_tempo_note(v01);
    }
}

#if CONFIG_OBOD_SCREENSHOTS
/*
 * The arpeggiator, for the snapshot walk.
 *
 * The EUCLID page is the one page whose frame depends on a state the factory patch does not
 * have: while the arp has taken the grid, the middle of the dial says ARP IS ACTIVE instead of
 * showing the figure, and that sentence is what the documentation's picture is for. The walk
 * therefore shoots the page twice, and these are the three small answers it needs.
 *
 * The switch is DIR's own list — OFF is its first position and UP the second, and the value a
 * list parameter carries is index/(count-1) — and it goes through write_param() like every
 * other state the walk sets, so the frame is the interface's own work and not a redrawing of
 * it. Whether the arp is running afterwards is synth_app_arp_active()'s answer, not ours.
 */
int synth_ui_arp_page(void)
{
    return (int)PAGE_EUCLID;
}

float synth_ui_arp_get(void)
{
    return synth_app_get_param(SYNTH_PARAM_ARP_DIR);
}

void synth_ui_arp_put(float dir01)
{
    write_param(SYNTH_PARAM_ARP_DIR, dir01);
}

/* DIR carries eight positions: OFF, UP, DN, UP-DN, DN-UP, UP-DN+, DN-UP+, RAND. */
float synth_ui_arp_on_value(void)
{
    return 1.0f / 7.0f;
}
#endif

/*
 * What the device remembers, read back at boot — before the sectors are built,
 * so that the first thing drawn is the truth.
 *
 * Restoring goes through synth_app_patch_apply() and not through write_param():
 * reading a stored value is not the user changing it, and routing it through the
 * writer would queue a flash write for every parameter on every boot. The apply is
 * also where a blob written before the drone's three shapes is repaired — the old
 * single shape becomes all three and ROOT is brought across the widened range — so
 * the two doors into a stored sound, this one and the preset list, cannot disagree
 * about what an old record means.
 *
 * Only STORE comes back. FORGET boots what the instrument was designed to sound
 * like, and RANDOM redraws it a moment later; in both of those the stored blob is
 * either unwanted or about to be replaced, and bringing it back would mean the boot
 * draw had to fight a stale sound it had just been handed. The test is against
 * APP_PATCH_STORE and not the setting's truthiness, because RANDOM is truthy.
 */
static void restore_settings(void)
{
    for (int i = 0; i < SETTINGS_COUNT; i++) {
        const int value = app_settings_get(SETTINGS_MAP[i].setting);
        synth_app_set_param(SETTINGS_MAP[i].param,
                            param_of(SETTINGS_MAP[i].param, value));
        apply_setting(SETTINGS_MAP[i].setting, value);
    }

    if (app_settings_get(APP_SET_PATCH) != APP_PATCH_STORE) {
        return;
    }

    float blob[SYNTH_PARAM_PATCH_COUNT];
    const int n = app_settings_patch_load(blob, SYNTH_PARAM_PATCH_COUNT);
    if (n <= 0) {
        return;     /* nothing stored, or a blob that did not survive its length check */
    }

    /*
     * n can be SHORT and that is not damage. The patch is the parameter list, so a
     * parameter appended to the end makes every blob written before it a prefix of the
     * current one: the values that are here are restored, and what the blob cannot carry
     * is answered by the apply below — the drone's three shapes from the old single shape
     * it does carry, FOLLOW from its factory position, the two RESET fields from their
     * documented defaults. That is the reason a new control goes at the END of the block,
     * and it is why this is a warning and not a refusal. A blob whose length disagrees
     * with its own count is caught in app_settings_patch_load, and that is the check that
     * actually matters.
     */
    if (n < SYNTH_PARAM_PATCH_COUNT) {
        ESP_LOGW(TAG, "stored sound has %d of %d parameters — the rest keep their defaults",
                 n, SYNTH_PARAM_PATCH_COUNT);
    }

    synth_app_patch_apply(blob, n);
    ESP_LOGI(TAG, "sound restored: %d parameters", n);
}

static void proxy_changed_cb(lv_event_t *e)
{
    (void)e;

    if (!s_ready || s_syncing) {
        return;
    }

    /*
     * The transport screen is modal: the wheel must not reach the page behind it — but it
     * is no longer ignored. This is the one screen on the instrument with a wheel and
     * nothing for it to turn, and the tempo is the one number worth changing while you are
     * looking at the button that starts and stops the music.
     *
     * It goes through the SAME parameter the knob used to drive, so a synced delay follows
     * it without knowing anything happened, and a preset stores the tempo set here. The
     * arc's position is still tracked for the page behind, so the first click after closing
     * is one step rather than the whole travel of a wheel nobody could see.
     */
    if (s_transport_open) {
        /*
         * The wheel's movement is taken here rather than below, because below is the page
         * behind the curtain and this screen has its own use for the same detents. The
         * acceleration is the same curve every other knob uses, and the tempo is
         * continuous, so there is no discrete case to hold it back.
         */
        const int32_t raw = lv_arc_get_value(s_proxy);
        const int32_t steps = raw - s_arc_last;
        s_arc_last = raw;
        if (steps != 0) {
            diag_knob((int)s_page, (int)SYNTH_PARAM_SEQ_TEMPO);
        }
        s_mult = knob_multiplier(steps, false);

        const float before = synth_app_get_param(SYNTH_PARAM_SEQ_TEMPO);
        const int32_t here =
            (int32_t)(before * (float)TRANSPORT_TEMPO_STEPS + 0.5f);

        int32_t target = here + steps * s_mult;
        if (target < 0) {
            target = 0;
        } else if (target > TRANSPORT_TEMPO_STEPS) {
            target = TRANSPORT_TEMPO_STEPS;
        }

        write_param(SYNTH_PARAM_SEQ_TEMPO,
                    (float)target / (float)TRANSPORT_TEMPO_STEPS);
        refresh_tempo();
        return;
    }

    const int32_t raw = lv_arc_get_value(s_proxy);
    const int32_t steps = raw - s_arc_last;
    s_arc_last = raw;

    if (steps == 0) {
        return;
    }

    /*
     * EVERY KNOB ACCELERATES, lists included. The exemption lists used to get — one detent,
     * one position, however fast the hand — was defensible when a list was four names long and
     * a flick could overshoot past something. It is not what a wheel does: on sixteen kits or
     * seventeen grooves the slow turn is what the exemption was protecting, and it still has
     * it above about twelve detents a second, while a flick crosses the list the way a flick on
     * any other control crosses its travel. Skipping a position is not a lost decision: the
     * sector prints the name of wherever the knob landed, and turning back is one detent.
     */
    s_mult = knob_multiplier(steps, s_discrete || (page()->view == VIEW_PRESET));

    if (s_nav_open) {
        /*
         * While the map is up the knob walks the sections of the current group and
         * must NOT reach the parameters: turning to find a section would otherwise
         * rewrite whatever was selected before the map opened — a value the user
         * never touched and cannot even see. NAV_WHEEL_PAGES is the one line that
         * turns this off again.
         */
#if NAV_WHEEL_PAGES
        nav_page_step(steps * s_mult);
#endif
        return;
    }

    const ui_page_t *p = page();

    int traced_param = -1;
    if (p->view == VIEW_KNOBS && p->knob_count > 0) {
        traced_param = (int)p->knobs[sel_index()].param;
    }
    diag_knob((int)s_page, traced_param);

    if (p->view == VIEW_PRESET) {
        /*
         * On the preset page the knob is the list, one detent to a row, and nothing
         * is loaded: selecting is not loading. The arc's range is the list — the stored
         * slots and the one free target past them (preset_refresh() sets it) — so this
         * is the same arithmetic as a knob on a discrete parameter, including the
         * clamp, which is what stops the walk at the ends instead of wrapping round a
         * list of 128.
         */
        int32_t target = s_proxy_value + steps * s_mult;
        if (target < 0) {
            target = 0;
        } else if (target > s_steps) {
            target = s_steps;
        }

        proxy_sync_value(target);
        preset_select((int)target + PRESET_SEL_INIT);
        return;
    }

    if (p->knob_count == 0) {
        return;
    }

    int32_t target = s_proxy_value + steps * s_mult;
    if (target < 0) {
        target = 0;
    } else if (target > s_steps) {
        target = s_steps;
    }

    const synth_param_t primary = p->knobs[sel_index()].param;
    write_param(primary, (float)target / (float)s_steps);

    /* The CLAMPED delta, not the requested one: the macro should stop when the
     * leader runs out of range, not keep travelling on a movement that no longer
     * shows anywhere. */
    const float d = (float)(target - s_proxy_value) / (float)s_steps;
    /* A setting does not DRIVE the macro either, which is the same rule seen from the
     * other end: turning the backlight must not move the sound. The loop also stops at
     * the patch boundary, so a flag left over from anywhere could not move a setting. */
    const bool leader_ok = ((int)primary < SYNTH_PARAM_PATCH_COUNT);
    for (int i = 0; leader_ok && i < SYNTH_PARAM_PATCH_COUNT; i++) {
        if (!s_macro[i] || i == (int)primary) {
            continue;
        }
        /* A reversed member takes the same delta the other way. This is the whole of
         * the inversion, and the only place the macro touches a value. */
        const float step = s_macro_inv[i] ? -d : d;
        float v = synth_app_get_param((synth_param_t)i) + step;
        if (v < 0.0f) {
            v = 0.0f;
        } else if (v > 1.0f) {
            v = 1.0f;
        }
        write_param((synth_param_t)i, v);
    }

    proxy_sync_value(target);
    refresh_values();

    /* The value moved — d is the clamped delta — so the middle says what this knob
     * does. A turn the rail swallows (already at 0, or a macro at the end of its
     * travel) is not a change and does not restart the two seconds. */
    if (d != 0.0f) {
        preview_show(primary);
    }
}

/* True when the CLICKED being resolved is the one that ended a swipe. A gesture still releases
 * as a CLICKED on whatever object the finger started on, so without this the page turn would
 * also re-select the sector under the finger. The click comes from the very call that sent the
 * gesture, so the test is which finger made both — see the tuning block. */
static bool swipe_just_happened(void)
{
    return s_swipe_contact != SWIPE_CONTACT_NONE && bsp_touch_contact() == s_swipe_contact;
}

/*
 * Double tap: turn a macro member around, so the macro pushes this parameter the other
 * way. The whole of the inversion is one sign, in the macro's own loop.
 *
 * Only a member can be reversed: the flag means nothing on its own, and a parameter
 * would carry it invisibly until it happened to join a macro. Reversing the sector the
 * knob is standing on is allowed and simply has no effect until the knob moves, because
 * the macro's loop skips the leader — the flag is a property of the PARAMETER and not
 * of this moment.
 */
static void sector_invert(int idx)
{
    const ui_page_t *p = page();

    if (!s_ready || swipe_just_happened() || idx < 0 || idx >= p->knob_count) {
        return;
    }

    const synth_param_t id = p->knobs[idx].param;
    if (!s_macro[id]) {
        return;
    }

    s_macro_inv[id] = !s_macro_inv[id];
    refresh_macro();

    ESP_LOGI(TAG, "macro %s %s", s_macro_inv[id] ? "invert" : "restore",
             p->knobs[idx].sector);
}

/*
 * The parameters a double tap may silence: the five part levels, the six reverb sends and
 * the four lane levels of the percussion mixer.
 *
 * They are named one by one rather than read out of a page table, because the mute is a
 * property of the PARAMETER: the paths that have to lift it — a knob, a macro member, a
 * preset load, a draw — hold the parameter and never the page or the sector index. Naming
 * them here is what keeps the sectors that can set a mute and the set of values that can
 * clear one the same list, and it keeps the gesture off every other sector, where the
 * double tap still belongs to the macro inversion.
 *
 * The levels and the sends are the two rows a mixer sets together — a part's level, and
 * how much of it goes to the reverb — and both are a plain 0..1 amount whose zero is a
 * meaningful setting rather than a broken one: silent, and no reverb. The four lane
 * levels of PERC MIX are the same amount on the part's own four lanes: zero there is a
 * lane that does not strike at all (perc_strike() refuses the hit rather than playing it
 * at zero), so the drop is heard as the drummer stopping that drum, which is exactly what
 * a mute is for. The microphone's
 * send is in the list with the other five for the same reason; its knob is the whole of
 * the microphone's path to the effects, so zero is what closes it. Nothing else on any
 * page is an amount of that kind — a mode, a rate or a cutoff has no zero that means
 * anything — which is why the list stops there.
 */
static bool can_mute(synth_param_t param)
{
    return param == SYNTH_PARAM_LEAD_LEVEL || param == SYNTH_PARAM_PERC_LEVEL ||
           param == SYNTH_PARAM_DRONE_LOW  || param == SYNTH_PARAM_DRONE_MID  ||
           param == SYNTH_PARAM_DRONE_HIGH ||
           param == SYNTH_PARAM_SEND_LOW   || param == SYNTH_PARAM_SEND_MID   ||
           param == SYNTH_PARAM_SEND_HIGH  || param == SYNTH_PARAM_SEND_LEAD  ||
           param == SYNTH_PARAM_SEND_PERC  || param == SYNTH_PARAM_SEND_MIC ||
           param == SYNTH_PARAM_PERC_MIX_KICK  || param == SYNTH_PARAM_PERC_MIX_SNARE ||
           param == SYNTH_PARAM_PERC_MIX_HAT   || param == SYNTH_PARAM_PERC_MIX_TOM ||
           viz_send_fx(param) != 0;
}

/* Every mute down, the values left where they are. A preset load has just put its own
 * levels and sends into the engine and never passes through write_param(), so this is the
 * one writer that has to lift the flag for itself. The remembered values are not cleared:
 * they are unreachable while their flag is down, and the next mute overwrites them with
 * whatever the loaded preset left sounding. */
static void mute_clear_all(void)
{
    for (int i = 0; i < SYNTH_PARAM_COUNT; i++) {
        s_mute_on[i] = false;
    }
}

/*
 * Mute: a double tap drops the value to silence, the next one lifts it back to where it
 * stood. It works on a part's level and on a part's send alike — the same gesture, the
 * same remembered value, the same speed — because the two are the same kind of amount and
 * there is nothing about either that a mute would mean differently.
 *
 * The mute is a SWITCH, not a fade, and synth_app_slide_begin() is deliberately not called
 * here. It used to be, on the argument that a mute was a batch like any other and SLIDE
 * should decide how long it took; the result was two different speeds for one gesture,
 * because the double tap's other meaning — the macro inversion, sector_invert() — is a flag
 * and answers on the spot, while the muted level fell over the whole slide time, half a
 * second at the default. On a page of levels that delay reads as the gesture itself being
 * late, and no page should make the same tap feel slower than another.
 *
 * So both halves are written without the ramp: with nothing travelling, the engine applies
 * a write in the block it arrives in, which is the instant cut. SLIDE stays what it is —
 * the time a batch of VALUES takes to arrive — and a mute is not a value being moved, it is
 * a part being switched out of the mix. The write is still an ordinary write, so the arc,
 * the readout and the patch's dirty mark all follow on their own.
 *
 * The order around each write is what keeps write_param()'s clear from mistaking the
 * gesture's own write for an outside hand, and each half has its own reason:
 *
 *  - muting, the flag is raised AFTER the write, so the write arrives as an ordinary
 *    move, and the value remembered is the one that is sounding when the tap lands —
 *    read before anything is written, which is the only value worth putting back.
 *    A part already at zero remembers zero: that is where it was, and there is no other
 *    value to guess at.
 *  - lifting, the flag is dropped BEFORE the write and the remembered value is read into
 *    a local first, so the restoring write is an ordinary move as well. The stored value
 *    is not cleared, so a mute can be lifted and set again without losing the level.
 *
 * The display is left entirely to what the page already has. The parameter is written to
 * zero, so the readout prints zero and the arc sweeps to zero — the same two things that
 * show any other quiet value. Nothing new is drawn, and there is no separate "off" mark
 * on a sector to keep in step with the value, which is the rule the rest of the interface
 * follows: the number on the screen is the number in the engine.
 */
static void sector_mute(int idx)
{
    const ui_page_t *p = page();

    if (!s_ready || swipe_just_happened() || idx < 0 || idx >= p->knob_count) {
        return;
    }

    const synth_param_t id = p->knobs[idx].param;
    if (!can_mute(id)) {
        return;
    }

    if (!s_mute_on[id]) {
        const float was = synth_app_get_param(id);

        write_param(id, 0.0f);
        s_mute_on[id] = true;
        s_mute_val[id] = was;
    } else {
        const float back = s_mute_val[id];

        s_mute_on[id] = false;
        write_param(id, back);
    }

    /* The knob is standing on this sector, so its position has to follow the level it
     * just lost or regained — the same pair sector_draw() makes after its own write. */
    proxy_load(id);
    refresh_values();
}

/*
 * A tap on a sector, from the words or from the wedge, and the double tap: the value's mute
 * when the sector under the finger is one can_mute() names, and a macro member turned
 * around otherwise.
 *
 * The double is counted HERE rather than with LV_EVENT_DOUBLE_CLICKED, because LVGL
 * counts clicks per OBJECT and a sector is two of them: the block of words and the polar
 * layer that fills the rest of the wedge. Two taps a centimetre apart land on different
 * objects, the count resets and the event never arrives — which is exactly what the panel
 * showed: a double that only worked out by the rim where the wedge is alone under the
 * finger. The gesture means two taps on one SECTOR, so the sector is what gets counted.
 *
 * Both ends of the interval are the moment a finger LANDED, taken from press_stamp_cb(),
 * and not the CLICKED that follows each release. A click is dispatched on the release, and
 * the release waits for a frame: the same pair of taps measured 200 ms when both clicks fell
 * in the same frame and 600 ms when a frame boundary fell between them, so the gesture
 * answered by luck. A press is dispatched in the frame the finger is in, and the two presses
 * of a pair fall in the same frame far more often than the two releases do — a tap that
 * starts and ends inside one frame has its press and its click stamped together anyway.
 *
 * The window itself is the other half of the forgiveness. Press to press, a deliberate pair
 * is 150 to 300 ms and a slow one 400; 500 leaves a margin above both and still stops short
 * of the rhythm of two separate taps, which is where the eye is already looking at the value
 * between them.
 */
#define DOUBLE_TAP_MS  500   /* press to press; see above */

/* How old a press may be and still be the one a click belongs to. A tap is over in a frame
 * or two; a press that started a long press is older than this, and its click is measured by
 * the clock instead — which is what keeps a long press and the tap after it from pairing. */
#define TAP_PRESS_MAX_AGE_MS 1000

static void sector_tapped(int idx)
{

    if (!s_ready || swipe_just_happened()) {
        return;
    }

    /*
     * The press of THIS tap, when there is one and it is still recent. The stamp is spent as
     * it is read: a click that has no press of its own behind it — a press the panel never
     * reported — is measured against the clock rather than against some older finger.
     */
    uint32_t now = now_ms();

    if (s_press_valid) {
        s_press_valid = false;

        if ((now - s_press_ms) < TAP_PRESS_MAX_AGE_MS) {
            now = s_press_ms;
        }
    }

    const bool twice = (idx == s_tap_idx) && ((now - s_tap_ms) < DOUBLE_TAP_MS);

    s_tap_ms = now;
    s_tap_idx = twice ? -1 : idx;   /* the third tap of a run starts over */

    if (twice) {
        /*
         * What the second tap means is decided by the PARAMETER under the finger, not by
         * the page: if it is a level or a send — one of the values can_mute() names — AND
         * it is not a macro member, the gesture is the mute; everything else keeps the
         * macro inversion it has always had.
         *
         * The two halves of that rule have two different reasons. Asking the page instead
         * of the parameter would be simpler and wrong — a value is not its page: the level
         * and the send of one part sit on different pages, and a page is a place rather
         * than a property, so reading the choice off the page would take the inversion away
         * from any other sector that ever shares the row. And a macro member keeps the
         * inversion on purpose: while a parameter rides the macro its double tap already
         * has a meaning, the direction the macro pushes it, and a member that could also be
         * muted through the same tap would make the two indistinguishable on the very
         * sectors that are hardest to read. s_macro[] is the membership — s_macro_inv[] is
         * only the direction, and it says nothing about whether the parameter is in the
         * macro at all.
         *
         * The bounds test is here because sector_tapped() has not made one yet;
         * sector_mute() and sector_invert() each make their own as well.
         */
        const ui_page_t *p = page();

        if (idx >= 0 && idx < p->knob_count && can_mute(p->knobs[idx].param) &&
            !s_macro[p->knobs[idx].param]) {
            sector_mute(idx);
        } else {
            sector_invert(idx);
        }
        return;
    }
    sector_activate(idx, false);

    /*
     * THE PICTURE FOLLOWS THE FINGER ACROSS THE ROW. A tap on a sector shows THAT sector's
     * figure, built from its own values, and the two seconds start again: choosing a sector
     * is the gesture that asks what it is set to, so the middle answers with the figure of
     * what the finger landed on. A tap while a figure is already up carries the burst along
     * the row instead of ending it — the same picture in the same place, one sector over.
     *
     * This is the same rule as a turn, spoken with a different finger: a turn explains the
     * knob under the hand, a tap explains the sector under it. The tap is not asked whether
     * a figure is up already, because a selection has to answer every time — the first tap of
     * a burst as much as the fifth.
     *
     * A sector with nothing honest to draw ends the burst and puts the page's name back:
     * preview_show() answers PREVIEW_NONE that way, which is the same answer the knob itself
     * gives when it is turned.
     */
    {
        const ui_page_t *p = page();

        if (idx >= 0 && idx < p->knob_count) {
            preview_show(p->knobs[idx].param);
        }
    }
}

/*
 * A new value for the parameter the knob is standing on, drawn on the spot.
 *
 * The middle of the page is the only place a tap can mean this. A tap on a sector already
 * means "select it" and its long press means the macro, so the draw has to live where
 * nothing else does — and the middle is exactly that, because the sector lookup rejects
 * everything inside the rim.
 *
 * It arrives as a batch like any other, so SLIDE applies, and synth_app_slide_begin() is
 * called BEFORE the write: the ramp is built from the values that are sounding when the
 * request is seen. A list parameter jumps, by the engine's own rule — a wave has no halfway
 * house.
 *
 * The settings are left alone for the reason the macro leaves them alone: a setting is not
 * part of the sound, and a draw landing on the screen's brightness would be a gesture on the
 * wrong object.
 *
 * The value is drawn from the middle of the range (PRESET_RAND_FLO and PRESET_RAND_SPAN),
 * the same as the sound randomiser's: a cutoff drawn end to end is as likely to be a closed
 * filter as an open one. A list is the exception, and only here: one tap draws one of its
 * entries, chosen evenly from all of them, which is what the gesture is asking for — "give
 * me another one of these" rather than "give me a musical patch". The patch-wide draw
 * narrows the two long division lists instead; see preset_rand_flo().
 */
static void sector_draw(void)
{
    const ui_page_t *p = page();
    const int idx = (int)s_sel[s_page];

    if (!s_ready || swipe_just_happened() || idx < 0 || idx >= p->knob_count) {
        return;
    }

    const synth_param_t id = p->knobs[idx].param;

    if ((int)id >= SYNTH_PARAM_PATCH_COUNT) {
        ESP_LOGI(TAG, "draw: %s is a setting, not part of the sound", p->knobs[idx].sector);
        return;
    }

    synth_app_slide_begin();

    const int positions = synth_app_param_steps(id);
    const float v = (positions > 1)
                        ? (float)(esp_random() % (uint32_t)positions) / (float)(positions - 1)
                        : PRESET_RAND_FLO + PRESET_RAND_SPAN * preset_random_unit();

    write_param(id, v);
    proxy_load(id);
    refresh_values();

    ESP_LOGI(TAG, "draw %s %.3f, slide %.0f ms", p->knobs[idx].sector, v, synth_app_slide_ms());
}

static void sector_tap_cb(lv_event_t *e)
{
    sector_tapped((int)(intptr_t)lv_event_get_user_data(e));
}

/*
 * The moment a finger landed, from whichever layer took the press.
 *
 * Registered on the block of words and on the polar layer, because either can be the object
 * under the finger and the panel reports no touch-down of its own to the application. The
 * stamp is not kept per sector: sector_tapped() is only ever reached for the sector whose
 * press this is — the release resolves the wedge under the finger again, and for a tap that
 * is the same wedge — so one stamp answers the one question the interval asks, which is when
 * the tap that is being resolved began.
 */
static void press_stamp_cb(lv_event_t *e)
{
    (void)e;

    s_press_ms = now_ms();
    s_press_valid = true;
}

/*
 * Selecting a sector, from wherever the tap arrived.
 *
 * There are two ways in — the text block's own touch area, which is a hand-sized
 * target centred on the words, and the polar layer below it, which turns any other
 * tap inside the wedge into the same thing. Both come through here, so they cannot
 * drift apart.
 */
static void sector_activate(int idx, bool toggle_macro)
{
    const ui_page_t *p = page();

    if (!s_ready || swipe_just_happened()) {
        return;
    }
    if (idx < 0 || idx >= p->knob_count) {
        return;
    }

    select_sector(idx);

    if (toggle_macro) {
        const synth_param_t id = p->knobs[idx].param;

        /*
         * A setting never joins the macro. The macro is about the SOUND, and a setting is
         * not part of the sound — it is where a write goes, as the engine's own comment
         * puts it — so riding the knob that happens to sit beside it would drag the
         * backlight or the ring along with the timbre. The settings are deliberately the
         * last entries in the enum, and SYNTH_PARAM_PATCH_COUNT is the line between them.
         */
        if ((int)id >= SYNTH_PARAM_PATCH_COUNT) {
            ESP_LOGI(TAG, "macro: %s is a setting, not part of the sound",
                     p->knobs[idx].sector);
            return;
        }

        s_macro[id] = !s_macro[id];
        refresh_macro();

        ESP_LOGI(TAG, "macro %s %s (%d)",
                 s_macro[id] ? "add" : "remove", p->knobs[idx].sector, macro_count());
    }
}

#if CONFIG_OBOD_SCREENSHOTS
/*
 * The macro, for the screenshot walk only: the long press's own path and the double tap's own
 * path, so that the frame shows the mark the interface really puts on a member and not a mark
 * drawn for the picture. macro_count() is read back by the walk before and after, which is how
 * it can say it left the instrument with no macro at all.
 */
void synth_ui_macro_toggle(int knob)
{
    sector_activate(knob, true);
}

void synth_ui_macro_invert(int knob)
{
    sector_invert(knob);
}

int synth_ui_macro_count(void)
{
    return macro_count();
}
#endif

/*
 * Has the hand moved far enough that this press is a drag and not a long press?
 *
 * Asked from the long press itself, not from the poll: LVGL sends LONG_PRESSED from its own
 * 400 ms clock, in the same frame the finger is read, and a poll up to 15 ms behind would let
 * the macro toggle before the cancel lands. The distance is measured from where the press
 * really began, and 5 px is enough: a finger that has travelled that far is being carried
 * somewhere, while a hand at rest stays inside it.
 */
static bool finger_travelled(void)
{
    if (!s_press_point_valid) {
        return false;
    }

    lv_indev_t *indev = lv_indev_active();
    if (indev == NULL) {
        return false;
    }

    lv_point_t p;
    lv_indev_get_point(indev, &p);

    lv_coord_t dx = p.x - s_press_x;
    lv_coord_t dy = p.y - s_press_y;
    if (dx < 0) {
        dx = -dx;
    }
    if (dy < 0) {
        dy = -dy;
    }

    return dx >= LONG_PRESS_SLOP_PX || dy >= LONG_PRESS_SLOP_PX;
}

/*
 * Long press: select, and toggle membership in the macro.
 *
 * Registered for LV_EVENT_LONG_PRESSED only. LVGL also emits
 * LONG_PRESSED_REPEAT every 100 ms for as long as the finger stays down, and
 * handling that would flip membership ten times a second.
 */
static void sector_long_cb(lv_event_t *e)
{
    if (!s_ready || swipe_just_happened() || finger_travelled()) {
        return;
    }
    sector_activate((int)(intptr_t)lv_event_get_user_data(e), true);
}

/*
 * The rest of the wedge.
 *
 * A tap on the text block used to be the ONLY way to select a sector: the rest of
 * the wedge — the arc, and the space between the arc and the words, which is most of
 * what a sector looks like — did nothing at all. On a radial control the wedge IS
 * the button, so this layer makes it one.
 *
 * The regions cannot be ordinary widgets. Four quadrants share a single centre, so
 * their bounding boxes are the same square, and an lv_arc's hit test is its whole
 * 352x352 box — four of those would swallow every tap on the screen. So there is one
 * transparent layer under the text and it answers in polar coordinates: turn the
 * touch point into an angle and a radius, reject the hub and the corners outside the
 * rim, then look the angle up in the SAME span table the arcs were drawn from, so
 * the target cannot drift away from the picture.
 */
static int sector_at_angle(int deg)
{
    const ui_page_t *p = page();
    const rim_t rim = page_rim();

    /* The same clamp as layout_sectors(), from the same length: what can be tapped is
     * what was drawn, whatever the rim turned out to hold. */
    const int n = (p->knob_count < rim.count) ? p->knob_count : rim.count;

    for (int i = 0; i < n; i++) {
        int s = rim.spans[i].start;
        int e = rim.spans[i].end;
        if (e <= s) {
            e += 360;               /* the span crosses 3 o'clock */
        }
        int a = deg;
        if (a < s) {
            a += 360;
        }
        if (a < e) {
            return i;
        }
    }
    return 0;
}

static bool sector_under_finger(uint8_t *out)
{
    const ui_page_t *p = page();

    if (s_rim_hit == NULL || s_nav_open || p->knob_count < 1) {
        return false;
    }

    lv_indev_t *indev = lv_indev_active();
    if (indev == NULL) {
        return false;
    }

    lv_point_t pt;
    lv_indev_get_point(indev, &pt);

    lv_area_t a;
    lv_obj_get_coords(s_rim_hit, &a);
    const int32_t dx = pt.x - (a.x1 + a.x2) / 2;
    const int32_t dy = pt.y - (a.y1 + a.y2) / 2;

    /* Squared distance: the common answer is "outside", and it needs no root. */
    const int32_t d2 = dx * dx + dy * dy;
    if (d2 < (int32_t)RIM_HIT_INNER * RIM_HIT_INNER ||
        d2 > (int32_t)RIM_HIT_OUTER * RIM_HIT_OUTER) {
        return false;
    }

    /* LVGL measures angles the same way this does — zero at 3 o'clock, clockwise —
     * and the screen's Y axis already points down, so atan2 needs no correction. */
    int deg = (int)(atan2f((float)dy, (float)dx) * 57.29578f);
    if (deg < 0) {
        deg += 360;
    }

    const int idx = sector_at_angle(deg);
    if (idx < 0 || idx >= p->knob_count || s_sector_arc[idx] == NULL) {
        return false;
    }

    /* Visibility is not asked: a sector's arc is never shown any more, and what a tap may
     * land on is bounded by the page's own count, which is the check just above. */

    *out = (uint8_t)idx;
    return true;
}

/*
 * The middle of the dial, as a tap target.
 *
 * The sector lookup rejects everything inside RIM_HIT_INNER, which is what made a tap in the
 * middle inert; this is the same test the other way round, so the two cannot overlap: a tap
 * is either on a sector or inside the rim, never both. A tap in the corners of the square
 * screen is outside RIM_HIT_OUTER and stays as inert as it was.
 *
 * A tap needs a target a finger can find, and the inside of the rim is what reads as the
 * middle of the page: that is the radius, rather than any tighter circle.
 */
static bool middle_under_finger(void)
{
    if (s_rim_hit == NULL || s_nav_open || s_transport_open) {
        return false;
    }

    lv_indev_t *indev = lv_indev_active();
    if (indev == NULL) {
        return false;
    }

    lv_point_t pt;
    lv_indev_get_point(indev, &pt);

    lv_area_t a;
    lv_obj_get_coords(s_rim_hit, &a);
    const int32_t dx = pt.x - (a.x1 + a.x2) / 2;
    const int32_t dy = pt.y - (a.y1 + a.y2) / 2;

    return (dx * dx + dy * dy) < (int32_t)RIM_HIT_INNER * RIM_HIT_INNER;
}

static void rim_tap_cb(lv_event_t *e)
{
    uint8_t idx;

    (void)e;
    if (sector_under_finger(&idx)) {
        sector_tapped((int)idx);
        return;
    }

    /* Nothing under the finger is a sector, so the only thing left a tap can mean here is a
     * new value for the parameter the knob is standing on. */
    if (middle_under_finger()) {
        sector_draw();
    }
}

static void rim_long_cb(lv_event_t *e)
{
    uint8_t idx;

    (void)e;

    /*
     * The transport screen is modal, and the layer on top of the page cannot make it so
     * on its own: the encoder is delivered to the object that has FOCUS, not to the
     * topmost one, so the wheel and this long press both arrive here regardless of what
     * is drawn over the page. See proxy_changed_cb() for the wheel and
     * screen_gesture_cb() for the swipes; this is the long press.
     */
    if (s_transport_open) {
        return;
    }

    /* A press that has already started to drag is not a long press: it must not put the
     * sector under the hand into the macro on its way past. See finger_travelled(). */
    if (swipe_just_happened() || finger_travelled()) {
        return;
    }

    /*
     * The middle is a dead zone, and deliberately so. The sector lookup rejects everything
     * inside RIM_HIT_INNER, so a long press there has nothing to answer; it cannot steal a
     * macro long press either, because the sector touch areas sit above this layer and
     * handle their own long press with their own index, and this circle is 16 px inside the
     * radius at which any of them begins. So what is left here is exactly the region no
     * sector and no hand ever claimed, and it takes no action rather than a surprising one.
     */

    if (sector_under_finger(&idx)) {
        sector_activate((int)idx, true);
    }
}

/*
 * Horizontal swipe turns the page.
 *
 * The event is sent with the indev as its parameter, so it is read from there
 * rather than through lv_event_get_indev(), which depends on how the event was
 * pushed.
 *
 * lv_indev_get_gesture_dir() is used instead of the LV_EVENT_GESTURE_LEFT/RIGHT
 * codes because those live behind LV_USE_GESTURE_RECOGNITION, while the
 * direction query is always available.
 */
/*
 * The hand that made the gesture, for the length of the turn it asked for.
 *
 * A flick crosses the screen in a fifth of a second and a deliberate swipe takes three or
 * four times that, and at any fixed duration one of the two is wrong: fast enough for the
 * flick is unreadably quick for the draw, and slow enough for the draw is a wait after a
 * flick. So the press is remembered and the turn is given the time the page would need to
 * travel its 360 px at the speed the finger was already moving.
 *
 * The floor is PAGE_SLIDE_MS: sooner than that is a cut and not a turn, whatever the hand
 * did. The ceiling is where the wait becomes the thing being noticed.
 */

static void screen_pressed_cb(lv_event_t *e)
{
    (void)e;
    lv_indev_t *indev = lv_indev_get_act();
    if (indev == NULL) {
        return;
    }

    lv_point_t p;
    lv_indev_get_point(indev, &p);

    s_press_us = esp_timer_get_time();
    s_press_x = p.x;
    s_press_y = p.y;
    s_press_point_valid = true;
    s_finger_moved = false;
    s_contact_seen = false;

    /*
     * The first poll measures the hand from here, not from itself.
     *
     * It used to start its own clock at the poll's first point, so that point's speed was
     * always zero — and a fast hand could already be past DRAG_START_PX by then, which sent
     * it down the drag path with no speed reading at all. The press is the real start of the
     * movement, and it is also the last point at which the hand was certainly still.
     */
    s_touch_x_last = p.x;
    s_touch_y_last = p.y;
    s_touch_us_last = s_press_us;

    /*
     * Arm the turn under the finger. The press is the only moment that knows whether a
     * drag is allowed at all: an overlay owns the glass while it is open, the preset page
     * spends horizontal travel on its list, and a turn already in flight owns the pictures.
     */
    s_drag_x0 = p.x;
    s_drag_vx = 0.0f;
    s_drag_travel = 0;
    /* A turn taken by this finger has been answered already; a new finger starts clean.
     * Without this a drag that stopped short of LVGL's own gesture limit would leave the
     * flag set and eat the NEXT swipe. */
    s_drag_ate_gesture = false;
    s_drag_carry = false;
    s_sheet_carry = false;
    s_drag_watch = s_ready && !s_sliding && !s_nav_open && !s_transport_open
                   && !drawer_in_flight() && s_page != PAGE_PRESET;

    /*
     * The page as it stands is NOT photographed here. A press is usually a tap, and a full
     * render for every touch was the largest cost between the finger and anything happening:
     * 30.7 ms and 253 KB in PSRAM, paid before the hand had moved at all. The picture is
     * taken by the poll on the first movement instead — see the s_press_snap note — so a tap
     * costs nothing and a drag still has the picture before its 12 px threshold. Whatever a
     * previous finger left behind goes now.
     */
    press_snap_drop();
}

/* The finger that took the swipe, for the click that ends it — see the tuning block above. */
static void swipe_was_taken(void)
{
    s_swipe_contact = bsp_touch_contact();
    /* And it ends any tap pair: a drag between two taps must not make the second one a
     * double tap of the first — the hand was carrying a page, not tapping a sector. */
    s_tap_idx = -1;
}

static void screen_gesture_cb(lv_event_t *e)
{
    if (!s_ready) {
        return;
    }

    lv_indev_t *indev = (lv_indev_t *)lv_event_get_param(e);
    if (indev == NULL) {
        return;
    }

    /*
     * A gesture is LVGL saying this finger is a swipe, and it says it part-way through the
     * press, not on the release: the threshold is a distance, and it is crossed while the
     * hand is still on the glass. So whichever of the two got there first owns the finger —
     * the drag, if it is already following, or this handler. Clearing the watch flags here
     * is what stops the other one from starting a second movement on the same hand: the
     * measured failure was a fast swipe opening a drawer by gesture and then being dragged
     * and put back by the poll, which is why it "sometimes did nothing".
     */
    s_drag_watch = false;
    s_sheet_watch = false;

    /*
     * A turn the hand has already carried is this gesture's answer: the drag is following,
     * and a second turn must not be taken from the same swipe.
     *
     * Its verdict is remembered rather than acted on here, because here the finger is still
     * down and a release now would finish the turn from under it. The release that ends the
     * finger reads the flag, which is what a flick ending inside a build needs: building a
     * turn or a drawer stalls the poll for one or two renders, and a release inside that
     * stall carries neither distance nor speed.
     */
    if (s_drag_ate_gesture) {
        s_drag_ate_gesture = false;

        if (s_drag_on) {
            const lv_dir_t dir = lv_indev_get_gesture_dir(indev);
            if ((dir == LV_DIR_LEFT && s_slide_dir > 0)
                || (dir == LV_DIR_RIGHT && s_slide_dir < 0)) {
                s_drag_carry = true;
            }
        }

        swipe_was_taken();
        return;
    }

    if (s_sheet_ate_gesture) {
        s_sheet_ate_gesture = false;

        if (s_sheet_on) {
            const lv_dir_t dir = lv_indev_get_gesture_dir(indev);
            const bool up = (dir == LV_DIR_TOP);
            const bool down = (dir == LV_DIR_BOTTOM);
            /* Which way the hand has to go for this drawer's travel to be the one it means:
             * the transport comes in from below, the map from above. */
            const bool toward = s_sheet_opening
                                    ? (s_sheet_nav ? down : up)
                                    : (s_sheet_nav ? up : down);
            if (toward) {
                s_sheet_carry = true;
                s_sheet_carry_dir = s_sheet_opening ? (s_sheet_nav ? 1 : -1)
                                                    : (s_sheet_nav ? -1 : 1);
            }
        }

        swipe_was_taken();
        return;
    }

    const lv_dir_t dir = lv_indev_get_gesture_dir(indev);

    if (s_transport_open) {
        /* The transport is on top, so the only gesture it takes is the one that
         * leaves it — the reverse of the one that opened it. */
        if (dir == LV_DIR_BOTTOM) {
            transport_close();
            swipe_was_taken();
        }
        return;
    }

    if (s_nav_open) {
        /* The map is on top, so the only gesture it takes is the one that closes
         * it. A horizontal swipe here would turn a page the user cannot see. */
        if (dir == LV_DIR_TOP) {
            nav_close();
            swipe_was_taken();
        }
        return;
    }

    /*
     * Up opens the transport, down opens the section map.
     *
     * Up was the one direction the instrument had left: left and right turn the page,
     * down is the map, a tap chooses a section and a long press works the macros. The
     * transport sat on the map before this and covered the chips it hung over, which is
     * why it moved to a screen of its own — see transport_open().
     */
    if (dir == LV_DIR_TOP) {
        transport_open();
        swipe_was_taken();
        return;
    }

    if (dir == LV_DIR_BOTTOM) {
        nav_open();
        swipe_was_taken();
        return;
    }

    if (dir != LV_DIR_LEFT && dir != LV_DIR_RIGHT) {
        return;
    }

    /*
     * On the preset page a horizontal swipe walks the list by eight rows — the fast
     * way down a store of 128 — and only turns the page when the list is already at
     * that end of itself. See preset_swipe(), which is the whole of that rule.
     */
    if (s_page == PAGE_PRESET) {
        const int rows = (dir == LV_DIR_LEFT) ? PRESET_SWIPE : -PRESET_SWIPE;
        if (preset_swipe(rows)) {
            swipe_was_taken();
            return;
        }
    }

    /*
     * How fast the hand was moving, which is how long the turn gets.
     *
     * The distance is taken along the axis the gesture went in, from where the finger went
     * down to where it is now, and the page is then given the time it would need to cover
     * its own 360 px at that speed. A press that never registered leaves the duration
     * alone rather than dividing by whatever the variables happen to hold.
     */
    lv_point_t cur;
    lv_indev_get_point(indev, &cur);

    const int64_t held_us = esp_timer_get_time() - s_press_us;
    if (s_press_us != 0 && held_us > 0) {
        const lv_coord_t dx = (cur.x > s_press_x) ? (cur.x - s_press_x) : (s_press_x - cur.x);
        const lv_coord_t dy = (cur.y > s_press_y) ? (cur.y - s_press_y) : (s_press_y - cur.y);
        const lv_coord_t moved = (dx >= dy) ? dx : dy;

        if (moved > 0) {
            /* px per millisecond, then the same length rule the early flick uses. */
            s_slide_ms = slide_ms_for_speed((float)moved * 1000.0f / (float)held_us);
        }
    }

    /* The direction is passed in rather than derived from the index, so that
     * wrapping from the last page to the first still travels the way the finger
     * went instead of rewinding through the whole set.
     *
     * It is +1 or -1 and not the lv_dir_t itself: the two codes are bit flags (1 and 2),
     * and s_slide_dir multiplies the width by this number to place the arriving page. A
     * left swipe is +1, so the page arrives from the right; a right swipe is -1, so it
     * arrives from the left. Passing the flag put BOTH directions' pictures off the right
     * edge, which is half a width of nothing arriving on a right swipe. */
    const int step = (dir == LV_DIR_LEFT) ? 1 : -1;
    turn_to((int)s_page + step, step);

    swipe_was_taken();
}

/* -------------------------------------------------------------------------- */
/* The preset page                                                            */
/* -------------------------------------------------------------------------- */
/*
 * The store of sounds, as a list of names.
 *
 * This is the first page that is not a set of values, and the difference is worth
 * stating because every other page is built the other way round. Each of those shows
 * two, three or four controls, every control has a rim, a name, a number and a knob
 * that walks it, and the curtain is a picture of those pages. A preset is not a
 * value: it is a WHOLE SOUND — every parameter at once, under a name — and the only
 * things to do with one are to load it and to write the running sound over it. A rim
 * of four values here would be a lie about what the page holds, so the page has no
 * knob count at all (see PAGES[]), and the wheel drives the LIST instead.
 *
 * The middle of the screen is the list: a window of PRESET_ROWS rows with the
 * selected one in the middle. The store holds up to 128 slots and the screen holds
 * seven names at a size worth reading, so the selection is always the middle row and
 * the rows move under it — the only arrangement in which the eye never has to find
 * the marker again.
 *
 * Seven at a 27 px pitch is what the column honestly holds, and what bounds it is the
 * chips below: they are sized for a fingertip first (48 px each), the list takes what
 * is left, and the page's own name at -150 has room to spare. The outermost row's box
 * ends 94.5 px from the middle and its ink at 88.5, and the chips' top edge is at 90 —
 * 1.5 px of air under that ink and no pitch left to give. So the column is at its
 * ceiling — seven rows and no pretence that 128 presets are on one screen: the wheel
 * and the swipe are how you cross the store, and the list is how you see where you are
 * in it. Adjacent row boxes touch for the same reason, which costs nothing because only
 * the selected one is filled.
 *
 * The chips are where they are because of the rim and not the list: every corner of
 * every one of them stays inside the arc's inner stroke at 162 px, the tightest being
 * SAVE's outer corner at 159.5. That is the whole reason the bottom two are 48 px and
 * not taller: below this the circle simply runs out of width.
 *
 * The three things you can do are three chips, and where each one sits says what it
 * acts on:
 *
 *   LOAD    beside the selected row, because it acts on that row. It is hidden when
 *           the store is empty or the selection stands on the free target, because in
 *           both cases there is nothing to load.
 *   SAVE    under the list, because it acts on the SOUND rather than on a row: it
 *           writes the running parameters into the selected slot, and on the free
 *           target — where there is no selected sound — it appends a new one and the
 *           selection follows it. That is why SAVE is live when the list is empty and
 *           on the free target, and LOAD is not: those are exactly where presets come
 *           from.
 *   RND     beside SAVE, and it is the only two-mode control on the instrument: a
 *           short press redraws the timbre, a long press redraws the timbre and the
 *           structure. The two parameter lists below are the whole of that difference.
 *
 * The list is the store PLUS ONE FREE TARGET, and that is a sound-library requirement
 * rather than a nicety: with the list identified with the contents, a store holding one
 * preset had a wheel range of zero and a single reachable row, so SAVE could only ever
 * overwrite it and a second preset could never exist. The free target is the slot just
 * past the last stored one, and it is drawn as a row — its number in the normal ink,
 * the word EMPTY in the dimmest ink the page has — because a slot you can write into
 * has to be visible. Numbering stays dense, so an arbitrary gap in the middle of the
 * store is not reachable; that would take a "used" bitmap in the store.
 *
 * Nothing loads a preset except the LOAD chip. Turning the wheel moves the selection
 * and plays nothing — on a page whose whole purpose is to choose between 128 sounds,
 * an instrument that barked a new one at every detent would be unusable — and a
 * horizontal swipe moves it eight rows at a time and equally silently. A swipe is
 * consumed only while the list can still move that way: at either end the same swipe
 * turns the page again, so the carousel has no page that cannot be left, and the map is
 * not the only way off this one.
 *
 * The dirty mark is one parameter changed since the last load or save. The UI is the
 * only thing on this device that writes a parameter — the sequencer and the audio
 * task read them — so a flag owned here is exact, and it is set in write_param(),
 * which is the single door that every knob, every macro member and the randomiser
 * comes through. Load and save clear it, because after either of them the store and
 * the sound agree.
 */

/*
 * SAVE blinks while the sound has moved since the last load or save.
 *
 * The chip is the only thing on the page that says the store and the sound disagree, and
 * a still chip would be missed among two buttons that never change. The dot that used to
 * carry this mark is gone: it was a second place to look for a state SAVE already owns,
 * and it never said what would put it out.
 *
 * What breathes is the chip's own opacity, not a colour of its own: the chip keeps the
 * page's surface and only its presence comes and goes. Not dirty, it is simply there.
 */
static void preset_blink(void)
{
    if (s_preset_save == NULL) {
        return;
    }

    if (!s_preset_dirty) {
        lv_obj_set_style_opa(s_preset_save, LV_OPA_COVER, LV_PART_MAIN);
        return;
    }

    const bool lit = ((s_tick / PRESET_BLINK_EVERY_N_TICKS) % 2) == 0;
    lv_obj_set_style_opa(s_preset_save, lit ? LV_OPA_COVER : LV_OPA_30, LV_PART_MAIN);
}

/* The last slot the list can reach: the free target past the end of the store, or the
 * last stored slot when the store is full and there is nowhere to append. Read by
 * preset_refresh(), preset_select() and preset_swipe() so that the wheel, the swipe
 * and the rows cannot disagree about where the list ends. */
static int preset_last(void)
{
    if (s_preset_count >= APP_PRESET_MAX) {
        return s_preset_count - 1;
    }

    return s_preset_count;
}

/*
 * Rebuild the window, and point the knob at the list.
 *
 * The proxy is re-ranged to the list's length so that one detent is one row. A
 * thousand-step arc for a list of 128 would be eight detents a row, and the
 * acceleration that makes a cutoff playable would jump the list by eight — a list is
 * discrete, and proxy_load() already treats a discrete parameter this way. With the
 * arc's range being the list, the two ends of the knob are the two ends of the list,
 * which is where the swipe takes over.
 *
 * Only called while this page is on screen: it owns the proxy, and re-pointing the
 * proxy from another page would rewrite what that page's knob is standing on.
 */
static void preset_refresh(void)
{
    if (s_preset == NULL || s_page != PAGE_PRESET) {
        return;
    }

    s_preset_count = app_settings_preset_count();

    /*
     * The list is NOT the contents of the store: it is the store plus one free target
     * past the end, and that slot is the whole reason a library can be built at all.
     * With the list identified with the contents, one stored preset meant a wheel range
     * of zero, one reachable row, and SAVE with nowhere to go but over it — the second
     * preset could never exist. The store has always supported the append: a slot at or
     * past the end is written as a new one, under a fresh name, and the slot used comes
     * back. So the wheel goes to the slot after the last stored one, and the row it
     * lands on says EMPTY.
     *
     * One free target and not all 128 free ones: turning past the end into forty empty
     * rows is a long walk to look at nothing, and this way the one row that can be
     * written is always the row just past the music. Numbering stays dense, so an
     * arbitrary gap in the middle of the store is not reachable — that would need a
     * "used" bitmap in the store, which is not wanted. A store at APP_PRESET_MAX has no
     * free target and simply ends.
     */
    const bool full = (s_preset_count >= APP_PRESET_MAX);

    /*
     * The list always has INIT at its head, so there is no such state as "no selection":
     * the clamp is against the head and the tail, and the head is INIT.
     */
    if (s_preset_sel < PRESET_SEL_INIT) {
        s_preset_sel = PRESET_SEL_INIT;
    } else if (s_preset_sel > preset_last()) {
        s_preset_sel = preset_last();
    }

    const bool on_free = (!full && s_preset_count > 0 && s_preset_sel == s_preset_count);
    const bool on_init = (s_preset_sel == PRESET_SEL_INIT);

    /*
     * There is no empty store on screen any more: INIT is a row and the free target past it
     * is a row, so the page always has something to stand on. The centred NO PRESETS line
     * stays in the build because a page built before the first refresh would otherwise be
     * blank, and it is never shown.
     *
     * LOAD goes away on the free target — that row is a slot to write, not a sound — and
     * SAVE goes away on INIT, which is not a slot at all and must not be overwritable.
     */
    lv_obj_set_hidden(s_preset_empty, true);
    lv_obj_set_hidden(s_preset_load, on_free);
    lv_obj_set_hidden(s_preset_save, on_init);

    char name[APP_PRESET_NAME_MAX];

    for (int r = 0; r < PRESET_ROWS; r++) {
        const int step = r - PRESET_ROWS / 2;
        const int slot = s_preset_sel + step;
        const bool init_row = (slot == PRESET_SEL_INIT);
        const bool used = (slot >= 0 && slot < s_preset_count);
        const bool free_slot = (!full && slot == s_preset_count);

        lv_obj_set_hidden(s_preset_row[r], !(init_row || used || free_slot));
        if (!(init_row || used || free_slot)) {
            continue;
        }

        /*
         * Two digits is what the store ever needs — 128 slots and numbered from one —
         * but the buffer is sized for the worst an int can print, because the compiler
         * cannot know the store's bound and a truncated slot number would be a lie
         * about which row you are standing on.
         */
        char number[12];
        if (init_row) {
            snprintf(number, sizeof(number), "%s", PRESET_INIT_NO);
        } else {
            snprintf(number, sizeof(number), "%02d", slot + 1);
        }
        lv_label_set_text(s_preset_no[r], number);

        /*
         * The name in the largest face it fits, or the word for a slot that has none.
         * The face is chosen by COUNT and not by measurement: the store's names are two
         * capitals each, and at eleven characters the widest of them — BURNT STONE — is
         * 126 px in the large face, which is exactly the column the row leaves before
         * LOAD. A longer name — ten of the store's twelve-character names, or anything the
         * store's API allows — drops to the smaller face rather than running into the
         * chip, where HOLLOW STONE is 100 px.
         */
        const char *text;
        if (init_row) {
            text = PRESET_INIT_TEXT;
        } else if (used) {
            text = app_settings_preset_name(slot, name, sizeof(name)) ? name : "";
        } else {
            text = PRESET_FREE_TEXT;
        }
        int n = 0;
        while (text[n] != '\0' && n <= PRESET_NAME_BIG) {
            n++;
        }
        lv_obj_set_style_text_font(s_preset_name[r],
                                   (n <= PRESET_NAME_BIG) ? &lv_font_anbscreen_20 : &lv_font_anbscreen_14,
                                   LV_PART_MAIN);
        lv_label_set_text(s_preset_name[r], text);

        /*
         * The falloff by distance from the middle. It is not decoration: on a list,
         * how far a row is from the selection IS the information, and on a page that
         * plays nothing when you turn the wheel it is the only sign that the wheel
         * moved at all.
         */
        lv_opa_t opa = PRESET_OPA_FAR;
        if (step == 0) {
            opa = PRESET_OPA_SEL;
        } else if (step == 1 || step == -1) {
            opa = PRESET_OPA_NEAR;
        }
        /* A free slot wears the dimmest ink the page has whatever its distance: EMPTY
         * is a statement that there is nothing here, not a name competing with the
         * names around it. Its NUMBER keeps the row's normal ink, because the number
         * is the slot SAVE would write into. */
        lv_obj_set_style_text_opa(s_preset_name[r],
                                  (used || init_row) ? opa : PRESET_OPA_FAR, LV_PART_MAIN);
        /* The slot number is the same ink one step further down: it is there to be
         * found, not to be read. */
        lv_obj_set_style_text_opa(s_preset_no[r], (lv_opa_t)(opa * 2 / 3), LV_PART_MAIN);

        /* And the selected row is filled as well as brightened, the way a selected
         * sector is: two marks that answer the same question cannot hide each other. */
        lv_obj_set_style_bg_color(s_preset_row[r],
                                  lv_color_hex(tint(GROUP_COLOR[GRP_VIEW].fill, TINT_SEL)),
                                  LV_PART_MAIN);
        lv_obj_set_style_bg_opa(s_preset_row[r],
                                (step == 0) ? LV_OPA_COVER : LV_OPA_TRANSP,
                                LV_PART_MAIN);
    }

    s_discrete = true;
    /*
     * The arc's range is the LIST, and the list is INIT plus the store plus the one free
     * target, so its last index is preset_last() + 1. The selection is a slot number with
     * INIT at -1, which is exactly the arc's value minus one; that is the only place the
     * offset is applied on the way in, and preset_select() takes it off again.
     */
    s_steps = preset_last() + 1;

    const int32_t at = s_preset_sel - PRESET_SEL_INIT;
    /* The wheel belongs to the transport curtain while it is up, and the proxy's range is part of
     * that handover: a refresh that ran underneath would put the range back to the number of
     * stored sounds, and the tempo would stop at the end of the list again. The list itself is
     * already redrawn above, so nothing is lost by stopping here. */
    if (s_transport_open) {
        return;
    }
    s_syncing = true;
    lv_arc_set_range(s_proxy, 0, s_steps);
    lv_arc_set_value(s_proxy, at);
    s_proxy_value = lv_arc_get_value(s_proxy);
    s_arc_last = s_proxy_value;
    s_syncing = false;
}

/*
 * Move the selection, silently.
 *
 * Selecting is not loading. The sound does not change until LOAD, so walking the
 * whole store costs nothing but the walk.
 */
static void preset_select(int slot)
{
    if (slot < PRESET_SEL_INIT) {
        slot = PRESET_SEL_INIT;
    } else if (slot > preset_last()) {
        slot = preset_last();
    }

    if (slot == s_preset_sel) {
        return;
    }

    s_preset_sel = slot;
    preset_refresh();
}

/*
 * Which of the page's receivers a touch belongs to.
 *
 * lv_indev_search_obj() walks children in creation order and stops at the first hit, so
 * it has no notion of distance: the 160 px row would win a point beside LOAD merely by
 * being created first, and the topmost chip would win even when the finger is already
 * past it. The page therefore uses LVGL's advanced hit test — LV_OBJ_FLAG_ADV_HITTEST
 * plus LV_EVENT_HIT_TEST on every receiver — and all of them run the same decision:
 *
 *   1. the drawn box of a chip always belongs to that chip. The bottom row's box
 *      reaches five pixel rows under SAVE and RND (the row ends at +94, the chips
 *      start at +90), and without this rule the row's centre — 9.5 px from the chip's
 *      inner top corner against the chip's own 42.6 — would hand a visible chip touch
 *      to the list.
 *   2. the LOAD chip's whole field belongs to LOAD, including the part of it that lies
 *      over the list's right end; that band is the miss this page is fixing.
 *   3. a row's drawn box belongs to the row, and the row does nothing with it: by the
 *      owner's rule the list is not a control, so a tap on a row selects nothing and
 *      performs no action. The box is claimed only so that no chip can take it. Without
 *      this rule SAVE and RND would take the bottom row's own text: on that text's line,
 *      45.5 px right of the row's centre, RND's centre is 32.7 px away while the row's
 *      own is 45.5, so the nearest-centre rule alone would randomise the patch on a tap
 *      that visibly landed on a preset name. The chip boxes still win inside
 *      their own rectangles (rule 1), so their drawn edges are untouched.
 *   4. everything left is blank overlap, and there the nearest centre wins, measured
 *      from the point to the centre of the receiver's box. An exact tie belongs to
 *      nobody, so the tap falls through to the page and does nothing rather than
 *      choosing by drawing order.
 *
 * The page's numbers make the overlaps safe in both directions: in LOAD's left band
 * the button's centre is 32.5 px away against the row's 82.5, and the bottom pair's
 * areas leave the one-pixel column at x = 179 and x = 180 between them, where their
 * centres are 88 px apart.
 */
static lv_obj_t *preset_receiver(int i)
{
    if (i < PRESET_ROWS) {
        return s_preset_row[i];
    }

    switch (i - PRESET_ROWS) {
    case 0:
        return s_preset_load;
    case 1:
        return s_preset_save;
    default:
        return s_preset_random;
    }
}

static lv_obj_t *preset_chip_box_at(const lv_point_t *p)
{
    lv_obj_t *chips[] = {s_preset_load, s_preset_save, s_preset_random};

    for (int i = 0; i < (int)(sizeof(chips) / sizeof(chips[0])); i++) {
        if (chips[i] == NULL || lv_obj_is_hidden(chips[i])) {
            continue;
        }

        lv_area_t a;
        lv_obj_get_coords(chips[i], &a);
        if (lv_area_is_point_on(&a, p, 0)) {
            return chips[i];
        }
    }

    return NULL;
}

static int32_t preset_receiver_dist2(lv_obj_t *o, const lv_point_t *p)
{
    lv_area_t a;
    lv_obj_get_coords(o, &a);

    const int32_t cx = (a.x1 + a.x2) / 2;
    const int32_t cy = (a.y1 + a.y2) / 2;
    const int32_t dx = p->x - cx;
    const int32_t dy = p->y - cy;

    return dx * dx + dy * dy;
}

static lv_obj_t *preset_row_box_at(const lv_point_t *p)
{
    for (int i = 0; i < PRESET_ROWS; i++) {
        if (s_preset_row[i] == NULL || lv_obj_is_hidden(s_preset_row[i])) {
            continue;
        }

        lv_area_t a;
        lv_obj_get_coords(s_preset_row[i], &a);
        if (lv_area_is_point_on(&a, p, 0)) {
            return s_preset_row[i];
        }
    }

    return NULL;
}

static void preset_ext_hit_cb(lv_event_t *e)
{
    lv_obj_t *self = lv_event_get_current_target(e);
    lv_hit_test_info_t *info = lv_event_get_hit_test_info(e);

    if (self == NULL || info == NULL) {
        return;
    }

    /* The event carries the point in this object's own coordinates; the table of
     * receivers is in screen coordinates. Nothing here is transformed today, but the
     * conversion is the one line that keeps that from being an assumption. */
    lv_point_t p = *info->point;
    lv_obj_transform_point(self, &p, LV_OBJ_POINT_TRANSFORM_FLAG_RECURSIVE);

    lv_obj_t *chip = preset_chip_box_at(&p);
    if (chip != NULL) {
        info->res = (chip == self);
        return;
    }

    /*
     * LOAD keeps the whole field it was given, even the part over the list's right
     * end; a row keeps its own box, even where SAVE/RND's upward pad reaches into it.
     * Both are drawn targets, so they are settled before any distance is measured.
     */
    if (s_preset_load != NULL && !lv_obj_is_hidden(s_preset_load)) {
        lv_area_t a;
        lv_obj_get_click_area(s_preset_load, &a);
        if (lv_area_is_point_on(&a, &p, 0)) {
            info->res = (s_preset_load == self);
            return;
        }
    }

    lv_obj_t *row = preset_row_box_at(&p);
    if (row != NULL) {
        info->res = (row == self);
        return;
    }

    lv_obj_t *winner = NULL;
    int32_t best = INT32_MAX;
    int32_t nearest = 0;

    for (int i = 0; i < PRESET_ROWS + 3; i++) {
        lv_obj_t *o = preset_receiver(i);
        if (o == NULL || lv_obj_is_hidden(o)) {
            continue;
        }

        lv_area_t a;
        lv_obj_get_click_area(o, &a);
        if (!lv_area_is_point_on(&a, &p, 0)) {
            continue;
        }

        const int32_t d = preset_receiver_dist2(o, &p);
        if (d < best) {
            best = d;
            winner = o;
            nearest = 1;
        } else if (d == best) {
            nearest++;
        }
    }

    info->res = (nearest == 1 && winner == self);
}

/*
 * A horizontal swipe walks PRESET_SWIPE rows, which is the fast way down a store of
 * 128 rather than eight turns of the wheel.
 *
 * It answers whether it took the gesture. At the first row a swipe back, and at the
 * last a swipe on, are the page turn again — that is the whole reason this is a
 * question rather than an action. The alternative, this page swallowing every
 * horizontal swipe, would make it a place you could only leave through the map.
 */
static bool preset_swipe(int delta)
{
    const int was = s_preset_sel;
    int slot = s_preset_sel + delta;
    if (slot < PRESET_SEL_INIT) {
        slot = PRESET_SEL_INIT;
    } else if (slot > preset_last()) {
        slot = preset_last();
    }

    if (slot == was) {
        return false;
    }

    s_preset_sel = slot;
    preset_refresh();
    return true;
}

static void preset_load_cb(lv_event_t *e)
{
    (void)e;

    /* The chip is hidden on the free target, so this is a second line rather than the
     * first: a load of a slot that holds nothing logs a failure and does nothing, which is
     * worse than not offering it. INIT is not a slot and IS loadable — it is the factory
     * sound, which is the whole reason the row exists. */
    if (s_preset_sel >= s_preset_count || swipe_just_happened()) {
        return;
    }

    const int n = (s_preset_sel == PRESET_SEL_INIT) ? synth_app_patch_factory()
                                                   : synth_app_preset_load(s_preset_sel);
    if (n <= 0) {
        ESP_LOGW(TAG, "preset %d did not load", s_preset_sel);
        return;
    }

    if (s_preset_sel == PRESET_SEL_INIT) {
        ESP_LOGI(TAG, "INIT loaded: %d parameters at their factory values", n);
        diag_record(DIAG_EVT_PRESET, 0, 3);
    } else {
        ESP_LOGI(TAG, "preset %d loaded: %d parameters", s_preset_sel, n);
        diag_record(DIAG_EVT_PRESET, s_preset_sel, 1);
    }

    /*
     * Every level the load carried is an outside hand on that parameter, and a load never
     * passes through write_param() — it goes straight into the app. Without this a part
     * muted before the load would keep its flag while the loaded level sounded, and the
     * next double tap would push the old remembered value over a preset the player never
     * asked to change. See mute_clear_all().
     */
    mute_clear_all();

    /*
     * Loaded is not dirty: the sound is now exactly what the store holds. Nothing is
     * redrawn either — this page has no sector values to correct, the ring reads the
     * live parameters on its own beat, and every other page refreshes its numbers
     * when it is entered.
     */
    s_preset_dirty = false;

    /*
     * The remembered patch follows the load, and that is a different question from the
     * flag above. The flag says "the sound no longer matches this preset slot"; the patch is the
     * sound the instrument comes back to. This call is here because a load never passes
     * through write_param() — it goes straight into the app — and without it a preset that
     * was loaded and then switched off at the mains came back as whatever the last knob had
     * left behind, which is the complaint this whole path was rebuilt for.
     */
    patch_note();

    /* The load carried a tempo of its own, and it is now where the clock stands. Noted here for
     * the same reason the patch is: this path never reaches write_param(). */
    app_settings_tempo_note(synth_app_get_param(SYNTH_PARAM_SEQ_TEMPO));
}

static void preset_save_cb(lv_event_t *e)
{
    (void)e;

    if (swipe_just_happened()) {
        return;
    }

    /* INIT is not a slot: it cannot be written over, and the chip is hidden while it is
     * selected. This is the second line, not the first, for a hand on the API. */
    if (s_preset_sel == PRESET_SEL_INIT) {
        return;
    }

    /*
     * A slot past the end means "there is no slot to write over": it appends, and hands
     * back the slot it used. The selection then follows it, so the row you just made is
     * the row you are standing on.
     */
    const int slot = synth_app_preset_save(s_preset_sel);
    if (slot < 0) {
        ESP_LOGW(TAG, "could not save a preset");
        return;
    }

    ESP_LOGI(TAG, "preset %d saved", slot);
    diag_record(DIAG_EVT_PRESET, slot, 2);

    s_preset_sel = slot;
    s_preset_dirty = false;
    /* Every save draws a new name, so the window has to be read back. */
    preset_refresh();
}

/*
 * What a random draw is allowed to touch.
 *
 * Both modes leave the same things alone, and the list is short because the reasons
 * are the same. The output level: a random master level in headphones is not a
 * surprise, it is an injury. The four layer sends and the percussion's: a reverb that
 * opens by itself is the one change that cannot be undone by ear, on an instrument
 * whose delays and tails are still sounding while you look for the knob. The tempo: a
 * random tempo breaks the one thing this instrument promises about time, which is that
 * a step is a whole number of audio blocks.
 *
 * The four part levels go with them — the drone's three registers, the lead's, the
 * percussion's — because a part level is the mix, and a random mix is the same injury
 * as a random master. The note length and the lead's glide go with the tempo, for the
 * same reason: they are how the part is played rather than how it sounds. All of those
 * are still on their pages, and loud in the ears of anyone who turns them.
 *
 * The draw itself is the app's, not the interface's: it needs the scales, the drum's
 * pitch range and the rule that maps a knob to a frequency, and all three live there.
 * What stays here is the gesture — the slide, the log line and the dirty flag. See
 * synth_app_random_draw() for what a draw chooses and why, and tools/random-model.js
 * for the hundred thousand draws that say it works.
 *
 * RND DEL travels with the call rather than being read before it: the delay's time
 * section is the one part of the timbre a player can take out of a draw, and with the
 * switch off neither half of it moves.
 */
static void preset_randomise(bool structural)
{
    /* The draw is a batch of new values like any other, so it arrives the same way a preset
     * does: as a slide, if one is configured. See synth_app_slide_begin(). */
    synth_app_slide_begin();

    const bool draw_delay_time = app_settings_get(APP_SET_RND_DELAY) != 0;
    const int drawn = synth_app_random_draw(structural ? 1 : 0, draw_delay_time ? 1 : 0);
    ESP_LOGI(TAG, "random draw: %d parameters, %s", drawn,
             structural ? "structure" : "timbre");
    /*
     * Dirty, and the selection does not move. A draw is a new sound in the slot you
     * are standing on, not a new preset: stepping the list would make the store look
     * as if it had changed when all that changed is the sound — and it would throw
     * away the name of the preset you would be overwriting if you then pressed SAVE.
     */
    s_preset_dirty = true;
}

/*
 * One callback for both modes of the chip.
 *
 * The short draw is on SHORT_CLICKED and not on CLICKED, and that is the whole trick:
 * LVGL sends CLICKED after a long press as well, so a short draw there would follow
 * every long one and leave the finger's second draw invisible. SHORT_CLICKED is sent
 * only when the press really was short.
 */
static void preset_random_cb(lv_event_t *e)
{
    if (swipe_just_happened()) {
        return;
    }

    preset_randomise(lv_event_get_code(e) == LV_EVENT_LONG_PRESSED);
}

/*
 * A chip: a pill with a word in it, in the grey the readout pages wear.
 *
 * It takes the gesture bubble like every other touch area, so that a swipe which
 * starts on a chip still turns the page rather than being swallowed — and for the same
 * reason every callback above begins with swipe_just_happened(): a gesture still
 * releases as a click on whatever the finger started on, and loading a preset by
 * accident while scrolling the list would be the worst thing this page could do.
 */
static lv_obj_t *make_chip(lv_obj_t *parent, const char *text, int w, int h, int x, int y)
{
    lv_obj_t *chip = make_touch_area(parent, w, h, LV_ALIGN_CENTER, x, y);
    /*
     * The chip's field of reaction is wider than its drawing: the fill and the word keep
     * the size they have always had, and PRESET_EXT_CLICK_PX of padding on every side is
     * offered to the finger. The arbitration between these pads and the list's rows is in
     * preset_ext_hit_cb(), which every receiver shares.
     */
    lv_obj_set_ext_click_area(chip, PRESET_EXT_CLICK_PX);
    lv_obj_set_adv_hittest(chip, true);
    lv_obj_add_event_cb(chip, preset_ext_hit_cb, LV_EVENT_HIT_TEST, NULL);
    lv_obj_set_style_radius(chip, h / 2, LV_PART_MAIN);
    /*
     * The page's own family, not the neutral arc background. COL_ARC_BG is the teal
     * of a rim that is not being played, and a chip is not a rim: on a grey page it
     * read as a hole with a hairline around it. This is the grey group's own tile
     * colour taken down to a surface depth by the same TINT_SEL that fills a selected
     * sector, so the buttons are made of the same stuff as everything else here.
     */
    lv_obj_set_style_bg_color(chip,
                              lv_color_hex(tint(GROUP_COLOR[GRP_VIEW].tile, TINT_SEL)),
                              LV_PART_MAIN);
    lv_obj_set_style_bg_opa(chip, LV_OPA_COVER, LV_PART_MAIN);
    /* No outline. The bright hairline was doing the work the fill should do, and a
     * chip that is already a shape does not need to be drawn around as well. */
    lv_obj_set_style_border_width(chip, 0, LV_PART_MAIN);

    /*
     * Pressed: the same fill, thinner. Opacity and not a second colour, because the
     * chip already spends its colour on what it does (LOAD, SAVE and RND are the same
     * grey), and because this is the move every other button in the instrument makes
     * — see the note above make_touch_area(). Nothing moves and nothing resizes.
     */
    lv_obj_set_style_bg_opa(chip, LV_OPA_70, LV_PART_MAIN | LV_STATE_PRESSED);

    lv_obj_t *label = make_label(chip, text, &lv_font_anbscreen_20, COL_TEXT, LV_ALIGN_CENTER, 0, 0);
    text_condensed(label, 0);
    return chip;
}

/*
 * The pressed state of SAVE and RND.
 *
 * Two things make it: the fill, which is the palette's teal-400 instead of the same
 * grey thinned by 30 percent, and the word on it, which has to go dark to be read
 * against that fill. A state does not reach a child on its own — lv_obj_add_state()
 * walks the children only while LV_OBJ_FLAG_STATE_TRICKLE is set — so the flag is set
 * on the chip and the ink is styled on the label, which is the chip's only child.
 *
 * LOAD keeps the page's older press: the same grey, thinner, and it is the one chip
 * on this page that does.
 */
static void chip_press_pair(lv_obj_t *chip)
{
    lv_obj_t *label = lv_obj_get_child(chip, 0);

    lv_obj_set_style_bg_color(chip, lv_color_hex(PRESET_CHIP_PRESS_FILL),
                              LV_PART_MAIN | LV_STATE_PRESSED);
    lv_obj_set_style_bg_opa(chip, LV_OPA_COVER, LV_PART_MAIN | LV_STATE_PRESSED);
    lv_obj_set_state_trickle(chip, true);
    lv_obj_set_style_text_color(label, lv_color_hex(PRESET_CHIP_PRESS_INK),
                                LV_PART_MAIN | LV_STATE_PRESSED);
}

/* -------------------------------------------------------------------------- */
/* Build                                                                      */
/* -------------------------------------------------------------------------- */

void synth_ui_build(void)
{
    /* Before the first widget: the trail left by the session that just ended.
     * It is cleared only after every line has reached the log. */
    diag_dump_previous();

    lv_obj_t *screen = lv_screen_active();

    /* Before anything is drawn: everything the device remembers, including the
     * sound, so the screen opens on the instrument's real state. */
    restore_settings();

    lv_obj_set_style_bg_color(screen, lv_color_hex(COL_BG), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(screen, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_set_scrollable(screen, false);

    /*
     * A full-screen catcher, created first so everything else sits on top of it.
     *
     * Its only job is to be the object under the finger for swipes that land on
     * empty space, and to bubble them up to the screen. It carries no CLICKED
     * handler, so a tap that ends up here does nothing at all.
     */
    lv_obj_t *catcher = lv_obj_create(screen);
    lv_obj_set_size(catcher, 360, 360);
    lv_obj_center(catcher);
    lv_obj_set_scrollable(catcher, false);
    lv_obj_set_style_bg_opa(catcher, LV_OPA_TRANSP, LV_PART_MAIN);
    lv_obj_set_style_border_width(catcher, 0, LV_PART_MAIN);
    lv_obj_set_style_pad_all(catcher, 0, LV_PART_MAIN);
    lv_obj_set_clickable(catcher, true);
    lv_obj_set_click_focusable(catcher, false);
    lv_obj_set_gesture_bubble(catcher, true);
    /* And the press, for the same reason and by the same route: the gesture that measures
     * the swipe arrives at the screen only because the catcher bubbles it, and the press
     * that gives the swipe its speed has to travel with it. */
    lv_obj_add_flag(catcher, LV_OBJ_FLAG_EVENT_BUBBLE);

    /*
     * Everything that belongs to a PAGE goes inside this container, so a page
     * turn can slide it.
     *
     * Two things must NOT slide: the catcher, which is what catches a swipe, and
     * the focus proxy, which the knob drives and which has to stay put for the
     * group to stay valid. So `real` holds the true screen from here on and
     * `screen` becomes the sliding content.
     */
    lv_obj_t *real = screen;

    s_content = lv_obj_create(real);
    lv_obj_set_size(s_content, 360, 360);
    lv_obj_center(s_content);
    lv_obj_set_scrollable(s_content, false);
    lv_obj_set_style_bg_opa(s_content, LV_OPA_TRANSP, LV_PART_MAIN);
    lv_obj_set_style_border_width(s_content, 0, LV_PART_MAIN);
    lv_obj_set_style_radius(s_content, 0, LV_PART_MAIN);
    lv_obj_set_style_pad_all(s_content, 0, LV_PART_MAIN);
    lv_obj_set_clickable(s_content, false);
    lv_obj_set_click_focusable(s_content, false);
    /* Carries gestures on up to the screen, which owns the handler. Without it
     * the walk up from a sector's touch area would stop here and every swipe
     * would be lost. */
    lv_obj_set_gesture_bubble(s_content, true);
    /* And the presses of everything inside it, for the same reason: a drag is armed by the
     * screen's own PRESSED handler, and an event only bubbles while every object it passes
     * has this flag. See make_touch_area(). */
    lv_obj_add_flag(s_content, LV_OBJ_FLAG_EVENT_BUBBLE);

    screen = s_content;

    /*
     * The rim's own pixels, as one picture: a 360x360 draw buffer in PSRAM, the same size and
     * the same kind as the map's mosaic, painted by the ring code in this file and blitted.
     *
     * Created before anything it carries, so it is the first child and everything else —
     * the spokes, the panels, the labels, the dots, the selection, the cursor — is painted
     * over it without a single reorder.
     *
     * If the memory is not there the arcs and the bands stay visible and draw themselves,
     * which is what they did before this existed: the page costs 115 ms more and still works.
     */
    s_rim_buf = lv_draw_buf_create(360, 360, LV_COLOR_FORMAT_RGB565, 0);

    if (s_rim_buf == NULL) {
        ESP_LOGE(TAG, "rim: no room for the %d KB picture, drawing it with objects",
                 (360 * 360 * 2) / 1024);
    } else {
        s_rim_img = lv_image_create(s_content);
        lv_image_set_src(s_rim_img, s_rim_buf);
        lv_obj_set_pos(s_rim_img, 0, 0);
        lv_obj_move_to_index(s_rim_img, 0);
        lv_obj_clear_flag(s_rim_img, LV_OBJ_FLAG_SCROLLABLE);
        lv_obj_set_clickable(s_rim_img, false);
        lv_obj_set_click_focusable(s_rim_img, false);
        suppress_theme_focus_decoration(s_rim_img);

        /* The buffer arrives uninitialised, and the picture is on screen from this moment —
         * refresh_arcs() does not run until the first page is applied. */
        rim_clear();
    }

    /* --- the rim: arcs, spokes, highlight panels, text --------------------- */
    for (int i = 0; i < SECTOR_MAX; i++) {
        /*
         * The indicator. NOT clickable, and that is load-bearing twice over:
         * ui_app collects focusable widgets by class and lv_arc is one of them,
         * so a clickable arc would join the group and break the BSP's "exactly
         * one candidate" rule — and an arc's hit test is its whole 352x352
         * bounding box rather than the drawn ring, so four of them would sit on
         * top of every other control and eat the taps.
         */
        lv_obj_t *arc = lv_arc_create(screen);
        lv_obj_set_size(arc, ARC_OBJ_SIZE, ARC_OBJ_SIZE);
        lv_obj_center(arc);
        lv_arc_set_range(arc, 0, PARAM_STEPS);
        lv_arc_set_value(arc, 0);
        lv_obj_set_style_arc_width(arc, ARC_W_IDLE, LV_PART_INDICATOR);
        lv_obj_set_style_arc_width(arc, ARC_W_IDLE, LV_PART_MAIN);
        lv_obj_set_style_arc_color(arc, lv_color_hex(COL_SEC_IDLE), LV_PART_INDICATOR);
        lv_obj_set_style_arc_color(arc, lv_color_hex(COL_ARC_BG), LV_PART_MAIN);
        lv_obj_set_style_bg_opa(arc, LV_OPA_TRANSP, LV_PART_KNOB);
        lv_obj_set_style_bg_opa(arc, LV_OPA_TRANSP, LV_PART_MAIN);

        /* Flat ends. Rounded caps make a partly filled sector read as a lozenge
         * floating on the rim; square ends make it read as a length, which is
         * what a value is. */
        lv_obj_set_style_arc_rounded(arc, false, LV_PART_INDICATOR);
        lv_obj_set_style_arc_rounded(arc, false, LV_PART_MAIN);

        lv_obj_set_clickable(arc, false);
        lv_obj_set_click_focusable(arc, false);
        suppress_theme_focus_decoration(arc);
        s_sector_arc[i] = arc;

        /* Geometry and colour, not a drawing: see the note above s_rim_buf. */
        if (s_rim_buf != NULL) {
            lv_obj_add_flag(arc, LV_OBJ_FLAG_HIDDEN);
        }
    }

    /*
     * The selected sector's fill, and the value mark that rides on its rim.
     *
     * Created here, above the rim arcs and below the spokes, so the fill sits under the
     * text while the spokes still read as the sector's own boundaries — and so the mark
     * covers the selected sector's indicator exactly, which is the point of giving it the
     * same 14 px band and the same range.
     *
     * They are two objects rather than one because an lv_arc has a single radius for both
     * of its parts (lv_arc.c: get_center()), and these two bands are at different radii:
     * the fill's centre line is 113 px out, the rim's is 169. One object cannot be both,
     * and the alternative — restyling a sector's own arc on every tap — repaints a 352 px
     * box each time. These two are moved by angle instead, which invalidates only the
     * wedge swept. See refresh_sectors().
     *
     * Neither is clickable, for the same two reasons the rim arcs are not: ui_app builds
     * the focus group by widget class, and an arc's hit test is its whole 352x352 box.
     */
    s_sel_body = lv_arc_create(screen);
    lv_obj_set_size(s_sel_body, ARC_OBJ_SIZE, ARC_OBJ_SIZE);
    lv_obj_center(s_sel_body);
    lv_obj_set_style_pad_all(s_sel_body, SEL_BODY_PAD, LV_PART_MAIN);
    lv_obj_set_style_arc_width(s_sel_body, SEL_BODY_W, LV_PART_MAIN);
    lv_obj_set_style_arc_width(s_sel_body, 0, LV_PART_INDICATOR);
    lv_obj_set_style_arc_rounded(s_sel_body, false, LV_PART_MAIN);
    lv_obj_set_style_bg_opa(s_sel_body, LV_OPA_TRANSP, LV_PART_KNOB);
    lv_obj_set_style_bg_opa(s_sel_body, LV_OPA_TRANSP, LV_PART_MAIN);
    lv_obj_set_clickable(s_sel_body, false);
    lv_obj_set_click_focusable(s_sel_body, false);
    suppress_theme_focus_decoration(s_sel_body);

    s_sel_rim = lv_arc_create(screen);

    lv_obj_set_size(s_sel_rim, ARC_OBJ_SIZE, ARC_OBJ_SIZE);
    lv_obj_center(s_sel_rim);
    lv_arc_set_range(s_sel_rim, 0, PARAM_STEPS);
    lv_arc_set_value(s_sel_rim, 0);
    lv_obj_set_style_arc_width(s_sel_rim, ARC_W_IDLE, LV_PART_INDICATOR);
    /* No track of its own: the family's dark track underneath is what the unfilled part
     * of the rim should keep looking like, and a zero width draws nothing at all
     * (lv_draw_arc.c: if(dsc->width == 0) return). */
    lv_obj_set_style_arc_width(s_sel_rim, 0, LV_PART_MAIN);
    lv_obj_set_style_arc_rounded(s_sel_rim, false, LV_PART_INDICATOR);
    lv_obj_set_style_bg_opa(s_sel_rim, LV_OPA_TRANSP, LV_PART_KNOB);
    lv_obj_set_style_bg_opa(s_sel_rim, LV_OPA_TRANSP, LV_PART_MAIN);
    lv_obj_set_clickable(s_sel_rim, false);
    lv_obj_set_click_focusable(s_sel_rim, false);
    suppress_theme_focus_decoration(s_sel_rim);

    /* The page has a picture by now (it is created above), so from this point the two arcs are
     * carriers and never objects on screen — see rim_paint_sel_body(). */
    if (s_rim_buf != NULL) {
        lv_obj_add_flag(s_sel_body, LV_OBJ_FLAG_HIDDEN);
        lv_obj_add_flag(s_sel_rim, LV_OBJ_FLAG_HIDDEN);
    }

    /*
     * THE MARKS ON THE RIM: the cursor of every list, and the cut between every two sectors.
     *
     * A list's rim is a CHOICE, so it shows one lit segment — the position the knob is on —
     * rather than a length. The sector's own arc still draws its dark track and, for a
     * continuous parameter, its fill; this object only adds what an lv_arc cannot: a band that
     * does not begin at the arc's start angle, and a line across the rim.
     *
     * THE CUT BETWEEN SECTORS IS HERE for the same reason: without it two neighbouring arcs
     * meet end to end and the rim reads as one continuous stroke, so six knobs look like one
     * six-times-longer knob. Two pixels of the screen's background at every boundary separate
     * them, over a lit rim and a dark one alike.
     *
     * CREATED AFTER BOTH SELECTION ARCS, and that is not a detail: stacking here is the order
     * of creation, and the selected sector's bright value mark is the last of the arcs. A mark
     * painted under it would be a mark the selected sector — the only one the hand is on —
     * never showed. Before the hub, because the hub covers the ring's inner part and none of
     * this paints there.
     */
    s_rim_marks = lv_obj_create(screen);
    lv_obj_remove_style_all(s_rim_marks);
    lv_obj_set_size(s_rim_marks, ARC_OBJ_SIZE, ARC_OBJ_SIZE);
    lv_obj_center(s_rim_marks);
    lv_obj_set_style_opa(s_rim_marks, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_clear_flag(s_rim_marks, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_clickable(s_rim_marks, false);
    lv_obj_set_click_focusable(s_rim_marks, false);
    suppress_theme_focus_decoration(s_rim_marks);
    lv_obj_add_event_cb(s_rim_marks, rim_marks_draw_cb, LV_EVENT_DRAW_MAIN, NULL);

    /*
     * The hub disc: the page's own background over both selection arcs, under the
     * spokes and under every label. Created HERE, between the fills and the tap layer,
     * because the order of creation is the order of stacking and those two neighbours
     * are the whole requirement — the fill must not reach the page's name, and the
     * spokes must stay visible over it.
     *
     * Its colour is set per page in apply_page(), to the same tint the screen itself is
     * given, so on screen it is not a circle at all: it is the place where the fill
     * stops. Its radius is the dividers' inner end, which is also where the fill now
     * begins, so the two meet exactly. See CENTRE_BG_R.
     */
    s_hub = lv_obj_create(screen);
    lv_obj_set_size(s_hub, 2 * CENTRE_BG_R, 2 * CENTRE_BG_R);
    lv_obj_center(s_hub);
    lv_obj_set_scrollable(s_hub, false);
    lv_obj_set_style_radius(s_hub, LV_RADIUS_CIRCLE, LV_PART_MAIN);
    lv_obj_set_style_bg_color(s_hub, lv_color_hex(tint(GROUP_COLOR[GRP_DRONE].fill, TINT_BG)),
                              LV_PART_MAIN);
    lv_obj_set_style_bg_opa(s_hub, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_set_style_border_width(s_hub, 0, LV_PART_MAIN);
    lv_obj_set_style_pad_all(s_hub, 0, LV_PART_MAIN);
    lv_obj_set_clickable(s_hub, false);
    lv_obj_set_click_focusable(s_hub, false);

    /*
     * The pagination dots, in the centre disc above the title.
     *
     * They are panels rather than labels because a dot is a shape, and make_panel()
     * leaves them unfocusable and unclickable — which is what keeps a tap on one from
     * eating a sector: the rim's polar layer rejects everything inside RIM_HIT_INNER, so
     * a click here falls through to the screen exactly as it did before the dots existed.
     *
     * One object per page; refresh_page_dots() decides which of them exist at the moment.
     */
    for (int i = 0; i < (int)PAGE_COUNT; i++) {
        lv_obj_t *dot = make_panel(screen, PAGE_DOT_D, PAGE_DOT_D, COL_BG,
                                   LV_ALIGN_CENTER, 0, PAGE_DOT_Y);
        lv_obj_set_style_radius(dot, LV_RADIUS_CIRCLE, LV_PART_MAIN);
        lv_obj_set_hidden(dot, true);
        s_page_dot[i] = dot;
    }

    /*
     * The polar tap layer, deliberately created HERE: after the arcs, so it is
     * above them (they are not clickable, but they are enormous), and before the
     * text blocks and their touch areas, so those stay on top and keep winning the
     * taps they were built for. Everything it does not cover is now a sector.
     */
    s_rim_hit = make_touch_area(screen, BSP_LCD_H_RES, BSP_LCD_V_RES,
                                LV_ALIGN_CENTER, 0, 0);
    lv_obj_add_event_cb(s_rim_hit, press_stamp_cb, LV_EVENT_PRESSED, NULL);
    lv_obj_add_event_cb(s_rim_hit, rim_tap_cb, LV_EVENT_CLICKED, NULL);
    lv_obj_add_event_cb(s_rim_hit, rim_long_cb, LV_EVENT_LONG_PRESSED, NULL);

    /* --- the preset page's ribbon ------------------------------------------ */
    s_wave = lv_line_create(screen);
    lv_obj_set_size(s_wave, WAVE_W, WAVE_H);
    /* On the equator, behind the list: the middle of the dial is the one line the eye
     * already follows on this page. */
    lv_obj_align(s_wave, LV_ALIGN_CENTER, 0, 0);
    lv_obj_set_style_line_width(s_wave, 2, LV_PART_MAIN);
    lv_obj_set_style_line_color(s_wave, lv_color_hex(tint(GROUP_COLOR[GRP_PRESET].bright, 96)),
                                LV_PART_MAIN);
    lv_obj_set_style_line_rounded(s_wave, true, LV_PART_MAIN);
    lv_obj_set_clickable(s_wave, false);
    lv_obj_set_click_focusable(s_wave, false);
    suppress_theme_focus_decoration(s_wave);
    lv_obj_set_hidden(s_wave, true);
    wave_advance();   /* a curve is there the first time the page opens */

    /* --- the tracks and their dots ---------------------------------------- */
    for (int i = 0; i < SECTOR_MAX; i++) {
        /*
         * A hairline arc on the sector's span, and the dot that rides it. Both are inert:
         * an lv_arc and an lv_obj would join the focusable group and eat taps otherwise,
         * the same reason the rim arcs are not clickable.
         */
        lv_obj_t *track = lv_arc_create(screen);

        /* An arc draws on its object's own radius with no padding, and that radius is the
         * stroke's OUTER edge, so the object is half a width wider than the circle the band
         * is centred on: VIZ_OBJ_R, which is where the dots ride and where the meters sit. */
        lv_obj_set_size(track, VIZ_OBJ_R * 2, VIZ_OBJ_R * 2);
        lv_obj_center(track);
        lv_arc_set_range(track, 0, PARAM_STEPS);
        lv_arc_set_value(track, 0);
        lv_obj_set_style_arc_width(track, VIZ_W, LV_PART_INDICATOR);
        lv_obj_set_style_arc_width(track, VIZ_W, LV_PART_MAIN);
        /* A neutral pair until layout_sectors() gives the track its section's colours. */
        lv_obj_set_style_arc_color(track, lv_color_hex(COL_FAINT), LV_PART_MAIN);
        lv_obj_set_style_arc_color(track, lv_color_hex(COL_MUTED), LV_PART_INDICATOR);
        lv_obj_set_style_bg_opa(track, LV_OPA_TRANSP, LV_PART_KNOB);
        lv_obj_set_style_bg_opa(track, LV_OPA_TRANSP, LV_PART_MAIN);
        lv_obj_set_style_arc_rounded(track, false, LV_PART_INDICATOR);
        lv_obj_set_style_arc_rounded(track, false, LV_PART_MAIN);
        lv_obj_set_clickable(track, false);
        lv_obj_set_click_focusable(track, false);
        suppress_theme_focus_decoration(track);
        lv_obj_set_hidden(track, true);
        s_viz_arc[i] = track;

        /*
         * The band a meter fills. An empty object with a draw event and no styles at all: it
         * paints nothing of its own, and what its event paints is the sector's arc, so it has
         * to sit where the track would and not one pixel off it. Not clickable, and not in the
         * focus group, for the reasons the track is not.
         */
        lv_obj_t *band = lv_obj_create(screen);
        lv_obj_remove_style_all(band);
        lv_obj_set_size(band, VIZ_OBJ_R * 2, VIZ_OBJ_R * 2);
        lv_obj_center(band);
        lv_obj_set_style_opa(band, LV_OPA_COVER, LV_PART_MAIN);
        lv_obj_clear_flag(band, LV_OBJ_FLAG_SCROLLABLE);
        lv_obj_set_clickable(band, false);
        lv_obj_set_click_focusable(band, false);
        suppress_theme_focus_decoration(band);
        lv_obj_set_hidden(band, true);
        lv_obj_add_event_cb(band, viz_band_draw_cb, LV_EVENT_DRAW_MAIN, NULL);
        s_viz_band[i] = band;

        lv_obj_t *dot = lv_obj_create(screen);
        lv_obj_remove_style_all(dot);
        lv_obj_set_size(dot, VIZ_DOT, VIZ_DOT);
        lv_obj_set_style_radius(dot, LV_RADIUS_CIRCLE, LV_PART_MAIN);
        lv_obj_set_style_bg_color(dot, lv_color_hex(COL_MUTED), LV_PART_MAIN);
        lv_obj_set_style_bg_opa(dot, LV_OPA_COVER, LV_PART_MAIN);
        lv_obj_set_clickable(dot, false);
        lv_obj_set_click_focusable(dot, false);
        suppress_theme_focus_decoration(dot);
        lv_obj_set_hidden(dot, true);
        s_viz_dot[i] = dot;
    }

    /* The spokes, between the arcs and the text so they read as boundaries. */
    for (int i = 0; i < DIV_MAX; i++) {
        lv_obj_t *line = lv_line_create(screen);
        lv_obj_set_size(line, 360, 360);
        lv_obj_center(line);
        lv_obj_set_style_line_width(line, 2, LV_PART_MAIN);
        lv_obj_set_style_line_color(line, lv_color_hex(COL_FAINT), LV_PART_MAIN);
        lv_obj_set_clickable(line, false);
        lv_obj_set_click_focusable(line, false);
        lv_obj_set_hidden(line, true);
        s_divider[i] = line;
    }

    for (int i = 0; i < SECTOR_MAX; i++) {
        /* The macro's block, for a member that is NOT the sector the knob is on: the
         * selected sector's fill is the wedge instead.
         *
         * Rounded all the way to a capsule rather than the usual 10 px corner, because a
         * 10 px corner is the one part of this block that reaches outside the sector. Its
         * inner corners are at (+-56, -24) from the anchor, which is 37.9 degrees off the
         * centre line where the sector is 36 wide: 3.0 px of it in the next sector's half.
         * A capsule's widest point at that inner edge is at +-32, and 32 px at 72 px out
         * is 24 degrees — inside the sector's 36, with room. */
        lv_obj_t *panel = make_panel(screen, PANEL_W, PANEL_H, COL_SEL_BG,
                                     LV_ALIGN_CENTER, 0, 0);
        lv_obj_set_style_radius(panel, PANEL_H / 2, LV_PART_MAIN);
        lv_obj_set_style_bg_opa(panel, LV_OPA_TRANSP, LV_PART_MAIN);
        s_sector_panel[i] = panel;

        s_sector_name[i] = make_label(screen, "", &lv_font_anbscreen_14, COL_MUTED,
                                      LV_ALIGN_CENTER, 0, 0);
        text_condensed(s_sector_name[i], 2);

        s_sector_value[i] = make_label(screen, "--", &lv_font_anbscreen_20, COL_MUTED,
                                       LV_ALIGN_CENTER, 0, 0);
        text_condensed(s_sector_value[i], 0);
    }

    /* --- the rim: touch areas, over the text ------------------------------- */
    for (int i = 0; i < SECTOR_MAX; i++) {
        lv_obj_t *touch = make_touch_area(screen, PANEL_W, PANEL_H,
                                          LV_ALIGN_CENTER, 0, 0);
        /* The same shape as the block it stands over, so the pressed wash comes out as
         * the capsule a sector's text sits in rather than as a rectangle behind it. Set
         * here, once: refresh_sectors() only ever changes the wash's colour. */
        lv_obj_set_style_radius(touch, PANEL_H / 2, LV_PART_MAIN);
        lv_obj_add_event_cb(touch, press_stamp_cb, LV_EVENT_PRESSED, NULL);
        lv_obj_add_event_cb(touch, sector_tap_cb, LV_EVENT_CLICKED,
                            (void *)(intptr_t)i);
        lv_obj_add_event_cb(touch, sector_long_cb, LV_EVENT_LONG_PRESSED,
                            (void *)(intptr_t)i);
        s_sector_touch[i] = touch;
    }

    /* --- the middle -------------------------------------------------------- */
    s_page_name = make_label(screen, "", &lv_font_anbscreen_20, COL_MUTED,
                             LV_ALIGN_CENTER, 0, PAGE_NAME_Y);
    text_condensed(s_page_name, 0);

    s_macro_label = make_label(screen, "", &lv_font_anbscreen_14, COL_MACRO_VALUE,
                               LV_ALIGN_CENTER, 0, MACRO_Y);
    text_condensed(s_macro_label, 2);
    lv_obj_set_hidden(s_macro_label, true);

    /* The one other thing that can want this line: the arp has the lead's grid, so the
     * grid's own controls do nothing and the page would otherwise read as broken. Made
     * here, beside the count it displaces, and hidden until something asks for it. */
    s_arp_label = make_label(screen, "ARP IS ACTIVE", &lv_font_anbscreen_20, COL_MUTED,
                             LV_ALIGN_CENTER, 0, MACRO_Y);
    text_condensed(s_arp_label, 0);
    lv_obj_set_hidden(s_arp_label, true);

    /*
     * The turning picture, over the middle of the disc.
     *
     * An empty box, not an image: its pixels are written by preview_draw_cb()
     * straight into the layer's buffer, because LVGL has no fast path for a 1-bit
     * image and the mask is cheaper than any object that could carry a picture.
     * Nothing is drawn until a knob moves, and the box is 56x56 centred, so its
     * farthest corner is 39.6 px from the middle against the hub's 52 — 12 px of
     * air, the same arithmetic the title's is checked with. Inside the box the
     * figure itself is 44x44, centred: six pixels of air on every side, the rule
     * every figure on every page is drawn to.
     *
     * Created after the name, the count and the notice, so it is above them when it
     * appears — and hidden by default, so the page opens exactly as it did before.
     */
    s_preview = lv_obj_create(screen);
    lv_obj_remove_style_all(s_preview);
    lv_obj_set_size(s_preview, SYNTH_PREVIEW_W, SYNTH_PREVIEW_H);
    lv_obj_center(s_preview);
    lv_obj_set_style_bg_opa(s_preview, LV_OPA_TRANSP, LV_PART_MAIN);
    lv_obj_set_style_border_width(s_preview, 0, LV_PART_MAIN);
    lv_obj_set_style_pad_all(s_preview, 0, LV_PART_MAIN);
    lv_obj_set_style_radius(s_preview, 0, LV_PART_MAIN);
    lv_obj_set_clickable(s_preview, false);
    lv_obj_set_click_focusable(s_preview, false);
    lv_obj_clear_flag(s_preview, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_add_event_cb(s_preview, preview_draw_cb, LV_EVENT_DRAW_MAIN, NULL);
    lv_obj_set_hidden(s_preview, true);

    /*
     * The focus proxy: a transparent arc, the only widget the knob drives, and
     * the only member of the focus group.
     *
     * It must be an arc because that is the class ui_app collects, and it must
     * be clickable because that is what is_eligible() tests. It is left
     * click-focusable in the FALSE position for the reason the whole UI depends
     * on: a tap on a click-focusable object that is already focused clears edit
     * mode, and lv_group_focus_obj() cannot restore it because it breaks out
     * before the focus callback when the object is already the focus.
     */
    s_proxy = lv_arc_create(real);
    lv_obj_set_size(s_proxy, PROXY_SIZE, PROXY_SIZE);
    lv_obj_center(s_proxy);
    lv_arc_set_range(s_proxy, 0, PARAM_STEPS);
    lv_arc_set_value(s_proxy, 0);
    lv_obj_set_style_bg_opa(s_proxy, LV_OPA_TRANSP, LV_PART_KNOB);
    lv_obj_set_style_bg_opa(s_proxy, LV_OPA_TRANSP, LV_PART_MAIN);
    lv_obj_set_style_arc_opa(s_proxy, LV_OPA_TRANSP, LV_PART_MAIN);
    lv_obj_set_style_arc_opa(s_proxy, LV_OPA_TRANSP, LV_PART_INDICATOR);
    lv_obj_set_clickable(s_proxy, true);
    lv_obj_set_click_focusable(s_proxy, false);
    /* The middle is what a finger finds first inside the rim: its press has to reach the
     * screen as well, or a slow drag begun in the middle would be the one place that could
     * still turn into a macro. */
    lv_obj_add_flag(s_proxy, LV_OBJ_FLAG_EVENT_BUBBLE);
    lv_obj_set_gesture_bubble(s_proxy, true);
    lv_obj_add_event_cb(s_proxy, proxy_changed_cb, LV_EVENT_VALUE_CHANGED, NULL);
    /*
     * The same long press as the rim's tap layer, and it has to be here as well.
     *
     * The proxy lives on the real screen rather than in the sliding content, so it is the
     * one object ABOVE that layer — and a long press aimed at the very middle of the dial
     * lands on its 8 x 8 box, not on the layer below. Without this, the precise centre of
     * the middle would answer differently from the ring around it. Only the long press,
     * exactly as on the layer: the proxy's CLICKED is not registered and a tap still does
     * nothing but leave the knob standing where it was.
     */
    lv_obj_add_event_cb(s_proxy, rim_long_cb, LV_EVENT_LONG_PRESSED, NULL);
    suppress_theme_focus_decoration(s_proxy);

    /* --- the preset page --------------------------------------------------- */
    /*
     * Seven row boxes and the chips. The rows are built once and only ever
     * re-labelled: preset_refresh() decides which of them are on screen and what they
     * say, so nothing here has to know anything about the store.
     *
     * Nothing in this page is focusable. The rows are clickable, but not as controls:
     * lv_obj_hit_test() refuses an object that is not clickable, so the flag is the only
     * way a row can stay in the search and take its own frame back from the chips'
     * enlarged fields. Nothing is bound to the row's CLICKED, so the row is a dead zone:
     * it keeps the point and does nothing with it. See preset_ext_hit_cb().
     */
    s_preset = lv_obj_create(screen);
    lv_obj_set_size(s_preset, 360, 360);
    lv_obj_center(s_preset);
    lv_obj_set_scrollable(s_preset, false);
    lv_obj_set_style_bg_opa(s_preset, LV_OPA_TRANSP, LV_PART_MAIN);
    lv_obj_set_style_border_width(s_preset, 0, LV_PART_MAIN);
    lv_obj_set_style_pad_all(s_preset, 0, LV_PART_MAIN);
    lv_obj_set_clickable(s_preset, false);
    lv_obj_set_click_focusable(s_preset, false);
    lv_obj_set_hidden(s_preset, true);

    for (int r = 0; r < PRESET_ROWS; r++) {
        const int step = r - PRESET_ROWS / 2;

        lv_obj_t *row = lv_obj_create(s_preset);
        lv_obj_set_size(row, PRESET_ROW_W, PRESET_ROW_H);
        /* Aligned left of centre by PRESET_ROW_X, so that the number's indent and the
         * name's position can stay put as the slot number grows a digit. The row is
         * invisible except when it is the selected one; see the note on the columns. */
        lv_obj_align(row, LV_ALIGN_CENTER, PRESET_ROW_X, step * PRESET_ROW_DY);
        lv_obj_set_scrollable(row, false);
        lv_obj_set_style_radius(row, 8, LV_PART_MAIN);
        lv_obj_set_style_bg_opa(row, LV_OPA_TRANSP, LV_PART_MAIN);
        lv_obj_set_style_border_width(row, 0, LV_PART_MAIN);
        lv_obj_set_style_pad_all(row, 0, LV_PART_MAIN);
        /*
         * Clickable, and deliberately without a CLICKED handler.
         *
         * Clickable is what keeps the row in the search at all: lv_obj_hit_test() returns
         * false for an object that is not, so without the flag the row leaves the
         * arbitration and the bottom row's own text falls to SAVE or RND. On that text's
         * line, 45.5 px right of the row's centre, RND's centre is 32.7 px away while the
         * row's own is 45.5: a tap on a preset name would randomise the patch.
         *
         * No handler is the owner's rule: the list is not a control, so a tap on a row
         * selects nothing and does nothing. The row still takes its drawn box and its own
         * pad away from the chips and then keeps the touch to itself. Its field is widened
         * like the chips', but the list's 27 px pitch means the vertical halves between
         * neighbours meet at the same midpoint either way; the pad's visible effect on a
         * row is its width (160 -> 176) and the two outer ends. See preset_ext_hit_cb()
         * for how a row and a chip settle an overlap.
         */
        lv_obj_set_clickable(row, true);
        lv_obj_set_click_focusable(row, false);
        lv_obj_set_ext_click_area(row, PRESET_EXT_CLICK_PX);
        lv_obj_set_adv_hittest(row, true);
        lv_obj_add_event_cb(row, preset_ext_hit_cb, LV_EVENT_HIT_TEST, NULL);

        /* Indented, not on the row's own edge: on the selected row the fill is visible
         * and a number welded to its corner reads as a mistake. The indent comes out of
         * the gap between the two words, not out of either of them. */
        s_preset_no[r] = make_label(row, "", &lv_font_anbscreen_14, COL_TEXT,
                                    LV_ALIGN_LEFT_MID, PRESET_NO_X, PRESET_INK_DY);
        text_condensed(s_preset_no[r], 2);

        s_preset_name[r] = make_label(row, "", &lv_font_anbscreen_20, COL_TEXT,
                                      LV_ALIGN_LEFT_MID, PRESET_NAME_X, PRESET_INK_DY);
        text_condensed(s_preset_name[r], 0);

        s_preset_row[r] = row;
    }

    /* The empty store, in one line, where the selected row would have been. */
    s_preset_empty = make_label(s_preset, "NO PRESETS", &lv_font_anbscreen_20, COL_MUTED,
                                LV_ALIGN_CENTER, 0, 0);
    text_condensed(s_preset_empty, 0);

    /* LOAD sits at the right of the selected row, clear of the longest name a row can
     * hold — 126 px of the 160 — which is why its x is a constant and not a measure; the
     * name's ink ends at +75 and the chip starts at +78.
     * It stands at the fingertip floor like the two below it, and nothing is above or
     * below it here. */
    s_preset_load = make_chip(s_preset, "LOAD", PRESET_LOAD_W, PRESET_LOAD_H, PRESET_LOAD_X, 0);
    lv_obj_add_event_cb(s_preset_load, preset_load_cb, LV_EVENT_CLICKED, NULL);

    s_preset_save = make_chip(s_preset, "SAVE", PRESET_SAVE_W, PRESET_CHIP_H,
                              PRESET_SAVE_X, PRESET_CHIP_Y);
    chip_press_pair(s_preset_save);
    lv_obj_add_event_cb(s_preset_save, preset_save_cb, LV_EVENT_CLICKED, NULL);

    s_preset_random = make_chip(s_preset, "RND", PRESET_RANDOM_W, PRESET_CHIP_H,
                                PRESET_RANDOM_X, PRESET_CHIP_Y);
    chip_press_pair(s_preset_random);
    lv_obj_add_event_cb(s_preset_random, preset_random_cb, LV_EVENT_SHORT_CLICKED, NULL);
    lv_obj_add_event_cb(s_preset_random, preset_random_cb, LV_EVENT_LONG_PRESSED, NULL);

    /*
     * The gesture handler lives on the SCREEN, and the screen must not carry
     * GESTURE_BUBBLE: LVGL walks up while the flag is set, so a bubbling screen
     * would send the walk past it to NULL and drop the gesture entirely.
     */
    lv_obj_add_event_cb(real, screen_gesture_cb, LV_EVENT_GESTURE, NULL);
    /* Where and when the finger went down, so the gesture can be given a speed. */
    lv_obj_add_event_cb(real, screen_pressed_cb, LV_EVENT_PRESSED, NULL);

    /*
     * Make sure the amplifier is live.
     *
     * The bring-up demo's tone page drives the PCM5100A's XSMT soft mute and
     * leaves the DAC muted when the user leaves that page. A muted amplifier
     * makes a completely healthy synth look dead, so this screen asserts the
     * unmuted state rather than assuming it.
     */
    if (bsp_audio_out_is_ready()) {
        bsp_audio_out_mute(false);
    }

    lv_timer_create(anim_timer_cb, ANIM_PERIOD_MS, NULL);
    lv_timer_create(housekeeping_timer_cb, HOUSEKEEP_PERIOD_MS, NULL);
    lv_timer_create(seq_timer_cb, SEQ_PERIOD_MS, NULL);
    /* The turn under the finger, which cannot be an event: see the drag block. */
    lv_timer_create(drag_timer_cb, DRAG_POLL_MS, NULL);

    /* --- the sequencer dots ------------------------------------------------- */
    for (int i = 0; i < SEQ_DOT_MAX; i++) {
        lv_obj_t *dot = make_panel(s_content, SEQ_DOT_OFF, SEQ_DOT_OFF, COL_STEP_OFF,
                                   LV_ALIGN_CENTER, 0, 0);
        lv_obj_set_style_radius(dot, LV_RADIUS_CIRCLE, LV_PART_MAIN);
        lv_obj_set_hidden(dot, true);
        lv_obj_set_clickable(dot, false);
        lv_obj_set_click_focusable(dot, false);
        s_seq_dot[i] = dot;
    }

    /*
     * The cursor is an OUTLINE rather than a filled dot, so it can sit on a dot
     * without hiding the thing it points at — and a lit dot is exactly what you
     * are trying to read.
     */
    s_seq_cursor = make_panel(s_content, SEQ_CURSOR_D, SEQ_CURSOR_D, COL_BG,
                              LV_ALIGN_CENTER, 0, 0);
    lv_obj_set_style_radius(s_seq_cursor, LV_RADIUS_CIRCLE, LV_PART_MAIN);
    lv_obj_set_style_bg_opa(s_seq_cursor, LV_OPA_TRANSP, LV_PART_MAIN);
    lv_obj_set_style_border_width(s_seq_cursor, 2, LV_PART_MAIN);
    lv_obj_set_style_border_color(s_seq_cursor, lv_color_hex(COL_STEP_DIM), LV_PART_MAIN);
    lv_obj_set_hidden(s_seq_cursor, true);
    lv_obj_set_clickable(s_seq_cursor, false);
    lv_obj_set_click_focusable(s_seq_cursor, false);

    /* --- the navigator ------------------------------------------------------ */
    nav_measure();

    /*
     * On the real screen, not in the content: the map is a curtain over
     * everything, and a page turn underneath it must not drag it sideways.
     *
     * Created last of the three so it sits on top of both the catcher and the
     * content, which is what makes it cover them — and why it is the object the
     * finger finds while it is up.
     */
    s_nav = lv_obj_create(real);
    lv_obj_set_size(s_nav, 360, 360);
    lv_obj_align(s_nav, LV_ALIGN_TOP_MID, 0, -360);
    lv_obj_set_scrollable(s_nav, false);
    lv_obj_set_style_bg_color(s_nav, lv_color_hex(COL_BG), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(s_nav, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_set_style_border_width(s_nav, 0, LV_PART_MAIN);
    lv_obj_set_style_radius(s_nav, 0, LV_PART_MAIN);
    lv_obj_set_style_pad_all(s_nav, 0, LV_PART_MAIN);
    lv_obj_set_clickable(s_nav, true);
    lv_obj_set_click_focusable(s_nav, false);
    /* A drag may start on the map itself and has to reach the screen like any other:
     * the presses of its cells bubble only if the map passes them on. */
    lv_obj_add_flag(s_nav, LV_OBJ_FLAG_EVENT_BUBBLE);
    lv_obj_set_hidden(s_nav, true);
    lv_obj_add_event_cb(s_nav, nav_bg_cb, LV_EVENT_CLICKED, NULL);
    lv_obj_add_event_cb(s_nav, nav_press_cb, LV_EVENT_PRESSED, NULL);
    lv_obj_add_event_cb(s_nav, nav_press_cb, LV_EVENT_RELEASED, NULL);
    lv_obj_add_event_cb(s_nav, nav_press_cb, LV_EVENT_PRESS_LOST, NULL);
    /* No press/pressing/release handlers any more: the map does not move under the
     * finger, so there is no drag to track and nothing left that could guard a tap. */


    /*
     * The mosaic, as one image: a 360x360 draw buffer, baked on a page change and on a flash, and
     * blitted as it is.
     *
     * It used to be drawn from the cells on every pass — a hundred-odd triangles and twice as many
     * cut lines for a full paint — which is a slide's worth of draw tasks for a picture that only
     * changes when the page or the rhythm does. In PSRAM, and it has to be: 253 KB is not in what is
     * left of the internal heap, and the drawer's own snapshots live there for the same reason.
     */
    s_nav_buf = lv_draw_buf_create(NAV_SCREEN, NAV_SCREEN, LV_COLOR_FORMAT_RGB565, 0);

    if (s_nav_buf == NULL) {
        ESP_LOGE(TAG, "map: no room for the %d KB mosaic",
                 (NAV_SCREEN * NAV_SCREEN * 2) / 1024);
    } else {
        s_nav_cells = lv_image_create(s_nav);
        lv_image_set_src(s_nav_cells, s_nav_buf);
        lv_obj_set_pos(s_nav_cells, 0, 0);
        lv_obj_clear_flag(s_nav_cells, LV_OBJ_FLAG_SCROLLABLE);
        lv_obj_set_clickable(s_nav_cells, false);
        lv_obj_set_click_focusable(s_nav_cells, false);

        /* The moving parts over the picture, and created before the names so that the names are
         * painted over them. A tap falls through both of them to the curtain. */
        s_nav_marks = lv_obj_create(s_nav);
        lv_obj_remove_style_all(s_nav_marks);
        lv_obj_set_size(s_nav_marks, NAV_SCREEN, NAV_SCREEN);
        lv_obj_set_pos(s_nav_marks, 0, 0);
        lv_obj_set_style_opa(s_nav_marks, LV_OPA_COVER, LV_PART_MAIN);
        lv_obj_clear_flag(s_nav_marks, LV_OBJ_FLAG_SCROLLABLE);
        lv_obj_set_clickable(s_nav_marks, false);
        lv_obj_set_click_focusable(s_nav_marks, false);
        suppress_theme_focus_decoration(s_nav_marks);
    
        /* Baked before the first frame that could show it, and timed while it is the only one in
         * the boot log: this is the whole rasterising the map ever does. */
        const int64_t bake_at = esp_timer_get_time();
        nav_mosaic();
        ESP_LOGI(TAG, "map: %d px mosaic baked in %d us",
                 NAV_SCREEN, (int)(esp_timer_get_time() - bake_at));
    }

    for (int i = 0; i < (int)PAGE_COUNT; i++) {
        /*
         * A page without a cell gets no name either: nav_measure() has already left its cell at
         * zero vertices, and the bake draws nothing for it.
         */
        if (!PAGES[i].tile) {
            continue;
        }

        /* The SHORT name, in the 20 px face the rest of the panel reads its values in. The cells
         * are 44 px discs, which is why every word here is three letters: at 20 px a glyph is
         * about 10 px of advance, so three fill a third of the disc and four would touch its
         * rim. The point the name is hung on is the cell's own area centroid — see nav_measure()
         * — so the word sits in the middle of the tile it belongs to, not above it. */
        s_nav_label[i] = make_label(s_nav, PAGES[i].tile_label, &lv_font_anbscreen_20, COL_TEXT,
                                    LV_ALIGN_CENTER, s_nav_lx[i], s_nav_ly[i]);
        text_condensed(s_nav_label[i], 2);

        /*
         * A name is not a button. Every object is clickable by default, and a click that lands on
         * one is delivered to that object and stops there — it does not reach the curtain below,
         * which is the only thing on this screen that has a click handler. So a tap aimed at the
         * name of a section did nothing at all, while a tap a few pixels away opened a page, and
         * the map read as one whose touch areas do not match what it draws. With this the name is
         * transparent to the finger and nav_page_at() answers from the point alone.
         */
        lv_obj_set_clickable(s_nav_label[i], false);
    }

    /*
     * The arp notice's dimmer. It is created here, after everything the page draws and
     * before the transport, so that turning it on can lift itself over the sectors while
     * the transport stays above both — the transport is a screen, not a decoration, and
     * nothing on a page may cover it.
     *
     * A wash rather than a colour change: dimming each family's own surfaces would mean
     * touching every one of them, and the notice would still have to out-read them.
     */
    s_dim = make_panel(screen, BSP_LCD_H_RES, BSP_LCD_V_RES, COL_BG,
                       LV_ALIGN_CENTER, 0, 0);
    lv_obj_set_style_bg_opa(s_dim, LV_OPA_80, LV_PART_MAIN);
    /* It must not take the press. The sectors underneath are what a tap and a swipe are
     * for, and a clickable object would be the one the gesture bubbles from — and it has
     * no reason to bubble, so the swipe would simply not arrive at the screen's handler.
     * An unclickable object is skipped by the hit test; this states that outright rather
     * than inheriting it from make_panel(). */
    lv_obj_remove_flag(s_dim, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_remove_flag(s_dim, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_hidden(s_dim, true);

    /*
     * The transport screen: one big play/stop button and nothing else, for now.
     *
     * It replaces the disc that used to hang over the map's top edge and cover the
     * chips it sat above. A layer in the map's own sense — a full-screen object,
     * created after the map so that nothing on the map can reach over it, reached by
     * the one gesture the instrument had left: a swipe up. See screen_gesture_cb().
     *
     * The background is set at open time to the current family's tint; this is only
     * the value it boots with.
     */
    s_transport = lv_obj_create(real);
    lv_obj_set_size(s_transport, 360, 360);
    lv_obj_align(s_transport, LV_ALIGN_CENTER, 0, 0);
    lv_obj_set_scrollable(s_transport, false);
    lv_obj_set_style_bg_color(s_transport, lv_color_hex(COL_BG), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(s_transport, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_set_style_border_width(s_transport, 0, LV_PART_MAIN);
    lv_obj_set_style_radius(s_transport, 0, LV_PART_MAIN);
    lv_obj_set_style_pad_all(s_transport, 0, LV_PART_MAIN);
    lv_obj_set_clickable(s_transport, true);
    lv_obj_set_click_focusable(s_transport, false);
    /* Same as the map: a drag started on PLAY is a drag, and the screen has to hear its
     * press to know that. The button's own click is held back by swipe_just_happened(). */
    lv_obj_add_flag(s_transport, LV_OBJ_FLAG_EVENT_BUBBLE);
    /*
     * The swipe that leaves this screen starts ON this screen, so the gesture has to
     * reach screen_gesture_cb() on the object behind it. The map gets that for free —
     * it is built the same way and its swipe up to close has always worked — but the
     * transport is a screen with no other way out, so it asks for it out loud.
     */
    lv_obj_set_gesture_bubble(s_transport, true);
    lv_obj_set_hidden(s_transport, true);

    /*
     * THE TRANSPORT'S RING IS A PICTURE, exactly as the pages' ring is.
     *
     * 360x360 RGB565 in PSRAM, 253 KB, created before every other child of the curtain so
     * that the button, the two readouts and the marks all draw over it. The old lv_arc is
     * still built below and is merely hidden when this buffer exists — if the allocation
     * fails it is the ring, with the same geometry, colours and behaviour as before.
     */
    s_tempo_buf = lv_draw_buf_create(360, 360, LV_COLOR_FORMAT_RGB565, 0);

    if (s_tempo_buf == NULL) {
        ESP_LOGW(TAG, "transport: no room for the tempo ring, the arc stays");
    } else {
        s_tempo_img = lv_image_create(s_transport);

        if (s_tempo_img == NULL) {
            lv_draw_buf_destroy(s_tempo_buf);
            s_tempo_buf = NULL;
            ESP_LOGW(TAG, "transport: no image for the tempo ring, the arc stays");
        } else {
            lv_image_set_src(s_tempo_img, s_tempo_buf);
            lv_obj_set_pos(s_tempo_img, 0, 0);
            lv_obj_clear_flag(s_tempo_img, LV_OBJ_FLAG_SCROLLABLE);
            lv_obj_set_clickable(s_tempo_img, false);
            lv_obj_set_click_focusable(s_tempo_img, false);
            suppress_theme_focus_decoration(s_tempo_img);

            /* A defined picture from the first frame, even though the curtain boots hidden
             * and is painted whole before it is ever shown. */
            const uint16_t bg = lv_color_to_u16(lv_color_hex(COL_BG));

            for (int y = 0; y < 360; y++) {
                rim_row_fill_buf((uint16_t *)s_tempo_buf->data,
                                 s_tempo_buf->header.stride, y, 0, 359, bg);
            }
        }
    }

    /*
     * One button, big enough to hit without looking and well inside the ring's
     * band, which starts at 162: radius 80 against it, 82 px of air. The face is
     * the one the map's disc wore, so the control did not change its clothes when
     * it changed screens. The mark stays 46 px — only the diameter was asked to
     * change.
     */
    s_transport_btn = make_panel(s_transport, TRANSPORT_BTN_D, TRANSPORT_BTN_D,
                                 COL_ARC_BG, LV_ALIGN_CENTER, 0, 0);
    lv_obj_set_style_radius(s_transport_btn, LV_RADIUS_CIRCLE, LV_PART_MAIN);
    lv_obj_set_clickable(s_transport_btn, true);
    lv_obj_set_click_focusable(s_transport_btn, false);
    /* The modern setter rather than the deprecated lv_obj_add_flag(): a tap that lands
     * on the label has to reach the button. */
    lv_obj_set_event_bubble(s_transport_btn, true);
    lv_obj_add_event_cb(s_transport_btn, transport_run_cb, LV_EVENT_CLICKED, NULL);
    /* Held down, it dims — the same pressed-state rule as every other button here. */
    lv_obj_set_style_bg_opa(s_transport_btn, LV_OPA_70, LV_PART_MAIN | LV_STATE_PRESSED);

    /*
     * The action as a mark rather than a word: a square for stop, a triangle for play.
     *
     * Neither can be a character — the fonts here are ASCII only — so both are drawn. The square
     * is a plain panel. The triangle is a closed line, three sides with no fill: at this size and
     * this stroke it reads as the play mark does everywhere else, and it costs no asset.
     */
    s_transport_stop = lv_obj_create(s_transport_btn);
    lv_obj_set_size(s_transport_stop, TRANSPORT_MARK_D, TRANSPORT_MARK_D);
    lv_obj_align(s_transport_stop, LV_ALIGN_CENTER, 0, 0);
    lv_obj_set_style_bg_color(s_transport_stop, lv_color_hex(COL_STOP_RIM), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(s_transport_stop, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_set_style_border_width(s_transport_stop, 0, LV_PART_MAIN);
    lv_obj_set_style_radius(s_transport_stop, 4, LV_PART_MAIN);
    lv_obj_set_clickable(s_transport_stop, false);
    lv_obj_set_click_focusable(s_transport_stop, false);

    /* The points must outlive this call: lv_line keeps the pointer, not a copy. */
    static lv_point_precise_t tri[4];
    tri[0].x = 0;                     tri[0].y = 0;
    tri[1].x = TRANSPORT_TRI_W - 1;   tri[1].y = (TRANSPORT_TRI_H - 1) / 2;
    tri[2].x = 0;                     tri[2].y = TRANSPORT_TRI_H - 1;
    tri[3].x = 0;                     tri[3].y = 0;
    s_transport_play = lv_line_create(s_transport_btn);
    lv_line_set_points(s_transport_play, tri, 4);
    lv_obj_set_style_line_width(s_transport_play, TRANSPORT_TRI_STROKE, LV_PART_MAIN);
    lv_obj_set_style_line_rounded(s_transport_play, true, LV_PART_MAIN);
    lv_obj_set_clickable(s_transport_play, false);
    lv_obj_set_click_focusable(s_transport_play, false);
    /*
     * Then pushed right by a sixth of its width. A right-pointing triangle carries its weight on
     * the left of its own box, so a box centred on the button reads as sitting to the left; a
     * sixth of the width is where the drawn centre and the box centre meet. This is the one
     * placement here that is optical rather than geometric, and it is why the mark is placed by
     * hand instead of aligned.
     */
    lv_obj_align(s_transport_play, LV_ALIGN_CENTER, TRANSPORT_TRI_W / 6, 0);
    transport_refresh_run();

    /*
     * ПРЕСЕТЫ: кнопка на месте, где стоял заряд.
     *
     * Страница пресетов больше не носит плитки в шторке — её место занял микшер
     * дорожек, — поэтому вход в неё переехал сюда, на транспортную шторку. Кнопка
     * того же рода, что чипы на самой странице (LVGL-панель с подписью), и того же
     * цвета: серая плитка семейства пресетов, взятая на глубину поверхности.
     */
    s_transport_preset = make_panel(s_transport, TRANSPORT_PRESET_W, TRANSPORT_PRESET_H,
                                    tint(GROUP_COLOR[GRP_PRESET].tile, TINT_SEL),
                                    LV_ALIGN_CENTER, 0, TRANSPORT_BAT_Y);
    lv_obj_set_style_radius(s_transport_preset, TRANSPORT_PRESET_H / 2, LV_PART_MAIN);
    lv_obj_set_clickable(s_transport_preset, true);
    lv_obj_set_click_focusable(s_transport_preset, false);
    /* A tap that lands on the word has to reach the panel. */
    lv_obj_set_event_bubble(s_transport_preset, true);
    lv_obj_add_event_cb(s_transport_preset, transport_preset_cb, LV_EVENT_CLICKED, NULL);
    /* Held down, it dims — the same pressed-state rule as the button above it. */
    lv_obj_set_style_bg_opa(s_transport_preset, LV_OPA_70, LV_PART_MAIN | LV_STATE_PRESSED);
    {
        lv_obj_t *label = make_label(s_transport_preset, "PRESET", &lv_font_anbscreen_20,
                                     COL_TEXT, LV_ALIGN_CENTER, 0, 0);
        text_condensed(label, 0);
    }

    /*
     * Заряд — рядом с темпом, на одной с ним линии и в мелком шрифте: это чтение
     * прибора, а не значение, которое ставят ручкой, и место внизу теперь занято.
     * Смещение вправо от темпа, за его правый край, но внутри видимого круга.
     */
    s_battery_label = make_label(s_transport, "", &lv_font_anbscreen_14, COL_MUTED,
                                 LV_ALIGN_CENTER, TRANSPORT_BAT_X, TRANSPORT_BPM_Y);
    if (!bsp_battery_is_available()) {
        lv_obj_set_hidden(s_battery_label, true);
    }
    refresh_battery();

    /*
     * The tempo, above the button and symmetric with the battery below it: at y = -132 the
     * round panel is still 228 px across, and "200 BPM" is 72 px at the parameter face.
     *
     * It wears the size and the colour of a parameter's reading rather than the battery's.
     * The battery is a measurement of something the instrument cannot control and the tempo
     * is a value you set, and this is the one screen where the two sit together — so they
     * are not allowed to look like each other.
     */
    /*
     * The tempo's arc: the rim the pages wear, except that it goes all the way round.
     *
     * The band is the edge of the glass — 352 across with 7 px of padding puts the outer edge of
     * a 14 px band exactly on it, which is what the sector rims do and what "along the edge"
     * means everywhere else, at the same thickness. It is a full circle because the tempo
     * belongs to no family and to no sector, and it starts at the top so the fill grows
     * clockwise from under the BPM readout.
     *
     * The bright accent is what a rim shows when it is the value being turned, and the track is
     * COL_ARC_BG — the same near-black every other rim draws its unfilled part in — so the filled
     * and the empty part of this circle stand as far apart as they do on the pages.
     */
    s_tempo_arc = lv_arc_create(s_transport);
    lv_obj_set_size(s_tempo_arc, ARC_OBJ_SIZE, ARC_OBJ_SIZE);
    lv_obj_align(s_tempo_arc, LV_ALIGN_CENTER, 0, 0);
    lv_obj_set_style_pad_all(s_tempo_arc, 7, LV_PART_MAIN);
    lv_arc_set_rotation(s_tempo_arc, 270);
    lv_arc_set_bg_angles(s_tempo_arc, 0, 360);
    lv_arc_set_range(s_tempo_arc, 0, TRANSPORT_TEMPO_STEPS);
    lv_arc_set_value(s_tempo_arc, 0);
    lv_obj_set_style_arc_width(s_tempo_arc, ARC_W_IDLE, LV_PART_INDICATOR);
    lv_obj_set_style_arc_width(s_tempo_arc, ARC_W_IDLE, LV_PART_MAIN);
    lv_obj_set_style_arc_rounded(s_tempo_arc, false, LV_PART_INDICATOR);
    lv_obj_set_style_arc_rounded(s_tempo_arc, false, LV_PART_MAIN);
    lv_obj_set_style_arc_color(s_tempo_arc, lv_color_hex(COL_ACCENT), LV_PART_INDICATOR);
    lv_obj_set_style_arc_color(s_tempo_arc, lv_color_hex(COL_ARC_BG), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(s_tempo_arc, LV_OPA_TRANSP, LV_PART_KNOB);
    lv_obj_set_style_bg_opa(s_tempo_arc, LV_OPA_TRANSP, LV_PART_MAIN);
    lv_obj_set_clickable(s_tempo_arc, false);
    lv_obj_set_click_focusable(s_tempo_arc, false);
    suppress_theme_focus_decoration(s_tempo_arc);

    /* The same way the sector arcs are demoted: the widget keeps the geometry, the colours
     * and the value, and the picture is what the panel sees. Only a live buffer hides it;
     * without one this arc is the ring. */
    if (s_tempo_buf != NULL) {
        lv_obj_add_flag(s_tempo_arc, LV_OBJ_FLAG_HIDDEN);
    }

    /*
     * The picture is painted here, once, with the boot tint and the tempo the instrument
     * starts at. Opening the curtain then costs only the notches that actually changed, even
     * the first time; a family change repaints only the area outside the band.
     */
    tempo_ring_paint_all();

    s_tempo_label = make_label(s_transport, "", &lv_font_anbscreen_20, COL_TEXT,
                               LV_ALIGN_CENTER, 0, TRANSPORT_BPM_Y);
    refresh_tempo();

    /* Laid out once at start-up so the buttons have a size before the first
     * open; the animation then only moves the curtain. */
    nav_layout();
    nav_mark_current();

    /*
     * A new sound at every switch-on, if that is what the PATCH setting says.
     *
     * Exactly the long press's draw — preset_randomise(true), structure and all — because
     * there is only one randomiser on the device. It sits HERE, and where it sits is the whole
     * question this call had to answer.
     *
     * AFTER restore_settings(), which runs at the top of this function: in STORE the
     * remembered sound is already in place, and drawing over it would be the setting
     * lying about what it does. In FORGET and RANDOM restore_settings() has already
     * returned without touching the sound, so there is nothing to fight.
     *
     * AFTER every object the draw can reach exists. Checked rather than assumed, by
     * following the two things a draw does. write_param() touches no widget at all:
     * its settings branch only matches SYNTH_PARAM_SET_*, and SETTINGS_MAP holds
     * nothing else, so no apply_setting() runs; the patch note is skipped in RANDOM
     * mode; and synth_app_set_param() is a one-way call into the audio task, which
     * never calls back into this file. The draw's own tail is s_preset_dirty = true, and
     * the chip that shows it exists by here anyway (the preset page is built above), so
     * the not-saved mark is right from the first frame instead of appearing the first time
     * the page is opened. Nothing else
     * in this function is needed: no arc, panel, label or tile is read or written.
     *
     * BEFORE s_ready and goto_page(), so the page that is drawn immediately afterwards
     * already shows the new sound rather than the one it replaced. goto_page() is what
     * fills the sectors in — apply_page() ends in select_sector(), which refreshes the
     * panel and the value labels — so a draw placed after it would leave the first
     * screen stale until the next knob move.
     *
     * The preset SELECTION does not move: preset_randomise() is deliberate about that
     * (see its own comment) — a draw is a new sound in the slot you are standing on,
     * not a new slot. Two consequences are expected rather than defects: the dot is
     * lit, because the sound is now not what is stored, and the sound may differ from
     * whatever preset the selection is pointing at.
     */
    /*
     * The clock is read BEFORE the draw and put back AFTER it.
     *
     * It is the one number that survives the PATCH setting: a sound drawn at random at every
     * switch-on is a sound, and the tempo is where the player left the instrument. Read here
     * because the draw below writes the tempo through write_param(), which notes its own value
     * as the one to keep — applying the stored tempo afterwards is what leaves the key holding
     * the player's tempo rather than the randomiser's.
     */
    float kept_tempo = 0.0f;
    const bool tempo_kept = app_settings_tempo_load(&kept_tempo);

    if (app_settings_get(APP_SET_PATCH) == APP_PATCH_RANDOM) {
        preset_randomise(true);
    }

    if (tempo_kept) {
        synth_app_set_param(SYNTH_PARAM_SEQ_TEMPO, kept_tempo);

        char line[16];
        synth_app_tempo_text(line, sizeof(line));
        ESP_LOGI(TAG, "tempo kept from the last session: %s", line);
    }

    /*
     * Noted either way, so that the key exists from the first switch-on: a device whose tempo has
     * never been touched still remembers the tempo it started at, and the next boot has something
     * to keep. It costs a write once — the note is a no-op while the value agrees with the key.
     */
    app_settings_tempo_note(synth_app_get_param(SYNTH_PARAM_SEQ_TEMPO));

    /* The page that is entered on a knob other than the first entry of its table, named by
     * parameter rather than by index — see seed_selection(). */
    seed_selection(PAGE_FILTER, SYNTH_PARAM_CUTOFF);

    s_ready = true;
    goto_page(PAGE_DRONE);

#if !CONFIG_OBOD_SCREENSHOTS
    /*
     * Last, so the cover lands on top of a finished interface, and only when the
     * snapshot service is off — see the note on splash_build().
     */
    splash_build(screen);
#endif

    ESP_LOGI(TAG, "%d pages, %d parameters, rim sectors by count, swipe to turn the page",
             (int)PAGE_COUNT, (int)SYNTH_PARAM_COUNT);

#if CONFIG_OBOD_SCREENSHOTS
    /*
     * The end of start-up, and therefore where the snapshots begin: the interface is built, the
     * first page is open, and nothing but the drawing of it is still to come. screenshots.c
     * waits for that drawing and then walks the pages, so this call only starts a task.
     *
     * Last in the function on purpose — the walk freezes the interface for the better part of a
     * minute, and start-up has to be finished before anything is taken.
     */
    screenshots_start();
#endif
}


void synth_ui_ring_notify(uint8_t r, uint8_t g, uint8_t b, uint32_t hold_ms)
{
    s_ring_r = r;
    s_ring_g = g;
    s_ring_b = b;
    /* Last, so the colour is in place before the deadline can make it visible. */
    s_ring_until_ms = now_ms() + hold_ms;
}
