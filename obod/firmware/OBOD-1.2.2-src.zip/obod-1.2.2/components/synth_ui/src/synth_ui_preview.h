/*
 * The picture in the middle of the dial while a knob is turning.
 *
 * One 50x56 picture, one paint colour, one bit per pixel: 350 bytes that say what
 * the parameter under the hand does. The page's name steps aside for two seconds,
 * the picture steps in, and the name comes back where it was.
 *
 * WHY A MASK AND NOT AN lv_image. LVGL has no fast path for a 1-bit image: an I1
 * source is expanded while it is drawn, so every frame would decode the same 350
 * bytes and then blend 2,800 pixels through the generic path. The mask is instead
 * written straight into the layer's RGB565 buffer from an LV_EVENT_DRAW_MAIN
 * callback — the same trick the rim and the map use — so the cost of a frame is a
 * bit test per pixel and a store for the ones that are lit. Nothing is allocated,
 * nothing is decoded, and the buffer that is written is the one the panel is about
 * to receive.
 *
 * WHY THE PICTURES ARE DRAWN FROM TABLES. A curve is a polyline of four to eight
 * vertices or a walk along x over a 16-value table, linearly interpolated. There is
 * no logarithm, square root or exponential on any drawing path: the filter table is
 * a decibel response sampled once, offline, and the two reverb tables are decay
 * envelopes of the same kind. The only arithmetic a frame does is add, multiply and
 * compare.
 *
 * Nothing here touches LVGL. The caller owns the object, the colour and the moment;
 * this file owns the geometry.
 */
#pragma once

#include <stdint.h>

#include "synth_app.h"

#ifdef __cplusplus
extern "C" {
#endif

/* The picture's size in pixels, and its mask in bytes. 50 x 56 divides by 8
 * exactly: one row is 50 bits, so rows are a continuous bit stream and the mask is
 * exactly 350 bytes rather than the 392 a byte-aligned row would take. */
#define SYNTH_PREVIEW_W 50
#define SYNTH_PREVIEW_H 56
#define SYNTH_PREVIEW_BYTES ((SYNTH_PREVIEW_W * SYNTH_PREVIEW_H) / 8)

/* Which figure a parameter gets. PREVIEW_NONE means the page's name stays: there is
 * nothing honest to draw for that control at this size, and a placeholder would be
 * worse than the word it replaced. */
typedef enum {
    PREVIEW_NONE = 0,
    PREVIEW_ENV,        /* the lead's four envelope stages, the active one thicker */
    PREVIEW_FILTER,     /* the drone filter: log frequency, dB, peak never clipped */
    PREVIEW_COMP,       /* the master compressor's transfer curve in dB */
        PREVIEW_WAVE,       /* the selected oscillator shape */
    PREVIEW_DELAY,      /* decaying echoes: time to the right, level up */
    PREVIEW_VERB,       /* one reverb tail: level, size, damping */
    PREVIEW_VERB_MODE,  /* one tail per mode, the selected one thicker */

    /* The second set: the lead's own filter pair, the modulation page, the
     * settings rings and the generators' step figures. Appended, so every kind
     * above keeps the value it had when the first set was measured. */
    PREVIEW_LEAD_FILTER, /* the lead's response: same shape, its own corner and Q */
    PREVIEW_LEAD_ENV,    /* how far the lead's envelope moves the corner */
    PREVIEW_LFO,         /* the filter LFO's own waveform, eight entries */
    PREVIEW_RATE,        /* the drift's rate: cycles across one picture */
    PREVIEW_MOD_DEPTH,   /* the drift's depth: reference and current amplitude */
    PREVIEW_TRIG,        /* the modulation's trigger: an edge and an arrow */
    PREVIEW_MIC,         /* the microphone: capsule, bar and stand */
    PREVIEW_RING,        /* the LED ring filled to its value */
    PREVIEW_RING_MODE,   /* the ring split by its four modes */
    PREVIEW_DELAY_MODE,  /* tape against crossfade */
    PREVIEW_DELAY_SYNC,  /* the division grid with the chosen beat marked */
    PREVIEW_CHORUS,      /* two detuned copies of one wave */
    PREVIEW_LEVEL,       /* the master level: a bar filled to its value */
    PREVIEW_DUCK,        /* the ducking envelope: a dip on the hit and the return */
    PREVIEW_FOLLOW,      /* the drone line and the note that pulls it, or not */
    PREVIEW_WIDTH,       /* three registers, spread by the width */
    PREVIEW_ACCENT,      /* a weak onset and an accented one */
    PREVIEW_PERC_PITCH,  /* where the drum's band-pass sits on its axis */
    PREVIEW_PERC_QUANT,  /* the drum's pitch, quantised or not */
    PREVIEW_PERC_DECAY,  /* how long the hit rings */
    PREVIEW_PERC_BODY,   /* the click and the body of the hit */
    PREVIEW_PERC_ENV,    /* how far the drum's filter falls over the hit */
    PREVIEW_ARP,         /* the arpeggiator's staircase: dir, speed, len, range */
    PREVIEW_FILTER_MODE, /* the corner's shape: low, band, high, or between */
} synth_preview_kind_t;

/* What the middle should show for `param`, or PREVIEW_NONE. */
synth_preview_kind_t synth_preview_kind(synth_param_t param);

/*
 * Everything the picture depends on, quantised to the pixel grid and packed into
 * one word. Equal keys mean the 350 bytes would be identical, which is how a
 * redraw is skipped while a knob moves inside one screen pixel: the values are
 * quantised to 1/50 of the travel, the same 50 columns the mask is drawn on.
 */
uint32_t synth_preview_key(synth_param_t param);

/* Fill `mask` (SYNTH_PREVIEW_BYTES) with the picture for `param`'s current value. */
void synth_preview_mask(synth_param_t param, uint8_t *mask);

/*
 * Paint the lit bits of `mask` into an RGB565 buffer.
 *
 * `dst` points at the first visible pixel of the picture's box inside the layer,
 * `stride_px` is the layer's row stride in pixels, and (`mx`,`my`) is where the
 * visible rectangle starts inside the 50x56 mask. The caller has already clipped
 * against the layer, so nothing here writes outside `w` x `h`.
 */
void synth_preview_blit(const uint8_t *mask, uint16_t *dst, int stride_px,
                        int mx, int my, int w, int h, uint16_t colour);

#ifdef __cplusplus
}
#endif
