/*
 * The pictures themselves. See synth_ui_preview.h for why this is a bit mask, why
 * it is written into the layer by hand, and why every curve is a polyline or a
 * 16-value table.
 *
 * The coordinate system is the picture's own: x runs 0..49 from the left, y 0..55
 * from the top. The box is centred on the dial, so y = 28 is the middle of the
 * screen and the page's name's line; the name is 24 px of ink and the picture is
 * taller than that on purpose, so the same 50x56 can hold an envelope with a floor
 * and a ceiling and still leave the release somewhere to go.
 */
#include "synth_ui_preview.h"

#include <math.h>
#include <stdbool.h>
#include <string.h>


/*
 * The filter's response, sampled offline: a two-pole low-pass at Q = 0.9 over six
 * octaves, one entry per 0.4 octave, in decibels. 0 dB is the shelf; the peak at
 * the corner is the resonance the picture adds on top. The table is the whole of
 * the frequency axis: +3 octaves at entry 15, -3 at entry 0.
 */

/* One cycle of a sine, x100, sixteen points: the wave picture's sine. */
static const int8_t PV_SIN[16] = {
    0, 38, 71, 92, 100, 92, 71, 38, 0, -38, -71, -92, -100, -92, -71, -38,
};

/* Noise, x100: one pass across the picture, no period, no repeat. Fixed, so the
 * same shape is the same shape on every build and in every screenshot. */
static const int8_t PV_NOISE[16] = {
    30, -70, 55, -20, 85, -45, 10, 65, -85, 40, -10, 75, -55, 20, -35, 60,
};

/* Two reverb decays, x100 of the initial level. FAST is a small room, SLOW a
 * cathedral; SIZE blends between them and DAMP is the exponent of the fall. */
static const int8_t PV_TAIL_FAST[16] = {
    100, 71, 50, 35, 25, 18, 12, 9, 6, 4, 3, 2, 2, 1, 1, 1,
};
static const int8_t PV_TAIL_SLOW[16] = {
    100, 88, 78, 68, 60, 53, 47, 41, 36, 32, 28, 25, 22, 19, 17, 15,
};

/* The ducking envelope, x100 of its depth, sixteen points over the return. It
 * starts at the deepest point of the dip and climbs back to the top; the knob is
 * the depth, not the shape, so the shape is fixed. */
static const int8_t PV_DUCK[16] = {
    100, 78, 61, 48, 38, 30, 24, 19, 15, 12, 9, 7, 6, 5, 4, 3,
};

/* A microphone envelope, x100: four phrases of speech rather than a waveform.
 * Smooth enough that the 2 px stroke never folds onto itself. The microphone shape of
 * the LFO is not periodic at all: mod_value() returns the envelope, 0..1, and the
 * figure shows phrases rather than a period. */
static const int8_t PV_MIC_ENV[16] = {
    0, 42, 68, 30, 55, 80, 38, 18, 62, 90, 47, 22, 54, 71, 33, 8,
};

/* The unit circle sampled every 5.625 degrees, x1000. The ring and the capsule are
 * the only round figures, and they are drawn as a closed polyline of these points,
 * so no drawing path needs a sine, a cosine or a square root. */
static const int16_t PV_COS[64] = {
    1000, 995, 981, 957, 924, 882, 831, 773, 707, 634, 556, 471,
    383, 290, 195, 98, 0, -98, -195, -290, -383, -471, -556, -634,
    -707, -773, -831, -882, -924, -957, -981, -995, -1000, -995, -981, -957,
    -924, -882, -831, -773, -707, -634, -556, -471, -383, -290, -195, -98,
    0, 98, 195, 290, 383, 471, 556, 634, 707, 773, 831, 882,
    924, 957, 981, 995,
};
static const int16_t PV_CSIN[64] = {
    0, 98, 195, 290, 383, 471, 556, 634, 707, 773, 831, 882,
    924, 957, 981, 995, 1000, 995, 981, 957, 924, 882, 831, 773,
    707, 634, 556, 471, 383, 290, 195, 98, 0, -98, -195, -290,
    -383, -471, -556, -634, -707, -773, -831, -882, -924, -957, -981, -995,
    -1000, -995, -981, -957, -924, -882, -831, -773, -707, -634, -556, -471,
    -383, -290, -195, -98,
};

/* -------------------------------------------------------------------------- */
/* Raster                                                                     */
/* -------------------------------------------------------------------------- */

/* The vertical placement of the figure in the frame. Every figure is drawn around
 * its own natural baseline, and the values differ; this one offset centres the
 * whole picture without a second pass over the mask. It is set per kind before
 * the figure is drawn. */
static int s_pv_oy;
static int s_pv_ox;

static void pv_px(uint8_t *m, int x, int y)
{
    x += s_pv_ox;
    y += s_pv_oy;
    if (x < 0 || x >= SYNTH_PREVIEW_W || y < 0 || y >= SYNTH_PREVIEW_H) {
        return;
    }
    const int i = y * SYNTH_PREVIEW_W + x;
    m[i >> 3] |= (uint8_t)(0x80u >> (i & 7));
}

/* The common field every figure is drawn in. 44 x 40 with even extents, centred
 * in the 50 x 56 frame: a 3 px margin left and right, 8 px above and below. The
 * offset is +1 in x because 50 - 44 is 6 and the mask's rows are even: the field
 * itself starts on an odd column, which is what puts its two margins equal. A
 * stroke is still two pixels wide; only the frame's column parity changes. */
#define PV_FX0 2
#define PV_FX1 44
#define PV_FY0 8
#define PV_FY1 46

/* The square figures — the microphone's circle and the ring — are 40 x 40:
 * their height is the field's, and a circle has to have both measurements
 * equal. Natural blocks run 6..44, so the offset is -1 to put them at 5..44. */
#define PV_SX0 6
#define PV_SX1 44
#define PV_SY0 8
#define PV_SY1 46

/* Nearest even coordinate at or below v. Every stroke coordinate goes through
 * this: a 2 x 2 brush must sit on even columns, or it straddles an odd edge and
 * a run of two blocks measures three pixels. */
static int pv_even(int v)
{
    return v & ~1;
}

static void pv_stamp(uint8_t *m, int x, int y, int s);

/* a / b rounded to nearest, b > 0, away from zero on a tie. The stroke walks use
 * it instead of a float divide so the block that lands on the end coordinate is
 * exactly the end coordinate on every machine. */
static int pv_div_round(int a, int b)
{
    return a >= 0 ? (a + b / 2) / b : -((-a + b / 2) / b);
}

/* Is this pixel already inked? Used where a dot must not land on the solid
 * stroke, and for the dots' own gap. Offset is applied the same way as pv_px. */
static bool pv_ink(const uint8_t *m, int x, int y)
{
    x += s_pv_ox;
    y += s_pv_oy;
    if (x < 0 || x >= SYNTH_PREVIEW_W || y < 0 || y >= SYNTH_PREVIEW_H) {
        return false;
    }
    const int i = y * SYNTH_PREVIEW_W + x;
    return (m[i >> 3] & (uint8_t)(0x80u >> (i & 7))) != 0;
}

/* The 2 x 2 block at (x,y) has a one-pixel halo of free mask around it. */
static bool pv_clear(const uint8_t *m, int x, int y)
{
    for (int dy = -1; dy <= 2; dy++) {
        for (int dx = -1; dx <= 2; dx++) {
            if (pv_ink(m, x + dx, y + dy)) {
                return false;
            }
        }
    }
    return true;
}

/*
 * A stroke is a chain of 2 x 2 blocks whose centres step exactly 2 px along the
 * dominant axis. Thickness is therefore 2 px everywhere, including a 45 degree
 * slope, where the staircase is exact and does not breathe. Ends are snapped to
 * even coordinates: the brush never straddles an odd edge.
 *
 * The old way was Bresenham with the brush stamped at every point. On a slope
 * steeper than about 2:1 that puts two stamps on some rows and three columns of
 * ink on the transition rows — the 3-4 px the owner saw on the envelope's
 * attack, the ring and the chorus. Stepping the dominant axis by exactly two
 * cannot do that: the other axis moves by at most two per block, so a row or a
 * column never sees more than one block.
 */
static void pv_stroke(uint8_t *m, int x0, int y0, int x1, int y1)
{
    x0 = pv_even(x0);
    y0 = pv_even(y0);
    x1 = pv_even(x1);
    y1 = pv_even(y1);

    const int dx = x1 > x0 ? x1 - x0 : x0 - x1;
    const int dy = y1 > y0 ? y1 - y0 : y0 - y1;
    const int sx = x1 >= x0 ? 1 : -1;
    const int sy = y1 >= y0 ? 1 : -1;
    const int steps = (dx >= dy ? dx : dy) / 2;

    if (steps == 0) {
        pv_stamp(m, x0, y0, 2);
        return;
    }

    for (int i = 0; i <= steps; i++) {
        int x;
        int y;
        if (dx >= dy) {
            x = x0 + sx * 2 * i;
            /* The minor axis moves at most 2 per block; rounding to even keeps
             * every block on the brush grid, and the last one lands exactly. */
            y = pv_even(y0 + pv_div_round(sy * dy * i, steps));
        } else {
            y = y0 + sy * 2 * i;
            x = pv_even(x0 + pv_div_round(sx * dx * i, steps));
        }
        pv_stamp(m, x, y, 2);
    }
}

/* The same walk, a dot every other block: exactly a four-pixel pitch along the
 * dominant axis, each dot 2 x 2. This is the pattern the unselected tails and
 * the reference lines use; a dot that would touch ink already on the mask is
 * dropped, so a dotted copy never merges into the solid one. */
static void pv_stroke_dots(uint8_t *m, int x0, int y0, int x1, int y1)
{
    x0 = pv_even(x0);
    y0 = pv_even(y0);
    x1 = pv_even(x1);
    y1 = pv_even(y1);

    const int dx = x1 > x0 ? x1 - x0 : x0 - x1;
    const int dy = y1 > y0 ? y1 - y0 : y0 - y1;
    const int sx = x1 >= x0 ? 1 : -1;
    const int sy = y1 >= y0 ? 1 : -1;
    const int steps = (dx >= dy ? dx : dy) / 2;

    for (int i = 0; i <= steps; i += 2) {
        int x;
        int y;
        if (dx >= dy) {
            x = x0 + sx * 2 * i;
            y = pv_even(y0 + pv_div_round(sy * dy * i, steps == 0 ? 1 : steps));
        } else {
            y = y0 + sy * 2 * i;
            x = pv_even(x0 + pv_div_round(sx * dx * i, steps == 0 ? 1 : steps));
        }
        if (pv_clear(m, x, y)) {
            pv_stamp(m, x, y, 2);
        }
    }
    if ((steps & 1) != 0 && pv_clear(m, x1, y1)) {
        pv_stamp(m, x1, y1, 2);
    }
}


/* An s x s square with its top-left corner at (x,y): the brush every stroke
 * uses.
 * 2 is the instrument's own stroke width; there is no 3 anymore, selection is a
 * pattern.
 *
 * The square is the one thing every figure repeats thousands of times, so the
 * common case — wholly inside the mask — walks the bitstream instead of calling
 * pv_px nine times: one bounds test, one index, then a shift that carries into
 * the next byte. The clipped case still goes through pv_px, because that is what
 * pv_px is for. */
static void pv_stamp(uint8_t *m, int x, int y, int s)
{
    x += s_pv_ox;
    y += s_pv_oy;
    if (x >= 0 && y >= 0 && x + s <= SYNTH_PREVIEW_W && y + s <= SYNTH_PREVIEW_H) {
        for (int dy = 0; dy < s; dy++) {
            int i = (y + dy) * SYNTH_PREVIEW_W + x;
            uint8_t *p = m + (i >> 3);
            int sh = i & 7;

            for (int dx = 0; dx < s; dx++) {
                *p |= (uint8_t)(0x80u >> sh);
                if (++sh == 8) {
                    sh = 0;
                    ++p;
                }
            }
        }
        return;
    }

    for (int dy = 0; dy < s; dy++) {
        for (int dx = 0; dx < s; dx++) {
            pv_px(m, x + dx - s_pv_ox, y + dy - s_pv_oy);
        }
    }
}

/* Bresenham, with the brush stamped at every point. Used for the few-vertex
 * polylines: an envelope's four segments, the rate chevrons, the delay strokes. */

/*
 * One column of a curve that is walked along x: from y0 to y1, s pixels wide and
 * s pixels past the lower end, so a steep segment has no gap where the next column
 * starts. This is what makes a table-driven curve look drawn rather than plotted.
 */

/*
 * A reference line: 2 x 2 dots on a four-pixel pitch, two pixels of air between
 * them. This is how every line under a figure is drawn now — the unity diagonal of
 * the compressor, the register lines, a delay grid, a zero line. It is a different
 * PATTERN from the curve, not a thinner or dimmer stroke: the owner's rule is two
 * pixels everywhere, and a dot is two by two.
 */
/*
 * The field. Every graph is plotted from its own natural y values and then
 * scaled to the field's own extremes, so the same 44 x 40 box is filled by a
 * filter response, a reverb tail or a chorus, and no figure carries its own
 * idea of how tall it should be. A flat curve sits on the centre row.
 */
static void pv_plot(uint8_t *m, int x0, const int *y, int n)
{
    for (int i = 0; i + 2 < n; i += 2) {
        pv_stroke(m, x0 + i, y[i], x0 + i + 2, y[i + 2]);
    }
    if (((n - 1) & 1) != 0) {
        pv_stroke(m, x0 + n - 3, y[n - 3], x0 + n - 1, y[n - 1]);
    }
}

/*
 * The field. Every graph is plotted from its own natural y values and then
 * scaled to the field's own extremes, so the same 44 x 40 box is filled by a
 * filter response, a reverb tail or a chorus, and no figure carries its own
 * idea of how tall it should be. A flat curve sits on the centre row.
 *
 * The curve is a chain of 2 x 2 blocks, sampled every second column: a run per
 * column put two blocks on the same row at every cusp, and the cusp measured
 * four pixels wide.
 */
static void pv_curve(uint8_t *m, int x0, const int *y, int n)
{
    int lo = y[0];
    int hi = y[0];
    for (int i = 1; i < n; i++) {
        if (y[i] < lo) {
            lo = y[i];
        }
        if (y[i] > hi) {
            hi = y[i];
        }
    }
    const int span = hi - lo;
    int ny[64] = { 0 };
    int i_lo = 0;
    int i_hi = 0;
    for (int i = 0; i < n && i < 64; i++) {
        if (span < 2) {
            ny[i] = (PV_FY0 + PV_FY1) / 2;
        } else {
            ny[i] = pv_even(PV_FY0 + ((y[i] - lo) * (PV_FY1 - PV_FY0)) / span);
            if (y[i] == lo) {
                i_lo = i;
            }
            if (y[i] == hi) {
                i_hi = i;
            }
        }
    }
    pv_plot(m, x0, ny, n);
    /* The plot walks with a two pixel step and can step over the row it was
     * aiming at; the extremes are therefore stamped, so every curve fills the
     * field's height exactly instead of coming up a row short. */
    if (span >= 2) {
        pv_stamp(m, pv_even(x0 + i_lo), PV_FY0, 2);
        pv_stamp(m, pv_even(x0 + i_hi), PV_FY1, 2);
    }
}

static void pv_dot_line(uint8_t *m, int x0, int y0, int x1, int y1)
{
    pv_stroke_dots(m, x0, y0, x1, y1);
}

/* The dots around a circle: the same walk as the solid arc, one 2 x 2 block every
 * other block, so the pitch is four pixels along the dominant axis and no dot
 * touches the solid part. */
static void pv_dot_arc(uint8_t *m, int cx, int cy, int r, int i0, int i1)
{
    int x = pv_even(cx + (PV_COS[i0 & 63] * r) / 1000);
    int y = pv_even(cy + (PV_CSIN[i0 & 63] * r) / 1000);
    int n = 0;

    if (pv_clear(m, x, y)) {
        pv_stamp(m, x, y, 2);
    }

    int i = i0;
    while (i < i1) {
        int j = i + 1;
        int nx;
        int ny;
        for (;;) {
            const int k = j & 63;
            nx = pv_even(cx + (PV_COS[k] * r) / 1000);
            ny = pv_even(cy + (PV_CSIN[k] * r) / 1000);
            const int ax = nx > x ? nx - x : x - nx;
            const int ay = ny > y ? ny - y : y - ny;
            if (j >= i1 || ax >= 2 || ay >= 2) {
                break;
            }
            j++;
        }
        if ((++n & 1) == 0 && pv_clear(m, nx, ny)) {
            pv_stamp(m, nx, ny, 2);
        }
        x = nx;
        y = ny;
        i = j;
    }
}

static void pv_vline(uint8_t *m, int x, int y0, int y1, int s)
{
    for (int y = y0; y <= y1 + s - 1; y++) {
        for (int dx = 0; dx < s; dx++) {
            pv_px(m, x + dx, y);
        }
    }
}

/* x + 0.5, for a positive coordinate. The drawing paths only ever deal in
 * non-negative pixels, and this keeps them off libm's rounding. */
static int pv_round(float v)
{
    return (int)(v + 0.5f);
}

/* A 16-entry table at position pos = 0..15, linearly interpolated. */
static float pv_tab(const int8_t *t, float pos)
{
    if (pos <= 0.0f) {
        return (float)t[0];
    }
    if (pos >= 15.0f) {
        return (float)t[15];
    }
    const int i = (int)pos;
    const float f = pos - (float)i;
    return (float)t[i] + ((float)t[i + 1] - (float)t[i]) * f;
}

/* -------------------------------------------------------------------------- */
/* What a parameter shows, and the values behind it                           */
/* -------------------------------------------------------------------------- */

/* 0..50: the value on the picture's own 50-column grid. This is the quantisation
 * the whole feature is built on — the mask cannot show more than one pixel of
 * difference, so a change smaller than 1/50 of the travel is a change that would
 * redraw the same 350 bytes. */
static int pv_q(synth_param_t p)
{
    int q = pv_round(synth_app_get_param(p) * 50.0f);
    if (q < 0) {
        q = 0;
    } else if (q > 50) {
        q = 50;
    }
    return q;
}

static int pv_index(synth_param_t p, int count)
{
    if (count < 2) {
        return 0;
    }
    int i = pv_round(synth_app_get_param(p) * (float)(count - 1));
    if (i < 0) {
        i = 0;
    } else if (i > count - 1) {
        i = count - 1;
    }
    return i;
}

/*
 * The filter's DEPTH as the engine uses it: the knob's own travel plus WIDTH's
 * half share when the filter is one of the motion destinations. This mirrors
 * filter_depth_sum() in synth_app.cpp, and the number beside the knob on the page
 * is the same sum — the picture and the readout must not disagree about how far
 * the cutoff is swept.
 */
static int pv_filter_depth_q(void)
{
    /* DEST is FILTER / PAN / BOTH: PAN is the middle of the list and the only
     * destination that does not move the filter. */
    const int dest = (int)(synth_app_get_param(SYNTH_PARAM_MOD_DEST) * 2.0f + 0.5f);

    float depth = synth_app_get_param(SYNTH_PARAM_FILTER_DEPTH);
    if (dest != 1) {
        depth += 0.5f * synth_app_get_param(SYNTH_PARAM_MOTION_DEPTH);
        if (depth > 1.5f) {
            depth = 1.5f;
        }
    }

    int q = pv_round(depth * (50.0f / 1.5f));
    if (q < 0) {
        q = 0;
    } else if (q > 50) {
        q = 50;
    }
    return q;
}

typedef struct {
    uint8_t q[4];       /* 0..50 on the picture grid, or a list index in q[3] */
    uint8_t active;     /* the envelope stage the hand is on, 0..3 */
} pv_vals_t;

static synth_preview_kind_t pv_values(synth_param_t param, pv_vals_t *v)
{
    memset(v, 0, sizeof(*v));

    switch (param) {
    case SYNTH_PARAM_LEAD_ATTACK:
    case SYNTH_PARAM_LEAD_DECAY:
    case SYNTH_PARAM_LEAD_SUSTAIN:
    case SYNTH_PARAM_LEAD_RELEASE:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_LEAD_ATTACK);
        v->q[1] = (uint8_t)pv_q(SYNTH_PARAM_LEAD_DECAY);
        v->q[2] = (uint8_t)pv_q(SYNTH_PARAM_LEAD_SUSTAIN);
        v->q[3] = (uint8_t)pv_q(SYNTH_PARAM_LEAD_RELEASE);
        v->active = (uint8_t)(param == SYNTH_PARAM_LEAD_ATTACK ? 0
                            : param == SYNTH_PARAM_LEAD_DECAY   ? 1
                            : param == SYNTH_PARAM_LEAD_SUSTAIN ? 2
                                                               : 3);
        return PREVIEW_ENV;

    case SYNTH_PARAM_DRONE_FILTER_MODE:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_DRONE_FILTER_MODE);
        return PREVIEW_FILTER_MODE;

    case SYNTH_PARAM_LEAD_FILTER_MODE:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_LEAD_FILTER_MODE);
        return PREVIEW_FILTER_MODE;

    case SYNTH_PARAM_CUTOFF:
    case SYNTH_PARAM_RESONANCE:
    case SYNTH_PARAM_FILTER_DEPTH:
    case SYNTH_PARAM_FILTER_RATE:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_CUTOFF);
        v->q[1] = (uint8_t)pv_q(SYNTH_PARAM_RESONANCE);
        v->q[2] = (uint8_t)pv_filter_depth_q();
        v->q[3] = (uint8_t)pv_q(SYNTH_PARAM_FILTER_RATE);
        return PREVIEW_FILTER;

    case SYNTH_PARAM_MASTER_COMP:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_MASTER_COMP);
        return PREVIEW_COMP;

    case SYNTH_PARAM_LEAD_WAVE:
    case SYNTH_PARAM_DRONE_OSC_LOW:
    case SYNTH_PARAM_DRONE_OSC_MID:
    case SYNTH_PARAM_DRONE_OSC_HIGH:
        v->q[0] = (uint8_t)pv_index(param, synth_app_param_steps(param));
        return PREVIEW_WAVE;

    case SYNTH_PARAM_DELAY_MIX:
    case SYNTH_PARAM_DELAY_FEEDBACK:
    case SYNTH_PARAM_DELAY_TIME:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_DELAY_MIX);
        v->q[1] = (uint8_t)pv_q(SYNTH_PARAM_DELAY_FEEDBACK);
        v->q[2] = (uint8_t)pv_q(SYNTH_PARAM_DELAY_TIME);
        v->q[3] = (uint8_t)pv_index(SYNTH_PARAM_DELAY_SYNC,
                                    synth_app_param_steps(SYNTH_PARAM_DELAY_SYNC));
        return PREVIEW_DELAY;

    case SYNTH_PARAM_VERB_MIX:
    case SYNTH_PARAM_VERB_SIZE:
    case SYNTH_PARAM_VERB_DAMP:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_VERB_MIX);
        v->q[1] = (uint8_t)pv_q(SYNTH_PARAM_VERB_SIZE);
        v->q[2] = (uint8_t)pv_q(SYNTH_PARAM_VERB_DAMP);
        return PREVIEW_VERB;

    case SYNTH_PARAM_VERB_MODE: {
        const int count = synth_app_param_steps(SYNTH_PARAM_VERB_MODE);
        v->q[0] = (uint8_t)pv_index(SYNTH_PARAM_VERB_MODE, count);
        v->q[1] = (uint8_t)(count > 0 ? count : 1);
        return PREVIEW_VERB_MODE;
    }

    /* The lead's response is the drone's shape with the lead's own corner and Q:
     * the two filters are the same two-pole low-pass, so drawing them differently
     * would be inventing a difference the ear does not hear. */
    case SYNTH_PARAM_LEAD_CUTOFF:
    case SYNTH_PARAM_LEAD_RESO:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_LEAD_CUTOFF);
        v->q[1] = (uint8_t)pv_q(SYNTH_PARAM_LEAD_RESO);
        return PREVIEW_LEAD_FILTER;

    case SYNTH_PARAM_LEAD_ENV:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_LEAD_ENV);
        v->active = 0;
        return PREVIEW_LEAD_ENV;

    /* SHAPE, RATE and DEPTH are one figure: the same LFO wave, with the shape,
     * the period and the reach of the swing as the three things that change. */
    case SYNTH_PARAM_LFO_SHAPE:
    case SYNTH_PARAM_MOTION_RATE:
    case SYNTH_PARAM_MOD_DEPTH:
        v->q[0] = (uint8_t)pv_index(SYNTH_PARAM_LFO_SHAPE,
                                    synth_app_param_steps(SYNTH_PARAM_LFO_SHAPE));
        v->q[1] = (uint8_t)pv_q(SYNTH_PARAM_MOTION_RATE);
        v->q[2] = (uint8_t)pv_q(SYNTH_PARAM_MOD_DEPTH);
        v->q[3] = (uint8_t)pv_index(SYNTH_PARAM_MOD_TRIG,
                                    synth_app_param_steps(SYNTH_PARAM_MOD_TRIG));
        return PREVIEW_LFO;

    case SYNTH_PARAM_MOD_TRIG:
        v->q[0] = (uint8_t)pv_index(SYNTH_PARAM_MOD_TRIG,
                                    synth_app_param_steps(SYNTH_PARAM_MOD_TRIG));
        return PREVIEW_TRIG;

    case SYNTH_PARAM_SET_MIC:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_SET_MIC);
        return PREVIEW_MIC;

    /* The two brightnesses share one ring: a ring filled to a value is exactly
     * what both knobs do, and the readout beside them says which surface it is. */
    case SYNTH_PARAM_SET_RING:
    case SYNTH_PARAM_SET_SCREEN:
        v->q[0] = (uint8_t)pv_q(param);
        return PREVIEW_RING;

    case SYNTH_PARAM_SET_RINGMODE: {
        const int count = synth_app_param_steps(SYNTH_PARAM_SET_RINGMODE);
        v->q[0] = (uint8_t)pv_index(SYNTH_PARAM_SET_RINGMODE, count);
        v->q[1] = (uint8_t)count;
        return PREVIEW_RING_MODE;
    }

    case SYNTH_PARAM_DELAY_TIMEMODE:
        v->q[0] = (uint8_t)pv_index(SYNTH_PARAM_DELAY_TIMEMODE,
                                    synth_app_param_steps(SYNTH_PARAM_DELAY_TIMEMODE));
        return PREVIEW_DELAY_MODE;

    /* SYNC is the same comb with the division setting the spacing; the figure is
     * the delay's own, only the spacing changes. */
    case SYNTH_PARAM_DELAY_SYNC:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_DELAY_MIX);
        v->q[1] = (uint8_t)pv_q(SYNTH_PARAM_DELAY_FEEDBACK);
        v->q[2] = (uint8_t)pv_q(SYNTH_PARAM_DELAY_TIME);
        v->q[3] = (uint8_t)(1 + pv_index(SYNTH_PARAM_DELAY_SYNC,
                                         synth_app_param_steps(SYNTH_PARAM_DELAY_SYNC)));
        return PREVIEW_DELAY_SYNC;

    case SYNTH_PARAM_CHORUS_RATE:
    case SYNTH_PARAM_CHORUS_DEPTH:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_CHORUS_RATE);
        v->q[1] = (uint8_t)pv_q(SYNTH_PARAM_CHORUS_DEPTH);
        v->active = (uint8_t)(param == SYNTH_PARAM_CHORUS_RATE ? 0 : 1);
        return PREVIEW_CHORUS;

    case SYNTH_PARAM_LEVEL:
        /* MASTER's VOL. The owner asked for no graph of the volume: the arc and
         * the readout already say it, and a bar in the middle of the dial was one
         * more thing to read on a page that is a mixer, not a meter. */
        return PREVIEW_NONE;

    case SYNTH_PARAM_MASTER_DUCK:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_MASTER_DUCK);
        return PREVIEW_DUCK;

    case SYNTH_PARAM_DRONE_FOLLOW: {
        const int count = synth_app_param_steps(SYNTH_PARAM_DRONE_FOLLOW);
        v->q[0] = (uint8_t)pv_index(SYNTH_PARAM_DRONE_FOLLOW, count);
        v->q[1] = (uint8_t)count;
        return PREVIEW_FOLLOW;
    }

    case SYNTH_PARAM_MOTION_DEPTH:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_MOTION_DEPTH);
        return PREVIEW_WIDTH;

    case SYNTH_PARAM_SEQ_ACCENT:
        v->q[0] = (uint8_t)pv_index(SYNTH_PARAM_SEQ_ACCENT,
                                    synth_app_param_steps(SYNTH_PARAM_SEQ_ACCENT));
        return PREVIEW_ACCENT;

    case SYNTH_PARAM_PERC_PITCH:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_PERC_PITCH);
        return PREVIEW_PERC_PITCH;

    case SYNTH_PARAM_PERC_QUANT:
        v->q[0] = (uint8_t)pv_index(SYNTH_PARAM_PERC_QUANT,
                                    synth_app_param_steps(SYNTH_PARAM_PERC_QUANT));
        return PREVIEW_PERC_QUANT;

    case SYNTH_PARAM_PERC_DECAY:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_PERC_DECAY);
        return PREVIEW_PERC_DECAY;

    case SYNTH_PARAM_PERC_BODY:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_PERC_BODY);
        return PREVIEW_PERC_BODY;

    case SYNTH_PARAM_PERC_ENV:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_PERC_ENV);
        return PREVIEW_PERC_ENV;

    case SYNTH_PARAM_ARP_DIR:
    case SYNTH_PARAM_ARP_SPEED:
    case SYNTH_PARAM_ARP_LEN:
    case SYNTH_PARAM_ARP_RANGE:
        v->q[0] = (uint8_t)pv_index(SYNTH_PARAM_ARP_DIR,
                                    synth_app_param_steps(SYNTH_PARAM_ARP_DIR));
        v->q[1] = (uint8_t)pv_index(SYNTH_PARAM_ARP_SPEED,
                                    synth_app_param_steps(SYNTH_PARAM_ARP_SPEED));
        v->q[2] = (uint8_t)pv_index(SYNTH_PARAM_ARP_LEN,
                                    synth_app_param_steps(SYNTH_PARAM_ARP_LEN));
        v->q[3] = (uint8_t)pv_index(SYNTH_PARAM_ARP_RANGE,
                                    synth_app_param_steps(SYNTH_PARAM_ARP_RANGE));
        v->active = (uint8_t)(param == SYNTH_PARAM_ARP_DIR     ? 0
                            : param == SYNTH_PARAM_ARP_SPEED   ? 1
                            : param == SYNTH_PARAM_ARP_LEN     ? 2
                                                               : 3);
        return PREVIEW_ARP;

    default:
        return PREVIEW_NONE;
    }
}

synth_preview_kind_t synth_preview_kind(synth_param_t param)
{
    pv_vals_t v;
    return pv_values(param, &v);
}

uint32_t synth_preview_key(synth_param_t param)
{
    pv_vals_t v;
    const synth_preview_kind_t kind = pv_values(param, &v);

    if (kind == PREVIEW_NONE) {
        return 0;
    }

    /* Five bits of kind, two of focus, four six-bit values: one word still says
     * everything the 350 bytes depend on. The kind grew past four bits when the
     * second set arrived, so the fields were moved up rather than allowed to
     * overlap the old layout. */
    uint32_t key = (uint32_t)kind | ((uint32_t)(v.active & 0x03u) << 5);
    for (int i = 0; i < 4; i++) {
        key |= (uint32_t)(v.q[i] & 0x3Fu) << (7 + 6 * i);
    }
    return key;
}

/* -------------------------------------------------------------------------- */
/* The seven figures                                                          */
/* -------------------------------------------------------------------------- */

/*
 * ENVELOPE. Time runs left to right and only left to right: the attack rises, the
 * decay falls to the sustain, the sustain holds, the release falls to the floor.
 * The four stage widths are the four times on the same log axis the engine uses
 * (geom_for), so a longer attack is a wider attack; the sustain is a level and
 * takes a fixed share.
 *
 * The stage under the hand is solid; the other three are the same 2 px stroke in
 * 2 x 2 dots. One paint colour, so the stage is marked by pattern, never by
 * weight: a 3 px segment beside 2 px segments was the owner's first defect.
 */
static void pv_env(uint8_t *m, const pv_vals_t *v)
{
    enum { X0 = PV_FX0, X1 = PV_FX1, YB = PV_FY1, YT = PV_FY0 };
    const int avail = X1 - X0;

    /* A stage at zero is a vertical edge, not a very short diagonal. The old
     * share table started attack at 10% and pv_split forced every stage to at
     * least three pixels, so zero attack still leaned two pixels to the right.
     * Widths are now built from the knobs directly: zero is zero, the first
     * division is exactly one 2 px stroke. */
    int wa = 0, wd = 0, wr = 0;
    if (v->q[0] > 0) {
        wa = pv_even(pv_round((float)v->q[0] * 0.55f));
        if (wa < 2) wa = 2;
    }
    if (v->q[1] > 0) {
        wd = pv_even(pv_round((float)v->q[1] * 0.55f));
        if (wd < 2) wd = 2;
    }
    if (v->q[3] > 0) {
        wr = pv_even(pv_round((float)v->q[3] * 0.55f));
        if (wr < 2) wr = 2;
    }

    const int room = avail - 4;             /* the sustain keeps four pixels */
    if (wa + wd + wr > room) {
        const int sum = wa + wd + wr;
        if (wa) wa = (wa * room) / sum;
        if (wd) wd = (wd * room) / sum;
        if (wr) wr = (wr * room) / sum;
        if (wa) wa = pv_even(wa < 2 ? 2 : wa);
        if (wd) wd = pv_even(wd < 2 ? 2 : wd);
        if (wr) wr = pv_even(wr < 2 ? 2 : wr);
        while (wa + wd + wr > room) {
            if (wa >= wd && wa >= wr && wa > 2) {
                wa -= 2;
            } else if (wd >= wr && wd > 2) {
                wd -= 2;
            } else if (wr > 2) {
                wr -= 2;
            } else {
                break;
            }
        }
    }

    int ws = avail - wa - wd - wr;
    if (ws < 2) {
        ws = 2;
    }

    const int ys = (YB - pv_round((float)(YB - YT) * (float)v->q[2] * 0.02f)) & ~1;
    const int xa = (X0 + wa) & ~1;
    const int xd = (xa + wd) & ~1;
    const int xs = (xd + ws) & ~1;

    const int px[5] = { X0, xa, xd, xs, X1 };
    const int py[5] = { YB, YT, ys, ys, YB };

    for (int i = 0; i < 4; i++) {
        if (i == (int)v->active) {
            pv_stroke(m, px[i], py[i], px[i + 1], py[i + 1]);
        } else {
            pv_dot_line(m, px[i], py[i], px[i + 1], py[i + 1]);
        }
    }
}

/*
 * FILTER. The one picture that is a measurement rather than an illustration: a log
 * frequency axis, a decibel amplitude axis, and a peak that is never clipped.
 *
 * The dB window is fixed at +30..-42 over the picture's 47 rows, so the shelf sits
 * at row 27 and the tallest resonance the engine can make — about +18 dB at the
 * top of RES — reaches row 16, eleven rows below the frame. Below the corner the
 * response falls 12 dB per octave; the axis is six octaves wide, so the skirt
 * leaves the picture's bottom edge and does not hug the right one.
 *
 * DEPTH is not a shape of the static response, and pretending it was would be a
 * lie: it is how far the LFO sweeps the corner. The line along the top is that
 * sweep, centred on the corner, its length the span in octaves. RATE is the speed
 * of that sweep and changes nothing about the response; a speed has no shape, so
 * the picture does not invent a mark for it — the curve and the span are the whole
 * figure. CUTOFF moves the corner, RES its height, DEPTH the span.
 */
/*
 * The low-pass response of a two-pole filter, computed rather than looked up:
 *
 *   |H|^2 = 1 / ((1 - r^2)^2 + (r/Q)^2),  r = f / fc
 *
 * At r = 0 the response is exactly 0 dB (the shelf on the left), at r = 1 it is
 * 20 log10(Q) (the peak, which rises and narrows as Q rises), and far to the
 * right it falls 40 dB per decade. The table read it used to do had a flat top
 * eight columns wide and no dependence on RESONANCE, which is exactly what the
 * panel showed: a barge on the left and a pancake at the corner.
 *
 * The curve is then scaled to the field: the peak touches the top, the rolloff
 * touches the bottom. Growth of the peak therefore shows as the shelf sinking
 * further below it — the distance from shelf to peak is the resonance.
 */
static void pv_response(uint8_t *m, const pv_vals_t *v)
{
    enum { N = PV_FX1 - PV_FX0 + 1 };

    const float f = (float)v->q[0] * 0.02f;
    const float res = (float)v->q[1] * 0.02f;

    /* The knob's travel is bent so its steepest part is in the middle of the
     * range: the corner then moves most where the hand spends its time, and the
     * picture moves with it instead of crawling at the ends. */
    const float bend = f * f * (3.0f - 2.0f * f);
    const float fc = 0.16f + 0.60f * bend;

    /* The hump: a corner at the top and wide shoulders, so that a quarter turn
     * of RESONANCE lifts the whole neighbourhood of the corner rather than one
     * column. An exponent of 1.2 gives a point at the top and a broad base. */
    const float pk = 0.5f + 13.5f * res;
    const float w = 0.18f;

    /* The window is 22 dB tall, not the 48 of a real response: the point here is
     * to show the turn of the knob, not to be a datasheet. */
    const float top = 14.0f;
    const float bot = -8.0f;
    const float inv_x = 1.0f / (float)(PV_FX1 - PV_FX0);

    int ys[N];
    for (int x = PV_FX0; x <= PV_FX1; x++) {
        const float u = (float)(x - PV_FX0) * inv_x;
        float db = 0.0f;
        if (u > fc) {
            const float s = (u - fc) / (1.0f - fc);
            db = -14.0f * powf(s, 1.6f);
        }
        const float du = fabsf(u - fc) / w;
        db += pk * expf(-powf(du, 1.2f));
        if (db > top) {
            db = top;
        } else if (db < bot) {
            db = bot;
        }
        ys[x - PV_FX0] = pv_round((float)PV_FY0 +
                                  (top - db) * (float)(PV_FY1 - PV_FY0) / (top - bot));
    }
    /* Scaled to its own extremes: the field is the frame for every figure, so the
     * response fills 44 x 40 at any cutoff and resonance rather than leaving the
     * top rows empty where a dotted rail used to sit. */
    pv_curve(m, PV_FX0, ys, N);
}

static void pv_filter(uint8_t *m, const pv_vals_t *v)
{
    pv_response(m, v);
}

/*
 * COMPRESSOR. Input dB against output dB, the same 48 dB on both axes, with the
 * same soft knee the rack's gain computer uses (6 dB wide). The dashed diagonal is
 * unity: the compressor is the distance between the two lines, and at COMP = 0
 * they coincide. The curve is the gain reduction itself, with no makeup: makeup
 * would lift the below-threshold half off the diagonal and hide the very thing
 * the picture is for. The shelf therefore sits under the diagonal by exactly the
 * reduction, which is what the owner asked to see.
 *
 * The ratio is not a second knob: the rack derives it from the same amount
 * (synth_rack_comp_ratio), 1:1 at COMP = 0 and 8:1 at the top. Reading a ratio
 * value of its own here left the curve on the unity line for every compression
 * the instrument can make, which is exactly what the owner saw.
 */
static void pv_comp(uint8_t *m, const pv_vals_t *v)
{
    enum { X0 = PV_FX0, X1 = PV_FX1, YT = PV_FY0, YB = PV_FY1, KNEE = 6 };

    const float amount = (float)v->q[0] * 0.02f;
    const float th = -30.0f * amount;
    const float ratio = 1.0f + 15.0f * amount;
    const float slope = 1.0f - 1.0f / ratio;
    const float db_per_x = 48.0f / (float)(X1 - X0);
    const float px_per_db = (float)(YB - YT) / 48.0f;

    /* The unity line is a reference, not the measured curve: it stays dotted so
     * the eye can tell the two apart where the curve runs close to it. */
    pv_stroke_dots(m, X0, YB, X1, YT);
    pv_stamp(m, X1, YT, 2);
    pv_stamp(m, X0, YB, 2);

    int ys[64];
    int n = 0;
    for (int x = X0; x <= X1; x++, n++) {
        const float indb = -48.0f + (float)(x - X0) * db_per_x;
        const float over = indb - th;

        float gain = 0.0f;
        if (over > (float)KNEE * 0.5f) {
            gain = -slope * over;
        } else if (over > -(float)KNEE * 0.5f) {
            const float t = over + (float)KNEE * 0.5f;
            gain = -slope * t * t * (1.0f / (2.0f * (float)KNEE));
        }

        const float out = indb + gain;
        int y = pv_round((float)YB - (out + 48.0f) * px_per_db);
        if (y < YT) {
            y = YT;
        } else if (y > YB) {
            y = YB;
        }
        ys[n] = y;
    }
    pv_curve(m, X0, ys, n);
}



/* The shape of one oscillator at u = 0..1 across the picture, -1..1. */
static float pv_wave_y(int shape, float u)
{
    switch (shape) {
    case 0: {                               /* SIN */
        float ph = u * 2.0f;
        ph -= (float)(int)ph;
        return pv_tab(PV_SIN, ph * 16.0f) * 0.01f;
    }
    case 1: {                               /* TRI */
        float ph = u * 2.0f;
        ph -= (float)(int)ph;
        const float d = ph - 0.5f;
        return 4.0f * (d < 0.0f ? -d : d) - 1.0f;
    }
    case 2: {                               /* SAW */
        float ph = u * 1.75f;
        ph -= (float)(int)ph;
        return 1.0f - 2.0f * ph;
    }
    case 3: {                               /* SQR */
        float ph = u * 2.0f;
        ph -= (float)(int)ph;
        return ph < 0.5f ? 1.0f : -1.0f;
    }
    case 5: {                               /* NSE */
        int i = (int)(u * 15.0f);
        if (i > 15) {
            i = 15;
        }
        return (float)PV_NOISE[i] * 0.01f;
    }
    default:
        return 0.0f;
    }
}

static void pv_wave(uint8_t *m, const pv_vals_t *v)
{
    enum { X0 = PV_FX0, X1 = PV_FX1, MID = (PV_FY0 + PV_FY1) / 2,
           AMP = (PV_FY1 - PV_FY0) / 2 };
    const int shape = v->q[0];
    const float inv_x = 1.0f / (float)(X1 - X0);

    /* SPR. One saw with its detuned twin: two parallel descents and the same
     * field as every other wave. */
    if (shape == 4) {
        const int peak = X1 - 4;
        pv_stroke(m, X0, PV_FY1, peak, PV_FY0);
        pv_vline(m, peak, PV_FY0, PV_FY1, 2);
        for (int y = PV_FY0; y <= PV_FY1; y += 4) {
            pv_stamp(m, X1, y, 2);
        }
        return;
    }

    /* NSE. Sample-and-hold steps four pixels wide, their own levels scaled to
     * the field so the noise figure has the same height as a sine. */
    if (shape == 5) {
        int lv[12];
        int lo = PV_NOISE[0];
        int hi = PV_NOISE[0];
        for (int i = 0; i < 12; i++) {
            lv[i] = PV_NOISE[i];
            if (lv[i] < lo) {
                lo = lv[i];
            }
            if (lv[i] > hi) {
                hi = lv[i];
            }
        }
        const int span = (hi > lo) ? hi - lo : 1;
        int prev = -1;
        int idx = 0;
        for (int x = X0; x <= X1; x += 4, idx++) {
            const int y = pv_even(PV_FY0 + ((hi - lv[idx > 11 ? 11 : idx])
                                            * (PV_FY1 - PV_FY0)) / span);
            if (prev >= 0 && y != prev) {
                pv_stroke(m, x, prev, x, y);
            }
            const int xe = (x + 2 > X1) ? X1 : x + 2;
            pv_stroke(m, x, y, xe, y);
            prev = y;
        }
        return;
    }

    int ys[64];
    int n = 0;
    for (int x = X0; x <= X1; x++, n++) {
        const float u = (float)(x - X0) * inv_x;
        ys[n] = pv_round((float)MID - pv_wave_y(shape, u) * (float)AMP);
    }
    pv_curve(m, X0, ys, n);
}

/*
 * DELAY. Echoes, each a 2 px upright stroke: time runs to the right, level rises
 * from the floor, and each repeat is quieter than the one before by the
 * feedback. Not bars — a bar at this size is a block, and the instrument's own
 * marks are strokes.
 *
 * The spacing is the delay time. In FREE it is the TIME knob, and the empty gap
 * between two repeats runs from 2 px at the bottom of the knob to 12 px at the
 * top in steps of 2 px. The pitch is the gap plus the 2 px stroke; the number of
 * repeats follows the pitch, because a longer delay has room for fewer echoes in
 * the same 44 px window. In a division it is the division, longest at the left
 * of the list and shortest at the right.
 *
 * There is no dry rail any more. The owner's rule is that only data stays in the
 * frame, and a line that does not move with a knob is not data. The first echo
 * itself is at the field's top, so the decay fills the height on its own.
 */
static void pv_delay(uint8_t *m, const pv_vals_t *v)
{
    enum { YB = PV_FY1, YT = PV_FY0 };

    if (v->q[0] < 1) {                      /* MIX at zero: the dry floor */
        pv_stroke(m, PV_FX0, PV_FX1, YB, YB);
        return;
    }

    int pitch;
    if (v->q[3] == 0) {                     /* FREE: the TIME knob */
        /* q[2] is 0..50; every 10 units of it is one 2 px step of the gap. */
        const int gap = 2 + 2 * ((int)v->q[2] / 10);
        pitch = gap + 2;
    } else {                                /* a division: longest first */
        pitch = 4 + (11 - (int)v->q[3]) / 2;
    }
    if (pitch < 4) {
        pitch = 4;
    }
    pitch &= ~1;

    const float fb = 0.35f + 0.60f * (float)v->q[1] * 0.02f;

    /* The echoes are spread across the whole 44 px field, first bar at the left
     * edge and last at the right one. With a fixed pitch the last bar stopped two
     * pixels short at some times; the gap is now the average the knob asks for,
     * and the right edge is always reached. */
    int taps = 1 + (PV_FX1 - PV_FX0) / pitch;
    if (taps < 2) {
        taps = 2;
    } else if (taps > 11) {
        taps = 11;
    }

    /* The first repeat stands at the mix level, not at full height: MIX is the
     * wet amount, so at 25 % the whole series is a quarter of the field high and
     * at 100 % it starts at the ceiling. Without that factor the three mix
     * positions drew the same picture, which the owner read as a dead knob. */
    const float wet = 0.15f + 0.85f * (float)v->q[0] * 0.02f;
    float hh = (float)(YB - YT) * wet;
    for (int i = 0; i < taps; i++) {
        const int x = pv_even(PV_FX0 + (i * (PV_FX1 - PV_FX0)) / (taps - 1));
        int h = pv_even(pv_round(hh));
        if (h < 2) {
            h = 2;
        }
        pv_vline(m, x, YB - h, YB, 2);
        hh *= fb;
    }
}

/*
 * REVERB. A solid wall of direct sound on the left, then the reflections: 2x2
 * dots on a four-pixel grid, thinning out to the right until the field is empty.
 * That is the metaphor the owner asked for and signed off, and it replaces the
 * decaying level curve, which said "one echo getting quieter" rather than "a
 * room filling with reflections".
 *
 * The four-pixel grid is what keeps the figure legal: 2 px of ink and 2 px of
 * air in both directions, so the dots can never melt into a stroke. The scatter
 * is a hash of the cell, not a random generator, so the same value draws the
 * same picture on every redraw — a preview that reshuffles while the hand is
 * still would shimmer.
 *
 * MIX  how many reflections there are at all; zero is the bare wall.
 * SIZE how far the field reaches: a small room dies out mid-field, a hall keeps
 *      going to the right edge.
 * DAMP how fast it thins: a dead room drops to single dots in two columns.
 */
static uint32_t pv_hash(int a, int b)
{
    uint32_t h = (uint32_t)(a * 73856093) ^ (uint32_t)(b * 19349663);
    h ^= h >> 13;
    h *= 0x5bd1e995u;
    h ^= h >> 15;
    return h;
}

static void pv_reverb_field(uint8_t *m, float mix, float size, float damp)
{
    enum { X0 = PV_FX0, X1 = PV_FX1, YT = PV_FY0, YB = PV_FY1 };

    /* The wall: the direct sound, two pixels wide and the full height. */
    pv_vline(m, X0, YT, YB - 1, 2);
    if (mix < 0.02f) {
        return;
    }

    const int cells_x = (X1 - X0 - 4) / 4;
    const int cells_y = (YB - YT + 3) / 4;
    int reach = 3 + (int)((float)(cells_x - 3) * size + 0.5f);
    if (reach < 1) {
        reach = 1;
    } else if (reach > cells_x) {
        reach = cells_x;
    }
    /* 1.2 is the gentle fall; 4.2 leaves two live columns and then air. The
     * density starts from a floor rather than from MIX alone: a quarter of the
     * wet signal still fills the first column with reflections, and the knob's
     * travel changes how much of the field survives, not whether it exists. */
    const float k = 0.6f + 3.4f * damp;
    const float p0 = 0.45f + 0.55f * mix;

    for (int i = 0; i < reach; i++) {
        const int x = X0 + 4 + i * 4;
        const float t = ((float)i + 0.5f) / (float)reach;
        const float p = p0 * powf(1.0f - t, k);

        /* An ordered column: the dots are spread evenly down the height, with a
         * per-column phase from the hash. Testing every cell against a random
         * number instead left holes and clumps — one column would lose its
         * middle and the field read as two clusters, which is not a gradient. */
        int count = (int)((float)cells_y * p + 0.5f);
        if (count <= 0) {
            continue;
        }
        const int phase = (int)(pv_hash(i, 7) % (uint32_t)cells_y);
        for (int n = 0; n < count; n++) {
            const int j = (phase + n * cells_y / count) % cells_y;
            pv_stamp(m, x, YT + j * 4, 2);
        }
    }
}

static void pv_verb(uint8_t *m, const pv_vals_t *v)
{
    pv_reverb_field(m,
                    (float)v->q[0] * 0.02f,
                    (float)v->q[1] * 0.02f,
                    (float)v->q[2] * 0.02f);
}

/*
 * REVERB MODE. The same field, one room per mode: a small room reaches three
 * columns and thins fast, a hall reaches the edge and holds. The knob is a list,
 * so the four pictures are four fixed rooms; MIX is left at a readable level
 * because this figure is about the shape, not about the amount.
 */
static void pv_verb_mode(uint8_t *m, const pv_vals_t *v)
{
    const int count = (v->q[1] < 2) ? 1 : v->q[1];
    const int mode = v->q[0];
    const float t = (count > 1) ? (float)mode / (float)(count - 1) : 0.0f;

    pv_reverb_field(m, 0.95f, 0.25f + 0.75f * t, 1.0f - 0.8f * t);
}

/* -------------------------------------------------------------------------- */
/* The second set: round figures, step figures, and the lead's own two        */
/* -------------------------------------------------------------------------- */

/* One arc of that circle, from index i0 to i1 (i1 may run past 63). The caller
 * leaves the gaps between the sectors of a ring by choosing where it starts and
 * stops. */
static void pv_circle_arc(uint8_t *m, int cx, int cy, int r, int i0, int i1)
{
    int x = pv_even(cx + (PV_COS[i0 & 63] * r) / 1000);
    int y = pv_even(cy + (PV_CSIN[i0 & 63] * r) / 1000);

    pv_stamp(m, x, y, 2);

    /* Walk the angle by the step that moves the arc two pixels along the
     * dominant axis, not by a fixed number of degrees. A fixed step gives the
     * top of the circle a one-pixel advance per segment and the 45 degree part
     * three, which is exactly how the arc used to breathe. */
    int i = i0;
    while (i < i1) {
        int j = i + 1;
        int nx;
        int ny;
        for (;;) {
            const int k = j & 63;
            nx = pv_even(cx + (PV_COS[k] * r) / 1000);
            ny = pv_even(cy + (PV_CSIN[k] * r) / 1000);
            const int ax = nx > x ? nx - x : x - nx;
            const int ay = ny > y ? ny - y : y - ny;
            if (j >= i1 || ax >= 2 || ay >= 2) {
                break;
            }
            j++;
        }
        pv_stroke(m, x, y, nx, ny);
        x = nx;
        y = ny;
        i = j;
    }
}

/*
 * LEAD FILTER. The same measurement as the drone's response, with the lead's own
 * corner and Q: the lead's filter is the same two-pole low-pass, so the picture
 * would be a lie if it changed shape. There is no DEPTH bracket and no RATE
 * chevrons here because the lead page has no such knobs — its ENV is the next
 * picture along, and it moves the corner rather than the span.
 */
static void pv_lead_filter(uint8_t *m, const pv_vals_t *v)
{
    /* The lead's response is the drone's measurement with the lead's own corner
     * and Q: same two-pole shape, same field. */
    pv_response(m, v);
}

/*
 * LEAD ENV. How far the envelope moves the corner, in octaves: the line starts on
 * the unmodulated cutoff and the shelf it settles on is the amount. Positive opens
 * upward, negative closes downward. The level it starts and ends on is the cutoff
 * the knob is set to; no tick marks it, because the curve itself leaves from
 * there and a second mark would only repeat the line.
 */
static void pv_lead_env(uint8_t *m, const pv_vals_t *v)
{
    enum { N = 5 };
    const float oct = -3.0f + 8.0f * (float)v->q[0] * 0.02f;
    const int xs[N] = { PV_FX0, 14, 22, 38, PV_FX1 };
    /* Natural units: the unmodulated line, the shelf the envelope reaches, and
     * the sustain it holds. Normalised below, so the envelope always fills the
     * field and the amount is the shape, not the size. */
    const int base = 30;
    const int shelf = base - pv_round(oct * 3.0f);
    const int sustain = shelf + (base - shelf) / 5;
    const int ys[N] = { base, shelf, sustain, sustain, base };

    int lo = ys[0];
    int hi = ys[0];
    for (int i = 1; i < N; i++) {
        if (ys[i] < lo) {
            lo = ys[i];
        }
        if (ys[i] > hi) {
            hi = ys[i];
        }
    }
    const int span = (hi > lo) ? hi - lo : 1;

    for (int i = 0; i + 1 < N; i++) {
        const int ya = pv_even(PV_FY0 + ((hi - ys[i]) * (PV_FY1 - PV_FY0)) / span);
        const int yb = pv_even(PV_FY0 + ((hi - ys[i + 1]) * (PV_FY1 - PV_FY0)) / span);
        pv_stroke(m, xs[i], ya, xs[i + 1], yb);
    }
}

/*
 * LFO SHAPE. The filter LFO's source, drawn as the wave it is. The eight entries
 * are not all waves — EXP+ and EXP- are ramps that fall like a saw, and MIC is an
 * envelope with no period at all — so each gets its own walk rather than being
 * forced through the oscillator table. RANDOM holds its value for five columns so
 * two strokes never merge into a block.
 */
static void pv_lfo(uint8_t *m, const pv_vals_t *v)
{
    enum { X0 = PV_FX0, X1 = PV_FX1, MID = (PV_FY0 + PV_FY1) / 2,
           AMP = (PV_FY1 - PV_FY0) / 2 };

    const int shape = v->q[0];
    const float cycles = 1.0f + 2.0f * (float)v->q[1] * 0.02f;
    const float depth = (float)v->q[2] * 0.02f;
    const float phase = (float)v->q[3] * 0.02f;
    const float inv_x = 1.0f / (float)(X1 - X0);

    /* No rails: the wave's own reach at full depth is the field's height, so the
     * scale comes from the data and not from a frame. At zero DEPTH the figure is
     * the centre line, which is the honest picture of a modulation doing nothing.
     *
     * The reach is not the same for all eight: SINE, TRI, SQUARE and SAW swing both
     * ways, while EXP+ and EXP- only fall and the microphone only rises. The figure
     * keeps that: a wave that pushes one way is drawn on one side of the centre line,
     * because that is what the modulation does. */

    int ys[64];
    int n = 0;
    int hold = 0;
    float held = 0.0f;
    for (int x = X0; x <= X1; x++, n++) {
        const float u = (float)(x - X0) * inv_x;
        float ph = u * cycles + phase;
        ph -= (float)(int)ph;

        switch (shape) {
        case 0:                             /* SINE */
            held = pv_tab(PV_SIN, ph * 16.0f) * 0.01f;
            break;
        case 1: {                           /* TRI */
            const float d = ph - 0.5f;
            held = 4.0f * (d < 0.0f ? -d : d) - 1.0f;
            break;
        }
        case 2:                             /* SQUARE */
            held = ph < 0.5f ? 1.0f : -1.0f;
            break;
        case 3:                             /* SAW */
            held = 1.0f - 2.0f * ph;
            break;
        case 4:                             /* RANDOM: a new value every five columns */
            if (hold == 0) {
                hold = 5;
                held = (float)PV_NOISE[(n / 5) & 15] * 0.01f;
            }
            hold--;
            break;
        case 5:                             /* EXP+: from the centre down to the bottom */
            held = -expf(-6.0f * (1.0f - ph));
            break;
        case 6:                             /* EXP-: from the bottom up to the centre */
            held = -expf(-6.0f * ph);
            break;
        default:                            /* MIC: the envelope, 0..1, one way only */
            held = pv_tab(PV_MIC_ENV, ph * 15.0f) * 0.01f;
            break;
        }

        ys[n] = pv_round((float)MID - held * depth * (float)AMP);
    }
    pv_plot(m, X0, ys, n);
}


/*
 * RATE. How many periods of the drift fit in the same width: half a period at the
 * bottom, three and a half at the top. The height does not change, because the
 * knob changes frequency and not depth — that is the picture next to it.
 */


/*
 * MOD DEPTH. Two waves, one amplitude: the full-travel reference in 2 px and the
 * current value over it in 3 px. At the bottom the bright one is almost flat; at
 * the top it covers the reference exactly. There is no second colour to say
 * "reference", so the reference is the thinner line.
 */


/*
 * TRIG. A trigger is a front, so the picture is a front: a low line, a rise, a
 * high plate and a fall. The five sources are the five gates the modulation can be
 * restarted by — one free edge, then note, hold, one-shot and step, which are a
 * shorter gate, a long gate, a narrow pulse and a train. The gate lengths are the
 * whole difference; an arrow over the edge said nothing the edge did not.
 */
static void pv_trig(uint8_t *m, const pv_vals_t *v)
{
    enum { X0 = PV_FX0, X1 = PV_FX1, LO = PV_FY1, HI = PV_FY0 };

    pv_stroke(m, X0, LO, X0 + 2, LO);

    switch (v->q[0]) {
    case 1:                                 /* NOTE: one pulse */
        pv_stroke(m, X0, LO, 14, LO);
        pv_stroke(m, 14, LO, 14, HI);
        pv_stroke(m, 14, HI, 26, HI);
        pv_stroke(m, 26, HI, 26, LO);
        pv_stroke(m, 26, LO, X1, LO);
        break;
    case 2:                                 /* HOLD */
        pv_stroke(m, X0, LO, 18, LO);
        pv_stroke(m, 18, LO, 18, HI);
        pv_stroke(m, 18, HI, X1, HI);
        pv_stroke(m, X1, HI, X1, LO);
        break;
    case 3:                                 /* ONES */
        pv_stroke(m, X0, LO, 10, LO);
        pv_stroke(m, 10, LO, 10, HI);
        pv_stroke(m, 10, HI, X1, HI);
        pv_stroke(m, X1, HI, X1, LO);
        break;
    default:                                /* STEP: three pulses */
        pv_stroke(m, X0, LO, 6, LO);
        for (int i = 0; i < 3; i++) {
            const int at = 6 + i * 13;
            pv_stroke(m, at, LO, at, HI);
            pv_stroke(m, at, HI, at + 4, HI);
            pv_stroke(m, at + 4, HI, at + 4, LO);
            pv_stroke(m, at + 4, LO, (i == 2) ? X1 : at + 13, LO);
        }
        break;
    }
}

/*
 * MIC. The input gain, as the transfer it is: the line's slope is the gain, flat
 * at 0 % and 45 degrees at 100 %. A microphone was a symbol, not a graph, and the
 * crossbar and the foot were its most decorative parts; the gain itself is a
 * straight line and needs no picture of a capsule.
 */
static void pv_mic(uint8_t *m, const pv_vals_t *v)
{
    (void)v;

    /* A microphone drawn as the owner asked: one plain circle of even diameter
     * and nothing else. Diameter 40, two-pixel stroke, centred. RING is the same
     * circle with a filled arc; the fill, not a grille, is what tells them
     * apart. */
    enum { CX = 25, CY = 27, R = 19 };
    pv_circle_arc(m, CX, CY, R, 0, 64);
}

/*
 * RING. One circle, filled from twelve o'clock clockwise to the value. The used
 * part is solid 2 px and the rest of the ring the same 2 px in dots; every ring on
 * the panel is read this way, and one paint colour means the difference has to be
 * pattern, never weight.
 */
static void pv_ring(uint8_t *m, const pv_vals_t *v)
{
    enum { CX = 25, CY = 27, R = 19 };
    pv_dot_arc(m, CX, CY, R, 0, 63);

    const int span = pv_round(64.0f * (float)v->q[0] * 0.02f);
    if (span > 0) {
        pv_circle_arc(m, CX, CY, R, 48, 48 + (span >= 64 ? 64 : span));
    }
}

/*
 * RING MODE. The same ring, broken into one arc per mode and separated by a gap
 * wide enough to read at 2 px: four sectors of ninety degrees, the one in force
 * solid and the others the same 2 px in dots. The picture says "the ring is
 * divided this way", not "the ring is this full" — that is the knob above.
 */
static void pv_ring_mode(uint8_t *m, const pv_vals_t *v)
{
    enum { CX = 25, CY = 27, R = 19 };
    int count = v->q[1];
    if (count < 2) {
        count = 4;
    }
    if (count > 4) {
        count = 4;
    }
    const int step = 64 / count;

    for (int i = 0; i < count; i++) {
        const int a = i * step;
        const int b = (i + 1) * step;
        if (i == (int)v->q[0]) {
            pv_circle_arc(m, CX, CY, R, a, b);
        } else {
            pv_dot_arc(m, CX, CY, R, a, b);
        }
    }
}

/*
 * DELAY MODE. TAPE is a row of echoes that fade as they repeat; XFADE is two
 * lines handing the same signal over, one leaving the top while the other arrives
 * from the floor. XFADE used to draw both as uprights at every repeat, which
 * produced six full-height columns and read as a solid fence. Two crossing lines
 * say the same thing without a single vertical.
 */
static void pv_delay_mode(uint8_t *m, const pv_vals_t *v)
{
    enum { N = 6, YT = PV_FY0, YB = PV_FY1 };

    if (v->q[0] == 0) {                     /* TAPE: repeats that fade */
        int h = YB - YT;
        for (int i = 0; i < N; i++) {
            const int x = pv_even(PV_FX0 + (i * (PV_FX1 - PV_FX0)) / (N - 1));
            pv_vline(m, x, YB - h, YB, 2);
            h = (h - h / 4) & ~1;
            if (h < 2) {
                h = 2;
            }
        }
        return;
    }

    pv_stroke(m, PV_FX0, YT, PV_FX1, YB);
    pv_stroke(m, PV_FX0, YB, PV_FX1, YT);
}

/*
 * DELAY SYNC. The division list as a grid of twelve beats: every beat is a 2 px
 * upright with a 2 px gap, and the chosen division is the one that stands taller.
 * FREE is the only position with no tall beat, because it is not on the grid.
 */
static void pv_delay_sync(uint8_t *m, const pv_vals_t *v)
{
    /* SYNC is the same comb with the division doing the spacing; pv_values has
     * already filled q[3] with the division index, so it is the same drawing. */
    pv_delay(m, v);
}

/*
 * CHORUS. Two copies of one wave, a little apart in period: the detune is the
 * whole of what the effect does. RATE is the period both copies are built on, so
 * it changes the number of cycles; DEPTH opens the distance between them, and the
 * copy under the hand is solid while the other is the same 2 px in dots.
 */
static void pv_chorus(uint8_t *m, const pv_vals_t *v)
{
    enum { X0 = PV_FX0, X1 = PV_FX1, N = (PV_FX1 - PV_FX0) / 2 + 1 };
    const float rate = (float)v->q[0] * 0.02f;
    const float depth = (float)v->q[1] * 0.02f;
    const float cycles = 0.5f + 3.5f * rate;
    const int amp = 2 + pv_round(11.0f * depth);
    const int spread = 1 + pv_round(5.0f * depth);
    const float inv_x = 1.0f / (float)(X1 - X0);

    /* DEPTH is the swing and the distance between the copies, and it multiplies
     * both: the old figure only moved the second copy and normalised the pair to
     * the field, so a deeper setting looked the same height. RATE is the number of
     * periods, not the step: the field is the same 44 px and only the density
     * changes. There is no normalisation pass, because that is what cancelled the
     * depth in the first place. */
    int y[2][N];
    for (int c = 0; c < 2; c++) {
        const float per = cycles + (c ? (0.15f + 0.45f * depth) : 0.0f);
        const int off = c ? spread : -spread;
        for (int i = 0; i < N; i++) {
            const int x = X0 + 2 * i;
            const float u = (float)(x - X0) * inv_x;
            float ph = u * per;
            ph -= (float)(int)ph;
            int yy = 27 + off - pv_round(pv_tab(PV_SIN, ph * 16.0f) * 0.01f * (float)amp);
            if (yy < PV_FY0) {
                yy = PV_FY0;
            } else if (yy > PV_FY1) {
                yy = PV_FY1;
            }
            y[c][i] = yy;
        }
    }

    /* The active copy first, solid; the other one in dots, and a dot that would
     * touch the solid copy is dropped, so two waves can cross at a shallow angle
     * without the crossing measuring four pixels. */
    const int act = (int)v->active ? 1 : 0;
    for (int pass = 0; pass < 2; pass++) {
        const int c = (pass == 0) ? act : 1 - act;
        for (int i = 0; i + 1 < N; i++) {
            const int xa = X0 + 2 * i;
            const int xb = xa + 2;
            const int ya = pv_even(y[c][i]);
            const int yb = pv_even(y[c][i + 1]);
            if (pass == 0) {
                pv_stroke(m, xa, ya, xb, yb);
            } else if ((i & 1) == 0) {
                const int xm = xa;
                const int ym = ya;
                if (pv_clear(m, xm, ym)) {
                    pv_stamp(m, xm, ym, 2);
                }
            }
        }
    }
}

/*
 * DUCK. The drone sits at its level, the drum lands, and the low end is held
 * down and let go again along the fixed return table. The knob is the depth, so
 * at zero the line is flat at the top — the drummer is not touching it.
 */
static void pv_duck(uint8_t *m, const pv_vals_t *v)
{
    enum { X0 = PV_FX0, X1 = PV_FX1, TOP = PV_FY0, BOT = PV_FY1 };
    const float depth = (float)v->q[0] * 0.02f;

    /* The floor the drone would sit on without the duck, so the figure keeps the
     * field's height at every depth. */

    int ys[64];
    int n = 0;
    for (int x = X0; x <= X1; x++, n++) {
        float y;
        if (x < 12) {
            y = (float)TOP;
        } else if (x == 12) {
            y = (float)BOT;
        } else {
            const float t = (float)(x - 12) / (float)(X1 - 12) * 15.0f;
            y = (float)BOT - (float)(BOT - TOP) * pv_tab(PV_DUCK, t) * 0.01f;
        }
        ys[n] = pv_round((float)TOP + (y - (float)TOP) * depth);
    }
    pv_plot(m, X0, ys, n);
}

/*
 * FILTER MODE. The corner's shape at one glance: the low pass holds the top and
 * falls, the band pass is a hump around the corner, the high pass rises to the
 * top. The knob is a cross-fade between the three, so the picture is too — the
 * shelf tilts down, the hump appears, the shelf tilts up.
 *
 * The corner sits at 45 % of the width rather than the middle: a low pass with
 * its corner in the centre spends half the field flat, and the shape reads in the
 * half that falls.
 */
static void pv_filter_mode(uint8_t *m, const pv_vals_t *v)
{
    enum { X0 = PV_FX0, X1 = PV_FX1, YT = PV_FY0, YB = PV_FY1, H = PV_FY1 - PV_FY0 };
    const float mode = (float)v->q[0] * 2.0f;      /* 0..100 percent */
    const float m01 = mode * 0.01f;
    const float inv = 1.0f / (float)(X1 - X0);

    int ys[64];
    int n = 0;
    for (int x = X0; x <= X1; x++, n++) {
        const float f = (float)(x - X0) * inv;
        const float r = (f > 0.01f) ? f / 0.45f : 0.01f;
        const float lp = 1.0f / (1.0f + r * r);
        const float hp = 1.0f / (1.0f + 1.0f / (r * r));
        const float d = (f - 0.45f) / 0.16f;
        const float bp = expf(-d * d);

        float y;
        if (mode <= 0.0f) {
            y = lp;
        } else if (mode >= 100.0f) {
            y = hp;
        } else if (mode < 50.0f) {
            const float t = m01 * 2.0f;
            y = lp * (1.0f - t) + bp * t;
        } else {
            const float t = (m01 - 0.5f) * 2.0f;
            y = bp * (1.0f - t) + hp * t;
        }
        ys[n] = YB - pv_round(y * (float)H * 0.95f);
    }
    pv_curve(m, X0, ys, n);
}
/*
 * FOLLOW. A tracking picture, the same one an arpeggiator or a MIDI merge shows:
 * the lead's pitch runs left to right, the drone's answer runs bottom to top, and
 * the question the knob asks is "how does the register answer a rising note".
 *
 *   CONS   the register holds its own note — a flat line across the middle;
 *   FULL   it rises with the note — one straight diagonal;
 *   SCALE  it rises in scale steps — a staircase.
 *
 * The previous drawing was a register that "reached" for a note mark on the
 * right, and the owner's verdict was that neither he nor a user could tell what
 * it meant. The line, the diagonal and the staircase are three shapes the eye
 * separates at once, and each one is the literal behaviour of the mode.
 */
static void pv_follow(uint8_t *m, const pv_vals_t *v)
{
    enum { X0 = PV_FX0, X1 = PV_FX1, YT = PV_FY0, YB = PV_FY1 };
    const int mode = v->q[0];

    if (mode == 2) {                        /* CONS: the register never leaves */
        const int y = (YT + YB) / 2;
        pv_stroke(m, X0, y & ~1, X1, y & ~1);
        return;
    }

    if (mode == 1) {                        /* FULL: the register tracks */
        pv_stroke(m, X0, YB, X1, YT);
        return;
    }

    /* SCALE: six treads of seven pixels, each a riser of six, from the floor at
     * the left edge to just under the top at the right one. The treads are what
     * makes it read as steps instead of a ragged diagonal. */
    const int tread = 7;
    const int riser = 6;
    int y = YB;
    for (int i = 0; i < 6; i++) {
        const int x = X0 + i * tread;
        pv_stroke(m, x, y, x + tread, y);
        if (i < 5) {
            pv_stroke(m, x + tread, y, x + tread, y - riser);
        }
        y -= riser;
    }
}

/*
 * WIDTH. The three registers and their spread: the knob widens the field, so the
 * same three lines move apart. Four pixels between centres is the floor, because
 * two 2 px strokes with less than 2 px of air read as one thick stroke.
 */
static void pv_width(uint8_t *m, const pv_vals_t *v)
{
    enum { X0 = PV_FX0, X1 = PV_FX1, TOP = PV_FY0, BOT = PV_FY1 };

    /* The three registers always span the field: the outer two sit on its edges
     * and the middle one moves with WIDTH, so the spread is what the picture
     * says and the size never changes. */
    const int mid = pv_even(TOP + 4 + ((BOT - TOP - 8) * (50 - (int)v->q[0])) / 50);

    pv_stroke(m, X0, TOP, X1, TOP);
    pv_stroke(m, X0, mid, X1, mid);
    pv_stroke(m, X0, BOT, X1, BOT);
}

/*
 * ACCENT. Two onsets, one at the velocity every hit gets and one marked by the
 * figure: the second column is taller by the accent. OFF leaves them equal, which
 * is exactly what the parameter does.
 */
static void pv_accent(uint8_t *m, const pv_vals_t *v)
{
    enum { BASE = PV_FY1, TOP = PV_FY0, XA = PV_FX0, XB = PV_FX1 };
    const int idx = v->q[0];

    /* The accented hit always reaches the top and the plain one falls as the
     * accent rises; at OFF the two are equal. The old floor stroke is gone: the
     * uprights stand on the field's bottom row and the two hits are the data. */
    const int h1 = TOP + ((BASE - TOP) * idx) / 7;

    pv_vline(m, XA, h1, BASE, 2);
    pv_vline(m, XB, TOP, BASE, 2);
}

/* PERC PITCH. The band-pass centre as the shape it is: one bell on a flat floor,
 * the bell moving along the axis. An end stop at each end and a marker on the
 * value were three symbols where a curve says the same thing. */
static void pv_perc_pitch(uint8_t *m, const pv_vals_t *v)
{
    enum { X0 = PV_FX0, X1 = PV_FX1, YB = PV_FY1, H = PV_FY1 - PV_FY0, W = 11 };

    const int c = pv_even(8 + pv_round(30.0f * (float)v->q[0] * 0.02f));
    int ys[64];
    int n = 0;
    for (int x = X0; x <= X1; x++, n++) {
        const int d = x > c ? x - c : c - x;
        const float a = (d >= W) ? 0.0f : 1.0f - (float)d / (float)W;
        ys[n] = YB - pv_round((float)H * a);
    }
    pv_curve(m, X0, ys, n);
}

/* PERC QUANT. What quantising does to a pitch sweep: OFF is the straight line,
 * ON is the same travel in four equal steps. */
static void pv_perc_quant(uint8_t *m, const pv_vals_t *v)
{
    enum { X0 = PV_FX0, X1 = PV_FX1, YB = PV_FY1, H = PV_FY1 - PV_FY0, W = 11 };

    /* The same bell as PITCH, held in four steps when QUANT is on: one family,
     * one figure, the property is the staircase. */
    const int c = pv_even(8 + pv_round(30.0f * (float)v->q[0] * 0.02f));
    const int on = v->q[0] != 0;

    int ys[64];
    int n = 0;
    for (int x = X0; x <= X1; x++, n++) {
        const int d = x > c ? x - c : c - x;
        float a = (d >= W) ? 0.0f : 1.0f - (float)d / (float)W;
        if (on) {
            a = floorf(a * 4.0f + 0.5f) * 0.25f;
        }
        ys[n] = YB - pv_round((float)H * a);
    }
    pv_curve(m, X0, ys, n);
}

/* PERC DECAY. How long the hit rings: the same fall, read further along the decay
 * table. The short gate falls out of the frame early; the long one holds its tail. */
static void pv_perc_decay(uint8_t *m, const pv_vals_t *v)
{
    enum { X0 = PV_FX0, X1 = PV_FX1, YT = PV_FY0, YB = PV_FY1 };
    const float speed = 2.5f - 2.0f * (float)v->q[0] * 0.02f;
    const float inv_x = 1.0f / (float)(X1 - X0);

    int ys[64];
    int n = 0;
    for (int x = X0; x <= X1; x++, n++) {
        const float u = (float)(x - X0) * inv_x;
        const float a = pv_tab(PV_TAIL_FAST, u * 15.0f * speed);
        ys[n] = YB - pv_round((float)(YB - YT) * a * 0.01f);
    }
    pv_curve(m, X0, ys, n);
}

/* PERC BODY. The click and the body as one curve: the fast table is the click,
 * the slow one the body, and the knob is the blend between them. */
static void pv_perc_body(uint8_t *m, const pv_vals_t *v)
{
    enum { X0 = PV_FX0, X1 = PV_FX1, YT = PV_FY0, YB = PV_FY1 };
    const float body = (float)v->q[0] * 0.02f;
    const float inv_x = 1.0f / (float)(X1 - X0);

    int ys[64];
    int n = 0;
    for (int x = X0; x <= X1; x++, n++) {
        const float u = (float)(x - X0) * inv_x;
        const float fast = pv_tab(PV_TAIL_FAST, u * 15.0f);
        const float slow = pv_tab(PV_TAIL_SLOW, u * 15.0f);
        const float a = fast + (slow - fast) * body;
        ys[n] = YB - pv_round((float)(YB - YT) * a * 0.01f);
    }
    pv_curve(m, X0, ys, n);
}

/* PERC ENV. How far the filter falls over the hit: the curve starts at the top
 * and settles on a floor the knob moves down. */
static void pv_perc_env(uint8_t *m, const pv_vals_t *v)
{
    enum { X0 = PV_FX0, X1 = PV_FX1, YT = PV_FY0, YB = PV_FY1 };
    const int floor_y = pv_even(14 + pv_round(32.0f * (float)v->q[0] * 0.02f));
    const float inv_x = 1.0f / (float)(X1 - X0);

    int ys[64];
    int n = 0;
    for (int x = X0; x <= X1; x++, n++) {
        const float u = (float)(x - X0) * inv_x;
        const float a = pv_tab(PV_TAIL_FAST, u * 15.0f);
        ys[n] = floor_y - pv_round((float)(floor_y - YT) * a * 0.01f);
    }
    pv_curve(m, X0, ys, n);
}

/*
 * ARP. A staircase with exactly LEN treads: a riser and a tread per note, the
 * first riser leaving the floor and the last tread ending the figure. UP puts the
 * low note on the left and the high one on the right, DOWN the other way round,
 * and UP-DOWN climbs and comes back. The run is scaled to the frame: the lowest
 * note on the floor and the highest on the ceiling, so LEN = 2 is one tread at
 * each end. RANGE changes the octave span the run covers; a static plot has one
 * frame for every span, so the frame shows the shape and the readout shows the
 * octaves.
 *
 * The count used to be one short because the first note was a bare riser and the
 * last tread was never drawn: with LEN = 2 that is one visible step. Both are
 * fixed here by drawing LEN treads and starting the first riser at the floor.
 */
static void pv_arp(uint8_t *m, const pv_vals_t *v)
{
    enum { X0 = PV_FX0, X1 = PV_FX1, YB = PV_FY1, YT = PV_FY0, H = PV_FY1 - PV_FY0 + 2 };

    const int dir = v->q[0];
    const int speed = v->q[1];
    const int len = 2 + v->q[2];

    if (dir == 0) {                         /* OFF: the run never starts */
        pv_stroke(m, X0, YT, X1, YT);
        return;
    }

    /* RANGE is how many times the ladder repeats upward. Three positions of the
     * knob are one, two and three spans; the preview repeats the same LEN steps at
     * each height. If three spans of this LEN cannot fit in forty rows with a 2 px
     * step and a 2 px gap, the top span is left out and the figure shows two —
     * never a squeezed third. */
    /* One span is about one octave tall (12 rows including the stroke) and the
     * spans are stacked from the floor upward, so RANGE does something the eye can
     * see: one span sits low, two reach higher, three higher still. If the third
     * does not fit with a 2 px step and a 2 px gap, only two are drawn. */
    int step = 2;
    while ((len - 1) * (step + 2) + 2 <= 12) {
        step += 2;
    }
    const int pass_h = (len - 1) * step + 2;

    int spans = 1 + ((int)v->q[3] % 3);
    while (spans > 1 && spans * pass_h + (spans - 1) * 2 > H) {
        spans--;
    }

    /* Horizontal pitch from SPEED: slow is wide, fast is dense. Every tread is
     * the same length, and the whole ladder is centred, so a slow run leaves a
     * symmetric margin instead of stretching only its last tread to the edge. */
    const int fit = (X1 - X0) / (len - 1);
    int pitch = pv_even((int)((float)fit
                              * (0.55f + 0.45f * (1.0f - (float)speed / 12.0f))));
    int cap = pv_even((X1 - X0) / len);
    if (cap < 2) {
        cap = 2;
    }
    if (pitch > cap) {
        pitch = cap;
    }
    if (pitch < 2) {
        pitch = 2;
    }
    const int run = pitch * len;
    int x0 = X0 + pv_even((X1 - X0 - run) / 2);
    if (x0 < X0) {
        x0 = X0;
    }

    float frac[10];
    for (int i = 0; i < len; i++) {
        const float t = (len > 1) ? (float)i / (float)(len - 1) : 0.0f;
        switch (dir) {
        case 1: frac[i] = t; break;
        case 2: frac[i] = 1.0f - t; break;
        case 3:
        case 5:
            frac[i] = 1.0f - (t < 0.5f ? (1.0f - 2.0f * t) : (2.0f * t - 1.0f));
            break;
        case 4:
        case 6: {
            const float tri = 1.0f - (t < 0.5f ? (1.0f - 2.0f * t) : (2.0f * t - 1.0f));
            frac[i] = 1.0f - tri;
            break;
        }
        default: {
            static const int8_t perm[8] = { 20, 80, 45, 100, 10, 65, 35, 90 };
            frac[i] = (float)perm[i % 8] * 0.01f;
            break;
        }
        }
    }

    float lo = frac[0];
    float hi = frac[0];
    for (int i = 1; i < len; i++) {
        if (frac[i] < lo) lo = frac[i];
        if (frac[i] > hi) hi = frac[i];
    }
    const float spread = (hi - lo > 0.001f) ? 1.0f / (hi - lo) : 0.0f;

    for (int p = 0; p < spans; p++) {
        const int base = YB - p * (pass_h + 2);
        int prev = base;
        for (int i = 0; i < len; i++) {
            const int x = x0 + i * pitch;
            const int xn = x0 + (i + 1) * pitch;
            const int y = pv_even(base - pv_round((float)((len - 1) * step)
                                                   * (frac[i] - lo) * spread));
            pv_stroke(m, x, prev, x, y);
            pv_stroke(m, x, y, xn, y);
            prev = y;
        }
    }
}

/* -------------------------------------------------------------------------- */
/* Public entry points                                                        */
/* -------------------------------------------------------------------------- */

/*
 * Horizontal centring is a property of the geometry: every figure now picks its own
 * right edge from its content, so the margins come out equal (or differ by the one
 * pixel a two-pixel stroke can explain) without a pass over the bits. Measuring
 * and shifting the whole mask cost more than drawing the figure, which is why the
 * runtime centring pass is gone.
 */

/* The vertical centre of each figure, in pixels, measured from its own drawing
 * origin. Chosen so the ink's top and bottom margins are equal; the values are
 * even where the figure's own height is even, because a two-pixel stroke should
 * stay on even coordinates. */
/* The few figures whose content does not start and end at the same distance from
 * the frame. A translation at draw time, not a pass over the mask: the delay's
 * bars and the arpeggio's staircase are placed by their own spacing, and the
 * correction is part of where they are drawn. */
/* The common field's origin. A figure is drawn in the 44 x 40 natural field
 * (PV_FX0..PV_FX1 by PV_FY0..PV_FY1) and this one offset puts that field at 3..46
 * by 8..47, so the margins are 3/3 and 8/8. The square figures are 40 wide with
 * natural blocks at 6..44, and their offset is -1; every figure's vertical
 * drawing already starts at PV_FY0, so there is no vertical offset left. */
static int pv_ox_for(synth_preview_kind_t kind)
{
    switch (kind) {
    case PREVIEW_MIC:
    case PREVIEW_RING:
    case PREVIEW_RING_MODE:
        return -1;
    default:
        return 1;
    }
}

static int pv_oy_for(synth_preview_kind_t kind)
{
    (void)kind;
    return 0;
}

void synth_preview_mask(synth_param_t param, uint8_t *mask)
{
    pv_vals_t v;
    const synth_preview_kind_t kind = pv_values(param, &v);

    memset(mask, 0, SYNTH_PREVIEW_BYTES);
    s_pv_oy = pv_oy_for(kind);
    s_pv_ox = pv_ox_for(kind);

    switch (kind) {
    case PREVIEW_ENV:       pv_env(mask, &v);       break;
    case PREVIEW_FILTER:    pv_filter(mask, &v);    break;
    case PREVIEW_FILTER_MODE: pv_filter_mode(mask, &v); break;
    case PREVIEW_COMP:      pv_comp(mask, &v);      break;
    case PREVIEW_WAVE:      pv_wave(mask, &v);      break;
    case PREVIEW_DELAY:     pv_delay(mask, &v);     break;
    case PREVIEW_VERB:      pv_verb(mask, &v);      break;
    case PREVIEW_VERB_MODE: pv_verb_mode(mask, &v); break;
    case PREVIEW_LEAD_FILTER: pv_lead_filter(mask, &v); break;
    case PREVIEW_LEAD_ENV:  pv_lead_env(mask, &v);  break;
    case PREVIEW_LFO:       pv_lfo(mask, &v);       break;
    case PREVIEW_RATE:
    case PREVIEW_MOD_DEPTH: pv_lfo(mask, &v);       break;
    case PREVIEW_TRIG:      pv_trig(mask, &v);      break;
    case PREVIEW_MIC:       pv_mic(mask, &v);       break;
    case PREVIEW_RING:      pv_ring(mask, &v);      break;
    case PREVIEW_RING_MODE: pv_ring_mode(mask, &v); break;
    case PREVIEW_DELAY_MODE: pv_delay_mode(mask, &v); break;
    case PREVIEW_DELAY_SYNC: pv_delay_sync(mask, &v); break;
    case PREVIEW_CHORUS:    pv_chorus(mask, &v);    break;
    case PREVIEW_DUCK:      pv_duck(mask, &v);      break;
    case PREVIEW_FOLLOW:    pv_follow(mask, &v);    break;
    case PREVIEW_WIDTH:     pv_width(mask, &v);     break;
    case PREVIEW_ACCENT:    pv_accent(mask, &v);    break;
    case PREVIEW_PERC_PITCH: pv_perc_pitch(mask, &v); break;
    case PREVIEW_PERC_QUANT: pv_perc_quant(mask, &v); break;
    case PREVIEW_PERC_DECAY: pv_perc_decay(mask, &v); break;
    case PREVIEW_PERC_BODY: pv_perc_body(mask, &v); break;
    case PREVIEW_PERC_ENV:  pv_perc_env(mask, &v);  break;
    case PREVIEW_ARP:       pv_arp(mask, &v);       break;
    default:                                        break;
    }

}

/*
 * Paint the lit bits.
 *
 * The per-frame cost, so it is kept as plain as it looks: per row, the mask byte
 * is loaded once and shifted, and a lit bit is one store. This is measurably the
 * fastest of the three shapes tried on the instrument (135 us for the full
 * 50x56 against 167 us for a run-fill and 203 us for a branchless load-modify-
 * store): the branch is not mispredicted often, because a curve leaves most of
 * each row empty, and the store is only issued for a pixel that is really ink.
 *
 * The rectangle is clipped to the mask once at the top; nothing below tests a
 * coordinate again. The band the caller passes is already the mask's ink rows,
 * so the rows scanned are the rows that can have anything on them.
 */
void synth_preview_blit(const uint8_t *mask, uint16_t *dst, int stride_px,
                        int mx, int my, int w, int h, uint16_t colour)
{
    if (dst == NULL || mask == NULL || stride_px <= 0 || w <= 0 || h <= 0) {
        return;
    }

    /* `my` is the mask row the dst pointer starts at, so the loop runs from it and
     * the buffer row is counted from it. `y` is therefore the ABSOLUTE mask row in
     * both the mask index and the screen row — the two must not disagree: a partial
     * refresh hands this function one 16-row strip at a time, and a strip that
     * started at 0 while the buffer row was `y - my` would read the mask past its
     * end and write above its own box. */
    int y0 = my < 0 ? 0 : my;
    int y1 = my + h;
    if (y1 > SYNTH_PREVIEW_H) {
        y1 = SYNTH_PREVIEW_H;
    }
    int x0 = mx < 0 ? 0 : mx;
    int x1 = mx + w;
    if (x1 > SYNTH_PREVIEW_W) {
        x1 = SYNTH_PREVIEW_W;
    }
    if (x0 >= x1 || y0 >= y1) {
        return;
    }

    for (int y = y0; y < y1; y++) {
        uint16_t *row = dst + (size_t)(y - my) * (size_t)stride_px;
        const int out = x0 - mx;

        /* Walk whole bytes of the row and visit only the set bits: a picture is
         * mostly holes, and a branch per dark pixel is what made the first
         * version cost 140 us. The mask is a continuous bit stream, so a row can
         * start in the middle of a byte. */
        const int bitpos = y * SYNTH_PREVIEW_W + x0;
        const uint8_t *mb = mask + (bitpos >> 3);
        int shift = bitpos & 7;
        int left = x1 - x0;
        int done = 0;

        while (left > 0) {
            uint8_t bits = *mb++;
            if (shift != 0) {
                bits &= (uint8_t)(0xFFu >> shift);
            }
            int take = 8 - shift;
            if (take > left) {
                take = left;
                bits &= (uint8_t)(0xFFu << (8 - take));
            }
            while (bits != 0) {
                const int p = 31 - __builtin_clz((unsigned)bits);
                const int k = done + 7 - p - shift;
                row[out + k] = colour;
                bits &= (uint8_t)~(1u << p);
            }
            left -= take;
            done += take;
            shift = 0;
        }
    }
}


