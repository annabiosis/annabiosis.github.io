/*
 * The pictures themselves. See synth_ui_preview.h for why this is a bit mask, why
 * it is written into the layer by hand, and why every curve is a polyline or a
 * 16-value table.
 *
 * The coordinate system is the picture's own: x and y both run 0..55. The frame is
 * centred on the dial, so the line between rows 27 and 28 is the middle of the
 * screen and of the page's name's line.
 *
 * THE FRAME IS 56 x 56 AND THE FIGURE INSIDE IT IS 44 x 44, CENTRED — six pixels of
 * air on every side, the same six on every page and for every figure. The 44 x 44
 * area is the whole ink budget: a figure draws inside columns and rows 6..49 and
 * nowhere else, and a mark on a vertex at the edge of that area spends its halo on
 * the two pixels of inset the figure keeps inside itself rather than on the air.
 */
#include "synth_ui_preview.h"

#include <math.h>
#include <stdbool.h>
#include <string.h>

/*
 * The filter's response, sampled offline: a two-pole low-pass at Q = 0.9 over six
 * octaves, one entry per 0.4 octave, in decibels. 0 dB is the shelf; the peak at
 * the corner is the resonance the picture adds on top. The table is the whole of
 * the frequency axis: +3 octaves at entry 15, -3 at entry 0.
 */

/* One cycle of a sine, x100, sixteen points: the wave picture's sine. */
static const int8_t PV_SIN[16] = {
    0, 38, 71, 92, 100, 92, 71, 38, 0, -38, -71, -92, -100, -92, -71, -38,
};


/* Two reverb decays, x100 of the initial level. FAST is a small room, SLOW a
 * cathedral; SIZE blends between them and DAMP is the exponent of the fall. The
 * drum's decay is shaped by the same two tables. */
static const int8_t PV_TAIL_FAST[16] = {
    100, 71, 50, 35, 25, 18, 12, 9, 6, 4, 3, 2, 2, 1, 1, 1,
};
static const int8_t PV_TAIL_SLOW[16] = {
    100, 88, 78, 68, 60, 53, 47, 41, 36, 32, 28, 25, 22, 19, 17, 15,
};

/* A microphone envelope, x100: four phrases of speech rather than a waveform.
 * Smooth enough that the 2 px stroke never folds onto itself. The microphone shape of
 * the LFO is not periodic at all: mod_value() returns the envelope, 0..1, and the
 * figure shows phrases rather than a period. */
static const int8_t PV_MIC_ENV[16] = {
    0, 42, 68, 30, 55, 80, 38, 18, 62, 90, 47, 22, 54, 71, 33, 8,
};

/* The unit circle sampled every 5.625 degrees, x1000. The LFO's sine and triangle are
 * polylines of these points and the square asks them for the sign alone, so no drawing
 * path needs a sine, a cosine or a square root. */
static const int16_t PV_COS[64] = {
    1000, 995, 981, 957, 924, 882, 831, 773, 707, 634, 556, 471,
    383, 290, 195, 98, 0, -98, -195, -290, -383, -471, -556, -634,
    -707, -773, -831, -882, -924, -957, -981, -995, -1000, -995, -981, -957,
    -924, -882, -831, -773, -707, -634, -556, -471, -383, -290, -195, -98,
    0, 98, 195, 290, 383, 471, 556, 634, 707, 773, 831, 882,
    924, 957, 981, 995,
};
/* Конверт: экспоненциальный спад на весь размах, 33 точки на оборот, тысячные.
 * Те же числа считает прототип, поэтому рисунок на экране и рисунок на листе
 * совпадают до пикселя. */
static const int16_t PV_CENV[33] = {
    1000, 786, 595, 423, 269,
    131, 8, -103, -203, -292,
    -371, -443, -507, -565, -616,
    -662, -704, -741, -774, -804,
    -831, -855, -876, -896, -913,
    -928, -942, -955, -966, -976,
    -985, -993, -1000,
};

static const int16_t PV_CSIN[64] = {
    0, 98, 195, 290, 383, 471, 556, 634, 707, 773, 831, 882,
    924, 957, 981, 995, 1000, 995, 981, 957, 924, 882, 831, 773,
    707, 634, 556, 471, 383, 290, 195, 98, 0, -98, -195, -290,
    -383, -471, -556, -634, -707, -773, -831, -882, -924, -957, -981, -995,
    -1000, -995, -981, -957, -924, -882, -831, -773, -707, -634, -556, -471,
    -383, -290, -195, -98,
};

/* -------------------------------------------------------------------------- */
/* Raster                                                                     */
/* -------------------------------------------------------------------------- */

/* The vertical placement of the figure in the frame. Every figure is drawn around
 * its own natural baseline, and the values differ; this one offset centres the
 * whole picture without a second pass over the mask. It is set per kind before
 * the figure is drawn. */
static int s_pv_oy;
static int s_pv_ox;

/* Зерно случайной фигуры. Меняется только при повороте RATE: раскладка должна
 * пересобираться от темпа, а DEPTH обязан крутить ту же картинку, меняя размах. */
static uint32_t s_pv_seed = 1u;

static void pv_px(uint8_t *m, int x, int y)
{
    x += s_pv_ox;
    y += s_pv_oy;
    if (x < 0 || x >= SYNTH_PREVIEW_W || y < 0 || y >= SYNTH_PREVIEW_H) {
        return;
    }
    const int i = y * SYNTH_PREVIEW_W + x;
    m[i >> 3] |= (uint8_t)(0x80u >> (i & 7));
}

/* The common field the older figures are drawn in: 44 x 40 with even extents,
 * centred in the 56 x 56 frame — six pixels of margin left and right, eight above
 * and below, so the field's own width is the whole 44 x 44 figure area. Natural x
 * runs 2..44 and the offset is +4, which lands the field on 6..49; the field the
 * new figures use is narrower and is placed by the figure itself.
 *
 * A stroke is two pixels wide in both. */
#define PV_FX0 2
#define PV_FX1 44
#define PV_FY0 8
#define PV_FY1 46

/* Nearest even coordinate at or below v. Every stroke coordinate goes through
 * this: a 2 x 2 brush must sit on even columns, or it straddles an odd edge and
 * a run of two blocks measures three pixels. */
static int pv_even(int v)
{
    return v & ~1;
}

/* Nearest even coordinate to v. The stroke walk rounds its own ends down; a
 * figure that has to land on the brush grid asks for the near one instead, so a
 * stage at nine pixels of travel draws ten rather than eight. */
static int pv_even_near(int v)
{
    return pv_even(v + 1);
}

static void pv_stamp(uint8_t *m, int x, int y, int s);

/* a / b rounded to nearest, b > 0, away from zero on a tie. The stroke walks use
 * it instead of a float divide so the block that lands on the end coordinate is
 * exactly the end coordinate on every machine. */
static int pv_div_round(int a, int b)
{
    return a >= 0 ? (a + b / 2) / b : -((-a + b / 2) / b);
}

/* Is this pixel already inked? Used where a dot must not land on the solid
 * stroke, and for the dots' own gap. Offset is applied the same way as pv_px. */
static bool pv_ink(const uint8_t *m, int x, int y)
{
    x += s_pv_ox;
    y += s_pv_oy;
    if (x < 0 || x >= SYNTH_PREVIEW_W || y < 0 || y >= SYNTH_PREVIEW_H) {
        return false;
    }
    const int i = y * SYNTH_PREVIEW_W + x;
    return (m[i >> 3] & (uint8_t)(0x80u >> (i & 7))) != 0;
}

/* The 2 x 2 block at (x,y) has a one-pixel halo of free mask around it. */
static bool pv_clear(const uint8_t *m, int x, int y)
{
    for (int dy = -1; dy <= 2; dy++) {
        for (int dx = -1; dx <= 2; dx++) {
            if (pv_ink(m, x + dx, y + dy)) {
                return false;
            }
        }
    }
    return true;
}

/*
 * A stroke is a chain of 2 x 2 blocks whose centres step exactly 2 px along the
 * dominant axis. Thickness is therefore 2 px everywhere, including a 45 degree
 * slope, where the staircase is exact and does not breathe. Ends are snapped to
 * even coordinates: the brush never straddles an odd edge.
 *
 * The old way was Bresenham with the brush stamped at every point. On a slope
 * steeper than about 2:1 that puts two stamps on some rows and three columns of
 * ink on the transition rows — the 3-4 px the owner saw on the envelope's
 * attack, the ring and the chorus. Stepping the dominant axis by exactly two
 * cannot do that: the other axis moves by at most two per block, so a row or a
 * column never sees more than one block.
 */
static void pv_stroke(uint8_t *m, int x0, int y0, int x1, int y1)
{
    x0 = pv_even(x0);
    y0 = pv_even(y0);
    x1 = pv_even(x1);
    y1 = pv_even(y1);

    const int dx = x1 > x0 ? x1 - x0 : x0 - x1;
    const int dy = y1 > y0 ? y1 - y0 : y0 - y1;
    const int sx = x1 >= x0 ? 1 : -1;
    const int sy = y1 >= y0 ? 1 : -1;
    const int steps = (dx >= dy ? dx : dy) / 2;

    if (steps == 0) {
        pv_stamp(m, x0, y0, 2);
        return;
    }

    for (int i = 0; i <= steps; i++) {
        int x;
        int y;
        if (dx >= dy) {
            x = x0 + sx * 2 * i;
            /* The minor axis moves at most 2 per block; rounding to even keeps
             * every block on the brush grid, and the last one lands exactly. */
            y = pv_even(y0 + pv_div_round(sy * dy * i, steps));
        } else {
            y = y0 + sy * 2 * i;
            x = pv_even(x0 + pv_div_round(sx * dx * i, steps));
        }
        pv_stamp(m, x, y, 2);
    }
}

/*
 * The 44 x 44 figure area in mask coordinates. A stroke coordinate is the top-left
 * corner of a 2 x 2 block, so the last legal one is 48: its block covers columns
 * 48..49, the last column of the area.
 */
/* The eighth entry of the SHAPE list, and the one that is not a waveform: the app's
 * LFO_SHAPE_MIC, which is SYNTH_LFO_SHAPE_MIC in the DSP. Seven waves come before it. */
#define PV_LFO_SHAPE_MIC 7

#define PV_AREA_X0 6
#define PV_AREA_W (PV_AREA_X1 + 1 - PV_AREA_X0)
#define PV_AREA_H (PV_AREA_Y1 + 1 - PV_AREA_Y0)
#define PV_AREA_X1 48
#define PV_AREA_Y0 6
#define PV_AREA_Y1 48

/* The NOTE list's twelve positions, C to B: the length of PV_NOTE_ICONS and of the tonic that
 * seq_root_midi() counts on. It is a list, not a travel, so it is counted rather than quantised. */
#define PV_NOTE_COUNT 12

/*
 * The same 2 x 2 brush, stepping ONE pixel per block instead of two.
 *
 * The coarse walk above is right where a figure is made of near-horizontal and
 * near-vertical segments — the envelope, the bars, the rings. On a forty-five
 * degree run it is wrong: blocks two apart on both axes touch only at their
 * corners, so the line reads as a row of separate dots rather than as a line, and
 * the owner saw exactly that on the filter's first skirt. A step of one pixel per
 * block makes the staircase solid on every slope; it draws more blocks, but the
 * mask is 392 bytes whether the ink is thick or thin.
 *
 * Coordinates are not snapped to even here. The filter's shelf sits on the field's
 * exact middle, rows 27..28, which is an odd row: snapping it would move the
 * figure half a division off the frame's centre line.
 *
 * Blocks outside the 44 x 44 area are dropped. The mask itself is 56 wide and would
 * take ink six pixels past the area on every side, and the figure's skirt is meant
 * to run out of the area and be cut by it — not to keep going into the air.
 */
static void pv_stroke_fine(uint8_t *m, int x0, int y0, int x1, int y1)
{
    const int dx = x1 > x0 ? x1 - x0 : x0 - x1;
    const int dy = y1 > y0 ? y1 - y0 : y0 - y1;
    const int sx = x1 >= x0 ? 1 : -1;
    const int sy = y1 >= y0 ? 1 : -1;
    const int steps = dx >= dy ? dx : dy;

    if (steps == 0) {
        if (x0 >= PV_AREA_X0 && x0 <= PV_AREA_X1 && y0 >= PV_AREA_Y0 &&
            y0 <= PV_AREA_Y1) {
            pv_stamp(m, x0, y0, 2);
        }
        return;
    }

    for (int i = 0; i <= steps; i++) {
        const int x = x0 + sx * pv_div_round(dx * i, steps);
        const int y = y0 + sy * pv_div_round(dy * i, steps);
        if (x < PV_AREA_X0 || x > PV_AREA_X1 || y < PV_AREA_Y0 || y > PV_AREA_Y1) {
            continue;
        }
        pv_stamp(m, x, y, 2);
    }
}

/* A stroke walked a whole number of pixels at a time, and without turning the
 * coordinates to even numbers: the SHAPE figure stands on odd pixels and the
 * even snapping of pv_stroke() would move it.
 *
 * Two pixels a step is what the steep branches want; one is what a diagonal
 * wants, because two-pixel blocks two pixels apart on both axes touch only at
 * their corners and the line reads as a dotted one.
 */
static void pv_stroke_px(uint8_t *m, int x0, int y0, int x1, int y1, int step)
{
    const int dx = x1 > x0 ? x1 - x0 : x0 - x1;
    const int dy = y1 > y0 ? y1 - y0 : y0 - y1;
    const int sx = x1 >= x0 ? 1 : -1;
    const int sy = y1 >= y0 ? 1 : -1;
    const int steps = (dx >= dy ? dx : dy) / step;

    if (steps == 0) {
        if (x0 >= PV_AREA_X0 && x0 <= PV_AREA_X1 && y0 >= PV_AREA_Y0 &&
            y0 <= PV_AREA_Y1) {
            pv_stamp(m, x0, y0, 2);
        }
        return;
    }

    for (int i = 0; i <= steps; i++) {
        int x;
        int y;
        if (dx >= dy) {
            x = x0 + sx * step * i;
            y = y0 + sy * pv_div_round(dy * i, steps);
        } else {
            y = y0 + sy * step * i;
            x = x0 + sx * pv_div_round(dx * i, steps);
        }
        if (x < PV_AREA_X0 || x > PV_AREA_X1 || y < PV_AREA_Y0 || y > PV_AREA_Y1) {
            continue;
        }
        pv_stamp(m, x, y, 2);
    }
}

/* An s x s square with its top-left corner at (x,y): the brush every stroke
 * uses.
 * 2 is the instrument's own stroke width; there is no 3 anymore, selection is a
 * pattern.
 *
 * The square is the one thing every figure repeats thousands of times, so the
 * common case — wholly inside the mask — walks the bitstream instead of calling
 * pv_px nine times: one bounds test, one index, then a shift that carries into
 * the next byte. The clipped case still goes through pv_px, because that is what
 * pv_px is for. */
static void pv_stamp(uint8_t *m, int x, int y, int s)
{
    x += s_pv_ox;
    y += s_pv_oy;
    if (x >= 0 && y >= 0 && x + s <= SYNTH_PREVIEW_W && y + s <= SYNTH_PREVIEW_H) {
        for (int dy = 0; dy < s; dy++) {
            int i = (y + dy) * SYNTH_PREVIEW_W + x;
            uint8_t *p = m + (i >> 3);
            int sh = i & 7;

            for (int dx = 0; dx < s; dx++) {
                *p |= (uint8_t)(0x80u >> sh);
                if (++sh == 8) {
                    sh = 0;
                    ++p;
                }
            }
        }
        return;
    }

    for (int dy = 0; dy < s; dy++) {
        for (int dx = 0; dx < s; dx++) {
            pv_px(m, x + dx - s_pv_ox, y + dy - s_pv_oy);
        }
    }
}

/* The one figure that has to take ink away again: the ring the hand is on. The
 * mask is additive everywhere else, so this walks the same offset arithmetic as
 * pv_px and clears the bit instead of setting it. */
static void pv_unset(uint8_t *m, int x, int y)
{
    x += s_pv_ox;
    y += s_pv_oy;
    if (x < 0 || x >= SYNTH_PREVIEW_W || y < 0 || y >= SYNTH_PREVIEW_H) {
        return;
    }
    const int i = y * SYNTH_PREVIEW_W + x;
    m[i >> 3] &= (uint8_t)~(0x80u >> (i & 7));
}

/*
 * The stage under the hand: a four-by-four ring of single pixels with a two-pixel
 * hole, and one pixel of free mask all round it.
 *
 * The hole is the block the vertex itself is drawn with — a stroke block is 2 x 2
 * and the hole is 2 x 2 — so the ring lands on the vertex rather than beside it,
 * which is the whole reason the mark is a ring and not a filled square. The pixel
 * of free mask is what separates the mark from the line: the curve breaks for one
 * pixel on each side and the ring reads as a mark, not as a thick place in the
 * stroke.
 *
 * THE RING IS CENTRED ON THE VERTEX, NOT ON THE BLOCK. A vertex is the point where
 * two segments meet, and the two-pixel block that draws it is one pixel down and one
 * to the right of that point. The ring therefore covers two pixels above the point and
 * two to its left, one below and one to its right; the hole falls on the point itself
 * and clears the block's upper-left pixel, so the mark hangs on the corner the way the
 * owner's drawing has it. This is what puts the figure's top row on the top edge of the
 * 44 — a ring centred on the block would leave a pixel of air above the peak — and it
 * is also what keeps the release's ring from hanging below the floor: the figure is
 * 42 pixels tall inside a 44-pixel area, and the last two rows under it stay empty.
 */
static void pv_mark(uint8_t *m, int x, int y)
{
    for (int dy = -3; dy <= 2; dy++) {
        for (int dx = -3; dx <= 2; dx++) {
            pv_unset(m, x + dx, y + dy);
        }
    }

    for (int i = -2; i <= 1; i++) {
        pv_px(m, x + i, y - 2);
        pv_px(m, x + i, y + 1);
        pv_px(m, x - 2, y + i);
        pv_px(m, x + 1, y + i);
    }
}

/* Bresenham, with the brush stamped at every point. Used for the few-vertex
 * polylines: an envelope's four segments, the rate chevrons, the delay strokes. */

/*
 * One column of a curve that is walked along x: from y0 to y1, s pixels wide and
 * s pixels past the lower end, so a steep segment has no gap where the next column
 * starts. This is what makes a table-driven curve look drawn rather than plotted.
 */

/*
 * A reference line: 2 x 2 dots on a four-pixel pitch, two pixels of air between
 * them. This is how every line under a figure is drawn now — the unity diagonal of
 * the compressor, the register lines, a delay grid, a zero line. It is a different
 * PATTERN from the curve, not a thinner or dimmer stroke: the owner's rule is two
 * pixels everywhere, and a dot is two by two.
 */
/*
 * The field. Every graph is plotted from its own natural y values and then
 * scaled to the field's own extremes, so the same 44 x 40 box is filled by a
 * filter response, a reverb tail or a chorus, and no figure carries its own
 * idea of how tall it should be. A flat curve sits on the centre row.
 */
static void pv_plot(uint8_t *m, int x0, const int *y, int n)
{
    for (int i = 0; i + 2 < n; i += 2) {
        pv_stroke(m, x0 + i, y[i], x0 + i + 2, y[i + 2]);
    }
    if (((n - 1) & 1) != 0) {
        pv_stroke(m, x0 + n - 3, y[n - 3], x0 + n - 1, y[n - 1]);
    }
}

/*
 * The field. Every graph is plotted from its own natural y values and then
 * scaled to the field's own extremes, so the same 44 x 40 box is filled by a
 * filter response, a reverb tail or a chorus, and no figure carries its own
 * idea of how tall it should be. A flat curve sits on the centre row.
 *
 * The curve is a chain of 2 x 2 blocks, sampled every second column: a run per
 * column put two blocks on the same row at every cusp, and the cusp measured
 * four pixels wide.
 */
static void pv_curve(uint8_t *m, int x0, const int *y, int n)
{
    int lo = y[0];
    int hi = y[0];
    for (int i = 1; i < n; i++) {
        if (y[i] < lo) {
            lo = y[i];
        }
        if (y[i] > hi) {
            hi = y[i];
        }
    }
    const int span = hi - lo;
    int ny[64] = { 0 };
    int i_lo = 0;
    int i_hi = 0;
    for (int i = 0; i < n && i < 64; i++) {
        if (span < 2) {
            ny[i] = (PV_FY0 + PV_FY1) / 2;
        } else {
            ny[i] = pv_even(PV_FY0 + ((y[i] - lo) * (PV_FY1 - PV_FY0)) / span);
            if (y[i] == lo) {
                i_lo = i;
            }
            if (y[i] == hi) {
                i_hi = i;
            }
        }
    }
    pv_plot(m, x0, ny, n);
    /* The plot walks with a two pixel step and can step over the row it was
     * aiming at; the extremes are therefore stamped, so every curve fills the
     * field's height exactly instead of coming up a row short. */
    if (span >= 2) {
        pv_stamp(m, pv_even(x0 + i_lo), PV_FY0, 2);
        pv_stamp(m, pv_even(x0 + i_hi), PV_FY1, 2);
    }
}

static void pv_vline(uint8_t *m, int x, int y0, int y1, int s)
{
    for (int y = y0; y <= y1 + s - 1; y++) {
        for (int dx = 0; dx < s; dx++) {
            pv_px(m, x + dx, y);
        }
    }
}

/* x + 0.5, for a positive coordinate. The drawing paths only ever deal in
 * non-negative pixels, and this keeps them off libm's rounding. */
static int pv_round(float v)
{
    return (int)(v + 0.5f);
}

/* A 16-entry table at position pos = 0..15, linearly interpolated. */
static float pv_tab(const int8_t *t, float pos)
{
    if (pos <= 0.0f) {
        return (float)t[0];
    }
    if (pos >= 15.0f) {
        return (float)t[15];
    }
    const int i = (int)pos;
    const float f = pos - (float)i;
    return (float)t[i] + ((float)t[i + 1] - (float)t[i]) * f;
}

/* -------------------------------------------------------------------------- */
/* What a parameter shows, and the values behind it                           */
/* -------------------------------------------------------------------------- */

/* 0..50: the value on the picture's own 50-column grid. This is the quantisation
 * the whole feature is built on — the mask cannot show more than one pixel of
 * difference, so a change smaller than 1/50 of the travel is a change that would
 * redraw the same 392 bytes. */
static int pv_q(synth_param_t p)
{
    int q = pv_round(synth_app_get_param(p) * 50.0f);
    if (q < 0) {
        q = 0;
    } else if (q > 50) {
        q = 50;
    }
    return q;
}

static int pv_index(synth_param_t p, int count)
{
    if (count < 2) {
        return 0;
    }
    int i = pv_round(synth_app_get_param(p) * (float)(count - 1));
    if (i < 0) {
        i = 0;
    } else if (i > count - 1) {
        i = count - 1;
    }
    return i;
}

typedef struct {
    uint8_t q[4];       /* 0..50 on the picture grid, or a list index in q[3] */
    uint8_t active;     /* the envelope stage the hand is on, 0..3 */
} pv_vals_t;

static synth_preview_kind_t pv_values(synth_param_t param, pv_vals_t *v)
{
    memset(v, 0, sizeof(*v));

    switch (param) {
    case SYNTH_PARAM_LEAD_ATTACK:
    case SYNTH_PARAM_LEAD_DECAY:
    case SYNTH_PARAM_LEAD_SUSTAIN:
    case SYNTH_PARAM_LEAD_RELEASE:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_LEAD_ATTACK);
        v->q[1] = (uint8_t)pv_q(SYNTH_PARAM_LEAD_DECAY);
        v->q[2] = (uint8_t)pv_q(SYNTH_PARAM_LEAD_SUSTAIN);
        v->q[3] = (uint8_t)pv_q(SYNTH_PARAM_LEAD_RELEASE);
        v->active = (uint8_t)(param == SYNTH_PARAM_LEAD_ATTACK ? 0
                            : param == SYNTH_PARAM_LEAD_DECAY   ? 1
                            : param == SYNTH_PARAM_LEAD_SUSTAIN ? 2
                                                               : 3);
        return PREVIEW_ENV;

    /* RATE and DEPTH are the filter's own LFO, and it is a sine: its shape is not a
     * control this page has. The figure used to follow the LFO page's SHAPE, which is how
     * the sweep came to trace a triangle that the filter was not sweeping; the two LFOs are
     * separate now, with their own rates, and this one is always SIN. */
    case SYNTH_PARAM_FILTER_RATE:
    case SYNTH_PARAM_FILTER_DEPTH:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_FILTER_DEPTH);
        v->q[1] = (uint8_t)pv_q(SYNTH_PARAM_FILTER_RATE);
        v->q[2] = 0;                    /* SINE, the only shape the filter's LFO has */
        return PREVIEW_SWEEP;

    /* The drone's filter is one picture from the three knobs that shape it: CUTOFF
     * and RESONANCE say where the corner and the peak are, MODE says which of the
     * three shapes the corners make.
     */    case SYNTH_PARAM_CUTOFF:
    case SYNTH_PARAM_RESONANCE:
    case SYNTH_PARAM_DRONE_FILTER_MODE:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_CUTOFF);
        v->q[1] = (uint8_t)pv_q(SYNTH_PARAM_RESONANCE);
        v->q[2] = (uint8_t)pv_q(SYNTH_PARAM_DRONE_FILTER_MODE);
        return PREVIEW_FILTER;

    case SYNTH_PARAM_MASTER_COMP:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_MASTER_COMP);
        return PREVIEW_COMP;

    case SYNTH_PARAM_LEAD_WAVE:
    case SYNTH_PARAM_DRONE_OSC_LOW:
    case SYNTH_PARAM_DRONE_OSC_MID:
    case SYNTH_PARAM_DRONE_OSC_HIGH:
        v->q[0] = (uint8_t)pv_index(param, synth_app_param_steps(param));
        return PREVIEW_WAVE;

    /*
     * MIX HAS NO PICTURE. The owner's rule for the effects: what is mixed in is read
     * off the arc and the number, and a figure in the middle would be one more thing
     * saying the same. The sends pages are where a level gets drawn.
     */
    case SYNTH_PARAM_DELAY_MIX:
    case SYNTH_PARAM_VERB_MIX:
    case SYNTH_PARAM_CHORUS_MIX:
        return PREVIEW_NONE;

    /* DELAY FEEDBACK has its own: see pv_delay_feedback(). */
    case SYNTH_PARAM_DELAY_FEEDBACK:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_DELAY_FEEDBACK);
        return PREVIEW_DELAY_FEEDBACK;

    /* The owner asked for no graph of the delay's own time and no graph of its division
     * either: the readout and the word beside it already say what the knob is set to, and
     * a comb in the middle of the dial on a page whose FDBK sector already draws one was
     * one figure too many. The delay sends keep their diamonds. */
    case SYNTH_PARAM_DELAY_TIME:
    case SYNTH_PARAM_DELAY_SYNC:
        return PREVIEW_NONE;

    /* REVERB SIZE has its own: see pv_verb_size(). */
    case SYNTH_PARAM_VERB_SIZE:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_VERB_SIZE);
        return PREVIEW_VERB_SIZE;

    case SYNTH_PARAM_VERB_DAMP:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_VERB_DAMP);
        return PREVIEW_VERB_DAMP;

    case SYNTH_PARAM_VERB_MODE: {
        const int count = synth_app_param_steps(SYNTH_PARAM_VERB_MODE);
        v->q[0] = (uint8_t)pv_index(SYNTH_PARAM_VERB_MODE, count);
        v->q[1] = (uint8_t)(count > 0 ? count : 1);
        return PREVIEW_VERB_MODE;
    }

    /*
     * THE SEND SECTIONS. The sends are where these figures belong: each of the three
     * sends pages hands the voice to one effect, and every sector of a page shows the
     * same figure, so the page reads as one thing while the hand moves along it —
     * rings for the reverb sends, diamonds for the delay sends, capsules for the
     * chorus sends. How much is sent is carried by the figure itself: a quarter of
     * the travel adds a ring or a diamond, and the chorus parts its capsules.
     *
     * THE EFFECTS ARE NOT TOUCHED. Their own pages keep the tail, the echoes, the
     * two waves, the division comb and the two time modes they have always had.
     */
    case SYNTH_PARAM_SEND_LEAD:
    case SYNTH_PARAM_SEND_PERC:
    case SYNTH_PARAM_SEND_LOW:
    case SYNTH_PARAM_SEND_MID:
    case SYNTH_PARAM_SEND_HIGH:
        v->q[0] = (uint8_t)pv_q(param);
        return PREVIEW_VERB_SECTOR;

    case SYNTH_PARAM_DLY_SEND_LEAD:
    case SYNTH_PARAM_DLY_SEND_PERC:
    case SYNTH_PARAM_DLY_SEND_LOW:
    case SYNTH_PARAM_DLY_SEND_MID:
    case SYNTH_PARAM_DLY_SEND_HIGH:
        v->q[0] = (uint8_t)pv_q(param);
        return PREVIEW_DELAY_SECTOR;

    case SYNTH_PARAM_CHR_SEND_LEAD:
    case SYNTH_PARAM_CHR_SEND_PERC:
    case SYNTH_PARAM_CHR_SEND_LOW:
    case SYNTH_PARAM_CHR_SEND_MID:
    case SYNTH_PARAM_CHR_SEND_HIGH:
        v->q[0] = (uint8_t)pv_q(param);
        return PREVIEW_CHORUS_SECTOR;

    /* The lead's filter: the same figure as the drone's, from the lead's own corner,
     * Q and mode. The two filters are the same two-pole one, so drawing them
     * differently would be inventing a difference the ear does not hear. */
    case SYNTH_PARAM_LEAD_CUTOFF:
    case SYNTH_PARAM_LEAD_RESO:
    case SYNTH_PARAM_LEAD_FILTER_MODE:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_LEAD_CUTOFF);
        v->q[1] = (uint8_t)pv_q(SYNTH_PARAM_LEAD_RESO);
        v->q[2] = (uint8_t)pv_q(SYNTH_PARAM_LEAD_FILTER_MODE);
        return PREVIEW_LEAD_FILTER;

    case SYNTH_PARAM_LEAD_ENV:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_LEAD_ENV);
        v->active = 0;
        return PREVIEW_LEAD_ENV;

    case SYNTH_PARAM_LEAD_FENV_SHAPE:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_LEAD_FENV_SHAPE);
        v->active = 0;
        return PREVIEW_LEAD_FENV_SHAPE;

    case SYNTH_PARAM_LEAD_VOICE:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_LEAD_VOICE);
        v->active = 0;
        return PREVIEW_LEAD_VOICE;

    /* GATE and PORTA: the owner drew both ends of each figure, so both ends are his and the
     * frames between them are the runs sliding. GATE opens, PORTA rounds its corners. */
    case SYNTH_PARAM_SEQ_GATE:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_SEQ_GATE);
        v->active = 0;
        return PREVIEW_LEAD_GATE;

    case SYNTH_PARAM_LEAD_PORTA:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_LEAD_PORTA);
        v->active = 0;
        return PREVIEW_LEAD_PORTA;

    /* SHAPE, SPEED and DEPTH are one figure: the LFO wave, with the shape, the
     * turns across the picture and the reach of the swing as the three things that
     * change.
     *
     * THE SINE IS THE SWEEP FIGURE, the same one the drone filter's RATE and DEPTH
     * draw: it is the same wave, so it is drawn by the same code and reads the same
     * on both pages. The other shapes keep the eight-shape figure until each gets
     * its own drawing. */
    case SYNTH_PARAM_LFO_SHAPE:
    case SYNTH_PARAM_MOTION_RATE:
    case SYNTH_PARAM_MOD_DEPTH: {
        const int shape = pv_index(SYNTH_PARAM_LFO_SHAPE,
                                   synth_app_param_steps(SYNTH_PARAM_LFO_SHAPE));
        if (shape == PV_LFO_SHAPE_MIC) {
            /* MIC: the envelope is the comb, the depth is how far the line has fallen. */
            v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_MOD_DEPTH);
            return PREVIEW_LFO_MIC;
        }
        if (shape <= 6) {                 /* все волны: SIN TRI SQR SAW RANDOM ENV+ ENV- */
            v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_MOD_DEPTH);
            v->q[1] = (uint8_t)pv_q(SYNTH_PARAM_MOTION_RATE);
            v->q[2] = (uint8_t)shape;
            return PREVIEW_SWEEP;
        }
        v->q[0] = (uint8_t)shape;
        v->q[1] = (uint8_t)pv_q(SYNTH_PARAM_MOTION_RATE);
        v->q[2] = (uint8_t)pv_q(SYNTH_PARAM_MOD_DEPTH);
        v->q[3] = (uint8_t)pv_index(SYNTH_PARAM_MOD_TRIG,
                                    synth_app_param_steps(SYNTH_PARAM_MOD_TRIG));
        return PREVIEW_LFO;
    }

    case SYNTH_PARAM_MOD_TRIG:
        v->q[0] = (uint8_t)pv_index(SYNTH_PARAM_MOD_TRIG,
                                    synth_app_param_steps(SYNTH_PARAM_MOD_TRIG));
        return PREVIEW_TRIG;

    /* THE SETTINGS PAGES DRAW NO FIGURE AT ALL. SCREEN, RING, RING FX and MIC set the panel
     * itself, and each of them had a symbol: a ring filled to a brightness, the same ring cut
     * into modes, a circle for the capsule. A symbol standing in for a value the readout
     * prints is exactly the picture that teaches the eye to stop reading, and the owner's
     * verdict was that the settings pages are not where art belongs. OPTIONS never had one.
     * The three kinds — MIC, RING, RING MODE — were the whole of their audience and are gone
     * with them. */
    case SYNTH_PARAM_SET_MIC:
    case SYNTH_PARAM_SET_RING:
    case SYNTH_PARAM_SET_SCREEN:
    case SYNTH_PARAM_SET_RINGMODE:
        return PREVIEW_NONE;

    case SYNTH_PARAM_DELAY_TIMEMODE:
        v->q[0] = (uint8_t)pv_index(SYNTH_PARAM_DELAY_TIMEMODE,
                                    synth_app_param_steps(SYNTH_PARAM_DELAY_TIMEMODE));
        return PREVIEW_DELAY_MODE;

    /* Both knobs of the chorus have their own now: DEPTH the clover of four rings, RATE the
     * chain of rectangles. */
    case SYNTH_PARAM_CHORUS_DEPTH:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_CHORUS_DEPTH);
        return PREVIEW_CHORUS_DEPTH;

    case SYNTH_PARAM_CHORUS_RATE:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_CHORUS_RATE);
        return PREVIEW_CHORUS_RATE;

    case SYNTH_PARAM_LEVEL:
        /* MASTER's VOL. The owner asked for no graph of the volume: the arc and
         * the readout already say it, and a bar in the middle of the dial was one
         * more thing to read on a page that is a mixer, not a meter. */
        return PREVIEW_NONE;

    case SYNTH_PARAM_MASTER_DUCK:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_MASTER_DUCK);
        return PREVIEW_DUCK;

    case SYNTH_PARAM_DRONE_FOLLOW: {
        const int count = synth_app_param_steps(SYNTH_PARAM_DRONE_FOLLOW);
        v->q[0] = (uint8_t)pv_index(SYNTH_PARAM_DRONE_FOLLOW, count);
        v->q[1] = (uint8_t)count;
        return PREVIEW_FOLLOW;
    }

    /* WIDTH, the drone page's fourth sector, draws the chorus depth figure: the owner asked
     * for one and the same picture wherever the knob widens something. It was three lines
     * spreading apart; the clover of four rings says the same thing louder, and the two
     * knobs travel over the same 0..50 range, so nothing had to be rescaled. */
    case SYNTH_PARAM_MOTION_DEPTH:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_MOTION_DEPTH);
        return PREVIEW_CHORUS_DEPTH;

    /* Both accent figures, and each with the step count of its own part: the lead's figure
     * is as long as the sequencer's bar, the drum's as long as the Euclid figure, and a
     * pattern shorter than sixteen steps repeats in the picture the way it repeats in sound. */
    case SYNTH_PARAM_SEQ_ACCENT:
    case SYNTH_PARAM_ARP_ACCENT:
    case SYNTH_PARAM_PERC_ACCENT: {
        /* The arp's figure sits on the transport's grid, not on its own LEN: the marks fall on
         * the sequencer's bar, which is why ARP ACCENT follows SEQ STEPS. */
        const synth_param_t steps = (param == SYNTH_PARAM_PERC_ACCENT) ? SYNTH_PARAM_PERC_STEPS
                                                                     : SYNTH_PARAM_SEQ_STEPS;
        v->q[0] = (uint8_t)pv_index(param, synth_app_param_steps(param));
        /* Длина бара, а не номер значения ручки: см. synth_app_bar_steps(). */
        v->q[1] = (uint8_t)synth_app_bar_steps(steps);
        v->q[2] = synth_app_weak_hits_are_off() ? 1u : 0u;
        return PREVIEW_ACCENT;
    }

    case SYNTH_PARAM_PERC_PITCH:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_PERC_PITCH);
        return PREVIEW_PERC_PITCH;

    case SYNTH_PARAM_PERC_QUANT:
        v->q[0] = (uint8_t)pv_index(SYNTH_PARAM_PERC_QUANT,
                                    synth_app_param_steps(SYNTH_PARAM_PERC_QUANT));
        return PREVIEW_PERC_QUANT;

    case SYNTH_PARAM_PERC_DECAY:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_PERC_DECAY);
        return PREVIEW_PERC_DECAY;

    case SYNTH_PARAM_PERC_BODY:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_PERC_BODY);
        return PREVIEW_PERC_BODY;

    case SYNTH_PARAM_PERC_ENV:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_PERC_ENV);
        return PREVIEW_PERC_ENV;

    /* SWING is how late the second sixteenth sits, so it is the one knob of the percussion
     * page whose value is a POSITION rather than an amount, and it gets the ruler. */
    case SYNTH_PARAM_PERC_SWING:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_PERC_SWING);
        return PREVIEW_SWING;

    /* DECAY gets one hit's envelope: see pv_perc_length(). The page's DECAY is PERC_LENGTH. */
    case SYNTH_PARAM_PERC_LENGTH:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_PERC_LENGTH);
        return PREVIEW_PERC_LENGTH;

    /* TONE gets the ring on its thread: see pv_tone(). */
    case SYNTH_PARAM_PERC_TONE:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_PERC_TONE);
        return PREVIEW_TONE;

    /* PUNCH gets the figure the owner drew: the ring cut into rays. See pv_punch(). The page
     * used to call this knob BODY and it changed nothing audible that the kit's own body did
     * not already do; the parameter number is the same, so a preset keeps its place. */
    case SYNTH_PARAM_PERC_BODY_TRIM:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_PERC_BODY_TRIM);
        return PREVIEW_PUNCH;

    /* TIMBRE gets the comb on its arch: see pv_timbre(). The knob already owns this parameter,
     * so nothing but the figure changes; the tines' lengths are the owner's two frames. */
    case SYNTH_PARAM_PERC_TIMBRE:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_PERC_TIMBRE);
        return PREVIEW_PERC_TIMBRE;

    /* SCATTER gets the diamond and the stripes: see pv_scatter(). The knob is on the lead's
     * euclid page and had no figure at all; the stripes are the owner's six frames. */
    case SYNTH_PARAM_SEQ_SCATTER:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_SEQ_SCATTER);
        return PREVIEW_SEQ_SCATTER;

    /* NOTE gets the twelve tonic icons: see pv_note(). It is the one knob on SCALE's page whose
     * value is a name rather than an amount — twelve positions, C to B — so it is drawn as twelve
     * drawings, one per position, in the list's own order. The mask carries the icon whole: no
     * offset, no formula, nothing between his drawing and the screen. */
    case SYNTH_PARAM_ROOT:
        v->q[0] = (uint8_t)pv_index(SYNTH_PARAM_ROOT, PV_NOTE_COUNT);
        return PREVIEW_NOTE;

    /* DENSITY gets the sixteen rings: see pv_density(). The knob is the probability that a step
     * sounds at all, so the figure is sixteen coins rather than sixteen cells — one ring per step
     * of the grid, each with a threshold of its own, and the owner's 44 x 44 sample for the ring. */
    case SYNTH_PARAM_DENSITY:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_DENSITY);
        return PREVIEW_DENSITY;

    /* VAR gets the tree: see pv_var(). */
    case SYNTH_PARAM_PERC_VARIATION:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_PERC_VARIATION);
        return PREVIEW_VAR;

    /* FILL gets the bar filling up: see pv_fill(). */
    case SYNTH_PARAM_PERC_FILL:
        v->q[0] = (uint8_t)pv_q(SYNTH_PARAM_PERC_FILL);
        return PREVIEW_FILL;

    /* GROOVE gets the part itself drawn: see pv_groove(). */
    case SYNTH_PARAM_PERC_GROOVE:
        v->q[0] = (uint8_t)pv_index(SYNTH_PARAM_PERC_GROOVE,
                                    synth_app_param_steps(SYNTH_PARAM_PERC_GROOVE));
        return PREVIEW_GROOVE;

    /* THE ARP PAGE HAS ONE FIGURE, ON THE DIRECTION. SPEED, LEN and RANGE have none.
     * They used to share one ladder: the same run drawn with the treads of the number in
     * hand, which at a glance said "an arpeggio" and said nothing about which sector the
     * knob was on. A figure that is the same picture in three places teaches the eye to stop
     * reading it, so the two knobs that are a count and a length now carry the number and the
     * panel's own label, and only the direction — the one setting that is a shape — keeps art. */
    case SYNTH_PARAM_ARP_DIR:
        v->q[0] = (uint8_t)pv_index(SYNTH_PARAM_ARP_DIR,
                                    synth_app_param_steps(SYNTH_PARAM_ARP_DIR));
        return PREVIEW_ARP;

    case SYNTH_PARAM_ARP_SPEED:
    case SYNTH_PARAM_ARP_LEN:
    case SYNTH_PARAM_ARP_RANGE:
        return PREVIEW_NONE;

    default:
        return PREVIEW_NONE;
    }
}

synth_preview_kind_t synth_preview_kind(synth_param_t param)
{
    pv_vals_t v;
    return pv_values(param, &v);
}

uint32_t synth_preview_key(synth_param_t param)
{
    pv_vals_t v;
    const synth_preview_kind_t kind = pv_values(param, &v);

    if (kind == PREVIEW_NONE) {
        return 0;
    }

    /* Six bits of kind, two of focus, four six-bit values: one word still says
     * everything the 392 bytes depend on. The kind grew past four bits when the
     * second set arrived and past five when the sends got their own figures, so the
     * fields were moved up rather than allowed to overlap the old layout. */
    uint32_t key = (uint32_t)kind | ((uint32_t)(v.active & 0x03u) << 6);
    for (int i = 0; i < 4; i++) {
        key |= (uint32_t)(v.q[i] & 0x3Fu) << (8 + 6 * i);
    }
    return key;
}

/* -------------------------------------------------------------------------- */
/* The seven figures                                                          */
/* -------------------------------------------------------------------------- */

/*
 * ENVELOPE. Time runs left to right and only left to right: the attack rises from
 * the floor to the peak, the decay falls to the sustain, the sustain holds, the
 * release falls back to the floor.
 *
 * THE FIGURE IS 44 x 44 AND SITS IN THE MIDDLE OF THE FRAME. Its curve is drawn in
 * a 40 x 40 field inside that area — eight pixels from the edge of the 56 x 56
 * frame, two inside the 44 — and those two pixels of inset are exactly what the ring
 * on a vertex spends, so a vertex in a corner of the field puts the mark's edge on
 * the edge of the 44 and never outside it. The field is built on the ten-pixel
 * division: four divisions across, four down.
 *
 * ONE LINE USES THE WHOLE 44: the floor. It runs from the left edge of the area to
 * the right one — two pixels past the field on each side — because it is the time
 * axis the four stages are measured on, not a border of the drawing field. Below it
 * two pixels of the area stay empty: the floor is the field's bottom row, and the
 * field is two pixels above the bottom of the 44.
 *
 * THE LEFT END DOES NOT MOVE. Everything is measured from the point where the curve
 * leaves the floor, the way the time axis of an envelope is: the peak sits at
 * ATTACK, the knee of the decay at ATTACK + DECAY, the end of the sustain ten
 * pixels further on, and the tail at RELEASE past that. Each of the three times
 * gets ten pixels of the forty, so a stage at full travel is one division of the
 * grid; the sustain has no knob of its own and takes the ten between the knee and
 * the tail. The level is the full height, and the floor is the bottom row.
 *
 * THE STAGE UNDER THE HAND IS THE SQUARE. A four-by-four ring of single pixels with
 * a two-pixel hole — the hole is exactly the block the vertex is drawn with, so the
 * ring sits on the vertex and never beside it — and one pixel of free mask around
 * the ring, so the curve breaks and the mark reads as a mark rather than as a thick
 * place in the line. The four stages are otherwise the same weight: selection has
 * never been a thicker line on this instrument, and it is not one here either.
 */
static void pv_env(uint8_t *m, const pv_vals_t *v)
{
    /* The field in the mask's own coordinates, before s_pv_ox: 40 wide and 40 tall
     * at eight of margin, which is two pixels inside the 44 x 44 figure area. The
     * floor runs two pixels further out than the field on both sides; see below. */
    enum { FX = 4, FY = 8, RIGHT = 38, FLOOR = 38, HOLD = 10, EDGE = 2 };

    /* The four knobs on the ten-pixel grid: the three times take a division each,
     * the sustain holds the ten between the knee and the tail, the level is the
     * height. pv_q() is 0..50, so a knob at the top of its travel is ten pixels. */
    const int wa = pv_even_near((int)v->q[0] * 10 / 50);
    const int wd = pv_even_near((int)v->q[1] * 10 / 50);
    const int wr = pv_even_near((int)v->q[3] * 10 / 50);
    const int level = pv_even_near((int)v->q[2] * FLOOR / 50);

    const int peak = wa;
    const int dec = peak + wd;
    int hold = dec + HOLD;
    int rel = hold + wr;

    /* Nothing leaves the field. The sustain gives way first, because it is the one
     * stage with no knob: three knobs at full travel still have to fit. */
    while (rel > RIGHT && hold - dec > 2) {
        hold -= 2;
        rel = hold + wr;
    }
    if (rel > RIGHT) {
        rel = RIGHT;
    }

    const int ys = FLOOR - level;

    pv_stroke(m, FX, FY + FLOOR, FX + peak, FY);
    pv_stroke(m, FX + peak, FY, FX + dec, FY + ys);
    pv_stroke(m, FX + dec, FY + ys, FX + hold, FY + ys);
    pv_stroke(m, FX + hold, FY + ys, FX + rel, FY + FLOOR);

    /* The floor, edge to edge of the 44: two pixels past the field at each end, so
     * the axis the stages are read against is the width of the figure. The two
     * pixels below it stay empty. */
    pv_stroke(m, FX - EDGE, FY + FLOOR, FX + RIGHT + EDGE, FY + FLOOR);

    int hx;
    int hy;
    switch (v->active) {
    case 0:                                     /* ATTACK: the peak */
        hx = peak;
        hy = 0;
        break;
    case 1:                                     /* DECAY: the knee */
        hx = dec;
        hy = ys;
        break;
    case 2:                                     /* SUSTAIN: the middle of the hold */
        hx = dec + (hold - dec) / 2;
        hy = ys;
        break;
    default:                                    /* RELEASE: the end of the tail */
        hx = rel;
        hy = FLOOR;
        break;
    }
    pv_mark(m, FX + hx, FY + hy);
}

/*
 * FILTER. The response the knob makes, drawn the owner's way: a shelf, a corner and
 * one straight skirt, on the same ten-pixel grid as the envelope.
 *
 * THE FIGURE IS THE 44 x 44 FIGURE AREA, the same one pv_env() uses: the field is
 * 40 x 40 at columns and rows 8..47 — two pixels inside the 44 — and the floor runs
 * the whole area, columns 6..49, with two pixels of air below it. The shelf sits on
 * the field's exact middle, rows 27..28, which is the middle of the screen; the
 * floor is the field's last block, rows 46..47.
 *
 * THREE THINGS MOVE, and each knob owns one of them. CUTOFF moves the corner across
 * the field, 0..40 px; RESONANCE lifts the peak above the shelf, up to the field's
 * top block; MODE decides what the corners are.
 *
 * THE SHELF NEVER SHORTENS. Its length is the same at every MODE: it is the pass
 * band, and a shelf that shrank as the mode turned would be drawing a different
 * filter. What changes is its height — it descends from the middle to the floor and
 * back. At the middle of the travel it lies on the floor, merges with it, and the
 * two skirts are all that is left: the band pass is exactly the hump that survives.
 * That is why MODE needs no third shape: the three are one figure at three heights.
 *
 * THE SKIRT IS ALWAYS ONE DIVISION WIDE, ten pixels, and it never disappears at the
 * edge of the field: a corner at the last column still gets its skirt, which runs
 * out of the area and is clipped by it. Hiding it left the flat shelf with no sign
 * of where the filter turns. For the same reason the shelf is drawn only while its
 * far end is inside the field: a clipped-off reminder of it would sit at the edge as
 * one block with nothing attached — a dot, not a shelf.
 *
 * THE STROKE STEPS ONE PIXEL here (pv_stroke_fine), because a forty-five degree
 * skirt drawn with the two-pixel step falls apart into a row of dots.
 *
 * Both filters use this figure: the drone's corner and Q on the drone page, the
 * lead's on the lead page. The two are the same two-pole filter, so they are the
 * same picture.
 */
static void pv_filter(uint8_t *m, const pv_vals_t *v)
{
    /* The figure area starts at column 6, the field two pixels in at 8, and the
     * field is 40 wide and tall. The skirt is one division, the ten of the grid. */
    enum { EDGE = 6, FIELD = 8, WIDE = 40, RIGHT = 48, MID = 27, FLOOR = 46,
           KNEE = 10, LIFT = 19 };

    const int corner = FIELD + (int)v->q[0] * WIDE / 50;
    const int peak = MID - (int)v->q[1] * LIFT / 50;

    /* MODE is 0..50 on the knob and 0..100 here: 0 is the low pass, 50 the band,
     * 100 the high. Only the shelf's height reads it. */
    const int mode = (int)v->q[2] * 2;
    const int shelf = mode <= 50 ? MID + (FLOOR - MID) * mode / 50
                                 : FLOOR - (FLOOR - MID) * (mode - 50) / 50;

    if (mode <= 50) {
        if (corner - KNEE > EDGE) {
            pv_stroke_fine(m, EDGE, shelf, corner - KNEE, shelf);
        }
        pv_stroke_fine(m, corner - KNEE, shelf, corner, peak);
        pv_stroke_fine(m, corner, peak, corner + KNEE, FLOOR);
    } else {
        pv_stroke_fine(m, corner - KNEE, FLOOR, corner, peak);
        pv_stroke_fine(m, corner, peak, corner + KNEE, shelf);
        if (corner + KNEE < RIGHT) {
            pv_stroke_fine(m, corner + KNEE, shelf, RIGHT, shelf);
        }
    }

    /* The floor, edge to edge of the 44, exactly as the envelope draws it. */
    pv_stroke_fine(m, EDGE, FLOOR, RIGHT, FLOOR);
}

/*
 * SWEEP. The modulation's own wave, drawn for the two knobs that shape it: DEPTH is
 * the reach above and below the middle line, RATE is how many turns the same width
 * holds — half a turn at the bottom of the knob, one in the middle, two at the top,
 * doubling in each half.
 *
 * THE FIGURE IS THE FILTER'S OWN: the same 44 x 44 area, the same 40-pixel field at
 * 8..46, and the middle of the screen — rows 27..28 — is the line the corner sits on
 * when the LFO is at zero. At DEPTH zero the whole figure is that middle line and
 * every step of the knob lifts the wave out of it in both directions by the same
 * amount; at full depth its extremes touch the field's top and bottom blocks. There
 * is no axis line under it: a wave is read against its own middle, and a floor would
 * only add a second horizontal.
 *
 * ONE PICTURE PER SHAPE, ONE GRID FOR ALL OF THEM. Every waveform the shape list
 * holds (SINE, TRI, SQR, SAW, RANDOM, EXP+, EXP-) is drawn on the same field, with
 * the same middle line and the same reach, so the SHAPE knob changes the shape and
 * nothing else. The two exponentials are the same envelope, one read backwards:
 * EXP- falls from the jump, EXP+ rises into it, so the second picture is the first
 * one mirrored. MIC — an envelope with no period at all — keeps the figure that
 * pv_lfo() draws, because RATE and DEPTH do not mean the same thing there.
 *
 * THE PHASE IS ANCHORED ON THE MIDDLE OF THE PICTURE. A turn puts the wave's peak on
 * the centre column, so at every rate the figure is symmetric about its own middle
 * and the wave compresses and stretches outward from there. The square's level flips
 * on that column, the triangle's vertex sits on it, and the saw's drop is drawn
 * there: what grows with RATE grows from the centre.
 *
 * VERTICALS ARE VERTICAL. A level change is one stroke at one column and not a slope
 * between two samples: a one-pixel step would turn a jump of half the field into a
 * diagonal, and the owner asked for this twice, on the square and on the saw.
 *
 * The sample count is a multiple of four, so a quarter turn always lands on a
 * sample, and one step of the sine table is 1/64 of a turn, so a peak or a trough
 * lands exactly on the field's edge instead of a pixel short of it.
 */

/* The placement of one sample of the saw. The phase is measured from the middle, so
 * the ramp reaches its top on the centre column and its bottom half a turn away. */
static int pv_saw_y(int k, int samples, int depth, int mid)
{
    const int m = (((2 * k - samples) % 128) + 128) % 128;
    return mid - pv_div_round(depth * (128 - 2 * m), 128);
}

/* The hash behind the random figure: the same 32 bits as the prototype that was
 * approved, so the picture on the screen is the picture on the sheet. */
static uint32_t pv_rnd(uint32_t seed, uint32_t i)
{
    uint32_t x = seed * 2654435761u + i * 40503u + 12345u;
    x ^= x >> 13;
    x *= 1274126177u;
    x ^= x >> 16;
    return x >> 8;
}

static void pv_sweep(uint8_t *m, const pv_vals_t *v)
{
    enum { FX = 8, RIGHT = 46, MID = 27, AMP = 19 };

    /* q[0] — глубина 0..50, q[1] — темп 0..50, q[2] — форма: 0 SIN, 1 TRI,
     * 2 SQR, 3 SAW, 4 RANDOM. */
    const int depth = pv_div_round((int)v->q[0] * AMP, 50);
    const int shape = (int)v->q[2];
    const int width = RIGHT - FX;
    const int q = (int)v->q[1];
    const int raw = q <= 25 ? 32 + q * 32 / 25 : 64 + (q - 25) * 64 / 25;
    const int samples = ((raw + 3) / 4) * 4;

    /* Фаза в шагах таблицы: один шаг — 1/64 оборота, вершина на центральном
     * отсчёте. Отрицательные индексы заворачиваются тем же & 63. */
    const int phase0 = 16 - samples / 2;

#define PV_X(k) (FX + pv_div_round(width * (k), samples))
#define PV_AT(k) ((phase0 + (k)) & 63)
#define PV_Y(val1000) (MID - pv_div_round(depth * (val1000), 1000))

    if (shape == 4) {
        /* RANDOM: ступени. Уровни и стыки лежат на решётке 10 px — из-за этого
         * случайность и видна; раскладку задаёт зерно, а число полок растёт с
         * темпом: две внизу, три в середине, четыре наверху. */
        static const int INNER[3] = { 18, 28, 38 };   /* 10, 20 и 30 поля */
        static const int LEVEL[5] = { 8, 18, 28, 38, 46 };

        const int bands = 2 + (q >= 17 ? 1 : 0) + (q >= 34 ? 1 : 0);
        uint32_t key[3];
        int val[3];
        for (int i = 0; i < 3; i++) {
            key[i] = pv_rnd(s_pv_seed, (uint32_t)i);
            val[i] = INNER[i];
        }
        /* ключи хеша по возрастанию, при равенстве — по координате */
        for (int i = 1; i < 3; i++) {
            const uint32_t kk = key[i];
            const int vv = val[i];
            int j = i - 1;
            while (j >= 0 && (key[j] > kk || (key[j] == kk && val[j] > vv))) {
                key[j + 1] = key[j];
                val[j + 1] = val[j];
                j--;
            }
            key[j + 1] = kk;
            val[j + 1] = vv;
        }
        int bounds[3] = { RIGHT, RIGHT, RIGHT };
        for (int i = 0; i < bands - 1; i++) {
            bounds[i] = val[i];
        }
        for (int i = 1; i < bands - 1; i++) {      /* и по возрастанию координаты */
            const int b = bounds[i];
            int j = i - 1;
            while (j >= 0 && bounds[j] > b) {
                bounds[j + 1] = bounds[j];
                j--;
            }
            bounds[j + 1] = b;
        }
        int lev[4] = { 0, 0, 0, 0 };
        for (int b = 0; b < bands; b++) {
            const uint32_t h = pv_rnd(s_pv_seed, (uint32_t)(10 + b));
            int idx = (int)(((h * 5u) >> 24) % 5u);
            if (b > 0 && idx == lev[b - 1]) {
                idx = (idx + 1) % 5;
            }
            lev[b] = idx;
        }
        /* The shelves are placed by RATE — two at the bottom of the knob, three in the
         * middle, four at the top — and they are only ever moved off the middle line by
         * DEPTH. This used to scale them with the rate as well, which made the picture
         * blind to DEPTH and made RATE do two things at once: at RATE 0 every shelf
         * collapsed onto the line and no amount of depth brought them back. */
        int x0 = FX;
        int yprev = MID + pv_div_round((LEVEL[lev[0]] - MID) * depth, AMP);
        for (int b = 0; b < bands; b++) {
            const int y = MID + pv_div_round((LEVEL[lev[b]] - MID) * depth, AMP);
            const int x1 = (b == bands - 1) ? RIGHT : bounds[b];
            pv_stroke_fine(m, x0, y, x1, y);                    /* полка */
            if (b > 0) {
                pv_stroke_fine(m, x0, yprev, x0, y);            /* ступень */
            }
            x0 = x1;
            yprev = y;
        }
        return;
    }

    if (shape == 0) {                                            /* SINE */
        int px = FX;
        int py = PV_Y(PV_CSIN[PV_AT(0)]);
        for (int k = 1; k <= samples; k++) {
            const int x = PV_X(k);
            const int y = PV_Y(PV_CSIN[PV_AT(k)]);
            pv_stroke_fine(m, px, py, x, y);
            px = x;
            py = y;
        }
        return;
    }

    if (shape == 1) {
        /* TRI: прямые между вершинами. Вершины там, где синус равен ±1 — центр и
         * через полоборота от него, то есть 32 отсчёта. */
        int px = FX;
        int py = PV_Y(PV_CSIN[PV_AT(0)]);
        for (int mm = -8; mm <= 8; mm++) {
            const int k = samples / 2 + 32 * mm;
            if (k <= 0 || k >= samples) {
                continue;
            }
            const int x = PV_X(k);
            const int y = PV_Y(PV_CSIN[PV_AT(k)] >= 0 ? 1000 : -1000);
            pv_stroke_fine(m, px, py, x, y);
            px = x;
            py = y;
        }
        pv_stroke_fine(m, px, py, RIGHT, PV_Y(PV_CSIN[PV_AT(samples)]));
        return;
    }

    if (shape == 2) {
        /* SQR: косинус неотрицателен — верхний уровень. Переключение ровно на
         * центральном столбце и через полоборота от него, поэтому на полуобороте
         * виден один перепад, на обороте — полный цикл, на двух — два. Уровень
         * берётся не на краю, где косинус ровно ноль и знак неопределён, а в
         * середине первой полки: там он всегда ±1000 и картинка не зависит от
         * того, в какую сторону округлится ноль. */
        int first = samples;
        for (int mm = -8; mm <= 8; mm++) {
            const int k = samples / 2 + 32 * mm;
            if (k > 0 && k < samples && k < first) {
                first = k;
            }
        }
        int lv = PV_COS[PV_AT(first / 2)] >= 0 ? 1 : -1;
        int px = FX;
        int py = MID - lv * depth;
        for (int mm = -8; mm <= 8; mm++) {
            const int k = samples / 2 + 32 * mm;
            if (k <= 0 || k >= samples) {
                continue;
            }
            const int x = PV_X(k);
            pv_stroke_fine(m, px, py, x, py);               /* полка */
            lv = -lv;
            const int y = MID - lv * depth;
            pv_stroke_fine(m, x, py, x, y);                 /* вертикаль */
            px = x;
            py = y;
        }
        pv_stroke_fine(m, px, py, RIGHT, py);
        return;
    }

    if (shape == 5 || shape == 6) {
        /* ENV: конверт на весь размах за оборот. Скачок стоит в центре картинки и
         * через оборот от него — как у пилы, поэтому темп растёт из центра и здесь.
         * ENV- падает от верха к низу, ENV+ — то же зеркало по горизонтали: одна и
         * та же таблица, прочитанная с конца. */
        const int reverse = shape == 5;
        int jumps[5];
        int nj = 0;
        for (int mm = -4; mm <= 4; mm++) {
            const int k = samples / 2 + 64 * mm;
            if (k >= 0 && k <= samples) {
                jumps[nj++] = k;
            }
        }
        for (int i = 0; i < nj; i++) {
            const int x = PV_X(jumps[i]);
            pv_stroke_fine(m, x, MID - depth, x, MID + depth);   /* скачок */
        }
        int cuts[7];
        int nc = 0;
        cuts[nc++] = 0;
        for (int i = 0; i < nj; i++) {
            if (jumps[i] != 0 && jumps[i] != samples) {
                cuts[nc++] = jumps[i];
            }
        }
        cuts[nc++] = samples;
        for (int i = 1; i < nc; i++) {
            const int c = cuts[i];
            int j = i - 1;
            while (j >= 0 && cuts[j] > c) {
                cuts[j + 1] = cuts[j];
                j--;
            }
            cuts[j + 1] = c;
        }
        for (int i = 0; i + 1 < nc; i++) {
            const int a = cuts[i];
            const int b = cuts[i + 1];
            if (a == b) {
                continue;
            }
            int px = 0;
            int py = 0;
            for (int s = 0; s <= 16; s++) {
                const int k = a + (b - a) * s / 16;
                /* ENV+ читает тот же конверт с обратной стороны: высота берётся в
                 * отражённой точке, поэтому рисунок — точное зеркало, а не похожая
                 * кривая. */
                const int ks = reverse ? (samples - k) : k;
                const int ph = (((ks - samples / 2) % 64) + 64) % 64;
                const int j = pv_div_round(ph * 32, 64);
                const int x = PV_X(k);
                const int y = PV_Y(PV_CENV[j]);
                if (s > 0) {
                    pv_stroke_fine(m, px, py, x, y);
                }
                px = x;
                py = y;
            }
        }
        return;
    }

    /* SAW: спуск на весь размах за оборот, скачок на центральном столбце — зубцы
     * расходятся от центра в обе стороны, и частота нарастает одинаково. */
    int jumps[5];
    int nj = 0;
    for (int mm = -4; mm <= 4; mm++) {
        const int k = samples / 2 + 64 * mm;
        if (k >= 0 && k <= samples) {
            jumps[nj++] = k;
        }
    }
    for (int i = 0; i < nj; i++) {
        const int x = PV_X(jumps[i]);
        pv_stroke_fine(m, x, MID - depth, x, MID + depth);      /* скачок */
    }
    int cuts[7];
    int nc = 0;
    cuts[nc++] = 0;
    for (int i = 0; i < nj; i++) {
        cuts[nc++] = jumps[i];
    }
    cuts[nc++] = samples;
    for (int i = 1; i < nc; i++) {
        const int c = cuts[i];
        int j = i - 1;
        while (j >= 0 && cuts[j] > c) {
            cuts[j + 1] = cuts[j];
            j--;
        }
        cuts[j + 1] = c;
    }
    for (int i = 0; i + 1 < nc; i++) {
        const int a = cuts[i];
        const int b = cuts[i + 1];
        if (a == b) {
            continue;
        }
        int jump_a = 0;
        int jump_b = 0;
        for (int j = 0; j < nj; j++) {
            if (jumps[j] == a) {
                jump_a = 1;
            }
            if (jumps[j] == b) {
                jump_b = 1;
            }
        }
        /* Скачок идёт снизу вверх: сразу после него значение +1, перед ним -1. */
        const int ya = jump_a ? MID - depth : pv_saw_y(a, samples, depth, MID);
        const int yb = jump_b ? MID + depth : pv_saw_y(b, samples, depth, MID);
        pv_stroke_fine(m, PV_X(a), ya, PV_X(b), yb);            /* спуск */
    }

#undef PV_X
#undef PV_AT
#undef PV_Y
}

/*
 * COMPRESSOR: the levelling itself. Nine moments in a row, each one's loudness the length of a
 * bar, the axis between them — so what the knob does is visible without a decibel scale: the
 * bars start out uneven and end up level.
 *
 * The two extremes are the owner's own 44 x 44 drawings. At COMP = 0 the lengths are 19, 15, 6,
 * 15, 10, 19, 13, 7 and 2; at the top they are 19, 19, 19, 17, 19, 19, 19, 15 and 13. Nothing
 * falls: the loud bars 1 and 6 stand at 19 at both ends, and the quiet ninth climbs from 2 to 13.
 * That is the instrument's compressor read honestly — it lifts the quiet moments to the loud one
 * instead of pushing the loud ones down, and a picture where the tallest bars came down would be
 * the one thing this figure must not say.
 *
 * Between the ends each bar travels in a straight line to its own upper value, which is the one
 * path that leaves both drawings exactly as drawn. The bar is symmetric about the axis but hangs
 * below it: the lower half is always two rows shorter, in both of his frames.
 */
#define PV_COMP_BARS 9
static const uint8_t PV_COMP_MIN[PV_COMP_BARS] = { 19, 15, 6, 15, 10, 19, 13, 7, 2 };
static const uint8_t PV_COMP_MAX[PV_COMP_BARS] = { 19, 19, 19, 17, 19, 19, 19, 15, 13 };

static void pv_comp(uint8_t *m, const pv_vals_t *v)
{
    enum {
        AXIS_TOP  = 21,   /* the axis is rows 21 and 22 of the 44 x 44 area */
        AXIS_BOT  = 22,
        BAR_LAST  = 20,   /* the upper half ends against the axis */
        BAR_FIRST = 25,   /* the lower half starts two rows below it */
        BAR_X0    = 1,    /* the leftmost bar, two pixels wide */
        BAR_STEP  = 5,
        BAR_W     = 2,
        BAR_DROP  = 2     /* how much shorter the lower half is */
    };
    const int t = (int)v->q[0] * 20;    /* 0..1000, nineteen steps of the 0..50 the knob gives */

    for (int k = 0; k < PV_COMP_BARS; k++) {
        const int a0 = PV_COMP_MIN[k];
        const int a1 = PV_COMP_MAX[k];
        /* Rounded to the nearest row, away from zero: every bar ends on its own drawing. */
        const int a = a0 + ((a1 - a0) * t + 500) / 1000;
        const int x = PV_AREA_X0 + BAR_X0 + k * BAR_STEP;

        for (int y = BAR_LAST - a + 1; y <= BAR_LAST; y++) {
            for (int dx = 0; dx < BAR_W; dx++) {
                pv_px(m, x + dx, PV_AREA_Y0 + y);
            }
        }
        for (int y = BAR_FIRST; y < BAR_FIRST + a - BAR_DROP; y++) {
            for (int dx = 0; dx < BAR_W; dx++) {
                pv_px(m, x + dx, PV_AREA_Y0 + y);
            }
        }
    }

    const int xend = PV_AREA_X0 + BAR_X0 + (PV_COMP_BARS - 1) * BAR_STEP + BAR_W - 1;
    for (int x = PV_AREA_X0 + BAR_X0; x <= xend; x++) {
        pv_px(m, x, PV_AREA_Y0 + AXIS_TOP);
        pv_px(m, x, PV_AREA_Y0 + AXIS_BOT);
    }
}

/*
 * THE SIX OSCILLATOR ICONS, converted from the owner's own 44 x 44 drawings, the same
 * way and for the same reason as the TRIG ones: one bit per pixel, MSB first, six bytes
 * to a row, and what he drew is what the screen shows. The order is the list's —
 * SIN, TRI, SAW, PLS, SPR, NSE — and the names on his files are the names in that list,
 * with SQR standing where the instrument says PLS.
 *
 * The figure used to be computed: a sine from the table, a ramp, a square, a noise walk
 * with its levels scaled to the field. Nine of a part's ten oscillators are the same four
 * shapes, and a list is read at a glance rather than measured, so the icons say what the
 * list says and the knobs keep their numbers.
 */
/* AN ICON IS THE WHOLE 44 x 44 FIGURE AREA, copied at 1:1: no offset, no brush, no
 * rounding — the mask's pixels are the screen's pixels. The three icon lists (the
 * oscillator's six shapes, TRIG's four sources, the arpeggio's seven directions) are
 * the owner's own drawings converted to bits, so the figure is his pixel work and not
 * a reconstruction of it. */
static void pv_icon(uint8_t *m, const uint8_t *src)
{
    enum { ROW_BYTES = SYNTH_PREVIEW_BYTES / SYNTH_PREVIEW_H };

    for (int row = 0; row < 44; row++) {
        for (int col = 0; col < 44; col++) {
            if (!(src[row * 6 + (col >> 3)] & (0x80u >> (col & 7)))) {
                continue;
            }
            const int x = PV_AREA_X0 + col;
            const int y = PV_AREA_Y0 + row;
            m[y * ROW_BYTES + (x >> 3)] |= (uint8_t)(0x80u >> (x & 7));
        }
    }
}

static const uint8_t PV_WAVE_ICONS[6][44 * 6] = {
    {   /* SIN */
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x3C, 0x00, 0x00, 0x00, 0x00,
        0x00, 0xFF, 0x00, 0x00, 0x00, 0x00,
        0x01, 0xC3, 0x80, 0x00, 0x00, 0x00,
        0x03, 0x00, 0xC0, 0x00, 0x00, 0x00,
        0x06, 0x00, 0x60, 0x00, 0x00, 0x00,
        0x0C, 0x00, 0x30, 0x00, 0x00, 0x00,
        0x1C, 0x00, 0x38, 0x00, 0x00, 0x10,
        0x18, 0x00, 0x18, 0x00, 0x00, 0x10,
        0x30, 0x00, 0x0C, 0x00, 0x00, 0x30,
        0x30, 0x00, 0x0C, 0x00, 0x00, 0x30,
        0x60, 0x00, 0x06, 0x00, 0x00, 0x60,
        0x60, 0x00, 0x06, 0x00, 0x00, 0x60,
        0xC0, 0x00, 0x03, 0x00, 0x00, 0xC0,
        0xC0, 0x00, 0x03, 0x00, 0x00, 0xC0,
        0x80, 0x00, 0x01, 0x80, 0x01, 0x80,
        0x80, 0x00, 0x01, 0x80, 0x03, 0x80,
        0x00, 0x00, 0x00, 0xC0, 0x03, 0x00,
        0x00, 0x00, 0x00, 0x60, 0x06, 0x00,
        0x00, 0x00, 0x00, 0x30, 0x0C, 0x00,
        0x00, 0x00, 0x00, 0x1C, 0x38, 0x00,
        0x00, 0x00, 0x00, 0x0F, 0xF0, 0x00,
        0x00, 0x00, 0x00, 0x03, 0xC0, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    },
    {   /* TRI */
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x18, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x3C, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x7E, 0x00, 0x00, 0x00, 0x00,
        0x00, 0xE7, 0x00, 0x00, 0x00, 0x00,
        0x01, 0xC3, 0x80, 0x00, 0x00, 0x00,
        0x03, 0x81, 0xC0, 0x00, 0x00, 0x00,
        0x07, 0x00, 0xE0, 0x00, 0x00, 0x00,
        0x0E, 0x00, 0x70, 0x00, 0x00, 0x00,
        0x1C, 0x00, 0x38, 0x00, 0x00, 0x00,
        0x38, 0x00, 0x1C, 0x00, 0x00, 0x00,
        0x70, 0x00, 0x0E, 0x00, 0x00, 0x60,
        0x60, 0x00, 0x07, 0x00, 0x00, 0xE0,
        0x00, 0x00, 0x03, 0x80, 0x01, 0xC0,
        0x00, 0x00, 0x01, 0xC0, 0x03, 0x80,
        0x00, 0x00, 0x00, 0xE0, 0x07, 0x00,
        0x00, 0x00, 0x00, 0x70, 0x0E, 0x00,
        0x00, 0x00, 0x00, 0x38, 0x1C, 0x00,
        0x00, 0x00, 0x00, 0x1C, 0x38, 0x00,
        0x00, 0x00, 0x00, 0x0E, 0x70, 0x00,
        0x00, 0x00, 0x00, 0x07, 0xE0, 0x00,
        0x00, 0x00, 0x00, 0x03, 0xC0, 0x00,
        0x00, 0x00, 0x00, 0x01, 0x80, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    },
    {   /* SAW */
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x60, 0x00, 0x00, 0x00, 0x00, 0x60,
        0x78, 0x00, 0x00, 0x00, 0x00, 0x60,
        0x7E, 0x00, 0x00, 0x00, 0x00, 0x60,
        0x67, 0x80, 0x00, 0x00, 0x00, 0x60,
        0x61, 0xE0, 0x00, 0x00, 0x00, 0x60,
        0x60, 0x78, 0x00, 0x00, 0x00, 0x60,
        0x60, 0x1E, 0x00, 0x00, 0x00, 0x60,
        0x60, 0x07, 0x80, 0x00, 0x00, 0x60,
        0x60, 0x01, 0xE0, 0x00, 0x00, 0x60,
        0x60, 0x00, 0x78, 0x00, 0x00, 0x60,
        0x60, 0x00, 0x1E, 0x00, 0x00, 0x60,
        0x60, 0x00, 0x07, 0x80, 0x00, 0x60,
        0x60, 0x00, 0x01, 0xE0, 0x00, 0x60,
        0x60, 0x00, 0x00, 0x78, 0x00, 0x60,
        0x60, 0x00, 0x00, 0x1E, 0x00, 0x60,
        0x60, 0x00, 0x00, 0x07, 0x80, 0x60,
        0x60, 0x00, 0x00, 0x01, 0xE0, 0x60,
        0x60, 0x00, 0x00, 0x00, 0x78, 0x60,
        0x60, 0x00, 0x00, 0x00, 0x1E, 0x60,
        0x60, 0x00, 0x00, 0x00, 0x07, 0xE0,
        0x60, 0x00, 0x00, 0x00, 0x01, 0xE0,
        0x60, 0x00, 0x00, 0x00, 0x00, 0x60,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    },
    {   /* SQR */
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x7F, 0xFF, 0xFE, 0x00, 0x00, 0x70,
        0x7F, 0xFF, 0xFE, 0x00, 0x00, 0x70,
        0x60, 0x00, 0x06, 0x00, 0x00, 0x60,
        0x60, 0x00, 0x06, 0x00, 0x00, 0x60,
        0x60, 0x00, 0x06, 0x00, 0x00, 0x60,
        0x60, 0x00, 0x06, 0x00, 0x00, 0x60,
        0x60, 0x00, 0x06, 0x00, 0x00, 0x60,
        0x60, 0x00, 0x06, 0x00, 0x00, 0x60,
        0x60, 0x00, 0x06, 0x00, 0x00, 0x60,
        0x60, 0x00, 0x06, 0x00, 0x00, 0x60,
        0x60, 0x00, 0x06, 0x00, 0x00, 0x60,
        0x60, 0x00, 0x06, 0x00, 0x00, 0x60,
        0x60, 0x00, 0x06, 0x00, 0x00, 0x60,
        0x60, 0x00, 0x06, 0x00, 0x00, 0x60,
        0x60, 0x00, 0x06, 0x00, 0x00, 0x60,
        0x60, 0x00, 0x06, 0x00, 0x00, 0x60,
        0x60, 0x00, 0x06, 0x00, 0x00, 0x60,
        0x60, 0x00, 0x06, 0x00, 0x00, 0x60,
        0x60, 0x00, 0x06, 0x00, 0x00, 0x60,
        0x60, 0x00, 0x06, 0x00, 0x00, 0x60,
        0xE0, 0x00, 0x07, 0xFF, 0xFF, 0xE0,
        0xE0, 0x00, 0x07, 0xFF, 0xFF, 0xE0,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    },
    {   /* SPR */
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x7F, 0xFE, 0x00, 0x00, 0x00, 0x60,
        0x7F, 0xFF, 0xC0, 0x00, 0x00, 0x60,
        0x63, 0xE1, 0xF0, 0x00, 0x00, 0x60,
        0x60, 0x70, 0x3C, 0x00, 0x00, 0x60,
        0x60, 0x38, 0x0E, 0x00, 0x00, 0x60,
        0x60, 0x0C, 0x07, 0x00, 0x00, 0x60,
        0x60, 0x06, 0x01, 0x80, 0x00, 0x60,
        0x60, 0x03, 0x00, 0xC0, 0x00, 0x60,
        0x60, 0x01, 0x80, 0xE0, 0x00, 0x60,
        0x60, 0x01, 0x80, 0x60, 0x00, 0x60,
        0x60, 0x00, 0xC0, 0x30, 0x00, 0x60,
        0x60, 0x00, 0xC0, 0x30, 0x00, 0x60,
        0x60, 0x00, 0x60, 0x18, 0x00, 0x60,
        0x60, 0x00, 0x70, 0x18, 0x00, 0x60,
        0x60, 0x00, 0x30, 0x0C, 0x00, 0x60,
        0x60, 0x00, 0x18, 0x06, 0x00, 0x60,
        0x60, 0x00, 0x0E, 0x03, 0x00, 0x60,
        0x60, 0x00, 0x07, 0x01, 0xC0, 0x60,
        0x60, 0x00, 0x03, 0xC0, 0xE0, 0x60,
        0x60, 0x00, 0x00, 0xF8, 0x7C, 0x60,
        0x60, 0x00, 0x00, 0x3F, 0xFF, 0xE0,
        0x60, 0x00, 0x00, 0x07, 0xFF, 0xE0,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    },
    {   /* NSE */
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x06, 0x00, 0x06, 0x06, 0x00, 0x00,
        0x06, 0x06, 0x06, 0x06, 0x00, 0x00,
        0x06, 0x06, 0x06, 0x66, 0x00, 0x00,
        0x06, 0x06, 0x06, 0x66, 0x60, 0x60,
        0x06, 0x06, 0x06, 0x66, 0x60, 0x60,
        0x66, 0x66, 0x06, 0x66, 0x60, 0x60,
        0x66, 0x66, 0x66, 0x66, 0x66, 0x60,
        0x66, 0x66, 0x66, 0x66, 0x66, 0x60,
        0x66, 0x66, 0x66, 0x66, 0x66, 0x60,
        0x66, 0x66, 0x66, 0x66, 0x66, 0x60,
        0x66, 0x66, 0x66, 0x66, 0x66, 0x60,
        0x66, 0x66, 0x66, 0x66, 0x66, 0x60,
        0x66, 0x66, 0x66, 0x66, 0x66, 0x60,
        0x66, 0x66, 0x66, 0x66, 0x66, 0x60,
        0x66, 0x66, 0x66, 0x66, 0x66, 0x60,
        0x66, 0x66, 0x66, 0x66, 0x66, 0x60,
        0x66, 0x66, 0x66, 0x66, 0x66, 0x60,
        0x66, 0x06, 0x66, 0x66, 0x66, 0x60,
        0x06, 0x06, 0x60, 0x66, 0x60, 0x60,
        0x06, 0x06, 0x60, 0x66, 0x60, 0x60,
        0x06, 0x06, 0x60, 0x66, 0x60, 0x60,
        0x00, 0x06, 0x00, 0x06, 0x60, 0x00,
        0x00, 0x06, 0x00, 0x06, 0x00, 0x00,
        0x00, 0x06, 0x00, 0x06, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    },
};

/* The icon is the whole 44 x 44 figure area, copied at 1:1: no offset, no brush. */
static void pv_wave(uint8_t *m, const pv_vals_t *v)
{
    enum { COUNT = 6 };

    const int which = (v->q[0] < COUNT) ? (int)v->q[0] : 0;

    pv_icon(m, PV_WAVE_ICONS[which]);
}

/* -------------------------------------------------------------------------- */
/* The second set: round figures, step figures, and the lead's own two        */
/* -------------------------------------------------------------------------- */

/*
 * DELAY. Echoes, each a 2 px upright stroke: time runs to the right, level rises
 * from the floor, and each repeat is quieter than the one before by the
 * feedback. Not bars — a bar at this size is a block, and the instrument's own
 * marks are strokes.
 *
 * The spacing is the delay time. In FREE it is the TIME knob, and the empty gap
 * between two repeats runs from 2 px at the bottom of the knob to 12 px at the
 * top in steps of 2 px. The pitch is the gap plus the 2 px stroke; the number of
 * repeats follows the pitch, because a longer delay has room for fewer echoes in
 * the same 44 px window. In a division it is the division, longest at the left
 * of the list and shortest at the right.
 *
 * There is no dry rail any more. The owner's rule is that only data stays in the
 * frame, and a line that does not move with a knob is not data. The first echo
 * itself is at the field's top, so the decay fills the height on its own.
 */
static void pv_delay(uint8_t *m, const pv_vals_t *v)
{
    enum { YB = PV_FY1, YT = PV_FY0 };

    if (v->q[0] < 1) {                      /* MIX at zero: the dry floor */
        pv_stroke(m, PV_FX0, PV_FX1, YB, YB);
        return;
    }

    int pitch;
    if (v->q[3] == 0) {                     /* FREE: the TIME knob */
        /* q[2] is 0..50; every 10 units of it is one 2 px step of the gap. */
        const int gap = 2 + 2 * ((int)v->q[2] / 10);
        pitch = gap + 2;
    } else {                                /* a division: longest first */
        pitch = 4 + (11 - (int)v->q[3]) / 2;
    }
    if (pitch < 4) {
        pitch = 4;
    }
    pitch &= ~1;

    const float fb = 0.35f + 0.60f * (float)v->q[1] * 0.02f;

    /* The echoes are spread across the whole 44 px field, first bar at the left
     * edge and last at the right one. With a fixed pitch the last bar stopped two
     * pixels short at some times; the gap is now the average the knob asks for,
     * and the right edge is always reached. */
    int taps = 1 + (PV_FX1 - PV_FX0) / pitch;
    if (taps < 2) {
        taps = 2;
    } else if (taps > 11) {
        taps = 11;
    }

    /* The first repeat stands at the mix level, not at full height: MIX is the
     * wet amount, so at 25 % the whole series is a quarter of the field high and
     * at 100 % it starts at the ceiling. Without that factor the three mix
     * positions drew the same picture, which the owner read as a dead knob. */
    const float wet = 0.15f + 0.85f * (float)v->q[0] * 0.02f;
    float hh = (float)(YB - YT) * wet;
    for (int i = 0; i < taps; i++) {
        const int x = pv_even(PV_FX0 + (i * (PV_FX1 - PV_FX0)) / (taps - 1));
        int h = pv_even(pv_round(hh));
        if (h < 2) {
            h = 2;
        }
        pv_vline(m, x, YB - h, YB, 2);
        hh *= fb;
    }
}


/*
 * REVERB DAMP. Four rings nested one inside another, at 21, 15, 9 and 3 pixels from the
 * middle. The outer one is always there; the three inside arrive from the rim inwards,
 * one per quarter of the knob, and each arrives as a half circle first — the second from
 * the top, the third from the bottom, the fourth from the top again — then closes into a
 * whole ring while the next begins its half. Two halves of one ring are never on screen
 * at once, so the figure reads as a wave dying inwards and not as a level filling up.
 *
 * The half is a sector test, not an angle: a dot is in the arc when it is on the right
 * side of both end rays, and for an arc wider than half a turn the test is run on the
 * gap that is left and inverted. That is four multiplies per dot, which is what lets the
 * figure be rebuilt on every turn of the knob.
 */
#define PV_DAMP_DEG (3.14159265f / 180.0f)

/* Квадраты радиусов в удвоенных пикселях и угол, с которого кольцо начинает дугу. */
static const int16_t PV_DAMP_EDGE[4][2] = {
    { 42, 38 }, { 30, 26 }, { 18, 14 }, { 6, 2 }
};
static const int16_t PV_DAMP_START[4] = { 0, 0, 180, 0 };

typedef struct {
    int ro2;
    int ri2;
    int kind;                   /* 0 — пусто, 1 — дуга, 2 — кольцо целиком */
    int negate;                 /* дуга шире половины: считаем зазор */
    float c0, s0, c1, s1;       /* лучи на краях */
} pv_arc_t;

static void pv_arc_build(pv_arc_t *a, const int16_t *edge, float start, float sweep)
{
    a->ro2 = (int)edge[0] * (int)edge[0];
    a->ri2 = (int)edge[1] * (int)edge[1];

    if (sweep <= 0.5f) {
        a->kind = 0;
        return;
    }
    if (sweep >= 359.5f) {
        a->kind = 2;
        return;
    }
    a->kind = 1;
    a->negate = (sweep > 180.0f);

    const float from = a->negate ? start + sweep : start;
    const float to = a->negate ? start + 360.0f : start + sweep;

    a->c0 = cosf(from * PV_DAMP_DEG);
    a->s0 = sinf(from * PV_DAMP_DEG);
    a->c1 = cosf(to * PV_DAMP_DEG);
    a->s1 = sinf(to * PV_DAMP_DEG);
}

static bool pv_arc_hit(const pv_arc_t *a, float dx, float dy, float d2)
{
    if (a->kind == 0 || d2 > (float)a->ro2 || d2 < (float)a->ri2) {
        return false;
    }
    if (a->kind == 2) {
        return true;
    }

    /* точка справа от начального луча и слева от конечного */
    const bool inside = (a->c0 * dy - a->s0 * dx >= 0.0f) &&
                        (a->c1 * dy - a->s1 * dx <= 0.0f);

    return a->negate ? !inside : inside;
}

static float pv_clamp01(float x)
{
    return (x < 0.0f) ? 0.0f : ((x > 1.0f) ? 1.0f : x);
}

static void pv_verb_damp(uint8_t *m, const pv_vals_t *v)
{
    const float u = (float)v->q[0] * (4.0f / 50.0f);
    pv_arc_t ring[4];

    pv_arc_build(&ring[0], PV_DAMP_EDGE[0], 0.0f, 360.0f);
    for (int k = 1; k < 4; k++) {
        const float sweep = 180.0f * (pv_clamp01(u - (float)(k - 1)) +
                                      pv_clamp01(u - (float)k));

        pv_arc_build(&ring[k], PV_DAMP_EDGE[k], (float)PV_DAMP_START[k], sweep);
    }

    for (int y = 0; y < 44; y++) {
        for (int x = 0; x < 44; x++) {
            const float dx = 2.0f * (float)x - 43.0f;
            const float dy = 43.0f - 2.0f * (float)y;
            const float d2 = dx * dx + dy * dy;

            for (int k = 0; k < 4; k++) {
                if (!pv_arc_hit(&ring[k], dx, dy, d2)) {
                    continue;
                }
                pv_px(m, PV_AREA_X0 + x, PV_AREA_Y0 + y);
                break;
            }
        }
    }
}



/*
 * DELAY MODE, as two icons rather than as a figure.
 *
 * There is nothing to interpolate: a tape delay and a crossfade are two behaviours, not
 * two ends of one amount, so the sector shows one picture or the other and never anything
 * between them — the mode steps, and the icon steps with it.
 *
 * Both pictures are the owner's own art, carried whole: 44 x 44 dots, the entire field.
 * They go through pv_icon, the same road the oscillator shapes take, so a dot in his
 * drawing is a dot on the dial and nothing is redrawn by hand.
 */
/* TAPE: a reel — a ring, four pins around the hub, and the hub itself. */
static const uint8_t PV_MODE_TAPE[44 * 6] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x7F, 0xE0, 0x00, 0x00,
    0x00, 0x03, 0xFF, 0xFC, 0x00, 0x00,
    0x00, 0x0F, 0xC0, 0x3F, 0x00, 0x00,
    0x00, 0x3E, 0x00, 0x07, 0xC0, 0x00,
    0x00, 0x78, 0x00, 0x01, 0xE0, 0x00,
    0x00, 0xE0, 0x0F, 0x00, 0x70, 0x00,
    0x01, 0xC0, 0x1F, 0x80, 0x38, 0x00,
    0x03, 0x80, 0x39, 0xC0, 0x1C, 0x00,
    0x07, 0x00, 0x30, 0xC0, 0x0E, 0x00,
    0x0E, 0x00, 0x30, 0xC0, 0x07, 0x00,
    0x0C, 0x00, 0x30, 0xC0, 0x03, 0x00,
    0x1C, 0x00, 0x30, 0xC0, 0x03, 0x80,
    0x18, 0x00, 0x30, 0xC0, 0x01, 0x80,
    0x38, 0x00, 0x30, 0xC0, 0x01, 0xC0,
    0x30, 0x00, 0x39, 0xC0, 0x00, 0xC0,
    0x30, 0x00, 0x1F, 0x80, 0x00, 0xC0,
    0x70, 0x00, 0x0F, 0x00, 0x00, 0xE0,
    0x60, 0xFF, 0x00, 0x0F, 0xF0, 0x60,
    0x61, 0xFF, 0x80, 0x1F, 0xF8, 0x60,
    0x63, 0x81, 0xC6, 0x38, 0x1C, 0x60,
    0x63, 0x00, 0xCF, 0x30, 0x0C, 0x60,
    0x63, 0x00, 0xCF, 0x30, 0x0C, 0x60,
    0x63, 0x81, 0xC6, 0x38, 0x1C, 0x60,
    0x61, 0xFF, 0x80, 0x1F, 0xF8, 0x60,
    0x60, 0xFF, 0x00, 0x0F, 0xF0, 0x60,
    0x70, 0x00, 0x0F, 0x00, 0x00, 0xE0,
    0x30, 0x00, 0x1F, 0x80, 0x00, 0xC0,
    0x30, 0x00, 0x39, 0xC0, 0x00, 0xC0,
    0x38, 0x00, 0x30, 0xC0, 0x01, 0xC0,
    0x18, 0x00, 0x30, 0xC0, 0x01, 0x80,
    0x1C, 0x00, 0x30, 0xC0, 0x03, 0x80,
    0x0C, 0x00, 0x30, 0xC0, 0x03, 0x00,
    0x0E, 0x00, 0x30, 0xC0, 0x07, 0x00,
    0x07, 0x00, 0x30, 0xC0, 0x0E, 0x00,
    0x03, 0x80, 0x39, 0xC0, 0x1C, 0x00,
    0x01, 0xC0, 0x1F, 0x80, 0x38, 0x00,
    0x00, 0xE0, 0x0F, 0x00, 0x70, 0x00,
    0x00, 0x78, 0x00, 0x01, 0xE0, 0x00,
    0x00, 0x3E, 0x00, 0x07, 0xC0, 0x00,
    0x00, 0x0F, 0xC0, 0x3F, 0x00, 0x00,
    0x00, 0x03, 0xFF, 0xFC, 0x00, 0x00,
    0x00, 0x00, 0x7F, 0xE0, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};

/* CROSSFADE: two bow ties head to tail, the old material crossed out. */
static const uint8_t PV_MODE_CROSS[44 * 6] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x20, 0x00, 0x00, 0x00, 0x00, 0x40,
    0x38, 0x00, 0x00, 0x00, 0x01, 0xC0,
    0x1E, 0x00, 0x00, 0x00, 0x07, 0x80,
    0x07, 0x80, 0x00, 0x00, 0x1E, 0x00,
    0x01, 0xE0, 0x00, 0x00, 0x78, 0x00,
    0x00, 0x78, 0x00, 0x01, 0xE0, 0x00,
    0x00, 0x1E, 0x00, 0x07, 0x80, 0x00,
    0x00, 0x07, 0x80, 0x1E, 0x0C, 0x00,
    0x00, 0x01, 0xE0, 0x78, 0x0C, 0x00,
    0x00, 0x00, 0x79, 0xE1, 0x8C, 0x00,
    0x00, 0x00, 0x1F, 0x81, 0x8C, 0x00,
    0x00, 0x00, 0x1F, 0x81, 0x8C, 0x00,
    0x00, 0x00, 0x79, 0xE1, 0x8C, 0x00,
    0x00, 0x01, 0xE0, 0x78, 0x0C, 0x00,
    0x00, 0x07, 0x80, 0x1E, 0x0C, 0x00,
    0x00, 0x1E, 0x06, 0x07, 0x80, 0x00,
    0x00, 0x78, 0x06, 0x01, 0xE0, 0x00,
    0x01, 0xE0, 0xC6, 0x00, 0x78, 0x00,
    0x07, 0x80, 0xC6, 0x00, 0x1E, 0x00,
    0x1E, 0x18, 0xC6, 0x00, 0x07, 0x80,
    0x78, 0x18, 0xC6, 0x00, 0x01, 0xE0,
    0x78, 0x18, 0xC6, 0x00, 0x01, 0xE0,
    0x1E, 0x18, 0xC6, 0x00, 0x07, 0x80,
    0x07, 0x80, 0xC6, 0x00, 0x1E, 0x00,
    0x01, 0xE0, 0xC6, 0x00, 0x78, 0x00,
    0x00, 0x78, 0x06, 0x01, 0xE0, 0x00,
    0x00, 0x1E, 0x06, 0x07, 0x80, 0x00,
    0x00, 0x07, 0x80, 0x1E, 0x0C, 0x00,
    0x00, 0x01, 0xE0, 0x78, 0x0C, 0x00,
    0x00, 0x00, 0x79, 0xF1, 0x8C, 0x00,
    0x00, 0x00, 0x1F, 0xB1, 0x8C, 0x00,
    0x00, 0x00, 0x1F, 0xB1, 0x8C, 0x00,
    0x00, 0x00, 0x79, 0xF1, 0x8C, 0x00,
    0x00, 0x01, 0xE0, 0x78, 0x0C, 0x00,
    0x00, 0x07, 0x80, 0x1E, 0x0C, 0x00,
    0x00, 0x1E, 0x00, 0x07, 0x80, 0x00,
    0x00, 0x78, 0x00, 0x01, 0xE0, 0x00,
    0x01, 0xE0, 0x00, 0x00, 0x78, 0x00,
    0x07, 0x80, 0x00, 0x00, 0x1E, 0x00,
    0x1E, 0x00, 0x00, 0x00, 0x07, 0x80,
    0x38, 0x00, 0x00, 0x00, 0x01, 0xC0,
    0x20, 0x00, 0x00, 0x00, 0x00, 0x40,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};



static void pv_delay_mode(uint8_t *m, const pv_vals_t *v)
{
    pv_icon(m, (v->q[0] == 0) ? PV_MODE_TAPE : PV_MODE_CROSS);
}


/*
 * REVERB ALGO, as four icons rather than as a field.
 *
 * The four rooms are a list, not an amount: a hall does not lie between a room and a
 * cathedral, it is a different room, so the sector shows one picture and steps to the
 * next. The order is the engine's own — ROOM, HALL, CATHEDRAL, PLATE — so the picture
 * can never disagree with the word beside it.
 *
 * Each icon is his drawing frame and all, placed at the field's origin: every one of the
 * four is centred in his 44 x 44 on his side, so any offset of ours would push it off
 * the middle.
 */
/* ROOM: a cube seen from one corner. */
static const uint8_t PV_ALGO_ROOM[44 * 6] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x1F, 0xFF, 0xFF, 0xFF, 0xC0,
    0x00, 0x3F, 0xFF, 0xFF, 0xFF, 0xC0,
    0x00, 0x78, 0x00, 0x00, 0x00, 0xC0,
    0x00, 0xF8, 0x00, 0x00, 0x00, 0xC0,
    0x01, 0xD8, 0x00, 0x00, 0x00, 0xC0,
    0x03, 0x98, 0x00, 0x00, 0x00, 0xC0,
    0x07, 0x18, 0x00, 0x00, 0x00, 0xC0,
    0x0E, 0x18, 0x00, 0x00, 0x00, 0xC0,
    0x1C, 0x18, 0x00, 0x00, 0x00, 0xC0,
    0x38, 0x18, 0x00, 0x00, 0x00, 0xC0,
    0x30, 0x18, 0x00, 0x00, 0x00, 0xC0,
    0x30, 0x18, 0x00, 0x00, 0x00, 0xC0,
    0x30, 0x18, 0x00, 0x00, 0x00, 0xC0,
    0x30, 0x18, 0x00, 0x00, 0x00, 0xC0,
    0x30, 0x18, 0x00, 0x00, 0x00, 0xC0,
    0x30, 0x18, 0x00, 0x00, 0x00, 0xC0,
    0x30, 0x18, 0x00, 0x00, 0x00, 0xC0,
    0x30, 0x18, 0x00, 0x00, 0x00, 0xC0,
    0x30, 0x18, 0x00, 0x00, 0x00, 0xC0,
    0x30, 0x18, 0x00, 0x00, 0x00, 0xC0,
    0x30, 0x18, 0x00, 0x00, 0x00, 0xC0,
    0x30, 0x18, 0x00, 0x00, 0x00, 0xC0,
    0x30, 0x18, 0x00, 0x00, 0x00, 0xC0,
    0x30, 0x18, 0x00, 0x00, 0x00, 0xC0,
    0x30, 0x18, 0x00, 0x00, 0x00, 0xC0,
    0x30, 0x18, 0x00, 0x00, 0x00, 0xC0,
    0x30, 0x18, 0x00, 0x00, 0x00, 0xC0,
    0x30, 0x18, 0x00, 0x00, 0x00, 0xC0,
    0x30, 0x18, 0x00, 0x00, 0x00, 0xC0,
    0x30, 0x1F, 0xFF, 0xFF, 0xFF, 0xC0,
    0x30, 0x3F, 0xFF, 0xFF, 0xFF, 0xC0,
    0x30, 0x70, 0x00, 0x00, 0x03, 0x80,
    0x30, 0xE0, 0x00, 0x00, 0x07, 0x00,
    0x31, 0xC0, 0x00, 0x00, 0x0E, 0x00,
    0x33, 0x80, 0x00, 0x00, 0x1C, 0x00,
    0x37, 0x00, 0x00, 0x00, 0x38, 0x00,
    0x3E, 0x00, 0x00, 0x00, 0x70, 0x00,
    0x3C, 0x00, 0x00, 0x00, 0xE0, 0x00,
    0x3F, 0xFF, 0xFF, 0xFF, 0xC0, 0x00,
    0x3F, 0xFF, 0xFF, 0xFF, 0x80, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};

/* HALL: the same room with its walls pushed out and its floor dropped. */
static const uint8_t PV_ALGO_HALL[44 * 6] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x7F, 0xFF, 0xFF, 0xFF, 0xFF, 0xE0,
    0x7F, 0xFF, 0xFF, 0xFF, 0xFF, 0xE0,
    0x78, 0x00, 0x00, 0x00, 0x01, 0xE0,
    0x7C, 0x00, 0x00, 0x00, 0x03, 0xE0,
    0x6E, 0x00, 0x00, 0x00, 0x07, 0x60,
    0x67, 0x00, 0x00, 0x00, 0x0E, 0x60,
    0x63, 0x80, 0x00, 0x00, 0x1C, 0x60,
    0x61, 0xC0, 0x00, 0x00, 0x38, 0x60,
    0x60, 0xE0, 0x00, 0x00, 0x70, 0x60,
    0x60, 0x70, 0x00, 0x00, 0xE0, 0x60,
    0x60, 0x3F, 0xFF, 0xFF, 0xC0, 0x60,
    0x60, 0x1F, 0xFF, 0xFF, 0x80, 0x60,
    0x60, 0x18, 0x00, 0x01, 0x80, 0x60,
    0x60, 0x18, 0x00, 0x01, 0x80, 0x60,
    0x60, 0x18, 0x00, 0x01, 0x80, 0x60,
    0x60, 0x18, 0x00, 0x01, 0x80, 0x60,
    0x60, 0x18, 0x00, 0x01, 0x80, 0x60,
    0x60, 0x18, 0x00, 0x01, 0x80, 0x60,
    0x60, 0x18, 0x00, 0x01, 0x80, 0x60,
    0x60, 0x18, 0x00, 0x01, 0x80, 0x60,
    0x60, 0x18, 0x00, 0x01, 0x80, 0x60,
    0x60, 0x18, 0x00, 0x01, 0x80, 0x60,
    0x60, 0x18, 0x00, 0x01, 0x80, 0x60,
    0x60, 0x18, 0x00, 0x01, 0x80, 0x60,
    0x60, 0x18, 0x00, 0x01, 0x80, 0x60,
    0x60, 0x18, 0x00, 0x01, 0x80, 0x60,
    0x60, 0x18, 0x00, 0x01, 0x80, 0x60,
    0x60, 0x18, 0x00, 0x01, 0x80, 0x60,
    0x60, 0x18, 0x00, 0x01, 0x80, 0x60,
    0x60, 0x18, 0x00, 0x01, 0x80, 0x60,
    0x60, 0x1F, 0xFF, 0xFF, 0x80, 0x60,
    0x60, 0x3F, 0xFF, 0xFF, 0xC0, 0x60,
    0x60, 0x70, 0x00, 0x00, 0xE0, 0x60,
    0x60, 0xE0, 0x00, 0x00, 0x70, 0x60,
    0x61, 0xC0, 0x00, 0x00, 0x38, 0x60,
    0x63, 0x80, 0x00, 0x00, 0x1C, 0x60,
    0x67, 0x00, 0x00, 0x00, 0x0E, 0x60,
    0x6E, 0x00, 0x00, 0x00, 0x07, 0x60,
    0x7C, 0x00, 0x00, 0x00, 0x03, 0xE0,
    0x78, 0x00, 0x00, 0x00, 0x01, 0xE0,
    0x7F, 0xFF, 0xFF, 0xFF, 0xFF, 0xE0,
    0x7F, 0xFF, 0xFF, 0xFF, 0xFF, 0xE0,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};

/* CATHEDRAL: an arch standing on the floor, taller than it is wide. */
static const uint8_t PV_ALGO_CATH[44 * 6] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x7F, 0xE0, 0x00, 0x00,
    0x00, 0x03, 0xFF, 0xFC, 0x00, 0x00,
    0x00, 0x0F, 0xC0, 0x3F, 0x00, 0x00,
    0x00, 0x3E, 0x00, 0x07, 0xC0, 0x00,
    0x00, 0x78, 0x00, 0x01, 0xE0, 0x00,
    0x00, 0xE0, 0x00, 0x00, 0x70, 0x00,
    0x01, 0xC0, 0x00, 0x00, 0x38, 0x00,
    0x03, 0x80, 0x00, 0x00, 0x1C, 0x00,
    0x07, 0x00, 0x00, 0x00, 0x0E, 0x00,
    0x0E, 0x00, 0x00, 0x00, 0x07, 0x00,
    0x0C, 0x00, 0x00, 0x00, 0x03, 0x00,
    0x1C, 0x00, 0x00, 0x00, 0x03, 0x80,
    0x18, 0x00, 0x00, 0x00, 0x01, 0x80,
    0x38, 0x00, 0x00, 0x00, 0x01, 0xC0,
    0x30, 0x00, 0x00, 0x00, 0x00, 0xC0,
    0x30, 0x00, 0x00, 0x00, 0x00, 0xC0,
    0x70, 0x00, 0x00, 0x00, 0x00, 0xE0,
    0x60, 0x00, 0x00, 0x00, 0x00, 0x60,
    0x60, 0x00, 0x00, 0x00, 0x00, 0x60,
    0x60, 0x00, 0x00, 0x00, 0x00, 0x60,
    0x60, 0x00, 0x1F, 0x80, 0x00, 0x60,
    0x60, 0x00, 0xFF, 0xF0, 0x00, 0x60,
    0x60, 0x01, 0xE0, 0x78, 0x00, 0x60,
    0x60, 0x03, 0x80, 0x1C, 0x00, 0x60,
    0x60, 0x07, 0x00, 0x0E, 0x00, 0x60,
    0x60, 0x0E, 0x00, 0x07, 0x00, 0x60,
    0x60, 0x0C, 0x00, 0x03, 0x00, 0x60,
    0x60, 0x0C, 0x00, 0x03, 0x00, 0x60,
    0x60, 0x18, 0x00, 0x01, 0x80, 0x60,
    0x60, 0x18, 0x00, 0x01, 0x80, 0x60,
    0x60, 0x18, 0x00, 0x01, 0x80, 0x60,
    0x60, 0x18, 0x00, 0x01, 0x80, 0x60,
    0x60, 0x18, 0x00, 0x01, 0x80, 0x60,
    0x60, 0x18, 0x00, 0x01, 0x80, 0x60,
    0x60, 0x18, 0x00, 0x01, 0x80, 0x60,
    0x60, 0x18, 0x00, 0x01, 0x80, 0x60,
    0x60, 0x18, 0x00, 0x01, 0x80, 0x60,
    0x60, 0x18, 0x00, 0x01, 0x80, 0x60,
    0x60, 0x18, 0x00, 0x01, 0x80, 0x60,
    0x60, 0x18, 0x00, 0x01, 0x80, 0x60,
    0x7F, 0xFF, 0xFF, 0xFF, 0xFF, 0xE0,
    0x7F, 0xFF, 0xFF, 0xFF, 0xFF, 0xE0,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};

/* PLATE: two sheets, one behind the other, and the sound between them. */
static const uint8_t PV_ALGO_PLAT[44 * 6] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x07, 0xFF, 0xFF, 0xC0,
    0x00, 0x00, 0x0F, 0xFF, 0xFF, 0xE0,
    0x00, 0x00, 0x1C, 0x00, 0x01, 0xC0,
    0x00, 0x00, 0x38, 0x00, 0x03, 0x80,
    0x00, 0x00, 0x70, 0x00, 0x07, 0x00,
    0x00, 0x00, 0xE0, 0x00, 0x0E, 0x00,
    0x00, 0x01, 0xC0, 0x00, 0x1C, 0x00,
    0x00, 0x03, 0x80, 0x00, 0x38, 0x00,
    0x00, 0x07, 0x00, 0x00, 0x70, 0x00,
    0x00, 0x0E, 0x00, 0x00, 0xE0, 0x00,
    0x00, 0x1C, 0x00, 0x01, 0xFF, 0xC0,
    0x00, 0x38, 0x00, 0x03, 0xFF, 0xE0,
    0x00, 0x70, 0x00, 0x07, 0x01, 0xC0,
    0x00, 0xE0, 0x00, 0x0E, 0x03, 0x80,
    0x01, 0xC0, 0x00, 0x1C, 0x07, 0x00,
    0x03, 0x80, 0x00, 0x38, 0x0E, 0x00,
    0x07, 0x00, 0x00, 0x70, 0x1C, 0x00,
    0x0E, 0x00, 0x00, 0xE0, 0x38, 0x00,
    0x1C, 0x00, 0x01, 0xC0, 0x70, 0x00,
    0x38, 0x00, 0x03, 0x80, 0xE0, 0x00,
    0x7F, 0xFF, 0xFF, 0x01, 0xC0, 0x00,
    0x3F, 0xFF, 0xFE, 0x03, 0x80, 0x00,
    0x00, 0x70, 0x00, 0x07, 0x00, 0x00,
    0x00, 0xE0, 0x00, 0x0E, 0x00, 0x00,
    0x01, 0xC0, 0x00, 0x1C, 0x00, 0x00,
    0x03, 0x80, 0x00, 0x38, 0x00, 0x00,
    0x07, 0x00, 0x00, 0x70, 0x00, 0x00,
    0x0E, 0x00, 0x00, 0xE0, 0x00, 0x00,
    0x1C, 0x00, 0x01, 0xC0, 0x00, 0x00,
    0x38, 0x00, 0x03, 0x80, 0x00, 0x00,
    0x7F, 0xFF, 0xFF, 0x00, 0x00, 0x00,
    0x3F, 0xFF, 0xFE, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};

static void pv_verb_mode(uint8_t *m, const pv_vals_t *v)
{
    static const uint8_t *const ICONS[] = {
        PV_ALGO_ROOM, PV_ALGO_HALL, PV_ALGO_CATH, PV_ALGO_PLAT
    };
    const int mode = (int)v->q[0];

    pv_icon(m, ICONS[(mode < 0 || mode > 3) ? 0 : mode]);
}


/*
 * DELAY SYNC. The division list as a grid of twelve beats: every beat is a 2 px
 * upright with a 2 px gap, and the chosen division is the one that stands taller.
 * FREE is the only position with no tall beat, because it is not on the grid.
 */
static void pv_delay_sync(uint8_t *m, const pv_vals_t *v)
{
    /* SYNC is the same comb with the division doing the spacing; pv_values has
     * already filled q[3] with the division index, so it is the same drawing. */
    pv_delay(m, v);
}


/*
 * CHORUS. Two copies of one wave, a little apart in period: the detune is the
 * whole of what the effect does. RATE is the period both copies are built on, so
 * it changes the number of cycles; DEPTH opens the distance between them, and the
 * copy under the hand is solid while the other is the same 2 px in dots.
 */
static void pv_chorus(uint8_t *m, const pv_vals_t *v)
{
    enum { X0 = PV_FX0, X1 = PV_FX1, N = (PV_FX1 - PV_FX0) / 2 + 1 };
    const float rate = (float)v->q[0] * 0.02f;
    const float depth = (float)v->q[1] * 0.02f;
    const float cycles = 0.5f + 3.5f * rate;
    const int amp = 2 + pv_round(11.0f * depth);
    const int spread = 1 + pv_round(5.0f * depth);
    const float inv_x = 1.0f / (float)(X1 - X0);

    /* DEPTH is the swing and the distance between the copies, and it multiplies
     * both: the old figure only moved the second copy and normalised the pair to
     * the field, so a deeper setting looked the same height. RATE is the number of
     * periods, not the step: the field is the same 44 px and only the density
     * changes. There is no normalisation pass, because that is what cancelled the
     * depth in the first place. */
    int y[2][N];
    for (int c = 0; c < 2; c++) {
        const float per = cycles + (c ? (0.15f + 0.45f * depth) : 0.0f);
        const int off = c ? spread : -spread;
        for (int i = 0; i < N; i++) {
            const int x = X0 + 2 * i;
            const float u = (float)(x - X0) * inv_x;
            float ph = u * per;
            ph -= (float)(int)ph;
            int yy = 27 + off - pv_round(pv_tab(PV_SIN, ph * 16.0f) * 0.01f * (float)amp);
            if (yy < PV_FY0) {
                yy = PV_FY0;
            } else if (yy > PV_FY1) {
                yy = PV_FY1;
            }
            y[c][i] = yy;
        }
    }

    /* The active copy first, solid; the other one in dots, and a dot that would
     * touch the solid copy is dropped, so two waves can cross at a shallow angle
     * without the crossing measuring four pixels. */
    const int act = (int)v->active ? 1 : 0;
    for (int pass = 0; pass < 2; pass++) {
        const int c = (pass == 0) ? act : 1 - act;
        for (int i = 0; i + 1 < N; i++) {
            const int xa = X0 + 2 * i;
            const int xb = xa + 2;
            const int ya = pv_even(y[c][i]);
            const int yb = pv_even(y[c][i + 1]);
            if (pass == 0) {
                pv_stroke(m, xa, ya, xb, yb);
            } else if ((i & 1) == 0) {
                const int xm = xa;
                const int ym = ya;
                if (pv_clear(m, xm, ym)) {
                    pv_stamp(m, xm, ym, 2);
                }
            }
        }
    }
}

static void pv_lead_filter(uint8_t *m, const pv_vals_t *v)
{
    pv_filter(m, v);
}

/*
 * SHAPE, the split of the lead filter's AR, in the drawing the owner gave.
 *
 * The field is 44 x 44 and the figure fills its width; the 56 is the mask with its six
 * pixels of margin. The floor is two pixels across the bottom of the field, the feet
 * stand one pixel inside its edges, the peak is a two-pixel block that travels from one
 * foot to the other in twenty steps of two pixels, and a square of four by four walls one
 * pixel thick rides above it, its left edge two pixels left of the peak's.
 *
 * The branches meet under the marker with two pixels of air. A steep branch is walked two
 * pixels at a time, a shallow one and a forty-five degree one a pixel at a time. At either
 * end of the knob the far branch is exactly forty-five degrees — its top stands a whole
 * rise away from its foot — and the near one becomes a wall on the peak.
 */
static void pv_lead_fenv_shape(uint8_t *m, const pv_vals_t *v)
{
    const int floor_y = 46;
    const int top_y = 11;
    const int rise = floor_y - top_y;
    const int foot_l = 8;
    const int foot_r = 46;
    const int k = (20 * (int)v->q[0] + 24) / 50;
    const int peak = 7 + 2 * k;
    const int top_l = peak - 2 < foot_l + rise ? peak - 2 : foot_l + rise;
    const int top_r = peak + 2 > foot_r - rise ? peak + 2 : foot_r - rise;
    const int wide_l = top_l > foot_l ? top_l - foot_l : foot_l - top_l;
    const int wide_r = top_r > foot_r ? top_r - foot_r : foot_r - top_r;

    pv_stroke_px(m, 6, floor_y, 48, floor_y, 2);

    if (peak > 7) {
        pv_stroke_px(m, top_l, top_y, foot_l, floor_y, rise > 2 * wide_l ? 2 : 1);
    } else {
        pv_stroke_px(m, peak, top_y, peak, floor_y, 2);
    }
    if (peak < 47) {
        pv_stroke_px(m, top_r, top_y, foot_r, floor_y, rise > 2 * wide_r ? 2 : 1);
    } else {
        pv_stroke_px(m, peak, top_y, peak, floor_y, 2);
    }

    const int mx = peak - 1;
    for (int i = 0; i < 4; i++) {
        pv_px(m, mx + i, 6);
        pv_px(m, mx + i, 9);
        pv_px(m, mx, 6 + i);
        pv_px(m, mx + 3, 6 + i);
    }
}

/*
 * VOICE, MONO or POLY: the owner's two drawings, carried whole.
 *
 * They are the notes themselves, not a computed figure: four bands of eight rows, each band
 * a run of ink in the 44 x 44 field, MONO broken into separate blocks and POLY joined into
 * long ones. Nothing is drawn from numbers here — both bitmaps are converted from his
 * pictures one bit per pixel, and the mask shows exactly what he drew.
 */
static const uint8_t PV_VOICE_ICONS[2][44 * 6] = {
    {   /* MONO */
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x7F, 0x80,
        0x00, 0x00, 0x00, 0x00, 0x7F, 0x80,
        0x00, 0x00, 0x00, 0x00, 0x7F, 0x80,
        0x00, 0x00, 0x00, 0x00, 0x7F, 0x80,
        0x00, 0x00, 0x00, 0x00, 0x7F, 0x80,
        0x00, 0x00, 0x00, 0x00, 0x7F, 0x80,
        0x00, 0x00, 0x00, 0x00, 0x7F, 0x80,
        0x00, 0x00, 0x00, 0x00, 0x7F, 0x80,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x07, 0xF8, 0x00, 0x00, 0x10,
        0x00, 0x07, 0xF8, 0x00, 0x00, 0x10,
        0x00, 0x07, 0xF8, 0x00, 0x00, 0x10,
        0x00, 0x07, 0xF8, 0x00, 0x00, 0x10,
        0x00, 0x07, 0xF8, 0x00, 0x00, 0x10,
        0x00, 0x07, 0xF8, 0x00, 0x00, 0x10,
        0x00, 0x07, 0xF8, 0x00, 0x00, 0x10,
        0x00, 0x07, 0xF8, 0x00, 0x00, 0x10,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x1F, 0xE0, 0x01, 0xFE, 0x00, 0x00,
        0x1F, 0xE0, 0x01, 0xFE, 0x00, 0x00,
        0x1F, 0xE0, 0x01, 0xFE, 0x00, 0x00,
        0x1F, 0xE0, 0x01, 0xFE, 0x00, 0x00,
        0x1F, 0xE0, 0x01, 0xFE, 0x00, 0x00,
        0x1F, 0xE0, 0x01, 0xFE, 0x00, 0x00,
        0x1F, 0xE0, 0x01, 0xFE, 0x00, 0x00,
        0x1F, 0xE0, 0x01, 0xFE, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x80, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x80, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x80, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x80, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x80, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x80, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x80, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x80, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    },
    {   /* POLY */
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x7F, 0xF0,
        0x00, 0x00, 0x00, 0x00, 0x7F, 0xF0,
        0x00, 0x00, 0x00, 0x00, 0x7F, 0xF0,
        0x00, 0x00, 0x00, 0x00, 0x7F, 0xF0,
        0x00, 0x00, 0x00, 0x00, 0x7F, 0xF0,
        0x00, 0x00, 0x00, 0x00, 0x7F, 0xF0,
        0x00, 0x00, 0x00, 0x00, 0x7F, 0xF0,
        0x00, 0x00, 0x00, 0x00, 0x7F, 0xF0,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x07, 0xFF, 0xFF, 0xFC, 0x10,
        0x00, 0x07, 0xFF, 0xFF, 0xFC, 0x10,
        0x00, 0x07, 0xFF, 0xFF, 0xFC, 0x10,
        0x00, 0x07, 0xFF, 0xFF, 0xFC, 0x10,
        0x00, 0x07, 0xFF, 0xFF, 0xFC, 0x10,
        0x00, 0x07, 0xFF, 0xFF, 0xFC, 0x10,
        0x00, 0x07, 0xFF, 0xFF, 0xFC, 0x10,
        0x00, 0x07, 0xFF, 0xFF, 0xFC, 0x10,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x1F, 0xFF, 0xFF, 0xFE, 0x00, 0x00,
        0x1F, 0xFF, 0xFF, 0xFE, 0x00, 0x00,
        0x1F, 0xFF, 0xFF, 0xFE, 0x00, 0x00,
        0x1F, 0xFF, 0xFF, 0xFE, 0x00, 0x00,
        0x1F, 0xFF, 0xFF, 0xFE, 0x00, 0x00,
        0x1F, 0xFF, 0xFF, 0xFE, 0x00, 0x00,
        0x1F, 0xFF, 0xFF, 0xFE, 0x00, 0x00,
        0x1F, 0xFF, 0xFF, 0xFE, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0xFF, 0xE0, 0x00, 0x00, 0x00, 0x00,
        0xFF, 0xE0, 0x00, 0x00, 0x00, 0x00,
        0xFF, 0xE0, 0x00, 0x00, 0x00, 0x00,
        0xFF, 0xE0, 0x00, 0x00, 0x00, 0x00,
        0xFF, 0xE0, 0x00, 0x00, 0x00, 0x00,
        0xFF, 0xE0, 0x00, 0x00, 0x00, 0x00,
        0xFF, 0xE0, 0x00, 0x00, 0x00, 0x00,
        0xFF, 0xE0, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    },
};

static void pv_lead_voice(uint8_t *m, const pv_vals_t *v)
{
    pv_icon(m, PV_VOICE_ICONS[v->q[0] < 25 ? 0 : 1]);
}

/*
 * ENV, the depth of the lead filter's envelope, in the drawing the owner gave.
 *
 * The wire is the corner the filter is tuned to, and it runs down the middle of the field
 * on columns 21 and 22. Under the middle of the knob it is straight from edge to edge with
 * a tick across it: no travel, and the envelope moves nothing. Turned either way it bends
 * towards the edge the knob is heading for — top and bottom both — and what is left in the
 * middle is a vertical run. At either end the top and the bottom lie flat, two rows of ink
 * against the field's edge, because the corner has reached the stop.
 *
 * The numbers are read off the seven frames. At a third of the travel the top leaves the
 * edge six pixels off centre and turns down at row sixteen; at two thirds it leaves twelve
 * off and turns at twelve; at the end it leaves twenty-one off — the field's whole width —
 * and turns at two, which is the flat top. Between those frames the bend is straight
 * interpolation, so the wire leans steadily as the knob turns.
 *
 * The arm is a band of constant width ACROSS its own direction: a strip two pixels wide laid
 * along the segment, filled row by row from the exact crossing of that strip with the row.
 * Walking a two-pixel brush down the arm instead was tried and rejected — where the arm is
 * flat the brush steps sideways and the row runs grow into a staircase, which is what the
 * owner saw on the panel and called thin. A strip has the same thickness at every angle:
 * two pixels of a row on a steep arm, three at forty-five degrees.
 *
 * The band is cut at the wire's right column, so no row of the arm can run past the wire.
 *
 * The right half is the left half mirrored about the axis between columns 21 and 22, which
 * is exactly how the owner's own frames relate: a block mirrors to 42 minus its column, a
 * pixel to 43 minus its. This figure is symmetric top to bottom as well, so mirroring both
 * axes is the same as mirroring one.
 *
 * The arrow says which way the corner is going: a shaft along the middle of the field out
 * to the tip and a head that grows with it. At the middle of the knob it is a bare tick six
 * pixels wide across the wire — there is no direction to show.
 */
#define PV_ENV_WIRE 21      /* the wire's left column, in the 44 x 44 field */
#define PV_ENV_LAST 43      /* the field's last column and last row */

/* One of the four anchors, interpolated over the knob's travel d (0..25), with the owner's
 * frames at d = 0, 8, 16 and 25. */
static int pv_env_stop(int d, int a, int b, int c, int e)
{
    if (d <= 8) {
        return a + ((b - a) * d + 4) / 8;
    }
    if (d <= 16) {
        return b + ((c - b) * (d - 8) + 4) / 8;
    }
    return c + ((e - c) * (d - 16) + 4) / 9;
}

/* Division and rounding that do not depend on the compiler's idea of a negative quotient:
 * the band arithmetic runs in sixty-fourths and both signs come up. */
static int pv_env_div(int a, int b)
{
    const int neg = (a < 0) != (b < 0);
    const int ua = a < 0 ? -a : a;
    const int ub = b < 0 ? -b : b;
    const int q = ub > 0 ? (ua + ub / 2) / ub : 0;
    return neg ? -q : q;
}

static int pv_env_floor(int a, int b)
{
    const int neg = (a < 0) != (b < 0);
    const int ua = a < 0 ? -a : a;
    const int ub = b < 0 ? -b : b;
    const int q = ub > 0 ? ua / ub : 0;
    return neg ? -q - (ua % (ub > 0 ? ub : 1) != 0) : q;
}

static int pv_env_ceil(int a, int b)
{
    return -pv_env_floor(-a, b);
}

/* A pixel of the figure, given in field coordinates 0..43. Nothing may land right of the
 * wire's right column, so the arm cannot run past it. */
static void pv_env_px(uint8_t *m, int fx, int fy, int flip)
{
    if (fx > PV_ENV_WIRE + 1) {
        return;
    }
    const int x = flip ? PV_ENV_LAST - fx : fx;
    const int y = flip ? PV_ENV_LAST - fy : fy;
    if (x < 0 || x > PV_ENV_LAST || y < 0 || y > PV_ENV_LAST) {
        return;
    }
    pv_px(m, PV_AREA_X0 + x, PV_AREA_Y0 + y);
}

/* The arm: a strip two pixels wide along the segment, filled row by row. Each row takes the
 * span between where the strip's edges cross it, so the thickness never depends on the
 * angle. The geometry runs in sixty-fourths of a pixel, which is what keeps the crossing
 * exact on a shallow arm. */
static void pv_env_band(uint8_t *m, int x0, int y0, int x1, int y1, int flip)
{
    const int dx = x1 - x0;
    const int dy = y1 - y0;
    int len = (int)(sqrtf((float)(dx * dx + dy * dy)) + 0.5f);
    if (len < 1) {
        len = 1;
    }
    const int nx = pv_env_div(-dy * 64, len);
    const int ny = pv_env_div(dx * 64, len);
    const int ax = x0 * 64, ay = y0 * 64;
    const int bx = x1 * 64, by = y1 * 64;
    const int px[4] = { ax + nx, bx + nx, bx - nx, ax - nx };
    const int py[4] = { ay + ny, by + ny, by - ny, ay - ny };

    int lo = py[0], hi = py[0];
    for (int i = 1; i < 4; i++) {
        if (py[i] < lo) {
            lo = py[i];
        }
        if (py[i] > hi) {
            hi = py[i];
        }
    }

    for (int y = pv_env_floor(lo, 64) - 1; y <= pv_env_floor(hi, 64) + 1; y++) {
        const int c = y * 64 + 32;
        int xs[4];
        int n = 0;
        for (int i = 0; i < 4; i++) {
            const int j = (i + 1) & 3;
            if ((py[i] <= c && c < py[j]) || (py[j] <= c && c < py[i])) {
                xs[n++] = px[i] + pv_env_div((px[j] - px[i]) * (c - py[i]), py[j] - py[i]);
            }
        }
        if (n < 2) {
            continue;
        }
        int xa = xs[0], xb = xs[0];
        for (int i = 1; i < n; i++) {
            if (xs[i] < xa) {
                xa = xs[i];
            }
            if (xs[i] > xb) {
                xb = xs[i];
            }
        }
        for (int x = pv_env_ceil(xa - 32, 64); x <= pv_env_floor(xb - 32, 64); x++) {
            pv_env_px(m, x, y, flip);
        }
    }
}


/*
 * GATE AND PORTA, drawn from the owner's own frames the way he drew them. The picture is
 * written down row by row of the 44 x 44 field: each row holds at most two runs, and every
 * run is written twice — as it sits in his first frame and as it sits in his last — and the
 * knob slides each run from the one to the other in a straight line. Nothing here is
 * re-derived from a curve, so both ends are his art down to the pixel, and the frames
 * between them follow from the two he gave.
 *
 * A run is {first column, last column}; PV_ROWS_NONE marks the free half of a row.
 * The travel is the knob's own 0..50, the same quantisation as every other figure.
 */
#define PV_ROWS_NONE 255

typedef struct {
    uint8_t s0, e0;   /* the first frame: first and last column of the run */
    uint8_t s1, e1;   /* the last frame */
} pv_row_run;

/* GATE: the two posts and the bar at the foot; the right post leaves as the gate opens. */
static const pv_row_run s_gate[44][2] = {
    { {PV_ROWS_NONE, 0, 0, 0}, {PV_ROWS_NONE, 0, 0, 0} },  /*  0 */
    { { 2,  5,  2, 40}, {PV_ROWS_NONE, 0, 0, 0} },  /*  1 */
    { { 1,  6,  1, 41}, {PV_ROWS_NONE, 0, 0, 0} },  /*  2 */
    { { 1,  2,  1,  2}, { 5,  6, 40, 41} },  /*  3 */
    { { 1,  2,  1,  2}, { 5,  6, 40, 41} },  /*  4 */
    { { 1,  2,  1,  2}, { 5,  6, 40, 41} },  /*  5 */
    { { 1,  2,  1,  2}, { 5,  6, 40, 41} },  /*  6 */
    { { 1,  2,  1,  2}, { 5,  6, 40, 41} },  /*  7 */
    { { 1,  2,  1,  2}, { 5,  6, 40, 41} },  /*  8 */
    { { 1,  2,  1,  2}, { 5,  6, 40, 41} },  /*  9 */
    { { 1,  2,  1,  2}, { 5,  6, 40, 41} },  /* 10 */
    { { 1,  2,  1,  2}, { 5,  6, 40, 41} },  /* 11 */
    { { 1,  2,  1,  2}, { 5,  6, 40, 41} },  /* 12 */
    { { 1,  2,  1,  2}, { 5,  6, 40, 41} },  /* 13 */
    { { 1,  2,  1,  2}, { 5,  6, 40, 41} },  /* 14 */
    { { 1,  2,  1,  2}, { 5,  6, 40, 41} },  /* 15 */
    { { 1,  2,  1,  2}, { 5,  6, 40, 41} },  /* 16 */
    { { 1,  2,  1,  2}, { 5,  6, 40, 41} },  /* 17 */
    { { 1,  2,  1,  2}, { 5,  6, 40, 41} },  /* 18 */
    { { 1,  2,  1,  2}, { 5,  6, 40, 41} },  /* 19 */
    { { 1,  2,  1,  2}, { 5,  6, 40, 41} },  /* 20 */
    { { 1,  2,  1,  2}, { 5,  6, 40, 41} },  /* 21 */
    { { 1,  2,  1,  2}, { 5,  6, 40, 41} },  /* 22 */
    { { 1,  2,  1,  2}, { 5,  6, 40, 41} },  /* 23 */
    { { 1,  2,  1,  2}, { 5,  6, 40, 41} },  /* 24 */
    { { 1,  2,  1,  2}, { 5,  6, 40, 41} },  /* 25 */
    { { 1,  2,  1,  2}, { 5,  6, 40, 41} },  /* 26 */
    { { 1,  2,  1,  2}, { 5,  6, 40, 41} },  /* 27 */
    { { 1,  2,  1,  2}, { 5,  6, 40, 41} },  /* 28 */
    { { 1,  2,  1,  2}, { 5,  6, 40, 41} },  /* 29 */
    { { 1,  2,  1,  2}, { 5,  6, 40, 41} },  /* 30 */
    { { 1,  2,  1,  2}, { 5,  6, 40, 41} },  /* 31 */
    { { 1,  2,  1,  2}, { 5,  6, 40, 41} },  /* 32 */
    { { 1,  2,  1,  2}, { 5,  6, 40, 41} },  /* 33 */
    { { 1,  2,  1,  2}, { 5,  6, 40, 41} },  /* 34 */
    { { 1,  2,  1,  2}, { 5,  6, 40, 41} },  /* 35 */
    { { 1,  2,  1,  2}, { 5,  6, 40, 41} },  /* 36 */
    { { 1,  2,  1,  2}, { 5,  6, 40, 41} },  /* 37 */
    { { 1,  2,  1,  2}, { 5,  6, 40, 41} },  /* 38 */
    { { 1,  2,  1,  2}, { 5,  6, 40, 41} },  /* 39 */
    { { 1,  2,  1,  2}, { 5, 43, 40, 43} },  /* 40 */
    { { 1,  2,  1,  2}, { 6, 43, 41, 43} },  /* 41 */
    { {PV_ROWS_NONE, 0, 0, 0}, {PV_ROWS_NONE, 0, 0, 0} },  /* 42 */
    { {PV_ROWS_NONE, 0, 0, 0}, {PV_ROWS_NONE, 0, 0, 0} },  /* 43 */
};

/* PORTA: the two brackets; the corners between the posts and the bars round off. */
static const pv_row_run s_porta[44][2] = {
    { {PV_ROWS_NONE, 0, 0, 0}, {PV_ROWS_NONE, 0, 0, 0} },  /*  0 */
    { {19, 43, 26, 43}, {PV_ROWS_NONE, 0, 0, 0} },  /*  1 */
    { {18, 43, 24, 43}, {PV_ROWS_NONE, 0, 0, 0} },  /*  2 */
    { {18, 19, 22, 25}, {PV_ROWS_NONE, 0, 0, 0} },  /*  3 */
    { {18, 19, 21, 23}, {PV_ROWS_NONE, 0, 0, 0} },  /*  4 */
    { {18, 19, 20, 22}, {PV_ROWS_NONE, 0, 0, 0} },  /*  5 */
    { {18, 19, 20, 21}, {PV_ROWS_NONE, 0, 0, 0} },  /*  6 */
    { {18, 19, 19, 20}, {PV_ROWS_NONE, 0, 0, 0} },  /*  7 */
    { {18, 19, 19, 20}, {PV_ROWS_NONE, 0, 0, 0} },  /*  8 */
    { {18, 19, 18, 19}, {PV_ROWS_NONE, 0, 0, 0} },  /*  9 */
    { {18, 19, 18, 19}, {PV_ROWS_NONE, 0, 0, 0} },  /* 10 */
    { {18, 19, 18, 19}, {PV_ROWS_NONE, 0, 0, 0} },  /* 11 */
    { {18, 19, 18, 19}, {PV_ROWS_NONE, 0, 0, 0} },  /* 12 */
    { {18, 19, 18, 19}, {PV_ROWS_NONE, 0, 0, 0} },  /* 13 */
    { {18, 19, 18, 19}, {PV_ROWS_NONE, 0, 0, 0} },  /* 14 */
    { {18, 19, 17, 18}, {PV_ROWS_NONE, 0, 0, 0} },  /* 15 */
    { {18, 19, 17, 18}, {PV_ROWS_NONE, 0, 0, 0} },  /* 16 */
    { {18, 19, 16, 17}, {PV_ROWS_NONE, 0, 0, 0} },  /* 17 */
    { {18, 19, 15, 17}, {PV_ROWS_NONE, 0, 0, 0} },  /* 18 */
    { {18, 19, 14, 16}, {PV_ROWS_NONE, 0, 0, 0} },  /* 19 */
    { {18, 19, 12, 15}, {PV_ROWS_NONE, 0, 0, 0} },  /* 20 */
    { { 0, 19,  0, 13}, {25, 43, 32, 43} },  /* 21 */
    { { 0, 18,  0, 11}, {24, 43, 30, 43} },  /* 22 */
    { {24, 25, 28, 31}, {PV_ROWS_NONE, 0, 0, 0} },  /* 23 */
    { {24, 25, 27, 29}, {PV_ROWS_NONE, 0, 0, 0} },  /* 24 */
    { {24, 25, 26, 28}, {PV_ROWS_NONE, 0, 0, 0} },  /* 25 */
    { {24, 25, 26, 27}, {PV_ROWS_NONE, 0, 0, 0} },  /* 26 */
    { {24, 25, 25, 26}, {PV_ROWS_NONE, 0, 0, 0} },  /* 27 */
    { {24, 25, 25, 26}, {PV_ROWS_NONE, 0, 0, 0} },  /* 28 */
    { {24, 25, 24, 25}, {PV_ROWS_NONE, 0, 0, 0} },  /* 29 */
    { {24, 25, 24, 25}, {PV_ROWS_NONE, 0, 0, 0} },  /* 30 */
    { {24, 25, 24, 25}, {PV_ROWS_NONE, 0, 0, 0} },  /* 31 */
    { {24, 25, 24, 25}, {PV_ROWS_NONE, 0, 0, 0} },  /* 32 */
    { {24, 25, 24, 25}, {PV_ROWS_NONE, 0, 0, 0} },  /* 33 */
    { {24, 25, 24, 25}, {PV_ROWS_NONE, 0, 0, 0} },  /* 34 */
    { {24, 25, 23, 24}, {PV_ROWS_NONE, 0, 0, 0} },  /* 35 */
    { {24, 25, 23, 24}, {PV_ROWS_NONE, 0, 0, 0} },  /* 36 */
    { {24, 25, 22, 23}, {PV_ROWS_NONE, 0, 0, 0} },  /* 37 */
    { {24, 25, 21, 23}, {PV_ROWS_NONE, 0, 0, 0} },  /* 38 */
    { {24, 25, 20, 22}, {PV_ROWS_NONE, 0, 0, 0} },  /* 39 */
    { {24, 25, 18, 21}, {PV_ROWS_NONE, 0, 0, 0} },  /* 40 */
    { { 0, 25,  0, 19}, {PV_ROWS_NONE, 0, 0, 0} },  /* 41 */
    { { 0, 24,  0, 17}, {PV_ROWS_NONE, 0, 0, 0} },  /* 42 */
    { {PV_ROWS_NONE, 0, 0, 0}, {PV_ROWS_NONE, 0, 0, 0} },  /* 43 */
};

/* Slide every run of the row table by the knob and lay the rows into the field. */
static void pv_lead_rows(uint8_t *m, const pv_row_run rows[44][2], int q)
{
    for (int y = 0; y < 44; y++) {
        for (int i = 0; i < 2; i++) {
            const pv_row_run *r = &rows[y][i];
            if (r->s0 == PV_ROWS_NONE) {
                continue;
            }
            int s = r->s0 + pv_env_div((int)(r->s1 - r->s0) * q, 50);
            int e = r->e0 + pv_env_div((int)(r->e1 - r->e0) * q, 50);
            if (e - s < 1) {
                e = s + 1;
            }
            if (s < 0) {
                s = 0;
            }
            if (e > PV_ENV_LAST) {
                e = PV_ENV_LAST;
            }
            for (int x = s; x <= e; x++) {
                pv_px(m, PV_AREA_X0 + x, PV_AREA_Y0 + y);
            }
        }
    }
}

static void pv_lead_gate(uint8_t *m, const pv_vals_t *v)
{
    pv_lead_rows(m, s_gate, (int)v->q[0]);
}

static void pv_lead_porta(uint8_t *m, const pv_vals_t *v)
{
    pv_lead_rows(m, s_porta, (int)v->q[0]);
}

static void pv_lead_env(uint8_t *m, const pv_vals_t *v)
{
    const int q = (int)v->q[0];                      /* 0..50, 25 is the middle */
    const int d = q >= 25 ? q - 25 : 25 - q;         /* distance to the middle */
    const int flip = q > 25;
    const int dx = pv_env_stop(d, 0, 6, 12, 21);     /* how far the top leaves the wire */
    const int bend = pv_env_stop(d, 0, 16, 12, 2);   /* the row it turns down at */
    const int top = pv_env_stop(d, 0, 0, 0, 1);      /* the row it starts on */
    const int reach = pv_env_stop(d, 2, 8, 10, 20);  /* the arrow's length */
    const int mid_a = 21;
    const int mid_b = mid_a + 1;

    if (dx == 0) {
        /* Середина ручки: провод во всё поле и засечка поперёк него. */
        for (int y = 0; y <= PV_ENV_LAST; y++) {
            pv_env_px(m, PV_ENV_WIRE, y, flip);
            pv_env_px(m, PV_ENV_WIRE + 1, y, flip);
        }
        for (int x = PV_ENV_WIRE - 2; x <= PV_ENV_WIRE + 3; x++) {
            pv_px(m, PV_AREA_X0 + (flip ? PV_ENV_LAST - x : x), PV_AREA_Y0 + mid_a);
            pv_px(m, PV_AREA_X0 + (flip ? PV_ENV_LAST - x : x), PV_AREA_Y0 + mid_b);
        }
        return;
    }

    if (bend - top <= 2) {
        /* На упоре верх и низ лежат: полка во всю ширину поля в две строки. */
        for (int x = PV_ENV_WIRE - dx; x <= PV_ENV_WIRE; x++) {
            pv_env_px(m, x, top, flip);
            pv_env_px(m, x, top + 1, flip);
            pv_env_px(m, x, PV_ENV_LAST - top, flip);
            pv_env_px(m, x, PV_ENV_LAST - top - 1, flip);
        }
        for (int y = top + 2; y <= PV_ENV_LAST - top - 2; y++) {
            pv_env_px(m, PV_ENV_WIRE, y, flip);
            pv_env_px(m, PV_ENV_WIRE + 1, y, flip);
        }
    } else {
        pv_env_band(m, PV_ENV_WIRE - dx + 1, top - 1, PV_ENV_WIRE + 1, bend, flip);
        pv_env_band(m, PV_ENV_WIRE - dx + 1, PV_ENV_LAST - top + 1,
                    PV_ENV_WIRE + 1, PV_ENV_LAST - bend, flip);
        for (int y = bend; y <= PV_ENV_LAST - bend; y++) {
            pv_env_px(m, PV_ENV_WIRE, y, flip);
            pv_env_px(m, PV_ENV_WIRE + 1, y, flip);
        }
    }

    /* Стрелка: древко от вершины до правого столбца провода, головка растёт вместе с ним,
     * чтобы на короткой стрелке она не превращалась в кляксу. */
    for (int k = 0; k <= reach + 1; k++) {
        pv_env_px(m, PV_ENV_WIRE + 1 - k, mid_a, flip);
        pv_env_px(m, PV_ENV_WIRE + 1 - k, mid_b, flip);
    }
    const int blade = reach >= 8 ? 4 : (reach + 2) / 2 > 2 ? (reach + 2) / 2 : 2;
    const int tip = PV_ENV_WIRE - reach;
    for (int i = 1; i <= blade; i++) {
        for (int a = 0; a < 2; a++) {
            for (int b = 0; b < 2; b++) {
                pv_env_px(m, tip + i + a, mid_a - i + b, flip);
                pv_env_px(m, tip + i + a, mid_a + i + b, flip);
            }
        }
    }
}

/*
 * MIC. The one source in the shape list that is not a wave: the microphone's
 * envelope has no period at all, so it cannot be drawn on the LFO field, where
 * RATE means turns across the width and DEPTH means reach above and below the
 * middle. It keeps its own figure — the envelope sampled across the picture, on
 * one side of the middle line, because the modulation only ever pushes one way.
 * The other seven shapes are drawn by pv_sweep().
 */
static void pv_lfo(uint8_t *m, const pv_vals_t *v)
{
    enum { X0 = PV_FX0, X1 = PV_FX1, MID = (PV_FY0 + PV_FY1) / 2,
           AMP = (PV_FY1 - PV_FY0) / 2 };

    const float cycles = 1.0f + 2.0f * (float)v->q[1] * 0.02f;
    const float depth = (float)v->q[2] * 0.02f;
    const float phase = (float)v->q[3] * 0.02f;
    const float inv_x = 1.0f / (float)(X1 - X0);

    int ys[64];
    int n = 0;
    for (int x = X0; x <= X1; x++, n++) {
        float ph = (float)(x - X0) * inv_x * cycles + phase;
        ph -= (float)(int)ph;
        const float held = pv_tab(PV_MIC_ENV, ph * 15.0f) * 0.01f;
        ys[n] = pv_round((float)MID - held * depth * (float)AMP);
    }
    pv_plot(m, X0, ys, n);
}

/*
 * MIC, THE SCOPE'S LINE FALLING ON THE ENVELOPE.
 *
 * The microphone has no waveform: it has an envelope, and the depth is how much of it the
 * modulation takes. So the picture is the envelope as a comb of nine columns along the
 * foot, and the LFO's own line above it: at zero the line is a straight rule at the top of
 * the field — a constant, which is what no depth means — and as the depth rises the rule
 * comes down until it lies on the envelope.
 *
 * IT LIES ON IT LIKE A ROPE. The line is what you get when a rope is dropped on a row of
 * pegs: it rests on the pegs it reaches, two rows of air above them, and between two pegs
 * it sags no steeper than one row per column — forty-five degrees, the steepest a two
 * pixel stroke can go without leaving a hole. Columns lower than the rope is are never
 * touched: their air is the reading, the part of the envelope the depth does not take.
 *
 * That shape is the lowest line that clears every peg, and it is one expression: for each
 * column, the lowest of the nine cones that hang from the column tops. The owner's frames
 * gave the comb and the level of the line at half travel; both are his numbers below.
 */
static void pv_lfo_mic(uint8_t *m, const pv_vals_t *v)
{
    enum { X0 = 1, X1 = 42, FLOOR = 40, LAST = 41, TOP_ROW = 2, GAP = 4, SIDE = 44 };
    /* Волна из кадров владельца: левый столбец и верх, ширина два, шаг пять. */
    static const uint8_t bar_x[9] = { 1, 6, 11, 16, 21, 26, 31, 36, 41 };
    static const uint8_t bar_top[9] = { 21, 25, 34, 25, 30, 21, 27, 33, 38 };
    /* Верх линии в среднем кадре владельца, по столбцам 1..42. */
    static const uint8_t mids[42] = {
        8, 8, 8, 9, 10, 10, 11, 11, 12, 13, 15, 15, 14, 12,
        11, 11, 11, 11, 12, 12, 13, 13, 12, 10, 9, 9,
        9, 9, 10, 11, 12, 12, 12, 13, 14, 15, 15, 15,
        16, 17, 17, 17,
    };

    const int depth = v->q[0] > 50 ? 50 : v->q[0];

    /* Свой буфер: строки шириной в один пиксель придётся добивать, а по маске
     * этого не сделать — она уже упакована. */
    uint8_t art[SIDE][(SIDE + 7) / 8];
    memset(art, 0, sizeof(art));
#define PV_ART_SET(x, y) \
    do { \
        if ((x) >= 0 && (x) < SIDE && (y) >= 0 && (y) < SIDE) { \
            art[(y)][(x) >> 3] |= (uint8_t)(0x80u >> ((x) & 7)); \
        } \
    } while (0)
#define PV_ART_GET(x, y) (((x) >= 0 && (x) < SIDE && (y) >= 0 && (y) < SIDE) \
    ? (unsigned)((art[(y)][(x) >> 3] >> (7 - ((x) & 7))) & 1u) : 0u)

    /* Пол и столбики. */
    for (int x = X0; x <= X1; x++) {
        PV_ART_SET(x, FLOOR);
        PV_ART_SET(x, LAST);
    }
    for (int i = 0; i < 9; i++) {
        for (int x = bar_x[i]; x <= bar_x[i] + 1; x++) {
            for (int y = bar_top[i]; y <= LAST; y++) {
                PV_ART_SET(x, y);
            }
        }
    }

    /* Линия: от верхней прямой до верёвки, лёгшей на столбики. */
    for (int x = X0; x <= X1; x++) {
        int rest = 99;
        for (int i = 0; i < 9; i++) {
            int d = (x > bar_x[i] + 1) ? x - (bar_x[i] + 1) : (bar_x[i] + 1) - x;
            if (d > 0) {
                d -= 1;
            }
            const int cone = (int)bar_top[i] - GAP + d;
            if (cone < rest) {
                rest = cone;
            }
        }
        if (rest > FLOOR - 4) {
            rest = FLOOR - 4;
        }

        const int mid = mids[(x - 1) % 42];
        int y;
        if (depth <= 25) {
            y = TOP_ROW + ((mid - TOP_ROW) * depth + 12) / 25;
        } else {
            y = mid + ((rest - mid) * (depth - 25) + 12) / 25;
        }
        PV_ART_SET(x, y);
        PV_ART_SET(x, y + 1);
    }

    /* Строка шириной в пиксель получает второй пиксель в сторону соседа: штрих два
     * пикселя при любом наклоне, и ни одного просвета в нём. */
    for (int y = 0; y < SIDE; y++) {
        for (int x = 0; x < SIDE; x++) {
            if (!PV_ART_GET(x, y)) {
                continue;
            }
            if (PV_ART_GET(x - 1, y) || PV_ART_GET(x + 1, y)) {
                continue;                       /* строка уже не одна */
            }
            const int right = PV_ART_GET(x + 1, y - 1) || PV_ART_GET(x + 1, y + 1);
            const int left = PV_ART_GET(x - 1, y - 1) || PV_ART_GET(x - 1, y + 1);
            if (!right && !left) {
                continue;
            }
            PV_ART_SET(left && !right ? x - 1 : x + 1, y);
        }
    }

    for (int y = 0; y < SIDE; y++) {
        for (int x = 0; x < SIDE; x++) {
            if (PV_ART_GET(x, y)) {
                pv_px(m, PV_AREA_X0 + x, PV_AREA_Y0 + y);
            }
        }
    }

#undef PV_ART_SET
#undef PV_ART_GET
}

/*
 * RATE. How many periods of the drift fit in the same width: half a period at the
 * bottom, three and a half at the top. The height does not change, because the
 * knob changes frequency and not depth — that is the picture next to it.
 */

/*
 * MOD DEPTH. Two waves, one amplitude: the full-travel reference in 2 px and the
 * current value over it in 3 px. At the bottom the bright one is almost flat; at
 * the top it covers the reference exactly. There is no second colour to say
 * "reference", so the reference is the thinner line.
 */

/*
 * THE FOUR TRIG ICONS, converted from the owner's own 44 x 44 drawings rather than
 * redrawn: one bit per pixel, MSB first, six bytes to a row (44 bits used, four spare).
 * A drawing that is converted keeps his proportions exactly — every stroke here is a
 * pixel he placed — and the third of the width where the note falls, the height of the
 * steps and the spot where the one-shot wave stops are his numbers, not mine.
 *
 * The bit means ink on the screen: white on his sheet is a set bit here.
 *
 * They are the only figures in this file that are not computed; everything else is a
 * function of the knobs. TRIG has no knob of its own to be a function of — its four
 * values are four pictures, and that is the whole parameter.
 */
static const uint8_t PV_TRIG_ICONS[4][44 * 6] = {
    {   /* FREE */
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x3C, 0x00, 0x00, 0x00, 0x00,
        0x00, 0xFF, 0x00, 0x00, 0x00, 0x00,
        0x01, 0xC3, 0x80, 0x00, 0x00, 0x00,
        0x03, 0x00, 0xC0, 0x00, 0x00, 0x00,
        0x06, 0x00, 0x60, 0x00, 0x00, 0x00,
        0x0C, 0x00, 0x30, 0x00, 0x00, 0x00,
        0x1C, 0x00, 0x38, 0x00, 0x00, 0x10,
        0x18, 0x00, 0x18, 0x00, 0x00, 0x10,
        0x30, 0x00, 0x0C, 0x00, 0x00, 0x30,
        0x30, 0x00, 0x0C, 0x00, 0x00, 0x30,
        0x60, 0x00, 0x06, 0x00, 0x00, 0x60,
        0x60, 0x00, 0x06, 0x00, 0x00, 0x60,
        0xC0, 0x00, 0x03, 0x00, 0x00, 0xC0,
        0xC0, 0x00, 0x03, 0x00, 0x00, 0xC0,
        0x80, 0x00, 0x01, 0x80, 0x01, 0x80,
        0x80, 0x00, 0x01, 0x80, 0x03, 0x80,
        0x00, 0x00, 0x00, 0xC0, 0x03, 0x00,
        0x00, 0x00, 0x00, 0x60, 0x06, 0x00,
        0x00, 0x00, 0x00, 0x30, 0x0C, 0x00,
        0x00, 0x00, 0x00, 0x1C, 0x38, 0x00,
        0x00, 0x00, 0x00, 0x0F, 0xF0, 0x00,
        0x00, 0x00, 0x00, 0x03, 0xC0, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    },
    {   /* NOTE */
        0x03, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x03, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x03, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x03, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x03, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x03, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x03, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x03, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x03, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x03, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x03, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x03, 0x01, 0xE0, 0x00, 0x00, 0x00,
        0x83, 0x07, 0xF8, 0x00, 0x00, 0x00,
        0xC3, 0x0E, 0x1C, 0x00, 0x00, 0x00,
        0x63, 0x18, 0x06, 0x00, 0x00, 0x00,
        0x33, 0x30, 0x03, 0x00, 0x00, 0x00,
        0x1B, 0x60, 0x01, 0x80, 0x00, 0x00,
        0x0F, 0xE0, 0x01, 0xC0, 0x00, 0x00,
        0x0F, 0xC0, 0x00, 0xC0, 0x00, 0x00,
        0x07, 0x80, 0x00, 0x60, 0x00, 0x00,
        0x07, 0x80, 0x00, 0x60, 0x00, 0x00,
        0x03, 0x00, 0x00, 0x30, 0x00, 0x00,
        0x03, 0x00, 0x00, 0x30, 0x00, 0x00,
        0x03, 0x00, 0x00, 0x18, 0x00, 0x00,
        0x03, 0x00, 0x00, 0x18, 0x00, 0x00,
        0x03, 0x00, 0x00, 0x0C, 0x00, 0x00,
        0x03, 0x00, 0x00, 0x0E, 0x00, 0x10,
        0x03, 0x00, 0x00, 0x06, 0x00, 0x10,
        0x03, 0x00, 0x00, 0x03, 0x00, 0x30,
        0x03, 0x00, 0x00, 0x01, 0x80, 0x60,
        0x03, 0x00, 0x00, 0x00, 0xE1, 0xC0,
        0x03, 0x00, 0x00, 0x00, 0x7F, 0x80,
        0x03, 0x00, 0x00, 0x00, 0x1E, 0x00,
        0x03, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x03, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x03, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x03, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x03, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x03, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x03, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x03, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x03, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x03, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x03, 0x00, 0x00, 0x00, 0x00, 0x00,
    },
    {   /* HOLD */
        0x00, 0x00, 0x00, 0x00, 0x00, 0x60,
        0x00, 0x00, 0x00, 0x01, 0xFF, 0xE0,
        0x00, 0x00, 0x00, 0x01, 0xFF, 0xE0,
        0x00, 0x00, 0x00, 0x01, 0x80, 0x00,
        0x00, 0x00, 0x00, 0x01, 0x80, 0x00,
        0x00, 0x00, 0x00, 0x01, 0x80, 0x00,
        0x00, 0x00, 0x00, 0x01, 0x80, 0x00,
        0x00, 0x00, 0x00, 0x01, 0x80, 0x00,
        0x00, 0x00, 0x00, 0x01, 0x80, 0x00,
        0x00, 0x00, 0x00, 0x01, 0x80, 0x00,
        0x00, 0x00, 0x00, 0x01, 0x80, 0x00,
        0x00, 0x00, 0x07, 0xFF, 0x80, 0x00,
        0x00, 0x00, 0x07, 0xFF, 0x80, 0xC0,
        0x00, 0x00, 0x06, 0x00, 0x01, 0xC0,
        0x00, 0x00, 0x06, 0x00, 0x03, 0x80,
        0x00, 0x00, 0x06, 0x00, 0x07, 0x00,
        0x00, 0x00, 0x06, 0x00, 0x0E, 0x00,
        0x00, 0x00, 0x06, 0x00, 0x1C, 0x00,
        0x00, 0x00, 0x06, 0x00, 0x38, 0x00,
        0x00, 0x00, 0x06, 0x00, 0x70, 0x00,
        0x00, 0x00, 0x06, 0x00, 0xE0, 0x00,
        0x00, 0x1F, 0xFE, 0x01, 0xC0, 0x00,
        0x00, 0x1F, 0xFE, 0x03, 0x80, 0x00,
        0x00, 0x18, 0x00, 0x07, 0x00, 0x00,
        0x00, 0x18, 0x00, 0x0E, 0x00, 0x00,
        0x00, 0x18, 0x00, 0x1C, 0x00, 0x00,
        0x00, 0x18, 0x00, 0x38, 0x00, 0x00,
        0x00, 0x18, 0x00, 0x70, 0x00, 0x00,
        0x00, 0x18, 0x00, 0xE0, 0x00, 0x00,
        0x00, 0x18, 0x01, 0xC0, 0x00, 0x00,
        0x00, 0x18, 0x03, 0x80, 0x00, 0x00,
        0x7F, 0xF8, 0x07, 0x00, 0x00, 0x00,
        0x7F, 0xF8, 0x0E, 0x00, 0x00, 0x00,
        0x60, 0x00, 0x1C, 0x00, 0x00, 0x00,
        0x60, 0x00, 0x38, 0x00, 0x00, 0x00,
        0x60, 0x00, 0x70, 0x00, 0x00, 0x00,
        0x60, 0x00, 0xE0, 0x00, 0x00, 0x00,
        0x60, 0x01, 0xC0, 0x00, 0x00, 0x00,
        0x60, 0x03, 0x80, 0x00, 0x00, 0x00,
        0x60, 0x07, 0x00, 0x00, 0x00, 0x00,
        0x60, 0x0E, 0x00, 0x00, 0x00, 0x00,
        0xE0, 0x0C, 0x00, 0x00, 0x00, 0x00,
        0xE0, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    },
    {   /* ONES */
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x03, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x07, 0x80, 0x00, 0x00, 0x00, 0x00,
        0x0C, 0xC0, 0x00, 0x00, 0x00, 0x00,
        0x18, 0x60, 0x00, 0x00, 0x00, 0x00,
        0x18, 0x60, 0x00, 0x00, 0x00, 0x00,
        0x18, 0x60, 0x00, 0x00, 0x00, 0x00,
        0x30, 0x30, 0x00, 0x00, 0x00, 0x00,
        0x30, 0x30, 0x00, 0x00, 0x00, 0x00,
        0x30, 0x30, 0x00, 0x00, 0x00, 0x00,
        0x60, 0x18, 0x00, 0x00, 0x00, 0x00,
        0x60, 0x18, 0x07, 0xFF, 0xFF, 0xF0,
        0x60, 0x18, 0x07, 0xFF, 0xFF, 0xF0,
        0x00, 0x18, 0x06, 0x00, 0x00, 0x00,
        0x00, 0x0C, 0x0C, 0x00, 0x00, 0x00,
        0x00, 0x0C, 0x0C, 0x00, 0x00, 0x00,
        0x00, 0x0C, 0x0C, 0x00, 0x00, 0x00,
        0x00, 0x04, 0x18, 0x00, 0x00, 0x00,
        0x00, 0x06, 0x18, 0x00, 0x00, 0x00,
        0x00, 0x06, 0x38, 0x00, 0x00, 0x00,
        0x00, 0x03, 0x30, 0x00, 0x00, 0x00,
        0x00, 0x01, 0xE0, 0x00, 0x00, 0x00,
        0x00, 0x00, 0xC0, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    },
};

/* The icon is the whole 44 x 44 figure area, copied at 1:1: no offset, no brush, no
 * rounding — here a mask pixel is a screen pixel. */
static void pv_trig(uint8_t *m, const pv_vals_t *v)
{
    const int which = (v->q[0] < 4) ? (int)v->q[0] : 0;

    pv_icon(m, PV_TRIG_ICONS[which]);
}

/*
 * DENSITY. Sixteen rings on a four-by-four grid — one per step of the grid — and the knob
 * thins them out.
 *
 * DENSITY is not a count: it is the probability that a step sounds at all, and seq_fire()
 * tosses a coin at every onset. So the picture is sixteen coins too, not sixteen cells: each
 * ring has a threshold of its own and stands until the knob has passed it. A live coin under
 * the hand would show a different number of rings on every turn — the picture would flicker
 * rather than thin — so the sixteen tosses are written down instead, laid on sixteen equal
 * slices of the travel and then shuffled.
 *
 * That is what makes the count follow the percentage without ever being a percentage: eight of
 * them at 50 %, four at 24 %, one at 2 %, all sixteen at 100 %, and never more than one away
 * from the quarter, the half and the three quarters. The shuffle is what makes them go in
 * scattered places rather than row by row.
 *
 * The ring is the owner's own drawing, a byte to the row, and it comes back pixel for pixel:
 * eight by eight with a two-pixel stroke, a four-pixel hole, the grid's step ten from a field
 * that starts at the third column.
 */
#define PV_DENSITY_CELLS 4
/* The ring, eight rows of eight: the top bit is the left column. */
static const uint8_t PV_DENSITY_DOT[8] = {
    0x3C, 0x7E, 0xE7, 0xC3, 0xC3, 0xE7, 0x7E, 0x3C,
};
/* When each ring goes, in steps of the knob's own 0..50 travel: a ring stands while its own
 * number is under the knob. Read left to right, top to bottom. */
static const uint8_t PV_DENSITY_TOSS[PV_DENSITY_CELLS * PV_DENSITY_CELLS] = {
    30, 8, 46, 17, 0, 36, 24, 11, 43, 20, 49, 5, 33, 14, 39, 27,
};

static void pv_density(uint8_t *m, const pv_vals_t *v)
{
    enum { X0 = 3, Y0 = 3, STEP = 10, RING = 8 };
    const int q = (int)v->q[0];

    for (int row = 0; row < PV_DENSITY_CELLS; row++) {
        for (int col = 0; col < PV_DENSITY_CELLS; col++) {
            const int cell = row * PV_DENSITY_CELLS + col;
            if (q <= (int)PV_DENSITY_TOSS[cell]) {
                continue;
            }
            const int ox = PV_AREA_X0 + X0 + col * STEP;
            const int oy = PV_AREA_Y0 + Y0 + row * STEP;

            for (int y = 0; y < RING; y++) {
                const uint8_t bits = PV_DENSITY_DOT[y];
                for (int x = 0; x < RING; x++) {
                    if ((bits >> (RING - 1 - x)) & 1u) {
                        pv_px(m, ox + x, oy + y);
                    }
                }
            }
        }
    }
}

/*
 * DUCK. The compressor's frame, read as the hit: nine bars on an axis, but here the drum
 * presses the level down — a notch opens at the left and a ball on a thread comes into the
 * field above it and rides down with the bars.
 *
 * The notch keeps one shape for the whole travel: bars 2 and 3 sit 3 and 4 rows below the
 * first, and from the fifth bar the row climbs back (+3, +6, +8, +9, +9). What moves is the
 * level T — 19, 17, 13, 9 and 7 — so the right half stays in the ceiling of 19 until the
 * whole figure has sunk below it. That is the owner's six 44 x 44 drawings read in order,
 * and the bars come back bar for bar.
 *
 * The ball is drawn, not traced: an even circle, symmetric about both axes, two pixels of
 * stroke between radii 4 and 6, hung on a two-pixel thread from the field's top edge. It
 * enters row by row — none at all, then one row, then two — and only after that does it sit
 * one row above the bars and travel with them; a jump of a stroke's width at the first
 * appearance is what the owner asked to remove. The lower twin is the mirror in the lower
 * half, so the figure reads the same from either side of the axis.
 */
#define PV_DUCK_BARS 9
/* Rows below the first bar, as drawn. */
static const int8_t PV_DUCK_PROFILE[PV_DUCK_BARS] = { 0, -3, -4, 0, 3, 6, 8, 9, 9 };
/* Which end of a shortened bar carries its one-pixel tip: 0 none, 1 left, 2 right. */
static const uint8_t PV_DUCK_CAP[PV_DUCK_BARS] = { 1, 0, 2, 2, 2, 0, 0, 0, 0 };
/* The level T in tenths of a row, at q = 0, 10, 20, 30, 40 and 50. */
static const uint8_t PV_DUCK_LEVEL[6] = { 190, 190, 170, 130, 90, 70 };

static int pv_duck_level(int q)
{
    if (q < 0) {
        q = 0;
    }
    if (q > 50) {
        q = 50;
    }
    const int i = q / 10;
    if (i >= 5) {
        return PV_DUCK_LEVEL[5];
    }
    const int a = PV_DUCK_LEVEL[i];
    const int b = PV_DUCK_LEVEL[i + 1];
    return a + (b - a) * (q - i * 10) / 10;
}

static int pv_duck_bar(int q, int k)
{
    const int dip = q >= 10 ? 10 : q;    /* the notch is at full depth after ten steps */
    const int v10 = pv_duck_level(q) + dip * (int)PV_DUCK_PROFILE[k];
    int v = v10 >= 0 ? (v10 + 5) / 10 : -((-v10 + 5) / 10);
    if (v < 0) {
        v = 0;
    }
    if (v > 19) {
        v = 19;                          /* the right half stands in the ceiling */
    }
    return v;
}

static void pv_duck(uint8_t *m, const pv_vals_t *v)
{
    enum {
        AXIS_TOP  = 21,
        AXIS_BOT  = 22,
        BAR_LAST  = 20,   /* the upper half ends against the axis */
        BAR_FIRST = 25,   /* the lower half starts two rows below it */
        BAR_X0    = 1,
        BAR_STEP  = 5,
        BAR_W     = 2,
        BAR_DROP  = 2,    /* how much shorter the lower half is */
        BAR_MAX   = 19,
        RING_CX2  = 19,   /* the circle's centre, doubled: x = 9.5 */
        RING_IN   = 4,    /* the hole's radius */
        RING_OUT  = 6,    /* the outer radius, so the stroke is two pixels */
        RING_D    = 11,   /* centre to the ball's last row */
        STEM_X    = 9     /* the thread's left column, two pixels wide */
    };
    const int q = (int)v->q[0];

    for (int k = 0; k < PV_DUCK_BARS; k++) {
        const int a = pv_duck_bar(q, k);
        const int x = PV_AREA_X0 + BAR_X0 + k * BAR_STEP;
        const int top = BAR_LAST - a + 1;
        const int bot = BAR_FIRST + a - BAR_DROP - 1;

        for (int y = top; y <= BAR_LAST; y++) {
            for (int dx = 0; dx < BAR_W; dx++) {
                pv_px(m, x + dx, PV_AREA_Y0 + y);
            }
        }
        for (int y = BAR_FIRST; y <= bot; y++) {
            for (int dx = 0; dx < BAR_W; dx++) {
                pv_px(m, x + dx, PV_AREA_Y0 + y);
            }
        }
        if (a < BAR_MAX && PV_DUCK_CAP[k]) {
            const int cx = x + (PV_DUCK_CAP[k] == 1 ? 0 : 1);
            pv_px(m, cx, PV_AREA_Y0 + top - 1);
            pv_px(m, cx, PV_AREA_Y0 + bot + 1);
        }
    }

    const int xend = PV_AREA_X0 + BAR_X0 + (PV_DUCK_BARS - 1) * BAR_STEP + BAR_W - 1;
    for (int x = PV_AREA_X0 + BAR_X0; x <= xend; x++) {
        pv_px(m, x, PV_AREA_Y0 + AXIS_TOP);
        pv_px(m, x, PV_AREA_Y0 + AXIS_BOT);
    }

    /* The ball enters row by row: its last row runs from -1 (nothing on the field) up to
     * 1 (two rows), and from the tenth step it is pinned one row above the bars. */
    const int r = q >= 10 ? 20 - pv_duck_bar(q, 0) : -1 + (2 * q) / 10;
    if (r < 0) {
        return;
    }

    for (int half = 0; half < 2; half++) {
        /* Centre on a half pixel, so the circle is symmetric on both axes; the lower ball
         * is the mirror of the upper one about the axis. */
        const int cy2 = half == 0 ? 2 * r - RING_D : 86 - (2 * r - RING_D);

        for (int y = 0; y < 44; y++) {
            const int uy = 2 * y - cy2;
            for (int x = 0; x < 44; x++) {
                const int ux = 2 * x - RING_CX2;
                const int d2 = ux * ux + uy * uy;
                if (d2 >= RING_IN * RING_IN * 4 && d2 <= RING_OUT * RING_OUT * 4) {
                    pv_px(m, PV_AREA_X0 + x, PV_AREA_Y0 + y);
                }
            }
        }

        /* The thread fills the dark gap between the ball and the field's edge. */
        const int from = half == 0 ? 0 : (cy2 + RING_D) / 2 + 1;
        const int to = half == 0 ? (cy2 - RING_D) / 2 - 1 : 43;
        for (int y = from; y <= to; y++) {
            pv_px(m, PV_AREA_X0 + STEM_X, PV_AREA_Y0 + y);
            pv_px(m, PV_AREA_X0 + STEM_X + 1, PV_AREA_Y0 + y);
        }
    }
}

/*
 * FOLLOW. A tracking picture, the same one an arpeggiator or a MIDI merge shows:
 * the lead's pitch runs left to right, the drone's answer runs bottom to top, and
 * the question the knob asks is "how does the register answer a rising note".
 *
 *   SCALE  it rises in scale steps — a staircase;
 *   CONS   the register holds its own note — a flat line across the middle;
 *   FULL   it rises with the note — one straight diagonal.
 *
 * The previous drawing was a register that "reached" for a note mark on the
 * right, and the owner's verdict was that neither he nor a user could tell what
 * it meant. The line, the diagonal and the staircase are three shapes the eye
 * separates at once, and each one is the literal behaviour of the mode.
 */
static void pv_follow(uint8_t *m, const pv_vals_t *v)
{
    enum { X0 = PV_FX0, X1 = PV_FX1, YT = PV_FY0, YB = PV_FY1 };
    const int mode = v->q[0];

    if (mode == 1) {                        /* CONS: the register never leaves */
        const int y = (YT + YB) / 2;
        pv_stroke(m, X0, y & ~1, X1, y & ~1);
        return;
    }

    if (mode == 2) {                        /* FULL: the register tracks */
        pv_stroke(m, X0, YB, X1, YT);
        return;
    }

    /* SCALE: six treads of seven pixels, each a riser of six, from the floor at
     * the left edge to just under the top at the right one. The treads are what
     * makes it read as steps instead of a ragged diagonal. */
    const int tread = 7;
    const int riser = 6;
    int y = YB;
    for (int i = 0; i < 6; i++) {
        const int x = X0 + i * tread;
        pv_stroke(m, x, y, x + tread, y);
        if (i < 5) {
            pv_stroke(m, x + tread, y, x + tread, y - riser);
        }
        y -= riser;
    }
}

/*
 * WIDTH. The three registers and their spread: the knob widens the field, so the
 * same three lines move apart. Four pixels between centres is the floor, because
 * two 2 px strokes with less than 2 px of air read as one thick stroke.
 */
static void pv_width(uint8_t *m, const pv_vals_t *v)
{
    enum { X0 = PV_FX0, X1 = PV_FX1, TOP = PV_FY0, BOT = PV_FY1 };

    /* The three registers always span the field: the outer two sit on its edges
     * and the middle one moves with WIDTH, so the spread is what the picture
     * says and the size never changes. */
    const int mid = pv_even(TOP + 4 + ((BOT - TOP - 8) * (50 - (int)v->q[0])) / 50);

    pv_stroke(m, X0, TOP, X1, TOP);
    pv_stroke(m, X0, mid, X1, mid);
    pv_stroke(m, X0, BOT, X1, BOT);
}

/*
 * THE TWO STEP MARKS, as rows of bits over the six-pixel cell, MSB first from the cell's
 * left edge:
 *
 *   accent   the whole cell with its four corners cut: flat sides, rounded corners, and
 *            twice the ink of the other, so it reads as the strong step at arm's length
 *            without turning into a bigger circle;
 *   weak     4 x 4 disc centred in the cell — the step that sounds, quietly.
 *
 * A SILENT STEP IS NOT DRAWN AT ALL. The first version gave it a ring, and on the glass the
 * ring read as a second kind of quiet dot rather than as an absence — at this pitch the hole
 * is two pixels across and the eye does not resolve it. Leaving the cell empty is the
 * reading that survives the screen: with WEAK VEL at zero the figure is the accents alone,
 * which is exactly what the instrument plays.
 */
static const uint8_t ACCENT_MARK[2][6] = {
    { 0x1E, 0x3F, 0x3F, 0x3F, 0x3F, 0x1E },   /* accent */
    { 0x00, 0x0C, 0x1E, 0x1E, 0x0C, 0x00 },   /* weak */
};

/*
 * ACCENT. Sixteen steps of the part's figure, four to a row on the ten-pixel lattice the
 * random shape uses: cells at 10, 20, 30 and 40, each 6 x 6, so the field 8..46 is filled
 * with equal margins. Step 1 is the top-left cell and the count runs left to right, top to
 * bottom — the order a bar is read in.
 *
 * WHICH CELLS ARE ACCENTED is the engine's own question, asked sixteen times: a figure
 * shorter than sixteen steps repeats, because that is exactly what accent_marks_step() does
 * to the sound. The picture then cannot show a rhythm the instrument will not play, which is
 * the one thing a static figure of a pattern must not do.
 */
static void pv_accent(uint8_t *m, const pv_vals_t *v)
{
    enum { CELL = 10, X0 = 10, Y0 = 10, WEAK = 1, ACCENT = 0 };

    const int accent = (int)v->q[0];
    const int n = (v->q[1] > 0) ? (int)v->q[1] : 16;
    const bool weak_off = v->q[2] != 0;

    for (int k = 0; k < 16; k++) {
        const bool marked = synth_app_accent_marks(accent, (uint32_t)k, n);
        if (!marked && weak_off) {
            continue;                   /* a step that will not sound is not drawn */
        }

        const int mark = marked ? ACCENT : WEAK;
        const int x = X0 + (k % 4) * CELL;
        const int y = Y0 + (k / 4) * CELL;

        for (int dy = 0; dy < 6; dy++) {
            const uint8_t bits = ACCENT_MARK[mark][dy];
            for (int dx = 0; dx < 6; dx++) {
                if (bits & (uint8_t)(0x20u >> dx)) {
                    pv_px(m, x + dx, y + dy);
                }
            }
        }
    }
}

/* PERC PITCH. The band-pass centre as the shape it is: one bell on a flat floor,
 * the bell moving along the axis. An end stop at each end and a marker on the
 * value were three symbols where a curve says the same thing. */
static void pv_perc_pitch(uint8_t *m, const pv_vals_t *v)
{
    enum { X0 = PV_FX0, X1 = PV_FX1, YB = PV_FY1, H = PV_FY1 - PV_FY0, W = 11 };

    const int c = pv_even(8 + pv_round(30.0f * (float)v->q[0] * 0.02f));
    int ys[64];
    int n = 0;
    for (int x = X0; x <= X1; x++, n++) {
        const int d = x > c ? x - c : c - x;
        const float a = (d >= W) ? 0.0f : 1.0f - (float)d / (float)W;
        ys[n] = YB - pv_round((float)H * a);
    }
    pv_curve(m, X0, ys, n);
}

/* PERC QUANT. What quantising does to a pitch sweep: OFF is the straight line,
 * ON is the same travel in four equal steps. */
static void pv_perc_quant(uint8_t *m, const pv_vals_t *v)
{
    enum { X0 = PV_FX0, X1 = PV_FX1, YB = PV_FY1, H = PV_FY1 - PV_FY0, W = 11 };

    /* The same bell as PITCH, held in four steps when QUANT is on: one family,
     * one figure, the property is the staircase. */
    const int c = pv_even(8 + pv_round(30.0f * (float)v->q[0] * 0.02f));
    const int on = v->q[0] != 0;

    int ys[64];
    int n = 0;
    for (int x = X0; x <= X1; x++, n++) {
        const int d = x > c ? x - c : c - x;
        float a = (d >= W) ? 0.0f : 1.0f - (float)d / (float)W;
        if (on) {
            a = floorf(a * 4.0f + 0.5f) * 0.25f;
        }
        ys[n] = YB - pv_round((float)H * a);
    }
    pv_curve(m, X0, ys, n);
}

/* PERC DECAY. How long the hit rings: the same fall, read further along the decay
 * table. The short gate falls out of the frame early; the long one holds its tail. */
static void pv_perc_decay(uint8_t *m, const pv_vals_t *v)
{
    enum { X0 = PV_FX0, X1 = PV_FX1, YT = PV_FY0, YB = PV_FY1 };
    const float speed = 2.5f - 2.0f * (float)v->q[0] * 0.02f;
    const float inv_x = 1.0f / (float)(X1 - X0);

    int ys[64];
    int n = 0;
    for (int x = X0; x <= X1; x++, n++) {
        const float u = (float)(x - X0) * inv_x;
        const float a = pv_tab(PV_TAIL_FAST, u * 15.0f * speed);
        ys[n] = YB - pv_round((float)(YB - YT) * a * 0.01f);
    }
    pv_curve(m, X0, ys, n);
}

/* PERC BODY. The click and the body as one curve: the fast table is the click,
 * the slow one the body, and the knob is the blend between them. */
static void pv_perc_body(uint8_t *m, const pv_vals_t *v)
{
    enum { X0 = PV_FX0, X1 = PV_FX1, YT = PV_FY0, YB = PV_FY1 };
    const float body = (float)v->q[0] * 0.02f;
    const float inv_x = 1.0f / (float)(X1 - X0);

    int ys[64];
    int n = 0;
    for (int x = X0; x <= X1; x++, n++) {
        const float u = (float)(x - X0) * inv_x;
        const float fast = pv_tab(PV_TAIL_FAST, u * 15.0f);
        const float slow = pv_tab(PV_TAIL_SLOW, u * 15.0f);
        const float a = fast + (slow - fast) * body;
        ys[n] = YB - pv_round((float)(YB - YT) * a * 0.01f);
    }
    pv_curve(m, X0, ys, n);
}

/* PERC ENV. How far the filter falls over the hit: the curve starts at the top
 * and settles on a floor the knob moves down. */
static void pv_perc_env(uint8_t *m, const pv_vals_t *v)
{
    enum { X0 = PV_FX0, X1 = PV_FX1, YT = PV_FY0, YB = PV_FY1 };
    const int floor_y = pv_even(14 + pv_round(32.0f * (float)v->q[0] * 0.02f));
    const float inv_x = 1.0f / (float)(X1 - X0);

    int ys[64];
    int n = 0;
    for (int x = X0; x <= X1; x++, n++) {
        const float u = (float)(x - X0) * inv_x;
        const float a = pv_tab(PV_TAIL_FAST, u * 15.0f);
        ys[n] = floor_y - pv_round((float)(floor_y - YT) * a * 0.01f);
    }
    pv_curve(m, X0, ys, n);
}

/*
 * THE EIGHT ARPEGGIO POSITIONS, the owner's 44 x 44 drawings converted to bits: OFF
 * first — one line, nothing running — then the seven directions.
 *
 * They belong to DIR alone. SPEED, LEN and RANGE still draw the run they make — a
 * staircase whose pitch, height and number of spans are the knobs' own numbers — so
 * the picture under the finger is the thing that knob did, not a picture of a list.
 */
static const uint8_t PV_ARP_ICONS[8][44 * 6] = {
    {   /* OFF */
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x7F, 0xFF, 0xFF, 0xFF, 0xFF, 0xE0,
        0x7F, 0xFF, 0xFF, 0xFF, 0xFF, 0xE0,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    },
    {   /* UP */
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x01, 0xFF, 0xE0,
        0x00, 0x00, 0x00, 0x01, 0xFF, 0xE0,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x07, 0xFF, 0x80, 0x00,
        0x00, 0x00, 0x07, 0xFF, 0x80, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x1F, 0xFE, 0x00, 0x00, 0x00,
        0x00, 0x1F, 0xFE, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x7F, 0xF8, 0x00, 0x00, 0x00, 0x00,
        0x7F, 0xF8, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    },
    {   /* DN */
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x7F, 0xF8, 0x00, 0x00, 0x00, 0x00,
        0x7F, 0xF8, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x1F, 0xFE, 0x00, 0x00, 0x00,
        0x00, 0x1F, 0xFE, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x07, 0xFF, 0x80, 0x00,
        0x00, 0x00, 0x07, 0xFF, 0x80, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x01, 0xFF, 0xE0,
        0x00, 0x00, 0x00, 0x01, 0xFF, 0xE0,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    },
    {   /* UP-DN */
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x07, 0xFF, 0x80, 0x00,
        0x00, 0x00, 0x07, 0xFF, 0x80, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x1F, 0xFE, 0x00, 0x00, 0x00,
        0x00, 0x1F, 0xFE, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x01, 0xFF, 0xE0,
        0x00, 0x00, 0x00, 0x01, 0xFF, 0xE0,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x7F, 0xF8, 0x00, 0x00, 0x00, 0x00,
        0x7F, 0xF8, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    },
    {   /* DN-UP */
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x7F, 0xF8, 0x00, 0x00, 0x00, 0x00,
        0x7F, 0xF8, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x01, 0xFF, 0xE0,
        0x00, 0x00, 0x00, 0x01, 0xFF, 0xE0,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x1F, 0xFE, 0x00, 0x00, 0x00,
        0x00, 0x1F, 0xFE, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x07, 0xFF, 0x80, 0x00,
        0x00, 0x00, 0x07, 0xFF, 0x80, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    },
    {   /* UP-DN+ */
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x03, 0xFE, 0x7F, 0xC0,
        0x00, 0x00, 0x03, 0xFE, 0x7F, 0xC0,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x3F, 0xE7, 0xFC, 0x00, 0x00, 0x00,
        0x3F, 0xE7, 0xFC, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    },
    {   /* DN-UP+ */
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x3F, 0xE7, 0xFC, 0x00, 0x00, 0x00,
        0x3F, 0xE7, 0xFC, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x03, 0xFE, 0x7F, 0xC0,
        0x00, 0x00, 0x03, 0xFE, 0x7F, 0xC0,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    },
    {   /* RAND */
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x7F, 0x00, 0x00, 0x00, 0x0F, 0xE0,
        0x7F, 0x00, 0x00, 0x00, 0x0F, 0xE0,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x3F, 0x80, 0x00,
        0x00, 0x00, 0x00, 0x3F, 0x80, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x1F, 0xC0, 0x00, 0x00, 0x00,
        0x00, 0x1F, 0xC0, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x01, 0xFC, 0x00,
        0x00, 0x00, 0x00, 0x01, 0xFC, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0xFE, 0x00, 0x00, 0x00,
        0x00, 0x00, 0xFE, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x03, 0xF8, 0x00, 0x00, 0x00, 0x00,
        0x03, 0xF8, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    },
};

/*
 * ARP. A staircase with exactly LEN treads: a riser and a tread per note, the
 * first riser leaving the floor and the last tread ending the figure. UP puts the
 * low note on the left and the high one on the right, DOWN the other way round,
 * and UP-DOWN climbs and comes back. The run is scaled to the frame: the lowest
 * note on the floor and the highest on the ceiling, so LEN = 2 is one tread at
 * each end. RANGE changes the octave span the run covers; a static plot has one
 * frame for every span, so the frame shows the shape and the readout shows the
 * octaves.
 *
 * The count used to be one short because the first note was a bare riser and the
 * last tread was never drawn: with LEN = 2 that is one visible step. Both are
 * fixed here by drawing LEN treads and starting the first riser at the floor.
 */
static void pv_arp(uint8_t *m, const pv_vals_t *v)
{
    /* One icon per direction and nothing else: the ladder that used to be drawn here is
     * gone with the figures of SPEED, LEN and RANGE. */
    pv_icon(m, PV_ARP_ICONS[v->q[0]]);
}
/* -------------------------------------------------------------------------- */
/* Уровни посыла                                                              */
/* -------------------------------------------------------------------------- */

/*
 * THE SEND LEVELS ARE ONE FIGURE PER SECTION, AND THE FIGURE COUNTS. Reverb sends
 * rings, delay sends diamonds, chorus sends two capsules; a quarter of the travel
 * adds one more ring or one more diamond, and the chorus pulls its capsules apart.
 * The owner drew all five states at 1:1, so every number below is measured from
 * his frames and not invented: a ring or a diamond that has appeared never changes
 * size, only new ones are added, and the spacing is fixed — which is exactly what
 * keeps the lines from breathing or merging between steps.
 *
 * The area is the usual 44 x 44, columns and rows 6..49, and these figures draw
 * absolute mask coordinates: their centre is the frame's centre, (28, 28).
 */
#define PV_SEND_VERB_RINGS 5
#define PV_SEND_DELAY_RINGS 5

/* Одиночный пиксель, а не блок 2 x 2, поэтому поле шире, чем PV_AREA_*: у блока
 * правый край это 48..49, у пикселя — сам 49. */
#define PV_SEND_X1 49
#define PV_SEND_Y1 49

/* Radii of the five states: reverb from the outside in, delay from the inside out. */
static const uint8_t PV_SEND_VERB_R[PV_SEND_VERB_RINGS] = { 20, 16, 12, 8, 4 };
static const uint8_t PV_SEND_DELAY_R[PV_SEND_DELAY_RINGS] = { 5, 10, 15, 20, 25 };

/* Chorus: how far the inner edges have moved at each of the five states. The
 * capsules keep their height and their outer edges; this is the only number that
 * travels, and it travels between the states linearly, so the picture steps by a
 * pixel at a time instead of jumping at the quarter marks. */
static const uint8_t PV_SEND_CHORUS_P[5] = { 0, 10, 16, 18, 20 };

/* The capsule's box and corner: rows 7..49 of the mask, radius 11, stroke 2 deep. */
#define PV_SEND_CAP_R 11
#define PV_SEND_CAP_T 7
#define PV_SEND_CAP_B 49
#define PV_SEND_CAP_L 7
#define PV_SEND_CAP_RT 49

/* Which of the five states the knob is in: one at zero, five at full travel. */
static int pv_send_state(int q)
{
    const int i = pv_div_round(q * 4, 50);      /* q is 0..50 on the picture grid */
    return i < 0 ? 0 : (i > 4 ? 4 : i);
}

/* A ring of the reverb ladder: the pixels whose distance from the centre is within
 * one pixel of the radius. Squared distances in doubled coordinates — no square
 * root on the drawing path, and the same pixels the prototype drew. */
static void pv_send_verb(uint8_t *m, const pv_vals_t *v)
{
    const int count = pv_send_state(v->q[0]) + 1;
    for (int i = 0; i < count; i++) {
        const int lo = 2 * PV_SEND_VERB_R[i] - 2;
        const int hi = 2 * PV_SEND_VERB_R[i] + 2;
        for (int y = PV_AREA_Y0; y <= PV_SEND_Y1; y++) {
            const int dy = 2 * y - 55;          /* the centre sits at 28.0 */
            for (int x = PV_AREA_X0; x <= PV_SEND_X1; x++) {
                const int dx = 2 * x - 55;
                const int d2 = dx * dx + dy * dy;
                if (d2 >= lo * lo && d2 <= hi * hi) {
                    pv_px(m, x, y);
                }
            }
        }
    }
}

/* A diamond of the delay ladder: the same walk in the taxicab metric. The ladder's
 * step is five pixels and the stroke is three of them, so two neighbouring diamonds
 * always keep two pixels of air between them however the knob sits. */
static void pv_send_delay(uint8_t *m, const pv_vals_t *v)
{
    const int count = pv_send_state(v->q[0]) + 1;
    for (int i = 0; i < count; i++) {
        const int lo = 2 * PV_SEND_DELAY_R[i] - 2;
        const int hi = 2 * PV_SEND_DELAY_R[i] + 2;
        for (int y = PV_AREA_Y0; y <= PV_SEND_Y1; y++) {
            const int dy = 2 * y - 55;
            const int ady = dy < 0 ? -dy : dy;
            for (int x = PV_AREA_X0; x <= PV_SEND_X1; x++) {
                const int dx = 2 * x - 55;
                const int adx = dx < 0 ? -dx : dx;
                const int d = adx + ady;
                if (d >= lo && d <= hi) {
                    pv_px(m, x, y);
                }
            }
        }
    }
}

/* Inside a rounded rectangle, all coordinates doubled. The classic corner test: the
 * distance to the shrunk box, compared with the radius. */
static bool pv_send_rr_in(int px, int py, int x0, int x1, int y0, int y1, int r)
{
    const int ax = x0 + r;
    const int bx = x1 - r;
    const int ay = y0 + r;
    const int by = y1 - r;
    int dx = 0;
    int dy = 0;
    if (px < ax) {
        dx = ax - px;
    } else if (px > bx) {
        dx = px - bx;
    }
    if (py < ay) {
        dy = ay - py;
    } else if (py > by) {
        dy = py - by;
    }
    return dx * dx + dy * dy <= r * r;
}

/* The chorus send: two capsules of one height. At zero they coincide and read as
 * one rounded square; as the knob turns their inner edges part and the pair becomes
 * two vessels. The stroke is two pixels inside the box, which is the same run of
 * pixels the prototype drew. */
static void pv_send_chorus(uint8_t *m, const pv_vals_t *v)
{
    /* The states sit every quarter; between two of them the shift is a straight
     * line, in twenty-five steps of the doubled grid. That is the animation the
     * owner asked for: the edge moves a pixel at a time, it does not jump. */
    const int q2 = 2 * (int)v->q[0];            /* 0..100 */
    const int st = q2 / 25;                     /* 0..4 */
    int p = PV_SEND_CHORUS_P[st];
    if (st < 4) {
        const int t = q2 - st * 25;
        p += pv_div_round((PV_SEND_CHORUS_P[st + 1] - PV_SEND_CHORUS_P[st]) * t, 25);
    }

    const int y0 = 2 * PV_SEND_CAP_T;
    const int y1 = 2 * PV_SEND_CAP_B;
    for (int y = PV_AREA_Y0; y <= PV_SEND_Y1; y++) {
        for (int x = PV_AREA_X0; x <= PV_SEND_X1; x++) {
            const int px = 2 * x + 1;
            const int py = 2 * y + 1;
            for (int c = 0; c < 2; c++) {
                const int x0 = 2 * (c == 0 ? PV_SEND_CAP_L : PV_SEND_CAP_L + p);
                const int x1 = 2 * (c == 0 ? PV_SEND_CAP_RT - p : PV_SEND_CAP_RT);
                const bool outer = pv_send_rr_in(px, py, x0, x1, y0, y1, 2 * PV_SEND_CAP_R);
                const bool inner = pv_send_rr_in(px, py, x0 + 4, x1 - 4, y0 + 4, y1 - 4,
                                                 2 * (PV_SEND_CAP_R - 2));
                if (outer && !inner) {
                    pv_px(m, x, y);
                    break;
                }
            }
        }
    }
}

/*
 * DELAY FEEDBACK. Nine bars on a five-pixel pitch, two pixels wide, laid outward from
 * the middle of the 44 x 44 area. Every bar is broken in the middle: a repeat is read
 * as the gap between the taps, and a solid comb would not say it.
 *
 * THE LADDER. The outer ends stand on 40 / 30 / 20 / 14 / 10 pixels and the ladder
 * slides outward with the knob — a bar d steps from the centre reaches full height on
 * the stage d + 3. Between the owner's six frames the ladder is interpolated, so a bar
 * grows a pixel at a time instead of jumping a rung, and the bars take turns: each
 * distance carries a small phase that is exactly zero on the frames themselves, which
 * is what keeps those six pictures pixel-exact while the motion between them stays
 * even rather than arriving in threes.
 *
 * THE GAPS. The centre bar parts from ten pixels to sixteen as the feedback passes the
 * second stage, its two neighbours hold a fixed six, everything further out is solid.
 * The part follows a smoothstep so the inner ends do not start and stop with a jolt.
 *
 * Integer arithmetic in hundredths of a pixel: the mask has no room for a float, and
 * the hundredths are what let the ladder be interpolated at all.
 */
#define PV_FB_BARS 9
#define PV_FB_PITCH 5
#define PV_FB_W 2
#define PV_FB_X0 1          /* the first bar's column inside the 44 x 44 area */
#define PV_FB_MID 22        /* the break sits between rows MID - h and MID - 1 + h */
#define PV_FB_GAP 5         /* half of the centre break at rest, in pixels */
#define PV_FB_GAP_HI 8      /* and at the top of the travel */
#define PV_FB_GAP_NEAR 3    /* the neighbouring bar's break, half, always */

/* Half-heights of the ladder: 10, 14, 20, 30 and 40 pixels across. */
static const uint8_t PV_FB_LADDER[5] = { 5, 7, 10, 15, 20 };

/* sin(pi * i / 10) x 100, i = 0..9 — the phase that makes the bars take turns. It is
 * zero at i = 0, which is exactly why the owner's six frames come out unchanged. */
static const uint8_t PV_FB_SIN10[10] = { 0, 31, 59, 81, 95, 100, 95, 81, 59, 31 };

/* The ladder at t hundredths of a pixel, linearly interpolated between the rungs. */
static int pv_fb_ladder(int t)
{
    if (t <= 0) {
        return PV_FB_LADDER[0] * 100;
    }
    if (t >= 400) {
        return PV_FB_LADDER[4] * 100;
    }
    const int i = t / 100;
    const int f = t % 100;
    return PV_FB_LADDER[i] * 100 + (PV_FB_LADDER[i + 1] - PV_FB_LADDER[i]) * f;
}

static void pv_delay_feedback(uint8_t *m, const pv_vals_t *v)
{
    /* k = 1 + q / 10: the six frames are the stages 1..6 and the knob's fifty steps
     * land a fifth of a stage apart, so the frame pictures are hit exactly. */
    const int q = v->q[0];
    const int k = 100 + 10 * q;                 /* hundredths of the stage */
    const int phase = PV_FB_SIN10[q % 10];

    for (int i = 0; i < PV_FB_BARS; i++) {
        const int d = i < 4 ? 4 - i : i - 4;

        /* The centre bar is the first tap: full height whatever the knob says. */
        int half = PV_FB_LADDER[4] * 100;
        if (d > 0) {
            int t = k - 100 * d + 100;                  /* t = k - d + 1 */
            t += (20 * phase * d) / 400;                /* this distance's turn */
            half = pv_fb_ladder(t);
            /* Below the first stage nothing but the centre has risen yet. */
            if (k < 200) {
                half = PV_FB_LADDER[0] * 100 +
                       (half - PV_FB_LADDER[0] * 100) * (k - 100) / 100;
            }
        }

        int gap = 0;
        if (d == 0) {
            int f = k - 200;
            if (f < 0) {
                f = 0;
            } else if (f > 100) {
                f = 100;
            }
            const int s = f * f * (300 - 2 * f) / 10000;    /* smoothstep, 0..100 */
            gap = PV_FB_GAP * 100 + (PV_FB_GAP_HI - PV_FB_GAP) * s * 100 / 100;
        } else if (d == 1) {
            gap = PV_FB_GAP_NEAR * 100;
        }

        const int h = (half + 50) / 100;
        const int g = (gap + 50) / 100;
        const int x = PV_AREA_X0 + PV_FB_X0 + i * PV_FB_PITCH;
        const int top0 = PV_AREA_Y0 + PV_FB_MID - h;
        const int top1 = PV_AREA_Y0 + PV_FB_MID - 1 - g;
        const int bot0 = PV_AREA_Y0 + PV_FB_MID + g;
        const int bot1 = PV_AREA_Y0 + PV_FB_MID - 1 + h;

        for (int y = top0; y <= top1; y++) {
            pv_px(m, x, y);
            pv_px(m, x + 1, y);
        }
        for (int y = bot0; y <= bot1; y++) {
            pv_px(m, x, y);
            pv_px(m, x + 1, y);
        }
    }
}

/*
 * REVERB SIZE. A box in isometric projection: the front face is a fixed 22 x 22 and
 * only the depth travels, from four pixels to twenty, so the box grows away from the
 * viewer while the face stays put — which is what a room getting longer looks like.
 *
 * THE FRAME IS CENTRED BY CONSTRUCTION. The picture spans 22 + depth and the depth is
 * always even, so the margins are whole pixels on both sides: the box cannot drift half
 * a pixel sideways as the knob moves, which at this size would read as a wobble.
 *
 * THE OUTLINE. The nine edges are two pixels thick on the axes and three on the
 * diagonals — a 45-degree stroke on this grid covers three columns a row, and the
 * owner's eight frames are built exactly that way, corner pixel included. This figure
 * is the one that matches his art down to the last pixel, so the arithmetic here is
 * deliberately literal: the same windows, the same clamps, nothing rounded.
 *
 * Depth comes from the knob on its own fifty-step grid, interpolated between his eight
 * stages and snapped to even; the intermediate values are the depths he did not draw,
 * eight, and they appear between his second and third frame.
 */
#define PV_RS_FACE 22
#define PV_RS_STAGES 8
#define PV_RS_AREA 44

/* The depths of his eight frames, in order. */
static const uint8_t PV_RS_DEPTH[PV_RS_STAGES] = { 4, 6, 10, 12, 14, 16, 18, 20 };

/* Depth for a knob at q of 0..50: seven gaps over the eight stages, snapped to even. */
static int pv_rs_depth(int q)
{
    const int x = q * 7;
    int i = x / 50;
    int d;

    if (i >= PV_RS_STAGES - 1) {
        d = PV_RS_DEPTH[PV_RS_STAGES - 1];
    } else {
        const int f = x % 50;
        d = PV_RS_DEPTH[i] + (PV_RS_DEPTH[i + 1] - PV_RS_DEPTH[i]) * f / 50;
    }

    d = (d + 1) & ~1;                   /* even, or the margins would be halves */
    if (d < PV_RS_DEPTH[0]) {
        d = PV_RS_DEPTH[0];
    } else if (d > PV_RS_DEPTH[PV_RS_STAGES - 1]) {
        d = PV_RS_DEPTH[PV_RS_STAGES - 1];
    }
    return d;
}

/* A row of the outline, clamped to the box's own frame. */
static void pv_rs_run(uint8_t *m, int xa, int xb, int y, int lo, int hi)
{
    if (xa < lo) {
        xa = lo;
    }
    if (xb > hi) {
        xb = hi;
    }
    for (int x = xa; x <= xb; x++) {
        pv_px(m, x, y);
    }
}

static void pv_rs_col(uint8_t *m, int x, int ya, int yb)
{
    for (int y = ya; y <= yb; y++) {
        pv_px(m, x, y);
    }
}

static void pv_verb_size(uint8_t *m, const pv_vals_t *v)
{
    const int d = pv_rs_depth(v->q[0]);
    const int off = (PV_RS_AREA - PV_RS_FACE - d) / 2;
    const int x0 = PV_AREA_X0 + off;
    const int y0 = PV_AREA_Y0 + off + d;
    const int x1 = x0 + PV_RS_FACE - 1;
    const int y1 = y0 + PV_RS_FACE - 1;
    const int hi_x = x1 + d;

    /* the front face */
    pv_rs_run(m, x0, x1, y0, x0, hi_x);
    pv_rs_run(m, x0, x1, y0 + 1, x0, hi_x);
    pv_rs_run(m, x0, x1, y1 - 1, x0, hi_x);
    pv_rs_run(m, x0, x1, y1, x0, hi_x);
    pv_rs_col(m, x0, y0, y1);
    pv_rs_col(m, x0 + 1, y0, y1);
    pv_rs_col(m, x1 - 1, y0, y1);
    pv_rs_col(m, x1, y0, y1);

    /* the far edges */
    pv_rs_run(m, x0 + d, x1 + d, y0 - d, x0, hi_x);
    pv_rs_run(m, x0 + d, x1 + d, y0 - d + 1, x0, hi_x);
    pv_rs_col(m, x1 + d - 1, y0 - d, y1 - d);
    pv_rs_col(m, x1 + d, y0 - d, y1 - d);

    /* the three diagonals: a three-wide window stepping one row at a time */
    for (int j = 0; j < d; j++) {
        pv_rs_run(m, x0 + 1 + j, x0 + 3 + j, y0 - 1 - j, x0, hi_x);
        pv_rs_run(m, x1 + j, x1 + 2 + j, y0 - 1 - j, x0, hi_x);
        pv_rs_run(m, x1 - 1 + j, x1 + 1 + j, y1 - 1 - j, x0, hi_x);
    }
    pv_px(m, x1 + 1, y0);               /* the corner the two top edges share */
}

/*
 * CHORUS DEPTH. Four rings of radius eleven and two pixels of stroke, sitting on the
 * cross — top, bottom, left and right of the middle. At zero they lie on top of each
 * other and read as one ring; as the knob turns they part along both axes, out to ten
 * pixels, and the single ring opens into a clover of four. That is the whole figure:
 * it is the distance between the rings, nothing else, which is what depth means here.
 *
 * THE MOTION IS IN HALF PIXELS. The spread is carried on the doubled grid and the rings
 * are tested with squared distances, so they travel a pixel at a time instead of
 * jumping two — the same arithmetic the chorus send figure uses, and the reason the
 * owner's five frames land on the ladder 0 / 4 / 6 / 8 / 10.
 */
#define PV_CD_R 22                  /* outer radius, doubled */
#define PV_CD_THICK 4               /* stroke, doubled */
#define PV_CD_STAGES 5

/* The spreads of his five frames, in pixels. */
static const uint8_t PV_CD_SPREAD[PV_CD_STAGES] = { 0, 4, 6, 8, 10 };

/* Spread in doubled pixels for a knob at q of 0..50. */
static int pv_cd_spread(int q)
{
    const int u = q * 8;            /* four gaps over the fifty steps */
    const int i = u / 100;
    const int f = u % 100;
    int num;

    if (i >= PV_CD_STAGES - 1) {
        return 2 * PV_CD_SPREAD[PV_CD_STAGES - 1];
    }
    num = 200 * PV_CD_SPREAD[i] + 2 * (PV_CD_SPREAD[i + 1] - PV_CD_SPREAD[i]) * f;
    return (num + 50) / 100;
}

static void pv_chorus_depth(uint8_t *m, const pv_vals_t *v)
{
    const int s2 = pv_cd_spread(v->q[0]);
    const int cx = 2 * PV_AREA_X0 + PV_AREA_W;      /* the middle of the 44 x 44 field */
    const int cy = 2 * PV_AREA_Y0 + PV_AREA_H;
    const int ox[4] = { 0, 0, -s2, s2 };
    const int oy[4] = { -s2, s2, 0, 0 };

    for (int y = 0; y < PV_AREA_H; y++) {
        const int py = 2 * (PV_AREA_Y0 + y) + 1;
        for (int x = 0; x < PV_AREA_W; x++) {
            const int px = 2 * (PV_AREA_X0 + x) + 1;
            for (int k = 0; k < 4; k++) {
                const int dx = px - (cx + ox[k]);
                const int dy = py - (cy + oy[k]);
                const int d2 = dx * dx + dy * dy;
                if (d2 <= PV_CD_R * PV_CD_R &&
                    d2 >= (PV_CD_R - PV_CD_THICK) * (PV_CD_R - PV_CD_THICK)) {
                    pv_px(m, PV_AREA_X0 + x, PV_AREA_Y0 + y);
                    break;
                }
            }
        }
    }
}

/*
 * CHORUS RATE. A chain of rounded rectangles, ONE WIDTH for the whole travel: twenty
 * pixels across, forty-two rows tall, two pixels of stroke, ends round. What the knob
 * moves is the pitch between their axes — twenty pixels at the slow end down to four at
 * the fast one — so the rectangles stand closer, overlap, and their arcs interleave into
 * a comb. The chain is wider than the field and is cut by it: the rectangles that do not
 * fit at one pitch come in from the edges at the next.
 *
 * THE WIDTH NEVER CHANGES. The owner's first five frames read as a chain that thins as
 * the rate rises; that was the wrong reading of his own art. The rectangles keep their
 * size, only the pitch travels, and the width is what makes the fast end read as a comb
 * of slots rather than a shrinking ladder.
 *
 * WHOLE PIXELS, OR THE FRAME STOPS MIRRORING. The chain is anchored so that the middle
 * rectangle's left wall falls on x = 11..12 of the field, with its right wall on 31..32:
 * the two mirror into each other, and so does every neighbour at a whole pitch. A
 * fractional pitch rounds the left wall one way and the right wall the other, and the
 * frame is visibly lopsided — the owner saw exactly that. Hence the integer pitch and the
 * step of one pixel: seventeen frames, twenty down to four.
 *
 * The pen is centred on the path, so a wall is two pixels: the rounded rectangle is the
 * outside of a path grown by one pixel minus the same path shrunk by one. Both tests are
 * squared distances on the doubled grid, so no drawing path here needs a square root.
 */
#define PV_CR_W 20                  /* width of the path, never changes */
#define PV_CR_R 10                  /* half the width: the ends are round */
#define PV_CR_TOP 2                 /* the path's top and bottom rows */
#define PV_CR_BOT 42
#define PV_CR_X 12                  /* the middle rectangle's left edge: its wall inks 11..12 */
#define PV_CR_P_FAST 4
#define PV_CR_STEPS 16              /* sixteen steps of one pixel: 20 .. 4 */

/* Pitch for a knob at q of 0..50: whole pixels, one at a time, no ties to round. */
static int pv_cr_pitch(int q)
{
    return PV_CR_P_FAST + ((50 - q) * PV_CR_STEPS + 25) / 50;
}

/* Is the pixel (x,y) inside the rounded rectangle [x0,x1) x [y0,y1) with radius r?
 * Coordinates are the pixel's top-left corner, so its centre is half a pixel in; the
 * whole test runs doubled to keep that half out of the arithmetic. */
static bool pv_cr_inside(int x, int y, int x0, int y0, int x1, int y1, int r)
{
    if (x < x0 || x >= x1 || y < y0 || y >= y1) {
        return false;
    }

    const int px = 2 * x + 1;
    const int py = 2 * y + 1;
    int cx = px;
    int cy = py;

    if (cx < 2 * (x0 + r)) {
        cx = 2 * (x0 + r);
    }
    if (cx > 2 * (x1 - r)) {
        cx = 2 * (x1 - r);
    }
    if (cy < 2 * (y0 + r)) {
        cy = 2 * (y0 + r);
    }
    if (cy > 2 * (y1 - r)) {
        cy = 2 * (y1 - r);
    }

    const int dx = px - cx;
    const int dy = py - cy;
    return dx * dx + dy * dy <= 4 * r * r;
}

/* The 44 x 44 field of the new figures, in the mask's own pixels. PV_AREA_W counts the
 * 2 x 2 blocks of the older brush and stops one short of the field's last column; a
 * figure that draws single pixels takes the field whole. */
#define PV_CR_FIELD 44

static void pv_chorus_rate(uint8_t *m, const pv_vals_t *v)
{
    const int p = pv_cr_pitch(v->q[0]);

    /* Enough rectangles each way for the fastest pitch: 12 * 4 is well past the field. */
    for (int k = -12; k <= 12; k++) {
        const int x0 = PV_CR_X + k * p;
        const int x1 = x0 + PV_CR_W;
        if (x1 < -1 || x0 > PV_CR_FIELD) {
            continue;
        }
        for (int y = 0; y < PV_CR_FIELD; y++) {
            for (int x = x0 - 2; x <= x1 + 1; x++) {
                if (x < 0 || x >= PV_CR_FIELD) {
                    continue;
                }
                if (!pv_cr_inside(x, y, x0 - 1, PV_CR_TOP - 1, x1 + 1, PV_CR_BOT + 1,
                                  PV_CR_R + 1)) {
                    continue;
                }
                if (pv_cr_inside(x, y, x0 + 1, PV_CR_TOP + 1, x1 - 1, PV_CR_BOT - 1,
                                 PV_CR_R - 1)) {
                    continue;
                }
                pv_px(m, PV_AREA_X0 + x, PV_AREA_Y0 + y);
            }
        }
    }
}

/*
 * SWING. A bar of sixteenths is five marks of two pixels in rows 2..19, and the box in rows
 * 24..41 is the straight ruler they are measured against: a two-pixel outline with its four
 * outer corners cut, and three ticks hanging from its top wall — the two side ones six rows
 * long, the middle one ten, so the box says where the beat and the half of the bar are.
 *
 * THE RULER NEVER MOVES. Every frame of the owner's sheet has the box identical to the last,
 * including its ticks; only the marks travel. That is the whole point of the figure: the eye
 * compares the marks against a fixed beat instead of watching a shape change size.
 *
 * THE MARKS. Mark j stands at ten j; every odd one sits late by d, and d runs 0..10 with the
 * knob. NO TWO MARKS MAY STAND CLOSER THAN SIX PIXELS: two two-pixel bars with less than two
 * pixels of air between them read as one thick bar, so a late mark PUSHES the next one right,
 * which pushes the next, and the row bunches up and slides out of the field at the far end.
 * That cascade is not an effect added on top — it is what the owner's six frames show, and it
 * is why the last pair leaves the picture at the top of the travel instead of merging.
 *
 * Eleven whole-pixel positions. A fractional step would put a mark between two columns and
 * the row would breathe by a pixel as the knob passed; the owner asked for whole pixels on the
 * rate figure for the same reason and this one has the same answer.
 */
#define PV_SW_STEP 10              /* distance between the marks at rest */
#define PV_SW_GAP 6                /* the closest two marks may stand */
#define PV_SW_DELAY 10             /* how far the odd mark is late at the top of the travel */
#define PV_SW_MARK_W 2
#define PV_SW_MARK_TOP 2
#define PV_SW_MARK_BOT 19
#define PV_SW_BOX_X0 1
#define PV_SW_BOX_X1 42
#define PV_SW_BOX_Y0 24
#define PV_SW_BOX_Y1 41
#define PV_SW_PEN 2
#define PV_SW_FIELD 44

static void pv_swing(uint8_t *m, const pv_vals_t *v)
{
    const int d = (v->q[0] * PV_SW_DELAY + 25) / 50;

    /* The ruler: an outline two pixels thick with the four outer corners left open. */
    for (int y = PV_SW_BOX_Y0; y <= PV_SW_BOX_Y1; y++) {
        for (int x = PV_SW_BOX_X0; x <= PV_SW_BOX_X1; x++) {
            const bool edge_x = (x < PV_SW_BOX_X0 + PV_SW_PEN) || (x > PV_SW_BOX_X1 - PV_SW_PEN);
            const bool edge_y = (y < PV_SW_BOX_Y0 + PV_SW_PEN) || (y > PV_SW_BOX_Y1 - PV_SW_PEN);
            if (!edge_x && !edge_y) {
                continue;
            }
            if ((x == PV_SW_BOX_X0 || x == PV_SW_BOX_X1) &&
                (y == PV_SW_BOX_Y0 || y == PV_SW_BOX_Y1)) {
                continue;
            }
            pv_px(m, PV_AREA_X0 + x, PV_AREA_Y0 + y);
        }
    }

    /* Its three ticks, hanging from under the top wall: beat, half, beat. */
    static const int tick_x[3] = { 11, 21, 31 };
    static const int tick_bot[3] = { 31, 35, 31 };
    for (int t = 0; t < 3; t++) {
        for (int y = PV_SW_BOX_Y0 + PV_SW_PEN; y <= tick_bot[t]; y++) {
            for (int i = 0; i < PV_SW_MARK_W; i++) {
                pv_px(m, PV_AREA_X0 + tick_x[t] + i, PV_AREA_Y0 + y);
            }
        }
    }

    /* The marks, pushed along by the one before them. */
    int prev = -100;
    for (int j = 0; j < 5; j++) {
        int x = PV_SW_STEP * j + ((j & 1) ? d : 0);
        if (x < prev + PV_SW_GAP) {
            x = prev + PV_SW_GAP;
        }
        prev = x;
        for (int y = PV_SW_MARK_TOP; y <= PV_SW_MARK_BOT; y++) {
            for (int i = 0; i < PV_SW_MARK_W; i++) {
                const int cx = x + 1 + i;
                if (cx >= 0 && cx < PV_SW_FIELD) {
                    pv_px(m, PV_AREA_X0 + cx, PV_AREA_Y0 + y);
                }
            }
        }
    }
}

/*
 * GROOVE. The written part drawn: sixteen steps on a 4 x 4 grid, ten pixels apart, the first
 * cell at (3,3), an eight-pixel glyph in each. The glyphs are the owner's, measured off his own
 * sample: a disc of radius four for the kick, a hollow diamond of the same reach for the snare,
 * a four-pixel square for the hat, a smaller hollow diamond for the tom and a two-pixel square
 * for the ghost hat.
 *
 * THE SNARE IS AN OUTLINE AND NOT A FILL. Filled, it sat next to the kick's disc as another
 * bright blob: at forty-four pixels the two were one shape with two silhouettes. Two pixels of
 * wall and a four-pixel hole make them different at a glance, and the outer edge is unchanged,
 * so the snare still lands where his drawing put it.
 *
 * ONE GLYPH PER CELL, THE HIGHEST: kick, then snare, then hat, then tom, then ghost. A cell is
 * ten pixels and an eight-pixel glyph, so two glyphs in one would not be two glyphs, they would
 * be a smudge. The order is the one the ear uses too — the loudest instrument of a step is the
 * one that says what the step is.
 *
 * TOM AND GHOST ARE DRAWN, and they are the reason the figure moves at all between the grooves
 * that share a kick and a snare: AFRO, LATIN, BOSSA, WOBBLE, SPLIT, DRILL put their difference
 * on the tom, and FUNK, HOUSE, TECHNO and CLUB on the ghost. A picture that dropped them would
 * draw two of those grooves identically.
 */
#define PV_GR_CELL 10              /* pitch of the step grid */
#define PV_GR_ORIGIN 3             /* the first cell's column and row */
#define PV_GR_GLYPH 8              /* the glyph is eight pixels in a ten-pixel cell */
#define PV_GR_FIELD 44

/* Half-pixel coordinates inside the cell, so a glyph can be centred between two columns. */
static int pv_gr_dx(int lx)
{
    return 2 * lx - 7;
}

/* The disc: radius four, squared to keep it in integers. */
static bool pv_gr_kick(int lx, int ly)
{
    const int dx = pv_gr_dx(lx);
    const int dy = pv_gr_dx(ly);
    return dx * dx + dy * dy <= 64;
}

/* The hollow diamond: |dx| + |dy| between the two reaches, both in half pixels. */
static bool pv_gr_diamond(int lx, int ly, int outer, int inner)
{
    const int d = (pv_gr_dx(lx) < 0 ? -pv_gr_dx(lx) : pv_gr_dx(lx)) +
                  (pv_gr_dx(ly) < 0 ? -pv_gr_dx(ly) : pv_gr_dx(ly));
    return d > inner && d <= outer;
}

/* The square, centred: four pixels for the hat, two for the ghost. */
static bool pv_gr_square(int lx, int ly, int half)
{
    return (lx >= 4 - half && lx <= 3 + half && ly >= 4 - half && ly <= 3 + half);
}

static void pv_gr_cell(uint8_t *m, int col, int row, int kind)
{
    const int gx = PV_GR_ORIGIN + col * PV_GR_CELL;
    const int gy = PV_GR_ORIGIN + row * PV_GR_CELL;

    for (int ly = 0; ly < PV_GR_GLYPH; ly++) {
        for (int lx = 0; lx < PV_GR_GLYPH; lx++) {
            bool lit = false;

            switch (kind) {
            case 0:                                     /* kick */
                lit = pv_gr_kick(lx, ly);
                break;
            case 1:                                     /* snare */
                lit = pv_gr_diamond(lx, ly, 8, 4);
                break;
            case 2:                                     /* hat */
                lit = pv_gr_square(lx, ly, 2);
                break;
            case 3:                                     /* tom */
                lit = pv_gr_diamond(lx, ly, 6, 2);
                break;
            case 4:                                     /* ghost hat */
                lit = pv_gr_square(lx, ly, 1);
                break;
            default:
                break;
            }

            if (lit) {
                pv_px(m, PV_AREA_X0 + gx + lx, PV_AREA_Y0 + gy + ly);
            }
        }
    }
}

static void pv_groove(uint8_t *m, const pv_vals_t *v)
{
    uint16_t lane[4];
    uint16_t ghost = 0;

    synth_app_groove_pattern((int)v->q[0], lane, &ghost);

    for (int s = 0; s < 16; s++) {
        const uint16_t bit = (uint16_t)(1u << s);
        int kind = -1;

        if (lane[0] & bit) {
            kind = 0;
        } else if (lane[1] & bit) {
            kind = 1;
        } else if (lane[2] & bit) {
            kind = 2;
        } else if (lane[3] & bit) {
            kind = 3;
        } else if (ghost & bit) {
            kind = 4;
        }

        if (kind >= 0) {
            pv_gr_cell(m, s % 4, s / 4, kind);
        }
    }
}

/*
 * FILL. The meter of how much of the part is filled, drawn in the same 4 x 4 grid as the groove
 * picture above, so the two sectors of the percussion page read as two views of one thing: this
 * one is the whole bar filling up, the other is what is written in it.
 *
 * A cell has four states — empty, a two-pixel square, a four-pixel square, a six-pixel square,
 * all three centred in the cell's own six-pixel box — and the queue starts at the LAST cell, the
 * bottom right one, and runs backwards through the reading order, the way the bar itself runs.
 *
 * THE RAMP IS THE POINT, and it is what his sample showed: each position of the knob raises one
 * cell at the front of the queue by one size, so three cells of three sizes stand behind the
 * front at all times. The alternative — filling each cell to a big square before touching the
 * next — draws one partial cell instead of two, and it is not what he drew: in his own picture a
 * medium square and a small one stand side by side.
 *
 * EIGHTEEN UNITS over the travel: sixteen cells plus the two steps of the ramp. The knob is 0..50,
 * so each unit spans about three positions — the figure is coarser than the knob on purpose, since
 * a cell is ten pixels and there is nothing honest between one size and the next.
 */
#define PV_FI_CELL 10              /* pitch of the cell grid, shared with the groove picture */
#define PV_FI_ORIGIN 4             /* the first cell's column and row */
#define PV_FI_BOX 6                /* the cell's own box; every size is centred in it */
#define PV_FI_LEVELS 3             /* small, medium, big */
#define PV_FI_CELLS 16
#define PV_FI_UNITS (PV_FI_CELLS + PV_FI_LEVELS - 1)

static void pv_fill(uint8_t *m, const pv_vals_t *v)
{
    const int units = ((int)v->q[0] * PV_FI_UNITS + 25) / 50;

    for (int k = 0; k < PV_FI_CELLS; k++) {
        int level = units - k;

        if (level <= 0) {
            /* The queue only gets emptier from here: every later cell is a step behind. */
            break;
        }
        if (level > PV_FI_LEVELS) {
            level = PV_FI_LEVELS;
        }

        const int s = PV_FI_CELLS - 1 - k;      /* backwards through the reading order */
        const int side = 2 * level;
        const int off = (PV_FI_BOX - side) / 2;
        const int x0 = PV_AREA_X0 + PV_FI_ORIGIN + (s % 4) * PV_FI_CELL + off;
        const int y0 = PV_AREA_Y0 + PV_FI_ORIGIN + (s / 4) * PV_FI_CELL + off;

        for (int y = 0; y < side; y++) {
            for (int x = 0; x < side; x++) {
                pv_px(m, x0 + x, y0 + y);
            }
        }
    }
}

/*
 * VAR. The tree the owner drew, growing from the bottom.
 *
 * THE GEOMETRY IS HIS, not invented: the trunk is a two-pixel column at x 21..22 from row 41 up to
 * row 33, every fork opens into a two-row bar with its lower corners cut by one pixel, every
 * branch and twig is two pixels wide, and the crown has eight twigs. At the top of the travel the
 * frame equals his drawing pixel for pixel, which is what tools/var-shape.py checks.
 *
 * THE GROWTH IS NOT A LEVEL SEQUENCE. Each branch has its own window of the travel, in thousandths:
 * it opens when its support has finished, plus its own pause, and it fills at its own speed. That is
 * what makes the figure look grown rather than assembled — and it is why the schedule below was
 * worked out once, in build/var-proto.py, instead of being recomputed on the panel: sixteen-bit
 * arithmetic per frame buys nothing.
 *
 * THE CENTRAL BRANCH LEADS. The owner asked for the side branches to trail further behind it, so
 * vLb — the inner branch on the left of the trunk — runs three times faster than the outer ones:
 * it is finished at 43 percent of the travel, the far left twig only at 83, and the last right-hand
 * twig exactly at the end. Every window still ends at one, so the full tree is the complete tree.
 */
#define PV_VR_ART 44

typedef struct {
    uint8_t  kind;     /* 0 — a branch, 1 — a bar */
    uint8_t  a;        /* the branch's column, or the bar's left end */
    uint8_t  b0;       /* the branch's bottom row, or the bar's upper row */
    uint8_t  b1;       /* the branch's top row, or the bar's right end */
    uint16_t start;    /* where in the travel this branch opens, thousandths */
    uint16_t end;      /* and where it has finished */
} pv_var_seg_t;

static const pv_var_seg_t s_var_segs[] = {
    { 0, 21, 41, 33,    0,  111 },   /* trunk  */
    { 1, 11, 31, 32,  111,  241 },   /* barA   */
    { 0, 11, 30, 23,  241,  323 },   /* vL     */
    { 0, 31, 30, 23,  242,  365 },   /* vR     */
    { 1,  5, 21, 17,  323,  391 },   /* barBL  */
    { 1, 26, 21, 38,  366,  448 },   /* barBR  */
    { 0,  5, 20, 13,  392,  572 },   /* vLa    */
    { 0, 16, 20, 13,  391,  429 },   /* vLb    */
    { 0, 26, 20, 13,  449,  548 },   /* vRa    */
    { 0, 37, 20, 13,  450,  648 },   /* vRb    */
    { 1,  1, 11, 10,  572,  665 },   /* barC1  */
    { 1, 13, 11, 20,  429,  453 },   /* barC2  */
    { 1, 23, 11, 30,  548,  594 },   /* barC3  */
    { 1, 33, 11, 42,  649,  750 },   /* barC4  */
    { 0,  1, 10,  2,  666,  825 },   /* t1     */
    { 0,  9, 10,  2,  667,  890 },   /* t2     */
    { 0, 13, 10,  2,  453,  506 },   /* t3     */
    { 0, 19, 10,  2,  453,  523 },   /* t4     */
    { 0, 23, 10,  2,  594,  695 },   /* t5     */
    { 0, 29, 10,  2,  595,  718 },   /* t6     */
    { 0, 33, 10,  2,  753, 1000 },   /* t7     */
    { 0, 41, 10,  2,  752,  937 },   /* t8     */
};

static void pv_var(uint8_t *m, const pv_vals_t *v)
{
    /* The knob is 0..50; the schedule is in thousandths, so one position is twenty. */
    const int t = (int)v->q[0] * 1000 / 50;

    for (size_t i = 0; i < sizeof(s_var_segs) / sizeof(s_var_segs[0]); i++) {
        const pv_var_seg_t *s = &s_var_segs[i];

        if (t <= (int)s->start) {
            continue;
        }

        /* Growth in 256ths, so a branch has whole pixels at every position of the knob. */
        int f = 256;

        if (t < (int)s->end) {
            f = (t - (int)s->start) * 256 / ((int)s->end - (int)s->start);
        }
        if (f <= 0) {
            continue;
        }

        if (s->kind == 0) {
            const int rows = s->b0 - s->b1 + 1;
            const int h = (f * rows + 128) / 256;
            const int x0 = PV_AREA_X0 + s->a;

            for (int y = s->b0 - h + 1; y <= s->b0; y++) {
                pv_px(m, x0, PV_AREA_Y0 + y);
                pv_px(m, x0 + 1, PV_AREA_Y0 + y);
            }
            continue;
        }

        /*
         * A bar opens from its middle outwards, in BOTH directions at once, which is why the
         * span is kept doubled: a bar between two odd columns has a half-pixel centre, and
         * rounding that to a whole pixel would make one arm lead the other.
         */
        const int c2 = s->a + s->b1;
        const int half2 = s->b1 - s->a;
        const int w = f * half2 / 256;
        const int lo = (c2 - w + 1) / 2;
        const int hi = (c2 + w) / 2;

        for (int x = lo; x <= hi; x++) {
            pv_px(m, PV_AREA_X0 + x, PV_AREA_Y0 + s->b0);
        }

        /*
         * The lower row is cut by a pixel at each end — the same chamfer his drawing has. A bar
         * only two pixels wide has nothing to cut: an inset row there would leave the bar
         * standing one pixel above its own support.
         */
        const int low_lo = (hi - lo >= 2) ? lo + 1 : lo;
        const int low_hi = (hi - lo >= 2) ? hi - 1 : hi;

        for (int x = low_lo; x <= low_hi; x++) {
            pv_px(m, PV_AREA_X0 + x, PV_AREA_Y0 + s->b0 + 1);
        }
    }
}

/*
 * TONE. The ring on a thread, mirrored and played backwards, as the owner asked.
 *
 * THE FOUR KNOTS ARE HIS FOUR FRAMES. He drew the ring small at the top and large at the bottom;
 * the figure wants it the other way round — large and hanging low at a low value, small and drawn
 * up at a high one — so the frames are read in reverse. Between the knots the diameter and the
 * top row run in a straight line, which is what makes the ring swell smoothly rather than step.
 *
 * THE RING IS ALWAYS SQUARE. It is centred between two columns, so its diameter must be even: an
 * odd diameter cannot sit on a half pixel and would leave the ring a pixel wider than it is tall,
 * with single pixels hanging off the sides. Rounding up to the next even number costs one step of
 * resolution and buys a shape that never wobbles.
 *
 * THE THREAD DOES NOT GO THROUGH. The inside of the ring is empty, so the thread is drawn only
 * outside it — that is how his frames are drawn, and it is what makes the ring read as a bubble
 * on a line rather than a bead with a line behind it.
 */
#define PV_TN_X 21          /* the thread's left column; it is two pixels wide */
#define PV_TN_STEM_TOP 2
#define PV_TN_STEM_BOT 41

typedef struct {
    uint16_t at;        /* where in the travel this knot sits, thousandths */
    uint8_t  size;      /* the ring's diameter there */
    uint8_t  top;       /* and the ring's top row */
} pv_tone_knot_t;

/* His four frames, in reverse: the big low ring at the bottom of the knob, the small high one
 * at the top. */
static const pv_tone_knot_t s_tone_knots[] = {
    {    0, 32, 11 },
    {  333, 22, 11 },
    {  667, 12, 11 },
    { 1000,  6,  4 },
};

/* which: 0 — the top row, 1 — the diameter. Rounded to the nearest whole pixel, halves away from
 * zero, so the image steps through the sizes evenly instead of lagging below each knot. */
static int pv_tone_between(int t, int which)
{
    const int n = (int)(sizeof(s_tone_knots) / sizeof(s_tone_knots[0]));

    for (int i = 0; i < n - 1; i++) {
        const int t0 = s_tone_knots[i].at;
        const int t1 = s_tone_knots[i + 1].at;

        if (t <= t1) {
            const int v0 = which ? s_tone_knots[i].size : s_tone_knots[i].top;
            const int v1 = which ? s_tone_knots[i + 1].size : s_tone_knots[i + 1].top;
            const int num = (v1 - v0) * (t - t0);
            const int den = t1 - t0;

            return v0 + (num >= 0 ? (num + den / 2) / den : -((-num + den / 2) / den));
        }
    }
    return which ? s_tone_knots[n - 1].size : s_tone_knots[n - 1].top;
}

static void pv_tone(uint8_t *m, const pv_vals_t *v)
{
    const int t = (int)v->q[0] * 1000 / 50;

    /* An even diameter: see the note over PREVIEW_TONE. */
    int d = pv_tone_between(t, 1);
    d += d & 1;

    const int high = pv_tone_between(t, 0);
    const int low = high + d - 1;

    /* Everything doubled, so the half-pixel centre stays exact and nothing ever rounds a pixel
     * off one side of the ring only. */
    const int cy2 = high + low;
    const int r2_out = d * d;
    const int r2_in = (d - 4) * (d - 4);

    for (int y = PV_TN_STEM_TOP; y <= PV_TN_STEM_BOT; y++) {
        const int dy2 = 2 * y - cy2;

        if (dy2 * dy2 <= r2_in) {
            continue;                   /* inside the ring: the thread is not drawn there */
        }
        pv_px(m, PV_AREA_X0 + PV_TN_X, PV_AREA_Y0 + y);
        pv_px(m, PV_AREA_X0 + PV_TN_X + 1, PV_AREA_Y0 + y);
    }

    for (int y = high; y <= low; y++) {
        const int dy2 = 2 * y - cy2;

        for (int x = PV_TN_X - d / 2; x <= PV_TN_X + 1 + d / 2; x++) {
            const int dx2 = 2 * x - 43;     /* 43 is twice the ring's centre column */
            const int dd = dx2 * dx2 + dy2 * dy2;

            if (dd <= r2_out && dd > r2_in) {
                pv_px(m, PV_AREA_X0 + x, PV_AREA_Y0 + y);
            }
        }
    }
}

/*
 * DECAY. One hit's envelope, drawn as the owner drew it: a floor, a left wall, a shelf and a
 * slope.
 *
 * THE SHELF IS THE KNOB and the slope is not. His four frames say so: read them in order and the
 * shelf runs 2, 12, 22, 32 columns while the slope is the same ten columns of thirty-seven rows
 * in every one of them — frames two, three and four agree column for column once shifted by ten.
 * So the gate lengthens by holding the hit longer, not by making it fall slower, and the slope
 * simply travels to the right. That is one line of arithmetic from 2 to 32 and no table.
 *
 * THE SLOPE'S STEP IS ROUNDED, NOT DRAWN BY BRESENHAM. His hand steps it four, four, four, four,
 * four, four, three, four rows on the way down; a clean integer line steps on a slightly
 * different pattern, which puts about ten pixels of his four frames a pixel away from this one.
 * The alternative — a table of his hand's steps — would repeat a wobble that no one can see at
 * forty-four pixels. tools/decay-shape.py holds the number.
 */
#define PV_DC_ART 44        /* the field the figure is drawn in */
#define PV_DC_BASE0 40      /* the floor: rows 40 and 41, the whole width */
#define PV_DC_BASE1 41
#define PV_DC_TOP0 1        /* the shelf: rows 1 and 2 */
#define PV_DC_WALL 1        /* the left wall: columns 1 and 2 */
#define PV_DC_WALL_BOT 39   /* the wall stands on the floor */
#define PV_DC_SLOPE0 3      /* the slope runs down rows 3..39 */
#define PV_DC_RUN 10        /* and across ten columns */
#define PV_DC_SPAN 37
#define PV_DC_SHELF_MIN 2   /* the shortest shelf: a hit that falls at once */

static void pv_perc_length(uint8_t *m, const pv_vals_t *v)
{
    /* The shelf, 2..32 columns: six per ten positions of the knob, rounded. */
    const int p = PV_DC_SHELF_MIN + (6 * (int)v->q[0] + 5) / 10;

    for (int x = 0; x < PV_DC_ART; x++) {
        pv_px(m, PV_AREA_X0 + x, PV_AREA_Y0 + PV_DC_BASE0);
        pv_px(m, PV_AREA_X0 + x, PV_AREA_Y0 + PV_DC_BASE1);
    }

    for (int y = PV_DC_TOP0; y <= PV_DC_WALL_BOT; y++) {
        pv_px(m, PV_AREA_X0 + PV_DC_WALL, PV_AREA_Y0 + y);
        pv_px(m, PV_AREA_X0 + PV_DC_WALL + 1, PV_AREA_Y0 + y);
    }

    for (int y = PV_DC_TOP0; y <= PV_DC_TOP0 + 1; y++) {
        for (int x = PV_DC_WALL; x <= p; x++) {
            pv_px(m, PV_AREA_X0 + x, PV_AREA_Y0 + y);
        }
    }

    for (int y = PV_DC_SLOPE0; y <= PV_DC_WALL_BOT; y++) {
        const int left = p - 1
            + ((y - PV_DC_SLOPE0) * PV_DC_RUN + PV_DC_SPAN / 2) / PV_DC_SPAN;

        pv_px(m, PV_AREA_X0 + left, PV_AREA_Y0 + y);
        pv_px(m, PV_AREA_X0 + left + 1, PV_AREA_Y0 + y);
    }
}

/*
 * PUNCH — the drum's attack, drawn as the four frames the owner drew.
 *
 * THE FOUR FRAMES ARE ONE POLYGON AT FOUR POSITIONS. Measured off his drawings, the ray
 * tips stand at the same radius in all of them (23.2, 23.2, 22.9, 22.9) and only the
 * notches between the rays get deeper — 20.5 to 11.5 across the axes and 22.2 to 3.8
 * across the diagonals. So the knob adds nothing and grows nothing: it cuts the ring into
 * ever deeper notches until only eight rays are left, which is why the picture reads as a
 * ring becoming a four-armed cross, then a six-armed star, then a burst.
 *
 * THE CORNERS. Sixteen of them: eight notches (four on the axes, four on the diagonals) and
 * eight ray tips, two per quadrant, at 26 and at 64 degrees, each with a flat cap. The four
 * numbers per knot are the two notch depths, the tip radius and the cap's half-width. The
 * angles are the same at every position, so the polygon never changes its topology and the
 * in-between frames are straight-sided rather than a wobble — the corner grid is what makes
 * the picture clean, and it is the reason the fit is exact at the first two knots.
 *
 * THE STROKE. Not a pen walked along the outline: a pen gives one pixel here and three
 * there, and on a diagonal it is a pixel and a half. The figure is drawn instead as the FILL
 * of the polygon with its own inward layer removed, which makes the width exactly what the
 * layer says. Two layers are needed and their kinds are not interchangeable, because a
 * diagonal edge moves in by 1.41 pixels per eight-neighbour layer and by 0.7 per
 * four-neighbour one: eight alone gives four pixels across a diagonal row where the owner's
 * hand gives three, four alone gives two where he gives three. One of each gives three on the
 * diagonals and two on the straight sides — two pixels of stroke along the normal, everywhere.
 *
 * The numbers are tenths, and the arithmetic is integer, so tools/punch-shape.py can run the
 * same sums and compare the result with the owner's four frames pixel for pixel.
 */
#define PV_PU_ART 44        /* the field, in pixels */
#define PV_PU_CENT 215      /* the centre, in tenths of a pixel: 21.5 */
#define PV_PU_TIP0 260      /* the ray tips, in tenths of a degree: 26.0 */
#define PV_PU_TIP1 640      /* and 64.0, the second of the pair inside a quadrant */
#define PV_PU_DIAG 450      /* the diagonal notch, in tenths of a degree */
#define PV_PU_QUAD 900      /* a quadrant, in tenths of a degree */
#define PV_PU_NV 24         /* corners: eight notches and eight ray tips, six per quadrant */
#define PV_PU_BYTES ((PV_PU_ART * PV_PU_ART + 7) / 8)

/*
 * The knots: their places on the 0..1000 travel. They are 320 and 660 rather than a third and
 * two thirds, because the figure is quantised to fifty positions — q * 20 — and a knot the
 * knob cannot land on is a knot the owner's frame is never drawn at. 320 is q = 16, 660 is
 * q = 33: the four frames are the four positions the hand can actually reach.
 */
#define PV_PU_T1 320
#define PV_PU_T2 660

/* The notches, in tenths of a pixel: across the axes and across the diagonals. */
#define PV_PU_A0 205
#define PV_PU_A1 205
#define PV_PU_A2 160
#define PV_PU_A3 115
#define PV_PU_D0 222
#define PV_PU_D1 154
#define PV_PU_D2 105
#define PV_PU_D3 38

/* The ray tips, in tenths of a pixel: the same reach at every position. */
#define PV_PU_R0 232
#define PV_PU_R1 232
#define PV_PU_R2 229
#define PV_PU_R3 229

/* The flat cap's half-width, in tenths of a degree: the rays blunt as they come out. */
#define PV_PU_S0 0
#define PV_PU_S1 10
#define PV_PU_S2 20
#define PV_PU_S3 25

/* Two bit fields of the field, for the fill and its eroded copy. */
static uint8_t s_pu_fill[PV_PU_BYTES];
static uint8_t s_pu_cut[PV_PU_BYTES];

static void pv_pu_put(uint8_t *g, int x, int y)
{
    const int bit = y * PV_PU_ART + x;
    g[bit >> 3] |= (uint8_t)(1u << (bit & 7));
}

static int pv_pu_at(const uint8_t *g, int x, int y)
{
    const int bit = y * PV_PU_ART + x;
    return (g[bit >> 3] >> (bit & 7)) & 1;
}

/* From one knot to the next, in tenths, rounded away from zero on both sides. */
static int pv_pu_mix(int pos, int t0, int t1, int a, int b)
{
    const int span = t1 - t0;
    const int num = (b - a) * (pos - t0);
    return a + (num + (num >= 0 ? span / 2 : -(span / 2))) / span;
}

/* One erode: a pixel survives only if its whole neighbourhood does. `eight` picks the
 * neighbourhood — the eight neighbours, or the four that share an edge. */
static void pv_pu_erode(const uint8_t *src, uint8_t *dst, int eight)
{
    memset(dst, 0, PV_PU_BYTES);

    for (int y = 0; y < PV_PU_ART; y++) {
        for (int x = 0; x < PV_PU_ART; x++) {
            if (!pv_pu_at(src, x, y)) {
                continue;
            }

            int keep = 1;
            for (int dy = -1; dy <= 1 && keep; dy++) {
                for (int dx = -1; dx <= 1 && keep; dx++) {
                    if (dx == 0 && dy == 0) {
                        continue;
                    }
                    if (!eight && dx != 0 && dy != 0) {
                        continue;
                    }

                    const int xx = x + dx;
                    const int yy = y + dy;
                    if (xx < 0 || xx >= PV_PU_ART || yy < 0 || yy >= PV_PU_ART
                        || !pv_pu_at(src, xx, yy)) {
                        keep = 0;
                    }
                }
            }

            if (keep) {
                pv_pu_put(dst, x, y);
            }
        }
    }
}

static void pv_punch(uint8_t *m, const pv_vals_t *v)
{
    const int t = (int)v->q[0] * 20;    /* 0..1000 */

    int a;
    int d;
    int r;
    int s;
    if (t <= PV_PU_T1) {
        a = pv_pu_mix(t, 0, PV_PU_T1, PV_PU_A0, PV_PU_A1);
        d = pv_pu_mix(t, 0, PV_PU_T1, PV_PU_D0, PV_PU_D1);
        r = pv_pu_mix(t, 0, PV_PU_T1, PV_PU_R0, PV_PU_R1);
        s = pv_pu_mix(t, 0, PV_PU_T1, PV_PU_S0, PV_PU_S1);
    } else if (t <= PV_PU_T2) {
        a = pv_pu_mix(t, PV_PU_T1, PV_PU_T2, PV_PU_A1, PV_PU_A2);
        d = pv_pu_mix(t, PV_PU_T1, PV_PU_T2, PV_PU_D1, PV_PU_D2);
        r = pv_pu_mix(t, PV_PU_T1, PV_PU_T2, PV_PU_R1, PV_PU_R2);
        s = pv_pu_mix(t, PV_PU_T1, PV_PU_T2, PV_PU_S1, PV_PU_S2);
    } else {
        a = pv_pu_mix(t, PV_PU_T2, 1000, PV_PU_A2, PV_PU_A3);
        d = pv_pu_mix(t, PV_PU_T2, 1000, PV_PU_D2, PV_PU_D3);
        r = pv_pu_mix(t, PV_PU_T2, 1000, PV_PU_R2, PV_PU_R3);
        s = pv_pu_mix(t, PV_PU_T2, 1000, PV_PU_S2, PV_PU_S3);
    }

    /* The corners in tenths of a pixel, in order round the figure: the notch on the axis,
     * the first tip with its flat cap, the notch on the diagonal, the second tip with its
     * cap, and then the same five in the next quadrant — six corners a quadrant, because the
     * axis notch is shared with the quadrant that starts there. */
    float vx[PV_PU_NV];
    float vy[PV_PU_NV];
    for (int q = 0; q < 4; q++) {
        const int deg[6] = {
            q * PV_PU_QUAD,
            q * PV_PU_QUAD + PV_PU_TIP0 - s,
            q * PV_PU_QUAD + PV_PU_TIP0 + s,
            q * PV_PU_QUAD + PV_PU_DIAG,
            q * PV_PU_QUAD + PV_PU_TIP1 - s,
            q * PV_PU_QUAD + PV_PU_TIP1 + s,
        };
        const int rad[6] = { a, r, r, d, r, r };

        for (int i = 0; i < 6; i++) {
            /* Tenths of a degree into radians: one degree is pi/180, so a tenth is pi/1800. */
            const float ang = (float)deg[i] * 3.14159265f / 1800.0f;
            vx[q * 6 + i] = (float)PV_PU_CENT + (float)rad[i] * cosf(ang);
            vy[q * 6 + i] = (float)PV_PU_CENT - (float)rad[i] * sinf(ang);
        }
    }

    /* The fill, by rows: the crossings of the row with the twenty-four sides, taken in pairs. */
    memset(s_pu_fill, 0, sizeof(s_pu_fill));
    for (int y = 0; y < PV_PU_ART; y++) {
        /* The row in the corners' own units — tenths — and not in pixels: the corners are in
         * tenths, and a row number compared against them fills nothing below the fourth row. */
        const float yc = (float)y * 10.0f;
        float xs[PV_PU_NV];
        int n = 0;

        for (int i = 0; i < PV_PU_NV; i++) {
            const int j = (i + 1) % PV_PU_NV;
            const float y0 = vy[i];
            const float y1 = vy[j];
            if (!((y0 <= yc && yc < y1) || (y1 <= yc && yc < y0))) {
                continue;
            }
            xs[n++] = vx[i] + (vx[j] - vx[i]) * (yc - y0) / (y1 - y0);
        }

        for (int i = 0; i + 1 < n; i++) {       /* four crossings, so an insertion sort is ample */
            for (int j = i + 1; j < n; j++) {
                if (xs[j] < xs[i]) {
                    const float tmp = xs[i];
                    xs[i] = xs[j];
                    xs[j] = tmp;
                }
            }
        }

        for (int i = 0; i + 1 < n; i += 2) {
            const int x0 = (int)ceilf(xs[i] * 0.1f);
            const int x1 = (int)floorf(xs[i + 1] * 0.1f);
            for (int x = x0; x <= x1; x++) {
                if (x >= 0 && x < PV_PU_ART) {
                    pv_pu_put(s_pu_fill, x, y);
                }
            }
        }
    }

    /* The stroke: the fill less its inward layer, one erode of each kind. */
    pv_pu_erode(s_pu_fill, s_pu_cut, 1);
    pv_pu_erode(s_pu_cut, s_pu_fill, 0);

    for (int y = 0; y < PV_PU_ART; y++) {
        for (int x = 0; x < PV_PU_ART; x++) {
            if (pv_pu_at(s_pu_fill, x, y)) {
                continue;
            }
            /* s_pu_fill now holds the twice-eroded fill, so the ink is what the cut layer
             * lost — that is, the pixels in s_pu_cut but no longer in s_pu_fill. */
            if (pv_pu_at(s_pu_cut, x, y)) {
                pv_px(m, PV_AREA_X0 + x, PV_AREA_Y0 + y);
            }
        }
    }
}

/*
 * TIMBRE. A comb of seven tines standing on an arch, which is the owner's own drawing: at the
 * minimum the tines are an even arc, at the maximum their lengths are scattered.
 *
 * The base is a formula and not his frame, because his hands disagree with themselves: the
 * arch in his two drawings is the same arch, but its left half is a pixel off its right half
 * in two places and two of its pixels sit a row away from the circle. A ring about the field's
 * own axis is even by construction, which is what the owner asked for after seeing the copy.
 *
 * Everything is in tenths of a pixel so that none of it depends on floating point: the centre
 * is (220, 420) tenths, which is the axis between columns 21 and 22 and the axis between rows
 * 41 and 42 — the two axes a field forty-four pixels wide actually has, since a pixel's centre
 * sits half a pixel in from its index — and the radii are 90 and 110, so the ring is two pixels
 * thick along the normal. The comparisons are on squared distances, which is exact.
 *
 * The tines never move except at the top: each one is cut off exactly where it meets the base
 * (PV_TI_BOT), so a tine cannot float in the air above the arch, and the two tables of tops
 * are the owner's two frames read column by column.
 */
#define PV_TI_ART 44
#define PV_TI_CX 220         /* tenths: the axis between columns 21 and 22 */
#define PV_TI_CY 420         /* tenths: the axis between rows 41 and 42 */
#define PV_TI_RIN2 8100      /* 90^2, inner radius */
#define PV_TI_ROUT2 12100    /* 110^2, outer radius */
#define PV_TI_X0 3           /* the first tine's left column */
#define PV_TI_STEP 6         /* and the distance between the tines */
#define PV_TI_N 7
#define PV_TI_FLOOR 41       /* the floor is two rows, 41 and 42 */
#define PV_TI_HOLE_X0 2      /* and it runs from column 2 to 41 */
#define PV_TI_HOLE_X1 41

/* The owner's two frames, read off his pictures: the tops of the seven tines. */
static const uint8_t s_ti_top_min[PV_TI_N] = { 13, 6, 3, 2, 3, 6, 13 };
static const uint8_t s_ti_top_max[PV_TI_N] = { 25, 12, 22, 7, 12, 2, 32 };

/* Where each tine stops, per column: the topmost pixel of the base beneath it. */
static const uint8_t s_ti_bottom[PV_TI_N][2] = {
    { 41, 41 },     /* x 3 and 4, on the floor */
    { 41, 41 },     /* x 9 and 10 */
    { 33, 32 },     /* x 15 and 16, on the arch's left wall */
    { 31, 31 },     /* x 21 and 22, on the crown */
    { 32, 33 },     /* x 27 and 28, on the arch's right wall */
    { 41, 41 },     /* x 33 and 34, on the floor */
    { 41, 41 },     /* x 39 and 40, on the floor */
};

/* A straight carry from a to b over the travel, rounded away from zero, as everywhere else. */
static int pv_ti_mix(int a, int b, int t)
{
    const int num = (b - a) * t;
    const int bias = (num >= 0) ? 500 : -500;
    return a + (num + bias) / 1000;
}

static void pv_timbre(uint8_t *m, const pv_vals_t *v)
{
    const int t = (int)v->q[0] * 20;

    /* The base: the floor with its notch, and the arch above it. */
    for (int y = 0; y < PV_TI_ART && y <= PV_TI_FLOOR + 1; y++) {
        const int dy = 10 * y + 5 - PV_TI_CY;
        for (int x = 0; x < PV_TI_ART; x++) {
            const int dx = 10 * x + 5 - PV_TI_CX;
            const int d2 = dx * dx + dy * dy;
            const int ring = (d2 >= PV_TI_RIN2 && d2 <= PV_TI_ROUT2);
            const int floor = (y >= PV_TI_FLOOR
                               && x >= PV_TI_HOLE_X0 && x <= PV_TI_HOLE_X1
                               && d2 >= PV_TI_RIN2);
            if (ring || floor) {
                pv_px(m, PV_AREA_X0 + x, PV_AREA_Y0 + y);
            }
        }
    }

    /* And the tines, each from its own top down to the base. */
    for (int i = 0; i < PV_TI_N; i++) {
        const int top = pv_ti_mix(s_ti_top_min[i], s_ti_top_max[i], t);
        for (int c = 0; c < 2; c++) {
            const int x = PV_TI_X0 + PV_TI_STEP * i + c;
            for (int y = top; y <= (int)s_ti_bottom[i][c]; y++) {
                pv_px(m, PV_AREA_X0 + x, PV_AREA_Y0 + y);
            }
        }
    }
}

/*
 * SCATTER: a diamond with stripes through it, which the owner drew as six frames — see the note
 * on PREVIEW_SEQ_SCATTER. The diamond is a ring of constant thickness about the field's own
 * axis; the stripes are the centre one plus two pairs, and a pair is invisible while its
 * half-distance is nought.
 *
 * All of it is integer, in tenths of a pixel. The diamond is the unit ball of the Manhattan
 * distance, so its level sets are rhombi and the ring between two of them has the same thickness
 * everywhere: |dx|/A + |dy|/B = 1 is the boundary, and multiplying through by A*B gives
 * |dx10|*B10 + |dy10|*A10 = A10*B10, which is exact.
 */
#define PV_SC_ART 44
#define PV_SC_CX 220         /* tenths: the axis between columns 21 and 22 */
#define PV_SC_CY 220         /* tenths: the axis between rows 21 and 22 */
#define PV_SC_A10 196        /* half-width, tenths */
#define PV_SC_B10 99         /* half-height, tenths */
#define PV_SC_FULL 19404     /* A10 * B10: the boundary itself */
#define PV_SC_LO 17208       /* the inner edge: two pixels of thickness along the normal */
#define PV_SC_HI 21601       /* the outer edge, those same two pixels on the other side */
#define PV_SC_AXIS 21        /* the diamond's axis: the upper arm of a stripe stops here */
#define PV_SC_Y0 2           /* and the arms run from row 2 to row 41 */
#define PV_SC_Y1 41
#define PV_SC_STEP 200       /* the travel is cut into five equal steps, one per his frame */

/* His six frames, read off: the half-distance of each pair at the five steps. */
static const uint8_t s_sc_h1[6] = { 0, 1, 4, 7, 11, 15 };
static const uint8_t s_sc_h2[6] = { 0, 0, 0, 1, 4, 6 };

/* Is this a pixel of the diamond? */
static int pv_sc_dia(int x, int y)
{
    const int dx = 10 * x + 5 - PV_SC_CX;
    const int dy = 10 * y + 5 - PV_SC_CY;
    const int f = (dx < 0 ? -dx : dx) * PV_SC_B10 + (dy < 0 ? -dy : dy) * PV_SC_A10;
    return (f >= PV_SC_LO && f <= PV_SC_HI);
}

/* A straight carry from a to b over one of the five steps, rounded away from zero. */
static int pv_sc_knot(const uint8_t *table, int t)
{
    int i = t / PV_SC_STEP;
    if (i > 4) {
        i = 4;
    }
    const int t0 = i * PV_SC_STEP;
    const int num = ((int)table[i + 1] - (int)table[i]) * (t - t0);
    const int bias = (num >= 0) ? (PV_SC_STEP / 2) : -(PV_SC_STEP / 2);
    return (int)table[i] + (num + bias) / PV_SC_STEP;
}

/*
 * One stripe. The upper arm runs from row 2 down to the diamond's axis; the lower one starts
 * where the stripe comes out from under the diamond's lower edge — the lowest diamond pixel in
 * that column — and runs to row 41. That is how it is in all six of his frames: inside the lower
 * half of the diamond the stripes are not drawn.
 */
static void pv_sc_stripe(uint8_t *m, int col)
{
    if (col < 0 || col >= PV_SC_ART) {
        return;
    }
    for (int y = PV_SC_Y0; y <= PV_SC_AXIS; y++) {
        pv_px(m, PV_AREA_X0 + col, PV_AREA_Y0 + y);
    }
    int bottom = -1;
    for (int y = PV_SC_ART - 1; y >= 0; y--) {
        if (pv_sc_dia(col, y)) {
            bottom = y;
            break;
        }
    }
    for (int y = (bottom < 0 ? PV_SC_AXIS + 1 : bottom); y <= PV_SC_Y1; y++) {
        pv_px(m, PV_AREA_X0 + col, PV_AREA_Y0 + y);
    }
}

static void pv_scatter(uint8_t *m, const pv_vals_t *v)
{
    const int t = (int)v->q[0] * 20;

    for (int y = 0; y < PV_SC_ART; y++) {
        for (int x = 0; x < PV_SC_ART; x++) {
            if (pv_sc_dia(x, y)) {
                pv_px(m, PV_AREA_X0 + x, PV_AREA_Y0 + y);
            }
        }
    }

    pv_sc_stripe(m, 21);
    pv_sc_stripe(m, 22);

    const int h[2] = { pv_sc_knot(s_sc_h1, t), pv_sc_knot(s_sc_h2, t) };
    for (int k = 0; k < 2; k++) {
        if (h[k] <= 0) {
            continue;                 /* a pair at zero lies on the centre stripe */
        }
        pv_sc_stripe(m, 21 - h[k]);
        pv_sc_stripe(m, 22 - h[k]);
        pv_sc_stripe(m, 21 + h[k]);
        pv_sc_stripe(m, 22 + h[k]);
    }
}

/*
 * THE TWELVE NOTE ICONS, converted from the owner's own 44 x 44 drawings the same way as the
 * oscillator and TRIG ones: one bit per pixel, MSB first, six bytes to a row, and what he drew
 * is what the screen shows. The order is the list's — C, C#, D, D#, E, F, F#, G, G#, A, A#, B —
 * which is the order the tonic is counted in: see seq_root_midi(), where index 0 is C and
 * index 11 is B.
 *
 * THE SET IS ONE FIGURE SEEN THROUGH TWELVE WINDOWS, and the windows are not the same size.
 * Each icon is a lattice — a rail at the top, a rail in the middle, a wall of keys between them,
 * and a foot below — but the width runs 26, 33, 38, 43, 44, 44, 44, 44, 43, 38, 33, 26 pixels
 * from C to B: it opens from C to E, stands at the full field from E to G, and closes again to B.
 * The anchoring is part of it: C, C#, D and D# hang on the right edge and grow leftwards, G#, A,
 * A# and B hang on the left edge and shrink rightwards. The figure therefore swings through the
 * field as the note rises, which is what the twelve icons say and what the slider prototype was
 * made to show.
 *
 * AN ICON IS CARRIED WHOLE. Nothing is computed and nothing is rounded: after the conversion
 * from his webp there is no arithmetic between his drawing and the mask, so all twelve are
 * pixel for pixel his. The one edit these ever took was his own — the wide key's foot, inset by
 * a pixel on each side so it leaves the bottom rail with rounded corners.
 */
static const uint8_t PV_NOTE_ICONS[12][44 * 6] = {
    {   /* C */
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x3F, 0xFF, 0xFF, 0xF0,
        0x00, 0x00, 0x3F, 0xFF, 0xFF, 0xF0,
        0x00, 0x00, 0x3E, 0x01, 0x80, 0x60,
        0x00, 0x00, 0x3E, 0x01, 0x80, 0x60,
        0x00, 0x00, 0x3E, 0x01, 0x80, 0x60,
        0x00, 0x00, 0x3E, 0x01, 0x80, 0x60,
        0x00, 0x00, 0x3E, 0x01, 0x80, 0x60,
        0x00, 0x00, 0x3E, 0x01, 0x80, 0x60,
        0x00, 0x00, 0x3E, 0x01, 0x80, 0x60,
        0x00, 0x00, 0x3E, 0x01, 0x80, 0x60,
        0x00, 0x00, 0x3E, 0x01, 0x80, 0x60,
        0x00, 0x00, 0x3E, 0x01, 0x80, 0x60,
        0x00, 0x00, 0x3E, 0x01, 0x80, 0x60,
        0x00, 0x00, 0x3E, 0x01, 0x80, 0x60,
        0x00, 0x00, 0x3E, 0x01, 0x80, 0x60,
        0x00, 0x00, 0x3E, 0x01, 0x80, 0x60,
        0x00, 0x00, 0x3E, 0x01, 0x80, 0x60,
        0x00, 0x00, 0x3E, 0x01, 0x80, 0x60,
        0x00, 0x00, 0x3F, 0x03, 0xC0, 0xE0,
        0x00, 0x00, 0x3F, 0xFF, 0xFF, 0xC0,
        0x00, 0x00, 0x3F, 0xFE, 0x7F, 0x80,
        0x00, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x00, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x00, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x00, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x00, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x00, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x00, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x00, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x00, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x00, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x00, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x00, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x00, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x00, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x00, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x00, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x00, 0x00, 0x3F, 0xC8, 0x1E, 0x00,
        0x00, 0x00, 0x1F, 0x9F, 0xFF, 0xF0,
        0x00, 0x00, 0x0F, 0x0F, 0xF3, 0xF0,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    },
    {   /* C# */
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x1F, 0x3F, 0xCF, 0xFF, 0xF0,
        0x00, 0x1F, 0x3F, 0xCF, 0xFF, 0xF0,
        0x00, 0x18, 0x3F, 0xC0, 0x0C, 0x60,
        0x00, 0x18, 0x3F, 0xC0, 0x0C, 0x60,
        0x00, 0x18, 0x3F, 0xC0, 0x0C, 0x60,
        0x00, 0x18, 0x3F, 0xC0, 0x0C, 0x60,
        0x00, 0x18, 0x3F, 0xC0, 0x0C, 0x60,
        0x00, 0x18, 0x3F, 0xC0, 0x0C, 0x60,
        0x00, 0x18, 0x3F, 0xC0, 0x0C, 0x60,
        0x00, 0x18, 0x3F, 0xC0, 0x0C, 0x60,
        0x00, 0x18, 0x3F, 0xC0, 0x0C, 0x60,
        0x00, 0x18, 0x3F, 0xC0, 0x0C, 0x60,
        0x00, 0x18, 0x3F, 0xC0, 0x0C, 0x60,
        0x00, 0x18, 0x3F, 0xC0, 0x0C, 0x60,
        0x00, 0x18, 0x3F, 0xC0, 0x0C, 0x60,
        0x00, 0x18, 0x3F, 0xC0, 0x0C, 0x60,
        0x00, 0x18, 0x3F, 0xC0, 0x0C, 0x60,
        0x00, 0x18, 0x3F, 0xC0, 0x0C, 0x60,
        0x00, 0x18, 0x3F, 0xC8, 0x1C, 0x60,
        0x00, 0x18, 0x1F, 0x9F, 0xF8, 0x60,
        0x00, 0x18, 0x0F, 0x0F, 0xF0, 0x60,
        0x00, 0x18, 0x00, 0x01, 0x80, 0x60,
        0x00, 0x18, 0x00, 0x01, 0x80, 0x60,
        0x00, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x00, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x00, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x00, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x00, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x00, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x00, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x00, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x00, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x00, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x00, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x00, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x00, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x00, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x00, 0x1C, 0x0F, 0x03, 0xC0, 0xF0,
        0x00, 0x0F, 0xFF, 0xFF, 0xFF, 0xF0,
        0x00, 0x07, 0xF9, 0xFE, 0x7F, 0x90,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    },
    {   /* D */
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x03, 0xFF, 0xFF, 0xFF, 0xFF, 0xF0,
        0x03, 0xFF, 0xFF, 0xFF, 0xFF, 0xF0,
        0x03, 0x18, 0x06, 0x01, 0x8C, 0x60,
        0x03, 0x18, 0x06, 0x01, 0x8C, 0x60,
        0x03, 0x18, 0x06, 0x01, 0x8C, 0x60,
        0x03, 0x18, 0x06, 0x01, 0x8C, 0x60,
        0x03, 0x18, 0x06, 0x01, 0x8C, 0x60,
        0x03, 0x18, 0x06, 0x01, 0x8C, 0x60,
        0x03, 0x18, 0x06, 0x01, 0x8C, 0x60,
        0x03, 0x18, 0x06, 0x01, 0x8C, 0x60,
        0x03, 0x18, 0x06, 0x01, 0x8C, 0x60,
        0x03, 0x18, 0x06, 0x01, 0x8C, 0x60,
        0x03, 0x18, 0x06, 0x01, 0x8C, 0x60,
        0x03, 0x18, 0x06, 0x01, 0x8C, 0x60,
        0x03, 0x18, 0x06, 0x01, 0x8C, 0x60,
        0x03, 0x18, 0x06, 0x01, 0x8C, 0x60,
        0x03, 0x18, 0x06, 0x01, 0x8C, 0x60,
        0x03, 0x18, 0x06, 0x01, 0x8C, 0x60,
        0x03, 0x1C, 0x0F, 0x03, 0x8C, 0x70,
        0x03, 0x0F, 0xFF, 0xFF, 0x0C, 0x30,
        0x03, 0x07, 0xFF, 0xFE, 0x0C, 0x10,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x81, 0x3F, 0xC8, 0x1E, 0x00,
        0x01, 0xFF, 0x9F, 0x9F, 0xFF, 0xF0,
        0x00, 0xFF, 0x0F, 0x0F, 0xF3, 0xF0,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    },
    {   /* D# */
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x7F, 0xFF, 0x3F, 0xCF, 0xFF, 0xF0,
        0x7F, 0xFF, 0x3F, 0xCF, 0xFF, 0xF0,
        0x63, 0x00, 0x3F, 0xC1, 0x8C, 0x00,
        0x63, 0x00, 0x3F, 0xC1, 0x8C, 0x00,
        0x63, 0x00, 0x3F, 0xC1, 0x8C, 0x00,
        0x63, 0x00, 0x3F, 0xC1, 0x8C, 0x00,
        0x63, 0x00, 0x3F, 0xC1, 0x8C, 0x00,
        0x63, 0x00, 0x3F, 0xC1, 0x8C, 0x00,
        0x63, 0x00, 0x3F, 0xC1, 0x8C, 0x00,
        0x63, 0x00, 0x3F, 0xC1, 0x8C, 0x00,
        0x63, 0x00, 0x3F, 0xC1, 0x8C, 0x00,
        0x63, 0x00, 0x3F, 0xC1, 0x8C, 0x00,
        0x63, 0x00, 0x3F, 0xC1, 0x8C, 0x00,
        0x63, 0x00, 0x3F, 0xC1, 0x8C, 0x00,
        0x63, 0x00, 0x3F, 0xC1, 0x8C, 0x00,
        0x63, 0x00, 0x3F, 0xC1, 0x8C, 0x00,
        0x63, 0x00, 0x3F, 0xC1, 0x8C, 0x00,
        0x63, 0x00, 0x3F, 0xC1, 0x8C, 0x00,
        0x63, 0x81, 0x3F, 0xC1, 0x8E, 0x00,
        0x61, 0xFF, 0x9F, 0x81, 0x87, 0xF0,
        0x60, 0xFF, 0x0F, 0x01, 0x83, 0xF0,
        0x60, 0x18, 0x00, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x00, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x70, 0x3C, 0x0F, 0x03, 0xC0, 0xF0,
        0x3F, 0xFF, 0xFF, 0xFF, 0xFF, 0xF0,
        0x1F, 0xE7, 0xF9, 0xFE, 0x7F, 0x90,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    },
    {   /* E */
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0xFF, 0xFF, 0xFF, 0xCF, 0xFF, 0xF0,
        0xFF, 0xFF, 0xFF, 0xCF, 0xFF, 0xF0,
        0x60, 0x18, 0x07, 0xC1, 0x80, 0x60,
        0x60, 0x18, 0x07, 0xC1, 0x80, 0x60,
        0x60, 0x18, 0x07, 0xC1, 0x80, 0x60,
        0x60, 0x18, 0x07, 0xC1, 0x80, 0x60,
        0x60, 0x18, 0x07, 0xC1, 0x80, 0x60,
        0x60, 0x18, 0x07, 0xC1, 0x80, 0x60,
        0x60, 0x18, 0x07, 0xC1, 0x80, 0x60,
        0x60, 0x18, 0x07, 0xC1, 0x80, 0x60,
        0x60, 0x18, 0x07, 0xC1, 0x80, 0x60,
        0x60, 0x18, 0x07, 0xC1, 0x80, 0x60,
        0x60, 0x18, 0x07, 0xC1, 0x80, 0x60,
        0x60, 0x18, 0x07, 0xC1, 0x80, 0x60,
        0x60, 0x18, 0x07, 0xC1, 0x80, 0x60,
        0x60, 0x18, 0x07, 0xC1, 0x80, 0x60,
        0x60, 0x18, 0x07, 0xC1, 0x80, 0x60,
        0x60, 0x18, 0x07, 0xC1, 0x80, 0x60,
        0x70, 0x3C, 0x0F, 0xC1, 0xC0, 0xF0,
        0x3F, 0xFF, 0xFF, 0xC0, 0xFF, 0xF0,
        0x1F, 0xE7, 0xFF, 0xC0, 0x7F, 0x90,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x07, 0x81, 0x3F, 0xC8, 0x1E, 0x00,
        0xFF, 0xFF, 0x9F, 0x9F, 0xFF, 0xF0,
        0xFC, 0xFF, 0x0F, 0x0F, 0xF3, 0xF0,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    },
    {   /* F */
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0xFF, 0xFF, 0x3F, 0xFF, 0xFF, 0xF0,
        0xFF, 0xFF, 0x3F, 0xFF, 0xFF, 0xF0,
        0x60, 0x18, 0x3E, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x3E, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x3E, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x3E, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x3E, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x3E, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x3E, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x3E, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x3E, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x3E, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x3E, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x3E, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x3E, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x3E, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x3E, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x3E, 0x01, 0x80, 0x60,
        0xF0, 0x38, 0x3F, 0x03, 0xC0, 0xF0,
        0xFF, 0xF0, 0x3F, 0xFF, 0xFF, 0xF0,
        0x9F, 0xE0, 0x3F, 0xFE, 0x7F, 0x90,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x07, 0x81, 0x3F, 0xC8, 0x1E, 0x00,
        0xFF, 0xFF, 0x9F, 0x9F, 0xFF, 0xF0,
        0xFC, 0xFF, 0x0F, 0x0F, 0xF3, 0xF0,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    },
    {   /* F# */
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0xFF, 0xFF, 0x3F, 0xCF, 0xFF, 0xF0,
        0xFF, 0xFF, 0x3F, 0xCF, 0xFF, 0xF0,
        0x03, 0x18, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x18, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x18, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x18, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x18, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x18, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x18, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x18, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x18, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x18, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x18, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x18, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x18, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x18, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x18, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x18, 0x3F, 0xC0, 0x0C, 0x00,
        0x07, 0x18, 0x3F, 0xC8, 0x1E, 0x00,
        0xFE, 0x18, 0x1F, 0x9F, 0xFF, 0xF0,
        0xFC, 0x18, 0x0F, 0x0F, 0xF3, 0xF0,
        0x60, 0x18, 0x00, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x00, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x60,
        0xF0, 0x3C, 0x0F, 0x03, 0xC0, 0xF0,
        0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xF0,
        0x9F, 0xE7, 0xF9, 0xFE, 0x7F, 0x90,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    },
    {   /* G */
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xF0,
        0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xF0,
        0x63, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x63, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x63, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x63, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x63, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x63, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x63, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x63, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x63, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x63, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x63, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x63, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x63, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x63, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x63, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x63, 0x18, 0x06, 0x01, 0x80, 0x60,
        0xE3, 0x1C, 0x0F, 0x03, 0xC0, 0xE0,
        0xC3, 0x0F, 0xFF, 0xFF, 0xFF, 0xC0,
        0x83, 0x07, 0xFF, 0xFE, 0x7F, 0x80,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x07, 0x81, 0x3F, 0xC8, 0x1E, 0x00,
        0xFF, 0xFF, 0x9F, 0x9F, 0xFF, 0xF0,
        0xFC, 0xFF, 0x0F, 0x0F, 0xF3, 0xF0,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    },
    {   /* G# */
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0xFF, 0xFF, 0x3F, 0xCF, 0xFF, 0xE0,
        0xFF, 0xFF, 0x3F, 0xCF, 0xFF, 0xE0,
        0x63, 0x00, 0x3F, 0xC0, 0x0C, 0x60,
        0x63, 0x00, 0x3F, 0xC0, 0x0C, 0x60,
        0x63, 0x00, 0x3F, 0xC0, 0x0C, 0x60,
        0x63, 0x00, 0x3F, 0xC0, 0x0C, 0x60,
        0x63, 0x00, 0x3F, 0xC0, 0x0C, 0x60,
        0x63, 0x00, 0x3F, 0xC0, 0x0C, 0x60,
        0x63, 0x00, 0x3F, 0xC0, 0x0C, 0x60,
        0x63, 0x00, 0x3F, 0xC0, 0x0C, 0x60,
        0x63, 0x00, 0x3F, 0xC0, 0x0C, 0x60,
        0x63, 0x00, 0x3F, 0xC0, 0x0C, 0x60,
        0x63, 0x00, 0x3F, 0xC0, 0x0C, 0x60,
        0x63, 0x00, 0x3F, 0xC0, 0x0C, 0x60,
        0x63, 0x00, 0x3F, 0xC0, 0x0C, 0x60,
        0x63, 0x00, 0x3F, 0xC0, 0x0C, 0x60,
        0x63, 0x00, 0x3F, 0xC0, 0x0C, 0x60,
        0x63, 0x00, 0x3F, 0xC0, 0x0C, 0x60,
        0x63, 0x81, 0x3F, 0xC8, 0x1C, 0x60,
        0x61, 0xFF, 0x9F, 0x9F, 0xF8, 0x60,
        0x60, 0xFF, 0x0F, 0x0F, 0xF0, 0x60,
        0x60, 0x18, 0x00, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x00, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x60,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x60,
        0xF0, 0x3C, 0x0F, 0x03, 0xC0, 0xE0,
        0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xC0,
        0x9F, 0xE7, 0xF9, 0xFE, 0x7F, 0x80,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    },
    {   /* A */
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0xFF, 0xFF, 0xFF, 0xFF, 0xFC, 0x00,
        0xFF, 0xFF, 0xFF, 0xFF, 0xFC, 0x00,
        0x60, 0x18, 0x06, 0x01, 0x8C, 0x00,
        0x60, 0x18, 0x06, 0x01, 0x8C, 0x00,
        0x60, 0x18, 0x06, 0x01, 0x8C, 0x00,
        0x60, 0x18, 0x06, 0x01, 0x8C, 0x00,
        0x60, 0x18, 0x06, 0x01, 0x8C, 0x00,
        0x60, 0x18, 0x06, 0x01, 0x8C, 0x00,
        0x60, 0x18, 0x06, 0x01, 0x8C, 0x00,
        0x60, 0x18, 0x06, 0x01, 0x8C, 0x00,
        0x60, 0x18, 0x06, 0x01, 0x8C, 0x00,
        0x60, 0x18, 0x06, 0x01, 0x8C, 0x00,
        0x60, 0x18, 0x06, 0x01, 0x8C, 0x00,
        0x60, 0x18, 0x06, 0x01, 0x8C, 0x00,
        0x60, 0x18, 0x06, 0x01, 0x8C, 0x00,
        0x60, 0x18, 0x06, 0x01, 0x8C, 0x00,
        0x60, 0x18, 0x06, 0x01, 0x8C, 0x00,
        0x60, 0x18, 0x06, 0x01, 0x8C, 0x00,
        0x70, 0x3C, 0x0F, 0x03, 0x8C, 0x00,
        0x3F, 0xFF, 0xFF, 0xFF, 0x0C, 0x00,
        0x1F, 0xE7, 0xFF, 0xFE, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x0C, 0x00,
        0x07, 0x81, 0x3F, 0xC8, 0x1C, 0x00,
        0xFF, 0xFF, 0x9F, 0x9F, 0xF8, 0x00,
        0xFC, 0xFF, 0x0F, 0x0F, 0xF0, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    },
    {   /* A# */
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0xFF, 0xFF, 0x3F, 0xCF, 0x80, 0x00,
        0xFF, 0xFF, 0x3F, 0xCF, 0x80, 0x00,
        0x03, 0x00, 0x3F, 0xC1, 0x80, 0x00,
        0x03, 0x00, 0x3F, 0xC1, 0x80, 0x00,
        0x03, 0x00, 0x3F, 0xC1, 0x80, 0x00,
        0x03, 0x00, 0x3F, 0xC1, 0x80, 0x00,
        0x03, 0x00, 0x3F, 0xC1, 0x80, 0x00,
        0x03, 0x00, 0x3F, 0xC1, 0x80, 0x00,
        0x03, 0x00, 0x3F, 0xC1, 0x80, 0x00,
        0x03, 0x00, 0x3F, 0xC1, 0x80, 0x00,
        0x03, 0x00, 0x3F, 0xC1, 0x80, 0x00,
        0x03, 0x00, 0x3F, 0xC1, 0x80, 0x00,
        0x03, 0x00, 0x3F, 0xC1, 0x80, 0x00,
        0x03, 0x00, 0x3F, 0xC1, 0x80, 0x00,
        0x03, 0x00, 0x3F, 0xC1, 0x80, 0x00,
        0x03, 0x00, 0x3F, 0xC1, 0x80, 0x00,
        0x03, 0x00, 0x3F, 0xC1, 0x80, 0x00,
        0x03, 0x00, 0x3F, 0xC1, 0x80, 0x00,
        0x07, 0x81, 0x3F, 0xC1, 0x80, 0x00,
        0xFF, 0xFF, 0x9F, 0x81, 0x80, 0x00,
        0xFC, 0xFF, 0x0F, 0x01, 0x80, 0x00,
        0x60, 0x18, 0x00, 0x01, 0x80, 0x00,
        0x60, 0x18, 0x00, 0x01, 0x80, 0x00,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x00,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x00,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x00,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x00,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x00,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x00,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x00,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x00,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x00,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x00,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x00,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x00,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x00,
        0x60, 0x18, 0x06, 0x01, 0x80, 0x00,
        0xF0, 0x3C, 0x0F, 0x03, 0x80, 0x00,
        0xFF, 0xFF, 0xFF, 0xFF, 0x00, 0x00,
        0x9F, 0xE7, 0xF9, 0xFE, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    },
    {   /* B */
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0xFF, 0xFF, 0xFF, 0xC0, 0x00, 0x00,
        0xFF, 0xFF, 0xFF, 0xC0, 0x00, 0x00,
        0x60, 0x18, 0x07, 0xC0, 0x00, 0x00,
        0x60, 0x18, 0x07, 0xC0, 0x00, 0x00,
        0x60, 0x18, 0x07, 0xC0, 0x00, 0x00,
        0x60, 0x18, 0x07, 0xC0, 0x00, 0x00,
        0x60, 0x18, 0x07, 0xC0, 0x00, 0x00,
        0x60, 0x18, 0x07, 0xC0, 0x00, 0x00,
        0x60, 0x18, 0x07, 0xC0, 0x00, 0x00,
        0x60, 0x18, 0x07, 0xC0, 0x00, 0x00,
        0x60, 0x18, 0x07, 0xC0, 0x00, 0x00,
        0x60, 0x18, 0x07, 0xC0, 0x00, 0x00,
        0x60, 0x18, 0x07, 0xC0, 0x00, 0x00,
        0x60, 0x18, 0x07, 0xC0, 0x00, 0x00,
        0x60, 0x18, 0x07, 0xC0, 0x00, 0x00,
        0x60, 0x18, 0x07, 0xC0, 0x00, 0x00,
        0x60, 0x18, 0x07, 0xC0, 0x00, 0x00,
        0x60, 0x18, 0x07, 0xC0, 0x00, 0x00,
        0xF0, 0x3C, 0x0F, 0xC0, 0x00, 0x00,
        0xFF, 0xFF, 0xFF, 0xC0, 0x00, 0x00,
        0x9F, 0xE7, 0xFF, 0xC0, 0x00, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x00, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x00, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x00, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x00, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x00, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x00, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x00, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x00, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x00, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x00, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x00, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x00, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x00, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x00, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x00, 0x00,
        0x03, 0x00, 0x3F, 0xC0, 0x00, 0x00,
        0x07, 0x81, 0x3F, 0xC0, 0x00, 0x00,
        0xFF, 0xFF, 0x9F, 0x80, 0x00, 0x00,
        0xFC, 0xFF, 0x0F, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    },
};

/* The NOTE list is twelve icons and no figure: the knob names the tonic, so the picture is his
 * drawing of that tonic and the number beside it says the same in a word. */
static void pv_note(uint8_t *m, const pv_vals_t *v)
{
    pv_icon(m, PV_NOTE_ICONS[v->q[0]]);
}

static int pv_ox_for(synth_preview_kind_t kind)
{
    switch (kind) {
    case PREVIEW_FILTER:
    case PREVIEW_LEAD_FILTER:
    case PREVIEW_COMP:            /* the bars are laid on the mask itself */
    case PREVIEW_DUCK:            /* the bars and the balls are laid on the mask itself */
    case PREVIEW_DENSITY:         /* the rings are laid on the mask themselves */
    case PREVIEW_SWEEP:
    case PREVIEW_ACCENT:      /* the step cells are placed on the mask itself */
    case PREVIEW_DELAY_FEEDBACK:  /* the bars are laid on the mask itself */
    case PREVIEW_VERB_SIZE:       /* the box is placed on the mask itself */
    case PREVIEW_CHORUS_DEPTH:    /* the rings are placed on the mask itself */
    case PREVIEW_CHORUS_RATE:     /* the chain is placed on the mask itself */
    case PREVIEW_SWING:           /* the ruler is placed on the mask itself */
    case PREVIEW_GROOVE:          /* the bar is placed on the mask itself */
    case PREVIEW_FILL:            /* the meter is placed on the mask itself */
    case PREVIEW_VAR:             /* the tree is placed on the mask itself */
    case PREVIEW_TONE:            /* the ring is placed on the mask itself */
    case PREVIEW_PERC_LENGTH:     /* the envelope is placed on the mask itself */
    case PREVIEW_PUNCH:           /* the polygon is placed on the mask itself */
    case PREVIEW_PERC_TIMBRE:     /* the comb is placed on the mask itself */
    case PREVIEW_SEQ_SCATTER:     /* the diamond is placed on the mask itself */
    case PREVIEW_DELAY_MODE:      /* the icons are carried whole, frame and all */
    case PREVIEW_NOTE:            /* the icons are carried whole, frame and all */
    case PREVIEW_VERB_DAMP:       /* the rings are placed on the mask itself */
    case PREVIEW_VERB_MODE:       /* the icons are carried whole, frame and all */
    case PREVIEW_LEAD_FENV_SHAPE: /* the triangle is placed on the field's own axes */
    case PREVIEW_LEAD_VOICE:      /* the strokes are placed on the field's own axes */
    case PREVIEW_VERB_SECTOR:   /* the section figures place themselves */
    case PREVIEW_DELAY_SECTOR:
    case PREVIEW_CHORUS_SECTOR:
    case PREVIEW_LFO_MIC:       /* the comb and the rope are placed on the mask itself */
        return 0;
    default:
        return 4;
    }
}

static int pv_oy_for(synth_preview_kind_t kind)
{
    (void)kind;
    return 0;
}

void synth_preview_mask(synth_param_t param, uint8_t *mask)
{
    pv_vals_t v;
    const synth_preview_kind_t kind = pv_values(param, &v);

    memset(mask, 0, SYNTH_PREVIEW_BYTES);
    s_pv_oy = pv_oy_for(kind);
    s_pv_ox = pv_ox_for(kind);

    /* Поворот RATE пересобирает расклад случайной фигуры; DEPTH её не трогает —
     * он только меняет размах. */
    if (param == SYNTH_PARAM_MOTION_RATE || param == SYNTH_PARAM_FILTER_RATE) {
        s_pv_seed += 0x9E3779B9u;
    }

    switch (kind) {
    case PREVIEW_ENV:       pv_env(mask, &v);       break;
    case PREVIEW_FILTER:    pv_filter(mask, &v);    break;
    case PREVIEW_COMP:      pv_comp(mask, &v);      break;
    case PREVIEW_WAVE:      pv_wave(mask, &v);      break;
    case PREVIEW_DELAY:     pv_delay(mask, &v);     break;
    case PREVIEW_VERB_DAMP: pv_verb_damp(mask, &v); break;
    case PREVIEW_VERB_MODE: pv_verb_mode(mask, &v); break;
    case PREVIEW_LEAD_FILTER: pv_lead_filter(mask, &v); break;
    case PREVIEW_LEAD_ENV:  pv_lead_env(mask, &v);  break;
    case PREVIEW_LEAD_FENV_SHAPE: pv_lead_fenv_shape(mask, &v); break;
    case PREVIEW_LEAD_VOICE: pv_lead_voice(mask, &v); break;
    case PREVIEW_LEAD_GATE:  pv_lead_gate(mask, &v);  break;
    case PREVIEW_LEAD_PORTA: pv_lead_porta(mask, &v); break;
    case PREVIEW_LFO:       pv_lfo(mask, &v);       break;
    case PREVIEW_RATE:
    case PREVIEW_MOD_DEPTH: pv_lfo(mask, &v);       break;
    case PREVIEW_TRIG:      pv_trig(mask, &v);      break;
    case PREVIEW_DELAY_MODE: pv_delay_mode(mask, &v); break;
    case PREVIEW_DELAY_SYNC: pv_delay_sync(mask, &v); break;
    case PREVIEW_CHORUS:    pv_chorus(mask, &v);    break;
    case PREVIEW_DUCK:      pv_duck(mask, &v);      break;
    case PREVIEW_DENSITY:   pv_density(mask, &v);   break;
    case PREVIEW_FOLLOW:    pv_follow(mask, &v);    break;
    case PREVIEW_LFO_MIC:   pv_lfo_mic(mask, &v);   break;
    case PREVIEW_WIDTH:     pv_width(mask, &v);     break;
    case PREVIEW_ACCENT:    pv_accent(mask, &v);    break;
    case PREVIEW_VERB_SECTOR:   pv_send_verb(mask, &v);   break;
    case PREVIEW_DELAY_SECTOR:  pv_send_delay(mask, &v);  break;
    case PREVIEW_CHORUS_SECTOR: pv_send_chorus(mask, &v); break;
    case PREVIEW_DELAY_FEEDBACK: pv_delay_feedback(mask, &v); break;
    case PREVIEW_VERB_SIZE:     pv_verb_size(mask, &v);  break;
    case PREVIEW_CHORUS_DEPTH:  pv_chorus_depth(mask, &v); break;
    case PREVIEW_CHORUS_RATE:   pv_chorus_rate(mask, &v); break;
    case PREVIEW_SWING:         pv_swing(mask, &v); break;
    case PREVIEW_GROOVE:        pv_groove(mask, &v); break;
    case PREVIEW_FILL:          pv_fill(mask, &v); break;
    case PREVIEW_VAR:           pv_var(mask, &v); break;
    case PREVIEW_TONE:          pv_tone(mask, &v); break;
    case PREVIEW_PERC_LENGTH:   pv_perc_length(mask, &v); break;
    case PREVIEW_PUNCH:         pv_punch(mask, &v); break;
    case PREVIEW_PERC_TIMBRE:   pv_timbre(mask, &v); break;
    case PREVIEW_SEQ_SCATTER:   pv_scatter(mask, &v); break;
    case PREVIEW_NOTE:          pv_note(mask, &v); break;
    case PREVIEW_PERC_PITCH: pv_perc_pitch(mask, &v); break;
    case PREVIEW_PERC_QUANT: pv_perc_quant(mask, &v); break;
    case PREVIEW_PERC_DECAY: pv_perc_decay(mask, &v); break;
    case PREVIEW_PERC_BODY: pv_perc_body(mask, &v); break;
    case PREVIEW_PERC_ENV:  pv_perc_env(mask, &v);  break;
    case PREVIEW_ARP:       pv_arp(mask, &v);       break;
    case PREVIEW_SWEEP:     pv_sweep(mask, &v);     break;
    default:                                        break;
    }

}

/*
 * Paint the lit bits.
 *
 * The per-frame cost, so it is kept as plain as it looks: per row, the mask byte
 * is loaded once and shifted, and a lit bit is one store. This is measurably the
 * fastest of the three shapes tried on the instrument (135 us for the full frame
 * as it was measured — 50 x 56 then, 56 x 56 now — against 167 us for a run-fill
 * and 203 us for a branchless load-modify-store): the branch is not mispredicted
 * often, because a curve leaves most of each row empty, and the store is only
 * issued for a pixel that is really ink.
 *
 * The rectangle is clipped to the mask once at the top; nothing below tests a
 * coordinate again. The band the caller passes is already the mask's ink rows,
 * so the rows scanned are the rows that can have anything on them.
 */
void synth_preview_blit(const uint8_t *mask, uint16_t *dst, int stride_px,
                        int mx, int my, int w, int h, uint16_t colour)
{
    if (dst == NULL || mask == NULL || stride_px <= 0 || w <= 0 || h <= 0) {
        return;
    }

    /* `my` is the mask row the dst pointer starts at, so the loop runs from it and
     * the buffer row is counted from it. `y` is therefore the ABSOLUTE mask row in
     * both the mask index and the screen row — the two must not disagree: a partial
     * refresh hands this function one 16-row strip at a time, and a strip that
     * started at 0 while the buffer row was `y - my` would read the mask past its
     * end and write above its own box. */
    int y0 = my < 0 ? 0 : my;
    int y1 = my + h;
    if (y1 > SYNTH_PREVIEW_H) {
        y1 = SYNTH_PREVIEW_H;
    }
    int x0 = mx < 0 ? 0 : mx;
    int x1 = mx + w;
    if (x1 > SYNTH_PREVIEW_W) {
        x1 = SYNTH_PREVIEW_W;
    }
    if (x0 >= x1 || y0 >= y1) {
        return;
    }

    for (int y = y0; y < y1; y++) {
        uint16_t *row = dst + (size_t)(y - my) * (size_t)stride_px;
        const int out = x0 - mx;

        /* Walk whole bytes of the row and visit only the set bits: a picture is
         * mostly holes, and a branch per dark pixel is what made the first
         * version cost 140 us. The mask is a continuous bit stream, so a row can
         * start in the middle of a byte. */
        const int bitpos = y * SYNTH_PREVIEW_W + x0;
        const uint8_t *mb = mask + (bitpos >> 3);
        int shift = bitpos & 7;
        int left = x1 - x0;
        int done = 0;

        while (left > 0) {
            uint8_t bits = *mb++;
            if (shift != 0) {
                bits &= (uint8_t)(0xFFu >> shift);
            }
            int take = 8 - shift;
            if (take > left) {
                take = left;
                bits &= (uint8_t)(0xFFu << (8 - take));
            }
            while (bits != 0) {
                const int p = 31 - __builtin_clz((unsigned)bits);
                const int k = done + 7 - p - shift;
                row[out + k] = colour;
                bits &= (uint8_t)~(1u << p);
            }
            left -= take;
            done += take;
            shift = 0;
        }
    }
}

