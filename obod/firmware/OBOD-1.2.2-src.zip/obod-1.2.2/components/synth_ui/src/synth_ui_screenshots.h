/*
 * The page table, as four questions, for the one file that needs to walk it.
 *
 * synth_ui.c owns PAGES[...] and the page turn; screenshots.c takes the pages as images for
 * the documentation and has no business knowing either. The two are in the same component and
 * the answers are three lines each, so this is a private header in src/ rather than an
 * addition to the public synth_ui.h — nothing outside the component gets to switch pages.
 *
 * Compiled only with CONFIG_OBOD_SCREENSHOTS; see screenshots.c for what it is for.
 */
#pragma once

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Start the walk, in a task of its own. Called at the end of synth_ui_build(), which is
 * itself under the LVGL lock: the task waits for the first frame and then holds that lock for
 * the whole walk, so it cannot be a call from there.
 */
void screenshots_start(void);

/* How many pages the instrument has: PAGE_COUNT, the swipe order. */
int synth_ui_page_count(void);

/* The name of a page by its number — the text in the middle of the dial, and the log line. */
const char *synth_ui_page_title(int idx);

/* Open a page by its number: goto_page(), slide animation and all. Needs the LVGL lock. */
void synth_ui_page_show(int idx);

/* Turn LVGL's timers for a while, so the slide animation that goto_page() starts runs to its
 * end. Needs the LVGL lock, which is what makes this the only thing advancing them. */
void synth_ui_page_pump(uint32_t ms);

/*
 * The states that are not pages: the two layers a swipe opens, and the two macro states a
 * long press and a double tap make. Each one is the very call the gesture itself makes —
 * nav_open() and transport_open() for the layers, sector_activate(idx, true) and
 * sector_invert(idx) for the macro — so the frame is the interface's own work and not a
 * redrawing of it. The hide calls are the same pair run backwards, and they are what puts
 * the instrument back the way it was found.
 */
void synth_ui_drawer_show(void);
void synth_ui_drawer_hide(void);
void synth_ui_transport_show(void);
void synth_ui_transport_hide(void);

/* Macro membership by knob number on the CURRENT page, the long press's own path. */
void synth_ui_macro_toggle(int knob);

/* The double tap's path: turns a member around. Does nothing on a non-member, as there. */
void synth_ui_macro_invert(int knob);

/* How many parameters ride the macro. The walk reads it before it builds anything and
 * again after it has taken it apart, so that it can say in the log that it left nothing. */
int synth_ui_macro_count(void);

/*
 * The arpeggiator, for the one page that is published in two states: with the arp running and
 * without it. The switch is DIR's own first position, so what the frame shows is the same
 * machinery the page's controls drive — see the comment above the implementations in
 * synth_ui.c. The walk puts back the value it found, so nothing is left behind.
 */
int synth_ui_arp_page(void);
float synth_ui_arp_get(void);
void synth_ui_arp_put(float dir01);

/* The value of DIR that runs the arp: UP, the second of its eight positions. */
float synth_ui_arp_on_value(void);

#ifdef __cplusplus
}
#endif
