/*
 * Screen snapshots for the documentation.
 *
 * This file is compiled only when CONFIG_OBOD_SCREENSHOTS is set, and the CMakeLists does not
 * even name it otherwise: a normal release carries none of this, not even as dead code.
 *
 * What it does, once, a few seconds after the interface is up: walks the instrument's pages in
 * PAGES[] order, lets each transition settle, takes the page as an image, and writes it to the
 * port the logs go to — a header line, then the frame in base64, then a terminator. Each page
 * looks like this, and nothing else appears between the header and the terminator:
 *
 *     @@SHOT 3 LEAD 360 360 259200
 *     <base64, 76 characters to the line>
 *     @@END
 *
 * After the last page come the states that are not pages at all — the drawer and the transport
 * screen the swipes open, and two macro states — each one opened by the very call the gesture or
 * the long press makes, so that what is published is the interface's own work. Then @@DONE, and
 * the instrument carries on as usual. tools/screens.ps1 on the computer reads that stream and
 * turns it into the PNGs in web/assets/screens/.
 *
 * Five decisions worth knowing before changing anything here.
 *
 * THE SNAPSHOT DRAWS INTO OUR OWN BUFFER, in PSRAM. A 360x360 RGB565 frame is 259 200 bytes,
 * which is not something LVGL's allocator may be able to find in internal RAM on demand. The
 * buffer is allocated once, before the walk, and reused for every page.
 * lv_snapshot_take_to_draw_buf() is what the older lv_snapshot_take_to_buf() forwards to in
 * this version of LVGL — same "render into a buffer I provide" call, without the deprecation
 * warning.
 *
 * THE BUFFER IS LARGER THAN THE SCREEN, AND THE FRAME IS CROPPED OUT OF IT. A snapshot covers
 * the object's area grown by its ext draw size, which on a screen whose children carry shadows
 * is a margin on all four sides. The screen's own top-left corner therefore sits at (ext, ext)
 * inside the buffer, and that is the corner the dump reads from; taking the margin along would
 * have put a border of leftover memory around every published image. The margin has to be
 * allowed for before the snapshot is taken but is only known to LVGL, and the getter lives in a
 * private header this build does not have (LV_USE_PRIVATE_API is off). So the buffer is set up
 * generously, the snapshot reshapes it to the true size, and the margin is measured back out of
 * the reshaped buffer afterwards — the number the crop uses is the one the snapshot itself
 * used, not a guess.
 *
 * THE FRAME GOES OUT RAW. Base64 of RGB565 is 346 KB per page and needs no compressor and no
 * image library on the device — the PNG is made on the computer, where Pillow costs a pip
 * install and the instrument's 2.6 ms control budget is not at stake.
 *
 * THE WRITES GO THROUGH THE USB-SERIAL-JTAG DRIVER, NOT THROUGH stdout. The console is fanned
 * out to UART0 as its primary and to the USB port as its secondary (see esp_stdio), so a
 * printf would push all 7.6 MB of the walk through UART0 at 115200 baud as well: eleven
 * minutes instead of well under one. The driver's writes block until the ring buffer takes the
 * bytes, which is what keeps the stream intact, and the VFS is switched to the driver so the
 * console's own writes queue in the same place instead of racing it at the register level.
 *
 * THE WHOLE WALK HOLDS THE LVGL LOCK. The port's task takes the same recursive lock around
 * lv_timer_handler(), so with it held nothing else draws, reads the knob or changes pages
 * while a frame is being taken — and, because that is also the lock the timers need, the pump
 * below is the single thing advancing the slide animation. The instrument is frozen for the
 * duration; the sound is not, and goes on as it was.
 *
 * A run in full: the flag on, tools/screens.ps1 reading COM4, the board flashed. The script
 * resets the board and waits, and everything below happens by itself.
 */
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "esp_heap_caps.h"
#include "esp_log.h"

#include "driver/usb_serial_jtag.h"
#include "driver/usb_serial_jtag_vfs.h"

#include "lvgl.h"

#include "bsp/bsp.h"

#include "app_settings.h"
#include "synth_app.h"
#include "synth_ui_screenshots.h"

#define SHOT_TAG "screenshots"

/*
 * Bytes of a frame that fit in one base64 line. 57 bytes are exactly 76 characters, which is
 * what the reader expects and what RFC 2045 asks for; the last line of a frame is short and
 * padded with '='.
 */
#define SHOT_LINE_IN 57

/*
 * How long a page is given after the switch. PAGE_SLIDE_MS in synth_ui.c is 200 ms and the
 * timers carrying the slide are only advanced by the pump below, so this is that, plus room
 * for the first refresh of the new page and for anything a page does on arrival. Half a
 * second more than the animation is deliberate: a page that arrived without being drawn is
 * the one failure this file cannot detect from the inside.
 */
#define SHOT_SETTLE_MS 600

/*
 * How long a layer is given after it is opened. The map and the transport screen slide for
 * NAV_SLIDE_MS, 220 ms, and the map lays its tiles out as it arrives, so a frame taken on the
 * slide would be a picture of the animation. Four times the slide is that, with room to spare.
 */
#define SHOT_LAYER_SETTLE_MS 900

/*
 * After a macro member is added or turned around. refresh_macro() redraws the sectors and the
 * arcs in place, so this is only the next refresh coming round, with room to spare.
 */
#define SHOT_MACRO_SETTLE_MS 400

/*
 * The page the macro states are taken on: DRONE, the first page, five knobs on one dial. The
 * task asks for a page where the marks are unmistakable, and five sectors of one family's blue
 * carrying the macro's orange-red — the fill of the ring sectors along with the border on the
 * tiles — is that page.
 */
#define SHOT_MACRO_PAGE 0

/* How many frames come out of the walk besides the pages: the EUCLID page with the
 * arpeggiator switched off, the two layers and the two macro states. */
#define SHOT_EXTRA_FRAMES 5

/*
 * Slack on the buffer. lv_draw_buf_init() may align the pointer it is handed, and the crop
 * reads a frame out of the middle of the buffer, so the allocation has to be the whole
 * rectangle plus whatever those two things need.
 */
#define SHOT_BUF_SLACK 512

/*
 * Ceiling on the screen's ext draw size while the buffer is being set up. The snapshot grows
 * the frame by that size on every side (see lv_snapshot.c) and the buffer must already be big
 * enough when the call is made, but LVGL keeps the number in a private header. The shadows and
 * outlines in this interface are far below this ceiling; a page that ever grew past it would
 * fail the reshape and be reported as one that would not render, rather than be cropped wrong.
 */
#define SHOT_EXT_MAX 128

/*
 * How long one write may block for. Long past any real stall in the ring buffer, short enough
 * that a cable pulled out mid-walk ends the run instead of hanging until the board is reset.
 */
#define SHOT_WRITE_TIMEOUT_MS 5000

/*
 * The wait before the walk starts. The task is created while the interface is being built, and
 * the first frame is drawn after that, by the LVGL task's next turn.
 *
 * Eight seconds rather than three, and the extra time is for the computer, not the instrument:
 * a reset through this port makes the chip enumerate its USB serial device again, and the host
 * needs a moment to notice the device has gone and come back before it can reopen the port and
 * listen. The walk starts once, so a reader that arrives late sees nothing at all.
 */
#define SHOT_START_DELAY_MS 8000

/* The task's own stack: LVGL's software renderer does a fair amount of work on it. */
#define SHOT_TASK_STACK 8192

/* Below the LVGL task, so it keeps the interface alive while the flow is set up. */
#define SHOT_TASK_PRIORITY 3

static const char SHOT_B64[] =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

/*
 * One write, all of it or nothing. usb_serial_jtag_write_bytes() returns how much of the
 * buffer the ring took and the rest has to be offered again; a zero means the wait ran out and
 * the stream is already broken, so the walk stops rather than publishing a half frame.
 */
static bool shot_write(const void *data, size_t len)
{
    const uint8_t *p = (const uint8_t *)data;

    while (len > 0) {
        const int n = usb_serial_jtag_write_bytes(p, len, pdMS_TO_TICKS(SHOT_WRITE_TIMEOUT_MS));
        if (n <= 0) {
            return false;
        }
        p += n;
        len -= (size_t)n;
    }

    return true;
}

static bool shot_puts(const char *text)
{
    return shot_write(text, strlen(text));
}

/* A line of the protocol. Every one of them is far shorter than the buffer. */
static bool shot_line(const char *fmt, ...)
{
    char line[128];
    va_list args;

    va_start(args, fmt);
    vsnprintf(line, sizeof(line), fmt, args);
    va_end(args);

    return shot_puts(line);
}

/*
 * 57 bytes in, 76 characters and a newline out. Called with a short block for the last line of
 * a frame, where the tail is padded.
 */
static void shot_b64(const uint8_t *in, size_t n, char *out)
{
    int o = 0;

    for (size_t i = 0; i < n; i += 3) {
        const uint32_t a = in[i];
        const uint32_t b = (i + 1 < n) ? in[i + 1] : 0;
        const uint32_t c = (i + 2 < n) ? in[i + 2] : 0;
        const uint32_t v = (a << 16) | (b << 8) | c;

        out[o++] = SHOT_B64[(v >> 18) & 0x3F];
        out[o++] = SHOT_B64[(v >> 12) & 0x3F];
        out[o++] = (i + 1 < n) ? SHOT_B64[(v >> 6) & 0x3F] : '=';
        out[o++] = (i + 2 < n) ? SHOT_B64[v & 0x3F] : '=';
    }

    out[o++] = '\n';
    out[o] = '\0';
}

/*
 * The port, as the driver sees it rather than as the console does.
 *
 * usb_serial_jtag_is_driver_installed() is false in this configuration: the USB port is the
 * secondary console here, and only the primary one installs the driver. Installing it is the
 * supported thing to do while the console is running — the VFS tests for the driver on every
 * write — and use_driver() is what makes the console's own writes go through the same ring.
 *
 * The receive buffer is sized but unused; the driver refuses a zero.
 */
static bool shot_port_open(void)
{
    if (!usb_serial_jtag_is_driver_installed()) {
        usb_serial_jtag_driver_config_t cfg = USB_SERIAL_JTAG_DRIVER_CONFIG_DEFAULT();
        cfg.tx_buffer_size = 4096;
        cfg.rx_buffer_size = 256;

        if (usb_serial_jtag_driver_install(&cfg) != ESP_OK) {
            return false;
        }
    }

    usb_serial_jtag_vfs_use_driver();
    return true;
}

/*
 * One frame off the live screen: the header, the rows, the terminator.
 *
 * Returns NULL when the whole frame went out and the reason when it did not, which is the same
 * contract the port helpers keep, so the walk decides what to do about it in one place.
 *
 * Row by row, and only the screen's own bytes out of each: a draw buffer may carry stride
 * padding at the end of a line, and the reader is told to expect exactly w * h * 2 bytes, so
 * padding must not travel. The frame starts one ext draw size in, both ways — that is the
 * margin the snapshot placed around the screen, measured from the buffer it just reshaped.
 */
static const char *shot_frame(lv_obj_t *scr, lv_draw_buf_t *buf, int32_t w, int32_t h,
                              uint32_t frame_bytes, int index, const char *name)
{
    const uint32_t row_bytes = (uint32_t)w * 2;

    /* Black under the frame: whatever the snapshot does not paint then reads as the
     * instrument's own background instead of the state before this one. Only the rows the
     * buffer actually covers, so a padded stride cannot run past the allocation. */
    memset(buf->data, 0, (size_t)buf->header.stride * buf->header.h);

    if (lv_snapshot_take_to_draw_buf(scr, LV_COLOR_FORMAT_RGB565, buf) != LV_RESULT_OK) {
        return "a state would not render";
    }

    if (!shot_line("@@SHOT %d %s %d %d %u\n", index, name, (int)w, (int)h,
                   (unsigned)frame_bytes)) {
        return "the port stopped taking writes";
    }

    const int32_t ext = (int32_t)((buf->header.w - (uint32_t)w) / 2);
    const uint8_t *base = (const uint8_t *)buf->data +
                          (size_t)ext * buf->header.stride + (size_t)ext * 2;
    char line[SHOT_LINE_IN / 3 * 4 + 2];

    for (int32_t y = 0; y < h; y++) {
        const uint8_t *row = base + (size_t)y * buf->header.stride;

        for (uint32_t x = 0; x < row_bytes; x += SHOT_LINE_IN) {
            size_t n = row_bytes - x;
            if (n > SHOT_LINE_IN) {
                n = SHOT_LINE_IN;
            }

            shot_b64(row + x, n, line);
            if (!shot_puts(line)) {
                return "the port stopped taking writes";
            }
        }
    }

    if (!shot_puts("@@END\n")) {
        return "the port stopped taking writes";
    }

    return NULL;
}

/*
 * The walk.
 *
 * Everything the reader is told comes out of this function in one stream: the header of a
 * page, its frame, the terminator, and @@DONE at the end. Whatever goes wrong — no buffer, no
 * lock, a page that would not render, a cable that went away — ends the stream without
 * @@DONE, which is how tools/screens.ps1 tells "not finished" from "finished", and the reason
 * the reason itself is logged only after the log level has been put back.
 */
static void shot_task(void *arg)
{
    (void)arg;

    vTaskDelay(pdMS_TO_TICKS(SHOT_START_DELAY_MS));

    if (!bsp_display_lock(0)) {
        ESP_LOGE(SHOT_TAG, "no LVGL lock, no snapshots");
        vTaskDelete(NULL);
        return;
    }

    /*
     * Nothing but this file's lines may appear between a header and its terminator, and the
     * instrument's other tasks keep logging while the walk runs: the audio task, the network
     * task and this component's own timers all write to the same port. The default level
     * covers every tag that has not been set explicitly, which is all of them; the explicit
     * per-tag levels are left alone and the default is put back at the end.
     */
    const esp_log_level_t logs = esp_log_level_get("*");
    esp_log_level_set("*", ESP_LOG_NONE);

    const char *why = NULL;

    lv_obj_t *scr = lv_screen_active();
    lv_obj_update_layout(scr);

    const int32_t w = lv_obj_get_width(scr);
    const int32_t h = lv_obj_get_height(scr);
    const uint32_t row_bytes = (uint32_t)w * 2;
    const uint32_t frame_bytes = row_bytes * (uint32_t)h;
    const int32_t wide = w + 2 * SHOT_EXT_MAX;
    const int32_t tall = h + 2 * SHOT_EXT_MAX;
    const size_t need = (size_t)wide * (size_t)tall * 2 + SHOT_BUF_SLACK;

    /* PSRAM rather than the internal heap: this is a quarter of a megabyte, and the display's
     * own buffers and the audio path both live in what is left. */
    uint8_t *raw = heap_caps_aligned_alloc(64, need, MALLOC_CAP_SPIRAM);
    if (raw == NULL) {
        why = "no PSRAM for the frame";
    }
    else if (!shot_port_open()) {
        why = "the USB serial port refused the driver";
    }

    lv_draw_buf_t buf;
    if (why == NULL &&
        lv_draw_buf_init(&buf, (uint32_t)wide, (uint32_t)tall,
                         LV_COLOR_FORMAT_RGB565, LV_STRIDE_AUTO, raw, (uint32_t)need) != LV_RESULT_OK) {
        why = "the draw buffer would not take the frame";
    }

    /*
     * PRESET is the one page whose picture is the store rather than the layout: an instrument
     * that has never saved a sound draws an empty list, and the frame would show the page but
     * say nothing about what a preset list looks like. The capture build therefore fills an
     * empty bank with four sounds of its own before the walk, through the same two calls the
     * RND button makes — so the names and the sounds in the frame are real presets, not a
     * drawing. A bank that already has something in it is left alone, and none of this code
     * ships: the file is compiled only with CONFIG_OBOD_SCREENSHOTS.
     */
    if (app_settings_preset_count() == 0) {
        for (int i = 0; i < 4; i++) {
            synth_app_random_draw(i == 3 ? 1 : 0, 0);
            synth_app_preset_save(i);
        }
        synth_ui_page_pump(SHOT_SETTLE_MS);
    }

    const int pages = synth_ui_page_count();
    const int frames = pages + SHOT_EXTRA_FRAMES;
    int sent = 0;
    int macro_before = -1;   /* what the walk found, for the log at the end */
    int macro_after = -1;    /* what it left behind */

    /*
     * The page the arpeggiator's plaque lives on is shot twice: once with the arp running, which
     * is the state the sentence ARP IS ACTIVE is there for, and once with it switched off, where
     * the figure shows through. Both frames come from here rather than from the states below, so
     * that the switch is on the device for exactly these two and no other page can see it; the
     * value the walk found is put back before the page is left.
     *
     * The second frame goes out under the page's own name and a suffix, because the reader
     * matches labels and this one is not a page: tools/lib/screens.js names its file.
     */
    const int arp_page = synth_ui_arp_page();
    float arp_was = 0.0f;
    bool arp_switched = false;

    for (int i = 0; why == NULL && i < pages; i++) {
        synth_ui_page_show(i);
        synth_ui_page_pump(SHOT_SETTLE_MS);

        if (i == arp_page) {
            arp_was = synth_ui_arp_get();
            synth_ui_arp_put(synth_ui_arp_on_value());
            synth_ui_page_pump(SHOT_SETTLE_MS);
            arp_switched = true;
        }

        why = shot_frame(scr, &buf, w, h, frame_bytes, i, synth_ui_page_title(i));
        if (why == NULL) {
            sent++;
        }

        if (arp_switched) {
            char name[40];

            synth_ui_arp_put(0.0f);
            synth_ui_page_pump(SHOT_SETTLE_MS);

            snprintf(name, sizeof name, "%s ARP OFF", synth_ui_page_title(arp_page));
            if (why == NULL) {
                why = shot_frame(scr, &buf, w, h, frame_bytes, sent, name);
                if (why == NULL) {
                    sent++;
                }
            }

            synth_ui_arp_put(arp_was);
            synth_ui_page_pump(SHOT_SETTLE_MS);
            arp_switched = false;
        }
    }

    /*
     * The states that are not pages: the two layers a swipe opens and the two macro states.
     *
     * Each is opened by the very call the gesture itself makes — synth_ui_drawer_show() is
     * nav_open() and synth_ui_macro_toggle() is the long press's sector_activate(idx, true) —
     * and each is left to settle before the frame is taken, because both of them move: the map
     * slides in and lays its tiles out, and the count in the middle of the dial grows as the
     * macro does.
     *
     * The macro is then taken apart the same way it was built, and the count before and after
     * goes into the log that is printed once the level is back. Nothing here writes a setting:
     * the membership is RAM only, so "nothing left behind" is a fact about the device and not
     * about a store this file has to remember to clear.
     */
    if (why == NULL) {
        synth_ui_drawer_show();
        synth_ui_page_pump(SHOT_LAYER_SETTLE_MS);

        why = shot_frame(scr, &buf, w, h, frame_bytes, sent, "DRAWER");
        if (why == NULL) {
            sent++;
        }

        synth_ui_drawer_hide();
        synth_ui_page_pump(SHOT_SETTLE_MS);
    }

    if (why == NULL) {
        synth_ui_transport_show();
        synth_ui_page_pump(SHOT_LAYER_SETTLE_MS);

        why = shot_frame(scr, &buf, w, h, frame_bytes, sent, "TRANSPORT");
        if (why == NULL) {
            sent++;
        }

        synth_ui_transport_hide();
        synth_ui_page_pump(SHOT_SETTLE_MS);
    }

    if (why == NULL) {
        synth_ui_page_show(SHOT_MACRO_PAGE);
        synth_ui_page_pump(SHOT_SETTLE_MS);

        macro_before = synth_ui_macro_count();

        synth_ui_macro_toggle(0);
        synth_ui_macro_toggle(1);
        synth_ui_macro_toggle(2);
        synth_ui_page_pump(SHOT_MACRO_SETTLE_MS);

        why = shot_frame(scr, &buf, w, h, frame_bytes, sent, "MACRO");
        if (why == NULL) {
            sent++;

            /* One member turned around: the double tap, marks and all. */
            synth_ui_macro_invert(1);
            synth_ui_page_pump(SHOT_MACRO_SETTLE_MS);

            why = shot_frame(scr, &buf, w, h, frame_bytes, sent, "MACRO INV");
            if (why == NULL) {
                sent++;
            }

            synth_ui_macro_invert(1);
        }

        synth_ui_macro_toggle(0);
        synth_ui_macro_toggle(1);
        synth_ui_macro_toggle(2);

        macro_after = synth_ui_macro_count();
    }

    if (why == NULL && !shot_puts("@@DONE\n")) {
        why = "the port stopped taking writes";
    }

    if (why == NULL) {
        /* The last bytes are still in the driver's ring on the way out of the chip. */
        usb_serial_jtag_wait_tx_done(pdMS_TO_TICKS(SHOT_WRITE_TIMEOUT_MS));
    }

    esp_log_level_set("*", logs);

    if (why != NULL) {
        ESP_LOGE(SHOT_TAG, "snapshots stopped after %d of %d frames: %s", sent, frames, why);
    }
    else {
        ESP_LOGI(SHOT_TAG,
                 "snapshots done: %d frames of %d (%d pages, %d states), macro %d before and %d after",
                 sent, frames, pages, SHOT_EXTRA_FRAMES, macro_before, macro_after);
    }

    heap_caps_free(raw);
    bsp_display_unlock();
    vTaskDelete(NULL);
}

void screenshots_start(void)
{
    /*
     * Its own task, not a call from synth_ui_build(): the walk takes the better part of a
     * minute and holds the LVGL lock throughout, and synth_ui_build() is itself called under
     * that lock, so it could not wait for any of it.
     */
    if (xTaskCreate(shot_task, "screenshots", SHOT_TASK_STACK, NULL,
                    SHOT_TASK_PRIORITY, NULL) != pdPASS) {
        ESP_LOGE(SHOT_TAG, "no room for the snapshot task");
    }
}
