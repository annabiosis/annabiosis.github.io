/*
 * The unattended stress program.
 *
 * SERVICE MODE, NOT A FEATURE. This file is compiled only with CONFIG_OBOD_STRESS, and
 * app_main() starts the task below only with that flag set. A build with the flag off
 * contains neither this task nor the observations it reads: the code is not in the
 * component at all.
 *
 * WHY IT EXISTS. The failures this instrument has had are the ones a bench finds by
 * accident: a value that is not a number reaching a pole and staying there, presets
 * written while the instrument plays, an effect claiming its scratch for the first time
 * in the middle of a note, a tempo the generators have never been asked for. None of
 * them need a person at the knob; all of them need hours. So this task sits below the
 * audio and statistics tasks, moves the same parameters the control surface moves, and
 * prints a verdict that names the seed, the block and the state it saw.
 *
 * WHAT IT DOES NOT DO. It never touches the engine directly: every change goes through
 * synth_app_set_param(), synth_app_set_running() or the preset calls, which is the path
 * a hand and a preset take. The one exception is the poisoned pole, and that call is
 * itself compiled only under this flag — it exists to prove the fuse works, not to
 * carry a fault into a normal build.
 *
 * THE RATES. One action per 20 ms tick, so the parameter sweep is exactly 50 changes a
 * second at its fastest. A pass takes roughly 37 seconds: the sweep over every sound
 * parameter, a tempo ladder from 30 to 300 BPM, the effect combinations, and eight
 * seconds of preset saves and loads. Presets, invalid values and poisoned poles are
 * interleaved on their own clocks and pre-empt one scenario tick, never more.
 */

#include "synth_app.h"
#include "synth_dsp.h"

#include "esp_log.h"
#include "esp_system.h"
#include "esp_timer.h"

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include <inttypes.h>
#include <math.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

static const char *TAG = "stress";

/* The seed the random choices are drawn from. A run is reproducible from the number in
 * the verdict: the same seed and the same pass number replay the same sequence. A build
 * may override it with -DSTRESS_SEED=<n> (see CMakeLists.txt); the verdict always says
 * which one was used. */
#ifndef STRESS_SEED
#define STRESS_SEED 0x5EED2026u
#endif

#define STRESS_TASK_PRIO   2
#define STRESS_TASK_STACK  4096
#define STRESS_TASK_CORE   0
#define STRESS_TICK_MS     20

/* Every period below is measured from the start of the scenario that owns it, so a
 * late tick cannot make the next one come early. */
#define VERDICT_PERIOD_MS   10000
#define INVALID_PERIOD_MS    3000
#define POISON_PERIOD_MS    10000
#define POISON_WAIT_MS       500

#define TEMPO_STEP_MS        1000
#define FX_STEP_MS             40

#define PRESET_PHASE_MS      8000
#define PRESET_LOAD_MS        900
#define PRESET_CYCLE_MS      2000

#define SILENT_AT_END_MS     2000

/* Four writes per parameter: minimum, maximum, minimum again, then the designed value.
 * The last step is what leaves the instrument playable at the end of the sweep; without
 * it the following scenario would start from a patch of zeroes. */
#define SWEEP_STEPS 4

static const float TEMPO_BPM[] = {
    30.0f, 36.0f, 40.0f, 45.0f, 60.0f, 72.0f,
    90.0f, 120.0f, 150.0f, 180.0f, 240.0f, 300.0f,
};
#define TEMPO_COUNT ((int)(sizeof(TEMPO_BPM) / sizeof(TEMPO_BPM[0])))

/* All the sound parameters in the order the control surface knows them: the patch, then
 * the three modulation destinations that live past the settings and are still part of
 * the sound. Settings are deliberately absent: they are stored and applied somewhere
 * else, and moving them through the audio path would test the wrong thing. */
#define SOUND_PARAM_COUNT \
    (SYNTH_PARAM_PATCH_COUNT + (SYNTH_PARAM_COUNT - SYNTH_PARAM_MOD_DEST))

typedef enum {
    PHASE_SWEEP = 0,
    PHASE_TEMPO,
    PHASE_EFFECTS,
    PHASE_PRESETS,
} stress_phase_t;

static uint32_t s_rng;
static uint32_t s_seed;
static uint32_t s_pass;

static stress_phase_t s_phase;
static int64_t s_phase_start_us;
static int64_t s_pass_start_us;

static int s_sweep_i;
static int s_sweep_sub;
static int s_tempo_i;
static int s_fx_i;
static int64_t s_next_tempo_us;
static int64_t s_next_fx_us;

static int64_t s_verdict_next_us;
static int64_t s_invalid_next_us;
static int64_t s_poison_next_us;

static uint32_t s_base_miss;
static uint32_t s_base_wr;
static uint32_t s_base_silence;
static uint32_t s_base_nonfinite;

static uint32_t s_poison_ok;
static uint32_t s_poison_miss;
static uint32_t s_poison_rescues;

static int      s_poison_pending;
static int      s_poison_target;
static uint32_t s_poison_base_nf;
static int64_t  s_poison_deadline_us;

static bool          s_restore_pending;
static synth_param_t s_restore_param;
static float         s_restore_value;

static uint32_t s_bad_ok;
static uint32_t s_bad_fail;

static float s_saved[SYNTH_PARAM_PATCH_COUNT];
static int   s_saved_slot;
static int   s_preset_load_pending;
static int64_t s_preset_load_us;
static int64_t s_preset_next_us;

static uint32_t s_preset_ok;
static uint32_t s_preset_fail;

static uint32_t s_fx_miss_base;
static uint32_t s_fx_wr_base;

static bool s_reset_fault;

/* -------------------------------------------------------------------------- */
/* Small helpers                                                              */
/* -------------------------------------------------------------------------- */

static uint32_t rng_next(void)
{
    uint32_t x = s_rng;

    /* xorshift32; the seed is kept nonzero on every write. */
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    s_rng = (x != 0u) ? x : 1u;
    return s_rng;
}

static float rng_f(void)
{
    return (float)(rng_next() >> 8) * (1.0f / 16777216.0f);
}

static synth_param_t sound_param(int i)
{
    if (i < SYNTH_PARAM_PATCH_COUNT) {
        return (synth_param_t)i;
    }
    return (synth_param_t)(SYNTH_PARAM_MOD_DEST + (i - SYNTH_PARAM_PATCH_COUNT));
}

/* The knob position that lands on a whole BPM: the inverse of seq_tempo_bpm() in
 * synth_app.cpp, whose span is log2(300 / 30) and whose floor is 30 BPM. */
static float bpm_v01(float bpm)
{
    if (bpm < 30.0f) {
        bpm = 30.0f;
    } else if (bpm > 300.0f) {
        bpm = 300.0f;
    }
    return log2f(bpm / 30.0f) / 3.32192809f;
}

static bool boot_reset_fault(void)
{
    switch (esp_reset_reason()) {
    case ESP_RST_PANIC:
    case ESP_RST_INT_WDT:
    case ESP_RST_TASK_WDT:
    case ESP_RST_WDT:
    case ESP_RST_BROWNOUT:
    case ESP_RST_PWR_GLITCH:
    case ESP_RST_CPU_LOCKUP:
        return true;
    default:
        return false;
    }
}

/* -------------------------------------------------------------------------- */
/* A playable patch                                                           */
/* -------------------------------------------------------------------------- */

/*
 * The designed values, with the parts the instrument ships silent turned on: the drum,
 * the three effects and the master section. The stress program has to hear the rack, and
 * a factory patch with every MIX at zero would exercise the dry path and nothing else.
 */
static void stress_baseline(void)
{
    for (int i = 0; i < SYNTH_PARAM_PATCH_COUNT; i++) {
        synth_app_set_param((synth_param_t)i, synth_app_param_default((synth_param_t)i));
    }

    synth_app_set_param(SYNTH_PARAM_PERC_LEVEL, 0.55f);
    synth_app_set_param(SYNTH_PARAM_SEND_PERC, 0.30f);
    synth_app_set_param(SYNTH_PARAM_DELAY_MIX, 0.45f);
    synth_app_set_param(SYNTH_PARAM_VERB_MIX, 0.35f);
    synth_app_set_param(SYNTH_PARAM_CHORUS_MIX, 0.25f);
    synth_app_set_param(SYNTH_PARAM_MASTER_COMP, 0.35f);
    synth_app_set_param(SYNTH_PARAM_MASTER_DUCK, 0.30f);
    synth_app_set_param(SYNTH_PARAM_DRIVE_AMOUNT, 0.25f);
    synth_app_set_param(SYNTH_PARAM_SEQ_TEMPO, bpm_v01(120.0f));
}

/* -------------------------------------------------------------------------- */
/* Verdict                                                                    */
/* -------------------------------------------------------------------------- */

static void stress_verdict(int64_t now_us, bool final)
{
    synth_app_stats_t st;
    synth_rack_stress_out_t out;
    synth_rack_rescue_t rescue;

    synth_app_get_stats(&st);
    synth_rack_stress_peak(&out);
    synth_rack_rescue_snapshot(&rescue);

    const uint32_t miss    = st.deadline_misses - s_base_miss;
    const uint32_t wr      = st.write_errors - s_base_wr;
    const uint32_t silence = rescue.silence_count - s_base_silence;
    const uint32_t nf      = rescue.nonfinite_count - s_base_nonfinite;
    const uint32_t stray   = (nf > s_poison_rescues) ? (nf - s_poison_rescues) : 0u;
    const double   t_s     = (double)(now_us - s_pass_start_us) / 1000000.0;

    /* A pass that has not made a sound for two seconds at its end did not exercise the
     * path: the drone may be released, the gate stuck, the master zeroed behind its
     * knob. `out.blocks == 0` means the audio task never produced a block at all. */
    const uint32_t now_ms = (uint32_t)esp_log_timestamp();
    const uint32_t age_ms = now_ms - out.last_sound_ms;
    const bool     silent = (out.blocks == 0u) || (age_ms > SILENT_AT_END_MS);

    const bool ok = (stray == 0u) && !silent && !s_reset_fault
                    && (s_poison_miss == 0u) && (s_bad_fail == 0u)
                    && (s_preset_fail == 0u);

    ESP_LOGI(TAG,
             "verdict%s seed 0x%08" PRIx32 " pass %u block %" PRIu32 " t %.1f s "
             "peak %ld..%ld nonfinite %" PRIu32 " stray %" PRIu32
             " silence %" PRIu32 " poison %" PRIu32 "/%" PRIu32
             " bad %" PRIu32 "/%" PRIu32 " preset %" PRIu32 "/%" PRIu32
             " miss %" PRIu32 " wrerr %" PRIu32 " reset %s %s",
             final ? " final" : "", s_seed, (unsigned)(s_pass + 1u),
             st.blocks, t_s,
             (long)(out.blocks ? out.peak_min : 0),
             (long)(out.blocks ? out.peak_max : 0),
             nf, stray, silence,
             s_poison_ok, s_poison_ok + s_poison_miss,
             s_bad_ok, s_bad_ok + s_bad_fail,
             s_preset_ok, s_preset_ok + s_preset_fail,
             miss, wr, s_reset_fault ? "yes" : "no", ok ? "ok" : "FAIL");
}

/* -------------------------------------------------------------------------- */
/* Scenarios                                                                  */
/* -------------------------------------------------------------------------- */

static void stress_pass_begin(int64_t now_us);

/*
 * The parameter sweep. Every sound parameter is walked from its minimum to its maximum,
 * back to the minimum and then to its designed value, one write per tick. The designed
 * value is written last so that the scenario after this one starts from a patch that can
 * be heard, rather than from the all-zeroes the down-stroke leaves behind.
 */
static bool sweep_step(int64_t now_us)
{
    (void)now_us;

    if (s_sweep_i >= SOUND_PARAM_COUNT) {
        stress_baseline();
        return false;
    }

    const synth_param_t p = sound_param(s_sweep_i);
    float v;

    switch (s_sweep_sub) {
    case 0:
    case 2:
        v = 0.0f;
        break;
    case 1:
        v = 1.0f;
        break;
    default:
        v = synth_app_param_default(p);
        break;
    }

    synth_app_set_param(p, v);

    if (++s_sweep_sub >= SWEEP_STEPS) {
        s_sweep_sub = 0;
        s_sweep_i++;
    }
    return true;
}

static void tempo_begin(int64_t now_us)
{
    stress_baseline();

    /* The arpeggiator takes the lead, the drum plays its own figure, and the delay is
     * short and synced: 1/16 at one tempo step, 1/32 at the next, for the whole ladder. */
    synth_app_set_param(SYNTH_PARAM_ARP_DIR, 1.0f / 7.0f);   /* UP; 0 is OFF */
    synth_app_set_param(SYNTH_PARAM_ARP_SPEED, 6.0f / 12.0f);
    synth_app_set_param(SYNTH_PARAM_ARP_LEN, 0.6f);
    synth_app_set_param(SYNTH_PARAM_ARP_RANGE, 0.5f);
    synth_app_set_param(SYNTH_PARAM_PERC_LEVEL, 0.60f);
    synth_app_set_param(SYNTH_PARAM_DELAY_MIX, 0.70f);
    synth_app_set_param(SYNTH_PARAM_DELAY_FEEDBACK, 0.45f);
    synth_app_set_param(SYNTH_PARAM_VERB_MIX, 0.25f);
    synth_app_set_param(SYNTH_PARAM_CHORUS_MIX, 0.20f);

    s_tempo_i = 0;
    s_next_tempo_us = now_us;

    ESP_LOGI(TAG, "tempo phase on: %d steps, 30..300 BPM, arp up, delay 1/16 and 1/32",
             TEMPO_COUNT);
}

static bool tempo_step(int64_t now_us)
{
    if (now_us < s_next_tempo_us) {
        return false;
    }

    if (s_tempo_i >= TEMPO_COUNT) {
        return false;
    }

    synth_app_set_param(SYNTH_PARAM_SEQ_TEMPO, bpm_v01(TEMPO_BPM[s_tempo_i]));

    /* 1/16 is index 10 of the twelve divisions, 1/32 is the last one. Alternating them
     * keeps the delay's read pointer moving at both ends of its short range. */
    synth_app_set_param(SYNTH_PARAM_DELAY_SYNC,
                        ((s_tempo_i & 1) == 0) ? (10.0f / 11.0f) : 1.0f);

    s_tempo_i++;
    s_next_tempo_us = now_us + (int64_t)TEMPO_STEP_MS * 1000;
    return true;
}

/*
 * The effect walk, as one list of (parameter, value) pairs. The ranges are written as
 * index over count so a list that grows keeps the same meaning: delay time 0..1 is the
 * whole free range, delay sync 0..1 is FREE..1/32, and the modes are their own divisor.
 */
static int fx_step(int i, synth_param_t *p, float *v)
{
    if (i < 22) {                       /* delay time, shortest -> longest -> back */
        *p = SYNTH_PARAM_DELAY_TIME;
        *v = (float)((i < 11) ? i : (21 - i)) / 10.0f;
        return 1;
    }
    i -= 22;

    if (i < 24) {                       /* delay division, FREE -> 1/32 -> back */
        *p = SYNTH_PARAM_DELAY_SYNC;
        *v = (float)((i < 12) ? i : (23 - i)) / 11.0f;
        return 1;
    }
    i -= 24;

    if (i < 3) {                        /* tape -> crossfade -> tape */
        *p = SYNTH_PARAM_DELAY_TIMEMODE;
        *v = (i == 1) ? 1.0f : 0.0f;
        return 1;
    }
    i -= 3;

    if (i < 22) {                       /* delay mix 0 <-> 1 */
        *p = SYNTH_PARAM_DELAY_MIX;
        *v = (float)((i < 11) ? i : (21 - i)) / 10.0f;
        return 1;
    }
    i -= 22;

    if (i < 8) {                        /* reverb modes, up and back */
        *p = SYNTH_PARAM_VERB_MODE;
        *v = (float)((i < 4) ? i : (7 - i)) / 3.0f;
        return 1;
    }
    i -= 8;

    if (i < 44) {                       /* reverb size and damp, each 0..1..0 */
        const int k = i % 22;
        *p = (i < 22) ? SYNTH_PARAM_VERB_SIZE : SYNTH_PARAM_VERB_DAMP;
        *v = (float)((k < 11) ? k : (21 - k)) / 10.0f;
        return 1;
    }
    i -= 44;

    if (i < 66) {                       /* chorus rate, depth and mix, each 0..1..0 */
        const int group = i / 22;
        const int k = i % 22;
        *p = (group == 0) ? SYNTH_PARAM_CHORUS_RATE
           : (group == 1) ? SYNTH_PARAM_CHORUS_DEPTH
                          : SYNTH_PARAM_CHORUS_MIX;
        *v = (float)((k < 11) ? k : (21 - k)) / 10.0f;
        return 1;
    }
    i -= 66;

    if (i < 12) {                       /* the four reverb sends, 0 -> 1 -> 0 */
        static const float send_cycle[3] = { 0.0f, 1.0f, 0.0f };
        *p = (synth_param_t)(SYNTH_PARAM_SEND_LOW + i / 3);
        *v = send_cycle[i % 3];
        return 1;
    }
    i -= 12;

    if (i < 24) {                       /* the six chorus, then the six delay sends */
        *p = (i < 12) ? (synth_param_t)(SYNTH_PARAM_CHR_SEND_LOW + i / 2)
                      : (synth_param_t)(SYNTH_PARAM_DLY_SEND_LOW + (i - 12) / 2);
        *v = ((i % 2) == 0) ? 1.0f : 0.0f;
        return 1;
    }

    return 0;
}

static void effects_begin(int64_t now_us)
{
    stress_baseline();

    /* The delay starts free-running so the time walk is audible, and every return is
     * open: an effect that is mixed at zero cannot poison anything but its own send. */
    synth_app_set_param(SYNTH_PARAM_DELAY_SYNC, 0.0f);
    synth_app_set_param(SYNTH_PARAM_DELAY_MIX, 0.80f);
    synth_app_set_param(SYNTH_PARAM_DELAY_FEEDBACK, 0.50f);
    synth_app_set_param(SYNTH_PARAM_VERB_MIX, 0.50f);
    synth_app_set_param(SYNTH_PARAM_CHORUS_MIX, 0.40f);
    synth_app_set_param(SYNTH_PARAM_MASTER_COMP, 0.40f);
    synth_app_set_param(SYNTH_PARAM_MASTER_DUCK, 0.30f);
    synth_app_set_param(SYNTH_PARAM_DRIVE_AMOUNT, 0.30f);

    s_fx_i = 0;
    s_next_fx_us = now_us;

    {
        synth_app_stats_t st;
        synth_app_get_stats(&st);
        s_fx_miss_base = st.deadline_misses;
        s_fx_wr_base = st.write_errors;
        ESP_LOGI(TAG, "effects phase on at block %" PRIu32, st.blocks);
    }
}

/*
 * One effect step per FX_STEP_MS. The return value separates "not due yet" from "the
 * list is finished": 0 means wait, 1 means a change was made, and -1 means the last
 * pair has been written and the phase is over. A single false for both would end the
 * phase on its first idle tick, which is exactly what the first run of this program
 * did before the distinction was made.
 */
static int effects_step(int64_t now_us)
{
    if (now_us < s_next_fx_us) {
        return 0;
    }

    synth_param_t p;
    float v;

    if (!fx_step(s_fx_i, &p, &v)) {
        synth_app_stats_t st;
        synth_app_get_stats(&st);
        ESP_LOGI(TAG,
                 "effects phase done: miss +%" PRIu32 ", wrerr +%" PRIu32
                 " (first switch included)",
                 st.deadline_misses - s_fx_miss_base,
                 st.write_errors - s_fx_wr_base);
        return -1;
    }

    synth_app_set_param(p, v);
    s_fx_i++;
    s_next_fx_us = now_us + (int64_t)FX_STEP_MS * 1000;
    return 1;
}

/* -------------------------------------------------------------------------- */
/* Presets                                                                    */
/* -------------------------------------------------------------------------- */

static void preset_begin(int64_t now_us)
{
    stress_baseline();

    s_preset_load_pending = 0;
    s_preset_next_us = now_us + 200000;
    s_phase_start_us = now_us;

    ESP_LOGI(TAG, "preset phase on: save and load every 2 s, %d values per record",
             SYNTH_PARAM_PATCH_COUNT);
}

static void preset_save(int64_t now_us)
{
    synth_app_get_params(s_saved, SYNTH_PARAM_PATCH_COUNT);

    /* The first eight slots only: a random slot over the whole 128-entry store would
     * spend the run appending new presets and never overwrite one, which is the write
     * pattern the flash sees least often. */
    const int slot = (int)(rng_next() % 8u);
    const int got = synth_app_preset_save(slot);

    if (got < 0) {
        s_preset_fail++;
        ESP_LOGW(TAG, "preset save failed, slot %d", slot);
        s_preset_next_us = now_us + (int64_t)PRESET_CYCLE_MS * 1000;
        return;
    }

    /* What the store will hand back: the record is one byte per value, so the copy is
     * quantised before it can be the expectation. */
    for (int i = 0; i < SYNTH_PARAM_PATCH_COUNT; i++) {
        float v = s_saved[i];
        if (!(v >= 0.0f)) {
            v = 0.0f;
        } else if (v > 1.0f) {
            v = 1.0f;
        }
        s_saved[i] = (float)(uint8_t)(v * 255.0f + 0.5f) / 255.0f;
    }

    s_saved_slot = got;
    s_preset_load_pending = 1;
    s_preset_load_us = now_us + (int64_t)PRESET_LOAD_MS * 1000;

    /* One visible change between the save and the load, so the load has something to
     * put back rather than rewriting the values that are already there. */
    const int idx = (int)(rng_next() % (uint32_t)SYNTH_PARAM_PATCH_COUNT);
    synth_app_set_param((synth_param_t)idx, rng_f());
}

static void preset_load(int64_t now_us)
{
    const int n = synth_app_preset_load(s_saved_slot);
    int bad = 0;

    if (n > 0) {
        for (int i = 0; i < SYNTH_PARAM_PATCH_COUNT; i++) {
            if (fabsf(synth_app_get_param((synth_param_t)i) - s_saved[i]) > (2.0f / 255.0f)) {
                if (bad < 3) {
                    ESP_LOGW(TAG, "preset mismatch p%d want %.4f got %.4f",
                             i, (double)s_saved[i],
                             (double)synth_app_get_param((synth_param_t)i));
                }
                bad++;
            }
        }
    }

    if (n <= 0 || bad != 0) {
        s_preset_fail++;
        ESP_LOGW(TAG, "preset load failed, slot %d, n %d, mismatches %d",
                 s_saved_slot, n, bad);
    } else {
        s_preset_ok++;
    }

    s_preset_load_pending = 0;
    s_preset_next_us = now_us + (int64_t)PRESET_CYCLE_MS * 1000;
}

static bool preset_tick(int64_t now_us)
{
    if (s_preset_load_pending) {
        if (now_us < s_preset_load_us) {
            return false;
        }
        preset_load(now_us);
        return true;
    }

    if (now_us < s_preset_next_us) {
        return false;
    }

    preset_save(now_us);
    return true;
}

/* -------------------------------------------------------------------------- */
/* Invalid values and poisoned poles                                          */
/* -------------------------------------------------------------------------- */

static void invalid_do(int64_t now_us)
{
    static const char *const NAME[4] = { "nan", "inf", "-1", "1.5" };
    float bad;

    const int which = (int)(rng_next() % 4u);
    const int idx = (int)(rng_next() % (uint32_t)SOUND_PARAM_COUNT);
    const synth_param_t p = sound_param(idx);

    switch (which) {
    case 0:
        bad = (float)NAN;
        break;
    case 1:
        bad = (float)INFINITY;
        break;
    case 2:
        bad = -1.0f;
        break;
    default:
        bad = 1.5f;
        break;
    }

    const float before = synth_app_get_param(p);
    synth_app_set_param(p, bad);
    const float after = synth_app_get_param(p);

    const bool clamped = isfinite(after) && (after >= 0.0f) && (after <= 1.0f);

    if (clamped) {
        s_bad_ok++;
    } else {
        s_bad_fail++;
    }

    ESP_LOGI(TAG, "bad p%d <- %s: read back %.3f (%s), restoring %.3f",
             (int)p, NAME[which], (double)after,
             clamped ? "clamped" : "NOT CLAMPED", (double)before);

    s_restore_pending = true;
    s_restore_param = p;
    s_restore_value = before;

    s_invalid_next_us = now_us + (int64_t)INVALID_PERIOD_MS * 1000;
}

static void poison_start(int64_t now_us)
{
    synth_rack_rescue_t r;
    synth_rack_rescue_snapshot(&r);

    s_poison_base_nf = r.nonfinite_count;
    s_poison_target = (int)(rng_next() % 2u);
    s_poison_deadline_us = now_us + (int64_t)POISON_WAIT_MS * 1000;
    s_poison_pending = 1;

    static const char *const NAME[2] = { "master", "comp" };

    ESP_LOGI(TAG, "poison %s pole, block %.1f s into the run",
             NAME[s_poison_target], (double)(now_us - s_pass_start_us) / 1000000.0);

    synth_rack_stress_poison(s_poison_target);
}

static void poison_poll(int64_t now_us)
{
    synth_rack_rescue_t r;
    synth_rack_rescue_snapshot(&r);

    if (r.nonfinite_count != s_poison_base_nf) {
        const uint32_t d = r.nonfinite_count - s_poison_base_nf;

        s_poison_ok++;
        s_poison_rescues++;
        s_poison_pending = 0;

        if (d > 1u) {
            ESP_LOGW(TAG, "poison produced %" PRIu32 " non-finite rescues at once", d);
        } else {
            ESP_LOGI(TAG, "poison rescued, serial %" PRIu32, r.serial);
        }
        return;
    }

    if (now_us >= s_poison_deadline_us) {
        s_poison_miss++;
        s_poison_pending = 0;
        ESP_LOGW(TAG, "poison NOT rescued within %d ms", POISON_WAIT_MS);
    }
}

/* -------------------------------------------------------------------------- */
/* The pass                                                                   */
/* -------------------------------------------------------------------------- */

static void stress_pass_begin(int64_t now_us)
{
    synth_app_stats_t st;
    synth_rack_rescue_t r;

    s_seed = STRESS_SEED + s_pass;
    s_rng = s_seed;

    synth_app_get_stats(&st);
    synth_rack_rescue_snapshot(&r);

    s_base_miss = st.deadline_misses;
    s_base_wr = st.write_errors;
    s_base_silence = r.silence_count;
    s_base_nonfinite = r.nonfinite_count;

    s_poison_ok = 0;
    s_poison_miss = 0;
    s_poison_rescues = 0;
    s_poison_pending = 0;
    s_bad_ok = 0;
    s_bad_fail = 0;
    s_preset_ok = 0;
    s_preset_fail = 0;
    s_preset_load_pending = 0;
    s_restore_pending = false;

    s_reset_fault = boot_reset_fault();

    s_phase = PHASE_SWEEP;
    s_sweep_i = 0;
    s_sweep_sub = 0;
    s_tempo_i = 0;
    s_fx_i = 0;

    s_pass_start_us = now_us;
    s_phase_start_us = now_us;
    s_verdict_next_us = now_us + (int64_t)VERDICT_PERIOD_MS * 1000;
    s_invalid_next_us = now_us + (int64_t)INVALID_PERIOD_MS * 1000;
    s_poison_next_us = now_us + (int64_t)POISON_PERIOD_MS * 1000;

    stress_baseline();
    synth_rack_stress_peak_reset();

    ESP_LOGI(TAG, "pass %u start, seed 0x%08" PRIx32 ", %d sound parameters",
             (unsigned)(s_pass + 1u), s_seed, SOUND_PARAM_COUNT);
}

static void stress_pass_end(int64_t now_us)
{
    stress_verdict(now_us, true);

    s_pass++;
    stress_pass_begin(now_us);
}

static void scenario_step(int64_t now_us)
{
    switch (s_phase) {
    case PHASE_SWEEP:
        if (!sweep_step(now_us)) {
            tempo_begin(now_us);
            s_phase = PHASE_TEMPO;
        }
        break;

    case PHASE_TEMPO:
        if (!tempo_step(now_us)) {
            if (s_tempo_i >= TEMPO_COUNT) {
                effects_begin(now_us);
                s_phase = PHASE_EFFECTS;
            }
        }
        break;

    case PHASE_EFFECTS: {
        const int r = effects_step(now_us);
        if (r < 0) {
            preset_begin(now_us);
            s_phase = PHASE_PRESETS;
        }
        break;
    }

    case PHASE_PRESETS:
        if ((now_us - s_phase_start_us) >= (int64_t)PRESET_PHASE_MS * 1000
            && !s_preset_load_pending) {
            stress_pass_end(now_us);
        }
        break;
    }
}

static void stress_tick(int64_t now_us)
{
    if (now_us >= s_verdict_next_us) {
        stress_verdict(now_us, false);
        s_verdict_next_us = now_us + (int64_t)VERDICT_PERIOD_MS * 1000;
    }

    if (s_poison_pending) {
        poison_poll(now_us);
        return;
    }

    if (s_restore_pending) {
        synth_app_set_param(s_restore_param, s_restore_value);
        s_restore_pending = false;
        return;
    }

    if (s_phase == PHASE_PRESETS) {
        if (preset_tick(now_us)) {
            return;
        }
    }

    if (now_us >= s_invalid_next_us) {
        invalid_do(now_us);
        return;
    }

    if (now_us >= s_poison_next_us) {
        poison_start(now_us);
        s_poison_next_us = now_us + (int64_t)POISON_PERIOD_MS * 1000;
        return;
    }

    scenario_step(now_us);
}

/* -------------------------------------------------------------------------- */
/* Task                                                                       */
/* -------------------------------------------------------------------------- */

static void stress_task(void *arg)
{
    (void)arg;

    /* The first seconds after boot belong to the audio task claiming its DMA, the
     * effects claiming their scratch on the first block that asks for them, and the
     * drone's 2.5 s attack. Starting before that would make the first verdict a report
     * on the boot rather than on the program. */
    vTaskDelay(pdMS_TO_TICKS(3000));

    synth_app_set_running(1);
    stress_pass_begin(esp_timer_get_time());

    TickType_t last = xTaskGetTickCount();

    for (;;) {
        vTaskDelayUntil(&last, pdMS_TO_TICKS(STRESS_TICK_MS));
        stress_tick(esp_timer_get_time());
    }
}

void synth_app_stress_start(void)
{
    if (xTaskCreatePinnedToCore(stress_task, "synth_stress", STRESS_TASK_STACK, NULL,
                                STRESS_TASK_PRIO, NULL, STRESS_TASK_CORE) != pdPASS) {
        ESP_LOGE(TAG, "could not create the stress task");
    }
}
