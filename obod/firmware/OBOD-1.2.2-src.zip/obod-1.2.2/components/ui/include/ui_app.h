/*
 * Bridge between the SquareLine Studio export and the rest of the firmware.
 *
 * WHAT SQUARELINE GIVES YOU
 *   A generated tree of C files (ui.c, ui.h, screens/, components/, fonts/,
 *   images/) whose only stable entry point is `ui_init()`. It knows nothing
 *   about the knob or application state.
 *
 * WHAT THIS FILE ADDS
 *   1. It calls ui_init() under the LVGL lock, so the caller cannot get that
 *      wrong.
 *   2. It fills the encoder's lv_group_t automatically. SquareLine does not
 *      put anything into a group, so without this the knob would move focus
 *      through an empty group and the UI would look dead. Widgets are found by
 *      class, walking the active screen.
 *   3. It gives the focused widget a visible style, so a knob-only
 *      interface still shows what it is about to change.
 *   4. It gives focus a visible style, because SquareLine does not generate
 *      one and an invisible focus ring is the single most common reason a
 *      knob UI feels broken.
 *
 * TYPICAL USE
 *
 *     ESP_ERROR_CHECK(ui_app_init(NULL));        // after bsp_init()
 *     ...
 *     ui_app_load_screen(ui_SettingsScreen, LV_SCR_LOAD_ANIM_MOVE_LEFT);
 *
 * Screen switching calls ui_app_refresh_focus_group() for you, so the knob
 * immediately navigates whatever is on screen.
 */
#pragma once

#include <stdbool.h>

#include "esp_err.h"
#include "lvgl.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    /* Focus the first focusable widget when the group is rebuilt. Without
     * this, nothing is highlighted until the user turns the knob once. */
    bool auto_focus_first;
    /*
     * Mark the focused widget with a visible outline.
     *
     * Off by default. On a knob-only board the group holds exactly one widget,
     * so focus never moves and the outline becomes permanent furniture drawn
     * around the control the user is already looking at. Switch it on only for
     * a screen that genuinely cycles focus between several widgets.
     */
    bool default_focus_style;
} ui_app_config_t;

#define UI_APP_CONFIG_DEFAULT()          \
    {                                    \
        .auto_focus_first    = true,     \
        .default_focus_style = false,    \
    }

/*
 * Initialise the SquareLine UI and attach it to the encoder.
 *
 * Call after bsp_init(). Pass NULL for the default configuration.
 * Returns ESP_ERR_INVALID_STATE if the display or encoder is missing.
 */
esp_err_t ui_app_init(const ui_app_config_t *config);

/*
 * Initialise with a screen builder of your own instead of the SquareLine export.
 *
 * `build` runs under the LVGL lock, on the active screen, exactly where
 * ui_init() would have run. Everything after it is unchanged: the focus group is
 * rebuilt from whatever the builder created and the focus style is installed.
 *
 * Pass NULL to get ui_init().
 *
 * This exists because components/ui/generated/ui.c is a placeholder that
 * tools/squareline_sync.ps1 replaces wholesale from the SquareLine Studio
 * export. A screen built in there is destroyed by the next export, so an
 * application that wants to own its screen needs somewhere else to build it.
 */
typedef void (*ui_app_screen_fn)(void);

esp_err_t ui_app_init_with_screen(const ui_app_config_t *config, ui_app_screen_fn build);

/* The group the encoder navigates. Never NULL after a successful init. */
lv_group_t *ui_app_get_group(void);

/*
 * Rebuild the group from the widgets currently on the active screen.
 *
 * Called automatically by ui_app_load_screen(). Call it by hand after creating
 * or deleting widgets at runtime.
 *
 * Must be called under the LVGL lock.
 */
void ui_app_refresh_focus_group(void);

/*
 * Force a widget into (or out of) the group regardless of its class.
 *
 * Useful for panels and images that SquareLine will not treat as interactive
 * but that the user is still expected to rotate through.
 *
 * Must be called under the LVGL lock.
 */
bool ui_app_add_focusable(lv_obj_t *obj);
bool ui_app_remove_focusable(lv_obj_t *obj);

/* Currently focused widget, or NULL. Must be called under the LVGL lock. */
lv_obj_t *ui_app_get_focused(void);

/*
 * Load a SquareLine screen and rebuild the focus group for it.
 *
 * `anim` is an lv_screen_load_anim_t value; LV_SCR_LOAD_ANIM_NONE switches
 * instantly. Reaches the same result as lv_screen_load_anim() plus
 * ui_app_refresh_focus_group().
 */
void ui_app_load_screen(lv_obj_t *screen, lv_screen_load_anim_t anim);

/*
 * Re-evaluate which widgets the knob can reach, and the focus indicator with
 * them.
 *
 * Call this after anything that changes which widgets are *visible* — a page
 * switch that shows and hides panes on a single screen, a tab change, a panel
 * opening. It does not reload a screen; ui_app_load_screen() does that.
 *
 * The reason it is needed is that the number of reachable widgets decides two
 * things at once: whether the focus is pinned, and whether the focus ring is
 * shown at all (it is hidden when there is only one candidate). A page switch
 * that only toggles visibility would otherwise leave both stale.
 *
 * Must be called under the LVGL lock.
 */
void ui_app_refresh_focus_group(void);

/*
 * Replace the built-in focus outline.
 *
 * Pass a style with a border or outline set; it is applied to the focused
 * widget and removed from the previous one. Pass NULL to disable the
 * indicator entirely.
 */
void ui_app_set_focus_style(lv_style_t *style);

#ifdef __cplusplus
}
#endif
