/*
 * PLACEHOLDER UI — overwritten by the SquareLine Studio export.
 *
 * This is a hardware bring-up demo, not a SquareLine project. It exists to
 * answer "does every peripheral on this board actually work?" from the device
 * itself, with no serial console attached.
 *
 * The shape of it is dictated by the hardware: there is no push button, so
 * LVGL never gets an ENTER and never enters edit mode. An encoder in navigate
 * mode only moves focus; it cannot change values. Therefore each page carries
 * exactly one focusable control — the arc — so rotating always edits it, and
 * the pages are switched by tapping the two arrows.
 *
 * Pages:
 *   1  Ring hue        knob sets the LED ring hue, live
 *   2  Backlight       knob sets panel brightness
 *   3  Tone            knob sets the frequency of a sine on the PCM5100A
 *   4  Test pattern    knob steps through solid fills — the diagnostic for
 *                      banding and colour artefacts
 *
 * tools/squareline_sync.ps1 replaces this file wholesale; nothing outside
 * ui_init() is referenced by the rest of the firmware.
 */

#include "ui.h"

#include <math.h>
#include <stdio.h>
#include <string.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "esp_log.h"

#include "bsp/bsp.h"

#include "ui_app.h"

static const char *TAG = "demo";

/* -------------------------------------------------------------------------- */
/* Pages                                                                      */
/* -------------------------------------------------------------------------- */

typedef enum {
    PAGE_RING = 0,
    PAGE_BACKLIGHT,
    PAGE_TONE,
    PAGE_PATTERN,
    PAGE_COUNT,
} page_t;

static const char *const PAGE_NAMES[PAGE_COUNT] = {
    "LED ring hue",
    "Backlight",
    "Tone",
    "Test pattern",
};

/* Ranges are per page; the arc is reconfigured on every switch. */
static const int PAGE_MIN[PAGE_COUNT] = {   0,   1,  200, 0 };
static const int PAGE_MAX[PAGE_COUNT] = { 359, 100, 4000, 4 };

static page_t s_page;
static int    s_value[PAGE_COUNT] = { 200, 80, 1000, 0 };
static bool   s_ui_ready;

/* --- Widgets -------------------------------------------------------------- */
static lv_obj_t *s_title;
static lv_obj_t *s_arc;
static lv_obj_t *s_value_label;
static lv_obj_t *s_unit_label;
static lv_obj_t *s_page_label;
static lv_obj_t *s_btn_prev;
static lv_obj_t *s_btn_next;
static lv_obj_t *s_hint;

/* Prototypes: the page actions call back into the UI. */
static void apply_page(void);

/* -------------------------------------------------------------------------- */
/* Page actions                                                               */
/* -------------------------------------------------------------------------- */

static void ring_apply(int hue)
{
    if (!bsp_led_is_available()) {
        return;
    }
    /* Full saturation, moderate value: the ring shares the rail with the
     * backlight, and full white on 13 LEDs is enough to sag it. */
    bsp_led_set_all_hsv((uint16_t)hue, 255, 200);
    bsp_led_refresh();
}

/*
 * Solid fills covering the whole panel. A flat colour is the fastest way to
 * tell a real display fault from a rendering one: banding on a flat field is
 * the panel or the bus, banding only on gradients is the frame buffer.
 */
static const uint32_t PATTERN_COLOURS[] = {
    0x000000,  /* black */
    0xFFFFFF,  /* white — reveals the most */
    0xFF0000,  /* red */
    0x00FF00,  /* green */
    0x0000FF,  /* blue */
};

static void pattern_apply(int index)
{
    if (index < 0 || index >= (int)(sizeof(PATTERN_COLOURS) / sizeof(PATTERN_COLOURS[0]))) {
        return;
    }
    lv_obj_set_style_bg_color(lv_screen_active(),
                              lv_color_hex(PATTERN_COLOURS[index]), LV_PART_MAIN);
}

static void page_action(page_t page, int value)
{
    switch (page) {
    case PAGE_RING:      ring_apply(value);      break;
    case PAGE_BACKLIGHT: bsp_display_brightness_set(value); break;
    case PAGE_TONE:      /* handled by the audio task */    break;
    case PAGE_PATTERN:   pattern_apply(value);   break;
    default: break;
    }
}

/* -------------------------------------------------------------------------- */
/* Audio                                                                      */
/* -------------------------------------------------------------------------- */
/*
 * One task serves the tone page. It generates a sine on the DAC while that page
 * is visible and idles otherwise, so the amplifier is not left running with a
 * DC offset when the user moves on.
 */
#define TONE_FRAMES      256
#define TONE_SAMPLE_RATE 44100
#define TONE_AMPLITUDE   8000

static void audio_task(void *arg)
{
    (void)arg;

    static int16_t buffer[TONE_FRAMES * 2];   /* stereo interleaved */
    const float two_pi = 6.2831853f;
    float phase = 0.0f;

    for (;;) {
        if (s_page != PAGE_TONE || !bsp_audio_out_is_ready()) {
            vTaskDelay(pdMS_TO_TICKS(50));
            continue;
        }

        const float step = two_pi * (float)s_value[PAGE_TONE] / (float)TONE_SAMPLE_RATE;
        for (int i = 0; i < TONE_FRAMES; i++) {
            const int16_t sample = (int16_t)(sinf(phase) * (float)TONE_AMPLITUDE);
            buffer[i * 2]     = sample;
            buffer[i * 2 + 1] = sample;
            phase += step;
            if (phase >= two_pi) {
                phase -= two_pi;
            }
        }

        size_t written = 0;
        /* A finite timeout: if the DAC stops draining, the UI must not wedge. */
        bsp_audio_out_write(buffer, sizeof(buffer), &written, 100);
    }
}

/* -------------------------------------------------------------------------- */
/* UI plumbing                                                                */
/* -------------------------------------------------------------------------- */

static void refresh_readout(void)
{
    const page_t p = s_page;
    char text[32];
    int shown = s_value[p];

    lv_label_set_text(s_title, PAGE_NAMES[p]);
    lv_obj_align(s_title, LV_ALIGN_TOP_MID, 0, 30);

    /* Human-readable value plus its unit, because "1000" means nothing on its
     * own and the arc alone cannot say what it controls. */
    switch (p) {
    case PAGE_RING:      snprintf(text, sizeof(text), "%d", shown);          lv_label_set_text(s_unit_label, "hue degrees"); break;
    case PAGE_BACKLIGHT: snprintf(text, sizeof(text), "%d", shown);          lv_label_set_text(s_unit_label, "percent");     break;
    case PAGE_TONE:      snprintf(text, sizeof(text), "%d", shown);          lv_label_set_text(s_unit_label, "Hz");          break;
    case PAGE_PATTERN:   snprintf(text, sizeof(text), "%d", shown);          lv_label_set_text(s_unit_label, "of 4");        break;
    default:             text[0] = '\0'; break;
    }
    lv_label_set_text(s_value_label, text);

    snprintf(text, sizeof(text), "%d / %d", (int)p + 1, (int)PAGE_COUNT);
    lv_label_set_text(s_page_label, text);

    /* Hints say what the knob does here — on a device with no labels, that is
     * the only way the user learns the current binding. */
    const char *hint = "";
    switch (p) {
    case PAGE_RING:      hint = "turn: hue"; break;
    case PAGE_BACKLIGHT: hint = "turn: brightness"; break;
    case PAGE_TONE:      hint = "turn: frequency"; break;
    case PAGE_PATTERN:   hint = "turn: colour"; break;
    default: break;
    }
    lv_label_set_text(s_hint, hint);
}

static void apply_page(void)
{
    refresh_readout();
    page_action(s_page, s_value[s_page]);
}

static void goto_page(int page)
{
    if (page < 0) {
        page = PAGE_COUNT - 1;
    } else if (page >= PAGE_COUNT) {
        page = 0;
    }

    s_page = (page_t)page;

    /* The screen background belongs to the test pattern; restore it when the
     * user leaves that page, or the whole UI inherits the last fill. */
    if (s_page != PAGE_PATTERN) {
        lv_obj_set_style_bg_color(lv_screen_active(), lv_color_hex(0x101418), LV_PART_MAIN);
    }

    /*
     * Hard-gate the DAC on the tone page.
     *
     * The audio task already stops generating elsewhere, but that alone leaves
     * whatever the I2S DMA has queued still draining — and, worse, leaves the
     * amplifier live with a DC offset. The PCM5100A's XSMT line is a soft mute,
     * so switching it produces no click.
     */
    if (bsp_audio_out_is_ready()) {
        bsp_audio_out_mute(s_page != PAGE_TONE);
    }

    lv_arc_set_range(s_arc, PAGE_MIN[s_page], PAGE_MAX[s_page]);
    lv_arc_set_value(s_arc, s_value[s_page]);

    apply_page();

    /*
     * Switching pages does not reload a screen — it shows and hides panes on
     * one screen. That changes how many widgets the knob can reach, and the
     * focus policy and the focus ring both key on that count, so the group is
     * re-evaluated rather than assumed. Without this a ring left over from a
     * page with several controls would stay on screen when the new page has
     * only one, where it should be absent.
     */
    ui_app_refresh_focus_group();
    bsp_encoder_refocus();
}

static void arc_changed_cb(lv_event_t *e)
{
    lv_obj_t *arc = lv_event_get_target_obj(e);

    if (!s_ui_ready) {
        return;
    }

    s_value[s_page] = (int)lv_arc_get_value(arc);
    refresh_readout();
    page_action(s_page, s_value[s_page]);
}

static void page_button_cb(lv_event_t *e)
{
    const intptr_t delta = (intptr_t)lv_event_get_user_data(e);
    goto_page((int)s_page + (int)delta);
}

/* A tappable control that the knob must NOT reach, and that must not take the
 * focus away from the arc either.
 *
 * Deliberately an lv_obj rather than an lv_button: ui_app.c's group builder
 * only collects interactive classes, so a plain clickable object stays out of
 * the encoder's path while remaining tappable. Using lv_button here would put
 * two extra items in the group and leave the knob cycling between them.
 *
 * Staying out of the GROUP is not enough on its own. LVGL's pointer handling
 * moves the focus to whatever click-focusable object was tapped, and doing so
 * clears the group's edit mode — after which the knob only shuffles focus and
 * changes no values. Clearing LV_OBJ_FLAG_CLICK_FOCUSABLE keeps the button
 * fully tappable while making it invisible to the focus system, which is what
 * makes touch and the knob independent. lv_obj_create() sets that flag by
 * default, so it has to be turned off explicitly. */
static lv_obj_t *make_touch_button(lv_obj_t *parent, const char *glyph, int delta, lv_align_t align, int x_ofs)
{
    lv_obj_t *btn = lv_obj_create(parent);
    lv_obj_set_scrollable(btn, false);
    lv_obj_set_size(btn, 56, 56);
    lv_obj_align(btn, align, x_ofs, 0);
    lv_obj_set_style_radius(btn, LV_RADIUS_CIRCLE, LV_PART_MAIN);
    lv_obj_set_style_bg_color(btn, lv_color_hex(0x1E2A36), LV_PART_MAIN);
    lv_obj_set_style_border_width(btn, 0, LV_PART_MAIN);
    lv_obj_set_clickable(btn, true);
    lv_obj_set_click_focusable(btn, false);
    lv_obj_add_event_cb(btn, page_button_cb, LV_EVENT_CLICKED, (void *)delta);

    lv_obj_t *label = lv_label_create(btn);
    lv_label_set_text(label, glyph);
    lv_obj_set_style_text_font(label, &lv_font_montserrat_20, LV_PART_MAIN);
    lv_obj_center(label);

    return btn;
}

/* -------------------------------------------------------------------------- */
/* Entry point                                                                */
/* -------------------------------------------------------------------------- */

void ui_init(void)
{
    lv_obj_t *screen = lv_screen_active();

    lv_obj_set_style_bg_color(screen, lv_color_hex(0x101418), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(screen, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_set_scrollable(screen, false);

    s_title = lv_label_create(screen);
    lv_obj_set_style_text_color(s_title, lv_color_hex(0x8A97A6), LV_PART_MAIN);
    lv_obj_align(s_title, LV_ALIGN_TOP_MID, 0, 30);

    /* --- The arc: the only focusable widget, so the knob always drives it --- */
    s_arc = lv_arc_create(screen);
    lv_obj_set_size(s_arc, 210, 210);
    lv_obj_center(s_arc);
    lv_arc_set_bg_angles(s_arc, 135, 45);
    lv_obj_set_style_arc_width(s_arc, 14, LV_PART_INDICATOR);
    lv_obj_set_style_arc_width(s_arc, 14, LV_PART_MAIN);
    lv_obj_set_style_arc_color(s_arc, lv_color_hex(0x00B4FF), LV_PART_INDICATOR);
    lv_obj_set_style_arc_color(s_arc, lv_color_hex(0x222A33), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(s_arc, LV_OPA_TRANSP, LV_PART_KNOB);
    /* Left clickable on purpose. ui_app.c's group builder only collects
     * interactive classes, so clickability is what puts the arc under the knob.
     * Touch can drag it as well, which on a device with no button is a feature
     * rather than something to suppress. */
    lv_obj_add_event_cb(s_arc, arc_changed_cb, LV_EVENT_VALUE_CHANGED, NULL);

    /*
     * The arc is the one widget the knob is meant to drive, so it must be the
     * one the focus system can reach. Declaring that explicitly means the
     * invariant holds even if the group is rebuilt or something else on the
     * screen is later made click-focusable by accident.
     */
    lv_obj_set_click_focusable(s_arc, true);

    /*
     * Kill the theme's focus decoration on the arc.
     *
     * This is the red frame that kept appearing. It is drawn by LVGL's default
     * theme, not by ui_app.c.
     *
     * The state that carries it is LV_STATE_EDITED. Measured, not guessed — the
     * resolved outline colour and width were dumped per state:
     *
     *   st=0x28 FOCUSED|EDITED                     -> outline w=2 #F44336 (red)
     *   st=0x68 FOCUSED|EDITED|HOVERED             -> outline w=2 #F44336 (red)
     *   st=0x78 FOCUSED|EDITED|HOVERED|FOCUS_KEY   -> outline w=2 #F44336 (red)
     *   st=0xF8 FOCUSED|EDITED|HOVERED|PRESSED|... -> outline w=2 #F44336 (red)
     *   st=0x08 FOCUSED                            -> clear
     *   st=0xC8 FOCUSED|HOVERED|PRESSED            -> clear
     *   st=0xD8 FOCUSED|EDITED?... no EDITED       -> clear
     *
     * Every red case contains LV_STATE_EDITED (0x20); no case without it is red.
     * An encoder in edit mode sets FOCUSED|EDITED, which is exactly the normal
     * state of this UI.
     *
     * Why `lv_obj_set_local_style_prop` and not the usual
     * `lv_obj_set_style_outline_width`:
     *
     *   `lv_obj_add_style` and the `lv_obj_set_style_*` helpers insert a NORMAL
     *   style, and lv_obj_add_style() inserts normal styles at the *front* of the
     *   list. `get_prop_core()` walks from the front, skips any candidate whose
     *   state is not strictly greater than the best so far, and returns on an
     *   exact state match — so the style added EARLIEST usually wins, and the
     *   theme's was added first, when the widget was created.
     *
     *   A LOCAL style is stored ahead of all normal styles and is consulted
     *   before them, so it wins outright and is not subject to that comparison.
     */
    lv_obj_set_local_style_prop(s_arc, LV_STYLE_OUTLINE_WIDTH,
                                (lv_style_value_t){ .num = 0 },
                                LV_PART_MAIN | LV_STATE_EDITED);
    lv_obj_set_local_style_prop(s_arc, LV_STYLE_OUTLINE_WIDTH,
                                (lv_style_value_t){ .num = 0 },
                                LV_PART_MAIN | LV_STATE_FOCUSED);
    lv_obj_set_local_style_prop(s_arc, LV_STYLE_OUTLINE_WIDTH,
                                (lv_style_value_t){ .num = 0 },
                                LV_PART_MAIN | LV_STATE_FOCUS_KEY);
    lv_obj_set_local_style_prop(s_arc, LV_STYLE_BORDER_WIDTH,
                                (lv_style_value_t){ .num = 0 },
                                LV_PART_MAIN | LV_STATE_EDITED);
    lv_obj_set_local_style_prop(s_arc, LV_STYLE_BORDER_WIDTH,
                                (lv_style_value_t){ .num = 0 },
                                LV_PART_MAIN | LV_STATE_FOCUSED);
    lv_obj_set_local_style_prop(s_arc, LV_STYLE_BORDER_WIDTH,
                                (lv_style_value_t){ .num = 0 },
                                LV_PART_MAIN | LV_STATE_FOCUS_KEY);

    s_value_label = lv_label_create(screen);
    lv_obj_set_style_text_font(s_value_label, &lv_font_montserrat_28, LV_PART_MAIN);
    lv_obj_set_style_text_color(s_value_label, lv_color_white(), LV_PART_MAIN);
    lv_obj_center(s_value_label);

    s_unit_label = lv_label_create(screen);
    lv_obj_set_style_text_color(s_unit_label, lv_color_hex(0x8A97A6), LV_PART_MAIN);
    lv_obj_align(s_unit_label, LV_ALIGN_CENTER, 0, 34);

    s_hint = lv_label_create(screen);
    lv_obj_set_style_text_color(s_hint, lv_color_hex(0x5A6673), LV_PART_MAIN);
    lv_obj_align(s_hint, LV_ALIGN_BOTTOM_MID, 0, -16);

    s_page_label = lv_label_create(screen);
    lv_obj_set_style_text_color(s_page_label, lv_color_hex(0x8A97A6), LV_PART_MAIN);
    lv_obj_align(s_page_label, LV_ALIGN_TOP_MID, 0, 52);

    /* The arrows sit on the screen's equator, hard left and hard right, where
     * the circle is widest — the only place on a 360 px round panel with room
     * for a comfortable target that does not crowd the arc. */
    s_btn_prev = make_touch_button(screen, "<", -1, LV_ALIGN_LEFT_MID, 34);
    s_btn_next = make_touch_button(screen, ">",  1, LV_ALIGN_RIGHT_MID, -34);

    ESP_LOGI(TAG, "bring-up demo ready: display, touch, encoder, ring, audio, SD");

    /* The audio task owns the DAC while the tone page is up. It is created once
     * and sleeps on every other page. */
    /* Lower priority than the LVGL task (4): this is background audio, and it
     * must never be able to starve rendering — an I2S write that blocks at the
     * same priority as LVGL is enough to freeze the whole UI. */
    if (bsp_audio_out_is_ready()) {
        xTaskCreate(audio_task, "demo_tone", 4096, NULL, 3, NULL);
    }

    s_ui_ready = true;
    goto_page(PAGE_RING);
}
