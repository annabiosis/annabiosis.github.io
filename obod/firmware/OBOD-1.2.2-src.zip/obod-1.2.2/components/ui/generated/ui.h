/*
 * PLACEHOLDER UI — this file is meant to be overwritten.
 *
 * It exists so that a fresh clone builds and runs before SquareLine Studio has
 * ever been opened. It publishes the same contract the real export does:
 * a set of screen/object pointers and a single `ui_init()` entry point.
 *
 * `tools/squareline_sync.ps1` deletes everything in this folder and replaces
 * it with your Studio export. Nothing else in the firmware references anything
 * here except `ui_init()`, so replacing it cannot break the build.
 */

#ifndef UI_H
#define UI_H

#ifdef __cplusplus
extern "C" {
#endif

#include "lvgl.h"

/* --- Screens -------------------------------------------------------------- */
extern lv_obj_t *ui_MainScreen;
extern lv_obj_t *ui_SettingsScreen;

/* --- Main screen ---------------------------------------------------------- */
extern lv_obj_t *ui_ValueArc;
extern lv_obj_t *ui_ValueLabel;
extern lv_obj_t *ui_TitleLabel;
extern lv_obj_t *ui_SettingsButton;

/* --- Settings screen ------------------------------------------------------ */
extern lv_obj_t *ui_BrightnessSlider;
extern lv_obj_t *ui_BrightnessLabel;
extern lv_obj_t *ui_BackButton;

/*
 * Build the UI and load the first screen.
 *
 * Must be called under the LVGL lock — ui_app_init() takes care of that.
 */
void ui_init(void);

#ifdef __cplusplus
}
#endif

#endif /* UI_H */
