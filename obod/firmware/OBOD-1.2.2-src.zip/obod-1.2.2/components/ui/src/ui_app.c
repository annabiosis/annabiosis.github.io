/*
 * Bridge between the SquareLine export and the firmware — see ui_app.h.
 */

#include "ui_app.h"

#include <string.h>

#include "esp_log.h"

#include "bsp/bsp.h"

#include "ui.h"

static const char *TAG = "ui";

static ui_app_config_t s_config;
static lv_group_t     *s_group;
static lv_obj_t       *s_focused;
static lv_style_t     *s_focus_style;
static lv_style_t      s_owned_focus_style;
static bool            s_own_style;

/*
 * Cancels LVGL's built-in focus decoration.
 *
 * The default theme adds `outline_primary` — 2px, #F44336 (Material Red 500),
 * 50% opacity — on LV_STATE_FOCUS_KEY. That is drawn whether or not this
 * component draws its own indicator, so a page with a single control showed a
 * red frame even though the ring logic correctly declined to add anything.
 *
 * It is cleared with an object LOCAL style property, not with lv_obj_add_style
 * and not with the lv_obj_set_style_* helpers. Both of those insert a *normal*
 * style, and normal styles are inserted at the front of the object's style list
 * while `get_prop_core()` takes the first match — so the style added earliest
 * wins, and the theme's was added first, when the widget was created. Anything
 * application code adds afterwards loses. A local style is stored ahead of all
 * normal styles and is consulted before them, so it wins outright.
 *
 * Both states are cleared: the encoder sets FOCUSED|FOCUS_KEY, other input
 * devices set FOCUSED alone, and precedence prefers an exact state match over a
 * partial one, so each state needs its own entry.
 */
static bool valid_control(lv_obj_t *obj)
{
    return obj && lv_obj_is_valid(obj);
}

/* -------------------------------------------------------------------------- */
/* Focus detection                                                            */
/* -------------------------------------------------------------------------- */

/*
 * SquareLine builds every interactive control from one of these classes. The
 * list is deliberately explicit rather than "everything with CLICKABLE",
 * because SquareLine marks its container panels clickable too, and those would
 * then soak up every detent.
 */
static bool is_focusable_class(const lv_obj_t *obj)
{
    if (lv_obj_check_type(obj, &lv_button_class))     return true;
    if (lv_obj_check_type(obj, &lv_slider_class))     return true;
    if (lv_obj_check_type(obj, &lv_switch_class))     return true;
    if (lv_obj_check_type(obj, &lv_checkbox_class))   return true;
    if (lv_obj_check_type(obj, &lv_dropdown_class))   return true;
    if (lv_obj_check_type(obj, &lv_roller_class))     return true;
    if (lv_obj_check_type(obj, &lv_arc_class))        return true;
    if (lv_obj_check_type(obj, &lv_spinbox_class))    return true;
    if (lv_obj_check_type(obj, &lv_textarea_class))   return true;
    if (lv_obj_check_type(obj, &lv_table_class))      return true;
#if LVGL_VERSION_MAJOR >= 9
    /* lv_btnmatrix was renamed in LVGL 9. */
    if (lv_obj_check_type(obj, &lv_buttonmatrix_class)) return true;
#else
    if (lv_obj_check_type(obj, &lv_btnmatrix_class))    return true;
#endif
    return false;
}

static bool is_eligible(lv_obj_t *obj)
{
    /* Hidden widgets cannot take focus, and a disabled one that steals a
     * detent is worse than one that is simply absent.
     *
     * LVGL 9.6 deprecated the generic lv_obj_has_flag() in favour of dedicated
     * per-flag predicates; the old spelling still works but warns. */
    if (lv_obj_is_hidden(obj)) {
        return false;
    }
    if (lv_obj_has_state(obj, LV_STATE_DISABLED)) {
        return false;
    }
    if (!lv_obj_is_clickable(obj)) {
        return false;
    }
    return is_focusable_class(obj);
}

/* -------------------------------------------------------------------------- */
/* Focus indicator                                                            */
/* -------------------------------------------------------------------------- */

/*
 * The focus ring.
 *
 * Drawn as an outline plus an outward glow rather than a plain rectangle.
 * Three properties matter on a 360px round screen:
 *
 *   - outline, not border, so adding and removing it cannot reflow the layout,
 *     which would make the UI jitter on every detent;
 *   - the corner radius tracks the widget's own, so a round arc gets a ring
 *     and a rectangular control gets a rounded rectangle;
 *   - the glow spreads OUTWARD (shadow_spread), so it never bleeds into the
 *     widget's interior, where it would read as a smudge over the artwork.
 *
 * Shown only when the knob has more than one target — see apply_focus().
 */
static lv_coord_t s_ring_radius = -1;

static void ensure_focus_style(void)
{
    if (s_focus_style) {
        return;
    }

    lv_style_init(&s_owned_focus_style);

    lv_style_set_outline_width(&s_owned_focus_style, 3);
    lv_style_set_outline_color(&s_owned_focus_style, lv_color_hex(0x38E1FF));
    lv_style_set_outline_opa(&s_owned_focus_style, LV_OPA_COVER);
    lv_style_set_outline_pad(&s_owned_focus_style, 1);

    /*
     * The glow is the same hue at low opacity. A wider, softer halo around a
     * crisp ring is what makes it read as light rather than as a border.
     */
    lv_style_set_shadow_color(&s_owned_focus_style, lv_color_hex(0x38E1FF));
    lv_style_set_shadow_width(&s_owned_focus_style, 16);
    lv_style_set_shadow_spread(&s_owned_focus_style, 2);
    lv_style_set_shadow_opa(&s_owned_focus_style, LV_OPA_30);
    lv_style_set_shadow_offset_x(&s_owned_focus_style, 0);
    lv_style_set_shadow_offset_y(&s_owned_focus_style, 0);

    s_focus_style = &s_owned_focus_style;
    s_own_style = true;
}

/*
 * Match the ring to the widget it surrounds.
 *
 * LVGL 9 has no outline radius of its own — the outline is drawn as a rounded
 * rectangle following the widget's shape radius. So the shape is chosen here on
 * the style's radius property.
 */
static void shape_ring(lv_obj_t *obj)
{
    if (!s_own_style) {
        return;     /* The application supplied its own style; do not touch it. */
    }

    const lv_coord_t w = lv_obj_get_width(obj);
    const lv_coord_t h = lv_obj_get_height(obj);
    const lv_coord_t shorter = w < h ? w : h;

    /*
     * A square-ish target is assumed to read as round — the arc on a knob
     * screen is the case that matters, and it is square. Anything else gets a
     * generous corner rather than a hard rectangle. Both are clamped to half
     * the shorter side, which is LVGL's own limit, so a single value stays
     * meaningful for either case.
     */
    const bool squarish = shorter > 40 &&
                          (w > h ? w - h : h - w) <= shorter / 4;

    const lv_coord_t radius = squarish
                            ? LV_RADIUS_CIRCLE
                            : LV_MIN((lv_coord_t)18, (lv_coord_t)(shorter / 2));

    if (radius == s_ring_radius) {
        return;
    }

    s_ring_radius = radius;
    lv_style_set_radius(&s_owned_focus_style, radius);

    /*
     * The halo follows the ring alone. A rectangular target does not get one:
     * its outline sits inset from the corners, so an outward spread there still
     * lands inside the shape and shows as a coloured patch rather than light.
     */
    lv_style_set_shadow_width(&s_owned_focus_style, squarish ? 16 : 0);
    lv_style_set_shadow_spread(&s_owned_focus_style, squarish ? 2 : 0);
}

static void clear_rings(void);
static void mark_ring(lv_obj_t *obj);

static void apply_focus(lv_obj_t *obj)
{
    if (obj == s_focused) {
        return;
    }

    if (valid_control(s_focused)) {
        lv_obj_remove_style(s_focused, s_focus_style, LV_PART_MAIN);
    }

    s_focused = obj;

    mark_ring(s_focused);
}

/*
 * Decide the ring for the currently focused widget and apply it.
 *
 * Split out because it has to run from more than one place. Waiting for the
 * next LV_EVENT_FOCUSED is not enough: a page change rebuilds the group and can
 * leave the focus where it was, so no event fires and a ring from the previous,
 * multi-control page would stay on screen. That is exactly the bug this fixes —
 * `ui_app_refresh_focus_group()` now re-evaluates instead of trusting an event.
 */
static void mark_ring(lv_obj_t *obj)
{
    if (!valid_control(obj) || !s_focus_style) {
        return;
    }

    /*
     * With one control there is nothing to disambiguate — the knob always drives
     * it and a tap cannot take it away — so the ring would be decoration. It
     * appears once a second candidate makes "which control does the knob drive?"
     * a real question.
     */
    if (bsp_encoder_focusable_count() > 1) {
        shape_ring(obj);
        lv_obj_add_style(obj, s_focus_style, LV_PART_MAIN);
    } else {
        lv_obj_remove_style(obj, s_focus_style, LV_PART_MAIN);
    }
}

/*
 * Strip the ring from every object in the group.
 *
 * Used when the number of candidates drops back to one: the ring may have been
 * applied to a widget that is no longer the focused one, and leaving it there
 * would show a highlight on a control the knob does not drive.
 */
static void clear_rings(void)
{
    if (!s_focus_style || !s_group) {
        return;
    }

    const uint32_t count = lv_group_get_obj_count(s_group);
    for (uint32_t i = 0; i < count; i++) {
        lv_obj_t *obj = lv_group_get_obj_by_index(s_group, i);
        if (valid_control(obj)) {
            lv_obj_remove_style(obj, s_focus_style, LV_PART_MAIN);
        }
    }
}

/* -------------------------------------------------------------------------- */
/* Event hooks                                                                */
/* -------------------------------------------------------------------------- */

static void focus_event_cb(lv_event_t *e)
{
    lv_obj_t *target = lv_event_get_target_obj(e);

    apply_focus(target);
}

/*
 * Attach the focus hooks.
 *
 * FOCUSED/DEFOCUSED carry the focus style: the focus group of this interface has a single
 * member, so they fire when the group is rebuilt rather than when a hand moves.
 */
static void attach_hooks(lv_obj_t *obj)
{
    lv_obj_add_event_cb(obj, focus_event_cb, LV_EVENT_FOCUSED,   NULL);
    lv_obj_add_event_cb(obj, focus_event_cb, LV_EVENT_DEFOCUSED, NULL);

    /*
     * Strip the theme's focus decoration from every focusable widget, so the
     * only focus indicator on screen is this component's — or none, when there
     * is a single control.
     *
     * Outstanding on LV_STATE_EDITED, measured from the resolved style: an
     * encoder in edit mode sets FOCUSED|EDITED, and it is EDITED that carries
     * the theme's red outline. Every red state observed contained 0x20; no state
     * without it was red.
     *
     * Local style properties, NOT a shared style added with lv_obj_add_style:
     * normal styles are inserted at the FRONT of the object's style list and
     * `get_prop_core()` prefers the earliest-added among equal candidates, so a
     * style the theme added at widget creation beats one the application adds
     * later. A local style is stored ahead of all normal styles and is consulted
     * first, so it wins.
     */
    lv_obj_set_local_style_prop(obj, LV_STYLE_OUTLINE_WIDTH,
                                (lv_style_value_t){ .num = 0 },
                                LV_PART_MAIN | LV_STATE_EDITED);
    lv_obj_set_local_style_prop(obj, LV_STYLE_OUTLINE_WIDTH,
                                (lv_style_value_t){ .num = 0 },
                                LV_PART_MAIN | LV_STATE_FOCUSED);
    lv_obj_set_local_style_prop(obj, LV_STYLE_OUTLINE_WIDTH,
                                (lv_style_value_t){ .num = 0 },
                                LV_PART_MAIN | LV_STATE_FOCUS_KEY);
    lv_obj_set_local_style_prop(obj, LV_STYLE_BORDER_WIDTH,
                                (lv_style_value_t){ .num = 0 },
                                LV_PART_MAIN | LV_STATE_EDITED);
    lv_obj_set_local_style_prop(obj, LV_STYLE_BORDER_WIDTH,
                                (lv_style_value_t){ .num = 0 },
                                LV_PART_MAIN | LV_STATE_FOCUSED);
    lv_obj_set_local_style_prop(obj, LV_STYLE_BORDER_WIDTH,
                                (lv_style_value_t){ .num = 0 },
                                LV_PART_MAIN | LV_STATE_FOCUS_KEY);
}

static void detach_hooks(lv_obj_t *obj)
{
    lv_obj_remove_event_cb_with_user_data(obj, focus_event_cb, NULL);
}

/* -------------------------------------------------------------------------- */
/* Group management                                                           */
/* -------------------------------------------------------------------------- */

static void collect_focusable(lv_obj_t *parent)
{
    const uint32_t child_count = lv_obj_get_child_count(parent);

    for (uint32_t i = 0; i < child_count; i++) {
        lv_obj_t *child = lv_obj_get_child(parent, (int32_t)i);
        if (!child) {
            continue;
        }

        if (is_eligible(child)) {
            lv_group_add_obj(s_group, child);
            attach_hooks(child);
        }

        /* Keep descending: SquareLine nests buttons inside containers. */
        collect_focusable(child);
    }
}

void ui_app_refresh_focus_group(void)
{
    if (!s_group) {
        return;
    }

    /* Start from a clean slate: the previous screen's widgets are gone and
     * stale pointers in the group would fault on the next detent. */
    lv_group_remove_all_objs(s_group);
    s_focused = NULL;

    lv_obj_t *screen = lv_screen_active();
    if (!screen) {
        return;
    }

    ensure_focus_style();
    collect_focusable(screen);

    if (s_config.auto_focus_first) {
        lv_group_focus_next(s_group);
    }

    /*
     * Put the group back into edit mode.
     *
     * Moving focus clears it — LVGL does that inside lv_group_focus_obj() and
     * focus_next_core(), because on a normal device leaving edit mode is how you
     * get back to navigating. On this board edit mode is permanent: there is no
     * button, so nothing can restore it, and a rotation while it is clear moves
     * the focus instead of changing the value.
     *
     * So the module that clears it has to clear up after itself. The BSP also
     * asserts this once per input read as a safety net, but relying on that would
     * leave a window between the page change and the next detent in which the
     * knob does the wrong thing — and would make the BSP's warning fire on every
     * healthy boot, which is how a diagnostic stops being read.
     */
    if (lv_group_get_obj_count(s_group) > 0 && !lv_group_get_editing(s_group)) {
        lv_group_set_editing(s_group, true);
    }

    /*
     * Re-evaluate the ring instead of relying on a focus event.
     *
     * A page change can leave the focus on an object that survives it, in which
     * case no LV_EVENT_FOCUSED fires and a ring left over from the previous
     * page stays on screen — showing a highlight even on a page with a single
     * control, where it should be absent entirely. Deciding it here, from the
     * current candidate count, removes that whole class of stale indicator.
     */
    clear_rings();
    if (valid_control(s_focused)) {
        mark_ring(s_focused);
    }

    ESP_LOGD(TAG, "focus group rebuilt: %d widget(s)", (int)lv_group_get_obj_count(s_group));
}

bool ui_app_add_focusable(lv_obj_t *obj)
{
    if (!s_group || !obj) {
        return false;
    }
    if (lv_obj_get_group(obj) == s_group) {
        return true;
    }

    lv_group_add_obj(s_group, obj);
    attach_hooks(obj);
    return true;
}

bool ui_app_remove_focusable(lv_obj_t *obj)
{
    if (!s_group || !obj) {
        return false;
    }

    detach_hooks(obj);
    lv_group_remove_obj(obj);

    if (s_focused == obj) {
        s_focused = NULL;
    }
    return true;
}

lv_group_t *ui_app_get_group(void)
{
    return s_group;
}

lv_obj_t *ui_app_get_focused(void)
{
    return s_focused;
}

void ui_app_set_focus_style(lv_style_t *style)
{
    if (s_own_style) {
        lv_style_reset(&s_owned_focus_style);
        s_own_style = false;
    }

    if (valid_control(s_focused)) {
        if (style) {
            lv_obj_add_style(s_focused, style, LV_PART_MAIN);
        } else if (s_focus_style) {
            lv_obj_remove_style(s_focused, s_focus_style, LV_PART_MAIN);
        }
    }

    s_focus_style = style;
}

void ui_app_load_screen(lv_obj_t *screen, lv_screen_load_anim_t anim)
{
    if (!screen) {
        return;
    }

    if (anim == LV_SCR_LOAD_ANIM_NONE) {
        lv_screen_load(screen);
    } else {
        /* 300 ms reads as deliberate without feeling slow on a knob. */
        lv_screen_load_anim(screen, anim, 300, 0, false);
    }

    ui_app_refresh_focus_group();
}

/* -------------------------------------------------------------------------- */
/* Init                                                                       */
/* -------------------------------------------------------------------------- */

esp_err_t ui_app_init(const ui_app_config_t *config)
{
    return ui_app_init_with_screen(config, NULL);
}

esp_err_t ui_app_init_with_screen(const ui_app_config_t *config, ui_app_screen_fn build)
{
    static const ui_app_config_t defaults = UI_APP_CONFIG_DEFAULT();
    s_config = config ? *config : defaults;

    if (!bsp_display_get_lvgl_display()) {
        ESP_LOGE(TAG, "display is not up — call bsp_init() first");
        return ESP_ERR_INVALID_STATE;
    }
    if (!bsp_encoder_is_ready()) {
        ESP_LOGE(TAG, "encoder is not up — enable features.encoder in bsp_init()");
        return ESP_ERR_INVALID_STATE;
    }

    s_group = bsp_encoder_get_group();
    if (!s_group) {
        ESP_LOGE(TAG, "no encoder group");
        return ESP_ERR_INVALID_STATE;
    }

    if (!bsp_display_lock(0)) {
        return ESP_FAIL;
    }

    /* The SquareLine entry point, or the application's own builder. Either way
     * everything created lands on the active screen, which is why the group is
     * rebuilt afterwards. */
    if (build) {
        build();
    } else {
        ui_init();
    }

    ensure_focus_style();
    ui_app_refresh_focus_group();

    bsp_display_unlock();

    ESP_LOGI(TAG, "%s ready, %d focusable widget(s) on screen",
             build ? "application screen" : "SquareLine UI",
             (int)lv_group_get_obj_count(s_group));
    return ESP_OK;
}
