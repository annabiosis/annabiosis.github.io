/*
 * midi_in.c — USB MIDI device: notes in, and the transport and clock with them.
 *
 * The shape of this file is IDF's own USB-MIDI example
 * (examples/peripherals/usb/device/tusb_midi): the descriptors, the interface
 * and endpoint numbering and the read loop are taken from it rather than
 * invented, because the descriptor layout is a specification and a plausible
 * variation of it is a device the host enumerates and then refuses to talk to.
 *
 * What differs is what the read loop DOES with a packet. The example logs every
 * one; this parses note on and note off out of it, reads the channel to decide
 * which part the note belongs to — channel 1 is the lead, channel 2 is the
 * percussion — and hands the note to the instrument. Four SYSTEM REALTIME bytes are
 * acted on as well, because they are the transport and the clock: 0xF8 is the tick
 * the instrument measures its tempo from, 0xFA and 0xFB start it, and 0xFC stops
 * it. Everything else about the traffic arrives, is recognised as something this
 * instrument has no use for and is dropped: a pitch bend, a control change, a SysEx
 * dump, and a note on any of the other fourteen channels. See midi_message() for
 * why the unassigned channels are silent rather than guessed at, and midi_feed_byte()
 * for the one thing that makes the realtime bytes unlike every other message on the
 * wire — they may arrive in the middle of one.
 *
 * WHY A TASK READS AND NOT A CALLBACK
 *   TinyUSB's receive callback runs in the USB stack's own task, and the
 *   example's polling loop is the pattern that is written down and tested for
 *   this class. Reading from a task of our own also keeps the whole input path
 *   in one place that can be read top to bottom: a packet becomes a note here,
 *   and the note becomes sound somewhere else entirely.
 *
 *   The task sleeps one tick between polls. The tick is 1 ms in this build
 *   (CONFIG_FREERTOS_HZ=1000), which is far below the block rate of the audio
 *   task, so polling adds nothing to the latency worth counting: what a player
 *   feels is the 64-byte host packet interval, not this loop.
 *
 * NOTHING HERE BLOCKS, ALLOCATES OR LOGS IN THE DATA PATH
 *   A note is handed on by writing four bytes into a ring and bumping an index.
 *   The only lines that could allocate or block are the ones that run once at
 *   start, and the one log line in the read loop, which reports a MOUNT CHANGE
 *   and therefore happens twice in a session rather than once per note.
 *
 * THE READER IS PARKED, NOT DELETED, WHEN THE INPUT IS OFF
 *   The task is created on the first enable and then lives for the life of the
 *   firmware, blocked on a task notification while the input is off. Deleting it
 *   and creating it again on every tap would spend a 4 KB stack and a fresh task
 *   handle each time, and — worse — the stack would be freed while the task was
 *   inside tud_task()'s own machinery on the other core. A task waiting on a
 *   notification it will be given is not running at all, which is the property
 *   the uninstall below needs: it must be able to prove the reader has left the
 *   stack alone before the stack is taken away. See midi_in_set_enabled().
 */

#include "midi_in.h"

#include <stdbool.h>
#include <stdint.h>

#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "tinyusb.h"
#include "tinyusb_default_config.h"

#include "synth_app.h"

static const char *TAG = "midi";

/* -------------------------------------------------------------------------- */
/* TinyUSB descriptors                                                        */
/* -------------------------------------------------------------------------- */

/* Interface counter. A MIDI function is always two interfaces — the audio
 * control interface that carries the class-specific descriptors and the MIDI
 * streaming interface that carries the jacks — and TUD_MIDI_DESCRIPTOR() emits
 * both, so ITF_COUNT is 2 and not 1. */
enum interface_count {
#if CFG_TUD_MIDI
    ITF_NUM_MIDI = 0,
    ITF_NUM_MIDI_STREAMING,
#endif
    ITF_COUNT
};

/* Endpoint numbers. EPNUM_MIDI is used twice: the OUT endpoint the host writes
 * notes to and, with the 0x80 bit, the IN endpoint this device never sends on.
 * The IN endpoint exists anyway — the class requires both jacks to be present —
 * which is why it is still declared in the descriptor below. */
enum usb_endpoints {
    EP_EMPTY = 0,
#if CFG_TUD_MIDI
    EPNUM_MIDI,
#endif
};

#define TUSB_DESCRIPTOR_TOTAL_LEN (TUD_CONFIG_DESC_LEN + CFG_TUD_MIDI * TUD_MIDI_DESC_LEN)

/* The MIDI jack's name, as the host shows it, is a string descriptor, and its
 * index is named here so the descriptor below does not carry a bare 4. */
#define MIDI_STR_INDEX 4

/* A FIXED serial number, deliberately. The example suggests the chip id, and
 * that is the right answer for a product with several units; here it would mean
 * a real dependency (esp_read_mac) and, worse, a device that the host sees as a
 * NEW device after every reflash — a fresh node in the DAW's port list each
 * time, with the previous one left behind as a ghost. One board, one name. */
static const char *s_str_desc[5] = {
    /* 0: the supported language, English (0x0409) */
    (char[]){0x09, 0x04},
    "OBOD",             /* 1: manufacturer */
    "OBOD synth",       /* 2: product */
    "OBOD0001",         /* 3: serial */
    "OBOD MIDI IN",     /* 4: the MIDI jack */
};

/* One configuration, one MIDI function, no bus power requested beyond the
 * default. The endpoint size is the full-speed maximum of 64 bytes: MIDI
 * messages are 4 bytes on the wire, so this is not a buffer to be tuned but the
 * packet size the class is specified with. */
static const uint8_t s_midi_cfg_desc[] = {
    /* Configuration number, interface count, string index, total length,
     * attribute, power in mA */
    TUD_CONFIG_DESCRIPTOR(1, ITF_COUNT, 0, TUSB_DESCRIPTOR_TOTAL_LEN, 0, 100),

    /* Interface number, string index, EP Out & EP In address, EP size */
    TUD_MIDI_DESCRIPTOR(ITF_NUM_MIDI, MIDI_STR_INDEX, EPNUM_MIDI,
                        (0x80 | EPNUM_MIDI), 64),
};

#if (TUD_OPT_HIGH_SPEED)
/* This chip is full-speed only, so this descriptor is never selected. It is
 * kept because TUD_OPT_HIGH_SPEED is a property of the TinyUSB build rather
 * than of the target: if a future board is high-speed, the qualifier has to
 * exist here or the device falls back with an error the host reports as
 * "unknown device" and nothing else. */
static const uint8_t s_midi_hs_cfg_desc[] = {
    TUD_CONFIG_DESCRIPTOR(1, ITF_COUNT, 0, TUSB_DESCRIPTOR_TOTAL_LEN, 0, 100),
    TUD_MIDI_DESCRIPTOR(ITF_NUM_MIDI, MIDI_STR_INDEX, EPNUM_MIDI,
                        (0x80 | EPNUM_MIDI), 512),
};
#endif /* TUD_OPT_HIGH_SPEED */

/* -------------------------------------------------------------------------- */
/* State                                                                      */
/* -------------------------------------------------------------------------- */

/* Above the read loop, because that loop is the first reader of all four, and below the
 * descriptors, because none of this has anything to do with them.
 *
 *   s_task       the reader. Created on the first enable and parked — not deleted — while
 *                the input is off, so a toggle costs no allocation at all.
 *   s_installed  the device stack is installed and has not been uninstalled. Its own flag
 *                rather than s_enabled, because the two answer different questions: this
 *                one is "may install() be called", that one is "may tud_* be called".
 *   s_enabled    whether the reader may touch the stack. Cleared BEFORE the reader is asked
 *                to stop, so the answer cannot be stale by the time the reader looks.
 *   s_parked     written by the reader, read by the caller: true while the reader is parked
 *                and provably out of every tud_* call.
 *
 * s_enabled and s_parked are the two that cross between tasks, which is what their volatile
 * says; s_task and s_installed are only ever touched by whichever task calls
 * midi_in_set_enabled(), which is main once and then the screen, never two at a time. */
static TaskHandle_t  s_task;
static bool          s_installed;
static volatile bool s_enabled;
static volatile bool s_parked;

/* -------------------------------------------------------------------------- */
/* Reading                                                                     */
/* -------------------------------------------------------------------------- */

/* The status nibbles this input acts on. Everything else — aftertouch, control
 * change, program change, pitch bend, the system common messages and all but four
 * of the realtime ones — is read off the endpoint and dropped, which is not an
 * omission: they are neither notes nor the transport, and the instrument has no
 * parameter a host should be able to reach. The one MIDI setting there is — MIDI IN
 * on the OPTIONS page — turns the whole input on and off rather than mapping any of
 * this, so nothing here is configurable.
 *
 * THE LOW NIBBLE OF A NOTE MESSAGE IS ITS CHANNEL, and the one thing this input
 * does with it is decide WHICH PART PLAYS. Channel 1 is the lead and channel 2 is
 * the percussion — two channels, two parts, and the reason it is a split rather than a
 * setting: a drum track that arrived on the lead's three voices would be a melody,
 * and a lead line that arrived on the drum would be a rhythm section. One channel
 * per part is the whole of the arrangement, and neither part needs a knob.
 *
 * CHANNELS 3 TO 16 ARE DROPPED, deliberately. "Every channel is accepted" was the
 * right answer while there was one part to accept them into; with two, a note from
 * a channel nobody assigned has no honest destination, and the default is the one
 * that would be worst: a DAW sends its drum tracks on channel 10 as a matter of
 * course, and an input that let them fall through to the lead would turn a drum
 * part into a melody the moment someone plumbed it up. Silence is a better answer
 * than the wrong part, and it is silent by construction rather than reported: the
 * note is dropped in midi_message() and nothing here logs it or counts it, which is
 * what the paragraph below is about.
 *
 * The channel byte itself is not logged and not counted per channel: a log line in
 * this path is the one thing that must not happen per note, and the input's only
 * setting says whether the input exists rather than which channel means what, so
 * there is nothing a per-channel count could report against. */
#define MIDI_STATUS_NOTE_OFF 0x80
#define MIDI_STATUS_NOTE_ON  0x90
#define MIDI_STATUS_MASK     0xF0
#define MIDI_CHANNEL_MASK    0x0F

#define MIDI_CHANNEL_LEAD    0    /* channel 1 as a musician counts it */
#define MIDI_CHANNEL_PERC    1    /* channel 2 */

/* System realtime: the four bytes this input acts on, and the shape of the whole class.
 * Everything from 0xF8 upwards is ONE byte that may arrive anywhere in the stream and is
 * never part of the message around it, which is what the parser below is built on. The
 * others of the class — 0xF9, 0xFD, 0xFE active sensing and 0xFF reset — arrive too; they
 * are recognised and dropped by midi_realtime(). */
#define MIDI_REALTIME_FIRST    0xF8
#define MIDI_REALTIME_CLOCK    0xF8
#define MIDI_REALTIME_START    0xFA
#define MIDI_REALTIME_CONTINUE 0xFB
#define MIDI_REALTIME_STOP     0xFC

/* Where a SysEx dump starts and stops. Nothing here is acted on, but the start of one
 * CANCELS the running status of the note stream: that is the specification, and an input
 * that did not know it would read a dump's data bytes as more of the last note played. */
#define MIDI_SYSEX_START       0xF0
#define MIDI_SYSEX_END         0xF7

/* THE PACKET'S OWN BYTE COUNT, in the low nibble of its first byte — the Code Index
 * Number, with the Cable Number in the high one. It is the specification's table (USB MIDI
 * 1.0, table 4-1) rather than a guess: 0x8 is a three-byte note off, 0x9 a three-byte note
 * on, 0xC a two-byte program change, 0xF one byte.
 *
 * IT IS READ HERE BECAUSE THE PADDING IS NOT ALWAYS ZERO. A system realtime byte is a
 * one-byte message in a four-byte packet, so two bytes behind it are padding — and feeding
 * those to the parser as data is a note off at velocity zero for whatever status happens to
 * be current, because zero padding IS a velocity of zero. This input never sends anything,
 * so the cable number is always 0 and the CIN alone says how much of the packet is a
 * message. */
static const uint8_t s_cin_bytes[16] = {
    0, 0, 2, 3, 3, 1, 2, 3,   /* 0x0..0x7: reserved, system common and SysEx */
    3, 3, 3, 3, 2, 2, 3, 1,   /* 0x8..0xF: the channel voice messages, then one byte */
};

/*
 * THE PARSER, AND WHY THERE IS ONE NOW.
 *
 * A USB-MIDI packet normally carries one complete message, and the first cut of this file
 * read packet[1..3] as (status, data, data) and kept nothing between packets. That is
 * enough for notes and it is not enough for the clock, for one reason written down in the
 * MIDI specification: SYSTEM REALTIME BYTES MAY ARRIVE BETWEEN THE BYTES OF ANOTHER
 * MESSAGE. A host that interleaves clock with a played chord produces a packet that is not
 * one message — 0x90, 0xF8, 0x3C — and a parser that took the three bytes in order would
 * read the clock as a note number, would play the byte that follows it as the velocity of
 * the status that was current, and would come out of the packet with its stream out of step
 * with the host.
 *
 * So the bytes are parsed as the STREAM they are, one at a time, with the running status
 * the wire has always had: a status byte starts a message, the data bytes after it complete
 * it, and a completed message leaves the status running for the next one. Every branch
 * below is one of three cases and nothing else:
 *
 *   - 0xF8 and up is realtime. It is acted on the moment it is seen and NOTHING ELSE
 *     CHANGES: no status is started, no data byte is accumulated, no half-assembled message
 *     is disturbed. That is the whole of the trap above, and it is one branch;
 *   - any other status byte ENDS whatever was being assembled, running status included. For
 *     a channel message that is the ordinary case — every note message this input plays
 *     carries its status — and for a system common message it is the specification;
 *   - a data byte with no running status behind it is not a message and is dropped, which
 *     is also what makes the tail of a dump harmless.
 *
 * NOTHING HERE PARSES A SYSTEM COMMON MESSAGE, deliberately: the only messages this input
 * acts on are the notes and the four realtime ones, and the rest are recognised so that
 * they cannot be mistaken for anything. SysEx takes a flag rather than a byte count because
 * it is the one message that spans packets and therefore has to survive between them.
 */
static uint8_t s_status;      /* running status; 0 = none */
static uint8_t s_data[2];
static uint8_t s_data_n;      /* data bytes accumulated so far */
static uint8_t s_data_need;   /* data bytes the current message wants */
static bool    s_sysex;       /* inside a dump: its data bytes are not notes */

/*
 * The four realtime bytes that mean something, and the reason they are a function of their
 * own: they are the one place in this file allowed to act on a message while it is still
 * half read. Nothing here checks the transport's own state or refuses a message the
 * instrument is not ready for — a START that arrives while it is already running is the
 * host being a step ahead of nothing — and nothing here waits: each call places an event in
 * the instrument's ring and returns, exactly as a note does.
 */
static void midi_realtime(uint8_t byte)
{
    switch (byte) {
    case MIDI_REALTIME_CLOCK:
        synth_app_midi_clock();
        return;
    case MIDI_REALTIME_START:
        synth_app_midi_transport(SYNTH_MIDI_TRANSPORT_START);
        return;
    case MIDI_REALTIME_CONTINUE:
        synth_app_midi_transport(SYNTH_MIDI_TRANSPORT_CONTINUE);
        return;
    case MIDI_REALTIME_STOP:
        synth_app_midi_transport(SYNTH_MIDI_TRANSPORT_STOP);
        return;
    default:
        /* Realtime, and not one of those four: dropped, with the parser's state left
         * exactly as it was — the same rule the clock is handled by. */
        return;
    }
}

/*
 * One completed note message, and the whole of what this input plays. Everything the
 * comment above says about the channel, and about a velocity of zero, is here and nowhere
 * else.
 */
static void midi_message(uint8_t status, uint8_t note, uint8_t velocity)
{
    /* The part, from the channel the message was sent on. Settled before the note
     * is looked at, because an unassigned channel is not a note at all. */
    synth_midi_part_t part;
    const uint8_t channel = status & MIDI_CHANNEL_MASK;

    if (channel == MIDI_CHANNEL_LEAD) {
        part = SYNTH_MIDI_LEAD;
    } else if (channel == MIDI_CHANNEL_PERC) {
        part = SYNTH_MIDI_PERC;
    } else {
        return;
    }

    /* A NOTE ON at velocity zero is a NOTE OFF. Hosts and keyboards both use it
     * — it is how a three-byte message is reused for the release — so an input
     * that did not know this would hold every such note forever and the lead
     * would be stuck on the last one played. It matters to the drum too: a
     * channel-2 note held at zero velocity must not strike. */
    if ((status & MIDI_STATUS_MASK) == MIDI_STATUS_NOTE_ON && velocity > 0) {
        synth_app_midi_note_on((int)note, (float)velocity / 127.0f, part);
        return;
    }

    if ((status & MIDI_STATUS_MASK) == MIDI_STATUS_NOTE_ON
        || (status & MIDI_STATUS_MASK) == MIDI_STATUS_NOTE_OFF) {
        synth_app_midi_note_off((int)note, part);
    }
}

/*
 * One byte at a time, in the order it arrived. The state kept between calls is the running
 * status and the data bytes of a message that is not finished yet, and the one thing that
 * may leave that state untouched is a realtime byte — which is the whole point of the
 * function.
 */
static void midi_feed_byte(uint8_t byte)
{
    if (byte >= MIDI_REALTIME_FIRST) {
        midi_realtime(byte);
        return;
    }

    if (byte >= 0x80) {
        /* A status byte ends whatever was being assembled, and running status is
         * part of "whatever": which of the two cases above it is decides whether
         * that matters. */
        s_status = 0;
        s_data_n = 0;
        s_data_need = 0;

        if (byte == MIDI_SYSEX_START) {
            s_sysex = true;
            return;
        }
        if (byte == MIDI_SYSEX_END) {
            s_sysex = false;
            return;
        }
        if (byte >= MIDI_SYSEX_START) {
            /* System common. Not acted on, and its data bytes are dropped below
             * because nothing is running. */
            return;
        }

        s_sysex = false;   /* a channel message ends a dump, whatever else it is */
        s_status = byte;
        /* Program change and channel pressure take ONE data byte and every other
         * channel message takes two. Neither is acted on; the count is here because
         * the parser has to know where a message ends to find the next one. */
        s_data_need = ((byte & MIDI_STATUS_MASK) == 0xC0
                       || (byte & MIDI_STATUS_MASK) == 0xD0) ? 1u : 2u;
        return;
    }

    if (s_sysex || s_status == 0) {
        return;
    }

    s_data[s_data_n] = byte;
    s_data_n++;
    if (s_data_n < s_data_need) {
        return;
    }

    /* Complete, and the status stays where it was: the next data byte without a
     * status of its own begins the next message, which is running status. */
    s_data_n = 0;
    midi_message(s_status, s_data[0], s_data[1]);
}

/*
 * One 4-byte USB-MIDI event packet: a cable/CIN byte, then up to three bytes of message.
 * As much of it as its CIN says is real is fed to the parser in order; the padding behind a
 * one-byte message is not, which is the second reason the table above is here.
 */
static void midi_handle_packet(const uint8_t *packet)
{
    const uint8_t bytes = s_cin_bytes[packet[0] & 0x0F];

    for (uint8_t i = 0; i < bytes; i++) {
        midi_feed_byte(packet[1 + i]);
    }
}

/*
 * The read loop.
 *
 * The MIDI interface always exposes an OUT jack whether or not the host uses
 * it, and an OUT endpoint nobody reads NAKs the host until it gives up. So the
 * endpoint is drained all the way down every time round rather than one message
 * per look: the loop runs at 1 kHz and a chord is three messages in the same
 * millisecond, which would otherwise be spread over three polls.
 *
 * It ends every pass by asking whether it is still wanted, and parks itself if
 * it is not. That check is the whole of the stop: it is placed AFTER the drain
 * and BEFORE the notification wait, so once s_parked is visible the task is
 * provably not inside a tud_* call and not about to make one — which is what
 * lets the caller uninstall the stack underneath it. Reading tud_midi_mounted()
 * or tud_midi_available() after midi_in_set_enabled(false) would be a call into
 * a stack that has been torn down, and this is the line that rules it out.
 */
static void midi_task(void *arg)
{
    (void)arg;

    uint8_t packet[4];
    bool mounted = false;

    for (;;) {
        /*
         * The one thing that cannot be seen from the outside is whether the
         * host enumerated the device at all: "no notes" and "no device" are the
         * same symptom from the keyboard, and this line is what tells them
         * apart. Logged only when it changes, so it is two lines in a session.
         */
        const bool now = tud_midi_mounted();
        if (now != mounted) {
            mounted = now;
            ESP_LOGI(TAG, "%s", mounted ? "host attached" : "host detached");
        }

        while (tud_midi_available()) {
            if (tud_midi_packet_read(packet)) {
                midi_handle_packet(packet);
            }
        }

        vTaskDelay(1);

        if (!s_enabled) {
            /* A new stack counts as a new host: the mount line is worth printing again
             * after an off/on, and the local flag is what suppresses it. */
            mounted = false;
            s_parked = true;
            ulTaskNotifyTake(pdTRUE, portMAX_DELAY);
            s_parked = false;
        }
    }
}

/* -------------------------------------------------------------------------- */
/* Start and stop                                                             */
/* -------------------------------------------------------------------------- */

/* Pinned to the core the audio task is NOT on, and below it in priority: a note
 * read must never be able to delay a block. Nothing here needs the other core's
 * cache, and the ring the note is written into is what makes the two tasks
 * independent of each other's timing. */
#define MIDI_TASK_CORE   0
#define MIDI_TASK_PRIO   5
#define MIDI_TASK_STACK  4096

/* How long the caller waits for the reader to park itself, in ticks. One tick is
 * 1 ms in this build and the loop is one tick long, so two would be enough; this
 * is the point at which the answer is "something is wrong" rather than "slow",
 * and it is bounded because the caller is the UI task, which has a screen to
 * draw and must not wait on a reader that is never going to stop. */
#define MIDI_PARK_TICKS  50

static esp_err_t midi_driver_install(void)
{
    tinyusb_config_t tusb_cfg = TINYUSB_DEFAULT_CONFIG();

    tusb_cfg.descriptor.string = s_str_desc;
    tusb_cfg.descriptor.string_count = sizeof(s_str_desc) / sizeof(s_str_desc[0]);
    tusb_cfg.descriptor.full_speed_config = s_midi_cfg_desc;
#if (TUD_OPT_HIGH_SPEED)
    tusb_cfg.descriptor.high_speed_config = s_midi_hs_cfg_desc;
    tusb_cfg.descriptor.qualifier = NULL;
#endif /* TUD_OPT_HIGH_SPEED */

    ESP_LOGI(TAG, "starting USB MIDI device (full speed)");

    return tinyusb_driver_install(&tusb_cfg);
}

/* Waits for the reader to report that it is parked, and says whether it did. */
static bool midi_wait_parked(void)
{
    for (int i = 0; i < MIDI_PARK_TICKS && !s_parked; i++) {
        vTaskDelay(1);
    }
    return s_parked;
}

esp_err_t midi_in_set_enabled(bool on)
{
    if (on == s_enabled) {
        return ESP_OK;
    }

    if (!on) {
        /*
         * Off, in the order that matters: the reader is told first and waited for, and only
         * a reader that has confirmed it is parked is the stack taken away from it. If it
         * never confirms — it cannot happen, the loop is one tick long — the input is put
         * back on and the error is reported rather than the stack being uninstalled under a
         * task that is still polling it.
         */
        s_enabled = false;
        if (s_task && !midi_wait_parked()) {
            s_enabled = true;
            ESP_LOGE(TAG, "the read task did not stop — USB MIDI left running");
            return ESP_ERR_TIMEOUT;
        }

        /*
         * WHAT TAKES THE DEVICE OFF THE BUS, from esp_tinyusb's own source (tinyusb.c,
         * tinyusb_task.c, include/tinyusb.h) rather than from what the name suggests:
         *
         *   1. tinyusb_task_stop() deletes the TinyUSB task, frees the descriptor copies it
         *      made, and calls tusb_deinit(rhport) — the stack teardown, which is what
         *      disconnects the device from the host and stops the OTG controller.
         *   2. tinyusb_power_management_uninstall() releases the PM lock, when the build
         *      has power management at all.
         *   3. usb_del_phy(s_ctx.phy_hdl) releases the internal PHY that install() created
         *      (USB_PHY_TARGET_INT, USB_PHY_CTRL_OTG, device mode, full speed) — and that
         *      release is the whole of why the debug port can come back: the pad belongs to
         *      whichever controller holds the PHY, and until this call the OTG controller
         *      holds it.
         *
         * The component documents this as a supported round trip — its own test app
         * (test_apps/general/main/test_teardown.c) installs and uninstalls the driver ten
         * times in a row — so the same function is the answer to turning the input back on.
         *
         * WHAT THIS DOES NOT DO, stated so that the log below is not read as a promise: the
         * USB-Serial-JTAG peripheral is a separate controller and esp_tinyusb knows nothing
         * about it, so nothing here re-attaches the console. What the release of the PHY
         * restores is the pad. Measured on the bench: the debug COM port does NOT come back
         * while the instrument runs — the driver goes and the USB controller goes with it, but
         * the port is on the cable again only after a restart with the input left off, which
         * reads the setting at boot. So this call is a necessary step and the only one this
         * component can take; the port question belongs to the next boot, not to this one.
         */
        const esp_err_t err = tinyusb_driver_uninstall();

        /* Cleared whatever the error: the failure can come from any of the three steps
         * above, so the stack is not ours to trust afterwards. The next enable calls
         * install() again, and an install that answers ESP_ERR_INVALID_STATE is the one
         * honest report that the stack was never actually torn down — that is the state
         * this call wanted, so it is treated as success there. */
        s_installed = false;
        if (err != ESP_OK) {
            ESP_LOGE(TAG, "USB device stack did not uninstall: %s", esp_err_to_name(err));
            return err;
        }

        ESP_LOGI(TAG, "off - the device stack is down and the USB controller released; the "
                      "debug port is back on the next boot with MIDI in off");
        return ESP_OK;
    }

    if (!s_installed) {
        esp_err_t err = midi_driver_install();
        if (err == ESP_ERR_INVALID_STATE) {
            /* Task already running: an earlier uninstall did not get past its first step, so
             * the stack is up and this is the state that was being asked for. install() has
             * already taken back the PHY it created before finding out. */
            ESP_LOGW(TAG, "USB device stack was still installed — reusing it");
            err = ESP_OK;
        }
        if (err != ESP_OK) {
            /* Logged, not fatal: the instrument is a synth first, and a note input
             * that did not come up is a cable to look at, not a reason to boot into
             * a device that makes no sound. */
            ESP_LOGE(TAG, "USB device stack did not install: %s", esp_err_to_name(err));
            return err;
        }
        s_installed = true;
    }

    /* Set before the task is created, so a task that runs immediately cannot decide it is
     * unwanted and park on the first pass. A notification given to a task that is not yet
     * waiting is latched, so the parked case cannot lose its wake-up either. */
    s_enabled = true;

    if (!s_task) {
        if (xTaskCreatePinnedToCore(midi_task, "midi_in", MIDI_TASK_STACK, NULL,
                                    MIDI_TASK_PRIO, &s_task, MIDI_TASK_CORE) != pdPASS) {
            s_task = NULL;
            s_enabled = false;
            tinyusb_driver_uninstall();
            s_installed = false;
            ESP_LOGE(TAG, "could not create the MIDI read task");
            return ESP_ERR_NO_MEM;
        }
    } else {
        xTaskNotifyGive(s_task);
    }

    ESP_LOGI(TAG, "waiting for a host");
    return ESP_OK;
}

esp_err_t midi_in_start(void)
{
    return midi_in_set_enabled(true);
}

bool midi_in_is_enabled(void)
{
    return s_enabled;
}
