/*
 * midi_in — the instrument as a USB MIDI DEVICE.
 *
 * Plug the board into a computer and it appears as a MIDI output port; notes
 * played on the computer's keyboard — or drawn in a DAW — sound on the
 * instrument. This is the HOST-to-DEVICE direction only: nothing is sent back, and
 * the messages this input acts on are note on, note off and the four system
 * realtime bytes that carry a transport and a clock (0xF8, 0xFA, 0xFB, 0xFC).
 * A host that plays the instrument with its own transport therefore also sets its
 * tempo and its play/stop — while the clock runs, the tempo the sequencers, the
 * arpeggiator and the modulation run at is the host's, measured from its ticks, and
 * the SEQ TEMPO knob keeps its own value and is back in charge about a second after
 * the clock stops. See the clock section in synth_app.cpp.
 *
 * THE CHANNEL IS WHICH PART PLAYS, and that is the whole of the routing: channel 1
 * is the lead and channel 2 is the percussion, one channel per part, with the
 * other fourteen dropped rather than sent somewhere they were not addressed. A
 * drum track on channel 10 therefore does nothing until it is moved to channel 2,
 * which is the honest answer while there is no setting to assign channels with.
 * See the note over midi_message() in midi_in.c.
 *
 * WHY IT IS A COMPONENT OF ITS OWN
 *   The USB device stack touches the same pins, the same PHY and the same
 *   peripheral as the serial console, so it is not a detail of the synth and
 *   not a detail of main(): it is a peripheral that happens to deliver notes.
 *   main() starts it with one call behind one switch, and this component's only
 *   link to the instrument is synth_app_midi_note_on()/_off(), synth_app_midi_clock()
 *   and synth_app_midi_transport().
 *
 * WHAT IT DOES NOT DO
 *   It does not touch the engine. Those calls place an event in a lock-free
 *   ring and return; the audio task — the one task that owns the engine —
 *   drains the ring between blocks and calls the engine itself. See the long
 *   note over synth_app_midi_note_on() in synth_app.h for why that indirection
 *   is not optional.
 *
 *   It does not transpose, and it does not apply a velocity curve: the velocity
 *   on the wire is the velocity the voice is opened at. Each of those would be a
 *   SETTING of its own and neither exists yet — what does exist is the switch
 *   below, APP_SET_MIDI_IN, and a switch is not a mapping. What it does do is
 *   READ THE CHANNEL, because a channel is part of the message and not a
 *   setting: the player said which part they meant when they sent it.
 *
 * THE COST OF THE SHARED PORT, AND WHAT TURNING IT OFF BUYS BACK
 *   USB-Serial-JTAG and USB-OTG are two controllers behind ONE PHY on this
 *   chip, so while the application is running the port is a MIDI interface and
 *   not a serial console. The ROM loader is untouched — esptool still resets
 *   and flashes the board — and the log keeps going out of the UART pads. The
 *   firmware stays alive and reachable; only the USB console is given up, which
 *   is the trade for notes over the same cable.
 *
 *   That is why the input is OFF at the factory and why it can be turned off
 *   while the instrument plays: midi_in_set_enabled(false) stops the reader and
 *   then uninstalls the device stack, which is the only thing that returns the
 *   port. What "returns the port" means in practice is written out at
 *   midi_in_set_enabled() in midi_in.c, from esp_tinyusb's own sources rather
 *   than from a guess.
 */
#pragma once

#include <stdbool.h>

#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Brings the USB device stack up as a MIDI interface and starts the task that
 * reads it. Call once, after the board has been initialised, from app_main —
 * and only when the MIDI IN setting says so; it is the same call as
 * midi_in_set_enabled(true), kept as the name main() has always used.
 *
 * Returns ESP_OK, or the error from the USB stack. The caller is expected to log
 * and carry on — the instrument plays without this, and a note input that is
 * missing is not a reason to refuse to boot.
 *
 * Calling it when the input is already up is a no-op and not an error: the
 * boot path and the screen both ask for the same state, and neither has to know
 * which of them got there first.
 */
esp_err_t midi_in_start(void);

/*
 * Turns the note input on or off while the instrument plays. Idempotent: asking
 * for the state it is already in does nothing and reports ESP_OK.
 *
 * ON installs the USB device stack (once, on the first call) and lets the read
 * task drain the endpoint. OFF stops the reader from touching the stack, then
 * runs tinyusb_driver_uninstall(), which is what tears the device off the bus
 * and releases the PHY — the debug port is the point of the whole call. See the
 * long note over the implementation for what each of those two steps is made of
 * and for the one thing it cannot promise.
 *
 * WHY THIS IS NOT midi_in_start()/midi_in_stop() PAIR
 *   Because the interesting direction is the second one. A stop that had to be
 *   matched against a start would be a second piece of state to keep in step
 *   with a setting that is itself a boolean; one function that takes the boolean
 *   cannot disagree with it.
 *
 * Returns ESP_OK, or ESP_ERR_TIMEOUT when the reader would not stop (the stack
 * is then left alone and the input stays up — a reader still polling a torn-down
 * stack is the one outcome worth refusing), or the error from the USB stack.
 */
esp_err_t midi_in_set_enabled(bool on);

/* Whether the input is up: the device stack is installed and the reader runs. */
bool midi_in_is_enabled(void);

#ifdef __cplusplus
}
#endif
