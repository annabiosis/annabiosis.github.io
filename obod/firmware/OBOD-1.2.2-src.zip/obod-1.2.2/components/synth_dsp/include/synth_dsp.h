/*
 * synth_dsp — the parts of the instrument that ESP32Synth cannot provide.
 *
 * WHY THIS EXISTS
 *   The engine sums every voice of a bus into a single mono int32 buffer, and
 *   its own output stage duplicates that one channel to both I2S slots. No
 *   voice can be panned, no bus FX can emit two channels, and the only stereo
 *   in the library is that final copy. A drone instrument needs a stereo field
 *   that breathes, so stereo is created here, after the engine, and the
 *   engine's own output is discarded.
 *
 * HOW THE STEREO FIELD IS MADE
 *   Each layer of the instrument owns one engine bus (bus 1..5 — bus 0 is the
 *   master and never runs FX). The last FX slot of that bus is a "pan capture":
 *   it writes the mono bus into the layer's own L/R accumulator with
 *   equal-power gains. The rack then sums those accumulators into a real stereo
 *   signal. Because the capture FX is per bus, each layer gets its own
 *   independent pan position, drift rates and phase — for free.
 *
 * WHERE THE STATE LIVES
 *   In file-scope statics inside each translation unit, not in the engine's
 *   es[6] array. The engine offers es[] precisely so an FX can keep per-slot
 *   state without heap; but there is exactly one synth instance in this
 *   firmware, nothing is ever torn down, and a plain static is clearer than
 *   reinterpreting six int32 as floats. If a second instance is ever needed,
 *   this is the thing to change.
 *
 * BLOCK SIZE
 *   The engine is driven with exactly SYNTH_BLOCK_SAMPLES per call and renders the
 *   block in one pass, so the capture FX always writes from offset 0 of the
 *   accumulator. The number lives in the engine's local config
 *   (ESP32Synth_Config.hpp) because the engine has to see it too; it is included
 *   below rather than copied, so there is one block size and not two.
 *
 * C LINKAGE
 *   Everything here is declared extern "C". The DSP layer is a plain C-style
 *   API — no classes, no templates, no references — and the UI is written in C,
 *   so the symbols have to survive the trip. Without this, a C++ definition
 *   would be name-mangled while a C caller emits the bare name, and the link
 *   would fail with an undefined reference that looks like a missing file.
 */
#pragma once

#include <stdbool.h>
#include <stdint.h>

#include "ESP32Synth_Config.hpp"

#ifdef __cplusplus
extern "C" {
#endif

/* One engine chunk and one audio block. Declared in ESP32Synth_Config.hpp, which the
 * engine reads as well; the audio task calls generateSamples() with exactly this many
 * samples, and every buffer in the path is either this size or derived from it. */

/* 48000 is not a preference: the engine is designed and tested at 48 kHz, and
 * the biquad patches it ships hardcode 48 kHz coefficients. */
#define SYNTH_SAMPLE_RATE 48000

/* Layers of the instrument. One engine bus each, in this order. */
#define SYNTH_NUM_LAYERS 5

typedef enum {
    SYNTH_LAYER_DRONE_LOW = 0,
    SYNTH_LAYER_DRONE_MID,
    SYNTH_LAYER_DRONE_HIGH,
    SYNTH_LAYER_LEAD,
    SYNTH_LAYER_AUX,
    SYNTH_LAYER_COUNT = SYNTH_NUM_LAYERS
} synth_layer_t;

/* -------------------------------------------------------------------------- */
/* Bus FX — signatures match ESP32Synth's SynthCustomFXCallback exactly.       */
/* -------------------------------------------------------------------------- */

/*
 * Pan + capture. Parameters (ep, written with setBusFXParam):
 *
 *   ep[0]  base pan          -1000..1000  -> -1.0 .. 1.0
 *   ep[1]  depth                0..1000   ->  0.0 .. 1.0
 *   ep[2]  drift rate 1     milliHertz    (31 -> 0.031 Hz)
 *   ep[3]  drift rate 2     milliHertz
 *   ep[4]  walk period          ms between new random walk targets
 *   ep[5]  walk depth           0..1000
 *   ep[6]  enable               0 or 1
 *   ep[7]  layer index          0 .. SYNTH_NUM_LAYERS-1
 */
void synth_fx_pan_capture(int32_t *bus_buffer, int samples, int16_t *ep, int32_t *es);

/*
 * Drone register filter: TPT/ZDF state-variable filter with its own LFO.
 * The engine has no filter in its core at all, and its two built-in LFOs are
 * pitch and amplitude only, stepped at the control rate. A drone lives on a
 * slow smooth sweep, so it gets a dedicated one.
 *
 *   ep[0]  base cutoff, Hz      20..20000
 *   ep[1]  resonance, Q x 100   50..2000  -> 0.5 .. 20
 *   ep[2]  LFO rate, milliHertz (50 -> 0.05 Hz)
 *   ep[3]  LFO depth, centioctaves (200 -> 2 octaves)
 *   ep[4]  mode 0 = low pass, 1 = band pass, 2 = high pass
 *   ep[5]  LFO shape 0 = sine, 1 = triangle, 2 = square, 3 = saw rising,
 *                     4 = random ramp (smooth, not stepped: a stepped random
 *                     value asks the filter to jump, and a filter that jumps
 *                     clicks)
 *   ep[6]  enable 0 or 1
 *   ep[7]  state index (any stable small number)
 */
void synth_fx_drone_filter(int32_t *bus_buffer, int samples, int16_t *ep, int32_t *es);

/*
 * The trigger mode the modulation is running under, and the note that restarts it.
 *
 * The mode lives here rather than in ep[] because a filter has no spare slot and because the
 * answer is the same for every register: one knob, one mode. 0 free, 1 per note, 2 held,
 * 3 one shot per note — the same numbering the control surface uses.
 *
 * A retrigger is a flag, not a call into the running block: the audio thread takes it at the
 * top of the next one, so nothing here can touch a phase mid-block.
 */
void synth_drone_lfo_trig(int mode);
void synth_drone_lfo_retrigger(void);

/*
 * The mode as the LFOs see it, and the count of notes that have restarted them.
 *
 * A counter rather than a flag because more than one reader needs it and each of them runs in
 * its own place in the block: the filter reads it on slot 0 of a bus, the pan drift on slot 1.
 * A flag would be taken by whichever came first, and the other would never see the note.
 */
int      synth_drone_lfo_mode(void);
uint32_t synth_drone_lfo_epoch(void);

/*
 * The drone filter's own sweep, -1..1, as the last block used it. One number for the three
 * registers: they share a shape and a rate and differ only in phase, and the display wants
 * the motion rather than which register is where in it. Read by the UI, never written.
 */
float synth_drone_lfo(void);

/*
 * Lead filter: TPT/ZDF state-variable low pass with an ADSR of its own.
 *
 * The drone's filter is free-running, because a drone is a texture held for
 * minutes. This one is TRIGGERED: the envelope opens it when a note starts and
 * lets it close afterwards, which is most of what makes a plucked sound plucked.
 * The two are not the same filter with different settings.
 *
 * Instantiated once, so its state is a single static rather than an array indexed
 * by ep[7] — there is no second lead bus to keep separate — and all eight
 * parameter slots are spoken for.
 *
 *   ep[0]  base cutoff, Hz. ZERO MEANS NOT CONFIGURED and the filter bypasses
 *          itself: setBusFX() memsets ep[], and a filter with a cutoff of zero
 *          would silence the lead rather than pass it through.
 *   ep[1]  resonance Q x 100 (50 -> 0.5)
 *   ep[2]  envelope amount, centioctaves, SIGNED. The cutoff is multiplied by
 *          2^(ep[2]/100 * env), so this is how far the envelope opens the filter
 *          measured in octaves — a linear mapping onto Hz would spend its travel
 *          where the ear is least sensitive. Negative values close the filter.
 *   ep[3]  attack, ms
 *   ep[4]  decay, ms
 *   ep[5]  sustain, 0..255
 *   ep[6]  release, ms
 *   ep[7]  gate: 0 released, 1 held
 *
 * Every segment is a one-pole curve rather than a straight line, so a short
 * decay reads as a strike rather than as a fade.
 */
void synth_fx_lead_filter(int32_t *bus_buffer, int samples, int16_t *ep, int32_t *es);

/* -------------------------------------------------------------------------- */
/* The microphone — RETIRED FROM THE FX, KEPT FOR MODULATION                     */
/* -------------------------------------------------------------------------- */
/*
 * NOTHING WIRES synth_fx_mic_in() ANY MORE. The input used to be added to the AUX bus and
 * reach the chorus, the delay and the reverb through its three sends; the owner took it out
 * of the sends and left it as a modulation source, so the application publishes an envelope
 * (synth_dsp_set_mic_env()) and no samples. Both functions below are kept because they are
 * the module's public surface and the removal is one line in the application's buses_init();
 * nothing calls them, and a reader who finds them here should know that before looking for
 * the caller.
 *
 * The PDM microphone is not a layer of the engine: it has no voices and no bus of
 * its own. It is summed into the AUX layer's bus — whose layer level stays at zero —
 * so it reaches the effects and never the dry output. See synth_fx_mic_in() and
 * synth_rack_process(), which takes each layer's send from the RAW captured signal
 * before the fader.
 */

/* The shape code the filter and the application agree on for "the envelope, not the
 * generator". The application's own LFO shape list ends with MIC in this position;
 * every other code the drone filter receives is one of its five waveforms. */
#define SYNTH_LFO_SHAPE_MIC 7

/*
 * The microphone's input FX, in slot 0 of the AUX bus' chain, before the pan capture
 * that puts the bus into the layer. It ADDS the block published by
 * synth_dsp_mic_publish() to the bus buffer and does nothing else — no filtering, no
 * gain, no envelope: all of that happens once, in the application, where the driver
 * is read.
 *
 *   ep[6]  enable 0 or 1
 */
void synth_fx_mic_in(int32_t *bus_buffer, int samples, int16_t *ep, int32_t *es);

/*
 * The block of microphone samples for the next synth_fx_mic_in(), as FLOAT at 16-bit
 * full scale (1.0 = 32767), published by the audio task once per engine block. The
 * caller owns the memory and it must outlive the call: the pointer is kept, not
 * copied, so nothing is allocated on either side of the seam.
 *
 * `count` may be shorter than the block — the PDM driver hands back whole descriptors
 * and a non-blocking read can end on a partial one — so only that many samples are
 * added and the rest of the bus is left alone. A null pointer or a count of zero
 * means silence, which is also what a switched-off microphone publishes.
 */
void synth_dsp_mic_publish(const float *samples, int count);

/*
 * The microphone's envelope, 0..1, and whether it REPLACES the LFOs that live inside
 * the DSP instead of simply being read by the application's own modulation.
 *
 * The envelope itself is computed in the application, beside the read; what crosses
 * this seam is only the number. The two places that need it inside the DSP are the
 * drone filter's cutoff sweep (synth_drone_filter.cpp) and the pan drift
 * (synth_pan_capture.cpp) — both are evaluated per block, and neither has a
 * parameter slot left to be told about it in.
 *
 * `replace` is what makes MIC a source rather than a waveform: when it is true the
 * filter's cutoff is its base times 2^(depth * env) and the pan is its base plus
 * depth * env, so the LFO is gone and the microphone is what moves them. The
 * DEPTH/WIDTH knobs still set how far. When it is false both behave exactly as they
 * did before, envelope or no envelope.
 *
 * Called by the audio task once per block, and read by the DSP in the same task, so
 * no lock is involved and none is wanted.
 */
void synth_dsp_set_mic_env(float env01, bool replace);

/* -------------------------------------------------------------------------- */
/* Layers                                                                     */
/* -------------------------------------------------------------------------- */

void   synth_dsp_init(uint32_t sample_rate);

/*
 * TAKE THE EFFECTS' MEMORY AFTER BOOT, NOT ON THE FIRST TURN OF A KNOB.
 *
 * The delay's four-second line is a megabyte and a half of PSRAM, and clearing it saturates
 * the bus the audio task runs from. At boot that interfered with the Wi-Fi beacon
 * allocation; on the first touch of a mix it put the clear in the middle of a phrase. This
 * starts a low-priority task that waits three seconds (the boot and the radio are done by
 * then), then asks the delay, the reverb and the plate for their memory in that order. Each
 * module clears its lines in bounded pieces with a pause between them, and only declares
 * itself ready after the last piece; the audio path returns silence until it does.
 *
 * Call once, from the end of app_main, after the screen and the network are up. Calling it
 * again does nothing. If the task cannot be created the effects fall back to the lazy claim
 * they had before, so this is an improvement in timing rather than a new dependency.
 */
void synth_dsp_prefetch_start(void);

float *synth_layer_l(int layer);
float *synth_layer_r(int layer);
void   synth_layers_clear(int samples);

/*
 * Where a layer currently sits in the stereo field, -1.0 (hard left) .. +1.0
 * (hard right). Written by the capture FX at the end of every block.
 *
 * This exists so the instrument can be SEEN as well as heard. The pan drift is
 * designed in tens of seconds, which is right for the sound and hopeless for
 * judging it by ear in a ten-second listen; a moving dot makes the same
 * information immediate, and shows at a glance whether the three registers are
 * actually decorrelated or moving as one.
 *
 * Reading it from another task is safe: it is a single aligned 32-bit float, so
 * a load either sees the old value or the new one, never a torn one. It is
 * telemetry, not control — nothing acts on it.
 */
float synth_layer_pan(int layer);

/*
 * How loud a layer currently is, 0.0 .. 1.0, written by the same FX at the end of
 * every block: that block's peak, with an instant attack and a one-pole release.
 *
 * Peak rather than RMS, and a release measured in tenths of a second, because the two
 * things this has to show are a hit and a texture. A percussion strike reaches the top
 * of the range in one block and falls away over the next few, which is what makes a
 * flash read as a flash; a drone holds a steady value that follows its own filter
 * sweep, which is what makes a glow read as a glow. RMS would flatten the first and
 * add nothing to the second.
 *
 * Same telemetry rules as the pan above: a single aligned float, safe to read from
 * another task, and nothing in the audio path acts on it.
 */
float synth_layer_env(int layer);

/*
 * The drift, published the same way: the -1..1 value the pan capture applied at the end
 * of the last block. WIDTH and SPEED on the drone's page are knobs about this motion, and
 * the display draws a dot on their tracks from it.
 */
float synth_layer_lfo(int layer);

/*
 * The same idea for the delay: how loud its wet signal is, 0.0 .. 1.0, and how far apart
 * the repeats are, in samples. Written by the delay itself at the end of every block.
 *
 * Both exist for the ring's reactive mode, which shows the repeats as a pulse travelling
 * around the circle, one step per repeat. That needs the spacing rather than a detector:
 * counting rises in the envelope would guess at where one repeat ends, and with feedback
 * the repeats overlap, so there is often no gap to count at all. The delay knows its own
 * time exactly, and this is that number.
 */
float synth_delay_env(void);
float synth_delay_time_samples(void);

/* -------------------------------------------------------------------------- */
/* Percussion                                                                 */
/* -------------------------------------------------------------------------- */

/*
 * Noise through a resonant band-pass, gated — the drum part, and deliberately not a
 * sixth engine layer. The engine's voices are pitch oscillators with a filter each;
 * a drum is the opposite shape, and none of that machinery would have been reused.
 *
 * PITCH is the centre of the filter and therefore the note of the hit. ENV drops
 * that centre over the decay — or over PERC_ENV_FALL_MAX_MS, 150 ms, when the decay is
 * longer, which is what a kick is made of — and that fall is the difference between a
 * hi-hat, a tom and a kick; at zero the voice is a hat and nothing else. DECAY is the
 * gate, LEVEL is the part's
 * fader, and BODY crossfades the hit between the noise it has always been and a sine
 * at that same centre, so a hit can be given a tone under its noise without a second
 * source to tune. RES is no longer a knob: it is a fixed factory value, because the
 * voice's peak and its level were calibrated at the value the knob used to default to.
 *
 * Three voices, used quietest-first, so a hit never cuts off a tail that is still
 * louder than the hit itself.
 *
 * The three mapping functions are exported because the display prints the numbers
 * the DSP uses: a readout that disagreed with the sound would be worse than none.
 * All of them take the knob's 0..1 position.
 */
void synth_perc_init(uint32_t sample_rate);
void synth_perc_set(float pitch01, float reso01, float decay01, float env01, float level01,
                    float body01);

/*
 * Strike the drum, at `velocity01` (0..1) and with the centre of the hit scaled by
 * `pitch_ratio`, where 1.0 is exactly the PITCH knob's centre.
 *
 * The ratio is for the MIDI input. A note played on channel 2 names a drum, and the one
 * thing a note can name in this voice is its pitch — PITCH is the band-pass centre and
 * therefore the note of the hit — so the application transposes the knob rather than
 * replacing it: the kit still sits where the player put it and the note moves the hit by
 * an interval. The ratio is latched into the voice with the velocity, so a hit that
 * steals a voice and lands two milliseconds later lands on the note it was asked for.
 * The sequencer's own figure passes 1.0 and its hits are bit for bit what they were.
 *
 * A ratio that is not greater than zero is taken as 1.0, for the same reason a velocity
 * that is not greater than zero is taken as "there was no hit": it is the one value that
 * would leave the voice untunable rather than mis-tuned.
 */
void synth_perc_trigger(float velocity01, float pitch_ratio);

/*
 * THE VOICES ARE THE INSTRUMENTS, and that is the whole of the drum's polyphony rule.
 *
 * A kit has four lanes — kick, snare, hat, tom — and each of them owns one voice for the whole
 * of its life: a hit on the kick can never take the hat's tail away, however dense the bar is,
 * because no lane can reach another's voice. What is monophonic is the LANE: a second hit on
 * the same instrument takes over the same voice, the way a drummer's hand does, and a snare
 * roll is a roll rather than a chord of snares.
 *
 * The fifth voice is the drum played from the keyboard, which has no lane. It is monophonic
 * like the others and it is the only voice that a sequencer hit cannot reach.
 *
 * WHY IT MATTERS HERE AND NOT IN A PLUGIN. Three voices over four lanes meant the quietest hit
 * was stolen whenever a bar struck four instruments on one step — and on a four-on-the-floor
 * groove that is the hat under every kick, which is exactly the hit the ear notices missing.
 */
#define PERC_VOICE_KICK   0
#define PERC_VOICE_SNARE  1
#define PERC_VOICE_HAT    2
#define PERC_VOICE_TOM    3
#define PERC_VOICE_LANES  4
#define PERC_VOICE_MIDI   4
#define PERC_VOICES       5

/* Strike one named voice. The index is clamped into the range above, so a caller that asks for
 * a voice the module does not have gets the last one rather than nothing. */
void synth_perc_trigger_voice(int voice, float velocity01, float pitch_ratio);
void synth_perc_process(int samples, float *l, float *r,
                        float *send_rev, float rev01,
                        float *send_chr_l, float *send_chr_r, float chr01,
                        float *send_dly_l, float *send_dly_r, float dly01);
float synth_perc_pitch_hz(float pitch01);

/*
 * The same map read backwards: the knob position that produces a given centre. It exists so
 * that a caller which decides on a FREQUENCY — the percussion's pitch snapping to the scale —
 * can hand the answer back to the knob without knowing the voice's range.
 */
float synth_perc_pitch_01(float hz);
float synth_perc_decay_ms(float decay01);
float synth_perc_env_octaves(float env01);

/*
 * WHAT THE DRUM IS SOUNDING, for the ring's reactive mode: the loudest of the three
 * voices — its gate times its velocity times the steal's fade — as 0.0 .. 1.0.
 *
 * The module has no bus to read this from. It is mixed into the rack's dry sum rather than
 * captured from a layer, which is why this number exists at all: the ring used to look for
 * the drum on the AUX bus, where it was never summed, so its green could not light. See
 * ring_reactive() in synth_ui.c.
 *
 * It is a pure reading of state the voices keep anyway — their gate, their velocity and the
 * steal's fade — taken on demand, so it costs three multiplies a voice and nothing at all
 * per sample: no detector, nothing added to the sample loop, and nothing that could miss a
 * hit between two blocks. The audio task calls it once per block; the display reads
 * synth_perc_env_published() instead.
 *
 * LEVEL IS NOT IN IT, and neither is the voice's own gain. The ring weighs every part by
 * its own fader and send (part_output_gain() in synth_ui.c), and the percussion's LEVEL is
 * applied there like the layers'; counting the fader here as well would make the ring read
 * the square of the knob. The voice's gain — PERC_GAIN, sqrt(Q/fc), the decay
 * compensation — is the module's calibration of a kick against a hat rather than the mix,
 * and it moves with PITCH, which a level meter of the part must not do.
 *
 * The envelope the ring actually reads is synth_perc_env_published() below: this number
 * after the application has shaped it. The two are separate on purpose — the module reports
 * what its voices are doing, and the application decides how long a flash lasts.
 */
float synth_perc_env(void);

/*
 * The same number published to the display, once per block, by the audio task: instant
 * attack and a one-pole release, so a 20 ms gate is still a flash on a ring that is drawn
 * at about eight frames a second. The counterpart of synth_dsp_set_mic_env(), which travels
 * the other way because the microphone's envelope is computed by the application and read
 * by the DSP; this one is computed by the DSP and read by the ring.
 *
 * The published value is a single aligned float written by the task that owns it and read
 * by the display task, like synth_layer_env() and synth_delay_env(): telemetry, and nothing
 * in the audio path acts on it.
 */
void  synth_dsp_set_perc_env(float env01);
float synth_perc_env_published(void);

/* Voices ringing in the last drum block, for the overload report. */
int   synth_perc_active_voices(void);

/* -------------------------------------------------------------------------- */
/* Rack                                                                       */
/* -------------------------------------------------------------------------- */

void synth_rack_set_layer_level(int layer, float level);
void synth_rack_set_master(float level);

/*
 * THE BOOT FADE: silence until the instrument has finished booting, then a measured
 * fade-in on the MASTER gain.
 *
 * The audio task starts before the screens, the fonts, the settings and the presets are
 * up, and everything above the rack is therefore making sound while the rest of the
 * boot is still taking the flash and the CPU. That sound is not the instrument: it is
 * whatever the drone's attack and a half-restored patch happened to be doing. The owner
 * heard it as stutter on reboots.
 *
 * So the rack holds its output at exactly zero until the application says the boot is
 * over, waits BOOT_FADE_DELAY_MS for the last of the boot's bursts to pass, and then
 * raises the master gain linearly over BOOT_FADE_MS. The fade is a multiplier on the
 * MASTER gain, applied after the compressor and beside s_master_cur, and not a factor on
 * the layers: that way it does not depend on how many voices are sounding, it cannot
 * change the balance between the parts, and at 1.0 it is a multiply by exactly one, so
 * the settled instrument is bit-for-bit what it was before this existed.
 *
 * The curve is linear in AMPLITUDE and not logarithmic. Seven hundred milliseconds is
 * short enough that the ear hears the slope rather than the shape, and a logarithmic
 * ramp over this span starts with a jump and then crawls — the opposite of a quiet
 * start.
 *
 * synth_rack_boot_arm() is called once, by main(), immediately before its
 * "boot complete" line. Before that call the gain is exactly zero and every sample the
 * rack writes is zero; the flag is a single word, so the call is safe from the
 * application task while the audio task renders.
 *
 * synth_rack_boot_gain() is telemetry for the desktop bench: the gain that applies to
 * the next output sample, 0 before the arm and 1 once the fade has finished.
 */
void  synth_rack_boot_arm(void);
float synth_rack_boot_gain(void);

/* The two numbers of that fade, in milliseconds. They are here as well as in the rack so
 * that a check on the desktop can state what it expects without copying them: 150 ms of
 * silence after the arm and 700 ms of linear ramp are the design, not an implementation
 * detail. */
#define SYNTH_BOOT_FADE_DELAY_MS 150.0f
#define SYNTH_BOOT_FADE_MS       700.0f

/*
 * THE MASTER COMPRESSOR, and the whole of its design in one place.
 *
 * One knob, because threshold and ratio are the same decision heard twice: turning it up
 * lowers the threshold AND raises the ratio, so there is one gesture from "not there" to
 * "held". At the bottom of the travel the stage is SKIPPED rather than computed with
 * neutral numbers, which is what keeps the factory sound the factory sound.
 *
 * The numbers, and why they are those numbers:
 *
 *   threshold   0 to -24 dBFS, linear in dB. 0 is above anything the instrument makes on
 *               its own, so the bottom of the travel really is off.
 *   ratio       1:1 to 8:1, linear in ratio. 8 rather than 20: this is a master bus on an
 *               instrument that is mostly sustained, and past 8 the difference is a
 *               limiter's, which is a different control doing a different job.
 *   knee        6 dB, soft. A hard knee puts a step in the gain, and on a drone that
 *               step is heard as a click on every swell.
 *   attack      25 ms. Long enough to let a drum hit through as a hit, and to stop the
 *               detector chasing the waveform of a 30 Hz drone; short enough to catch a
 *               lead note within the first tenth of its envelope.
 *   release     250 ms. Ten times the attack, which is where a bus compressor usually
 *               sits: slow enough to hold a phrase together, fast enough that the gain is
 *               back before the next one.
 *   sidechain   150 Hz high-pass. Without it the low drone drives the detector and the
 *               gain rides the waveform.
 *   makeup      half the static reduction, -t * (1 - 1/ratio) / 2: 0 dB at the bottom of
 *               the travel and 10.5 dB at the top. Half rather than all of it because the
 *               full figure assumes a signal sitting at 0 dBFS and this instrument's
 *               peaks are well below that. The consequence, stated plainly: from a
 *               quarter to the middle of the travel the knob is roughly gain-neutral,
 *               and only the top of it ends up quieter than it started.
 *
 * The detector is LINKED — one envelope from max(|L|,|R|) — so a hit on one side cannot
 * move the image.
 *
 * NOTHING HERE STEPS. The knob's three settings are targets, and the gain in force
 * walks to the curve's answer over 12 ms — see COMP_GAIN_GLIDE_MS in synth_rack.cpp —
 * while the detector's own envelope, which is a measurement of the last 250 ms rather
 * than a setting, is carried across a change instead of being reset. That reset is
 * what used to make the knob crackle: zeroing the envelope tells the curve the
 * instrument is silent, so the block the knob arrived on asked for none of the
 * reduction and all of the makeup, and the gain stepped up onto the boost and back off
 * it. The stage is still SKIPPED at the bottom of the travel — one comparison per
 * sample, and the sound unchanged — but the gain is first allowed to walk back to
 * exactly unity before the skip takes over, so taking the knob down is not a step
 * either.
 */
void  synth_rack_set_comp(float amount01);

/*
 * Sidechain depth for the drone's low end, 0..1. The drum's own published envelope is the
 * control, so the duck moves exactly when a hit does; 0 is off and off is bit-transparent.
 */
void  synth_rack_set_duck(float amount01);

/*
 * THE DRIVE IS NOT HERE ANY MORE.
 *
 * There were two calls here — synth_rack_set_drive(algo, amount) and
 * synth_rack_set_drive_pos(after_fx) — and with them four shapers (SOFT, HARD, FOLD, TUBE), a
 * per-bus level estimate, a compensation table and two positions in the chain. All of it is
 * gone: the owner's decision, taken after living with the instrument. The signal path is now
 * the summing loop, the drum, the three effects, the compressor and the master, with no
 * saturation stage anywhere in it.
 *
 * SYNTH_PARAM_DRIVE_AMOUNT, SYNTH_PARAM_DRIVE_ALGO and SYNTH_PARAM_SET_DRIVE_POS still EXIST
 * as parameters, with their slots in the enum untouched, because a parameter is an index into
 * every stored preset and into the patch blob: deleting one from the middle would hand every
 * value after it to a different control and a stored sound would come back as a different
 * instrument. They are dead slots, their appliers do nothing, and no page offers them.
 */

/*
 * How far the low end is held down at this moment, 0..1, after the smoothing. Telemetry for
 * the display: nothing in the audio path reads it back, and it is the number the ear hears.
 */
float synth_rack_duck_depth(void);

/* The ratio the knob is asking for, so a readout can print the mapping rather than guess
 * at it. 1.0 at the bottom, COMP_RATIO_MAX at the top. */
float synth_rack_comp_ratio(float amount01);

/*
 * True connects the generators to the rack; false disconnects them.
 *
 * This is the STOP button's half of the transport, and it deliberately sits at the
 * rack's INPUT rather than on its master gain. Muting the master takes the delay repeats
 * and the reverb tail down with it, and a stopped instrument whose tail is cut dead
 * sounds like a power switch rather than like a player taking their hands off. With the
 * gate at the input, the generators stop feeding the rack while the rack itself keeps
 * running: whatever was already in the lines rings out and decays on its own, which is
 * the whole point of a tail.
 *
 * IT IS NO LONGER THE TRANSPORT ALONE, and no longer a switch. The caller is the audio
 * task, which opens it while a note from the MIDI input is held or its tail is still
 * alive — an instrument a computer is playing has to be audible with the transport
 * stopped — and STOP is enforced on the GENERATORS instead: the sequencer opens no notes
 * and the drum strikes none while it is stopped. The change is RAMPED, one step per
 * sample, because a note arriving between two samples would otherwise step the signal and
 * a step is a click. The ramp is faster opening than closing — 1.5 ms against 5 ms — since
 * what opens it is a note's attack and what closes on it is the drone; see the note over
 * GATE_OPEN_TAU_S in synth_rack.cpp.
 */
void synth_rack_set_gate(int on);

/*
 * THE TRANSPORT, as the silence watchdog has to see it.
 *
 * The gate above is wider than the transport: it is also open while an external note is
 * held or its tail is alive, and a drone under a stopped transport is silent by
 * definition rather than by fault. The watchdog therefore asks the application for the
 * transport itself, once per block, and this is that answer. It is a plain store read by
 * the audio task on the block that follows, like every other setter here.
 */
void synth_rack_set_transport(int running);

/*
 * HOW THE REVERB MAKES ITS TAIL.
 *
 * Three sets of numbers for one engine, and a fourth mode that is a second engine entirely.
 * The three are what make the numeric modes affordable: every one is the same twelve delay
 * lines with the same per-sample cost, so changing between them cannot push the audio task
 * past its 5.33 ms block. ROOM is small and dark, HALL is the tuning this reverb has always
 * had, and CATHEDRAL is long and bright.
 *
 * There WAS a fourth numeric mode, HOLD: a tail that did not decay, held by a comb loop gain
 * just under one and measured in tens of seconds rather than by a feedback path that had
 * escaped. It is gone because the sound broke on the way out of it into the cathedral, and the
 * machinery went with it rather than staying switched off, because a mode nobody chooses is a
 * mode that only rots. Its row is out of
 * MODE[] in synth_fx_reverb.cpp and its name out of the readout; a value stored in the flash
 * that pointed at it is migrated ONCE, by list position, to HALL — see migrate_patch_verb()
 * in app_settings.c for the remembered sound and migrate_store_modes() in app_presets.c for
 * the preset slots.
 *
 * There was a GATE mode before that one, and it went the same way: a gated tail, opened by a
 * drum hit or a lead note and chopped 120 ms later. The gate, its envelope, its trigger and its
 * call sites are all deleted; the plate kept its own.
 *
 * PLATE is Dattorro's plate reverberator: a different topology, not a different tuning, with
 * its own feedback paths, its own PSRAM block and its own file. It is the one that sounds
 * like a plate rather than like a room, and it costs thirteen delay-line reads a sample
 * against the Freeverb's twenty-four, so it is not a deadline risk either. Its damping and
 * size are the same DAMP and SIZE knobs the other modes have. Switching to it, or away from
 * it, is crossfaded like any other mode change: the wet is faded down over 15 ms, the change
 * is made at the bottom of that fade, and it comes back over 250 ms — the tail is not cut,
 * it is handed over.
 *
 * An FDN (Jot) would be a third topology; shimmer needs a pitch shifter inside the reverb's
 * own loop and is the most expensive thing on that list. Both are in FEATURES.md and are not
 * built.
 */
typedef enum {
    SYNTH_REVERB_ROOM = 0,
    SYNTH_REVERB_HALL,
    SYNTH_REVERB_CATHEDRAL,
    SYNTH_REVERB_PLATE,
    SYNTH_REVERB_MODE_COUNT
} synth_reverb_mode_t;

/*
 * The three effects. All of them work on the stereo sum, because they are the
 * only stages that can be stereo at all: the engine's buses are mono and are
 * captured to L/R before they ever reach the rack.
 *
 *   chorus   rate in Hz, depth 0..1, mix 0..1
 *   delay    time in SAMPLES — the caller owns the tempo — feedback 0..0.95, mix 0..1
 *   reverb   size 0..1, damping 0..1, mix 0..1, and one of synth_reverb_mode_t
 *
 * A MIX IS A RETURN LEVEL, and for the reverb and the delay it is also a CROSSFADE. The
 * three effects are fed from send buses, one level per part, and each hands back raw wet;
 * the mix scales that wet at the summing point. On its own a return can only be added to a
 * dry path that stays whole, which is why the knob could never reach "only the effect".
 * The reverb and the delay therefore duck the dry by send x return, so at the top of both
 * the part really is inside the effect; a closed send or a closed return leaves the dry
 * exactly as it was. The chorus is untouched: it is a send-only return, with no crossfade.
 *
 * The reverb's crossfade is PER LAYER, because its send is per layer: the lead can go into
 * the room while the drone keeps its dry. The delay's is one factor on the whole dry pair,
 * and its input walks from its sends to the dry pair as that factor opens — a bus insert
 * has to hear what it replaces. Both carry a gain against the answer's own level, measured
 * at -11 dB for the room and -3..-4 dB for the delay: +9 dB and +2 dB put the wet within a
 * decibel of the dry it replaces at the top of the travel, which is what makes the crossfade
 * a replacement rather than a fade into a hole. The unboosted room sat 11 dB under the dry
 * at every return, and no curve over the knob could have fixed that.
 *
 * The room's +9 dB is the number measured at the sizes the instrument ships with. Past SIZE
 * 0.75 the room's own build-up makes its answer arrive at the dry's level, and the same
 * multiplier put the wet eleven decibels over the instrument and the output against its
 * fuse, so the gain tapers with the size: 0.78 ROOM, 1.22 HALL, 0.79 CATHEDRAL and 1.52
 * PLATE against the dry at the top. The delay's +2 dB needs no taper; its answer follows the
 * feedback rather than the size.
 *
 * The reverb does not take the dry sum. It has its own send bus, one level per
 * layer, so the drone can stay nearly dry while the lead sits in a room — a send in
 * the old sense, the dry instrument asking for a space.
 *
 * Every setter is safe to call from the control task; they are applied per block,
 * like everything else here.
 */
void synth_rack_set_chorus(float rate_hz, float depth01, float mix01);
/*
 * `crossfade` is how a CHANGE OF TIME arrives rather than how the delay sounds: false
 * bends the repeats the way tape does — the read pointer slews, bounded, to the new
 * position — and true puts the pointer there at once and fades the tap it left out over
 * thirty milliseconds instead. See DELAY_SLEW_MAX and DELAY_XFADE_MS in
 * synth_fx_delay.cpp for why the ceiling is a half sample per sample.
 *
 * It is an argument of this call rather than a setter of its own for the reason the
 * reverb's mode is: one effect, one call, so a block cannot apply half of it.
 */
void synth_rack_set_delay(float time_samples, float feedback01, float mix01, bool crossfade);
void synth_rack_set_reverb(float size01, float damp01, float mix01, int mode);

void synth_rack_set_reverb_send(int layer, float level01);

/*
 * How much percussion goes to the reverb.
 *
 * Not one of the layer sends: the percussion is mixed into the rack's dry sum
 * rather than captured from an engine bus, so it has no layer to be indexed by. It
 * is a send all the same — the drum part asks for a room without being handed one.
 */
void synth_rack_set_perc_send(float level01);

/*
 * The chorus's and the delay's sends, per part, beside the reverb's above. Each part chooses
 * how much of itself reaches each of the three effects. The chorus's MIX is its return level
 * and nothing else. The delay's MIX is its return level AND its crossfade: the whole dry pair
 * is ducked as it opens, and the delay's input walks from these sends to the dry pair with it.
 */
void synth_rack_set_chorus_send(int layer, float level01);
void synth_rack_set_delay_send(int layer, float level01);
void synth_rack_set_perc_chorus_send(float level01);
void synth_rack_set_perc_delay_send(float level01);

/*
 * How many times the output fuse has rescued a non-finite block since boot.
 *
 * Telemetry for the statistics line; nothing in the audio path reads it back. The
 * counter is written by the audio task and read from the other core, which is safe
 * for one aligned 32-bit word.
 */
uint32_t synth_rack_rescue_count(void);

/*
 * THE SILENCE WATCHDOG, and its record for the boot after a reset.
 *
 * A drone sounds for as long as its level is above zero, so an output that is exactly
 * silent while the transport runs and the drone is up is a fault, not a state the
 * instrument can be in: a gate stuck at zero, a level zeroed behind the knob, an output
 * stage that stopped writing. The non-finite fuse cannot see any of those — every number
 * is a number — so the rack watches for the other kind of failure: the output is zero
 * across a whole block for a full second while all the conditions above say it should be
 * sounding. The test is done on the samples the scope already reads, not on a second
 * pass over the block.
 *
 * What the watchdog does when it fires is what the non-finite fuse does: the same rescue
 * (poles and smoothers installed on their targets, the effects' state cleared by their
 * owners), one line in the log — printed by the application from the snapshot below, never
 * from the audio task — and a rate limit that keeps a persistent fault from becoming a
 * waterfall.
 *
 * The record below is what the audio task pins on the block a rescue fires, and it is
 * the whole of what the rescue publishes: the counters, the states the line names, and
 * the trail the application turns into the RTC record for the next boot. The rescue
 * itself writes no log line — a UART wait on the audio task costs a block — so the
 * statistics task copies this record and prints it, and `serial` is what tells that
 * reader it has a rescue it has not printed yet. The audio task is the only writer;
 * `serial` is published last, so a reader compares it rather than trusting a struct it
 * may have caught half-written.
 */
typedef struct {
    uint32_t serial;           /* bumped on every rescue; the reader compares it */
    uint32_t silence_count;    /* rescues caused by a silent output */
    uint32_t nonfinite_count;  /* rescues caused by a bad number */
    uint32_t cause;            /* 1 silence, 0 non-finite: which one wrote the fields */
    uint32_t uptime_ms;        /* since boot, at the moment of that rescue */
    uint32_t lasted_ms;        /* how long the output had been silent; 0 for non-finite */
    uint32_t bad_l;            /* non-finite probe on the left; non-finite cause only */
    uint32_t bad_r;            /* the same for the right */
    float    master;           /* the five states a silent failure is read through */
    float    comp;
    float    gate;
    float    duck;
    float    drone;            /* the three drone levels summed */
    float    last_l;           /* the mixed tail the fuse probed; bad cause only */
    float    last_r;
    float    layers[SYNTH_NUM_LAYERS];  /* the layer targets, as the line prints them */
    float    delay_samples;    /* the delay's time in samples and its feedback, at that */
    float    delay_fb;         /* moment: settings the next block would have played */
} synth_rack_rescue_t;

uint32_t synth_rack_rescue_serial(void);
void     synth_rack_rescue_snapshot(synth_rack_rescue_t *out);

#if CONFIG_OBOD_STRESS
/*
 * The stress mode's window on the rack's output, and its way of poisoning a pole.
 *
 * All three exist only in a build with CONFIG_OBOD_STRESS. The observation is a pass
 * over the block the audio task has just written — 256 compares against a budget of
 * 128000 — and it keeps the signed minimum and maximum, the number of blocks seen and
 * the uptime of the last block that was not exactly zero. The last field is what tells
 * "the output never went silent" from "the output is zero now", which a cumulative
 * peak cannot.
 *
 * The reset is called once per stress pass from the stress task. A block that lands
 * between the reset's stores and the reader's loads can be attributed to the wrong
 * side of it; the only consequence is one block of peak in the neighbouring pass, and
 * that is deliberate: a lock on this path would cost the audio task more than the
 * measurement is worth.
 */
typedef struct {
    int32_t  peak_min;        /* signed minimum over the pass; 32767 when no block seen */
    int32_t  peak_max;        /* signed maximum over the pass; -32768 when no block seen */
    uint32_t blocks;          /* output blocks observed since the reset */
    uint32_t last_sound_ms;   /* esp_log_timestamp() of the last block with a nonzero sample */
} synth_rack_stress_out_t;

void synth_rack_stress_peak_reset(void);
void synth_rack_stress_peak(synth_rack_stress_out_t *out);

/*
 * Puts a non-number directly into one of the two poles the fuse checks by name and that
 * are not rewritten by an unrolled per-sample loop: 0 master gain, 1 compressor gain.
 * Called from the stress task and nothing else. The fuse is expected to catch it on the
 * next block and count one non-finite rescue; a pass that does not see that rescue has
 * not tested the fuse.
 */
void synth_rack_stress_poison(int which);
#endif

/* Sums the captured layers and writes interleaved int16 stereo. */
void synth_rack_process(int samples, int16_t *out_stereo);

/*
 * How many points the master's waveform is published in, and the reader for them.
 *
 * Written once per block from the rack's own output, after the master level and the
 * compressor, so what the display draws is what leaves the instrument. The block is
 * decimated to this many points rather than buffered: the page that draws it wants the shape
 * of the sound, not a recording of it, and a block is already a picture of the moment.
 *
 * Copied into the caller's array; the reader never holds a pointer into the audio side.
 */
#define SYNTH_SCOPE_POINTS 41
int synth_rack_scope(float *dst, int max);

#ifdef __cplusplus
}
#endif
