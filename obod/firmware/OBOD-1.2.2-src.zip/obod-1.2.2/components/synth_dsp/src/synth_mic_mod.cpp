#include "synth_dsp.h"
#include "synth_dsp_private.h"

/*
 * The microphone as a MODULATION SOURCE, and nothing else.
 *
 * Two statics and the setters for them: the envelope the application computed this
 * block, and whether the SHAPE knob is on MIC, which decides whether that envelope
 * REPLACES the LFOs inside the DSP or is merely read by the application's own
 * generator. Both are written by synth_dsp_set_mic_env() from the audio task and read
 * by the filter and the pan capture in the same task, in the same block, so there is
 * no lock and no need for one.
 *
 * The envelope itself is not computed here. It comes from the one place that already
 * reads the driver and knows the sensitivity, which is the audio task in synth_app —
 * see mic_process_block() there.
 */

namespace {

float s_env     = 0.0f;   /* 0..1 as the application computed it */
bool  s_replace = false;  /* the shape is MIC: the envelope takes the LFO's place */

} // namespace

void synth_mic_mod_init(void)
{
    s_env = 0.0f;
    s_replace = false;
}

void synth_dsp_set_mic_env(float env01, bool replace)
{
    /* Negated lower test: a NaN must land on silence, not travel into the filter's
     * cutoff and the pan's position as a number no comparison can catch. */
    if (!(env01 >= 0.0f)) {
        env01 = 0.0f;
    } else if (env01 > 1.0f) {
        env01 = 1.0f;
    }
    s_env = env01;
    s_replace = replace;
}

float synth_mic_mod_env(void)
{
    return s_env;
}

bool synth_mic_mod_replaces(void)
{
    return s_replace;
}
