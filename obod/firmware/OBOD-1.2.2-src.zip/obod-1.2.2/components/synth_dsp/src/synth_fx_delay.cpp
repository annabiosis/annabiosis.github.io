#include "esp_attr.h"
#include "synth_dsp.h"
#include "synth_dsp_private.h"

#include <math.h>
#include <string.h>

#include "esp_heap_caps.h"
#include "esp_log.h"

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

/*
 * Ping-pong stereo delay.
 *
 * The input is summed to mono and fed to the LEFT line only; the left repeat
 * feeds the right line and the right repeat feeds the left one. So the first
 * repeat comes out on the left, the second on the right, the third on the left
 * again: the repeats walk across the stereo field instead of sitting in the
 * middle. That is a deliberate choice for this instrument, where the engine is
 * mono and every echo would otherwise land in the same place as the note that
 * caused it.
 *
 * The time is set in samples by the application, which is the only part of the
 * system that knows the tempo. Nothing here knows what a beat is — it is handed a
 * number, and because that number is derived from the same block counter that
 * drives the sequencer, a synced delay cannot drift away from the sequence no
 * matter how long it runs.
 *
 * Changing the time is slewed rather than switched. A hard jump in a delay line
 * that is feeding back is a click, and a click fed back repeats.
 *
 * The lines are claimed after boot by the prefetch task, and on first use only if the mix
 * knob moves earlier — see the note in claim_lines().
 */

namespace {

constexpr const char *TAG = "delay";

constexpr float DELAY_MAX_MS   = 4000.0f;   /* one whole note at 60 bpm; the app's
                                             * slowest synced division is 1/1, and
                                             * below 60 bpm it clamps rather than
                                             * dropping the repeat */
constexpr float DELAY_MIN_MS   = 2.0f;
constexpr float DELAY_GLIDE_MS = 60.0f;   /* time constant for a time change */
/* The fade the wet gets when a restarted effect's first material reaches its tap, so the
 * read does not turn on inside a waveform. See s_warm_inv beside the state below. */
constexpr float DELAY_WARM_MS  = 10.0f;

/*
 * THE CEILING ON HOW FAST THE READ POINTER MAY MOVE, in samples of line per sample
 * of audio.
 *
 * The glide below is a one-pole, and a one-pole's RATE is proportional to the
 * distance it has to cover — which is fine for a knob and not fine for a jump. The
 * knob's whole travel is 20 ms to 1500 ms, and the pole covers it at 25 samples per
 * sample at the first step; a change of DIVISION with the tempo low — 1/32 to 1/1 at
 * 30 bpm asks for eight seconds, which the clamp cuts back to the line's own four —
 * is a jump of 180000 samples, and the pole runs that at 62 samples per sample: it
 * crosses the entire line in the sixty milliseconds of one time constant. Sweeping
 * the whole line that fast is what turns "a longer echo" into the burst of chirp
 * this exists to remove. It is not a wrong index and it never leaves the buffer —
 * the read clamps at both ends — but a read that walks over a line full of repeats
 * that fast drags all of them back into the feedback path in a few thousand samples,
 * and what comes out is a swell rather than an echo.
 *
 * A HALF, and not a whole one. At one sample per sample the read position stands
 * still — the pointer runs backwards exactly as fast as the line is written — and
 * a held sample is a DC step for as long as the change takes, which is a thump in
 * place of a chirp. Half is the slowest the pointer may go while still advancing,
 * an octave down: the tape-stop the ear already knows, bounded, and the change
 * takes the time it takes on tape rather than the time a pole would give it.
 */
constexpr float DELAY_SLEW_MAX = 0.5f;

/*
 * HOW LONG THE CROSSFADE TAKES — the mode that does not slew at all.
 *
 * Thirty milliseconds: long enough that a jump between two positions in the line is a
 * replacement rather than a click, short enough that it reads as the new time ARRIVING
 * rather than as a journey to it, which is the whole of the difference between this and
 * the ceiling above. A linear fade rather than an equal-power one, because the two taps
 * carry the same material at two offsets: they are related signals rather than
 * independent ones, so the dip an equal-power law would be correcting for is not there
 * to correct.
 */
constexpr float DELAY_XFADE_MS = 30.0f;

/* The repeats' loop gain, which is a gain and steps like one: a feedback that goes
 * from a half to nine tenths between two samples multiplies everything already in
 * the line by that much at once. 20 ms, the same order as the compressor's own. */
constexpr float DELAY_FB_GLIDE_MS = 20.0f;

float *s_line[2] = { nullptr, nullptr };
int    s_len     = 0;
int    s_write   = 0;
float  s_rate    = 48000.0f;
float  s_delay   = 4800.0f;   /* current, in samples */
float  s_target  = 4800.0f;   /* where the knob wants it */
float  s_glide   = 0.0f;
/*
 * The mode, and the state of a fade that is running: the tap being left, and how much of
 * the fade is still to come. Both are still in tape mode, and the sample loop tests the
 * count rather than the mode, so the tape path pays one comparison it always paid.
 */
bool   s_xfade     = false;
float  s_delay_b   = 4800.0f;  /* the tap being faded out, in samples */
int    s_xfade_n   = 0;        /* samples of fade left to run */
int    s_xfade_len = 1440;     /* the whole fade, in samples: 30 ms at 48 kHz */
float  s_fb      = 0.35f;
float  s_fb_cur  = 0.35f;     /* that, through the one-pole above: what is applied */
float  s_fb_glide = 0.0f;
float  s_mix     = 0.0f;
bool   s_ready   = false;
/* The audio task only ASKS for the lines; claim_task() does the work. Kept beside s_ready
 * because the two are read and written together and nowhere else. */
volatile bool s_want_claim = false;
/* Set by the boot prefetch so its 10 ms poll does not ask again after the one attempt the
 * claim task is allowed. Written and read by the prefetch task alone. */
bool s_prefetch_asked = false;
/* The rack's MIX is above zero. The delay's own mix is always 1 (the rack balances dry
 * against wet), so without this flag the module cannot tell a running rack from a player
 * asking for the effect — and would take a megabyte and a half during boot again. */
bool s_active = false;

/*
 * THE LINE HAS GONE BAD, and the audio task must not touch it.
 *
 * Set by synth_delay_reset_state() after a non-finite sample has been found in the rack's
 * output. The sample is already in the line, and zeroing it costs the same forty
 * milliseconds the claim above exists to keep off the audio core — so the task that owns
 * the zeroing clears it instead, and the process loop answers with silence until it has.
 * Silence and not the send: the rack adds this buffer to the dry path as a RETURN, and a
 * bypass that handed the dry signal back would be a level jump at the moment of the rescue.
 */
volatile bool s_dirty = false;

/*
 * HOW MUCH OF THE LINE HAS BEEN WRITTEN SINCE THE EFFECT WAS LAST ASKED FOR FROM NOTHING.
 *
 * The line is never cleared when a return comes back up: it is a megabyte and a half, and
 * the clearing is exactly the traffic this design keeps off the audio core. It does not need
 * to be cleared either. The read is one tap behind the write, so after the tap's worth of
 * samples written by the restarted effect, every position the read can reach holds material
 * written since the restart — and until then the read would be reaching into the phrase the
 * line was left holding, which is the one thing a return that comes back must not open on.
 *
 * So the wet is silence while s_fill is shorter than the tap in force, and the fresh
 * material arrives on its own, one tap time later, with no clearing and no gap in the bus.
 * The count saturates at the line's length: past that there is nothing left to protect.
 */
int    s_fill    = 0;
/* One over the ramp the wet is faded in with when the fresh material reaches the tap: ten
 * milliseconds, which is short enough to be part of the first repeat and long enough that
 * the sample it starts on is not a step. */
float  s_warm_inv = 1.0f / 480.0f;

/*
 * Telemetry for the ring, not signal: the envelope of the wet signal, and the spacing of
 * the repeats in samples. Nothing in the audio path reads either of them.
 *
 * The wet rather than the output, because the output carries the dry as well, and the dry
 * is present in between the repeats. The time is published rather than measured by the
 * reader: counting rises in the envelope would have to guess where one repeat ends, and
 * with feedback the repeats overlap, so there is often no gap to count.
 */
float  s_wet_env = 0.0f;

/*
 * Boot, after the boot path is done — and not in the audio task either.
 *
 * A megabyte and a half of delay line. Taken inside the boot sequence, this memory stopped
 * the Wi-Fi SoftAP from starting, and the driver's reaction to a failed beacon allocation
 * was a NULL dereference and a reboot. Taken at the first turn of the mix knob, it was
 * worse in a different way: the clear landed exactly while somebody was playing. So the
 * memory is claimed by synth_dsp_prefetch_start() three seconds after app_main has
 * finished, and the first turn of the knob now finds it ready. If the knob is turned before
 * that, the audio path still only ASKS: this module's claim task does the work off the
 * audio core and the delay stays silent until it is done.
 *
 * The zeroing is the expensive part, and it is not a millisecond: a megabyte and a half of
 * PSRAM zeros in about forty milliseconds on this board, fifteen blocks rather than one,
 * measured as a 39955 us block the first time a delay mix was raised. A hole that size in
 * the middle of the audio task is heard; it also starves the other core, because the audio
 * task fetches its code from the same PSRAM. So the clear is written by synth_fx_zero() in
 * four-kilobyte pieces with a tick between them — no piece holds the bus for more than a
 * fraction of a block — and s_ready is set only after the last one.
 */
bool claim_lines(void)
{
    const size_t bytes = sizeof(float) * (size_t)s_len;
    for (int c = 0; c < 2; c++) {
        if (s_line[c]) {
            continue;
        }
        s_line[c] = (float *)heap_caps_malloc(bytes, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
        if (!s_line[c]) {
            ESP_LOGE(TAG, "no room for %u bytes of delay line — bypassed", (unsigned)bytes);
            return false;
        }
    }

    for (int c = 0; c < 2; c++) {
        synth_fx_zero(s_line[c], bytes);
    }

    s_write = 0;
    s_fill = s_len;             /* the line is empty, so there is nothing to protect against */

    ESP_LOGI(TAG, "ping-pong, %.2f s a side in PSRAM, %d samples",
             (double)(DELAY_MAX_MS / 1000.0f), s_len);
    s_ready = true;             /* last, so the audio task never reads a half-zeroed line */
    return true;
}

/*
 * The audio path's side of it. Never allocates and never zeroes: it asks, and the task
 * created for the job answers by setting s_ready, which claim_lines() does last.
 *
 * The boot prefetch has usually already done the asking; this stays for the case where a
 * hand reaches the mix before the prefetch has run, and for a build that never started it.
 */
bool ensure(void)
{
    if (s_ready) {
        return true;
    }

    s_want_claim = true;
    return false;
}

/*
 * The claim itself, off the audio core. It sleeps between looks rather than waiting on a
 * semaphore: one flag, one waiter, and at most one request per boot.
 *
 * The same loop owns the rescue's zeroing, and for the same measured reason: a dirty line is
 * a megabyte and a half that must not be memset inside a block. The write index is reset here
 * too, which is safe because the audio path does not touch the line at all while the flag is
 * up — see synth_delay_process().
 */
void claim_task(void *)
{
    for (;;) {
        if (s_dirty) {
            if (s_line[0] && s_line[1] && s_len > 0) {
                const size_t bytes = sizeof(float) * (size_t)s_len;
                synth_fx_zero(s_line[0], bytes);
                synth_fx_zero(s_line[1], bytes);
                s_write = 0;
                s_fill = s_len;     /* cleared, so nothing stale is left to read */
            }
            s_dirty = false;    /* last: the audio task may read the line again after this */
            continue;
        }

        if (!s_want_claim || s_ready) {
            vTaskDelay(pdMS_TO_TICKS(10));
            continue;
        }

        s_want_claim = false;   /* one attempt: a failure would only repeat the log line */
        if (!claim_lines()) {
            ESP_LOGW(TAG, "delay line not claimed — the delay stays bypassed until reboot");
        }
    }
}

} // namespace

/*
 * The boot prefetch's question, asked until the answer is yes. The request is made once:
 * claim_task() gets one attempt per boot, and repeating it after a failure would only
 * repeat the log line the failure already printed.
 */
bool synth_delay_prefetch(void)
{
    if (s_ready) {
        return true;
    }

    if (!s_prefetch_asked) {
        s_prefetch_asked = true;
        s_want_claim = true;
    }
    return false;
}

void synth_delay_init(uint32_t sample_rate)
{
    s_rate = (float)sample_rate;
    s_len = (int)(s_rate * DELAY_MAX_MS / 1000.0f);

    /* The task that does the claim, on the core the audio task is not on, at the lowest
     * priority there is: it only wakes when the audio path has asked for the lines. */
    xTaskCreatePinnedToCore(claim_task, "delay_claim", 3072, nullptr, 1, nullptr, 0);
    if (s_len < 64) {
        s_len = 64;
    }

    s_glide = 1.0f - expf(-1.0f / (DELAY_GLIDE_MS * s_rate / 1000.0f));
    s_fb_glide = 1.0f - expf(-1.0f / (DELAY_FB_GLIDE_MS * s_rate / 1000.0f));
    s_xfade_len = (int)(DELAY_XFADE_MS * s_rate / 1000.0f);

    synth_delay_set(s_rate * 0.25f, 0.35f, 0.0f);
    s_fill = 0;                 /* nothing is written until the line has been claimed */
    s_warm_inv = 1.0f / (DELAY_WARM_MS * s_rate / 1000.0f);

    /* Nothing to glide FROM at boot: the line is empty and the feedback the first
     * block runs on is the one that was just asked for, not a ramp up to it. */
    s_fb_cur = s_fb;
}

void synth_delay_set(float time_samples, float feedback01, float mix01)
{
    /*
     * The clamps are the same two the read applies, and they are written the same
     * way: the lower test is the NEGATION of the one the value has to pass, so a
     * NaN — which compares false against everything — is pulled back to the
     * minimum with the values below it instead of being stored as the target. A
     * NaN here would be a NaN in the read a sample later, and (int)NaN is INT_MIN.
     *
     * The line's own length is the upper limit because that is what the read can
     * reach: anything longer than len - 2 is dropped rather than wrapped, which is
     * what the display in the application says it does for the slowest synced
     * divisions at the slowest tempo — eight seconds asked of a four-second line.
     */
    const float min_samples = DELAY_MIN_MS * s_rate / 1000.0f;
    if (!(time_samples >= min_samples)) {
        time_samples = min_samples;
    } else if (time_samples > (float)(s_len - 2)) {
        time_samples = (float)(s_len - 2);
    }

    if (!(feedback01 >= 0.0f)) {
        feedback01 = 0.0f;
    } else if (feedback01 > 0.95f) {
        /* Never 1: a delay that replaces everything it removes never decays, and
         * the only way out of that is a power cycle. */
        feedback01 = 0.95f;
    }
    if (!(mix01 >= 0.0f)) {
        mix01 = 0.0f;
    } else if (mix01 > 1.0f) {
        mix01 = 1.0f;
    }

    /*
     * A change of time is where the two modes part company.
     *
     * TAPE leaves the target here and lets the loop above walk to it, which is the bend.
     * CROSSFADE moves the read position to the new time in this one step and leaves the
     * tap it came from to be faded out over DELAY_XFADE_MS, so the repeats are replaced
     * rather than travelled to. The fading tap is captured BEFORE the move and the count
     * is restarted, which is what makes a knob turn — a new target every block — a
     * sequence of very small fades rather than a bend: the two taps are one block apart,
     * so neither end of such a fade has anything audible in it.
     *
     * The test is on the target rather than on the caller's parameters, so a block that
     * asks for the same time again — which is every block — starts nothing.
     */
    if (s_xfade && time_samples != s_target) {
        s_delay_b = s_delay;
        s_delay = time_samples;
        s_xfade_n = s_xfade_len;
    }

    s_target = time_samples;
    s_fb = feedback01;
    s_mix = mix01;
}

/* The rack's MIX, not this module's: see the note where s_active is declared. */
void synth_delay_set_active(bool active)
{
    s_active = active;
}

void synth_delay_set_mode(bool crossfade)
{
    /*
     * Turning the mode off mid-fade abandons the fading tap where it stands, which is a
     * step in the wet signal — so the fade is FINISHED rather than left half done: the tap
     * is let go, and the active one is already at the time that was asked for, so what is
     * heard after this is the new time and nothing else.
     */
    s_xfade = crossfade;
    if (!crossfade) {
        s_xfade_n = 0;
    }
}

/*
 * The rescue, from synth_rack.cpp's fuse. Two numbers are put on their targets here because
 * they are read on the very next sample: the read position jumps to the time the knob asks
 * for, which is what the line will be read at once it has been cleared, and the loop gain is
 * the one the knob asks for. The wet envelope is telemetry and starts again from silence.
 *
 * The line itself is the megabyte and a half and is NOT cleared here. s_dirty hands it to
 * claim_task(), which is already the task that owns that memory; until it has finished,
 * synth_delay_process() returns silence. The rescue is allowed to be inaudible for as long
 * as the clearing takes — a delay return that is missing for forty milliseconds is not a
 * click, and the alternative is the forty-millisecond hole in the audio task itself.
 */
void synth_delay_reset_state(void)
{
    s_delay = s_target;
    s_fb_cur = s_fb;
    s_xfade_n = 0;
    s_wet_env = 0.0f;
    s_dirty = true;
}

float synth_delay_feedback(void)
{
    return s_fb;
}

/*
 * THE RETURN HAS COME BACK UP FROM ZERO.
 *
 * Not a clear: a count. The line keeps the phrase it was left holding, and the read below
 * answers with silence until one tap's worth of material has been written over it — see
 * s_fill. Nothing else happens here, which is the point: this runs in the audio task on the
 * block a return is raised, and the alternative costs a megabyte and a half of PSRAM.
 */
void synth_delay_restart(void)
{
    s_fill = 0;
}

/* The envelope's fall time, in seconds. Long enough to see a repeat from across a room,
 * short enough that consecutive repeats stay separate at speed. */
constexpr float WET_RELEASE_S = 0.14f;

IRAM_ATTR void synth_delay_process(int samples, float *l, float *r)
{
    const float block_s = (samples > 0) ? ((float)samples / s_rate) : 0.0f;
    const float release = 1.0f - expf(-block_s / WET_RELEASE_S);

    /*
     * The mix is the effect's own switch, and with it shut the lines are silent — but the
     * ring's envelope has to fall with them rather than freeze where they stopped. A spark
     * left hanging on the circle after the delay is turned off would be a lie about the
     * sound.
     */
    if (s_mix <= 0.0f || !l || !r || samples <= 0) {
        s_wet_env -= s_wet_env * release;
        if (s_wet_env < 0.001f) {
            s_wet_env = 0.0f;
        }
        return;
    }

    /*
     * The line is dirty and the task that owns it has not finished clearing it. The buffer
     * this writes is the rack's delay RETURN, so it is silence and not the send: the rack
     * adds it to the dry path, and handing the send back would be a step in level exactly
     * when the rescue is trying to avoid one.
     */
    if (s_dirty) {
        for (int i = 0; i < samples; i++) {
            l[i] = 0.0f;
            r[i] = 0.0f;
        }
        s_wet_env = 0.0f;
        return;
    }

    if (!s_ready) {
        /* The boot prefetch has not taken the lines yet. A turn of the MIX before it has
         * is the one case that still asks: s_active is the rack's mix, which is the only
         * signal that separates "the rack is running" from "the player wants the delay".
         * With both false the line is not requested at all, so a device left alone never
         * pays the megabyte and a half during boot.
         *
         * Until the last piece of the clear has landed the return is silence, not the send
         * and not a stale block: the rack sums this beside the dry path, and silence is the
         * one answer that cannot be heard as a step. */
        if (s_active) {
            ensure();
        }
        for (int i = 0; i < samples; i++) {
            l[i] = 0.0f;
            r[i] = 0.0f;
        }
        s_wet_env -= s_wet_env * release;
        if (s_wet_env < 0.001f) {
            s_wet_env = 0.0f;
        }
        return;
    }

    float peak = 0.0f;
    /* Read once and written back after the loop: the count is touched on every sample, and a
     * static it has to reload through a store is not something to spend a block on. */
    int fill = s_fill;

    for (int i = 0; i < samples; i++) {
        /* The time: one pole towards the target, then the ceiling on how far that
         * pole may move the pointer in one sample. The pole is what turns a knob
         * step into a glide; the ceiling is what turns a change of division into a
         * bend instead of a sweep of the whole line.
         *
         * The ceiling is applied AFTER the pole and not instead of it, so a slow
         * move never meets it: the pole's step is 3.5e-4 of the distance that is
         * left, which only reaches half a sample once that distance is 1441 samples
         * — 30 ms of time. Below that the glide is the pole it always was, which is
         * every knob step and every small correction; above it — a fast turn, or a
         * division change that can ask for two seconds of line at once — the
         * pointer walks at the ceiling and takes the time that takes. */
        float step = (s_target - s_delay) * s_glide;
        if (step > DELAY_SLEW_MAX) {
            step = DELAY_SLEW_MAX;
        } else if (step < -DELAY_SLEW_MAX) {
            step = -DELAY_SLEW_MAX;
        }
        s_delay += step;

        /* The repeats' loop gain, on its own pole. It is read by the write below
         * and by nothing else, so smoothing it here cannot disagree with the rack's
         * derivation of what this effect added. */
        s_fb_cur += (s_fb - s_fb_cur) * s_fb_glide;

        /*
         * How much of the material written since the restart actually reaches the tap:
         * see s_fill. The tap is the one IN FORCE, so a time that grows while the line is
         * still cold keeps the wet silent until the line has been written that far.
         *
         * The gain is not a switch but a ten-millisecond ramp, because the read does not
         * start on a zero: it starts on the first sample the restarted effect wrote, and a
         * read that turns on inside a waveform is a step whatever the line holds. The ramp
         * costs two multiplies and it is exactly zero while the tap is still behind the
         * fresh material, so the cold part of the wait reads nothing at all.
         */
        const float fresh = ((float)fill - s_delay) * s_warm_inv;
        const float wet_gain = (fresh >= 1.0f) ? 1.0f : ((fresh > 0.0f) ? fresh : 0.0f);
        const bool  warm = (wet_gain <= 0.0f);

        float rl = 0.0f;
        float rr = 0.0f;
        if (!warm) {
            rl = synth_fx_read(s_line[0], s_len, s_write, s_delay) * wet_gain;
            rr = synth_fx_read(s_line[1], s_len, s_write, s_delay) * wet_gain;
        }

        /*
         * The crossfade, when one is running: the same two reads again, at the tap the
         * pointer has just left, mixed in and taken out over the fade. It is applied to the
         * pair that the OUTPUT and the FEEDBACK both read — the two writes below take rl and
         * rr — because the sweeping tap is what the ceiling above exists to bound, and a
         * fade that reached only the output would leave the feedback path taking the jump
         * this is here to remove.
         *
         * Linear in the sample count, so a fade that is interrupted — a knob turned again
         * inside the thirty milliseconds — starts a new one from the tap the pointer stands
         * on rather than from wherever the last one had got to. At one block between those
         * two taps that is inaudible, and a division change, which arrives in one block and
         * is not repeated, always runs its fade to the end.
         * A fade that is still to run when the line is cold is not started either: the tap it
         * came from is on the same stale line, so its first read has nothing to say until the
         * fresh material has reached it. It is thirty milliseconds and it starts then.
         */
        if (s_xfade_n > 0 && !warm) {
            const float f = 1.0f - (float)s_xfade_n / (float)s_xfade_len;
            rl = rl * f + synth_fx_read(s_line[0], s_len, s_write, s_delay_b) * (1.0f - f);
            rr = rr * f + synth_fx_read(s_line[1], s_len, s_write, s_delay_b) * (1.0f - f);
            s_xfade_n--;
        }

        const float al = fabsf(rl);
        const float ar = fabsf(rr);
        const float mag = (al > ar) ? al : ar;
        if (mag > peak) {
            peak = mag;
        }

        /* Mono in, and only into the left line — that is what makes it bounce. */
        const float feed = (l[i] + r[i]) * 0.5f;

        s_line[0][s_write] = feed + rr * s_fb_cur;
        s_line[1][s_write] = rl * s_fb_cur;

        l[i] = l[i] * (1.0f - s_mix) + rl * s_mix;
        r[i] = r[i] * (1.0f - s_mix) + rr * s_mix;

        if (++s_write >= s_len) {
            s_write = 0;
        }
        if (fill < s_len) {
            fill++;
        }
    }
    s_fill = fill;

    /* The wet envelope, on the same terms as the layers': instant up, one-pole down. It is
     * taken from the wet pair rather than from the output, so a repeat carries the same
     * weight whether the mix knob sits at a tenth or at one. */
    if (peak > s_wet_env) {
        s_wet_env = peak;
    } else {
        s_wet_env += (peak - s_wet_env) * release;
    }
    if (s_wet_env > 1.0f) {
        s_wet_env = 1.0f;
    }
}

float synth_delay_env(void)
{
    return s_wet_env;
}

float synth_delay_time_samples(void)
{
    return s_target;
}
