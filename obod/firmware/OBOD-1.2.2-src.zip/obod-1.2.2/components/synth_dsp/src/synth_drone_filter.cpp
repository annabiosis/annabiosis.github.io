#include "synth_dsp.h"
#include "synth_dsp_private.h"
#include "synth_stage_timing.h"

#if STAGE_TIMING
#include "esp_timer.h"
#endif

#include <math.h>

/*
 * Drone register filter: TPT/ZDF state-variable filter with its own LFO.
 *
 * WHY NOT THE ENGINE'S FILTER
 *   ESP32Synth ships two bus filters (FX_BiquadFilter, FX_BiquadFilterFast) and
 *   they are fine filters, but they recompute their coefficients once per
 *   render block from parameters pushed in by user code, and their frequency
 *   tables hardcode 48 kHz. More importantly there is no modulation path in the
 *   engine at all: no LFO routes to a filter, so a sweep has to be driven from
 *   outside at whatever rate the caller manages. A drone is a slow filter sweep
 *   held for minutes; it deserves its own LFO inside the same loop, where the
 *   sweep cannot be quantised by anything.
 *
 * WHY TPT
 *   The topology-preserving transform SVF (Zavalishin) stays stable at high
 *   resonance, needs one tanf per block plus five multiply-adds per sample, and
 *   gives low/band/high outputs from the same state. A direct-form biquad would
 *   need coefficient interpolation to sweep smoothly; this one just works.
 *
 * CUTOFF IS MODULATED IN OCTAVES, so a 1-octave sweep sounds like a 1-octave
 * sweep instead of crawling at the bottom and racing at the top.
 */

namespace {

struct SvfState {
    float ic1eq;         /* integrator states */
    float ic2eq;
    float lfo_phase;     /* 0..1 */
    float cutoff;        /* smoothed, Hz */
    float cutoff_target; /* Hz */
    float depth;         /* smoothed LFO depth, centioctaves */
    bool  depth_set;     /* false until the first block has given it a value */
    float q;             /* smoothed resonance, same pole as the cutoff */
    /* The smooth-random shape is the only one that needs memory of its own:
     * where the current cycle started, and where it is heading. */
    float lfo_rand_from;
    float lfo_rand_to;
};

SvfState s_svf[SYNTH_NUM_LAYERS];
float    s_inv_sample_rate = 1.0f / (float)SYNTH_SAMPLE_RATE;

uint32_t s_lfo_rng = 0x9E3779B9u;

/*
 * Bipolar random for the smooth-random shape.
 *
 * Deterministic from boot, deliberately: a modulation source that produced a
 * different sequence every session would make two otherwise identical listens
 * impossible to compare, and the point of this shape is to be judged.
 */
float lfo_rand_bipolar(void)
{
    s_lfo_rng ^= s_lfo_rng << 13;
    s_lfo_rng ^= s_lfo_rng >> 17;
    s_lfo_rng ^= s_lfo_rng << 5;
    /* The top half of the word, reinterpreted as signed, lands in -1..+1
     * without a division. */
    return (float)(int16_t)(s_lfo_rng >> 16) * (1.0f / 32768.0f);
}

} // namespace

/* The sweep of the last block, for the display. See synth_drone_lfo(). */
float s_lfo_pub;

/* Set from the control side, read by the block. */
static volatile int s_trig_mode;
static volatile uint32_t s_trig_epoch;
static uint32_t s_trig_seen;       /* the epoch this filter has already acted on */

void synth_drone_lfo_trig(int mode)
{
    s_trig_mode = mode;
}

void synth_drone_lfo_retrigger(void)
{
    s_trig_epoch = s_trig_epoch + 1;
}

int synth_drone_lfo_mode(void)
{
    return s_trig_mode;
}

uint32_t synth_drone_lfo_epoch(void)
{
    return s_trig_epoch;
}

void synth_drone_filter_init(uint32_t sample_rate)
{
    s_inv_sample_rate = 1.0f / (float)sample_rate;

    for (int i = 0; i < SYNTH_NUM_LAYERS; i++) {
        s_svf[i].ic1eq = 0.0f;
        s_svf[i].ic2eq = 0.0f;
        s_svf[i].cutoff = 0.0f;
        s_svf[i].cutoff_target = 0.0f;
        s_svf[i].depth = 0.0f;
        s_svf[i].depth_set = false;
        s_svf[i].q = 0.0f;
        s_svf[i].lfo_rand_from = 0.0f;
        s_svf[i].lfo_rand_to = lfo_rand_bipolar();
        /* Staggered start phases, so the three registers never sweep together. */
        s_svf[i].lfo_phase = (float)i * 0.23f;
    }
}

/*
 * The rescue, from synth_rack.cpp's fuse. The integrators are the filter's memory and are
 * cleared unconditionally — units of numbers, microseconds. The cutoff, the resonance and the
 * depth are poles that were being walked towards knobs, so they are only replaced where the
 * poison actually reached them, and a cutoff of zero is this module's own "no ramp, take the
 * knob on the next block" value rather than silence. The phase is clamped into its range for
 * the same reason the chorus's is: sinf() of a non-finite phase is NaN, and the filter would
 * poison itself again on the next block without ever reading a sample.
 */
void synth_drone_filter_reset_state(void)
{
    for (int i = 0; i < SYNTH_NUM_LAYERS; i++) {
        SvfState &st = s_svf[i];

        st.ic1eq = 0.0f;
        st.ic2eq = 0.0f;

        if (!isfinite(st.cutoff) || st.cutoff < 0.0f) {
            st.cutoff = 0.0f;
        }
        if (!isfinite(st.cutoff_target) || st.cutoff_target < 0.0f) {
            st.cutoff_target = 0.0f;
        }
        if (!isfinite(st.q) || st.q < 0.0f) {
            st.q = 0.0f;
        }
        if (!isfinite(st.depth)) {
            st.depth = 0.0f;
            st.depth_set = false;   /* the next block seeds it from the knob */
        }
        if (!isfinite(st.lfo_phase) || st.lfo_phase < 0.0f || st.lfo_phase >= 1.0f) {
            st.lfo_phase = 0.0f;
        }
        if (!isfinite(st.lfo_rand_from)) {
            st.lfo_rand_from = 0.0f;
        }
        if (!isfinite(st.lfo_rand_to)) {
            st.lfo_rand_to = 0.0f;
        }
    }
}

static void synth_fx_drone_filter_body(int32_t *bus_buffer, int samples, int16_t *ep, int32_t *es)
{
    /* A note's restart is taken here, at the top of a block: the phases below are all that
     * the LFO is, and a reset halfway through a sweep would be a click. One epoch for all
     * registers, because they are one instrument's three bands. */
    const uint32_t epoch = s_trig_epoch;

    if (epoch != s_trig_seen) {
        s_trig_seen = epoch;

        for (int i = 0; i < SYNTH_NUM_LAYERS; i++) {
            s_svf[i].lfo_phase = 0.0f;
        }
    }

    (void)es;   /* state lives in s_svf[]; see the note in synth_dsp.h */

    if (!ep[6]) {
        return;
    }
    const int idx = ep[7];
    if (idx < 0 || idx >= SYNTH_NUM_LAYERS) {
        return;
    }
    if (samples <= 0) {
        return;
    }
    if (samples > SYNTH_BLOCK_SAMPLES) {
        samples = SYNTH_BLOCK_SAMPLES;
    }

    SvfState &st = s_svf[idx];
    const float dt = (float)samples * s_inv_sample_rate;

    /* --- cutoff modulation ------------------------------------------------ */
    st.lfo_phase += (float)ep[2] * 0.001f * dt;     /* ep is milliHertz */
    if (s_trig_mode == 3 && st.lfo_phase >= 1.0f) {
        /* One shot: the shape runs to its end and stays there. An exponential shape read at
         * its end is a settled envelope, which is what the mode is for. */
        st.lfo_phase = 1.0f;
    } else if (st.lfo_phase >= 1.0f) {
        st.lfo_phase -= 1.0f;
        /* A new random target for the next cycle, and the old target becomes the
         * new starting point. That is what keeps the ramp continuous across the
         * wrap: the value a cycle ends on is the value the next one begins from,
         * so there is nothing there to click. */
        st.lfo_rand_from = st.lfo_rand_to;
        st.lfo_rand_to = lfo_rand_bipolar();
    }

    /*
     * The microphone as the modulation source, when the SHAPE knob is on MIC.
     *
     * The envelope REPLACES this filter's own LFO rather than being added to it: the
     * point of the choice is that the room moves the filter instead of a cycle, and a
     * sum of the two would be a room on top of a sweep. The depth is still the DEPTH
     * knob and its WIDTH share — the same ep[3] below — so nothing about the range
     * changes; what changes is where the number in the exponent came from. The phase
     * above keeps running, so leaving MIC resumes the sweep where it would have been.
     *
     * The envelope is 0..1 and the LFO is -1..1, so the cutoff starts at the base and
     * only opens above it. That is deliberate: an envelope is a positive quantity, and
     * base * 2^(depth * env) is the same law this file already applies to a waveform.
     *
     * The MIC shape code is checked as well as the flag, and both mean the same thing.
     * The flag is what the pan capture has to read, because its eight parameter slots
     * are all spoken for; the code is what this filter already receives, and a reader
     * should be able to see the source in the value the switch is on.
     */
    float lfo;
    if (synth_mic_mod_replaces() || ep[5] == SYNTH_LFO_SHAPE_MIC) {
        lfo = synth_mic_mod_env();
    } else {
        /*
         * All five shapes are readings of the same phase, so switching between them
         * never jumps the sweep: the phase is the state, and the shape is only how
         * it is interpreted. Only the random one carries extra state.
         */
        switch (ep[5]) {
        case 0:     /* sine: the organic one, fastest through the middle */
            lfo = sinf(st.lfo_phase * 6.28318531f);
            break;

        case 2:     /* square: the sweep becomes a two-state alternation */
            lfo = (st.lfo_phase < 0.5f) ? 1.0f : -1.0f;
            break;

        case 3:     /* saw, rising: a long climb and an abrupt return */
            lfo = 2.0f * st.lfo_phase - 1.0f;
            break;

        case 4:     /* random ramp, not a random step */
            lfo = st.lfo_rand_from + (st.lfo_rand_to - st.lfo_rand_from) * st.lfo_phase;
            break;

        default:    /* 1, and anything unrecognised: triangle, linear both ways */
            lfo = 4.0f * fabsf(st.lfo_phase - 0.5f) - 1.0f;
            break;
        }
    }

    s_lfo_pub = lfo;

    /*
     * The depth is a knob, and a knob is a staircase: each detent asks for a new sweep width,
     * and because the target is base * 2^(depth * lfo), a step in depth is a step in the
     * corner of up to the whole sweep — the click that is heard while WIDTH is turned. It is
     * therefore smoothed on its own, slower than the corner it multiplies: 60 ms turns a
     * detent into a widening rather than a jump, and it cannot slow the sweep itself, which
     * is the LFO's business and stays at 8 ms in the corner below.
     */
    if (!st.depth_set) {
        st.depth = (float)ep[3];
        st.depth_set = true;
    } else {
        float ad = dt * (1.0f / 0.060f);

        if (ad > 1.0f) {
            ad = 1.0f;
        }

        st.depth += ((float)ep[3] - st.depth) * ad;
    }

    const float depth_oct = st.depth * 0.01f;       /* centioctaves -> octaves */
    const float base_hz = (float)ep[0];

    float target = base_hz * exp2f(depth_oct * lfo);

    /* Keep it below Nyquist with margin, and above DC. The lower test is negated:
     * a base of zero times a depth that has overflowed the exponential is a NaN, and
     * a NaN fails both of the comparisons a plain `x < 20` / `x > max` pair makes. */
    const float fc_max = 0.45f / s_inv_sample_rate;
    if (!(target >= 20.0f)) {
        target = 20.0f;
    } else if (target > fc_max) {
        target = fc_max;
    }
    st.cutoff_target = target;

    /* One-pole smoothing over ~8 ms, so a jump in the base cutoff cannot step
     * the filter hard enough to click.
     *
     * 8, not the 15 it was: this is a low-pass on the sweep itself, and the top of the
     * RATE travel puts the LOW register's LFO at 6 Hz (MID 8.4, HIGH 4.8). At 15 ms the
     * smoother's corner sits at 10.6 Hz against a block rate of 187.5 Hz, so a 6 Hz sweep
     * came out at 89 % of the depth asked for and 24 degrees late, and MID, the fastest
     * of the three, lost 19 % and 32 degrees. At 8 ms the corner is 19.9 Hz: 6 Hz comes
     * out at 97 % and 11 degrees late, MID at 95 % and 15. The phase still advances once
     * per block, and the smoother's corner stays ten times below the block rate, so this
     * is a filter on the sweep rather than a source of stepping: the largest per-block
     * change the smoothed cutoff makes stays under the one the target itself makes in
     * the same block. */
    /* One coefficient for both settings below: they are both knobs read once per
     * block, and neither is a modulator. */
    float a = dt / 0.008f;
    if (a > 1.0f) {
        a = 1.0f;
    }

    if (st.cutoff <= 0.0f) {
        st.cutoff = target;                         /* first block: no ramp from zero */
    } else {
        st.cutoff += (target - st.cutoff) * a;
    }

    /* --- TPT coefficients ------------------------------------------------- */
    float q = (float)ep[1] * 0.01f;                 /* Q x 100 -> Q */
    if (!(q >= 0.5f)) {
        q = 0.5f;
    } else if (q > 20.0f) {
        q = 20.0f;
    }

    /*
     * RESONANCE IS SMOOTHED, on the same per-block pole the cutoff uses, and it is
     * the ONE coefficient here that reaches the output without being offered a
     * glide anywhere else.
     *
     * The lead filter's does not need this: its Q goes into a1/a2/a3, and those are
     * ramped across 32 samples between one coefficient update and the next, which is
     * what makes a resonance move there a sweep rather than a splice. This filter
     * has no such ramp — it is the cheap one, and the whole of its design is that
     * one tanf per block plus five multiply-adds per sample — so a Q that has just
     * been moved lands on the very next block. Q sets where the peak sits and how
     * tall it is, and on a resonant sweep that is a step in the output; a per-block
     * pole will not remove the step, but it turns one step of the whole change into
     * a series of steps a few per cent of it, which is the difference between a
     * click and a knob.
     */
    if (st.q <= 0.0f) {
        st.q = q;                                   /* first block: no ramp from zero */
    } else {
        st.q += (q - st.q) * a;
    }

    const float g = tanf(3.14159265f * st.cutoff * s_inv_sample_rate);
    const float k = 1.0f / st.q;
    const float a1 = 1.0f / (1.0f + g * (g + k));
    const float a2 = g * a1;
    const float a3 = g * a2;

    const int mode = ep[4];

    for (int i = 0; i < samples; i++) {
        const float x = (float)bus_buffer[i] * (1.0f / 32768.0f);

        const float v3 = x - st.ic2eq;
        const float v1 = a1 * st.ic1eq + a2 * v3;
        const float v2 = st.ic2eq + a2 * st.ic1eq + a3 * v3;
        st.ic1eq = 2.0f * v1 - st.ic1eq;
        st.ic2eq = 2.0f * v2 - st.ic2eq;

        float y;
        if (mode <= 0) {
            y = v2;                                 /* low pass, bit for bit */
        } else if (mode >= 100) {
            y = x - k * v1 - v2;                    /* high pass */
        } else if (mode < 50) {
            /* Low to band: the two outputs cross-faded by the knob's first half.
             * A cross-fade of one state is what makes the sweep continuous; a
             * switch would step the output on a held drone and click. */
            const float t = (float)mode * 0.02f;
            y = v2 * (1.0f - t) + v1 * t;
        } else {
            const float t = (float)(mode - 50) * 0.02f;
            y = v1 * (1.0f - t) + (x - k * v1 - v2) * t;
        }

        /* Resonance can push the output past full scale; the rack limits the
         * sum, but this keeps a single bus from overflowing int32 first. */
        float out = y * 32768.0f;
        if (out > 2147483000.0f) {
            out = 2147483000.0f;
        } else if (out < -2147483000.0f) {
            out = -2147483000.0f;
        }
        bus_buffer[i] = (int32_t)out;
    }
}

float synth_drone_lfo(void)
{
    return s_lfo_pub;
}

/*
 * The published callback, with the stage measured around it.
 *
 * This runs inside the engine's render — generateSamples() calls it once per block per
 * register — so it cannot be timed from the outside, and the three registers are three
 * separate calls. The measurement is a wrapper rather than a timer inside the body because
 * the body returns from six places (an unconfigured register, a bad index, a block of zero
 * samples), and a stage that is only counted on some of them is a wrong number.
 */
void synth_fx_drone_filter(int32_t *bus_buffer, int samples, int16_t *ep, int32_t *es)
{
#if STAGE_TIMING
    const int64_t t0 = esp_timer_get_time();
    synth_fx_drone_filter_body(bus_buffer, samples, ep, es);
    synth_stage_add(SYNTH_STAGE_DRONE, (uint32_t)(esp_timer_get_time() - t0));
#else
    synth_fx_drone_filter_body(bus_buffer, samples, ep, es);
#endif
}

