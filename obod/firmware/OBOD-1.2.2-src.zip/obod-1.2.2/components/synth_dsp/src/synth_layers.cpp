#include "synth_dsp.h"

#include <string.h>

/*
 * Stereo accumulators, one pair per layer.
 *
 * The pan capture FX writes into these and the rack reads them back once
 * generateSamples() has returned. They are float because everything after the
 * engine is float: the engine's fixed-point arithmetic stays inside the engine,
 * where it belongs, and the rack is free to use the FPU the S3 actually has.
 *
 * Sized for exactly one engine block, which is why the audio task always calls
 * generateSamples() with SYNTH_BLOCK_SAMPLES: the capture FX has no way to know
 * which chunk of a larger request it is being called for, so a multi-chunk
 * request would make every chunk overwrite the same region.
 */
static float s_layer_l[SYNTH_NUM_LAYERS][SYNTH_BLOCK_SAMPLES];
static float s_layer_r[SYNTH_NUM_LAYERS][SYNTH_BLOCK_SAMPLES];

float *synth_layer_l(int layer)
{
    return s_layer_l[layer];
}

float *synth_layer_r(int layer)
{
    return s_layer_r[layer];
}

void synth_layers_clear(int samples)
{
    if (samples <= 0) {
        return;
    }
    if (samples > SYNTH_BLOCK_SAMPLES) {
        samples = SYNTH_BLOCK_SAMPLES;
    }

    const size_t bytes = (size_t)samples * sizeof(float);
    for (int i = 0; i < SYNTH_NUM_LAYERS; i++) {
        memset(s_layer_l[i], 0, bytes);
        memset(s_layer_r[i], 0, bytes);
    }
}
