#include "esp_attr.h"
#include "synth_dsp.h"
#include "synth_dsp_private.h"

#include <math.h>
#include <string.h>

#include "esp_heap_caps.h"
#include "esp_log.h"

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

/*
 * THE PLATE — Dattorro's plate reverberator, as a second topology beside the Freeverb in
 * synth_fx_reverb.cpp.
 *
 * It is here for two reasons. It sounds like nothing Freeverb can be talked into: a dense,
 * even plate whose modes never settle into the ringing that eight fixed combs always end up
 * with, because Dattorro modulates two of the tank's allpasses and that is what breaks the
 * modes up. And it costs LESS delay-line traffic per sample than Freeverb does — thirteen
 * lines against twenty-four — which on this instrument is the price that actually matters:
 * see the 5.33 ms block in FEATURES.md, and what happened the last time a per-sample cost
 * was allowed to exceed it.
 *
 * WHERE EVERY NUMBER COMES FROM. The structure, the delay lengths, the tap positions, the
 * tap SIGNS and the diffusion gains are Dattorro's, checked line by line against a port
 * (el-visio's dattorro-verb) rather than against anybody's summary.
 * That check was worth doing: the first version of this file had the tank's order wrong —
 * the modulated allpass belongs BEFORE the pre-damping delay, not after it — and the taps
 * of each channel come from BOTH halves of the tank, four from the opposite one and three
 * from its own, not all seven from the opposite one as an earlier reading of the table
 * claimed.
 *
 * Three things are deliberately not the port's, and they are named here rather than buried:
 *
 *   . The lengths are SCALED to the running rate. The paper's tunings are in samples at
 *     29761 Hz, a rate chosen for the arithmetic of 1997; the port runs them unscaled at
 *     48 kHz, which makes its space 1.6 times smaller in time than the paper's. Scaling
 *     keeps the design's TIMES, which is what a reverb is made of.
 *   . The modulation is a SINE where the port uses a triangle of ±1 sample steps every
 *     2048. Same depth, same rate (its 65536-sample cycle, 0.73 Hz at 48 kHz); a sine has
 *     no corner in its derivative, so the moving tap cannot click.
 *   . DAMP and SIZE are the engine's own knobs, mapped onto the two coefficients the paper
 *     has: DAMP onto the tank's damping lowpass (0.95 at nought, the port's own default,
 *     down to 0.10 at full, which is heavy) and SIZE onto the decay (0.55 to 0.95, and
 *     0.75 at the middle of the knob, which is the port's default). The port's separate
 *     input filter is fixed at its default 0.85 and the second diffusor's gain follows the
 *     decay exactly as the port derives it.
 *
 * STABILITY is structural: every element in the loop is either lossless (the allpasses) or
 * lossy (the damping lowpass), and the loop is closed through the decay, which is always
 * below one. A loop of unit-or-less elements closed through a gain below one cannot grow.
 */

namespace {

constexpr const char *TAG = "plate";

/* The rate the paper's tunings are in samples at. */
constexpr int PAPER_RATE = 29761;

/*
 * The tank. TANK_AP[0] and [2] are the modulated first diffusors of the two halves and
 * TANK_DL[0] and [2] are the delays that follow them, which is where the port's names
 * preDampingDelay / postDampingDelay come from: the damping sits between the two.
 */
const int TANK_AP[4] = { 672, 1800, 908, 2656 };
const int TANK_DL[4] = { 4453, 3720, 4217, 3163 };

/* The input diffusion: four allpasses in series, two gains, and a light lowpass first. */
const int IN_DIFF[4] = { 142, 107, 379, 277 };

constexpr float IN_DIFF_G1   = 0.75f;
constexpr float IN_DIFF_G2   = 0.625f;
constexpr float DECAY_DIFF_G = 0.70f;   /* the first diffusor, and the port NEGATES it */
constexpr float PREFILTER    = 0.85f;   /* the port's default; a one-pole, light */

/* The port's pre-delay default: a tenth of its 100 ms buffer. */
constexpr float PREDELAY_MS  = 10.0f;

/* Eight samples at 29761 Hz, kept as a TIME so that scaling the lines scales the depth
 * with them and the modulation stays the same fraction of the diffusor it moves. */
constexpr float EXCURSION_MS = 0.5376f;

/* The port's modulation cycle is 65536 samples, which at 48 kHz is 0.73 Hz. */
constexpr float MOD_HZ       = 0.73f;

/* SIZE onto the decay, and DAMP onto the tank's damping lowpass. The ends are the port's
 * default (0.75) at the middle of SIZE, and its default (0.95, which is almost no damping)
 * at nought on DAMP. */
constexpr float DECAY_MIN   = 0.55f;
constexpr float DECAY_SPAN  = 0.40f;
constexpr float DAMP_LIGHT  = 0.95f;
constexpr float DAMP_SPAN   = 0.85f;

/* The second diffusor's gain, derived from the decay exactly as the port derives it. */
constexpr float DIFF2_ADD   = 0.15f;
constexpr float DIFF2_MIN   = 0.25f;
constexpr float DIFF2_MAX   = 0.50f;

/*
 * The one number that is mine alone: how much of the send goes into the tank. The port
 * applies no gain at all — its tank runs hot and its caller scales the output — so this is
 * the plate's trim against the Freeverb modes, worked out from that engine's own scale
 * (0.015 into eight combs at 0.84 feedback) and the plate's accumulation over a 0.75 decay
 * loop. If the plate turns out louder or quieter than the hall, THIS is the number to move.
 */
constexpr float IN_GAIN = 0.12f;

/* A block-rate one-pole on the knobs, so that a hand on SIZE or DAMP is a sweep. */
constexpr float GLIDE_MS = 250.0f;

struct Line {
    float *buf;
    int    len;
    int    idx;
    int    nom;         /* the delay this line is meant to be, before modulation */
};

/*
 * One output tap: which half of the tank, which of its three tapped lines, how far behind
 * the write head, and with what sign. Line 0 is the delay before the damping, 1 the second
 * diffusor, 2 the delay after it.
 *
 * These are the port's getLeft and getRight, in order. Note the shape of it: four taps from
 * the opposite half and three from its own, with the signs alternating — that is what makes
 * one network into a stereo pair without a second network.
 */
struct Tap {
    int   half;
    int   line;
    int   at;
    float sign;
};

const Tap LEFT_TAPS[7] = {
    { 1, 0,  266, +1.0f }, { 1, 0, 2974, +1.0f }, { 1, 1, 1913, -1.0f }, { 1, 2, 1996, +1.0f },
    { 0, 0, 1990, -1.0f }, { 0, 1,  187, -1.0f }, { 0, 2, 1066, +1.0f },
};

const Tap RIGHT_TAPS[7] = {
    { 0, 0,  353, +1.0f }, { 0, 0, 3627, +1.0f }, { 0, 1, 1228, -1.0f }, { 0, 2, 2673, +1.0f },
    { 1, 0, 2111, -1.0f }, { 1, 1,  335, -1.0f }, { 1, 2,  121, +1.0f },
};

constexpr int TAPS_PER_OUT = 7;

/*
 * The whole plate, descriptors at the head of one PSRAM block and the lines behind them, the
 * same arrangement synth_fx_reverb.cpp uses: one allocation, one failure path, and no chance
 * of the pool fragmenting across thirteen small requests.
 */
struct Plate {
    Line  pre;              /* the input predelay */
    Line  dif[4];           /* the input diffusion allpasses */
    Line  ap[4];            /* the tank's diffusors, 0 and 2 modulated */
    Line  dl[4];            /* the tank's delays, 0 and 2 before the damping */
    int   left_at[TAPS_PER_OUT];
    int   right_at[TAPS_PER_OUT];
    float pre_lp;           /* the input's own lowpass state */
    float lp[2];            /* the damping lowpass, one per half */
    float cross[2];         /* what the other half handed over last sample */
    float damp_freq;        /* the damping coefficient in use */
    float decay;            /* the decay in use */
    float diff2;            /* the second diffusor's gain, derived from the decay */
    float lfo;              /* the modulation phase, 0..1 */
};

Plate *s_pl = nullptr;
float  s_scale  = 1.0f;
float  s_sr     = 48000.0f;
float  s_size   = 0.5f;
float  s_damp   = 0.0f;
float  s_mix    = 0.0f;
float  s_decay_to = DECAY_MIN + 0.5f * DECAY_SPAN;
float  s_damp_to  = DAMP_LIGHT;
float  s_lfo_inc  = 0.0f;
int    s_excursion = 16;
bool   s_ready  = false;
/* The audio task only ASKS for the plate; claim_task() does the work. Read and written
 * together with s_ready and nowhere else. */
volatile bool s_want_claim = false;
/* Set by the boot prefetch so its poll asks once. Read and written by that task alone. */
bool s_prefetch_asked = false;

/*
 * THE POOL HAS GONE BAD, set by synth_plate_reset_state(). claim_task() zeroes the lines and
 * puts the tank's one-poles back on the knobs' targets off the audio core; the process loop
 * returns silence until it has. The plate reads thirteen lines a sample, so a rescue that
 * left them poisoned would put the same NaN back in the tank on the very next block.
 */
volatile bool s_dirty = false;

int scaled(int samples)
{
    int n = (int)((float)samples * s_scale + 0.5f);
    return (n < 8) ? 8 : n;
}

inline float line_read(const Line &l, int back)
{
    int i = l.idx - back;
    while (i < 0) {
        i += l.len;
    }
    return l.buf[i];
}

inline float line_step(Line &l, float in)
{
    const float out = l.buf[l.idx];
    l.buf[l.idx] = in;
    if (++l.idx >= l.len) {
        l.idx = 0;
    }
    return out;
}

/*
 * A PROPER allpass, in the form the port uses: y = g*x + (1 - g^2)*d, with x - g*d stored.
 * Note that this is not the form Freeverb's own allpass takes — Freeverb's is an
 * approximation that diffuses without being allpass, which is fine where it is and would
 * change the plate's decay if it were used here. g may be negative; the first diffusor's is.
 */
inline float allpass_step(Line &l, float in, float g)
{
    const float d = l.buf[l.idx];
    const float s = in - g * d;
    l.buf[l.idx] = s;
    if (++l.idx >= l.len) {
        l.idx = 0;
    }
    return g * in + (1.0f - g * g) * d;
}

/* The modulated diffusor: the same filter read at a fractional position, which is what a
 * moving tap is. synth_fx_read() is the shared fractional read the chorus and the delay
 * already use, so the wrap arithmetic exists once. */
inline float allpass_mod(Line &l, float in, float g, float delay)
{
    const float d = synth_fx_read(l.buf, l.len, l.idx, delay);
    const float s = in - g * d;
    l.buf[l.idx] = s;
    if (++l.idx >= l.len) {
        l.idx = 0;
    }
    return g * in + (1.0f - g * g) * d;
}

/*
 * After boot, not on the first turn of the knob — and not in the audio task.
 *
 * The reason is spelled out in synth_fx_reverb.cpp: a large PSRAM claim inside the boot
 * sequence stops the Wi-Fi SoftAP from allocating its beacon buffers. The plate is a mode of
 * the reverb but it owns its own block, and BOTH blocks can be resident — the Freeverb's pool
 * is claimed for the widest of its modes, and the plate is one of those rows, so choosing the
 * plate claims the other engine's lines as well. The boot prefetch asks for both, in order,
 * three seconds after app_main has finished. They are claimed once and then kept; nothing
 * here pays for them twice.
 *
 * The claim is made by claim_task(), not in the audio task: a hundred and forty kilobytes of
 * PSRAM zeroed while a note is sounding is a hole six milliseconds wide, measured. The clear
 * is piecewise (synth_fx_zero()), so no single piece is a hole at all and the task is a
 * sequence of short bursts rather than one long one.
 */
bool claim_plate(void)
{
    if (s_ready) {
        return true;
    }

    const int pre_len = (int)(PREDELAY_MS * 0.001f * s_sr + 0.5f);
    s_excursion = (int)(EXCURSION_MS * 0.001f * s_sr + 0.5f);
    if (s_excursion < 1) {
        s_excursion = 1;
    }

    int    len_dif[4];
    int    len_ap[4];
    int    len_dl[4];
    size_t total = (size_t)((pre_len > 8) ? pre_len : 8);

    for (int i = 0; i < 4; i++) {
        const bool modulated = ((i & 1) == 0);

        len_dif[i] = scaled(IN_DIFF[i]) + 1;
        /* A modulated line needs room for the excursion on top of its own length, and the
         * read is clamped to len - 2, so the margin is two samples, not one. */
        len_ap[i]  = scaled(TANK_AP[i]) + (modulated ? s_excursion + 4 : 1);
        len_dl[i]  = scaled(TANK_DL[i]) + 1;

        total += (size_t)len_dif[i] + (size_t)len_ap[i] + (size_t)len_dl[i];
    }

    const size_t bytes = sizeof(Plate) + total * sizeof(float);
    s_pl = (Plate *)heap_caps_malloc(bytes, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!s_pl) {
        ESP_LOGE(TAG, "no room for %u bytes of plate — bypassed", (unsigned)bytes);
        return false;
    }
    memset(s_pl, 0, sizeof(Plate));

    float *p = (float *)(s_pl + 1);
    s_pl->pre = { p, (pre_len > 8) ? pre_len : 8, 0, (pre_len > 8) ? pre_len : 8 };
    p += s_pl->pre.len;

    for (int i = 0; i < 4; i++) {
        s_pl->dif[i] = { p, len_dif[i], 0, len_dif[i] };
        p += len_dif[i];
    }
    for (int i = 0; i < 4; i++) {
        const int nom = scaled(TANK_AP[i]);
        s_pl->ap[i] = { p, len_ap[i], 0, nom };
        p += len_ap[i];
    }
    for (int i = 0; i < 4; i++) {
        s_pl->dl[i] = { p, len_dl[i], 0, len_dl[i] };
        p += len_dl[i];
    }

    /* Every line is named now, so the ranges can be cleared. The helper bounds each burst;
     * see synth_fx_zero(). */
    synth_fx_zero(s_pl->pre.buf, sizeof(float) * (size_t)s_pl->pre.len);
    for (int i = 0; i < 4; i++) {
        synth_fx_zero(s_pl->dif[i].buf, sizeof(float) * (size_t)s_pl->dif[i].len);
        synth_fx_zero(s_pl->ap[i].buf, sizeof(float) * (size_t)s_pl->ap[i].len);
        synth_fx_zero(s_pl->dl[i].buf, sizeof(float) * (size_t)s_pl->dl[i].len);
    }

    for (int t = 0; t < TAPS_PER_OUT; t++) {
        s_pl->left_at[t]  = (int)((float)LEFT_TAPS[t].at * s_scale + 0.5f);
        s_pl->right_at[t] = (int)((float)RIGHT_TAPS[t].at * s_scale + 0.5f);
    }

    s_pl->damp_freq = s_damp_to;
    s_pl->decay = s_decay_to;
    s_pl->diff2 = DIFF2_MIN;

    ESP_LOGI(TAG, "dattorro plate: 4 diffusers, 4 tank diffusors, 4 tank lines, %u KB in PSRAM",
             (unsigned)(bytes / 1024));
    s_ready = true;             /* last, so the audio task never reads a half-zeroed line */
    return true;
}

/*
 * The audio path's side of it. Never allocates and never zeroes: it asks, and the task
 * created for the job answers by setting s_ready, which claim_plate() does last.
 *
 * The boot prefetch has usually already done the asking; this remains for a mix or a mode
 * that moves before it has run, and for a build that never starts it.
 */
bool ensure(void)
{
    if (s_ready) {
        return true;
    }

    s_want_claim = true;
    return false;
}

/*
 * The claim itself, off the audio core. It sleeps between looks rather than waiting on a
 * semaphore: one flag, one waiter, and at most one request per boot.
 *
 * It owns the rescue's zeroing as well, for the reason the flag above gives. The descriptors
 * sit at the head of the same block and are left alone: only their lines and the one-poles
 * that hold the tank's charge are touched.
 */
void claim_task(void *)
{
    for (;;) {
        if (s_dirty) {
            if (s_pl) {
                synth_fx_zero(s_pl->pre.buf, sizeof(float) * (size_t)s_pl->pre.len);
                s_pl->pre.idx = 0;
                for (int i = 0; i < 4; i++) {
                    synth_fx_zero(s_pl->dif[i].buf,
                                  sizeof(float) * (size_t)s_pl->dif[i].len);
                    s_pl->dif[i].idx = 0;
                    synth_fx_zero(s_pl->ap[i].buf,
                                  sizeof(float) * (size_t)s_pl->ap[i].len);
                    s_pl->ap[i].idx = 0;
                    synth_fx_zero(s_pl->dl[i].buf,
                                  sizeof(float) * (size_t)s_pl->dl[i].len);
                    s_pl->dl[i].idx = 0;
                }

                s_pl->pre_lp = 0.0f;
                s_pl->lp[0] = s_pl->lp[1] = 0.0f;
                s_pl->cross[0] = s_pl->cross[1] = 0.0f;

                /* The tank's poles on the knobs' targets, not on zero: after a rescue the
                 * plate must sound like the SIZE and DAMP the player can see. */
                s_pl->decay = s_decay_to;
                s_pl->damp_freq = s_damp_to;

                float diff2 = s_pl->decay + DIFF2_ADD;
                if (diff2 < DIFF2_MIN) {
                    diff2 = DIFF2_MIN;
                } else if (diff2 > DIFF2_MAX) {
                    diff2 = DIFF2_MAX;
                }
                s_pl->diff2 = diff2;
                s_pl->lfo = 0.0f;
            }
            s_dirty = false;    /* last: the audio task may read the lines again after this */
            continue;
        }

        if (!s_want_claim || s_ready) {
            vTaskDelay(pdMS_TO_TICKS(10));
            continue;
        }

        s_want_claim = false;   /* one attempt: a failure would only repeat the log line */
        if (!claim_plate()) {
            ESP_LOGW(TAG, "plate not claimed — the plate stays bypassed until reboot");
        }
    }
}

inline float tap_read(const Plate &pl, int half, int line, int at)
{
    const Line &ln = (line == 0) ? pl.dl[half * 2]
                   : (line == 1) ? pl.ap[half * 2 + 1]
                                 : pl.dl[half * 2 + 1];
    return line_read(ln, at);
}

/*
 * One sample: in goes the send, out come the two channels. The tank is ONE network — the two
 * halves hand each other their decayed post-damping output, which is the cross-feedback in
 * the paper's figure — and the stereo comes from the taps, not from running it twice.
 */
inline void plate_sample(Plate &pl, float in, float exc, float *out_l, float *out_r)
{
    /* The pre-delay, then the input's own light lowpass, then four allpasses in series. */
    float x = line_step(pl.pre, in);
    pl.pre_lp += (x - pl.pre_lp) * PREFILTER;
    x = pl.pre_lp;

    x = allpass_step(pl.dif[0], x, IN_DIFF_G1);
    x = allpass_step(pl.dif[1], x, IN_DIFF_G1);
    x = allpass_step(pl.dif[2], x, IN_DIFF_G2);
    x = allpass_step(pl.dif[3], x, IN_DIFF_G2);

    for (int h = 0; h < 2; h++) {
        /* The diffused input plus what the other half handed over last sample. */
        float y = x + pl.cross[h];

        /* The modulated diffusor comes FIRST, with a negated gain: that is the port's sign
         * and the paper's, and putting it after the delay was this file's first mistake. */
        y = allpass_mod(pl.ap[h * 2], y, -DECAY_DIFF_G, (float)pl.ap[h * 2].nom + exc);

        /* The delay before the damping, then the damping lowpass itself, then the decay. */
        y = line_step(pl.dl[h * 2], y);
        pl.lp[h] += (y - pl.lp[h]) * pl.damp_freq;
        y = pl.lp[h] * pl.decay;

        /* The second diffusor, whose gain follows the decay, and the delay after it — the
         * one the other half reads. */
        y = allpass_step(pl.ap[h * 2 + 1], y, pl.diff2);
        y = line_step(pl.dl[h * 2 + 1], y);
        pl.cross[h] = y * pl.decay;
    }

    /* The taps are read after the writes above, which is one sample later than the port
     * reads them; at this length of line that is not a difference anybody can hear. */
    float l = 0.0f;
    float r = 0.0f;
    for (int t = 0; t < TAPS_PER_OUT; t++) {
        l += LEFT_TAPS[t].sign  * tap_read(pl, LEFT_TAPS[t].half,  LEFT_TAPS[t].line,  pl.left_at[t]);
        r += RIGHT_TAPS[t].sign * tap_read(pl, RIGHT_TAPS[t].half, RIGHT_TAPS[t].line, pl.right_at[t]);
    }

    *out_l = l;
    *out_r = r;
}

} // namespace

/* The boot prefetch's question, asked until the answer is yes. One request: the claim task
 * gets one attempt, and a second would fail the same way and log twice. */
bool synth_plate_prefetch(void)
{
    if (s_ready) {
        return true;
    }

    if (!s_prefetch_asked) {
        s_prefetch_asked = true;
        s_want_claim = true;
    }
    return false;
}

void synth_plate_init(uint32_t sample_rate)
{
    s_sr = (float)sample_rate;
    s_scale = (float)sample_rate / (float)PAPER_RATE;
    s_lfo_inc = MOD_HZ / (float)sample_rate;   /* phase runs 0..1, so this is per sample */
    s_size = 0.5f;
    s_damp = 0.0f;
    s_mix = 0.0f;
    s_decay_to = DECAY_MIN + s_size * DECAY_SPAN;
    s_damp_to = DAMP_LIGHT - s_damp * DAMP_SPAN;

    /* The task that does the claim, on the core the audio task is not on, at the lowest
     * priority there is: it only wakes when the audio path has asked for the plate. */
    xTaskCreatePinnedToCore(claim_task, "plate_claim", 3072, nullptr, 1, nullptr, 0);
}

void synth_plate_set(float size01, float damp01, float mix01)
{
    /*
     * Negated lower tests, the same rule as every other setter: NaN fails `!(x >= min)`
     * and lands on the bound, where `x < min` passed it into the decay and the damping —
     * two numbers the tank applies on every sample for the rest of the tail, long after
     * the block the setter ran in has been looked at.
     */
    if (!(size01 >= 0.0f)) {
        size01 = 0.0f;
    } else if (size01 > 1.0f) {
        size01 = 1.0f;
    }
    if (!(damp01 >= 0.0f)) {
        damp01 = 0.0f;
    } else if (damp01 > 1.0f) {
        damp01 = 1.0f;
    }
    if (!(mix01 >= 0.0f)) {
        mix01 = 0.0f;
    } else if (mix01 > 1.0f) {
        mix01 = 1.0f;
    }

    s_size = size01;
    s_damp = damp01;
    s_mix = mix01;
    s_decay_to = DECAY_MIN + s_size * DECAY_SPAN;
    s_damp_to = DAMP_LIGHT - s_damp * DAMP_SPAN;
}

/*
 * The rescue, from synth_rack.cpp's fuse. The block is marked dirty and claim_task() — the
 * task that already owns this memory — does the clearing; the process loop returns silence
 * until it has. Nothing here touches the lines: this runs in the audio task, and the tank is
 * a hundred and forty kilobytes.
 */
void synth_plate_reset_state(void)
{
    if (s_pl) {
        s_dirty = true;
    }
}

/*
 * The output lands in wet_l / wet_r RAW: the balance between this and the dry signal belongs
 * to the rack, which owns the mix and applies it to the pair — exactly as the delay does. The
 * crossfade that hides a mode change belongs to synth_fx_reverb.cpp, which owns the mode, and
 * is applied to these buffers afterwards.
 */
IRAM_ATTR void synth_plate_process(int samples, const float *send, float *wet_l, float *wet_r)
{
    if (!wet_l || !wet_r || samples <= 0) {
        return;
    }

    if (s_mix <= 0.0f || !ensure()) {
        for (int i = 0; i < samples; i++) {
            wet_l[i] = 0.0f;
            wet_r[i] = 0.0f;
        }
        return;
    }

    /* Not cleared yet: the wet is the rack's return, so it is silence rather than the send. */
    if (s_dirty) {
        for (int i = 0; i < samples; i++) {
            wet_l[i] = 0.0f;
            wet_r[i] = 0.0f;
        }
        return;
    }

    /* The knobs glide once per block, and the modulation is interpolated across the block:
     * two sines per block instead of two per sample, which at 0.73 Hz is smoother than
     * anything a listener can name. */
    const float k = 1.0f - expf(-(float)samples / (GLIDE_MS * 0.001f * s_sr));
    s_pl->decay += (s_decay_to - s_pl->decay) * k;
    s_pl->damp_freq += (s_damp_to - s_pl->damp_freq) * k;

    float diff2 = s_pl->decay + DIFF2_ADD;
    if (diff2 < DIFF2_MIN) {
        diff2 = DIFF2_MIN;
    } else if (diff2 > DIFF2_MAX) {
        diff2 = DIFF2_MAX;
    }
    s_pl->diff2 = diff2;

    const float phase = s_pl->lfo;
    const float exc0 = (float)s_excursion * sinf(6.2831853f * phase);
    const float exc1 = (float)s_excursion * sinf(6.2831853f * (phase + (float)samples * s_lfo_inc));
    const float exc_step = (exc1 - exc0) / (float)samples;

    float exc = exc0;
    for (int i = 0; i < samples; i++) {
        float l = 0.0f;
        float r = 0.0f;
        plate_sample(*s_pl, send[i] * IN_GAIN, exc, &l, &r);
        wet_l[i] = l;
        wet_r[i] = r;
        exc += exc_step;
    }

    s_pl->lfo += s_lfo_inc * (float)samples;
    while (s_pl->lfo >= 1.0f) {
        s_pl->lfo -= 1.0f;
    }
}
