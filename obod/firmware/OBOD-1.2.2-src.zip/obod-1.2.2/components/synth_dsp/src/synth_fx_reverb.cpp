#include "esp_attr.h"
#include "synth_dsp.h"
#include "synth_dsp_private.h"

#include <math.h>
#include <string.h>

#include "esp_heap_caps.h"
#include "esp_log.h"

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

/*
 * Freeverb.
 *
 * Eight damped combs into four allpasses, per channel, with the right channel's
 * lines longer by the usual spread. This is Schroeder's topology in the form
 * Freeverb settled on, and it is here for the same reason it is everywhere: it
 * sounds like a room, it costs a quarter of what a convolution costs, and it has
 * exactly three controls that a player can understand.
 *
 * It is also the only genuinely two-channel effect here. The engine is mono, the
 * chorus merely widens what the panner already did, but the reverb invents a
 * space that was never in the signal — which is why it gets its own send bus and
 * four send levels, one per layer, rather than a single mix.
 *
 * Everything this needs — the hundred kilobytes of delay lines and the twelve
 * line descriptors per channel — is one PSRAM block, claimed by the boot prefetch once the
 * radio and the screen are up. See the note in claim_pool().
 *
 * The player can choose between four ALGORITHMS: three SETTINGS of this one engine —
 * the line lengths, the comb feedback, the damping and what goes in are enough to make
 * a small damped room, the hall this reverb always was and a cathedral that rings for
 * seconds — and the plate, which is a different topology rather than different numbers.
 * See MODE below for the numbers and for what is deliberately not here.
 */

namespace {

constexpr const char *TAG = "reverb";

constexpr int COMB_COUNT    = 8;
constexpr int ALLPASS_COUNT = 4;

/* Freeverb's tunings at 44.1 kHz, scaled to the running rate when claimed. */
const int COMB_TUNE[COMB_COUNT]       = { 1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617 };
const int ALLPASS_TUNE[ALLPASS_COUNT] = { 556, 441, 341, 225 };
constexpr int STEREO_SPREAD = 23;

constexpr float INPUT_GAIN = 0.015f;     /* Freeverb's fixed input gain */
constexpr float ALLPASS_FB = 0.5f;

/*
 * Anti-denormal.
 *
 * A feedback loop that decays towards zero spends its last few seconds at
 * magnitudes that are denormal, and arithmetic on those is not free on every
 * FPU. One part in 10^30 is far below anything audible and keeps every state
 * variable in the normal range.
 */
constexpr float ANTI_DENORMAL = 1e-30f;

/*
 * WHAT THE PLAYER CHOOSES. Three sets of numbers for the engine above, and a fourth entry
 * that is not this engine at all.
 *
 * That is what "the cheapest reverbs" means here, and it is worth being plain about what it
 * buys and what it does not. A tail's LENGTH is a function of the line lengths and the comb
 * feedback; its CHARACTER is a function of the damping and of how wide the lines are spread;
 * so scale, feedback, damping and input gain are enough for a small dark room, the hall this
 * reverb always was and a cathedral. Every one of those three is the same
 * twelve lines and the same per-sample cost, so the choice cannot make
 * the audio task miss its deadline — which is the property that matters on this instrument.
 *
 * The fourth is Dattorro's plate, and it is a different TOPOLOGY rather than different
 * numbers: different feedback paths, a different stability argument, its own file
 * (synth_fx_plate.cpp) and its own PSRAM block, because the two engines are never both
 * resident. It is no more of a risk to the deadline than the other three, and for a reason
 * worth stating: it reads THIRTEEN delay lines a sample where this engine reads twenty-four.
 * That file says where its numbers come from and which three are deliberately not the paper's.
 *
 * A FOURTH NUMERIC MODE STOOD HERE — HOLD, a tail held by a comb loop gain just under one.
 * It is gone because the sound broke on the way out of it into the cathedral. Its row is out
 * of the table rather than left switched off under it, because a mode nobody chooses only rots.
 * SYNTH_REVERB_MODE_COUNT followed it down
 * and so did the position of PLATE, so a value already stored in the flash that named HOLD is
 * migrated to HALL once, by list position — see app_settings.c for the remembered sound and
 * app_presets.c for the preset slots.
 *
 * What is still NOT here: an FDN (Jot) is a third topology, and shimmer needs a pitch shifter
 * inside this loop and is the most expensive thing on the list. Both are in FEATURES.md.
 *
 * The layout is claimed for the WIDEST of the numeric modes and never changes size, so
 * switching between them is arithmetic and never an allocation: 150 KB from the audio task's
 * heap is not a thing to ask for while a note is sounding.
 */
struct Mode {
    float scale;        /* multiplies every line: the size of the space */
    float damp_mul;     /* multiplies the DAMP knob */
    float fb_min;       /* comb feedback = fb_min + SIZE * fb_span */
    float fb_span;
    float input_mul;    /* multiplies what arrives from the send */
    bool  plate;        /* Dattorro's plate instead: none of the fields above is used */
};

const Mode MODE[SYNTH_REVERB_MODE_COUNT] = {
    /* ROOM      */ { 0.62f, 1.35f, 0.700f, 0.260f, 1.00f, false },
    /* HALL      */ { 1.00f, 1.00f, 0.700f, 0.280f, 1.00f, false },
    /* CATHEDRAL */ { 1.45f, 0.45f, 0.740f, 0.250f, 1.00f, false },
    /* PLATE     */ { 1.00f, 1.00f, 0.700f, 0.280f, 1.00f, true  },
};

/*
 * AND A MODE CHANGE IS NOT A JUMP.
 *
 * Re-cutting the lines means the same memory is read at different places from one sample
 * to the next, and if a tail is sounding through it that is a step in the waveform, which
 * in a sounding tail is a click. So the wet is faded out over WET_DOWN_MS, the lines are
 * re-cut at the bottom of that fade where nothing is coming out, and it comes back over
 * WET_UP_MS. What a switch sounds like is then the space changing around the tail, which
 * is what is actually happening, rather than the waveform being cut.
 *
 * The SHAPE underneath moves on its own, slower schedule: the comb feedback, the damping
 * and the input gain glide towards the new mode over GLIDE_MS, so the decay becomes the
 * other decay instead of stepping. That is also what smooths a knob: a comb's feedback is
 * a gain, and a step in it is a click nobody reports and everybody hears.
 */
constexpr float WET_DOWN_MS = 15.0f;
constexpr float WET_UP_MS   = 250.0f;
constexpr float GLIDE_MS    = 250.0f;

struct Comb {
    float *buf;
    int    len;
    int    idx;
    float  store;
    float  feedback;
    float  damp1;
    float  damp2;
};

struct Allpass {
    float *buf;
    int    len;
    int    idx;
    float  feedback;
};

/*
 * The descriptors live next to the lines they describe, inside the same block.
 * Twelve of them per channel is 640 bytes, which is not much — but this file has
 * already learned what "not much" does to the boot path, and a pointer load per
 * comb per sample is not a price worth arguing about.
 */
struct State {
    Comb    comb[2][COMB_COUNT];
    Allpass ap[2][ALLPASS_COUNT];
};

State *s_st    = nullptr;
float  s_scale = 1.0f;      /* sample rate / 44100, for the tunings */
float  s_sr    = 48000.0f;  /* and the rate itself, for the time constants */
float  s_size  = 0.5f;
float  s_damp  = 0.4f;
float  s_mix   = 0.0f;
int    s_mode  = SYNTH_REVERB_HALL;     /* the mode the lines are cut for */
int    s_want  = SYNTH_REVERB_HALL;     /* the mode the player last asked for */
bool   s_ready = false;
/* The audio path only ASKS for the pool; claim_task() does the work. Read and written
 * together with s_ready and nowhere else. */
volatile bool s_want_claim = false;
/* Set by the boot prefetch so its poll asks once. Read and written by that task alone. */
bool s_prefetch_asked = false;

/*
 * THE POOL HAS GONE BAD. Set by synth_reverb_reset_state() after a non-finite sample has
 * reached the rack's output; claim_task() zeroes the lines and snaps the shape off the audio
 * core, and synth_reverb_process() answers with silence until it has. A hundred and sixty
 * kilobytes is not the delay's megabyte and a half, but it is still a memset that does not
 * belong in a 5.33 ms block.
 */
volatile bool s_dirty = false;

/* The crossfade around a mode change, and the shape glide under it. The glide is a
 * one-pole per BLOCK, not per sample: what it moves is a set of gains, and a gain that
 * arrives over 250 ms in steps of 2.7 ms is smooth by any measure a listener has. */
float  s_wet       = 1.0f;
float  s_wet_down  = 0.0f;
float  s_wet_up    = 0.0f;
float  s_fb_cur    = 0.0f;
float  s_damp_cur  = 0.0f;
float  s_in_cur    = 1.0f;
float  s_fb_to     = 0.0f;
float  s_damp_to   = 0.0f;
float  s_in_to     = 1.0f;

IRAM_ATTR inline float comb_step(Comb &c, float in)
{
    const float out = c.buf[c.idx];
    c.store = out * c.damp2 + c.store * c.damp1;
    c.buf[c.idx] = in + c.store * c.feedback + ANTI_DENORMAL;
    if (++c.idx >= c.len) {
        c.idx = 0;
    }
    return out;
}

IRAM_ATTR inline float allpass_step(Allpass &a, float in)
{
    const float bufout = a.buf[a.idx];
    a.buf[a.idx] = in + bufout * a.feedback;
    if (++a.idx >= a.len) {
        a.idx = 0;
    }
    return bufout - in;
}

/*
 * The shape, in two halves. The targets come from the knobs and the mode; what the combs
 * actually use is moved towards them by shape_step(), which is what turns a mode change
 * into a space changing rather than a step, and a knob move into something that does not
 * click. apply_shape() is therefore cheap and safe to call on every setter call.
 */
void apply_shape(void)
{
    if (!s_st) {
        return;
    }

    const Mode &m = MODE[s_mode];
    s_fb_to   = m.fb_min + s_size * m.fb_span;
    s_damp_to = s_damp * m.damp_mul * 0.4f;
    s_in_to   = m.input_mul;
}

/* One glide step, and the only place the coefficients are written into the combs. Called
 * once per block from synth_reverb_process(). The step is 1 - exp(-samples / GLIDE_MS)
 * of the distance that is left, which is a one-pole that cannot overshoot. */
void shape_step(int samples)
{
    if (!s_st) {
        return;
    }

    const float k = 1.0f - expf(-(float)samples / (GLIDE_MS * 0.001f * (float)s_sr));
    s_fb_cur   += (s_fb_to - s_fb_cur) * k;
    s_damp_cur += (s_damp_to - s_damp_cur) * k;
    s_in_cur   += (s_in_to - s_in_cur) * k;

    const float d2 = 1.0f - s_damp_cur;
    for (int c = 0; c < 2; c++) {
        for (int i = 0; i < COMB_COUNT; i++) {
            s_st->comb[c][i].feedback = s_fb_cur;
            s_st->comb[c][i].damp1 = s_damp_cur;
            s_st->comb[c][i].damp2 = d2;
        }
    }
}

/* The first application, which has nothing to glide FROM: the lines have just been
 * zeroed and there is no old shape to leave behind. */
void snap_shape(void)
{
    s_fb_cur = s_fb_to;
    s_damp_cur = s_damp_to;
    s_in_cur = s_in_to;
    shape_step(1);
}

/*
 * Point every line at the length this mode wants.
 *
 * The pool is cut once, for the widest mode, and never moves again: here the same pool is
 * re-cut, so a narrower mode uses a prefix of its own line and nothing is allocated or freed. An index that a shorter line no longer contains is pulled back to
 * the start of its buffer — that costs one sample of whatever was in the tail and, more to
 * the point, it cannot read outside the block it belongs to.
 */
void apply_mode(void)
{
    /* The plate cuts nothing: its lines are its own, they never change length, and its block
     * may not even be claimed yet. */
    if (MODE[s_mode].plate) {
        return;
    }

    if (!s_st) {
        return;
    }

    const Mode &m = MODE[s_mode];

    for (int c = 0; c < 2; c++) {
        const int spread = c ? STEREO_SPREAD : 0;

        for (int i = 0; i < COMB_COUNT; i++) {
            Comb &cb = s_st->comb[c][i];
            cb.len = (int)((float)COMB_TUNE[i] * s_scale * m.scale) + spread;
            if (cb.idx >= cb.len) {
                cb.idx = 0;
            }
        }
        for (int i = 0; i < ALLPASS_COUNT; i++) {
            Allpass &ap = s_st->ap[c][i];
            ap.len = (int)((float)ALLPASS_TUNE[i] * s_scale * m.scale) + spread;
            if (ap.idx >= ap.len) {
                ap.idx = 0;
            }
        }
    }

    apply_shape();
}

/*
 * The line lengths a mode needs, and the bytes they come to. One formula, so that the pool
 * claimed in claim_pool() and the lines cut in apply_mode() can never disagree.
 * lens may be null when only the size is wanted.
 */
size_t pool_lens(float scale, int lens[2][COMB_COUNT + ALLPASS_COUNT])
{
    size_t total = 0;

    for (int c = 0; c < 2; c++) {
        const int spread = c ? STEREO_SPREAD : 0;

        for (int i = 0; i < COMB_COUNT; i++) {
            const int len = (int)((float)COMB_TUNE[i] * s_scale * scale) + spread;
            if (lens) {
                lens[c][i] = len;
            }
            total += (size_t)len;
        }
        for (int i = 0; i < ALLPASS_COUNT; i++) {
            const int len = (int)((float)ALLPASS_TUNE[i] * s_scale * scale) + spread;
            if (lens) {
                lens[c][COMB_COUNT + i] = len;
            }
            total += (size_t)len;
        }
    }

    return sizeof(State) + total * sizeof(float);
}

/*
 * One sample of the crossfade a mode change runs: down over WET_DOWN_MS, the lines re-cut at
 * the bottom of that fade where nothing is coming out, and back up over WET_UP_MS. Here
 * rather than in the setter because a fade needs a sample clock, and here rather than inline
 * in the block loop because the plate's path needs it too — two copies of a fade would be
 * two places for it to drift apart.
 */
IRAM_ATTR inline void fade_step(void)
{
    if (s_want != s_mode) {
        s_wet -= s_wet_down;
        if (s_wet <= 0.0f) {
            s_wet = 0.0f;
            s_mode = s_want;
            apply_mode();
        }
    } else if (s_wet < 1.0f) {
        s_wet += s_wet_up;
        if (s_wet > 1.0f) {
            s_wet = 1.0f;
        }
    }
}

/*
 * After boot, not on the first turn of a knob — and not in the audio task either.
 *
 * The layout is claimed for the WIDEST of the modes and never changes size again, so switching
 * between them is arithmetic and never an allocation. Sizing each mode for itself was tried and
 * taken back out: it is worth forty to ninety microseconds on a block, and it costs a free and
 * a re-claim — three to six milliseconds wide — every time the algorithm knob moves, plus a
 * hundred and eight kilobytes of the internal heap that the rest of the instrument wants.
 *
 * Inside the boot sequence this stopped the Wi-Fi SoftAP from allocating its beacon buffers,
 * and the Wi-Fi driver's reaction to that failure is an unchecked NULL dereference and a reboot
 * loop. Leaving it until the first mix or send was raised put the clear in the middle of a
 * phrase. So synth_dsp_prefetch_start() asks for it three seconds after app_main has finished:
 * late enough for the radio, early enough for the first phrase. The audio path still never
 * allocates or zeroes; claim_task() owns both, off the audio core.
 *
 * One allocation for the lines and their descriptors together: one failure path, and no chance
 * of the pool fragmenting across a dozen small requests. The descriptors are zeroed as a
 * structure; the lines behind them are cleared piecewise by synth_fx_zero(), which is what
 * keeps a hundred and sixty kilobytes of clear from becoming one long burst on the PSRAM bus.
 */
bool claim_pool(void)
{
    /* The WIDEST of the modes, so that no later switch has to move the pool: a move is a free,
     * a claim and a zeroing of a hundred and fifty kilobytes in the middle of the audio task,
     * measured at three to six milliseconds, and it lands every time the algorithm knob moves. */
    float widest = 0.0f;
    for (int i = 0; i < SYNTH_REVERB_MODE_COUNT; i++) {
        if (MODE[i].scale > widest) {
            widest = MODE[i].scale;
        }
    }

    int lens[2][COMB_COUNT + ALLPASS_COUNT];
    const size_t bytes = pool_lens(widest, lens);

    /* PSRAM, always: at 48 kHz the widest mode wants 161 KB and the internal heap has about
     * 152, so a pool that must never move cannot live inside. Taking it there anyway was tried
     * and measured — it is worth forty to ninety microseconds on a block, and it costs a
     * hundred and eight kilobytes of internal heap, most of what the rest of the instrument has
     * left after boot. See the note above ensure(). */
    s_st = (State *)heap_caps_malloc(bytes, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!s_st) {
        ESP_LOGE(TAG, "no room for %u bytes of reverb — bypassed", (unsigned)bytes);
        return false;
    }
    memset(s_st, 0, sizeof(State));

    float *p = (float *)(s_st + 1);
    for (int c = 0; c < 2; c++) {
        for (int i = 0; i < COMB_COUNT; i++) {
            s_st->comb[c][i] = { p, lens[c][i], 0, 0.0f, 0.84f, 0.2f, 0.8f };
            p += lens[c][i];
        }
        for (int i = 0; i < ALLPASS_COUNT; i++) {
            s_st->ap[c][i] = { p, lens[c][COMB_COUNT + i], 0, ALLPASS_FB };
            p += lens[c][COMB_COUNT + i];
        }
    }

    /* Now that every descriptor names its range, the ranges are cleared. This is the
     * hundred and sixty kilobytes the comment above is about; doing it line by line lets
     * synth_fx_zero() put a tick between its pieces and keeps each burst short. */
    for (int c = 0; c < 2; c++) {
        for (int i = 0; i < COMB_COUNT; i++) {
            const Comb &cb = s_st->comb[c][i];
            synth_fx_zero(cb.buf, sizeof(float) * (size_t)cb.len);
        }
        for (int i = 0; i < ALLPASS_COUNT; i++) {
            const Allpass &ap = s_st->ap[c][i];
            synth_fx_zero(ap.buf, sizeof(float) * (size_t)ap.len);
        }
    }

    /* The running mode's own lengths, which are a prefix of what was just claimed, and
     * a shape snapped rather than glided: these lines have just been zeroed, so there is
     * no old shape for the glide to leave behind. */
    apply_mode();
    snap_shape();
    /* The mode is an index; its name is on the screen, in synth_app's readout. */
    ESP_LOGI(TAG, "freeverb: %d combs + %d allpasses a side, %u KB in PSRAM, mode %d",
             COMB_COUNT, ALLPASS_COUNT, (unsigned)(bytes / 1024), s_mode);

    s_ready = true;             /* last, so the audio task never reads a half-zeroed line */
    return true;
}

/*
 * The audio path's side of it. Never allocates and never zeroes: it asks, and the task created
 * for the job answers by setting s_ready, which claim_pool() does last.
 *
 * The boot prefetch has usually already done the asking; this remains for a mix or a send that
 * moves before it has run, and for a build that never starts it.
 */
bool ensure(void)
{
    if (s_ready) {
        return true;
    }

    s_want_claim = true;
    return false;
}

/*
 * The claim itself, off the audio core. It sleeps between looks rather than waiting on a
 * semaphore: one flag, one waiter, and at most one request per boot.
 *
 * It also owns the rescue's zeroing, for the reason the flag above gives. Every line is
 * cleared through its own descriptor rather than by one memset over the block, because the
 * descriptors live at the head of that block and carry the lengths and the shape.
 */
void claim_task(void *)
{
    for (;;) {
        if (s_dirty) {
            if (s_st) {
                for (int c = 0; c < 2; c++) {
                    for (int i = 0; i < COMB_COUNT; i++) {
                        Comb &cb = s_st->comb[c][i];
                        synth_fx_zero(cb.buf, sizeof(float) * (size_t)cb.len);
                        cb.idx = 0;
                        cb.store = 0.0f;
                    }
                    for (int i = 0; i < ALLPASS_COUNT; i++) {
                        Allpass &ap = s_st->ap[c][i];
                        synth_fx_zero(ap.buf, sizeof(float) * (size_t)ap.len);
                        ap.idx = 0;
                    }
                }

                /* The shape, snapped rather than glided: these lines are silent, so there is
                 * no old tail for a 250 ms glide to smear. */
                apply_mode();
                snap_shape();
            }
            s_dirty = false;    /* last: the audio task may read the lines again after this */
            continue;
        }

        if (!s_want_claim || s_ready) {
            vTaskDelay(pdMS_TO_TICKS(10));
            continue;
        }

        s_want_claim = false;   /* one attempt: a failure would only repeat the log line */
        if (!claim_pool()) {
            ESP_LOGW(TAG, "reverb not claimed — the reverb stays bypassed until reboot");
        }
    }
}

} // namespace

/* The boot prefetch's question, asked until the answer is yes. One request: a failed claim
 * is not retried, because the second attempt would fail for the same reason and log twice. */
bool synth_reverb_prefetch(void)
{
    if (s_ready) {
        return true;
    }

    if (!s_prefetch_asked) {
        s_prefetch_asked = true;
        s_want_claim = true;
    }
    return false;
}

void synth_reverb_init(uint32_t sample_rate)
{
    /* The task that does the claim, on the core the audio task is not on, at the lowest
     * priority there is: it only wakes when the audio path has asked for the pool. */
    xTaskCreatePinnedToCore(claim_task, "verb_claim", 3072, nullptr, 1, nullptr, 0);

    s_scale = (float)sample_rate / 44100.0f;
    s_sr    = (float)sample_rate;

    /* The time constants, in samples: the two halves of the crossfade a mode change runs.
     * This is the only place in this file where milliseconds become numbers. */
    s_wet_down  = 1.0f / (WET_DOWN_MS * 0.001f * s_sr);
    s_wet_up    = 1.0f / (WET_UP_MS * 0.001f * s_sr);

    s_want = SYNTH_REVERB_HALL;

    /* The plate is a mode of this module, so this module starts it. Its own block is not
     * claimed here — it is claimed the first time the plate mode is actually asked for. */
    synth_plate_init(sample_rate);

    synth_reverb_set(0.5f, 0.4f, 0.0f, SYNTH_REVERB_HALL);
}

void synth_reverb_set(float size01, float damp01, float mix01, int mode)
{
    /*
     * Negated lower tests: a NaN fails them and lands on the low bound instead of
     * reaching apply_shape(), where it became a comb feedback and stayed in the tail
     * for as long as the tail lasted — long after the fuse's look at the block that
     * the setter ran in. An infinity is pulled to the bound it names.
     */
    if (!(size01 >= 0.0f)) {
        size01 = 0.0f;
    } else if (size01 > 1.0f) {
        size01 = 1.0f;
    }
    if (!(damp01 >= 0.0f)) {
        damp01 = 0.0f;
    } else if (damp01 > 1.0f) {
        damp01 = 1.0f;
    }
    if (!(mix01 >= 0.0f)) {
        mix01 = 0.0f;
    } else if (mix01 > 1.0f) {
        mix01 = 1.0f;
    }
    if (mode < 0 || mode >= SYNTH_REVERB_MODE_COUNT) {
        mode = SYNTH_REVERB_HALL;
    }

    s_size = size01;
    s_damp = damp01;
    s_mix = mix01;

    if (mode != s_want) {
        s_want = mode;
        /*
         * With the mix down there is nothing to fade, so the lines are cut here and the
         * crossfade is skipped: setting up a sound with the reverb off should not cost a
         * quarter of a second of waiting. Otherwise the crossfade is run from the block
         * loop, which is the only place with a sample clock to run it against.
         */
        if (s_mix <= 0.0f) {
            s_mode = s_want;
            apply_mode();
        }
    }

    apply_shape();
}

/*
 * The rescue, from synth_rack.cpp's fuse. The crossfade is snapped open and the mode is taken
 * as the one the player asked for — a rescue in the middle of a mode change would otherwise
 * leave the wet at whatever the fade had reached, which after a poisoning is zero. The pool
 * is marked dirty instead of being cleared here: claim_task() owns that memory, and a
 * hundred and sixty kilobytes of memset in the audio task is the same mistake at a smaller
 * scale as the delay's megabyte and a half.
 */
void synth_reverb_reset_state(void)
{
    s_wet = 1.0f;
    s_mode = s_want;
    if (s_st) {
        s_dirty = true;
    }
}

IRAM_ATTR void synth_reverb_process(int samples, const float *send, float *wet_l, float *wet_r)
{
    if (!wet_l || !wet_r || samples <= 0) {
        return;
    }

    if (s_mix <= 0.0f) {
        /* No reverb wanted, so the answer is no reverb. Silence rather than garbage, because
         * the rack always reads these buffers: at zero mix its balance is dry times one plus
         * this, so zero here means the dry passes through untouched. */
        for (int i = 0; i < samples; i++) {
            wet_l[i] = 0.0f;
            wet_r[i] = 0.0f;
        }
        return;
    }

    /*
     * The plate is a different topology in a different file with its own block, so it is
     * dispatched to before any of the machinery below is touched. Nothing is shared with it
     * except the mode, the three knobs and the crossfade — and, deliberately, the Freeverb's
     * own block is not claimed at all on this path.
     */
    if (MODE[s_mode].plate) {
        synth_plate_set(s_size, s_damp, s_mix);
        synth_plate_process(samples, send, wet_l, wet_r);

        /* The crossfade is the reverb's because the mode is. It runs over the buffer the
         * plate has just written, so a switch takes effect on the NEXT block, 2.7 ms later,
         * by which time the fade is already on its way back up from zero. That is why the
         * switch cannot click even though the topology changes between two blocks. */
        for (int i = 0; i < samples; i++) {
            fade_step();
            wet_l[i] *= s_wet;
            wet_r[i] *= s_wet;
        }
        return;
    }

    /*
     * A dirty pool has not been cleared yet; until it has, the room has nothing to say. The
     * buffers are the rack's wet RETURN, so they are silenced: leaving the send in them would
     * add dry signal through a path whose whole job is to add space.
     */
    if (s_dirty) {
        for (int i = 0; i < samples; i++) {
            wet_l[i] = 0.0f;
            wet_r[i] = 0.0f;
        }
        return;
    }

    if (!ensure()) {
        for (int i = 0; i < samples; i++) {
            wet_l[i] = 0.0f;
            wet_r[i] = 0.0f;
        }
        return;
    }

    /* One glide step for the whole block, before anything is read from it. */
    shape_step(samples);

    const float input_gain = INPUT_GAIN * s_in_cur;

    for (int i = 0; i < samples; i++) {
        /*
         * A mode change, if one is waiting: the wet goes down, the lines are re-cut at the
         * bottom of that fade where nothing is coming out, and it comes back up. Here
         * rather than in the setter because a fade needs a sample clock.
         */
        fade_step();

        const float in = send[i] * input_gain;

        float l = 0.0f;
        float r = 0.0f;

        for (int c = 0; c < COMB_COUNT; c++) {
            l += comb_step(s_st->comb[0][c], in);
            r += comb_step(s_st->comb[1][c], in);
        }
        for (int a = 0; a < ALLPASS_COUNT; a++) {
            l = allpass_step(s_st->ap[0][a], l);
            r = allpass_step(s_st->ap[1][a], r);
        }

        /*
         * RAW, with no mix applied: the balance between this and the dry signal belongs to
         * the rack, which owns the mix and sums the two — the same law the delay uses. The
         * mix is still what decides whether this runs at all, above.
         */
        wet_l[i] = l * s_wet;
        wet_r[i] = r * s_wet;
    }
}
