#include "synth_dsp.h"
#include "synth_dsp_private.h"

/*
 * The microphone's way into the instrument: a bus INPUT, not a voice.
 *
 * WHY IT IS A BUS FX AND NOT A LAYER
 *   The engine's layers are buses of voices, and a microphone is not a voice: it has
 *   no pitch, no envelope of its own and no note. Giving it a layer would mean giving
 *   it a fader in the dry mix, and a microphone in the dry mix in the same room as the
 *   speaker is a feedback loop with a time constant of one block.
 *
 *   So the input arrives on the AUX layer's bus, whose mix level is non-zero (a bus
 *   with a mix level of zero is skipped, FX chain and all) but whose LAYER LEVEL in
 *   the rack is zero. The rack takes each layer's reverb send from the captured signal
 *   BEFORE the layer level is applied — see synth_rack_process() — so the microphone
 *   reaches the effects and can never reach the dry output, whatever the send says.
 *
 * WHY IT ADDS RATHER THAN WRITES
 *   Slot 1 of every bus is the pan capture, which is what turns the bus into a stereo
 *   layer; slot 0 is free on the AUX bus. Writing the bus from slot 0 would replace
 *   whatever else ever comes to live there, and the capture would then be capturing
 *   the microphone instead of it. Adding keeps the input a contribution to the bus
 *   rather than the bus' contents.
 *
 * The samples are already filtered and scaled by the application: this file moves the
 * block and applies no gain of its own. See synth_dsp_mic_publish() in synth_dsp.h.
 */

namespace {

const float *s_src   = nullptr;   /* the application's block, borrowed, never freed here */
int         s_count  = 0;

} // namespace

void synth_dsp_mic_publish(const float *samples, int count)
{
    if (samples == nullptr || count <= 0) {
        s_src = nullptr;
        s_count = 0;
        return;
    }
    if (count > SYNTH_BLOCK_SAMPLES) {
        count = SYNTH_BLOCK_SAMPLES;
    }
    s_src = samples;
    s_count = count;
}

const float *synth_mic_block(int *count)
{
    if (count != nullptr) {
        *count = s_count;
    }
    return s_src;
}

void synth_fx_mic_in(int32_t *bus_buffer, int samples, int16_t *ep, int32_t *es)
{
    (void)es;   /* no state of its own: the block lives in the application */

    if (!ep[6]) {
        return;
    }

    int count = 0;
    const float *src = synth_mic_block(&count);
    if (src == nullptr || count <= 0) {
        return;
    }
    if (samples <= 0) {
        return;
    }
    if (samples > SYNTH_BLOCK_SAMPLES) {
        samples = SYNTH_BLOCK_SAMPLES;
    }
    if (count > samples) {
        count = samples;
    }

    for (int i = 0; i < count; i++) {
        /* The bus is int32 scaled to 16-bit full scale, which is the same full scale
         * the application published against, so this is a unit conversion and not a
         * gain: the microphone's own gain is the sensitivity setting, and how much of
         * it reaches the reverb is the send.
         *
         * The application clamps its block at full scale before publishing it (the
         * sensitivity knob's software gain is capped there), so |v| cannot exceed 32768
         * and the guard below cannot double-limit anything the microphone sends: it is
         * the int32 backstop, and it is here because the DSP cannot see how the block was
         * made. */
        float v = src[i] * 32768.0f;
        if (v > 2147483000.0f) {
            v = 2147483000.0f;
        } else if (v < -2147483000.0f) {
            v = -2147483000.0f;
        }
        bus_buffer[i] += (int32_t)v;
    }
}
