# synth_core — vendored ESP32Synth and the port patch

Upstream: [danilogcrf2-oss/ESP32Synth](https://github.com/danilogcrf2-oss/ESP32Synth)
version **2.5.0**, MIT (see `LICENSE`), obtained as a source archive
(`ESP32Synth-main`) rather than a git checkout, so there is no commit hash to
pin.

The `src/` tree is upstream plus the edits below, minus one deletion: the
`src/helix/` MP3 decoder directory (23 files) is **not** part of this checkout.
It is unused (`ENABLE_MP3` is 0 and nothing reaches it) and it is
RPSL/RCSL-licensed, which this MIT release must not carry. Everything else is
byte-identical to the archive.

Keep this list in sync when re-vendoring. Each entry names the upstream file
and what changed, so a diff against a fresh archive should show exactly these
edits plus the deleted `src/helix/` and nothing else.

## Build glue

| File | Change |
|---|---|
| `CMakeLists.txt` | New. Upstream has no build files whatsoever. Compiles `src/ESP32Synth.cpp` only; `src/helix` is not in `SRCS` (the directory itself is gone, see above). |

## Compile breaks on ESP-IDF 6.1

| File | Upstream | Change |
|---|---|---|
| `src/ESP32Synth.h` | `#include "esp_clk.h"` | → `"esp_private/esp_clk.h"`. The public header was removed after IDF 4.4; `esp_clk_cpu_freq()` now lives in the private one. |
| `src/ESP32Synth.h` | driver includes without gpio | Added `#include "driver/gpio.h"`. `beginPWM()` calls `gpio_reset_pin()`, which no longer arrives transitively. |
| `src/ESP32Synth.h` | `#include <string.h>` only | Added `<strings.h>` (`strcasecmp` in `ESP32Synth_SDStream.hpp`) and `<stdlib.h>` (`abs`). |
| `src/ESP32Synth_Begins.hpp` | `i2s_port_t requested_port = ...` | → `int requested_port = ...`. IDF 6.0 deleted the `i2s_port_t` typedef; `I2S_NUM_*` are plain macros now. |
| `src/ESP32Synth_Begins.hpp` | `i2s_pdm_tx_gpio_config_t gpio_cfg` set `.clk` and `.dout` only | Added `.dout2 = I2S_GPIO_UNUSED` (guarded by `SOC_I2S_PDM_MAX_TX_LINES > 1`) and `.invert_flags`. IDF 6.1 added fields, and the project builds with `-Werror=missing-field-initializers`. |
| `src/ESP32Synth_Begins.hpp` | `i2s_std_gpio_config_t gpio_cfg` set `.mclk/.bclk/.ws/.dout` only | Added `.din = I2S_GPIO_UNUSED` and `.invert_flags`. Beyond the warning, this is a latent bug: the omitted `.din` zero-initialises to **GPIO0**, so `begin()` would let the I2S driver claim GPIO0 as a data input. |

## Upstream bugs fixed

These are not IDF 6.1 problems — they break the library for any consumer that
deviates from upstream's default configuration.

| File | Problem | Fix |
|---|---|---|
| `src/ESP32Synth.h` | `StreamTrack::seeking` was declared **inside `#if ENABLE_MP3`**, but `ESP32Synth_Renders.hpp` (skips rendering while a seek is in flight) and `ESP32Synth_SDStream.hpp` (sets it) use it unconditionally. With `ENABLE_MP3 == 0` the library does not compile at all. | Declared unconditionally, above the `#if`. |
| `src/ESP32SynthNotes.h` | Defined ~140 two- and three-letter macros (`c0`…`g10`, `c1`, `g8`, …) unconditionally. **LVGL's `lv_color.h` has parameters literally named `c1` and `g8`**, so any translation unit that includes both headers fails to compile — including ours, via `bsp.h`. | The note macros are now behind `SYNTH_ENABLE_NOTE_MACROS`. Nothing in the engine uses them (it works in centiHertz), so we never define it. `midiToFreq()` stays unconditional. |

## Our additions

Not upstream fixes: behaviour this instrument needs and the library has no
equivalent for. Everything below is off unless the application asks for it.

### Wave morph — a shape change that is a crossfade instead of a step

| File | Change |
|---|---|
| `src/ESP32Synth.h` | `Voice` gained `morphFromFunc`, `morphFromType`, `nextWaveFunc`, `pendingWaveFunc`, `pendingValid`, `morphAcc`, `morphInc` and `morphDelay`; `morph`, `nextWaveType` and `pendingWaveType` were already in the struct, unused, with this feature, and are now the rest of the same state. `currWaveType`, `currWaveIsBasic` and `nextWaveIsBasic` are the Tracker instrument's own shape state, read by the other branch of `render()`, and the morph never writes them. New public `setWaveSmooth()`; new private `renderVoiceMorph()`, `renderShapeInto()` and the two `morphScratchA/B[SYNTH_MORPH_BLOCK_MAX]` buffers. |
| `src/ESP32Synth_Core.hpp` | `setWaveSmooth()` implemented, plus the file-static `wave_shape_can_morph()`, `wave_shape_same()` and `wave_morph_reset()`. `setWave()` and `setCustomWave()` call `wave_morph_reset()`, which ends a fade in flight; so does `setInstrument()`, which renders through the other branch and would otherwise leave a fade neither rendered nor finished. |
| `src/ESP32Synth.cpp` | `renderShapeInto()` (one shape, rendered into a buffer) and `ESP32Synth::renderVoiceMorph()` (both shapes, weighted) ahead of `render()`; `render()`'s per-voice dispatch gained a single `if (vo->morphAcc != 0)` in front of the existing switch. |
| `src/ESP32Synth_Config.hpp` | New `SYNTH_MORPH_BLOCK_MAX` (256), `#ifndef`-guarded like the rest. It sizes the two scratch buffers: 2 KB of `.bss`. |

**What it costs.** Measured by compiling the header and `synth_app.cpp` with the
project's own command lines, before against after: `Voice` 248 -> 280 bytes
(+768 bytes over 24 voices), the two scratch buffers 2048 bytes, so 2816 bytes of
`.bss` in all; and 3090 bytes of flash (`renderShapeInto`) plus 1148 bytes of IRAM
(`renderVoiceMorph`) plus 588 bytes of flash (`setWaveSmooth`). After a block, only
a morphing voice costs anything: one extra render, about 2.5 % of the block budget,
and the application staggers the drone's nine voices 20 ms apart so that at most
one of them is doubled in any block. The generator is deliberately kept out of
IRAM — the same reasoning as the compiler note at the top of
`ESP32Synth_Patches.hpp` — which is also why it must be one body and not two.

**Why.** The application's WAVE control is a *list* — six shapes, one detent
each — and every list on this instrument arrives in one step, deliberately (see
`synth_app.cpp`). On a sounding drone that step is a step in the waveform, which
is a click; the fix cannot be a slide on the parameter, because the parameter is
a list and is also stored in presets and drawn at random. So the smoothing lives
in the voice: `setWaveSmooth(voice, type, cb, morphMs, startDelayMs)` renders the
voice through the old shape AND the new one for the same span from the same phase
and crossfades them over `morphMs`, one weight per sample.

**What is instant, still.** `setWave()` and `setCustomWave()` are untouched in
behaviour and remain what a tracker instrument, a sample and a sequencer stage
use; so do wavetables, samples and streams, which carry a position of their own
and cannot be rendered twice (`wave_shape_can_morph()` refuses them), and so does
any `morphMs == 0` request. A block larger than `SYNTH_MORPH_BLOCK_MAX` switches
instantly and silently rather than writing past the scratch.

**A knob turned faster than the fade.** One fade is in flight and one requested
shape waits behind it (`pendingWave*`); a second request replaces the first. The
running fade is never cut short, because a fade is a blend and jumping to its
target early steps the waveform by whatever part of the blend was still to run —
the click the feature exists to remove. A burst of detents therefore coalesces
into one waiting shape, the voice runs one fade at a time, and the state is the
same size whatever the knob does. The cost is that the sound is at most one
`morphMs` behind the knob while a fade is running.

**Default behaviour is unchanged.** `morphAcc == 0` means "settled, this voice IS
the shape it says it is", and zero is what a zeroed `Voice` already holds — the
constructor's `voices[i] = {}` leaves every new field off. A voice that never
calls `setWaveSmooth()` renders through exactly the switch it always did, and the
whole cost of the feature when nothing is morphing is one comparison per voice
per block. The instant setters also *end* a fade, and since the voice's live type
is set to the target the moment a fade starts, what is dropped is the crossfade
and never the shape.

## Known but not fixed

- **`src/ESP32Synth_Patches.hpp` has strict-aliasing UB.** `DSP_BiquadOsc`
  stores oscillator state in `Voice::cw[]` and accesses it by casting that array
  to `int64_t*` (`lines ~444, ~525`). GCC flags it under `-Werror`, so the one
  translation unit that includes the header — `synth_app.cpp` — wraps the
  include in `#pragma GCC diagnostic ignored "-Wstrict-aliasing"`.

  We include the header only for `AA_Saw`/`AA_Pulse` and never call
  `DSP_BiquadOsc`, so nothing is miscompiled today. **If a later phase wants
  that patch, fix the type-punning first** (`memcpy` into and out of the
  `int64_t`) instead of relying on the pragma.

- **The LEDC/PWM path is left as upstream**, including `ledc_ovf_isr` being
  `IRAM_ATTR` while calling FreeRTOS semaphore APIs. On IDF 6.0 that needs
  `CONFIG_FREERTOS_IN_IRAM` to be safe *at runtime*, but the ISR is only
  registered by `beginPWM()`, which this project never calls. If the linker
  ever objects, dropping `IRAM_ATTR` from that function is the fix.

## Configuration overrides

| File | Change |
|---|---|
| `src/ESP32Synth_Config.hpp` | `MAX_VOICES`, `MAX_WAVETABLES`, `MAX_SAMPLES`, `MAX_ARP_NOTES`, `MAX_STREAMS`, `STREAM_BUF_SAMPLES` were unconditional `#define`s, so passing `-DMAX_VOICES=24` was a redefinition error. They are now `#ifndef`-guarded and set to this project's values (`MAX_VOICES 24`, `MAX_WAVETABLES 8`, `MAX_SAMPLES 4`, `MAX_ARP_NOTES 4`, `MAX_STREAMS 1`, `STREAM_BUF_SAMPLES 512`). |
| `src/ESP32Synth_Config.hpp` | `ENABLE_MP3` default `1` → `0`. There is no MP3 playback in this instrument, and the decoder directory has been removed from the tree (see above). |
| `src/ESP32Synth_Config.hpp` | `MAX_BUSES` **4 → 6**. Bus 0 is the master and never runs FX, so the five instrument layers need buses 1..5. `setVoiceBus()`/`setBusFX()` reject out-of-range ids *silently*, so with 4 a layer's voices would render into bus 0 — the one output this firmware discards — and be inaudible with no error anywhere. `synth_app.cpp` now has a `static_assert` on this. |

Values are hardcoded in the header rather than passed as `-D` on purpose: the
`ESP32Synth` object contains `Voice voices[MAX_VOICES]` as a member array, so
any translation unit that includes `ESP32Synth.h` with different values would
disagree about the class layout. One header, one set of numbers.

Trimming these took the engine object from about 66 KB to about 9.5 KB — which
matters, because this board has ~143 KB of internal RAM free before the
instrument is even running.

## How we use it

- **Pull mode** (`beginCustom(48000, nullptr)`): no engine task is created and
  nothing is heap-allocated; our own audio task drives `generateSamples()`.
- **One bus per layer**, because bus 0 is the engine master and never runs FX
  (the mixdown loop starts at bus 1). Stereo is created entirely outside the
  engine — see `components/synth_dsp`.
- **Everything is configured before the audio task starts.** The engine has no
  locking of any kind: no critical sections, no atomics, not even `volatile` on
  the voice array, and `setBusFX()` `memset`s parameter arrays the render loop
  reads. Concurrent setters are a data race by construction.
