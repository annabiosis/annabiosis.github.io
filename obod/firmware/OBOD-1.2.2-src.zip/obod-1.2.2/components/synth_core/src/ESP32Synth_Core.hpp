#pragma once
#include "ESP32Synth.h"

void ESP32Synth::noteOn(uint16_t voice, uint32_t freqCentiHz, uint16_t volume) {
    if (voice >= MAX_VOICES) return;
    Voice* vo = &voices[voice];

    vo->freqVal = freqCentiHz;
    uint32_t vCalc = (uint32_t)volume << _volShift;
    vo->vol = (vCalc > 65535) ? 65535 : (uint16_t)vCalc;
    vo->active  = true;

    // MEGA SAFE: Clean previous note state (prevents ADSR locks and glide leakage)
    vo->sampleFinished  = false;
    vo->slideFreqActive = false;
    vo->slideVolActive  = false;
    if (!vo->smoothEnv) vo->currEnvVal = 0; // Force immediate envelope reset if not smoothing!

    // Calculate phase increment
    vo->phaseInc = (uint32_t)(((uint64_t)freqCentiHz << 32) / (_sampleRate * 100));

    // Force an immediate control update to snap parameters instantly
    controlSampleCounter = controlIntervalSamples;

    if (vo->inst) { // Tracker Instrument
        vo->envState    = ENV_ATTACK;
        vo->currEnvVal  = ENV_MAX;
        vo->stageIdx    = 0;
        vo->controlTick = 0;
        vo->phase       = (uint32_t)vo->startPhase * 11930465UL;
    } else if (vo->instSample) { // Sample-based Instrument
        vo->type            = WAVE_SAMPLE;
        vo->sampleFinished  = false;
        vo->sampleLoopMode  = vo->instSample->loopMode;
        vo->sampleLoopStart = vo->instSample->loopStart;
        vo->sampleDirection = (vo->sampleLoopMode != LOOP_REVERSE);

        const SampleData* sData = nullptr;
        uint32_t root = 0;
        // Find sample zone
        for (int i = 0; i < vo->instSample->numZones; i++) {
            const SampleZone* z = &vo->instSample->zones[i];
            if (freqCentiHz >= z->lowFreq && freqCentiHz <= z->highFreq) {
                if (z->sampleId < MAX_SAMPLES) {
                    sData         = &registeredSamples[z->sampleId];
                    vo->curSampleId = z->sampleId;
                    root = (z->rootOverride > 0) ? z->rootOverride : sData->rootFreqCentiHz;
                }
                break;
            }
        }

        if (sData) {
            vo->sampleLoopEnd = (vo->instSample->loopEnd == 0 || vo->instSample->loopEnd > sData->length)
                                ? sData->length
                                : vo->instSample->loopEnd;
            uint32_t startOffset = (sData->length * vo->startPhase) / 360;
            if (startOffset >= sData->length && sData->length > 0) startOffset = sData->length - 1;
            vo->samplePos1616    = vo->sampleDirection
                                   ? ((uint64_t)startOffset << 16)
                                   : ((uint64_t)(sData->length - 1 - startOffset) << 16);
        } else {
            vo->samplePos1616 = 0;
        }

        // Calculate playback increment
        if (sData && sData->data && root > 0) {
            uint64_t ratio1616   = ((uint64_t)freqCentiHz << 16) / root;
            vo->sampleInc1616    = (uint32_t)((ratio1616 * sData->sampleRate) / _sampleRate);
        } else {
            vo->sampleInc1616 = 0;
        }

    } else { // Standard voice types
        if (vo->type == WAVE_NOISE) {
            vo->rngState += SYNTH_MICROS(); // Re-seed — highly compatible
        } else if (vo->type == WAVE_CUSTOM) {
            if (!vo->smoothEnv) {
                vo->phase = (uint32_t)vo->startPhase * 11930465UL;
                memset(vo->cw, 0, sizeof(vo->cw)); // O(1) memory clear at -O3
            }
        } else if (vo->type == WAVE_SAMPLE) {
            vo->sampleFinished  = false;
            const SampleData* sData = &registeredSamples[vo->curSampleId];
            vo->sampleDirection = (vo->sampleLoopMode != LOOP_REVERSE);

            if (sData->data && sData->length > 0) {
                uint32_t startOffset = (sData->length * vo->startPhase) / 360;
                if (startOffset >= sData->length && sData->length > 0) startOffset = sData->length - 1;
                vo->samplePos1616    = vo->sampleDirection
                                       ? ((uint64_t)startOffset << 16)
                                       : ((uint64_t)(sData->length - 1 - startOffset) << 16);
                if (sData->rootFreqCentiHz > 0) {
                    uint64_t ratio1616 = ((uint64_t)freqCentiHz << 16) / sData->rootFreqCentiHz;
                    vo->sampleInc1616  = (uint32_t)((ratio1616 * sData->sampleRate) / _sampleRate);
                } else {
                    vo->sampleInc1616 = 0;
                }
            } else {
                vo->samplePos1616 = 0;
                vo->sampleInc1616 = 0;
            }
        } else if (vo->type == WAVE_STREAM && vo->streamTrackId >= 0) {
            StreamTrack* trk    = &this->streams[vo->streamTrackId];
            trk->seekTarget     = 0; // Seek to beginning
            trk->playing        = true;
            vo->streamFracAccum = 0;

            if (trk->rootFreqCentiHz > 0) {
                uint64_t ratio1616 = ((uint64_t)freqCentiHz << 16) / trk->rootFreqCentiHz;
                vo->sampleInc1616  = (uint32_t)((ratio1616 * trk->sampleRate) / _sampleRate);
            } else {
                vo->sampleInc1616 = (uint32_t)(((uint64_t)trk->sampleRate << 16) / _sampleRate);
            }
        } else { // Basic waveforms
            if (!vo->smoothEnv) vo->phase = (uint32_t)vo->startPhase * 11930465UL;
        }

        if (vo->arpActive) {
            vo->arpIdx         = 0;
            vo->arpTickCounter = 0;
        }
    }

    // Trigger ADSR universal
    if (!vo->inst) {
        if (vo->rateAttack >= ENV_MAX) { // Zero attack time
            vo->currEnvVal = ENV_MAX;
            vo->envState   = ENV_DECAY;
        } else {
            if (!vo->smoothEnv) vo->currEnvVal = 0; // Evita o drop se smoothEnv estiver ligado
            vo->envState   = ENV_ATTACK;
        }
    }
}

void ESP32Synth::noteOff(uint16_t voice) {
    if (voice < MAX_VOICES && voices[voice].active) {
        voices[voice].envState   = ENV_RELEASE;
        voices[voice].stageIdx   = 0; // Reset instrument stage index
        voices[voice].controlTick = 0;
    }
}

void ESP32Synth::setFrequency(uint16_t voice, uint32_t freqCentiHz) {
    if (voice >= MAX_VOICES) return;
    Voice* v = &voices[voice];
    v->freqVal = freqCentiHz;

    // Recalculate increment
    if (v->type == WAVE_SAMPLE) {
        if (v->instSample != nullptr) { // Treat as a multi-zone sample instrument
            const SampleData* sData = nullptr;
            uint32_t root = 0;
            for (int i = 0; i < v->instSample->numZones; i++) {
                const SampleZone* z = &v->instSample->zones[i];
                if (freqCentiHz >= z->lowFreq && freqCentiHz <= z->highFreq) {
                    if (z->sampleId < MAX_SAMPLES) {
                        sData = &registeredSamples[z->sampleId];
                        root = (z->rootOverride > 0) ? z->rootOverride : sData->rootFreqCentiHz;
                    }
                    break;
                }
            }
            if (sData && sData->data && root > 0) {
                uint64_t ratio1616 = ((uint64_t)freqCentiHz << 16) / root;
                v->sampleInc1616   = (uint32_t)((ratio1616 * sData->sampleRate) / _sampleRate);
            }
        } else { // Simple Sample Mode
            const SampleData* sData = &registeredSamples[v->curSampleId];
            if (sData->data && sData->rootFreqCentiHz > 0) {
                uint64_t ratio1616 = ((uint64_t)freqCentiHz << 16) / sData->rootFreqCentiHz;
                v->sampleInc1616   = (uint32_t)((ratio1616 * sData->sampleRate) / _sampleRate);
            }
        }
    } else if (v->type == WAVE_STREAM && v->streamTrackId >= 0) {
        StreamTrack* trk = &streams[v->streamTrackId];
        if (trk->rootFreqCentiHz > 0) {
            uint64_t ratio1616 = ((uint64_t)freqCentiHz << 16) / trk->rootFreqCentiHz;
            v->sampleInc1616   = (uint32_t)((ratio1616 * trk->sampleRate) / _sampleRate);
        } else {
            v->sampleInc1616   = (uint32_t)(((uint64_t)trk->sampleRate << 16) / _sampleRate);
        }
    } else {
        v->phaseInc = (uint32_t)(((uint64_t)freqCentiHz * 4294967296ULL) / (_sampleRate * 100ULL));
    }
}

void ESP32Synth::setVolume(uint16_t voice, uint16_t volume) {
    if (voice < MAX_VOICES) {
        uint32_t vCalc = (uint32_t)volume << _volShift;
        voices[voice].vol = (vCalc > 65535) ? 65535 : (uint16_t)vCalc;
    }
}

/*
 * Can this shape be rendered TWICE for the same span of time? That is the whole
 * requirement a morph has of a shape, and it is not true of all of them: a wavetable, a
 * sample and a stream all carry a POSITION that the first render has already advanced, so
 * rendering one of those a second time would replay a different part of the data, and a
 * crossfade between the two would be a crossfade between two moments rather than between
 * two shapes. Those three switch instantly, exactly as they do today, and so does anything
 * else this engine does not recognise.
 */
static inline bool wave_shape_can_morph(WaveType type, SynthCustomWaveCallback cb) {
    if (type == WAVE_CUSTOM) return cb != nullptr;
    return type == WAVE_SINE || type == WAVE_TRIANGLE || type == WAVE_SAW ||
           type == WAVE_PULSE || type == WAVE_NOISE;
}

/*
 * Are these two the same shape, as the render path would tell them apart? A callback only
 * counts when the type is WAVE_CUSTOM, which is what setCustomWave() forces and what the
 * dispatch in render() switches on.
 */
static inline bool wave_shape_same(WaveType ta, SynthCustomWaveCallback ca,
                                   WaveType tb, SynthCustomWaveCallback cb) {
    if (ta != tb) return false;
    if (ta == WAVE_CUSTOM) return ca == cb;
    return true;
}

/* An instant switch ends everything a fade was doing: the blend, the wait and the request
 * waiting behind it. The type has already been written by the caller. */
static inline void wave_morph_reset(Voice* vo) {
    vo->morphAcc     = 0;
    vo->morphDelay   = 0;
    vo->morph        = 0;
    vo->pendingValid = 0;
}

void ESP32Synth::setWave(uint16_t voice, WaveType type) {
    if (voice < MAX_VOICES) {
        voices[voice].type = type;
        /* An instant switch ENDS any fade that was in flight. The voice already carries
         * this type — it is the target the fade was walking towards — so what is dropped
         * here is the crossfade and not the shape. See setWaveSmooth(). */
        wave_morph_reset(&voices[voice]);
    }
}

void ESP32Synth::setPulseWidthBitDepth(uint8_t bits) {
    if (bits < 1)  bits = 1;
    if (bits > 32) bits = 32;
    _pwShift = 32 - bits; // Automatically calculates the shift needed
}

void ESP32Synth::setPulseWidth(uint16_t voice, uint32_t width) {
    if (voice < MAX_VOICES) {
        uint64_t wCalc = (uint64_t)width << _pwShift;
        voices[voice].pulseWidth = (wCalc > 0xFFFFFFFFULL) ? 0xFFFFFFFFUL : (uint32_t)wCalc;
    }
}

void ESP32Synth::setCustomWave(uint16_t voice, SynthCustomWaveCallback cb) {
    if (voice < MAX_VOICES) {
        voices[voice].customWaveFunc = cb;
        voices[voice].type = WAVE_CUSTOM; // Automatically forces the wave type!
        wave_morph_reset(&voices[voice]); // and ends any fade, as setWave() does
    }
}

/*
 * The smooth version of the two setters above.
 *
 * WHY IT IS NOT A SLIDE ON THE PARAMETER
 *   The WAVE control is a list, and every list on this instrument reaches its destination
 *   in one step by design — see synth_app.cpp. Where the smoothing belongs is therefore
 *   here, inside the voice, as a property of how a shape is CHANGED rather than of how a
 *   number is stored: the shape fades into the next one over a fixed time, whatever the
 *   knob did to get there, and a preset load, a random draw and a hand on the encoder all
 *   get the same answer without knowing about it.
 *
 * HOW THE FADE IS CARRIED
 *   Both shapes are rendered for the same span, from the same phase, with the same
 *   envelope, and the two are mixed by a weight that walks from one to the other — see
 *   renderVoiceMorph(). The voice's own type is set to the TARGET immediately, so the
 *   shape in force, the shape a later request is compared against and the shape the next
 *   block renders are the target from the moment this returns; only the sound lags, and
 *   only for the length of the fade.
 *
 * ONE FADE IN FLIGHT, ONE REQUEST WAITING
 *   A request that arrives while a fade is still running does not shorten it. It is worth
 *   being exact about why, because the obvious alternative is wrong: a fade is a blend of
 *   two shapes, so jumping to its target early steps the waveform by exactly the part of the
 *   blend that was still to run — with a 25 ms fade and a detent every 10 ms that is more
 *   than half the shape difference, a full-scale step, the very click this exists to remove.
 *   Instead the request waits in ONE slot (pendingWave*), replacing whatever was waiting
 *   there, and when the running fade arrives the next one starts from the shape it arrived
 *   at. A knob turned faster than the fade therefore coalesces: the voice runs one fade at a
 *   time and carries one waiting shape, whatever the knob did, and there is no queue to grow.
 *   The price is latency — the sound is at most one fade time behind the knob — and it is
 *   paid only while a fade is running.
 */
void ESP32Synth::setWaveSmooth(uint16_t voice, WaveType type, SynthCustomWaveCallback cb,
                               uint16_t morphMs, uint16_t startDelayMs) {
    if (voice >= MAX_VOICES) return;
    Voice* vo = &voices[voice];

    const bool want_custom = (type == WAVE_CUSTOM);
    SynthCustomWaveCallback from_cb = vo->customWaveFunc;
    const WaveType from_type = vo->type;

    /* The shape in force was asked for: nothing to fade. Note that "in force" during a fade
     * means the shape the fade is heading FOR — the audible blend is between the two ends, and
     * the request says where it should end up. Whatever was waiting behind it is dropped. */
    if (wave_shape_same(type, want_custom ? cb : nullptr, from_type, from_cb)) {
        vo->pendingValid = 0;
        return;
    }

    /* Instruments render their shape through another branch of render(), and the three
     * shapes with a position of their own cannot be rendered twice. Both go the instant
     * way, which is what they did before this existed. */
    const bool smooth = (morphMs > 0) && (vo->inst == nullptr) &&
                        wave_shape_can_morph(type, cb) &&
                        wave_shape_can_morph(from_type, from_cb);

    if (!smooth) {
        if (want_custom) setCustomWave(voice, cb);
        else             setWave(voice, type);
        return;
    }

    if (vo->morphAcc != 0) {
        /* A fade is running: this becomes the shape waiting behind it. One slot, latest wins,
         * and the running fade is left exactly as it is — cutting it short is the step
         * described above. renderVoiceMorph() starts the next fade when this one lands. */
        vo->pendingWaveType = type;
        vo->pendingWaveFunc = want_custom ? cb : nullptr;
        vo->pendingValid    = 1;
        return;
    }

    vo->morphFromType = from_type;
    vo->morphFromFunc = from_cb;
    vo->nextWaveType  = type;
    vo->nextWaveFunc  = want_custom ? cb : nullptr;

    vo->type = type;                        /* in force at once, audible in morphMs */
    if (want_custom) vo->customWaveFunc = cb;

    const uint32_t sr = (_sampleRate > 0) ? _sampleRate : 48000;
    /* A stagger is a wait before the fade starts. Clamped to what the field holds: 65535
     * samples is 1.36 s at 48 kHz, and nothing in the app asks for a tenth of that. */
    const uint32_t delay = ((uint32_t)startDelayMs * sr) / 1000u;
    vo->morphDelay = (uint16_t)(delay > 65535u ? 65535u : delay);

    const uint32_t span = ((uint32_t)morphMs * sr) / 1000u;
    /* MORPH_FULL is 255 in the Q16 the accumulator holds: the ramp is 0..255 << 16. */
    uint32_t inc = ((uint32_t)255 << 16) / (span ? span : 1u);
    if (inc == 0) inc = 1;

    vo->morphInc = inc;
    vo->morphAcc = 1;                       /* non-zero from the first sample: it IS the flag */
    vo->morph    = 0;
    vo->pendingValid = 0;                   /* this fade has nothing waiting behind it yet */
}

// --- Envelope (ADSR) ---
void ESP32Synth::setEnv(uint16_t voice, uint16_t a, uint16_t d, uint8_t s, uint16_t r) {
    if (voice >= MAX_VOICES) return;
    Voice* v = &voices[voice];
    v->levelSustain = (uint32_t)s * (ENV_MAX / 255);

    // Safety guard against division by zero (minimum spm of 1)
    uint32_t spm = (_sampleRate >= 1000) ? (_sampleRate / 1000) : 1;

    v->rateAttack  = (a == 0) ? ENV_MAX : ENV_MAX / ((uint32_t)a * spm);
    v->rateDecay   = (d == 0) ? ENV_MAX : (ENV_MAX - v->levelSustain) / ((uint32_t)d * spm);
    v->rateRelease = (r == 0) ? ENV_MAX : ENV_MAX / ((uint32_t)r * spm);
}

void ESP32Synth::setSmoothEnv(uint16_t voice, bool enable) {
    if (voice < MAX_VOICES) {
        voices[voice].smoothEnv = enable;
    }
}

// --- Phase Control ---
void ESP32Synth::setStartPhase(uint16_t voice, uint16_t phaseDegrees) {
    if (voice < MAX_VOICES) {
        voices[voice].startPhase = phaseDegrees % 360;
    }
}

void ESP32Synth::setCurrentPhase(uint16_t voice, uint16_t phaseDegrees) {
    if (voice >= MAX_VOICES) return;
    Voice* vo   = &voices[voice];
    uint32_t deg = phaseDegrees % 360;

    if (vo->type == WAVE_SAMPLE) {
        const SampleData* sData = &registeredSamples[vo->curSampleId];
        if (sData && sData->length > 0) {
            uint32_t offset     = (sData->length * deg) / 360;
            vo->samplePos1616   = (uint64_t)offset << 16;
        }
    } else if (vo->type != WAVE_NOISE) {
        vo->phase = (uint32_t)deg * 11930465UL; // 11930465 ~= (2^32)/360
    }
}

// --- Modulation & Slides ---

void ESP32Synth::setVibrato(uint16_t voice, uint32_t rateCentiHz, uint32_t depthCentiHz) {
    if (voice >= MAX_VOICES) return;
    // Precise calculation that fully adapts to the current sample rate!
    voices[voice].vibRateInc  = (uint32_t)(((uint64_t)rateCentiHz  * 4294967296ULL) / ((uint64_t)_sampleRate * 100ULL));
    voices[voice].vibDepthInc = (uint32_t)(((uint64_t)depthCentiHz * 4294967296ULL) / ((uint64_t)_sampleRate * 100ULL));
}

void ESP32Synth::setVibratoPhase(uint16_t voice, uint16_t phaseDegrees) {
    if (voice < MAX_VOICES) {
        voices[voice].vibPhase = (uint32_t)(phaseDegrees % 360) * 11930465UL;
    }
}

void ESP32Synth::setTremolo(uint16_t voice, uint32_t rateCentiHz, uint16_t depth) {
    if (voice >= MAX_VOICES) return;
    voices[voice].trmRateInc = (uint32_t)(((uint64_t)rateCentiHz * 4294967296ULL) / ((uint64_t)_sampleRate * 100ULL));
    voices[voice].trmDepth   = depth;
}

void ESP32Synth::setTremoloPhase(uint16_t voice, uint16_t phaseDegrees) {
    if (voice < MAX_VOICES) {
        voices[voice].trmPhase = (uint32_t)(phaseDegrees % 360) * 11930465UL;
    }
}

void ESP32Synth::slideFreq(uint16_t voice, uint32_t startFreqCentiHz, uint32_t endFreqCentiHz, uint32_t durationMs) {
    if (voice >= MAX_VOICES) return;
    Voice* v = &voices[voice];
    uint32_t ticks = (durationMs == 0) ? 0 : ((durationMs * controlRateHz + 999) / 1000);

    uint32_t endInc = (uint32_t)(((uint64_t)endFreqCentiHz << 32) / (_sampleRate * 100));

    if (ticks == 0) {
        v->phaseInc          = endInc;
        v->freqVal           = endFreqCentiHz;
        v->slideFreqActive   = false;
        return;
    }

    uint32_t startInc = (uint32_t)(((uint64_t)startFreqCentiHz << 32) / (_sampleRate * 100));
    // Bresenham's algorithm for integer slides
    int64_t  diff  = (int64_t)endInc - (int64_t)startInc;
    int32_t  delta = (int32_t)(diff / (int64_t)ticks);
    int64_t  rem   = diff - (int64_t)delta * (int64_t)ticks;

    v->phaseInc                = startInc;
    v->slideFreqDeltaInc       = delta;
    v->slideFreqRem            = (int32_t)rem;
    v->slideFreqRemAcc         = 0;
    v->slideFreqTicksTotal     = ticks;
    v->slideFreqTicksRemaining = ticks;
    v->slideFreqTargetInc      = endInc;
    v->slideFreqTargetCenti    = endFreqCentiHz;
    v->slideFreqActive         = true;
    v->freqVal                 = startFreqCentiHz;
}

void ESP32Synth::slideFreqTo(uint16_t voice, uint32_t endFreqCentiHz, uint32_t durationMs) {
    if (voice >= MAX_VOICES) return;
    uint32_t start = voices[voice].freqVal;
    if (start == 0) { // If current frequency is 0, calculate from phaseInc
        start = (voices[voice].phaseInc != 0)
                ? (uint32_t)(((uint64_t)voices[voice].phaseInc * _sampleRate * 100) >> 32)
                : endFreqCentiHz;
    }
    slideFreq(voice, start, endFreqCentiHz, durationMs);
}

void ESP32Synth::slideVolAbsolute(uint16_t voice, uint16_t startVol16, uint16_t endVol16, uint32_t durationMs) {
    if (voice >= MAX_VOICES) return;
    Voice* v = &voices[voice];
    uint32_t ticks = (durationMs == 0) ? 0 : ((durationMs * controlRateHz + 999) / 1000);

    if (ticks == 0) {
        v->vol             = endVol16;
        v->slideVolActive  = false;
        return;
    }

    v->vol           = startVol16;
    v->slideVolCurr  = (int64_t)startVol16 << 16; // 16 bits of fractional precision!
    v->slideVolTarget = endVol16;

    int64_t diff     = ((int64_t)endVol16 << 16) - v->slideVolCurr;
    v->slideVolInc   = diff / (int64_t)ticks;

    v->slideVolTicksRemaining = ticks;
    v->slideVolActive         = true;
}

void ESP32Synth::slideVol(uint16_t voice, uint16_t startVol, uint16_t endVol, uint32_t durationMs) {
    // Converts the user-facing resolution and passes it to the absolute internal engine
    slideVolAbsolute(voice, startVol << _volShift, endVol << _volShift, durationMs);
}

void ESP32Synth::slideVolTo(uint16_t voice, uint16_t endVol, uint32_t durationMs) {
    if (voice >= MAX_VOICES) return;
    slideVolAbsolute(voice, voices[voice].vol, endVol << _volShift, durationMs);
}

// --- Wavetable & Instruments ---

void ESP32Synth::setWavetable(uint16_t voice, const void* data, uint32_t size, BitDepth depth) {
    if (voice < MAX_VOICES) {
        voices[voice].wtData = data;
        voices[voice].wtSize = size;
        voices[voice].depth  = depth;
    }
}

void ESP32Synth::registerWavetable(uint16_t id, const void* data, uint32_t size, BitDepth depth) {
    if (id < MAX_WAVETABLES) {
        wavetables[id].data  = data;
        wavetables[id].size  = size;
        wavetables[id].depth = depth;
    }
}

void ESP32Synth::setInstrument(uint16_t voice, Instrument* inst) {
    if (voice >= MAX_VOICES) return;
    voices[voice].inst       = inst;
    voices[voice].instSample = nullptr;
    voices[voice].stageIdx   = 0;
    voices[voice].controlTick = 0;
    voices[voice].currEnvVal = (inst == nullptr) ? 0 : ENV_MAX;
    voices[voice].envState   = (inst == nullptr) ? ENV_IDLE : ENV_ATTACK;
    voices[voice].smoothEnv  = (inst != nullptr); // Auto-enable smooth envelope for Tracker Instruments
    /* An instrument renders its shape through the other branch of render(), which does not
     * know about a morph — so a fade left in flight here would be neither rendered nor
     * finished, and would come back to life if the voice were later detached. It ends now. */
    wave_morph_reset(&voices[voice]);
}

void ESP32Synth::setInstrument(uint16_t voice, Instrument_Sample* inst) {
    if (voice >= MAX_VOICES) return;
    voices[voice].instSample = inst;
    voices[voice].inst       = nullptr;
    voices[voice].currEnvVal = 0;
    voices[voice].envState   = ENV_IDLE;
}

void ESP32Synth::detachInstrument(uint16_t voice, WaveType newWaveType) {
    if (voice >= MAX_VOICES) return;
    setInstrument(voice, (Instrument*)nullptr);
    setWave(voice, newWaveType);
}

// --- Sample Control ---

bool ESP32Synth::registerSample(uint16_t sampleId, const void* data, uint32_t length, uint32_t sampleRate, uint32_t rootFreqCentiHz, BitDepth depth) {
    if (sampleId >= MAX_SAMPLES || data == nullptr) return false;

    registeredSamples[sampleId].data             = data;
    registeredSamples[sampleId].length           = length;
    registeredSamples[sampleId].sampleRate       = sampleRate;
    registeredSamples[sampleId].rootFreqCentiHz  = rootFreqCentiHz;
    registeredSamples[sampleId].depth            = depth;
    return true;
}

void ESP32Synth::setSample(uint16_t voice, uint16_t sampleId, LoopMode loopMode, uint32_t loopStart, uint32_t loopEnd) {
    if (voice >= MAX_VOICES || sampleId >= MAX_SAMPLES) return;
    Voice* v = &voices[voice];
    v->type            = WAVE_SAMPLE;
    v->curSampleId     = sampleId;
    v->sampleLoopMode  = loopMode;
    v->sampleLoopStart = loopStart;
    v->sampleLoopEnd   = loopEnd;
    v->instSample      = nullptr; // Detach sample instrument if any
}

void ESP32Synth::setSampleLoop(uint16_t voice, LoopMode loopMode, uint32_t loopStart, uint32_t loopEnd) {
    if (voice < MAX_VOICES) {
        Voice* v           = &voices[voice];
        v->sampleLoopMode  = loopMode;
        v->sampleLoopStart = loopStart;
        v->sampleLoopEnd   = loopEnd;
    }
}

// --- Arpeggiator ---

void ESP32Synth::detachArpeggio(uint16_t voice) {
    if (voice < MAX_VOICES) voices[voice].arpActive = false;
}

// --- Custom Parameters ---

void ESP32Synth::setCustomParam(uint16_t voice, uint8_t paramId, int16_t value) {
    if (voice < MAX_VOICES && paramId < SYNTH_CUSTOM_PARAMS_PER_VOICE) {
        voices[voice].cp[paramId] = value;
    }
}

void ESP32Synth::setDSPParam(uint8_t paramId, int16_t value) {
    if (paramId < SYNTH_CUSTOM_PARAMS_GLOBAL) {
        this->dp[paramId] = value;
    }
}