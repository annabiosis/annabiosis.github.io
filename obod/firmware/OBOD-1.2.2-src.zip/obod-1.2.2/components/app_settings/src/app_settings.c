#include "app_settings.h"

#include <math.h>
#include <stddef.h>
#include <string.h>

#include "esp_log.h"
#include "esp_timer.h"
#include "nvs.h"
#include "nvs_flash.h"
#include "sdkconfig.h"

#include "bsp/bsp_display.h"
#include "bsp/bsp_led.h"

static const char *TAG = "settings";

#define NVS_NAMESPACE   "sys"
#define PATCH_KEY       "params"
#define PATCH_MIG_KEY   "patch_mig"
/* The clock's own key: see app_settings_tempo_note() for why it is not in the patch. */
#define TEMPO_KEY       "tempo"
#define PARAM_MIG_KEY   "param_mig"
#define SCALE_MIG_KEY   "scale_mig"
#define VERB_MIG_KEY    "verb_mig"

/*
 * Long enough that a knob being turned never reaches the flash, short enough
 * that letting go and pulling the power does not lose the setting. Two seconds
 * is longer than the pause between two deliberate movements and shorter than the
 * time it takes to reach for the switch.
 */
#define WRITE_DELAY_US  (2 * 1000 * 1000)

/*
 * The settings, one row each.
 *
 * A table rather than a function per setting: every one of them is read, clamped,
 * applied and stored in exactly the same way, and a function per setting would be as
 * many places to forget to handle one of them.
 *
 * `fallback` is what the hardware already is when nothing has ever been stored —
 * not zero. The backlight is set by the BSP at boot and the ring starts
 * unattenuated, so a device that has never been configured still reports the truth.
 */
typedef struct {
    const char *key;
    int         min;
    int         max;
    int         fallback;
} setting_desc_t;

static const setting_desc_t SETTINGS[APP_SET_COUNT] = {
    [APP_SET_SCREEN]    = { "scr_pct",   0, 100, CONFIG_BSP_LCD_BRIGHTNESS_DEFAULT },
    [APP_SET_RING]      = { "ring_pct",  0, 100, 100 },
    [APP_SET_RING_MODE] = { "ring_mode", 0, APP_RING_MODE_COUNT - 1, APP_RING_PAGE },
    /*
     * No seq_reset row. RESET is a patch parameter now — a preset carries its own period —
     * so there is nothing left here to read, clamp or store: see SYNTH_PARAM_SEQ_RESET in
     * synth_app.h. The row and the enum entry were removed rather than left dead, and the
     * slot on the SYSTEM page is empty: it is not taken by another setting and the
     * vibration motor is not coming back. A `seq_reset` byte written by an older image is
     * simply never read again, and the factory 16 comes from the parameter's own default.
     */
    /*
     * STORE, not RANDOM. A device that has never been configured should come back with the
     * sound it was left with; inventing a new one at every switch-on is a mode worth having
     * and not a mode worth being the factory state. The migration below moves the boards
     * that already carry the old default and leaves a deliberate RANDOM alone.
     */
    [APP_SET_PATCH]     = { "patch_on",  APP_PATCH_FORGET, APP_PATCH_RANDOM,
                            APP_PATCH_STORE },
    /* Five positions — off, 0.2, 0.5, 1.5 and 3 seconds — and the INDEX is what is stored,
     * the way the patch mode stores its own. The durations themselves live in synth_app,
     * which is the only thing that can act on them. */
    [APP_SET_SLIDE]     = { "slide_i",   0, 4, 2 },
    /*
     * ON, because that is what the instrument already did. Both halves of the delay's time
     * section — SYNC and TIME — have been part of the timbre draw for as long as the draw
     * has existed, so a setting whose factory state changed the sound of every patch
     * already saved would arrive as a fault rather than as a choice. OFF is the new one:
     * for a player who has placed the delay in time and does not want a draw to move it.
     */
    [APP_SET_RND_DELAY] = { "rnd_dly",   0, 1, 1 },
    /*
     * The microphone, OFF at the factory, like the ring-mode fallback above: a device
     * that has never been configured has not been listened to yet. Every row in this
     * table is required — the array is indexed by APP_SET_* and read through
     * SETTINGS[i].key, so a missing row is a null key and a crash on the first turn of
     * the knob, not a compile error.
     */
    [APP_SET_MIC]       = { "mic_pct",   0, 100, 0 },
    /*
     * The weak hit, 80 of 127 out of the factory: the number this was when it was a
     * constant in synth_app.cpp, and the weak hit of that pair sits 20*log10(127/80) =
     * 4.01 dB below an accented hit. The range is the engine's own velocity, whole
     * numbers 0..127, so nothing is rounded on the way in or out: 127 is "no difference"
     * — every hit struck as loud as the voice goes — and 0 leaves only the accented
     * onsets sounding, because the engine reads a velocity that is not greater than zero
     * as "no hit". The one reader is accent_velocity_weak() in synth_app.cpp, which is
     * where the three values are explained; the 127 and the 80 are written out here as
     * well because this component cannot include synth_app.h — it would be a cycle —
     * and the division there clamps, so the two copies cannot disagree audibly.
     */
    [APP_SET_WEAK_VEL]  = { "weak_vel",  0, 127, 80 },
    /*
     * The note input, OFF out of the factory — and the reason is the socket rather than the
     * taste. Only one controller can own the USB PHY, so while the device stack is up the
     * USB-C port is a MIDI interface and the debug console is gone from the computer; OFF is
     * the state that keeps the port. What gives it up is a turn of the MIDI IN knob on OPTIONS
     * while the instrument plays, and the port does not come back on the spot: the driver and
     * the USB controller are released, and the console is on the cable again only after a
     * restart with this OFF — which is why main() reads the value at every boot.
     * See APP_SET_MIDI_IN in app_settings.h.
     *
     * 0..1 rather than a list of names, like the random-delay switch above: the two positions
     * are OFF and ON, and synth_app_param_text() prints exactly those two words.
     *
     * Its effect is NOT applied from apply_to_hardware() below, and that is a build-graph
     * fact rather than an oversight: components/midi already requires synth_app, which
     * requires this component, so app_settings calling midi_in_set_enabled() would be a cycle.
     * The settings pages own the call instead — see apply_setting() in synth_ui.c — exactly as
     * they own the ring mode, and the boot-time decision is main()'s, made from this value.
     */
    [APP_SET_MIDI_IN]   = { "midi_in",   0, 1, 0 },
    /* Eleven positions — instant, 5, 10, 15, 20, 25, 30, 40, 60, 80 and 100 ms — and the INDEX
     * is what is stored, the way the slide's row stores its own. The durations themselves live
     * in synth_app.cpp (WAVE_MORPH_MS), which is the only thing that can act on them.
     *
     * 25 ms out of the factory: long enough that the waveform is not stepped into, short enough
     * that the knob still feels like a knob, and the value the feature was listened to at. 0 is
     * a real position and means exactly the old behaviour — one render, one step per block — so
     * the feature can be switched off from the screen without a reflash. See
     * APP_SET_WAVE_MORPH in app_settings.h for why it is a setting and not a patch parameter.
     */
    [APP_SET_WAVE_MORPH] = { "wav_morph", 0, 10, 5 },
    /* Dead, and kept for the same reason the enum entry is: this table is indexed by it. The
     * key is never written any more, and the entry has to stay so the ones around it keep
     * their places in a stored blob. */
    [APP_SET_DRIVE_POS]  = { "drv_fx",    0, 1, 0 },
};

/* The step counts app_seq_reset_t stands for, indexed by the stored position. */
static const int SEQ_RESET_STEPS[APP_SEQ_RESET_COUNT] = { 0, 16, 32, 64, 128, 256 };

int app_seq_reset_steps(int index)
{
    if (index < 0 || index >= APP_SEQ_RESET_COUNT) {
        return 0;
    }
    return SEQ_RESET_STEPS[index];
}

typedef struct {
    uint16_t count;
    float    value[APP_SETTINGS_PATCH_MAX];
} patch_blob_t;

static nvs_handle_t s_nvs;
static bool         s_ready;

static int      s_value[APP_SET_COUNT];
static uint32_t s_dirty;        /* settings waiting for the flash */
static bool     s_patch_dirty;
static patch_blob_t s_patch;    /* always the most recent sound, dirty or not */
static app_settings_patch_repair_t s_patch_repair;  /* factory values live in synth_app */
static float    s_tempo;        /* the knob's position, 0..1, as last seen */
static bool     s_tempo_valid;  /* something was stored, or something has noted one */
static bool     s_tempo_dirty;

static esp_timer_handle_t s_write_timer;

/* -------------------------------------------------------------------------- */
/* Storage                                                                    */
/* -------------------------------------------------------------------------- */

static void write_pending(void)
{
    if (!s_ready) {
        return;
    }

    bool wrote = false;

    for (int i = 0; i < APP_SET_COUNT; i++) {
        if (!(s_dirty & (1u << i))) {
            continue;
        }
        const esp_err_t err = nvs_set_u8(s_nvs, SETTINGS[i].key, (uint8_t)s_value[i]);
        if (err != ESP_OK) {
            ESP_LOGW(TAG, "could not store %s: %s", SETTINGS[i].key, esp_err_to_name(err));
            continue;
        }
        s_dirty &= ~(1u << i);
        wrote = true;
    }

    if (s_patch_dirty) {
        esp_err_t err;
        if (s_value[APP_SET_PATCH]) {
            /* offsetof, and NOT sizeof(s_patch.count): patch_blob_t starts with a uint16_t
             * and continues with a float array, so there are two bytes of padding between
             * them. Writing sizeof(count) + n * sizeof(float) therefore cuts the LAST value
             * in half — 60 parameters went to flash as 242 bytes instead of 244, and the
             * sixtieth came back made half of what was written and half of whatever the
             * stack happened to hold. */
            err = nvs_set_blob(s_nvs, PATCH_KEY, &s_patch,
                               offsetof(patch_blob_t, value) +
                               (size_t)s_patch.count * sizeof(float));
        } else {
            /* Turning the memory off forgets the sound as well. "Off" that still
             * restored the old patch on the next boot would be a lie. */
            err = nvs_erase_key(s_nvs, PATCH_KEY);
            if (err == ESP_ERR_NVS_NOT_FOUND) {
                err = ESP_OK;
            }
        }
        if (err == ESP_OK) {
            s_patch_dirty = false;
            wrote = true;
        } else {
            ESP_LOGW(TAG, "could not store the patch: %s", esp_err_to_name(err));
        }
    }

    if (s_tempo_dirty) {
        const esp_err_t terr = nvs_set_blob(s_nvs, TEMPO_KEY, &s_tempo, sizeof(s_tempo));
        if (terr == ESP_OK) {
            s_tempo_dirty = false;
            wrote = true;
        } else {
            ESP_LOGW(TAG, "could not store the tempo: %s", esp_err_to_name(terr));
        }
    }

    const esp_err_t err = nvs_commit(s_nvs);
    if (err != ESP_OK) {
        ESP_LOGW(TAG, "nvs_commit: %s", esp_err_to_name(err));
        return;
    }

    /*
     * One line per gesture, not per detent: the debounce means this runs when
     * the user has stopped turning, which is also the only moment the answer is
     * interesting. It is what makes "did my setting survive?" a question the log
     * can answer rather than a question that needs another reboot to test.
     */
    if (wrote) {
        ESP_LOGI(TAG, "stored: screen %d%%, ring %d%%, mode %d, remember %d, "
                      "rnd delay %d, mic %d%%, weak vel %d, midi in %d, %u value(s)",
                 s_value[APP_SET_SCREEN], s_value[APP_SET_RING], s_value[APP_SET_RING_MODE],
                 s_value[APP_SET_PATCH], s_value[APP_SET_RND_DELAY],
                 s_value[APP_SET_MIC], s_value[APP_SET_WEAK_VEL], s_value[APP_SET_MIDI_IN],
                 (unsigned)s_patch.count);

        /* Separate line: the tempo is not a setting and not part of the patch, and the line
         * above is about the instrument's switches. Its own line is what makes "did the tempo
         * survive?" answerable from the log alone. */
        if (s_tempo_valid) {
            ESP_LOGI(TAG, "stored: tempo %.4f of the knob's travel", (double)s_tempo);
        }
    }
}

static void write_timer_cb(void *arg)
{
    (void)arg;
    write_pending();
}

static void schedule_write(void)
{
    if (!s_ready || !s_write_timer) {
        return;
    }
    /* Restart rather than start: every change pushes the write further out, so
     * the flash is touched once per gesture and not once per detent.
     *
     * A stop and a start rather than esp_timer_restart(). That one refuses to touch a timer
     * that is not armed — it checks first and returns ESP_ERR_INVALID_STATE without starting
     * anything — and a one-shot timer is not armed the moment it has fired, which is also
     * the state this is in on the very first change after a power-up. So the debounce armed
     * itself never, and write_pending() was never called: every setting, and the remembered
     * sound with it, lived in RAM until the board was switched off. esp_timer_stop() reports
     * the same "not armed" as an error and it is ignored on purpose, because not running is
     * exactly the case this has to recover from. */
    esp_timer_stop(s_write_timer);
    esp_timer_start_once(s_write_timer, WRITE_DELAY_US);
}

/* -------------------------------------------------------------------------- */
/* Applying                                                                   */
/* -------------------------------------------------------------------------- */

/*
 * The two settings the board enacts itself.
 *
 * Both are safe to call with the value they already have, so this needs no
 * "has it changed" bookkeeping. The display brightness takes percent directly;
 * the ring takes an attenuation where 255 is "nothing taken off", which is how
 * the BSP's own ceiling is expressed.
 */
static void apply_to_hardware(app_setting_t id, int value)
{
    switch (id) {
    case APP_SET_SCREEN:
        bsp_display_brightness_set(value);
        break;
    case APP_SET_RING:
        if (bsp_led_is_available()) {
            bsp_led_set_brightness((uint8_t)(value * 255 / 100));
        }
        break;
    default:
        /* The ring mode belongs to the ring's own redraw and the sequencer
         * realignment to the audio task; neither is a board call. */
        break;
    }
}

/* -------------------------------------------------------------------------- */
/* The values whose meaning moved                                             */
/* -------------------------------------------------------------------------- */
/*
 * A remembered sound is an array of floats with no names in it: the position is the
 * parameter (see synth_app.h's synth_param_t) and the value is normalised. Four of those
 * positions now mean something different from what they meant when the values in the flash
 * were written, so the same number would come back as a different sound — silently, since
 * nothing about a float says which control wrote it.
 *
 *   ARP SPEED and DELAY SYNC
 *     Two division lists, widened from five entries to thirteen and twelve. A list
 *     position is round(v * (count - 1)), so a longer list renumbers every entry but the
 *     two ends: the delay's factory 1/8 was index 2 of 5, its value is 0.5, and against
 *     twelve entries 0.5 is index 6 — a dotted eighth. Both maps therefore go by NAME
 *     rather than by arithmetic: each old entry names the new entry that is the same
 *     division.
 *
 *   PERC PITCH
 *     The knob's floor moved from 55 Hz to 35 Hz and its span from 7.00 to 7.65 octaves,
 *     so the same height sits at a different position. Equal heights give:
 *
 *         35 * 2^(7.65 * new) = 55 * 2^(7.00 * old)
 *         new = old * 7.00 / 7.65 + log2(55 / 35) / 7.65
 *
 *     The second term is the floor dropping away: log2(55/35) = 0.6520767, and
 *     0.6520767 / 7.65 = 0.0852388. The old factory position 0.28 — the 214 Hz tom — comes
 *     back as 0.3414, which is 214 Hz again; and 0.3415 is what synth_app's own factory
 *     default for this parameter has been since the floor moved, which is the check that
 *     this is the right formula rather than merely a plausible one.
 *
 *   PERC ENV
 *     The depth's ceiling moved from three octaves to five, so the same fall is 3/5 of the
 *     travel: 0.45 * 3 / 5 = 0.27 — again the value synth_app already defaults to.
 *
 *   VERB MODE
 *     The reverb's mode list lost an entry: HOLD, which sat fourth of five. Every position
 *     after the hole moved down and the hole itself has no position left, so this one is a
 *     map and not a formula — ROOM, HALL and CATHEDRAL keep their places, PLATE becomes 3,
 *     and a stored HOLD becomes HALL. See MIG_VERB_MAP below.
 *
 * SCALE is the same kind of move as VERB MODE — a list that changed length — and those two
 * are corrected one at a time, each under a flag of its own, because neither walk can be
 * repeated: the second pass would find a different entry under the same number. Both are
 * described over their own functions, migrate_patch_scale() and migrate_patch_verb().
 *
 * The indexes are written out rather than included: synth_app requires this
 * component, so including its header here would be a cycle. They are checked against the
 * enum by static asserts in synth_app.cpp, next to the list they belong to.
 */
#define MIG_ARP_SPEED   33
#define MIG_DELAY_SYNC  36
#define MIG_PERC_PITCH  51
#define MIG_PERC_ENV    54
#define MIG_SCALE       10
#define MIG_VERB_MODE   43

/* Old entry -> the new entry holding the same division. */
static const uint8_t MIG_ARP_MAP[5]   = { 6, 8, 10, 11, 12 };  /* 1/4, 1/8, 1/8T, 1/16, 1/32 */
static const uint8_t MIG_DELAY_MAP[5] = { 0, 5, 7, 9, 10 };    /* FREE, 1/4, 1/8, 1/8T, 1/16 */

#define MIG_ARP_OLD      5
#define MIG_ARP_NEW     13
#define MIG_DELAY_OLD    5
#define MIG_DELAY_NEW   12

/*
 * The scale list grew from eleven to sixteen, and every one of the eleven kept its place —
 * the five new ones were appended for exactly this reason — so an old position is the same
 * position and the map below is the identity. It is not the numbers that make it necessary:
 * the byte read back is a NORMALISED value, and the list it is read through is longer, so
 * the same byte lands on a different entry unless it is walked through the old length once.
 */
#define MIG_SCALE_OLD   11
#define MIG_SCALE_NEW   16
static const uint8_t MIG_SCALE_MAP[MIG_SCALE_OLD] =
    { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

/*
 * The reverb's mode list lost an entry, and the loss was not at the end: HOLD sat fourth of
 * five, so the mode after it moved down and the hole itself has nowhere to point. The map is
 * therefore almost the identity — ROOM, HALL and CATHEDRAL keep their positions and PLATE
 * comes down from 4 to 3 — with one entry that is not: HOLD becomes HALL, the mode the device
 * comes up in and the nearest thing to it that still exists. There is nothing else it could
 * honestly become. Walking the stored value through the OLD length and writing it back
 * through the new one is mig_list()'s whole job; see the note over it.
 */
#define MIG_VERB_OLD     5
#define MIG_VERB_NEW     4
static const uint8_t MIG_VERB_MAP[MIG_VERB_OLD] =
    { 0, 1, 2, 1, 3 };          /* ROOM, HALL, CATHEDRAL, HOLD->HALL, PLATE */

/* 55 Hz over 7.00 octaves became 35 Hz over 7.65. */
#define MIG_PITCH_SCALE   (7.00f / 7.65f)
#define MIG_PITCH_OFFSET  (0.6520767f / 7.65f)
/* Three octaves of depth became five. */
#define MIG_ENV_SCALE     (3.0f / 5.0f)

/* A float read out of the flash can be anything at all, a NaN included, and every step
 * below would carry it straight through to the engine. This is the one place that decides
 * what a nonsense value becomes. */
static float mig_clamp01(float v)
{
    if (!(v > 0.0f)) {          /* negative, zero and not-a-number all land on the floor */
        return 0.0f;
    }
    return (v > 1.0f) ? 1.0f : v;
}

/* One stored list position, read through the old list and written back through the new. */
static float mig_list(float v, const uint8_t *map, int old_count, int new_count)
{
    int old = (int)(mig_clamp01(v) * (float)(old_count - 1) + 0.5f);
    if (old < 0) {
        old = 0;
    } else if (old > old_count - 1) {
        old = old_count - 1;
    }
    return (float)map[old] / (float)(new_count - 1);
}

/*
 * Rewrites the remembered sound in the flash, once.
 *
 * Returns true when there is nothing left to do — "there was no sound stored" included —
 * and false only when the write itself failed, so a boot that could not reach the flash
 * tries again next time instead of marking the work done.
 *
 * The blob goes straight through nvs_set_blob() rather than through the s_patch copy and
 * its debounce, and that is the one place this differs from the patch_mig migration below:
 * the patch's own write path is gated on the sound being remembered at all, while this is a
 * correction to the bytes rather than an edit to the sound. It has to happen whether PATCH
 * says STORE or not, or a device that spent one boot on FORGET would carry the old meanings
 * for good.
 */
static bool migrate_patch_values(void)
{
    patch_blob_t blob;
    size_t len = sizeof(blob);
    if (nvs_get_blob(s_nvs, PATCH_KEY, &blob, &len) != ESP_OK) {
        return true;            /* nothing remembered: nothing to rewrite */
    }
    if (len < sizeof(blob.count) || blob.count > APP_SETTINGS_PATCH_MAX) {
        ESP_LOGW(TAG, "stored patch is malformed (%u bytes, %u values) — not migrated",
                 (unsigned)len, (unsigned)blob.count);
        return true;            /* damaged: app_settings_patch_load() refuses it anyway */
    }

    const int n = (int)blob.count;
    if (len < offsetof(patch_blob_t, value) + (size_t)n * sizeof(float)) {
        ESP_LOGW(TAG, "stored patch is truncated (%u bytes for %d values) — not migrated",
                 (unsigned)len, n);
        return true;
    }

    /* Only the positions this firmware still has: a blob written before a parameter was
     * appended is shorter, and a position past its end keeps its default rather than being
     * invented here. */
    bool touched = false;

    if (n > MIG_ARP_SPEED) {
        blob.value[MIG_ARP_SPEED] =
            mig_list(blob.value[MIG_ARP_SPEED], MIG_ARP_MAP, MIG_ARP_OLD, MIG_ARP_NEW);
        touched = true;
    }
    if (n > MIG_DELAY_SYNC) {
        blob.value[MIG_DELAY_SYNC] =
            mig_list(blob.value[MIG_DELAY_SYNC], MIG_DELAY_MAP, MIG_DELAY_OLD, MIG_DELAY_NEW);
        touched = true;
    }
    if (n > MIG_PERC_PITCH) {
        const float old = mig_clamp01(blob.value[MIG_PERC_PITCH]);
        blob.value[MIG_PERC_PITCH] = mig_clamp01(old * MIG_PITCH_SCALE + MIG_PITCH_OFFSET);
        touched = true;
    }
    if (n > MIG_PERC_ENV) {
        blob.value[MIG_PERC_ENV] = mig_clamp01(blob.value[MIG_PERC_ENV]) * MIG_ENV_SCALE;
        touched = true;
    }

    if (!touched) {
        return true;
    }

    /* The length is the one app_settings_patch_load() will check it against — the count
     * plus the padding the blob starts with, not offsetof() replaced by sizeof(). */
    const size_t bytes = offsetof(patch_blob_t, value) + (size_t)n * sizeof(float);
    if (nvs_set_blob(s_nvs, PATCH_KEY, &blob, bytes) != ESP_OK) {
        ESP_LOGW(TAG, "could not rewrite the remembered sound");
        return false;
    }

    ESP_LOGI(TAG, "remembered sound: %d values, divisions and percussion moved to their new "
                  "meanings", n);
    return true;
}

/*
 * The remembered sound's SCALE, walked through the list it was saved against.
 *
 * A flag of its own rather than PARAM_MIG_KEY above, and that is not tidiness: that flag is
 * already set on every device that has booted an earlier firmware, and its corrections are
 * not idempotent — re-running the percussion's would move those values twice. So the scale
 * gets its own one-time flag, which is also what a later list change has to do.
 *
 * Nothing here is invented: the eleven entries kept their meanings, so mig_list() is asked
 * for an identity map, and what it does is the arithmetic the longer list now demands.
 */
static bool migrate_patch_scale(void)
{
    patch_blob_t blob;
    size_t len = sizeof(blob);
    if (nvs_get_blob(s_nvs, PATCH_KEY, &blob, &len) != ESP_OK) {
        return true;            /* nothing remembered: nothing to rewrite */
    }
    if (len < sizeof(blob.count) || blob.count > APP_SETTINGS_PATCH_MAX
        || (int)blob.count <= MIG_SCALE) {
        /* Damaged, or a sound from before this parameter existed: both keep their
         * defaults rather than being invented here. */
        return true;
    }

    const size_t bytes = offsetof(patch_blob_t, value) + (size_t)blob.count * sizeof(float);
    if (len < bytes) {
        ESP_LOGW(TAG, "stored patch is truncated (%u bytes for %u values) — not migrated",
                 (unsigned)len, (unsigned)blob.count);
        return true;
    }

    blob.value[MIG_SCALE] = mig_list(blob.value[MIG_SCALE], MIG_SCALE_MAP,
                                     MIG_SCALE_OLD, MIG_SCALE_NEW);

    if (nvs_set_blob(s_nvs, PATCH_KEY, &blob, bytes) != ESP_OK) {
        ESP_LOGW(TAG, "could not rewrite the remembered sound's scale");
        return false;
    }

    ESP_LOGI(TAG, "remembered sound: scale moved to the %d-entry list", MIG_SCALE_NEW);
    return true;
}

/*
 * The remembered sound's REVERB MODE, walked through the list it was saved against.
 *
 * The reverb lost HOLD, so its list is four long where it was five, PLATE moved down from 4
 * to 3, and a saved HOLD — which has no position left — becomes HALL, the mode the device
 * comes up in and the nearest one to it that still exists. Nothing is invented here: the
 * stored value is read through the OLD five-entry list and written back through the new
 * four-entry one, and MIG_VERB_MAP above is the whole of the decision. A sound that never
 * held a HOLD reads back as the algorithm it already was: the stored number moves — HALL
 * is 0.25 of five and 0.3333 of four — while the position the knob points at does not.
 *
 * A flag of its own, and here it is not tidiness but necessity: the walk is NOT idempotent
 * in the direction that matters. CATHEDRAL is 2 of 4 now, which is 0.6667 — a second walk
 * through the old five-entry list reads that as position 3, HOLD, and turns it into HALL. So
 * the flag has to go in with the value, and a boot that could not reach the flash has to try
 * again rather than mark the work done. See also migrate_patch_scale(), which has the same
 * shape for the same reason.
 */
static bool migrate_patch_verb(void)
{
    patch_blob_t blob;
    size_t len = sizeof(blob);
    if (nvs_get_blob(s_nvs, PATCH_KEY, &blob, &len) != ESP_OK) {
        return true;            /* nothing remembered: nothing to rewrite */
    }
    if (len < sizeof(blob.count) || blob.count > APP_SETTINGS_PATCH_MAX
        || (int)blob.count <= MIG_VERB_MODE) {
        /* Damaged, or a sound from before this parameter existed: both keep their
         * defaults rather than being invented here. */
        return true;
    }

    const size_t bytes = offsetof(patch_blob_t, value) + (size_t)blob.count * sizeof(float);
    if (len < bytes) {
        ESP_LOGW(TAG, "stored patch is truncated (%u bytes for %u values) — not migrated",
                 (unsigned)len, (unsigned)blob.count);
        return true;
    }

    blob.value[MIG_VERB_MODE] = mig_list(blob.value[MIG_VERB_MODE], MIG_VERB_MAP,
                                         MIG_VERB_OLD, MIG_VERB_NEW);

    if (nvs_set_blob(s_nvs, PATCH_KEY, &blob, bytes) != ESP_OK) {
        ESP_LOGW(TAG, "could not rewrite the remembered sound's reverb mode");
        return false;
    }

    ESP_LOGI(TAG, "remembered sound: reverb mode moved to the %d-entry list, HOLD to HALL",
             MIG_VERB_NEW);
    return true;
}

/* -------------------------------------------------------------------------- */
/* Public API                                                                 */
/* -------------------------------------------------------------------------- */

uint32_t app_settings_init(void)
{
    for (int i = 0; i < APP_SET_COUNT; i++) {
        s_value[i] = SETTINGS[i].fallback;
    }

    esp_err_t err = nvs_flash_init();
    if (err == ESP_ERR_NVS_NO_FREE_PAGES || err == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_LOGW(TAG, "nvs partition needs erasing (%s)", esp_err_to_name(err));
        ESP_ERROR_CHECK(nvs_flash_erase());
        err = nvs_flash_init();
    }
    if (err != ESP_OK) {
        ESP_LOGW(TAG, "nvs unavailable: %s — using defaults", esp_err_to_name(err));
        return 0;
    }

    err = nvs_open(NVS_NAMESPACE, NVS_READWRITE, &s_nvs);
    if (err != ESP_OK) {
        ESP_LOGW(TAG, "nvs_open(%s): %s — using defaults", NVS_NAMESPACE, esp_err_to_name(err));
        return 0;
    }

    uint32_t found = 0;
    for (int i = 0; i < APP_SET_COUNT; i++) {
        uint8_t stored = 0;
        if (nvs_get_u8(s_nvs, SETTINGS[i].key, &stored) != ESP_OK) {
            continue;
        }
        if (stored < SETTINGS[i].min || stored > SETTINGS[i].max) {
            ESP_LOGW(TAG, "%s out of range (%u) — ignoring", SETTINGS[i].key, (unsigned)stored);
            continue;
        }
        s_value[i] = stored;
        found |= 1u << i;
        apply_to_hardware((app_setting_t)i, stored);
    }

    /* The clock, read before anything can use it — restore_settings() in the UI is what puts it
     * back into the sound, and it runs a moment after this. Refused unless it is a position on
     * the knob: a blob written by something else would otherwise become a tempo nobody asked
     * for, and a value outside 0..1 is not a place the wheel can stand. */
    {
        float tempo = 0.0f;
        size_t len = sizeof(tempo);
        if (nvs_get_blob(s_nvs, TEMPO_KEY, &tempo, &len) == ESP_OK && len == sizeof(tempo) &&
            tempo >= 0.0f && tempo <= 1.0f) {
            s_tempo = tempo;
            s_tempo_valid = true;
        }
    }

    s_ready = true;

    const esp_timer_create_args_t timer_args = {
        .callback = write_timer_cb,
        .name     = "settings_wr",
    };
    if (esp_timer_create(&timer_args, &s_write_timer) != ESP_OK) {
        ESP_LOGW(TAG, "no write timer — settings will not persist");
        s_write_timer = NULL;
    }

    /*
     * One-time: the factory default used to be RANDOM, and a board that has never been
     * configured cannot be told apart from a user who chose RANDOM on purpose — the old
     * default was written by this same table. The flag makes this happen once and for all,
     * so anyone who turns RANDOM back on afterwards keeps it.
     *
     * It runs after the write timer exists, so the value is committed by the same debounce
     * every other setting uses. The flag goes into the same commit as the value: a flag
     * written on its own could survive a power cut that the value did not, and then the
     * migration would never run again.
     */
    uint8_t migrated = 0;
    if (nvs_get_u8(s_nvs, PATCH_MIG_KEY, &migrated) != ESP_OK) {
        if (s_value[APP_SET_PATCH] == APP_PATCH_RANDOM) {
            ESP_LOGI(TAG, "patch mode: RANDOM was the old default — moving it to STORE");
            s_value[APP_SET_PATCH] = APP_PATCH_STORE;
            s_dirty |= 1u << APP_SET_PATCH;
        }
        nvs_set_u8(s_nvs, PATCH_MIG_KEY, 1);
        schedule_write();
    }

    /*
     * The other one-time correction, and the same rule about the flag: it goes into the
     * same commit as the values, because a flag that survived a power cut the values did
     * not would leave the old numbers being read as new ones for good.
     *
     * Written here rather than through the debounce, unlike the flag above: this edits the
     * remembered sound itself, whose write path waits on the sound being remembered at all
     * — see migrate_patch_values(). It runs before anything can read the blob back, which
     * is the whole point: synth_ui restores the sound from here.
     */
    uint8_t values_migrated = 0;
    if (nvs_get_u8(s_nvs, PARAM_MIG_KEY, &values_migrated) != ESP_OK) {
        if (migrate_patch_values()) {
            nvs_set_u8(s_nvs, PARAM_MIG_KEY, 1);
            nvs_commit(s_nvs);
        }
    }

    /* And the third correction, which cannot share that flag: see migrate_patch_scale(). */
    uint8_t scale_migrated = 0;
    if (nvs_get_u8(s_nvs, SCALE_MIG_KEY, &scale_migrated) != ESP_OK) {
        if (migrate_patch_scale()) {
            nvs_set_u8(s_nvs, SCALE_MIG_KEY, 1);
            nvs_commit(s_nvs);
        }
    }

    /*
     * And the fourth, for the reverb's shorter mode list. Its own flag for a sharper reason
     * than the third's: this walk is not idempotent either — see migrate_patch_verb(), where
     * the second pass would turn a cathedral into a hall — and every device that has ever
     * booted carries the flags above already. The reverb's default is HALL and stays HALL; it
     * is the value the migration writes for a sound that named the mode that no longer exists.
     */
    uint8_t verb_migrated = 0;
    if (nvs_get_u8(s_nvs, VERB_MIG_KEY, &verb_migrated) != ESP_OK) {
        if (migrate_patch_verb()) {
            nvs_set_u8(s_nvs, VERB_MIG_KEY, 1);
            nvs_commit(s_nvs);
        }
    }

    ESP_LOGI(TAG, "screen %d%%, ring %d%%, ring mode %d, remember %d, "
                  "rnd delay %d, mic %d%%, weak vel %d, midi in %d (%u stored)",
             s_value[APP_SET_SCREEN], s_value[APP_SET_RING], s_value[APP_SET_RING_MODE],
             s_value[APP_SET_PATCH], s_value[APP_SET_RND_DELAY],
             s_value[APP_SET_MIC], s_value[APP_SET_WEAK_VEL], s_value[APP_SET_MIDI_IN],
             (unsigned)__builtin_popcount(found));

    /* Here rather than from the caller: the presets live in the same partition
     * and their namespace can only be opened once NVS is up, which is what the
     * line above proves. */
    app_presets_init();

    return found;
}

int app_settings_get(app_setting_t id)
{
    if (id < 0 || id >= APP_SET_COUNT) {
        return 0;
    }
    return s_ready ? s_value[id] : SETTINGS[id].fallback;
}

void app_settings_set(app_setting_t id, int value)
{
    if (id < 0 || id >= APP_SET_COUNT) {
        return;
    }
    if (value < SETTINGS[id].min) {
        value = SETTINGS[id].min;
    } else if (value > SETTINGS[id].max) {
        value = SETTINGS[id].max;
    }
    if (s_ready && value == s_value[id]) {
        return;
    }

    s_value[id] = value;
    apply_to_hardware(id, value);

    /* Turning the memory off forgets the sound now, not on the next boot. */
    if (id == APP_SET_PATCH && !value) {
        s_patch.count = 0;
        s_patch_dirty = true;
    }

    s_dirty |= 1u << id;
    schedule_write();
}

void app_settings_commit(void)
{
    if (s_write_timer) {
        esp_timer_stop(s_write_timer);
    }
    write_pending();
}

/* -------------------------------------------------------------------------- */
/* The remembered sound                                                       */
/* -------------------------------------------------------------------------- */

void app_settings_patch_set_repair(app_settings_patch_repair_t repair)
{
    s_patch_repair = repair;
}

int app_settings_patch_load(float *out, int count)
{
    if (!s_ready || count <= 0) {
        return 0;
    }

    patch_blob_t blob;
    size_t len = sizeof(blob);
    if (nvs_get_blob(s_nvs, PATCH_KEY, &blob, &len) != ESP_OK) {
        return 0;
    }
    if (len < sizeof(blob.count) || blob.count > APP_SETTINGS_PATCH_MAX) {
        ESP_LOGW(TAG, "stored patch is malformed (%u bytes, %u values)",
                 (unsigned)len, (unsigned)blob.count);
        return 0;
    }

    int n = (int)blob.count;
    if (n > count) {
        n = count;
    }

    /* The length has to cover every value that is about to be read out of the blob. A blob
     * written before the padding above was accounted for is two bytes short, and this is
     * where that is caught: refused outright rather than handed on with its last parameter
     * stitched together from a half-written float and the bytes that followed it. */
    if (len < offsetof(patch_blob_t, value) + (size_t)n * sizeof(float)) {
        ESP_LOGW(TAG, "stored patch is truncated (%u bytes for %d values) — ignored",
                 (unsigned)len, n);
        return 0;
    }

    /*
     * The boundary where a remembered number becomes the sound. NVS is only as trustworthy
     * as the image that wrote it: a power cut mid-write, a reflash that moved a parameter,
     * or a float that was never a number are all values this loop can receive. Each is
     * replaced by its factory value here, before the caller can apply it, and reported once.
     */
    for (int i = 0; i < n; i++) {
        float v = blob.value[i];

        if (!isfinite(v) || v < 0.0f || v > 1.0f) {
            const float factory = s_patch_repair ? s_patch_repair(i, v) : 0.0f;

            ESP_LOGW(TAG, "stored patch: parameter %d was %g, using factory %g",
                     i, (double)v, (double)factory);
            v = factory;
        }
        out[i] = v;
    }

    return n;
}

void app_settings_patch_note(const float *in, int count)
{
    if (!s_ready || !in || count <= 0) {
        return;
    }
    if (count > APP_SETTINGS_PATCH_MAX) {
        count = APP_SETTINGS_PATCH_MAX;
    }

    /* A copy, not a pointer: the caller's array belongs to the audio task and
     * will have changed by the time the flash is written. */
    memcpy(s_patch.value, in, (size_t)count * sizeof(float));
    s_patch.count = (uint16_t)count;
    s_patch_dirty = true;
    schedule_write();
}

void app_settings_tempo_note(float v01)
{
    if (!s_ready) {
        return;
    }

    if (!(v01 >= 0.0f)) {
        v01 = 0.0f;
    } else if (v01 > 1.0f) {
        v01 = 1.0f;
    }

    /* Unchanged is not a change: at boot the stored tempo is handed back to the sound and then
     * noted again from the same number, and a randomiser's own writes pass through here on the
     * way to being overruled. Neither is worth a flash write. */
    if (s_tempo_valid && s_tempo == v01) {
        return;
    }

    s_tempo = v01;
    s_tempo_valid = true;
    s_tempo_dirty = true;
    schedule_write();
}

bool app_settings_tempo_load(float *out)
{
    if (!out || !s_tempo_valid) {
        return false;
    }

    *out = s_tempo;
    return true;
}

void app_settings_patch_forget(void)
{
    s_patch.count = 0;
    s_patch_dirty = true;
    schedule_write();
}
