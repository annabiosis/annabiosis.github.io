[Русский](RELEASE-NOTES.md) · **English**

# OBOD 1.2.2

A round synthesizer-controller on the ESP32-S3 with a 360 × 360 dial.

## What is new in 1.2.2

A release about hits, about the character of the sound and about what used to be hidden inside:
percussion has become an instrument with a kit of its own and a part of its own, the random patch
draw has gained a character, and the overdrive has left the signal path altogether.

Percussion is no longer one voice with a pitch knob. There are five: four lanes — kick, snare, hat
and tom — each hold a voice of their own, so the hat under the kick does not take a voice away from
the kick, and the fifth voice is given to the notes that arrive over MIDI. The sound of the section
is chosen by the kit: twenty-eight sets, each with four recipes and its own alternate voices — open
hat, rim, tight kick, higher tom. The PERC knobs have become the sound of the kit: TONE transposes
the kit as a whole, TUNE moves the kick and the tom and seats them in the key, DECAY multiplies the
gates of every lane, PUNCH decides how a hit enters — a long soft attack, a short click of the beater or the
way the kit recorded it — TIMBRE adds life — a
hard hit answers brighter and longer, the pitch shivers, the tuning walks across bars, and up to a
fifth of the hits take the alternate voice. The pitch, the fall of the pitch and the length are
moved by the modulation from the LFO page.

The part has moved to a page of its own, PERC SEQ. GROOVE picks one of thirty-two written grooves
with its own ghost notes and its own cycle of bars; VAR decides how often the cycle plays the
shifted part — the moves are taken once per cycle, two at a high value, and the first cycle always
sounds as written; FILL closes the cycle with one of fifteen fills, replacing the second half of the
bar, and the same fill does not come twice in a row; when there is no fill, the hat takes the open
voice on the last bar. SWING delays every second sixteenth, SPEED sets the speed of the drum's
clock as a multiple — 1/4, 1/2, X1 or X2 — and ACCENT lays out the accents: the marked beats stay
at full strength, the rest are weakened to WEAK VEL.

The balance of the four lanes inside the part lives on a page of its own, PERC MIX: KICK,
SNARE, HAT and TOM stand at 100 when the lane sounds as the kit recorded it, and the knob only
weakens — it cannot add to what was written. A lane at zero does not strike at all: the hit is
not spent on silence, and the part counts it as played. That is why zero is how a lane is muted —
a double tap on a sector drops it to zero and the second tap puts the level back, the same
gesture as the levels and the sends in the mixers. The indicators on the ring show the strength
of the last hit of each lane. The lane levels belong to the patch and the preset; the mute is a
gesture on the panel and is not written. The lanes run apart: a hit on one moves neither the
level, nor the shape, nor the BODY of the others, so the tail of the hat is not heard in the
kick. The level of the part as a whole stays on LEVELS.

The arpeggiator has gained a third independent accent pattern: the accents of the lead, of the arp
and of the hits are different patterns, and each is moved by its own knob. ROOT is split into NOTE
and OCT: the pitch of the tonic and its octave move separately. The filters of the drone and of the
lead have gained MODE — low, band, high and the intermediate positions between them. The former
PITCH, ENV, QUANT, STEPS, PULSES and ROTATE are no longer knobs on the panel: their work has moved
into the recipes of the kits, and the hits have no Euclidean grid. The parameters have stayed in the
patch as dead slots, because a parameter's number addresses the stored presets.

There is no overdrive in the instrument any more. The shaper has been removed from the path
together with the DRIVE and ALGO knobs, and it appears in neither the diagrams nor the
descriptions: the dry path, three sends and three returns go straight into the gate and the
compressor. The microphone has been removed from the sends too: it has stayed a modulation
source, and the AUX bus is silent.

The ring now shows what has been written rather than the knob: the dot has stopped being reset when
a parameter is written on the fly, so while the transport runs the ring shows the part. The knob
accelerates on continuous parameters under a long turn, while the lists still click one position at
a time: the kit and the groove are chosen one by one.
Presets are no longer a tile on the map of the sections: the section opens with the PRESET
button on the transport screen, and the battery charge has moved there too, next to the tempo.
The labels of the tiles on the map are set in the saturated steps of the same colours, so the
families are told apart by colour before the word is read.
 The instrument powers on with the volume
rising, and the default volume is 80%.

The random patch draw goes by characters rather than by a single slice: the draw has gained a
performance and a manner, not only a timbre. In FULL the drone follows the sequencer with the
arpeggiator too, not only the notes that have been played; each register has a waveform of its own
and a base of its own — 55, 110 and 220 Hz, which the tonic does not move — while the tonic itself
has spread across seven octaves.

## What is inside

24 voices at 48 kHz, a drone of three spectral parts, a lead, percussion of five voices and a
microphone input as a modulation source. Two sequencers, an arpeggiator, sixteen scales with
quantising of incoming notes. Effects: chorus, ping-pong delay and reverb in four modes, including
the Dattorro plate. Twenty-three pages, one hundred ten knobs, one hundred sixteen sound
parameters and one hundred twenty-eight preset slots in NVS. Reception of notes over USB-MIDI with transport and
clock.

## What is in the archive

The source code of the project, `dependencies.lock` with pinned component versions, the flashing
page for the browser, documentation of the hardware and the signal chain, and the lists of features
and third-party components.

The ready image is not part of the source archive: it lives in the repository and on the GitHub
release page — `OBOD.bin`, 1 276 000 bytes, SHA-256
`2FCF0DA90BC0A71E40BC058D08F74766633898889762A2F8473476C1685C43E4` — while on the site it is
published sealed only. The source archive on the site is open to everyone, no release code
needed.

## Flashing procedure

```
pwsh -NoProfile -File .\tools\idf.ps1 -p COM4 flash
```

Or with the browser: the flashing page on the site, `tools/webflash/serve.ps1` — locally. The image
on the site lies sealed: the page asks for the release code, derives the key from it and decrypts
the file in the browser, and the image goes to the instrument already decrypted. The release code
is a single one and lives in the Boosty post: the posts with codes are available to any
subscription tier (boosty.to/annabiosis). Details are in `docs/RELEASE.md`.

## Known limitations

Reception of notes is disabled from the factory and occupies the only USB controller, so there is
no debug COM port on the cable. Control change, pitch bend and program change are not handled, and
there is no MIDI output. Tempo from an external clock does not reach delay synchronization. There
is no master limiter and no ditherer, and Bluetooth MIDI is absent. The kit and the groove are
stored as a position in the list, so a preset from an earlier release can land on a different kit:
the lists have become longer.

The Russian text in [RELEASE-NOTES.md](RELEASE-NOTES.md) is the source; if the two diverge, the Russian one is right.
