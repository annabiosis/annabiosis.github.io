[Русский](RELEASE-NOTES.md) · **English**

# OBOD 1.2.2

A round synthesizer-controller on the ESP32-S3 with a 360 × 360 dial.

## What is new in 1.2.2

A release about hits, about the character of the sound and about what used to be hidden inside:
percussion has become an instrument with a kit of its own and a part of its own, the random patch
draw has gained a character, and the overdrive has left the signal path altogether.

Percussion is no longer one voice with a pitch knob. There are five: four lanes — kick, snare, hat
and tom — each hold a voice of their own, so the hat under the kick does not take a voice away from
the kick, and the fifth voice is given to the notes that arrive over MIDI. The sound of the section
is chosen by the kit: twenty-eight sets, each with four recipes and its own alternate voices — open
hat, rim, tight kick, higher tom. The PERC knobs have become the sound of the kit: TONE transposes
the kit as a whole, TUNE moves the kick and the tom and seats them in the key, DECAY multiplies the
gates of every lane, BODY decides whether a hit is noise, tone or a mixture, TIMBRE adds life — a
hard hit answers brighter and longer, the pitch shivers, the tuning walks across bars, and up to a
fifth of the hits take the alternate voice. The pitch, the fall of the pitch and the length are
moved by the modulation from the DRONE MOD page.

The part has moved to a page of its own, PERC SEQ. GROOVE picks one of twenty-four written grooves
with its own ghost notes and its own cycle of bars; VAR decides how often the cycle plays the
shifted part — the moves are taken once per cycle, two at a high value, and the first cycle always
sounds as written; FILL closes the cycle with one of six fills, replacing the second half of the
bar, and the same fill does not come twice in a row; when there is no fill, the hat takes the open
voice on the last bar. SWING delays every second sixteenth, SPEED sets the speed of the drum's
clock as a multiple — 1/4, 1/2, X1 or X2 — and ACCENT lays out the accents: the marked beats stay
at full strength, the rest are weakened to WEAK VEL.

The arpeggiator has gained a third independent accent pattern: the accents of the lead, of the arp
and of the hits are different patterns, and each is moved by its own knob. ROOT is split into NOTE
and OCT: the pitch of the tonic and its octave move separately. The filters of the drone and of the
lead have gained MODE — low, band, high and the intermediate positions between them. The former
PITCH, ENV, QUANT, STEPS, PULSES and ROTATE are no longer knobs on the panel: their work has moved
into the recipes of the kits, and the hits have no Euclidean grid. The parameters have stayed in the
patch as dead slots, because a parameter's number addresses the stored presets.

There is no overdrive in the instrument any more. The shaper has been removed from the path
together with the DRIVE and ALGO knobs, and it appears in neither the diagrams nor the
descriptions: the dry path, three sends and three returns go straight into the gate and the
compressor. The microphone has been removed from the sends too: it has stayed a modulation
source, and the AUX bus is silent.

The ring now shows what has been written rather than the knob: the dot has stopped being reset when
a parameter is written on the fly, so while the transport runs the ring shows the part. The knob
accelerates on continuous parameters under a long turn, while the lists still click one position at
a time: the kit and the groove are chosen one by one. The instrument powers on with the volume
rising, and the default volume is 80%.

The random patch draw goes by characters rather than by a single slice: the draw has gained a
performance and a manner, not only a timbre. In FULL the drone follows the sequencer with the
arpeggiator too, not only the notes that have been played; each register has a waveform of its own
and a base of its own — 55, 110 and 220 Hz, which the tonic does not move — while the tonic itself
has spread across seven octaves.

## What is inside

24 voices at 48 kHz, a drone of three spectral parts, a lead, percussion of five voices and a
microphone input as a modulation source. Two sequencers, an arpeggiator, sixteen scales with
quantising of incoming notes. Effects: chorus, ping-pong delay and reverb in four modes, including
the Dattorro plate. Twenty-two pages, one hundred one knobs, one hundred five sound parameters and
one hundred twenty-eight preset slots in NVS. Reception of notes over USB-MIDI with transport and
clock.

## What is in the archive

The source code of the project, `dependencies.lock` with pinned component versions, the ready image
`OBOD.bin` — 1 241 152 bytes, SHA-256
`2556F7651401641F83346705E08C77CE79920F29C4C8BD18FB7A574B90E453B0` — the flashing page for the
browser, documentation of the hardware and the signal chain, and the lists of features and
third-party components.

## Flashing procedure

```
pwsh -NoProfile -File .\tools\idf.ps1 -p COM4 flash
```

Or with the browser: the flashing page on the site, `tools/webflash/serve.ps1` — locally. The image
on the site lies sealed: the page asks for the release code, derives the key from it and decrypts
the file in the browser, and the image goes to the instrument already decrypted. The release code
is a single one and lives in the Boosty post. Details are in `docs/RELEASE.md`.

## Known limitations

Reception of notes is disabled from the factory and occupies the only USB controller, so there is
no debug COM port on the cable. Control change, pitch bend and program change are not handled, and
there is no MIDI output. Tempo from an external clock does not reach delay synchronization. There
is no master limiter and no ditherer, and Bluetooth MIDI is absent. The kit and the groove are
stored as a position in the list, so a preset from an earlier release can land on a different kit:
the lists have become longer.

The Russian text in [RELEASE-NOTES.md](RELEASE-NOTES.md) is the source; if the two diverge, the Russian one is right.
