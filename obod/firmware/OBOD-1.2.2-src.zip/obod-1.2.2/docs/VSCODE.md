# Working in VS Code

The project is set up so that a fresh clone builds, flashes and debugs without
any per-machine edits to committed files. Machine-specific paths live in
`.idf-env.json` (git-ignored) or in the ESP-IDF extension's own settings.

---

## One-time setup

### 1. Install the extension

VS Code will prompt you — `.vscode/extensions.json` recommends
`espressif.esp-idf-extension`. Install it, then run
**`ESP-IDF: Configure ESP-IDF Extension`** from the command palette and pick
your ESP-IDF installation.

The extension writes absolute paths into its own user settings. That is
expected and is why those paths are not in this repository.

### 2. Tell the command-line tasks where ESP-IDF is

The tasks in `.vscode/tasks.json` call `tools/idf.ps1`, which locates ESP-IDF
by itself in this order:

1. `$env:IDF_PATH`, if already exported in your shell;
2. `.idf-env.json` in the repository root;
3. the standard install locations (`~/esp/esp-idf`, `~/esp/v5.*/esp-idf`,
   `C:/Espressif/frameworks/esp-idf-v5.*`).

If your installation is somewhere else, create `.idf-env.json`:

```json
{
  "idfPath": "C:\\esp\\v5.4\\esp-idf",
  "toolsPath": "C:\\esp\\tools"
}
```

`toolsPath` is only needed if you set `IDF_TOOLS_PATH` during installation.

Verify with:

```powershell
pwsh -File tools/idf.ps1
```

which prints the resolved ESP-IDF path and a list of common commands.

### 3. Build

`Ctrl+Shift+B`, or **Tasks: Run Task → `IDF: Build`**.

---

## Tasks

| Label | What it runs |
|---|---|
| `IDF: Build` | `idf.py build` — the default build task |
| `IDF: Build + Flash + Monitor` | the everyday loop |
| `IDF: Flash` | flash only |
| `IDF: Monitor` | serial monitor; exit with `Ctrl+]` |
| `IDF: Full clean` | `idf.py fullclean` |
| `IDF: Menuconfig` | board options — brightness, LED ring, mic type, QSPI clock |
| `IDF: Size` | per-component flash usage |
| `IDF: Erase flash` | wipes NVS, Wi-Fi credentials and both OTA slots |
| `UI: Sync SquareLine export` | mirrors `ui/export/` into `components/ui/generated/` |
| `FS: Upload assets to SPIFFS` | writes `assets/` into the `storage` partition |

Flash, monitor and upload tasks prompt for the serial port the first time
(`COM7`, `/dev/ttyACM0`, `/dev/cu.usbmodem1101`, …). The prompt is a VS Code
input — it does not remember, so keep the value handy or edit the `inputs`
block in `.vscode/tasks.json`.

### Why a wrapper script instead of plain `idf.py`?

`tools/idf.ps1` dot-sources ESP-IDF's own `export.ps1`, so the tasks work from
any terminal — plain PowerShell, the VS Code integrated terminal, a CI runner —
without requiring the extension to have pre-exported the environment first, and
without putting an absolute path into a committed file. It invents no
environment variables of its own.

---

## Debugging

The ESP32-S3 has a **USB-Serial-JTAG bridge on chip**, so you do not need an
external probe.

1. Connect USB-C to the board's **native USB** port, not the CH340 one. If your
   board exposes only one port, it is the native one.
2. Set a breakpoint.
3. Run and Debug → **`ESP-IDF: Debug (built-in USB-JTAG)`**.

Three configurations are provided:

| Configuration | Use |
|---|---|
| `Debug (built-in USB-JTAG)` | resets, halts and breaks at `app_main` |
| `Debug (built-in USB-JTAG, no break at start)` | attaches to a running image |
| `Attach (built-in USB-JTAG)` | attach without resetting |

These use `${command:espIdf.*}` commands from the extension, so if VS Code
reports *"command 'espIdf.getToolchainGdb' not found"*, the extension is
missing or has not been configured. Running **`ESP-IDF: Add .vscode
configuration folder`** regenerates `launch.json`, `settings.json` and
`c_cpp_properties.json` with absolute paths for your machine — at the cost of
making them non-portable, which is why the committed versions avoid that.

### JTAG caveat

The native USB-JTAG shares pins with the USB peripheral. If the firmware itself
brings up USB (TinyUSB, USB-serial, MSC), debugging over the same port
conflicts. Nothing in this framework does, but application code might.

---

## IntelliSense

`c_cpp_properties.json` derives its include paths from `${env:IDF_PATH}` and
from `build/compile_commands.json`.

**Always build once before trusting IntelliSense.** `compile_commands.json` is
generated during the build and is what makes managed components like LVGL and
`esp_lcd_st77916` resolvable. Before the first build, `#include "lvgl.h"` will
show as an error — that is expected, not a misconfiguration.

If it stays broken after a successful build:
**`ESP-IDF: Add .vscode configuration folder`** rewrites the file with absolute
paths.

Common tweak — if you develop on Windows but build on Linux (or vice versa),
`intelliSenseMode` in `c_cpp_properties.json` should be changed to match the
compiler you are actually using (`windows-gcc-x64`, `linux-gcc-x64`,
`macos-clang-x64`).

---

## Sharing the project across machines

Committed and portable:

* `.vscode/tasks.json`, `launch.json`, `extensions.json`, `settings.json`,
  `c_cpp_properties.json`
* `sdkconfig.defaults`, `partitions.csv`
* `tools/idf.ps1` and `tools/idf.sh`

Deliberately git-ignored:

* `sdkconfig` — regenerated from `sdkconfig.defaults`; edit the defaults, not
  the generated file, if you want the change to be shared
* `build/`, `managed_components/`, `dependencies.lock`
* `.idf-env.json` — per-machine
* `ui/export/` — your Studio working copy

Because `sdkconfig` is ignored, menuconfig changes are per-machine. To make a
setting permanent for everyone, add it to `sdkconfig.defaults` and delete your
local `sdkconfig`.

---

## Linux and macOS

`tools/idf.sh` mirrors `tools/idf.ps1` and is wired into the `linux`/`osx`
branches of every task. Core dumps and esptool permissions:

```bash
sudo usermod -aG dialout "$USER"   # then log out and back in
```

For the built-in USB-JTAG debug port, udev rules are needed — the ESP-IDF
installer offers to add them (`install.sh` with `--enable-...`), and OpenOCD
fails with a permission error without them.
