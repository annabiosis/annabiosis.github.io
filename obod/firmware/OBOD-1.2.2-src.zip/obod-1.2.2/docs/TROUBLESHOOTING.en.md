[Русский](TROUBLESHOOTING.md) · **English**

# Troubleshooting

Organised by what you actually see. Each entry names the mechanism, not just
the fix, so you can tell a real match from a coincidence.

---

## Build

### `idf.py: command not found` / `ESP-IDF was not found`

`tools/idf.ps1` could not locate ESP-IDF. It searches `$env:IDF_PATH`,
`.idf-env.json`, then the standard install locations. Create the config file:

```json
{ "idfPath": "C:\\esp\\v5.4\\esp-idf" }
```

Run `pwsh -File tools/idf.ps1` with no arguments to see which path it resolved.

### `esp_lcd_st77916: version solving failed` or unknown component

The component manager could not reach the registry, or the IDF version is too
old. `esp_lcd_st77916` 2.x requires **ESP-IDF ≥ 5.4**; that constraint is in
`main/idf_component.yml`.

```powershell
pwsh -File tools/idf.ps1 --version
```

### `undefined reference to ui_init`

`components/ui/generated/` has no `.c` files. Either restore the placeholder
`ui.c`, or run **`UI: Sync SquareLine export`** after exporting from Studio. The
component's `CMakeLists.txt` prints a warning at configure time when this
happens.

### Changes to `sdkconfig.defaults` had no effect

Defaults are only applied when `sdkconfig` does not exist. Either delete
`sdkconfig` and rebuild, or run `idf.py menuconfig` and set it there — but note
menuconfig changes are per-machine, since `sdkconfig` is git-ignored.

### New SquareLine screens are missing from the binary

The component globs `generated/*.c` with `CONFIGURE_DEPENDS`, so a normal
rebuild should pick them up. If it does not, run `idf.py reconfigure` — or,
rarely, delete `build/` (CMake caches directory listings aggressively).

---

## Display

### Screen stays completely dark

The most likely cause is the **panel revision mismatch**, not a wiring fault.
Two ST77916 revisions exist and the driver's built-in init sequence only
matches one.

Try `Knob BSP → Display → Use the vendor LCD init sequence` → **enable** →
rebuild. The log line at boot tells you which one is active:

```
I (324) bsp.display: init sequence: driver default
```

Confirm the backlight is actually being driven before assuming the panel is at
fault — `bsp_display_brightness_set(100)` from `app_main` is a one-line test.

### Screen is lit but shows snow, stripes or a shifted image

Almost always timing. Lower `Knob BSP → Display → QSPI clock` to 20 MHz:

```
Knob BSP → Display (ST77916, QSPI) → QSPI clock (MHz)
```

If 20 MHz is clean and 40 MHz is not, you have a marginal panel or a board
revision with longer traces. The default is 40 MHz. Raising it to 80 MHz works
on some boards and is outside the panel's specified range — do not raise it
while diagnosing.

### Colours are inverted (photographic negative)

Something is calling `esp_lcd_panel_invert_color(panel, true)`. Remove it. The
init sequence already ends with `0x21` (INVON) because this panel is wired
inverted, and the two inversions cancel into a negative.

The vendor Arduino demo calls `invertColor(true)` after init, which is safe
there only because re-sending INVON is idempotent. `bsp_display.c` deliberately
does not call it.

### Colours are byte-swapped (red looks blue)

`Knob BSP → Display → Swap bytes in the draw buffer` → enable.

### Tearing during animation

The draw buffers are in PSRAM by default, which trades a little bandwidth for a
lot of internal RAM. If tearing is visible:

1. confirm `Knob BSP → Display → Double buffering` is enabled;
2. raise `Buffer height (lines)` from 60 to 96;
3. only then consider moving buffers to internal RAM (turn off *Place LVGL draw
   buffers in PSRAM*) — that costs ~86 KB of the ~320 KB available and will
   collide with Wi-Fi and audio DMA.

---

## Touch

### Touch does nothing

Check the boot log for:

```
E (298) bsp.touch: no CST816S at address 0x15 — check the flex connector
```

If present, it is physical: reseat the display flex cable. The BSP probes the
bus before handing it to the driver precisely so this produces one clear line
instead of a wall of panel-IO errors.

If the probe *succeeds* but touches are ignored, the controller is alive and
the problem is the interrupt line or LVGL's input device.

### Touches land in the wrong place

The controller reports coordinates in panel space; if the panel is mounted
rotated relative to the display, they need transforming:

```
Knob BSP → Touch → Swap touch axes / Mirror touch X / Mirror touch Y
```

`bsp_touch_set_swap_xy()` and `bsp_touch_set_mirror()` do the same at runtime,
which is faster to iterate with than a rebuild.

### Touches are dropped or jumpy

Drop `Knob BSP → Touch → I2C clock` from 400 kHz to 100 kHz. 100 kHz is the
CST816S specification; 400 kHz usually works but is out of spec, and this is
exactly what out-of-spec looks like.

---

## Rotary encoder

### The knob does nothing in the UI

This is almost always a **group** problem, not a hardware problem. LVGL's
encoder input only moves focus between widgets that are in an `lv_group_t`, and
SquareLine puts nothing into a group.

`ui_app_init()` builds the group by walking the active screen. Check the log:

```
I (3980) ui: SquareLine UI ready, 4 focusable widget(s) on screen
```

If that number is 0, your widgets are not a class the bridge recognises. Add
them explicitly:

```c
bsp_display_lock(0);
ui_app_add_focusable(my_panel);
bsp_display_unlock();
```

If you load a screen with `lv_screen_load()` directly instead of
`ui_app_load_screen()`, the group is not rebuilt and the knob goes dead until
the next call.

### Rotation is backwards

`Knob BSP → Encoder → Swap rotation direction`. It swaps A and B in software,
so no rewiring is needed. This is also the fix for boards whose two encoder
revisions disagree about phase order.

### Detents are doubled or dropped

The driver does not use `espressif/knob`, so `CONFIG_KNOB_*` has no effect on
this board. `bsp_encoder.c` debounces with a single time gate: any edge arriving
within `ENC_DEBOUNCE_US` (2 ms) of the previous one is discarded, and both pins
share one handler so they share one clock.

A worn encoder that doubles detents is producing real extra edges on the same
pin, not reversals, so the fix is to widen that gate. Raise `ENC_DEBOUNCE_US` in
`bsp_encoder.c` — 3 to 4 ms trades a little responsiveness for stability. Going
much beyond that starts swallowing genuine fast turns.

Dropped detents are the opposite problem and usually are not debounce at all:
check the probe's per-line transition counts. If one line moves far less than the
other, that line's contact or pull-up is marginal, and no decoder setting fixes
it.

### The knob component is not used

`espressif/knob` is deliberately absent from this project — it decodes
quadrature, and this encoder is not quadrature (see
[HARDWARE.md](HARDWARE.md#the-encoder-is-not-quadrature--measured)). The
dependency has been removed from the component's `CMakeLists.txt`, so
`iot_knob_*` symbols are not available and `CONFIG_KNOB_*` options do not exist.

The LVGL encoder indev is created directly in `bsp_encoder.c`, and it is the only
reader of the two GPIOs. Do not add a second driver on the same pins.

### I want to react to raw detents

There is no `iot_knob_register_cb()` to register — the knob component is not in
this project. The decoder lives in `bsp_encoder.c`, and the accumulated step
count is deliberately private to it.

React to LVGL events instead — `LV_EVENT_FOCUSED`, `LV_EVENT_VALUE_CHANGED`,
`LV_EVENT_CLICKED`. That is what the bridge does for focus, and it composes
correctly with the rest of the input system.

If you genuinely need the raw edges — for a jog wheel, or a custom gesture — the
clean place to add a hook is inside `encoder_isr()` in `bsp_encoder.c`, next to
the existing `s_accum` update. Do not add a second ISR on the same pins.

---

## Haptics

The vibration motor is **not used**: the firmware has no driver and no feedback
setting, and neither taps nor turns buzz. The ring and the screen are the
feedback. The DRV2605L stays on the JC3636K718C board, but the instrument never
addresses `0x5A` on the I2C bus, so the boot log has no line about it.

---

## LED ring

### The ring never lights

Two common causes:

1. **It is not enabled.** The ring is not in `BSP_FEATURES_DEFAULT()` — use
   `BSP_FEATURES_ALL()` or set `.led_ring = true`.
2. **`Knob BSP → Peripherals → Addressable RGB ring GPIO` is -1**, which
   compiles the ring out. It should default to 0.

### The ring is dim

That is intentional. `CONFIG_BSP_LED_BRIGHTNESS_LIMIT` caps every `bsp_led_*`
call at 128/255 by default, because the ring, backlight, motor and DAC share one
rail. If you raise it, do so in steps and watch for display flicker or resets —
both mean the rail is sagging, not that the code is wrong.

### GPIO0 worries

The ring data line is GPIO0, an ESP32-S3 strapping pin. Driving it during boot
can select the wrong boot mode. `bsp_led_init()` is only called after the
system is up, which is why the ring is excluded from the default feature set.

---

## Audio

### No sound

Check the log for `audio out` — if `bsp_audio_out_init()` failed, the reason is
printed. The PCM5100A is a plain I2S DAC with no I2C control, so a failure here
is almost always the I2S peripheral (both controllers in use) rather than the
codec.

Remember the output is **muted at init** and unmuted once the channel is
running, to keep the power-on thump out of the speaker. If you mute it and
forget to unmute, `bsp_audio_out_is_muted()` tells you.

### The microphone returns silence or garbage

The BSP assumes the mic is **PDM**, based on the schematic routing only two
signals to it. If yours is a conventional I2S mic that needs a word-select
line, switch:

```
Knob BSP → Microphone → Microphone interface → I2S
```

and set the word-select GPIO.

If PDM is correct but the level is low, `bsp_audio_in_set_gain()` is the only
recourse — and on this chip it is no recourse at all. ESP-IDF exposes no
analogue gain on the PDM RX path; on the parts that have the PDM RX
high-pass/amplify stage (P4, S31) there is `amplify_num`, a straight multiplier
of the converted samples, 1..15, that is, 0 to +23.5 dB with a step that shrinks
from +6.0 dB at the bottom to +0.6 dB at the top — not "3 dB per step", and
+23.5 dB maximum and not 42. **The ESP32-S3 does not have that stage**:
`SOC_I2S_SUPPORTS_PDM_RX_HP_FILTER` is undefined, `i2s_pdm_rx_slot_config_t` has
no `amplify_num` field, and the call compiles its `this chip has no PDM RX
amplify stage` branch and returns `ESP_ERR_NOT_SUPPORTED` (the application asks
once per run and then remembers, so the warning appears once, not on every
detent). The level is therefore raised in software,
after the DC blocker, by the microphone's sensitivity setting (up to 6x, +15.6
dB). Any gain there lifts the microphone's own noise floor along with the
signal, and 8.7x is where the loudest thing measured on this board (a hand clap,
0.115 of full scale) reaches full scale; if the result sounds harsh rather than
loud, that is why. Confirm the sample rate matches what the microphone expects
before assuming the level is too low.

---

## SD card

### `not mounted`

The board has no card-detect line, so "no card" and "unreadable card" both
appear as a mount failure. `bsp_sdcard_mount()` retries in 1-bit mode
automatically; if that also fails you will see both errors.

Common causes: the card is exFAT (the ESP32 FAT driver wants FAT32), or it is
not seated. Cards above 32 GB ship exFAT by default — reformat as FAT32 on a PC.

### The card mounts but files are missing

`assets/` uploaded with **`FS: Upload assets to SPIFFS`** lands in the on-board
`storage` partition, not on the SD card. They are different filesystems at
different paths — `/assets` versus `/sdcard`. Check which one your code opens.

---

## The instrument rebooted by itself

### What the firmware does

The first line the application prints on every boot is the reset reason:

`reset reason: 4 (panic / abort)`

The number is `esp_reset_reason()` and the bracket is its meaning. Panics and brownouts get a warning of their own: the first is a fault in the code, the second is a fault in the supply, and they are fixed in different places.

The last actions are kept in RTC memory, which survives a reset: page turns, opening and closing the drawers, knob movement, effect parameters, preset load and save, and the note input on/off. On the next boot the log shows the last twenty records with the time since boot and then clears the ring. The knob is written at most ten times a second, so one movement cannot fill the ring on its own.

If the instrument goes silent while the screen and the parameter values keep working, look for `rescue N: silence for 1.0 s, ...` in the log. That is the silence watchdog: it sees the transport running, the drone's levels up and the rack's output exactly zero for a whole second, and does what the non-finite fuse does — puts every pole and smoother on its target and clears the effects' state — so the sound comes back without a reboot. The line repeats at most every three seconds; if it keeps coming, the instrument is not curing itself and a reset is the next step. The last rescue is kept in RTC memory and printed after the next boot as `previous boot: silence at 12.4 s, ...`, which says how long after power-on it happened and what state the path was in. After an ordinary power-off there is no such line.

On a panic the handler writes a core dump to the 64 KB `coredump` partition. The dump survives the reboot and is read with a separate command.

### How to capture the trail

Connect the instrument to COM4 and run:

```
pwsh -File tools/crash.ps1 -Port COM4
```

The script resets the board, reads the log, decodes the dump if there is one, and writes everything to `build/crash-<date>.txt`. If there is no dump it says so and shows the reset reason from the log. If the board must not be reset, add `-NoReset`.

### How to read the dump

Look for the `Crashed task` line — the task in which the panic happened — and the `#0`, `#1`, … lines with function names. The top frame is the failure point; the frames below show how execution got there. If the dump has no task name, the frame before `vPortTaskWrapper` names the task. The task and the stack belong to the build that was on the board: match `build/guition_knob.elf` to the flashed image, otherwise the function names come from another build.

### A `LoadProhibited` dump at a zero address with `spi_bus_lock` in the stack

This is not the supply and not heat: two parts of the firmware that share the display's data bus collided. The task that draws a frame and the interrupt that pushes it into the panel ended up on different processor cores, and at one narrow spot in the driver one of them cleared a pointer while the other was still reading it. The firmware keeps them on one core on purpose, so a dump of this shape means that property was lost somewhere, not that the instrument broke.

What to check, in order:

1. The core that carries the bus interrupt and the core of the drawing task must be the same one. In `components/bsp_jc3636k718c/src/bsp_display.c` that is `bus_cfg.isr_cpu_id = ESP_INTR_CPU_AFFINITY_0` at bus bring-up and `lvgl_cfg.task_affinity = 0` further down. If the drawing task is moved to another core, the interrupt moves with it: the two numbers are one number.
2. In the dump, `Crashed task` is whichever task the interrupt happened to catch on its own core, so it is usually the audio task and not the culprit. The line to read is the top of the stack: `spi_bus_lock` with `spi_intr` beneath it. A zero in `EXCVADDR` confirms a pointer was read after it had been cleared, rather than some neighbouring memory being corrupted.
3. The ESP-IDF version: the race in `bg_exit_core()` (`components/esp_hw_support/spi_bus_lock.c`) is fixed upstream — `lock->acquiring_dev` is read once into a local and `desired_dev` is used from then on. In 6.1 it is read three times, and the cure above only closes the window for our task layout. After an IDF change, look at that function: if the triple read is gone, the bus may be released on either core again.
4. If the dump shows a different address, or the top of the stack is somewhere else, it is another fault — see the table below and “How to read the dump”.

### Reset reason → what it means → where to look

| Log line | What it means | Where to look |
| --- | --- | --- |
| `power-on` | Power was applied again; RTC memory is gone | Supply, cable, switch |
| `external pin` | Reset over EN | Reset button, wiring, USB |
| `software (esp_restart)` | Software reset | `esp_restart()`, firmware update |
| `panic / abort` | Exception or `abort()` | Dump and stack, `tools/crash.ps1` |
| `task watchdog` | A task ran past its deadline | Blocking calls, `vTaskDelay`, audio task |
| `interrupt watchdog` | An interrupt did not return | Drivers, critical sections |
| `other watchdog` | Another watchdog fired | Watchdog configuration |
| `brownout` | The supply dipped | 5 V rail, ring, backlight, cable |
| `power glitch` | A short supply dip | Supply and connectors |
| `CPU lockup` | Double exception | Dump, stack, `tools/crash.ps1` |
| `deep sleep wake` | Woken from deep sleep | Normal wake-up |
| `USB peripheral` / `JTAG` | Reset over USB or JTAG | Cable, debugger |

If the log contains `Found core dump ... in flash`, the dump really was written; if there is no dump but the reason is a panic, check that the `coredump` partition reached the partition table and that the ELF matches the image.

---

## Power

### Random resets, display flicker, Wi-Fi drops under load

Almost certainly the shared 5 V rail, not software. Contributors, roughly in
order of impact:

1. the LED ring at high brightness,
2. the backlight at 100 %,
3. the vibration motor,
4. Wi-Fi transmit bursts.

Reduce `CONFIG_BSP_LED_BRIGHTNESS_LIMIT` first, then the backlight. Powering the
board from a weak USB port or a thin cable makes this dramatically worse — try
a different supply before changing any code.

On a brownout the chip reports the reason at boot:

```
Brownout detector was triggered
```

That message is the confirmation that it is power and not a firmware bug.

The Russian text in [TROUBLESHOOTING.md](TROUBLESHOOTING.md) is the source; if the two diverge, the Russian one is right.
