# Hardware reference — Guition JC3636K718C

Everything here is in `components/bsp_jc3636k718c/include/bsp/bsp_pins.h`. This
document exists to explain *why* those values are what they are, because two of
them contradict the vendor's own demo code.

---

## The board

| | |
|---|---|
| Model | JC3636K718C_I_Y1(GY) |
| MCU | ESP32-S3R8, dual-core LX7 @ 240 MHz |
| Memory | 16 MB QIO flash, 8 MB **Octal** PSRAM |
| Display | 1.85" IPS, 360×360, fully laminated, ST77916 |
| Input | capacitive touch + rotary encoder |
| Output | RGB LED ring, speaker (PCM5100A), vibration motor |
| Storage | microSD |
| Radio | Wi-Fi 2.4 GHz + BT 5.0 |

For the manufacturer's own summary see
[guition.com](https://www.guition.com/esp32-display-module/1-85-inch-round-knob-screen).

---

## Pin map

### Display — ST77916 on QSPI

| Signal | GPIO |
|---|---|
| CS | 12 |
| SCK | 11 |
| D0 / D1 / D2 / D3 | 13 / 14 / 15 / 16 |
| RST | 17 |
| Backlight (PWM) | 21 |
| TE (unused) | 18 |

The panel is on a **4-lane QSPI** bus, not plain SPI. That is why
`esp_lcd_st77916` ≥ 2.0 is required — earlier versions only do single-lane.

`lcd_cmd_bits = 32` and `flags.quad_mode = true` are mandatory; the driver
prepends the `0x02` write-command opcode itself, so the init list contains
ordinary 8-bit command codes.

### Touch — CST816S on I2C

| Signal | GPIO |
|---|---|
| SDA | 9 |
| SCL | 10 |
| INT | 7 |
| RST | 8 |
| Address | `0x15` |

Specified for 100 kHz. It usually runs at 400 kHz, but that is outside the
datasheet — if touches are dropped, come back down (`Knob BSP → Touch → I2C
clock`).

### I2C bus

GPIO 9 and 10 carry **both** the CST816S and the DRV2605L. The bus is therefore
owned by the BSP as a whole (`src/bsp_i2c.c`) rather than by either driver, and
each device sets its own clock rate when it is added. External pull-ups R56/R57
are fitted; the BSP enables the internal ones as well, which costs nothing at
these speeds.

### Encoder

| Signal | GPIO |
|---|---|
| A | 2 |
| B | 1 |

There is **no push button** — see below.

### Addressable LED ring

| | |
|---|---|
| Data | **GPIO0** |
| Count | **13** |
| Order | GRB (WS2812-compatible) |
| Brightness cap | 128/255 by default |

GPIO0 is an ESP32-S3 strapping pin. The ring must not be driven until after
boot, which is why `bsp_led_init()` is not part of `BSP_FEATURES_DEFAULT()`.

### Audio

| Signal | GPIO |
|---|---|
| I2S BCK | 3 |
| I2S LRCK (WS) | 45 |
| I2S DOUT → PCM5100A | 42 |
| PCM5100A XSMT (mute, active low) | 46 |
| Mic clock | 5 |
| Mic data | 4 |

The PCM5100A needs no I2C configuration and no MCLK — it recovers its clock
from BCK/LRCK.

### microSD — SDMMC 4-bit

| Signal | GPIO |
|---|---|
| CLK | 39 |
| CMD | 38 |
| D0–D3 | 40, 41, 48, 47 |

mount point `/sdcard`. `bsp_sdcard_mount()` falls back to 1-bit mode
automatically if 4-bit fails.

### Other

| Signal | GPIO |
|---|---|
| Battery ADC | 6 |

---

## Three things that are easy to get wrong

These three cost real time on this board — one contradicts the vendor demo, one
contradicts a published teardown, and one is a trap in LVGL itself.

### 1. There is no push button

`2-Program Example/Demo_arduino/ST77916_LVGL_DEMO/pincfg.h` contains:

```c
#define BTN_PIN 0
```

…twice, in fact. But `BTN_PIN` is **never referenced anywhere in the vendor
sources** — `scr_st77916.h` sets up the knob from `ROTARY_ENC_PIN_A/B` and
never mentions the button. It is dead code.

GPIO0 is the LED ring's data line. The schematic shows net `GPIO0` going to
FPC pin 6-5 (the lighting sub-board) through pull-up R11, and two independent
firmwares for this board agree:

* `kaspizzo/lamarzocco` — `LM_CTRL_LED_RING_GPIO GPIO_NUM_0`, `COUNT 13`
* `MichalZaniewicz/esphome-guition-jc3636k718c-va` — the ESPHome port uses
  GPIO0 for the addressable ring

Nothing else is left over for a switch either. **Design the UI to be fully
usable with rotation alone**, and let touch cover direct selection. In
particular, LVGL normally synthesises ENTER from the encoder's button, so
`LV_EVENT_CLICKED` never arrives from the knob — see
[SQUARELINE.md](SQUARELINE.md#there-is-no-push-button).

If you find a switch on a free GPIO on some revision, set
`Knob BSP → Encoder → Use a push button` and give its number.

GPIO19 and GPIO20 appear in the schematic as MCU-only nets that are not brought
out to any connector, so they are not usable either.

### 2. The encoder: two pulse lines, and the decoder must poll

This section has been wrong twice, and the wrong answers are kept here because
they are more instructive than the conclusion.

**The hardware, as finally measured.** Two switch contacts that rest open:

| State | Meaning |
|---|---|
| `A=1 B=1` | rest — the state it holds when untouched |
| `A=0 B=1` | A's contact closed |
| `A=1 B=0` | B's contact closed |
| `A=0 B=0` | both closed — **transient, sub-millisecond** |

Turning the knob one way closes A's contact; turning it the other way closes
B's. Direction is therefore encoded by *which line pulsed*, and one complete
pulse — the contact closing and opening again — is one detent.

**What the evidence does and does not support.** The `A=0 B=0` state exists (see
mistake 2) but is too brief for any of the probes below to sample reliably, and
that single fact invalidated two confident conclusions in a row. Treat any claim
here that rests on the *rate* of one transition relative to another as
unreliable, including this document's own earlier numbers. What is solid is the
per-line pulse count, because it is counted in the driver rather than sampled:

```
A 95 rising / 95 falling,  B 193 rising / 193 falling   (one 20 s turn)
```

Both lines move and both directions work. The exact ratio between them varies
between runs and is not worth interpreting.

**Mistake 1: "not quadrature", from a probe that could not see the answer.** A
1 kHz probe reported each line moving alone on ~97% of transitions and never
sampled `A=0 B=0`. That was written down as "two independent pulse lines". It is
an artifact of the sample rate: the probe cannot observe a state shorter than its
own period, so the both-closed step is invisible.

**Mistake 2: "ordinary quadrature", from over-reading the same trace.** The
sequence

```
(1,1) -> (0,1) -> (1,0) -> (1,1)
```

has no `(0,0)` in it, yet arriving at `(1,0)` from `(0,1)` requires both lines to
change — which cannot happen unless both contacts are briefly closed. That
reasoning was sound, and it correctly proved the both-closed state exists. The
error was the conclusion drawn from it: a 4×4 quadrature transition table was
installed, on the assumption that a detent is four transitions. It produced
**1 net step from 779 pulses**, and the knob stopped working entirely. The
hardware produces one pulse per detent, not a four-phase cycle, so even a correct
quadrature table would have counted four steps where one was wanted.

**Mistake 3: counting both edges of a pulse.** The next attempt derived direction
from the level pair at the moment a pulse completed — but at that moment the line
has just risen, so the "other line is low" test was false in every case. It
returned 0 for all 260 edges. A dead decoder, not an inverted one, and it took a
per-direction counter to tell those two apart.

**What actually worked: poll, and count one pulse.** A bounce burst on these
contacts lasts microseconds, and a level sampled every 1 ms cannot see it. The
decoder now samples both lines in a 1 kHz task, accepts a change only after it
has held for 1.5 ms, and emits one step when a pulse completes. The vendor's own
driver for this board polls the same way, for the same reason, and that was
visible from the start.

The verification is arithmetic rather than a judgement call: the steps must equal
the pulses. They do —

```
raw edges:          A 95 rising / 95 falling,  B 193 rising / 193 falling
steps by direction: 193 one way, -95 the other
```

— which is the check that finally distinguished a working decoder from the three
broken ones before it. `bsp_encoder_get_edges()` exposes those counts so it can
be re-run rather than believed.

**A note on the vendor driver.** The claim that the vendor drives this encoder
through `espressif/knob` (a quadrature decoder) does not survive contact with the
vendor's source: the demo ships `bidi_switch_knob.c`, a polling decoder that
counts one edge per line. `espressif/knob` remains out of this project.

**Direction is a convention, and it was got wrong twice.** Nothing in the
hardware says which rotation should increase a value. `ENC_SIGN_A`/`ENC_SIGN_B`
in `bsp_encoder.c` set it, and the correct setting was established by trying both
— it is A=−1, B=+1. Do not re-derive it from the trace; the trace cannot tell you
which way the user expects the value to move. `Knob BSP → Encoder → Swap rotation
direction` flips it without rebuilding.

### 3. Touch clears the knob's edit mode

This one is a trap, and it costs an afternoon if you do not know it is there.

LVGL only sends arrow keys to the focused widget while the input group is in
**edit mode**. Edit mode is normally toggled by pressing the encoder's button —
and this board has no button, so once it is off it can never be turned back on.

`lv_group_focus_obj()` in LVGL's core clears edit mode on **every** focus
change, not only when the focus actually moves:

```c
void lv_group_focus_obj(lv_obj_t * obj)
{
    ...
    //On defocus edit mode must be leaved
    lv_group_set_editing(g, false);
    ...
}
```

Touch drives that path: tapping anything click-focusable runs the pointer input
device through `indev_click_focus()` into `lv_group_focus_obj()`. Edit mode
drops to false, and the knob silently degrades from "change the value" to "move
focus between widgets" — which on a screen with one focusable widget means it
looks completely dead, permanently, until reboot.

Three things prevent it, and all are in place:

1. **Touch-only controls are marked not click-focusable** —
   `lv_obj_set_click_focusable(btn, false)`. They stay tappable but become
   invisible to the focus system, so a tap cannot move the focus at all. LVGL's
   own calendar arrows and keyboard use the same call.
2. **Edit mode is re-asserted on every focus change**, through the group's focus
   callback, which the core invokes immediately *after* clearing editing. This
   covers focus changes from any other source.
3. **The focus policy is enforced on every input read**, by
   `bsp_encoder_enforce_focus()`. See below.

`bsp_encoder_refocus()` repairs the focus on demand and
`bsp_encoder_is_driving()` reports whether the knob can currently reach the UI —
useful as an assertion after any code that changes the screen.

#### The focus policy

> One indicator on the screen → the knob always drives it, and a tap cannot take
> it away. Several indicators → a tap chooses which one the knob drives.

The two halves need opposite mechanisms, which is why this is not a single
setting:

* **One indicator is a prevention problem.** LVGL's `lv_group_focus_obj()`
  clears edit mode on *every* focus change — including one that focuses the
  object already focused — and touch reaches it through `indev_click_focus()`.
  With no push button, a cleared edit mode is permanent. So when there is exactly
  one focusable widget, the focus is pinned to it and edit mode is re-asserted on
  every input read.
* **Several indicators is the opposite.** The tap *must* move the focus, so the
  widgets stay click-focusable and the forced refocus is deliberately skipped.

The condition is therefore "is there exactly one candidate?" — no mode flag, and
a screen with two indicators simply gets stock LVGL behaviour, which is already
correct. Pages with a single arc get the pinned behaviour for free.

`bsp_encoder_enforce_focus()` returns `true` when it had to repair something, so
application code can assert the invariant after changing the screen instead of
discovering the problem on the next rotation. It logs once when edit mode had
been cleared, and once if a screen has widgets but nothing focusable is in the
group — the state where the knob looks dead until reboot.

#### The focus indicator

When there are several candidates the focused one gets a **ring**: a 3 px outline
in `#38E1FF` with an outward glow at 30% opacity, sized to the widget's own shape
(circle for the arc, rounded rectangle for others). It is an *outline*, not a
border, so adding and removing it cannot reflow the layout.

With a single candidate the ring is **absent**, which is the same rule expressed
on screen: if the knob can only drive one thing, saying so is decoration.

Two details that are easy to get wrong:

* **The ring must not be sticky.** A page change rebuilds the group and may leave
  the focus on an object that survives it, so no `LV_EVENT_FOCUSED` fires and a
  ring from the previous page stays visible. `ui_app_refresh_focus_group()`
  therefore *re-evaluates* the ring from the current candidate count instead of
  trusting an event — that was a real bug, and the symptom was a ring showing on
  a page with one control, where it should not appear at all.
* **The candidate count comes from one place.** `bsp_encoder_focusable_count()`
  is what both the focus policy and the ring key on, so they cannot disagree
  about what counts as a candidate.
* **The theme draws its own focus outline, on `LV_STATE_EDITED`.** LVGL's
  default theme outlines the focused widget in **red** — 2 px, `#F44336`
  (Material Red 500), 50% opacity. That is independent of anything this project
  draws, so a page with one control still showed a red frame even once the ring
  logic correctly declined to add anything. It looked exactly like the ring code
  was broken, and it was not.

  The state that carries it is **not** the one the theme's source first suggests.
  Dumping the *resolved* style per state gave:

  | Object state | Resolved outline |
  |---|---|
  | `0x28` FOCUSED\|EDITED | `w=2 #F44336` **red** |
  | `0x68` FOCUSED\|EDITED\|HOVERED | `w=2 #F44336` **red** |
  | `0x78` +FOCUS_KEY | `w=2 #F44336` **red** |
  | `0xF8` +PRESSED\+SCROLLED | `w=2 #F44336` **red** |
  | `0x08` FOCUSED | clear |
  | `0xC8` FOCUSED\|HOVERED\|PRESSED | clear |
  | `0xD8` FOCUSED\|PRESSED\|SCROLLED | clear |

  Every red state contains `LV_STATE_EDITED` (0x20) and no non-red state does.
  An encoder in edit mode sets `FOCUSED|EDITED`, which is the normal state of
  this UI — so the frame is visible almost always.

  The fix has to use a **local** style property:

  ```c
  lv_obj_set_local_style_prop(obj, LV_STYLE_OUTLINE_WIDTH,
                              (lv_style_value_t){ .num = 0 },
                              LV_PART_MAIN | LV_STATE_EDITED);
  ```

  Neither `lv_obj_add_style()` nor the `lv_obj_set_style_*` helpers work here,
  and the reason is worth remembering. They insert a **normal** style, and
  `lv_obj_add_style()` inserts normal styles at the *front* of the object's style
  list. `get_prop_core()` walks that list, skips any candidate whose state is not
  strictly greater than the best so far, and returns on an exact state match — so
  the style added **earliest** usually wins, and the theme's was added first, at
  widget creation. Anything the application adds afterwards is outranked. A local
  style is stored ahead of all normal styles and is consulted before them, so it
  wins outright.

  This took several wrong attempts precisely because it looks like it should just
  work, and because the state the theme actually decorates is not the state its
  source appears to target.

## The vibration motor is on the board and unused

The board carries a **DRV2605L** (U13, VSSOP-10) driving the LRA at I2C address
**`0x5A`**, on the same bus as the touch controller, with EN tied to 3V3 and
IN/TRIG tied to GND: the only way to drive it is an I2C register write. The
shipping firmware does not use it — the feedback in this instrument is the ring
and the screen, and the motor was removed once that was settled. The part is
still on the schematic, so nothing has to change for a board that keeps it.

---

## Panel revisions

Two revisions of the ST77916 are circulating. They are distinguishable by
reading register `0x04` over QSPI and comparing the response:

| Response | Variant |
|---|---|
| `00 7F 7F 7F` | standard — the driver's built-in sequence is correct |
| `00 02 7F 7F` | alternate — needs a different init sequence |

`esp_lcd_st77916` 2.x ships a sequence for 360×360 panels and it is expected to
work here. If it does not — snow, wrong geometry, a shifted image — enable
`Knob BSP → Display → Use the vendor LCD init sequence`. That sequence was
transcribed line by line from the vendor demo and matches the panel this board
ships with.

### Do not invert the colours

This panel is wired for inverted colour, and **both** the driver's built-in
sequence and the vendor sequence already end with `0x21` (INVON). Calling
`esp_lcd_panel_invert_color(panel, true)` on top produces a photographic
negative. The vendor Arduino demo calls `invertColor(true)` after init, which
is idempotent rather than additive — that is why it is safe there and a trap
here.

---

## Microphone: assumed PDM

Only two signals reach the microphone: clock (GPIO5) and data (GPIO4). A
conventional I2S MEMS microphone needs a third, word-select line, so the fitted
part is almost certainly **PDM** and the BSP drives it with the ESP32-S3 PDM RX
path.

If you identify the part and it turns out to be I2S, switch
`Knob BSP → Microphone` to I2S and set the word-select GPIO.

---

## Power budget

The ring, the backlight, the motor and the DAC all draw from the same rail.
Full white on 13 LEDs plus a bright backlight is enough to brown the board out
mid-frame. Hence `CONFIG_BSP_LED_BRIGHTNESS_LIMIT`, which caps every
`bsp_led_*` call at 128/255 by default. It stood at 96, which put the ring at
37% of what the LEDs can do with the RING setting at 100%; 128 raises that to
50% and is a third more light on the colours the instrument draws.

The ceiling was measured on hardware, with the instrument playing its own
patterns, the backlight lit and the RING setting at 100%, reading the supply
the board reports on its status line:

| Limit | Supply | Resets |
|---|---|---|
| 96  | 2221–2234 mV | none |
| 128 | 2213–2215 mV | none |
| 160 | 2154–2156 mV | none |

128 costs the rail ten millivolts and is what ships. 160 still stands but pulls
the supply down by sixty, a quarter more light for a cost that is growing faster
than the light is — the mark of a rail approaching its knee, which is why the
step after it is not recommended without a supply that can be watched.

If you raise it, do it in steps and watch for the display flickering or the
device resetting — both are symptoms of a sagging rail, not of a software bug.
