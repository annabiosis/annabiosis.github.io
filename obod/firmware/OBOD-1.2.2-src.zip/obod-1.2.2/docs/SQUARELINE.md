# SquareLine Studio → firmware

How to get a design out of SquareLine Studio and running on the knob, and the
handful of things that actually cost time.

---

## Version pairing (read this first)

The single most common failure is a **minor version mismatch** between the LVGL
that SquareLine exported against and the LVGL the firmware compiles. Symptoms
range from `undefined reference to lv_image_dsc_t` to a UI that builds and then
renders garbage.

| SquareLine Studio | Export targets available |
|---|---|
| 1.6.2 | 8.3.11, 9.1, 9.2.2, 9.3, **9.5** |
| 1.6.1 / 1.6.0 | 8.3.11, 9.1, 9.2.2, **9.3** |
| 1.5.1 | 9.2.2 |
| 1.4.1 | 9.1 |
| 1.4.0 | 8.3.11 |

This project pins **LVGL 9.4** (see `components/bsp_jc3636k718c/idf_component.yml`).
Set SquareLine's *Board properties → LVGL version* to the closest available at
or below that, and **re-export after any LVGL upgrade**. Never go the other way:
an export made against a newer LVGL will not compile against an older one.

To move the project's LVGL instead, edit the `lvgl/lvgl` constraint in
`components/bsp_jc3636k718c/idf_component.yml` and delete `dependencies.lock`.

---

## The loop

1. **Configure once.** *Project Settings → Export directory* →
   `<repo>/ui/export`. Set *LVGL version* per the table above.
2. **Design.**
3. **Export.** *File → Export → Export UI Files*.
4. **Sync.** VS Code task **`UI: Sync SquareLine export`**.
5. **Build and flash.** Task **`IDF: Build + Flash + Monitor`**.

Step 4 mirrors `ui/export/` into `components/ui/generated/`, replacing the
previous snapshot wholesale. Only that folder is touched.

---

## What the export contains

```
ui/export/
├── ui.c, ui.h              entry point: ui_init(); also ui_destroy() (1.5.2+)
├── ui_helpers.c/.h         internal helpers, generated
├── ui_events.c             skeletons for "Call function" actions
├── screens/
│   └── ui_<Screen>.c/.h    <screen>_screen_init()/_destroy(), per-screen events
├── components/
│   ├── ui_comp_<Name>.c/.h
│   └── ui_comp_hook.c      ← NOT overwritten on export
├── images/                 ui_img_*.c as C arrays by default
├── fonts/                  ui_font_*.c — subsets of the glyphs used
├── ui_theme_manager.c/.h   only when global colours/themes are used
├── ui_themes.c/.h
├── filelist.txt            newline-separated .c list
└── CMakeLists.txt          not used here; see below
```

`filelist.txt` is ignored by this project — the component globs `generated/*.c`
with `CONFIGURE_DEPENDS` instead, so new screens are picked up automatically.

Likewise the generated `CMakeLists.txt` is not wired in: it assumes the UI is a
subdirectory of the application via `add_subdirectory(ui)`, whereas here it is
a proper ESP-IDF component.

### Where to put your code

| Never edit | Edit freely |
|---|---|
| `ui.c`, `ui.h` | `components/ui/src/ui_app.c` |
| `screens/*` | `components/ui/generated/ui_comp_hook.c` |
| `components/ui_comp_*.c` | your own component |
| `ui_helpers.c` | |

Everything except `ui_comp_hook.c` is regenerated on every export.

For **Call function** actions, set *Project Settings → Call function export
file* to **`none`** and implement the functions yourself. Otherwise SquareLine
writes skeletons into `ui_events.c` and overwrites them on the next export —
which means either lost work or an unwanted empty stub silently replacing your
handler. Declaring the same `void my_handler(lv_event_t *e)` signature yourself
is enough; nothing generated has to know about it.

---

## `lv_conf.h` — do not use one

The `lvgl/lvgl` ESP-IDF component has a Kconfig option
**`LV_CONF_SKIP`** (LVGL → Build → *Skip lv_conf.h*), and it defaults to **on**.
Configuration comes from `CONFIG_LV_*` in menuconfig, not from a file.

SquareLine can generate an `lv_conf.h`. **Delete it.** If one exists anywhere on
the include path while `LV_CONF_SKIP=y`, you get confusing symptoms — a
half-applied configuration, a different default font, or widgets that are
compiled out despite appearing enabled.

If you genuinely need a file-based `lv_conf.h`, there must be exactly one on the
include path, and you must set `LV_CONF_SKIP=n`. The LVGL component adds
`-DLV_CONF_INCLUDE_SIMPLE` and searches one level above its own directory, so
`managed_components/lv_conf.h` is a natural place.

This project's settings live in `sdkconfig.defaults`.

---

## The knob does not work until widgets are in a group

This deserves its own section because it is the number one "the encoder is
broken" report, and it is never the encoder.

LVGL's encoder input device moves focus between objects in an `lv_group_t`.
SquareLine puts nothing in a group. So out of the box the knob rotates through
an empty group, focus never moves, and the UI looks dead.

`ui_app.c` fixes this by walking the active screen and adding widgets it
recognises. Check the boot log:

```
I (3980) ui: SquareLine UI ready, 4 focusable widget(s) on screen
```

**Zero means your widgets are not a class the bridge recognises.** Add them
explicitly:

```c
bsp_display_lock(0);
ui_app_add_focusable(ui_MyPanel);
bsp_display_unlock();
```

Also: use `ui_app_load_screen()` rather than `lv_screen_load()`. The former
rebuilds the group for the new screen; the latter leaves the knob focused on
widgets that no longer exist.

```c
ui_app_load_screen(ui_SettingsScreen, LV_SCR_LOAD_ANIM_MOVE_LEFT);
```

### Keeping a widget out of the group

A widget joins the group when it is one of the interactive classes **and** has
`LV_OBJ_FLAG_CLICKABLE` set. Clear the flag and the knob will rotate straight
past it — the idiomatic way to make a decorative arc or a read-only value
display skippable without touching the bridge:

```c
lv_obj_remove_flag(ui_GaugeArc, LV_OBJ_FLAG_CLICKABLE);
```

The reverse also works: `ui_app_add_focusable()` pulls in a widget the
class-based detection would have missed, and `ui_app_remove_focusable()` drops
one that SquareLine marked clickable but the user should never land on.

### There is no push button

The board has a rotary encoder with no switch contact wired to the MCU (see
[HARDWARE.md](HARDWARE.md)). LVGL normally synthesises ENTER from the encoder
button, so **`LV_EVENT_CLICKED` will never arrive from the knob**.

Two ways to confirm a selection:

```c
/* Tap the widget on the touch panel — works for free, since the widget is
   clickable and the touch indev is a pointer device. */

/* Or trigger it from your own logic: */
lv_group_t *g = ui_app_get_group();
lv_group_send_data(g, LV_KEY_ENTER);
```

If you want the knob only to set a value — a volume or brightness — and never
to navigate, skip the group entirely and drive the widget directly:

```c
bsp_display_lock(0);
lv_arc_set_value(ui_VolumeArc, volume);
bsp_display_unlock();
```

---

## Focus feedback

`ui_app.c` draws a focus outline automatically. It uses `outline`, not
`border`, deliberately: an outline does not change the widget's size, so adding
and removing it cannot reflow the layout. On a 360 px round screen with tight
spacing that is the difference between a stable UI and one that jitters on
every detent.

To use your own indicator:

```c
static lv_style_t focus_style;
lv_style_init(&focus_style);
lv_style_set_outline_width(&focus_style, 4);
lv_style_set_outline_color(&focus_style, lv_color_hex(0xFF6B00));

void my_ui_start(void) {
    ui_app_set_focus_style(&focus_style);
}
```

Call it after `ui_app_init()`. Pass `NULL` to remove the indicator entirely. To
disable the built-in one, set `.default_focus_style = false` in the config.

---

## Thread safety

LVGL is not thread safe. Anything that touches a widget — including from a
Wi-Fi or audio task — must hold the lock:

```c
if (bsp_display_lock(0)) {
    lv_label_set_text(ui_StatusLabel, "online");
    bsp_display_unlock();
}
```

Rules that matter in practice:

* do **not** call `bsp_display_lock()` from inside an LVGL event callback —
  callbacks already run in the LVGL task and taking the lock again deadlocks;
* `ui_app_load_screen()`, `ui_app_refresh_focus_group()` and the
  `ui_app_*_focusable()` helpers must be called under the lock;
  `bsp_display_rotation_set()` takes it internally, so do not hold it when
  calling that;
* from a non-LVGL task, `lv_async_call()` is the cheap way to hop onto the LVGL
  task without blocking.

`bsp_display_lock(0)` waits indefinitely. Use a finite timeout when a deadlock
would be worse than a dropped update.

---

## Widgets and fonts that come out missing

### `undefined reference to lv_chart_create`

The widget is compiled out of LVGL. Enable it in
**`IDF: Menuconfig → Component config → LVGL → Widgets`**, or add the
`CONFIG_LV_USE_*` line to `sdkconfig.defaults` so everyone gets it.

Widgets most often needed by a SquareLine design:

```
CONFIG_LV_USE_ARC, BAR, BUTTON, BUTTONMATRIX, CHECKBOX, DROPDOWN, IMAGEBUTTON,
KEYBOARD, LABEL, LED, LINE, LIST, MSGBOX, ROLLER, SCALE, SLIDER, SPAN, SPINBOX,
SPINNER, SWITCH, TABLE, TABVIEW, TEXTAREA, TILEVIEW, WIN, CHART, CALENDAR,
ANIMIMG, QRCODE
CONFIG_LV_USE_FLEX, CONFIG_LV_USE_GRID      (layout containers)
CONFIG_LV_USE_THEME_DEFAULT                 (the default theme)
```

For images loaded from a filesystem rather than as C arrays, you also need
`CONFIG_LV_USE_FS_*` plus a decoder (`CONFIG_LV_USE_LODEPNG` or
`CONFIG_LV_USE_LIBPNG`).

`sdkconfig.defaults` already enables flex, grid, qrcode, snapshot and three
Montserrat sizes.

### Text shows as boxes (tofu)

SquareLine generates **subsets**: only the glyphs used in the design. Any string
produced at runtime — a clock, `"%d"`, a sensor name, Cyrillic — will be
missing.

Three fixes, in order of preference:

1. add the characters or a character range in SquareLine's **Font manager** and
   re-export (keeps the subset small);
2. use a built-in Montserrat for that label
   (`CONFIG_LV_FONT_MONTSERRAT_*`, then `lv_obj_set_style_text_font()`);
3. widen `LV_FONT_DEFAULT`.

Also confirm the font SquareLine writes as the default actually exists in your
build — with `LV_CONF_SKIP=y` the file-based default is ignored and you fall
back to LVGL's, which is easy to mistake for a rendering bug.

### Images

Leave *Image export mode* at its default: images become C arrays
(`ui_img_*.c`), which need no filesystem and no decoder. Switch to `fsdrv` only
if the flash cost matters, and remember that it requires copying the generated
`drive/assets` folder onto the device — see [../assets/README.md](../assets/README.md).

---

## Round screen specifics

SquareLine can mark the board as round, but it does not generate a mask. If your
screen background is opaque and fills the panel, the corners of the square
framebuffer are simply not visible behind the bezel. If it is not:

```c
lv_obj_set_style_radius(lv_screen_active(), LV_RADIUS_CIRCLE, 0);
lv_obj_set_style_clip_corner(lv_screen_active(), true, 0);
```

Keep interactive content inside roughly 300 px of the 360 px width — anything
touching the edge is awkward to reach and partially hidden by the case.

---

## Performance

The combination that works on this board:

| Setting | Value | Where |
|---|---|---|
| Draw buffers | PSRAM, double buffered, 60 lines | `Knob BSP → Display` |
| Colour depth | 16-bit | `CONFIG_LV_COLOR_DEPTH_16` |
| Refresh period | 10 ms | `CONFIG_LV_DEF_REFR_PERIOD` |
| Fast memory in IRAM | on | `CONFIG_LV_ATTRIBUTE_FAST_MEM_USE_IRAM` |
| CPU | 240 MHz | `CONFIG_ESP_DEFAULT_CPU_FREQ_MHZ_240` |
| Optimisation | `-O2` | `CONFIG_COMPILER_OPTIMIZATION_PERF` |

An on-screen performance monitor is genuinely useful while designing:

```
IDF: Menuconfig → Component config → LVGL → Others → Show performance monitor
```

**Turn it off for release.** It draws over your UI and costs CPU every frame.

Full-screen repaints (a rotating image, an animated radial spectrum on the whole
360×360) will visibly lag on this hardware — the QSPI panel bus is the ceiling,
not the CPU. Prefer partial updates and small animated regions.

---

## Reference

* [SquareLine changelog](https://docs.squareline.io/docs/miscellanos/changelog/)
* [SquareLine typical workflow](https://docs.squareline.io/docs/introduction/typical_dev/)
* [SquareLine project settings](https://docs.squareline.io/docs/1.6.1/dev_env/project_settings/)
* [SquareLine events](https://docs.squareline.io/docs/events/)
* [LVGL ESP-IDF integration](https://lvgl.io/docs/open/9.4/details/integration/chip_vendors/espressif/add_lvgl_to_esp32_idf_project)
