"""Generates the signal-chain diagram into two places from one source.

Sources of truth:

    obod-signal-chain.mmd    текст схемы, единственный источник

Generated:

    obod-signal-chain.html   отдельная страница со схемой
    ../../web/under.html     блок схемы между маркерами BEGIN/END signal diagram

Run this script after editing the .mmd:

    python docs/signal-chain/gen_html.py

Both places embed the diagram text instead of loading it: the pages are opened
over file://, and in that mode the browser refuses to fetch a neighbouring file.

Both places use the local copy vendor/mermaid.min.js and have no external
address, so they render without network access.

Zoom and pan are written here rather than taken from a library: the pages must
stay self-contained, and a few dozen lines do the whole job. The wheel scales
around the pointer, dragging moves the drawing, a double click or the reset
button returns to the whole diagram.

The diagram block lives on the documentation page «Под капотом» (web/under.html).
That page carries its own copy of the diagram so that it does not need an
iframe: an iframe meant a second frame around the drawing and a guessed height
under it. The block between the markers is rewritten on every run of this
script, so do not edit it by hand: edit the .mmd instead.

The old single promo page is gone: the block is written to web/under.html only.
"""
import html
import os

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
MMD = os.path.join(HERE, "obod-signal-chain.mmd")
OUT = os.path.join(HERE, "obod-signal-chain.html")
PAGE = os.path.join(ROOT, "web", "under.html")
DIAGRAM_BEGIN = "<!-- BEGIN signal diagram -->"
DIAGRAM_END = "<!-- END signal diagram -->"
MERMAID = "vendor/mermaid.min.js"
PAGE_MERMAID = "../docs/signal-chain/vendor/mermaid.min.js"

# Оформление сцены. Имена классов начинаются с .signal, чтобы правила не
# задевали ничего на промо-странице, у которой своя вёрстка.
CSS = """  .signal .bar {
    display: flex;
    align-items: center;
    gap: 8px;
    margin: 0 0 12px;
  }

  .signal .bar .hint {
    margin: 0 0 0 4px;
    color: var(--grey40);
    font-size: 13px;
  }

  .signal .bar button {
    width: 34px;
    height: 34px;
    padding: 0;
    color: var(--text);
    font: inherit;
    font-size: 17px;
    line-height: 1;
    background: rgba(255,255,255,.06);
    border: 1px solid var(--border);
    border-radius: 10px;
    cursor: pointer;
  }

  .signal .bar button:hover { background: rgba(255,255,255,.12); }
  .signal .bar button:active { transform: translateY(1px); }
  .signal .bar button.wide { width: auto; padding: 0 12px; font-size: 14px; }

  /* Сцена держит рисунок и обрезает его, когда тот увеличен. */
  .signal .stage {
    position: relative;
    min-height: 200px;
    overflow: hidden;
    touch-action: none;
    cursor: grab;
  }

  .signal .stage.dragging { cursor: grabbing; }

  .signal .stage .mermaid {
    display: block;
    margin: 0;
    background: transparent;
  }

  /* Ширина по сцене, высота по пропорции: рисунок заполняет блок. */
  .signal .stage svg {
    display: block;
    max-width: 100% !important;
    height: auto !important;
    transform-origin: 0 0;
  }

  /* Развёрнутый вид: блок накрывает окно страницы, сцена забирает остаток
     высоты, рисунок подгоняется сразу при развороте. Это не полноэкранный
     режим браузера, а разворот внутри самой страницы. */
  .signal.expanded {
    position: fixed;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    z-index: 9999;
    display: flex;
    flex-direction: column;
    padding: 16px;
    background: var(--bg, #000);
  }

  .signal.expanded .stage {
    flex: 1 1 auto;
    min-height: 0;
  }

  .signal.expanded .stage svg {
    max-height: 100%;
  }
"""

# Разметка сцены. Одна на обе страницы: на каждой схеме ровно одна, поэтому
# одинаковые идентификаторы не пересекаются.
MARKUP = """<div class="signal">
  <p class="fallback" id="fallback" hidden>Схема не отрисовалась: библиотека
    mermaid.min.js не загрузилась или текст схемы не разобран. Текст схемы лежит
    ниже, в блоке с исходником.</p>

  <div class="bar">
    <button type="button" id="zoom-out" aria-label="Уменьшить" title="Уменьшить">&#8722;</button>
    <button type="button" id="zoom-in" aria-label="Увеличить" title="Увеличить">+</button>
    <button type="button" id="zoom-reset" class="wide" title="Показать схему целиком">Сброс</button>
    <button type="button" id="zoom-full" class="wide" title="Развернуть схему на всё окно">Развернуть</button>
    <p class="hint">Колесо мыши — масштаб, перетаскивание — сдвиг, двойной щелчок — показать целиком.</p>
  </div>

  <div class="stage" id="stage">
<pre class="mermaid">
@@MMD@@</pre>
  </div>
</div>
"""

# Настройка рисования и управление масштабом и сдвигом. Одинаково на обеих
# страницах: разница только в том, откуда приходит библиотека.
JS = """mermaid.initialize({
  startOnLoad: false,
  securityLevel: 'strict',
  theme: 'dark',
  fontFamily: '"IBM Plex Sans", ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif',
  flowchart: { curve: 'basis', useMaxWidth: true, htmlLabels: true },
  themeVariables: {
    darkMode: true,
    background: '#000000',
    primaryColor: '#011b1c',
    primaryTextColor: '#ffffff',
    primaryBorderColor: '#0C7970',
    lineColor: '#30DA98',
    textColor: '#ffffff',
    fontSize: '14px'
  }
});

(function () {
  var MIN_SCALE = 0.5;
  var MAX_SCALE = 6;
  var STEP = 1.25;

  function fail() {
    var el = document.getElementById('fallback');
    if (el) { el.hidden = false; }
  }

  function setupPanZoom() {
    var stage = document.getElementById('stage');
    var svg = stage ? stage.querySelector('svg') : null;
    if (!stage || !svg) { return; }

    var scale = 1, tx = 0, ty = 0, drag = null;

    function clamp(s) { return Math.min(MAX_SCALE, Math.max(MIN_SCALE, s)); }

    function apply() {
      svg.style.transform = 'translate(' + tx + 'px,' + ty + 'px) scale(' + scale + ')';
    }

    function reset() {
      scale = 1;
      tx = 0;
      ty = 0;
      apply();
    }

    /* Показать рисунок целиком: сперва вернуть исходный вид, затем измерить его
       и, если он не помещается в сцену, уменьшить и поставить по центру. */
    function fit() {
      reset();
      var r = stage.getBoundingClientRect();
      var b = svg.getBoundingClientRect();
      if (!r.width || !r.height || !b.width || !b.height) { return; }
      var k = clamp(Math.min(r.width / b.width, r.height / b.height, 1));
      scale = k;
      tx = (r.width - b.width * k) / 2;
      ty = (r.height - b.height * k) / 2;
      apply();
    }

    function zoomAt(clientX, clientY, factor) {
      var r = stage.getBoundingClientRect();
      var px = clientX - r.left;
      var py = clientY - r.top;
      var next = clamp(scale * factor);
      if (next === scale) { return; }
      var k = next / scale;
      tx = px - k * (px - tx);
      ty = py - k * (py - ty);
      scale = next;
      apply();
    }

    function zoomCenter(factor) {
      var r = stage.getBoundingClientRect();
      zoomAt(r.left + r.width / 2, r.top + r.height / 2, factor);
    }

    stage.addEventListener('wheel', function (e) {
      e.preventDefault();
      zoomAt(e.clientX, e.clientY, e.deltaY < 0 ? 1.15 : 1 / 1.15);
    }, { passive: false });

    stage.addEventListener('pointerdown', function (e) {
      if (e.button !== 0) { return; }
      drag = { x: e.clientX, y: e.clientY, tx: tx, ty: ty };
      stage.classList.add('dragging');
      try { stage.setPointerCapture(e.pointerId); } catch (err) { }
      e.preventDefault();
    });

    stage.addEventListener('pointermove', function (e) {
      if (!drag) { return; }
      tx = drag.tx + (e.clientX - drag.x);
      ty = drag.ty + (e.clientY - drag.y);
      apply();
    });

    function endDrag(e) {
      if (!drag) { return; }
      drag = null;
      stage.classList.remove('dragging');
      try { stage.releasePointerCapture(e.pointerId); } catch (err) { }
    }

    stage.addEventListener('pointerup', endDrag);
    stage.addEventListener('pointercancel', endDrag);

    stage.addEventListener('dblclick', fit);

    var zin = document.getElementById('zoom-in');
    var zout = document.getElementById('zoom-out');
    var zres = document.getElementById('zoom-reset');
    var zfull = document.getElementById('zoom-full');
    if (zin) { zin.addEventListener('click', function () { zoomCenter(STEP); }); }
    if (zout) { zout.addEventListener('click', function () { zoomCenter(1 / STEP); }); }
    if (zres) { zres.addEventListener('click', fit); }

    var wrap = stage.closest ? stage.closest('.signal') : null;
    var expanded = false;

    /* Разворот внутри страницы: блок накрывает окно, прокрутка страницы под ним
       выключается, выход по кнопке или по Esc. */
    function setExpanded(on) {
      if (!wrap) { return; }
      expanded = on;
      if (on) { wrap.classList.add('expanded'); } else { wrap.classList.remove('expanded'); }
      if (zfull) { zfull.textContent = on ? 'Свернуть' : 'Развернуть'; }
      if (document.body) { document.body.style.overflow = on ? 'hidden' : ''; }
      /* Раскладка после смены режима успевает измениться не сразу. */
      setTimeout(fit, 60);
    }

    if (zfull) {
      zfull.addEventListener('click', function () { setExpanded(!expanded); });
    }

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && expanded) { setExpanded(false); }
    });

    fit();
  }

  function run() {
    var done = mermaid.run({ querySelector: '.mermaid' });
    if (done && typeof done.then === 'function') {
      done.then(setupPanZoom).catch(fail);
    } else {
      setupPanZoom();
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', run);
  } else {
    run();
  }
})();
"""

PAGE_TEMPLATE = """<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>OBOD — путь сигнала</title>
<!--
  Источник схемы — obod-signal-chain.mmd. Его текст вставлен в блок
  <pre class="mermaid"> ниже при генерации: страница открывается по file://, а в
  этом режиме браузер не даёт читать соседний файл запросом. При правке .mmd
  страницу надо перегенерировать:

      python docs/signal-chain/gen_html.py

  Та же схема, тем же текстом, вставлена в web/under.html между маркерами
  BEGIN/END signal diagram: отдельного айфрейма для неё больше нет.

  Рисует локальная копия vendor/mermaid.min.js (mermaid 11.17.2, лицензия MIT).
  Внешних адресов у страницы нет, поэтому она работает без интернета.
-->
<style>
  :root {
    --bg:       #000;
    --panel:    #011b1c;
    --text:     #fff;
    --grey40:   rgba(255,255,255,.4);
    --green400: #71FEAB;
    --border:   rgba(255,255,255,.2);
    --radius:   24px;
    --sans: "IBM Plex Sans", ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
  }

  * { box-sizing: border-box; }

  html, body {
    margin: 0;
    background: var(--bg);
    color: var(--text);
    font-family: var(--sans);
    font-weight: 300;
    font-size: 16px;
    line-height: 1.6;
  }

  body { padding: 16px; }

  .wrap {
    max-width: 1400px;
    margin: 0 auto;
    padding: 14px 20px 18px;
    background: var(--panel);
    border: 1px solid var(--border);
    border-radius: var(--radius);
  }

@@CSS@@
  .fallback {
    margin: 0 0 12px;
    color: var(--grey40);
    font-size: 13px;
  }

  .fallback[hidden] { display: none; }

  a { color: var(--green400); }
</style>
</head>

<body>

<div class="wrap">
@@MARKUP@@</div>

<script src="@@MERMAID@@"></script>
<script>
@@JS@@</script>

</body>
</html>
"""


def render_markup(mmd):
    return MARKUP.replace("@@MMD@@", html.escape(mmd, quote=False))


def main():
    with open(MMD, encoding="utf-8") as f:
        mmd = f.read()

    page = (PAGE_TEMPLATE
            .replace("@@CSS@@", CSS.rstrip("\n"))
            .replace("@@MARKUP@@", render_markup(mmd))
            .replace("@@MERMAID@@", MERMAID)
            .replace("@@JS@@", JS))
    with open(OUT, "w", encoding="utf-8", newline="\n") as f:
        f.write(page)
    print("wrote %s (%d bytes of diagram text)" % (OUT, len(mmd)))

    with open(PAGE, encoding="utf-8") as f:
        page_html = f.read()
    begin = page_html.find(DIAGRAM_BEGIN)
    end = page_html.find(DIAGRAM_END)
    if begin < 0 or end < 0 or end < begin:
        raise SystemExit("в %s нет маркеров %s / %s" % (PAGE, DIAGRAM_BEGIN, DIAGRAM_END))

    head = page_html[:begin + len(DIAGRAM_BEGIN)]
    tail = page_html[end:]
    block = [
        "",
        "<style>",
        CSS.rstrip("\n"),
        "</style>",
        "",
        render_markup(mmd).rstrip("\n"),
        "",
        '<script src="%s"></script>' % PAGE_MERMAID,
        "<script>",
        JS.rstrip("\n"),
        "</script>",
        "",
    ]
    with open(PAGE, "w", encoding="utf-8", newline="\n") as f:
        f.write(head + "\n".join(block) + tail)
    print("wrote %s (diagram block between the markers)" % PAGE)


if __name__ == "__main__":
    main()
