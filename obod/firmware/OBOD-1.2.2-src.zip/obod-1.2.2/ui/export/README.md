# SquareLine Studio export folder

Point SquareLine Studio's **Project Settings → Export directory** here.

```
File → Project Settings → Export directory → <this repo>/ui/export
File → Export → Export UI Files
```

Then run the VS Code task **`UI: Sync SquareLine export`** (or
`tools/squareline_sync.ps1`), which mirrors the export into
`components/ui/generated/` and rebuilds the focus group on the next flash.

## Why this folder is git-ignored

The design source of truth is the `.spj` project and whatever Studio keeps
beside it. What the *firmware* needs is the exported C code, and that is
committed separately under `components/ui/generated/`. Keeping the two apart
means:

* a fresh clone builds without SquareLine Studio installed;
* re-exporting into a different folder, or mid-edit, cannot break the build;
* `git log` on `components/ui/generated/` shows exactly when the UI changed.

See [docs/SQUARELINE.md](../../docs/SQUARELINE.md) for the settings the export
needs, and for why widgets do not respond to the knob until they are in the
input group.
