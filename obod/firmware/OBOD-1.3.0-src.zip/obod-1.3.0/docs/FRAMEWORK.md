> Примечание. Это прежний главный документ проекта: он писался, когда репозиторий
> был заготовкой под BSP-фреймворк. Текст сохранён на английском как есть — он
> остаётся справочником по плате, по порядку инициализации и по работе с
> SquareLine Studio. Описание самого инструмента OBOD — в
> [../README.md](../README.md).
>
> Поправлены только пути: ссылки на документы в этой папке и на `tools/` пересчитаны
> под новое положение файла. Всё остальное — дословно, включая раздел о снятии
> кнопки энкодера из первоначального задания.
>
> Требования ниже устарели: документ называет ESP-IDF 5.4, тогда как проект собирается
> на 6.1, а сборка в CI идёт на 6.0 и 6.1. Актуальные требования — в
> [../README.md](../README.md).

# Guition JC3636K718C — firmware framework

A working starting point for the **1.85" round knob screen** (ESP32-S3R8,
360×360 IPS, rotary encoder), built for **VS Code** and **SquareLine Studio**.

The board support package hides every pin and every bring-up ordering rule, so
application code is just: *start the board, hand the UI to SquareLine, react to
events.* UI work happens in SquareLine Studio; firmware work happens in VS Code.

```
┌──────────────────────────────────────────────────────────────┐
│  SquareLine Studio  ──export──▶  components/ui/generated/    │
│         (design)                        (compiled in)        │
└──────────────────────────────────────────────────────────────┘
                    ▲                        │
                    │ ui_init()              │ LVGL events
                    │                        ▼
┌──────────────────────────────────────────────────────────────┐
│  components/ui/src/ui_app.c   ← encoder group, focus style │
├──────────────────────────────────────────────────────────────┤
│  components/bsp_jc3636k718c   ← display, touch, knob, audio… │
├──────────────────────────────────────────────────────────────┤
│  components/app_net           ← provisioning + OTA (off)     │
└──────────────────────────────────────────────────────────────┘
```

---

## Hardware

| Block | Part | Interface | Pins |
|---|---|---|---|
| MCU | ESP32-S3R8 | — | 16 MB QIO flash, 8 MB Octal PSRAM |
| Display | ST77916, 360×360 | **QSPI** | CS 12, SCK 11, D0–D3 13/14/15/16, RST 17, BL 21 |
| Touch | CST816S | I2C 0x15 | SDA 9, SCL 10, INT 7, RST 8 |
| LED ring | WS2812 ×13 | RMT | data GPIO0 |
| Knob | rotary encoder | GPIO | A 2, B 1 |
| Audio out | PCM5100A | I2S | BCK 3, LRCK 45, DOUT 42, MUTE 46 |
| Audio in | PDM MEMS mic | I2S/PDM | CLK 5, DATA 4 |
| Storage | microSD | SDMMC 4-bit | CLK 39, CMD 38, D0–D3 40/41/48/47 |

Two surprises worth knowing before you write code — both documented in
[HARDWARE.md](HARDWARE.md) with the evidence:

* **There is no push button.** The vendor demo's `pincfg.h` defines `BTN_PIN 0`,
  but that macro is never referenced and GPIO0 is the LED ring's data line.
  Design your UI to work with rotation alone.
* **The vibration motor is I2C, not a GPIO.** A DRV2605L drives the LRA at 0x5A
  on the touch bus, and the shipping firmware does not use it: the feedback in
  this instrument is the ring and the screen.

---

## Requirements

| Tool | Version | Notes |
|---|---|---|
| ESP-IDF | **≥ 5.4** | `esp_lcd_st77916` 2.x needs it for QSPI |
| VS Code | any recent | with the ESP-IDF extension |
| SquareLine Studio | 1.6.x, exporting **LVGL 9** | optional until you design a UI |
| Python | ≥ 3.9 | installed by the ESP-IDF installer |

---

## Quick start

### 1. Install ESP-IDF 5.4 or newer

```powershell
mkdir $HOME\esp; cd $HOME\esp
git clone -b v5.4 --recursive https://github.com/espressif/esp-idf.git
cd esp-idf
.\install.ps1 esp32s3
```

On Linux/macOS, use `install.sh` instead — this is the
[official procedure](https://docs.espressif.com/projects/esp-idf/en/v5.4/esp32s3/get-started/).

### 2. Point the project at it

The build scripts find ESP-IDF automatically if it is in a standard location.
Otherwise, create `.idf-env.json` in the repository root (it is git-ignored):

```json
{ "idfPath": "C:\\esp\\v5.4\\esp-idf" }
```

### 3. Build and flash

Open the folder in VS Code (`Ctrl+Shift+B` builds), or from a terminal:

```powershell
pwsh -File tools/idf.ps1 build
pwsh -File tools/idf.ps1 -p COM7 flash monitor
```

The VS Code task **`IDF: Build + Flash + Monitor`** does the whole loop and
asks for the serial port the first time.

If esptool cannot connect, the board may not be in download mode. This is the
ROM bootloader built into the ESP32-S3: it accepts an image over the serial
port regardless of what is in flash. Normally esptool, and the browser page
that speaks the same protocol, enter this mode automatically by toggling DTR
and RTS on the USB-UART bridge or through the USB-Serial/JTAG reset sequence,
but that path depends on the board and the port. On a first flash, after an
erased or crashed image, or over the native USB-Serial/JTAG port, where there
are no DTR/RTS lines, the automatic reset may not work: the chip boots
normally and the write never starts. In the esptool log the chip stays silent
or answers in the wrong mode.

To enter download mode by hand, hold **BOOT** (GPIO0, the strapping pin
sampled at reset), connect the cable or press **RESET**, wait for the port to
appear, then release **BOOT**. After flashing, press **RESET** or power-cycle:
with USB-Serial/JTAG a core reset does not re-sample the strapping pin, so the
chip would otherwise stay in download mode. GPIO0 is also the LED ring's data
line, so the ring may behave oddly while BOOT is held; the pin is sampled only
at reset, so this does not affect flashing. BOOT and RESET are the board's
service buttons for the chip, not a button on the encoder — the encoder has
none.

### 4. Expected first boot

```
I (312) bsp: ST77916 360x360 ready: QSPI 40 MHz, 60-line double buffer in PSRAM
I (324) bsp: init sequence: driver default
I (298) bsp.touch: CST816S ready at 100 kHz (INT 7, RST 8)
I (402) bsp.encoder: encoder ready (polling decoder, A=2 / B=1, 1 ms period, direction normal)
I (3980) ui: SquareLine UI ready, 4 focusable widget(s) on screen
I (3990) app: boot complete
```

You should see the placeholder UI: an arc whose value follows the knob, and a
Settings screen reachable by tapping the on-screen button.

---

## Repository layout

```
.
├── components/
│   ├── bsp_jc3636k718c/      Board support: display, touch, knob, audio, SD,
│   │                         LED ring.  No app needs a raw GPIO.
│   ├── ui/                   SquareLine integration
│   │   ├── include/ui_app.h  The bridge API
│   │   ├── src/ui_app.c      Encoder group, focus ring
│   │   └── generated/        ← SquareLine writes here. Disposable.
│   └── app_net/              Provisioning + OTA with rollback, not started
├── main/main.c               Example application — deliberately thin
├── ui/export/                Drop your SquareLine export here (git-ignored)
├── tools/                    idf.ps1/sh, squareline_sync.ps1/sh, upload_fs.ps1/sh
├── docs/                     HARDWARE, SQUARELINE, VSCODE, TROUBLESHOOTING
├── assets/                   Files packed into the on-board SPIFFS partition
├── .github/workflows/        Builds the tree on push (IDF 5.4 and 5.5)
├── sdkconfig.defaults        Board defaults; applied on a fresh build
└── partitions.csv            16 MB layout: two 4 MB OTA slots, 7 MB SPIFFS + 64 KB coredump
```

---

## The SquareLine workflow

The design loop is three steps:

1. **Design** in SquareLine Studio.
   Set *Project Settings → Export directory* to this repository's `ui/export/`,
   and set the LVGL version to **9**.

2. **Export** — *File → Export → Export UI Files*.

3. **Sync and build** — run the VS Code task **`UI: Sync SquareLine export`**,
   then build.

`tools/squareline_sync.ps1` copies the export into `components/ui/generated/`,
replacing the previous snapshot. Only that folder is touched; the bridge in
`src/ui_app.c` and everything else survives.

**Why copy instead of building straight out of the export folder?** So the
firmware keeps building from a known-good snapshot when Studio is closed or
mid-edit, and so the export can live outside the repository. Generated output
is committed on purpose: a fresh clone builds without Studio installed.

[SQUARELINE.md](SQUARELINE.md) covers the details that actually cost
time: which `lv_conf.h` settings the export needs, why widgets do not respond
to the knob, and how to add your own event handlers next to generated ones.

---

## The knob, in one paragraph

SquareLine does not put anything into an LVGL input group — so out of the box,
the knob rotates through an empty group and the UI looks dead. `ui_app.c` walks
the active screen, finds widgets by class, and adds them to the group. It marks
the focused control with a ring (an outline, not a border, so the layout cannot
jitter) — but only when the screen has more than one control, because with one
control there is nothing to disambiguate — and buzzes the motor on focus changes.
Call `ui_app_load_screen()` instead of `lv_screen_load()` and the group is
rebuilt for you.

---

## Common tasks

| Task | VS Code command palette → *Tasks: Run Task* |
|---|---|
| Build | `IDF: Build` |
| Build, flash, monitor | `IDF: Build + Flash + Monitor` |
| Erase everything (incl. Wi-Fi credentials) | `IDF: Erase flash` |
| Change board options (brightness, LED ring, mic type) | `IDF: Menuconfig` |
| See what is using flash | `IDF: Size` |
| Push assets to SPIFFS without reflashing | `FS: Upload assets to SPIFFS` |
| Re-export UI | `UI: Sync SquareLine export` |

---

## Network and updates

**The instrument has no network.** `app_main` does not call `app_net_init()`, so
the Wi-Fi stack is never initialised and no SoftAP is raised — not on a first
boot either. Firmware is written over the wire: the browser page in
`tools/webflash`, or `idf.py flash`.

`components/app_net` is still in the tree and still builds. It holds the
provisioning code (`app_net_reset_provisioning()` and the rest) and the
OTA-with-rollback code, and `app_ota_mark_valid()` is still called at boot, so an
image written over the wire into an OTA slot still has its rollback cancelled.
To bring the network back, set `APP_NET_BRINGUP` to 1 in `main/main.c`: that is
the only change needed, and the boot then does exactly what it used to, ring
indication included.

For development, `IDF: Menuconfig → Knob network services` can compile in static
credentials and skip provisioning entirely. That path sits behind the same
switch now; do not ship such a build either way, the password ends up in the
binary.

---

## MIDI input

The instrument enumerates as a USB-MIDI device, so the computer sees one port
named **OBOD MIDI IN**.

* Notes are read by channel: **channel 1** drives the lead, **channel 2** the
  percussion. Channels 3 to 16 are discarded. The lead is three-voice
  polyphonic; a fourth note takes the voice of the oldest one.
* Lead notes are quantised to the scale selected on the **SCALE** page before they
  sound. The **CHROMATIC** scale passes notes through unchanged.
* Real-time transport is accepted: `0xFA` starts the transport and returns the
  sequencers to the top of the phrase, `0xFB` continues without resetting the
  position, `0xFC` stops. Stop follows the rule the instrument already has — the
  sequencers and the percussion open no notes, and held MIDI notes keep
  sounding, including the arpeggiator running over them.
* Clock is accepted: `0xF8`, 24 ticks per quarter note. While ticks arrive, that
  tempo replaces the knob value for the two euclidean sequencers, the
  arpeggiator and the modulation generator. The patch parameter is not
  rewritten, so a tempo from the wire never reaches a preset, and about a second
  without ticks hands the tempo back to the knob. The transport screen mirrors
  the tempo actually in use: the arc and the BPM label show the clock tempo.
* What is accepted and what is dropped: note on and note off with velocity, where
  a note on at velocity zero counts as a note off, as does a note off at any
  velocity, plus four real-time bytes — `0xF8`, `0xFA`, `0xFB` and `0xFC`.
  Everything else is recognised and dropped: control change, pitch bend, program
  change, aftertouch, the system common messages, SysEx, and notes on channels 3
  to 16. No control change has any effect, so CC 123 (all notes off) does not
  release notes and there is no MIDI way to release them all.
* No settings and no patch parameters were added for this. Receive works while
  **MIDI IN** is on — the setting on the **OPTIONS** page, off by default.

Worth knowing before you turn it on: the ESP32-S3 has a single USB controller,
so while note receive is on the instrument holds it as a MIDI device and the
debug COM port does not appear on the cable. To get the port back, turn note
receive off and reboot the instrument. The same warning is in
[../tools/webflash/README.md](../tools/webflash/README.md).

---

## Debugging

The ESP32-S3 has a USB-Serial-JTAG bridge on chip, so breakpoints need no
external probe: connect the **native USB** port (not the CH340 one) and use the
`ESP-IDF: Debug (built-in USB-JTAG)` configuration in Run and Debug.
See [VSCODE.md](VSCODE.md).

---

## Troubleshooting

| Symptom | Likely cause |
|---|---|
| Screen stays dark | `CONFIG_BSP_LCD_USE_VENDOR_INIT` — there are two ST77916 revisions; enable it in menuconfig |
| Colours inverted / negative | Do not call `esp_lcd_panel_invert_color()`; the init sequence already inverts |
| Screen shows snow or a shifted image | Lower `Knob BSP → Display → QSPI clock` to 20 MHz, then work back up |
| Touch does nothing | Check the log for `no CST816S at address 0x15`; reseat the flex cable |
| Knob does nothing in the UI | Widgets must be in the group — see [SQUARELINE.md](SQUARELINE.md) |
| Rotation backwards | `Knob BSP → Encoder → Swap rotation direction` |
| Build fails: `idf.py: command not found` | Set `.idf-env.json` (step 2 above) |
| No debug COM port on the cable | Note receive is on: the instrument holds the single USB controller as a MIDI device. Turn note receive off and reboot the instrument — see [MIDI input](#midi-input) and [../tools/webflash/README.md](../tools/webflash/README.md) |

More in [TROUBLESHOOTING.md](TROUBLESHOOTING.md).

---

## Verification status

Being explicit about what has and has not been checked, because it affects
where to look first when something is wrong.

**Verified against primary sources**

* Pin map — the vendor demo's `pincfg.h`, cross-checked against the board
  schematic and two independent firmwares for this board.
* The ST77916 vendor init sequence was transcribed line by line from the
  vendor source.

*Every API this framework calls was then read back out of the upstream header
  it comes from, not inferred from documentation or memory:*

| Header | What it confirmed |
|---|---|
| `esp_lcd_st77916.h` | `st77916_lcd_init_cmd_t`, `st77916_vendor_config_t`, both `ST77916_PANEL_*` macros, `esp_lcd_new_panel_st77916()` |
| `esp_lvgl_port_disp.h` | every field of `lvgl_port_display_cfg_t`, including `color_format` and the `flags` bitfield |
| `esp_lvgl_port.h` | `ESP_LVGL_PORT_INIT_CONFIG()`, `lvgl_port_lock/unlock/deinit` |
| `esp_lvgl_port_knob.h` | `lvgl_port_encoder_cfg_t`, and that `encoder_enter` is a `button_handle_t` on button v4 |
| `button_types.h`, `button_gpio.h` | `button_config_t`, `button_gpio_config_t` field-for-field, `iot_button_new_gpio_device()` |
| `i2s_pdm.h` | the entire PDM RX path — and the absence of a gain call (see below) |
| `esp_lcd_io_i2c.h` semantics | checked indirectly; the bus cast in `bsp_touch.c` is the only spot resting on an unopened header |
| `esp_lcd_touch_cst816s.h` | the factory signature, the `0x15` address, and that the IO macro really does expose `scl_speed_hz` for the override |
| `lvgl/core/lv_obj.h` | the whole object API — **and that `lv_obj_clear_flag()` no longer exists** |
| `lvgl/core/lv_group.h` | every group call, `lv_group_send_data()`, `LV_KEY_ENTER` |
| `lvgl/core/lv_obj_event.h` | `lv_event_get_target_obj()`, `lv_obj_remove_event_cb_with_user_data()` |

That pass paid for itself three times over. It caught:

* `i2s_channel_reconfig_pdm_rx_gain()` — which **does not exist**. The PDM RX
  path has no gain call at all, only `amplify_num` in the slot configuration —
  and that field only exists on the chips with the PDM RX high-pass/amplify
  stage (P4, S31). The ESP32-S3 this board runs is not one of them, so the BSP
  compiles the "no PDM RX amplify stage" branch and `bsp_audio_in_set_gain()`
  returns `ESP_ERR_NOT_SUPPORTED`; the microphone's sensitivity is a software
  gain in the application (see FEATURES.md).
* `#include "knob.h"` — the component ships `iot_knob.h`.
* `lv_obj_clear_flag()` — removed in LVGL 9 in favour of `lv_obj_remove_flag()`.

It also placed `iot_button_new_gpio_device()` in `button_gpio.h` rather than
`iot_button.h`.

**Build status: compiles and links clean.**

`idf.py build` succeeds against **ESP-IDF 6.1** with GCC 15.2 and LVGL 9.6:

```
Successfully created ESP32-S3 image.
guition_knob.bin binary size 0x16ed30 bytes. Smallest app partition is 0x400000 bytes. 0x2912d0 bytes (64%) free.
Project build complete.
```

Getting there flushed out nine real problems that only a compiler finds. The
ones worth knowing about, because they will recur:

| Problem | Cause |
|---|---|
| `CONFIGURE_DEPENDS is invalid for script and find package modes` | ESP-IDF reads component `CMakeLists.txt` in CMake *script* mode, where that keyword is illegal. `squareline_sync` now touches the file instead. |
| `Failed to resolve component 'wifi_provisioning'` | IDF 6.0 moved provisioning to the registry as `espressif/network_provisioning` **and renamed the API and the callback signature**. `src/app_prov.h` maps both generations onto one set of names. |
| `NETWORK_PROV_SECURITY_1 undeclared` | protocomm compiles security versions out; version 1 is off by default on 6.x. |
| LVGL `-Werror=attributes` in `lv_draw_sw_blend_to_a8.c` | `CONFIG_LV_ATTRIBUTE_FAST_MEM_USE_IRAM` plus GCC 15's stricter section checks. Now documented and off. |
| `MALLOC_CAP_DEFAULT undeclared` inside `led_strip` | 2.5.x relied on IDF transitively including `esp_heap_caps.h`. Pinned to 3.x. |
| `esp_lcd_i2c_bus_handle_t undeclared` | The I2C panel-IO call takes `i2c_master_bus_handle_t` directly from 6.0; the old opaque type is gone. |
| `undefined reference to ui_MainScreen` | The placeholder `ui.c` declared the widget pointers `extern` in `ui.h` but never defined them. |
| `esp_flash_get_size` arity, `i2c_master_bus_rm_device` rename | Straight IDF 6 API changes. |
| Missing `esp_app_format`, `spi_flash`, `mbedtls` in `PRIV_REQUIRES` | IDF does not infer these; the build names the component that owns the header and refuses. |

**Verified on hardware**

The board has been booted, flashed and observed. Every peripheral in the pin map
comes up, and the boot reaches `app: boot complete`:

```
I (710) bsp.encoder: encoder pins at rest: A(2)=1 B(1)=1 (expect 1 and 1)
I (757) bsp.audio: output ready: 44100 Hz, 16-bit, stereo
I (752) bsp.audio: input ready: 16000 Hz, 16-bit, PDM
I (843) bsp: board ready
I (908) bsp:  microSD    : mounted at /sdcard
I (954) ui: SquareLine UI ready, 1 focusable widget(s) on screen
I (2759) app: boot complete
```

That boot reports, in order: ST77916 at 50 MHz with the vendor init sequence,
CST816S at IC id 182, a 13-LED ring, I2S output, PDM input, and a
480 MB SD card mounted 4-bit at 40 MHz. There is no `app_net` line and no SoftAP:
the network is not started (see [Network and updates](#network-and-updates)), so
firmware goes in over the wire. OTA rollback is still cancelled — that is
`app_ota_mark_valid()`, which needs no radio.

**The encoder now works, in both directions, and the focus bug is fixed.** Both
were found by measurement after several wrong guesses; the full account is in
[HARDWARE.md](HARDWARE.md#2-the-encoder-two-pulse-lines-and-the-decoder-must-poll).
In short:

* The encoder is **two switch contacts**, not a quadrature phase pair. Each
  direction closes its own contact; one completed pulse is one detent.
* The decoder **polls at 1 kHz** instead of using GPIO interrupts. The contacts
  bounce, and an edge-counting decoder amplifies that into the dominant signal —
  which is what made the knob appear to work one way only.
* It counts **one step per completed pulse**. The verification is arithmetic, not
  a judgement call: the step count must equal the pulse count, and it does.
* **Touch no longer kills the knob.** LVGL's `lv_group_focus_obj()` clears edit
  mode on *every* focus change, including a tap, and the board has no button to
  restore it. The BSP now enforces the policy below on every input read.

```
steps by direction: 193 one way, -95 the other
raw edges:          A 95 rising / 95 falling,  B 193 rising / 193 falling
```

The focus policy is:

> One control on the screen → the knob always drives it, and a tap cannot take it
> away. Several controls → a tap chooses which one the knob drives.

The focused control is highlighted with a ring, and the ring is **absent** when
there is only one control — if the knob can only drive one thing, saying so is
decoration.

One more trap worth knowing about, because it looks exactly like a bug in the
code above: **LVGL's own theme outlines the focused widget in red.** That frame
is drawn by `lv_theme_default`, on `LV_STATE_EDITED` — the state an encoder in
edit mode sits in permanently — and it cannot be cancelled with
`lv_obj_set_style_outline_width()` or `lv_obj_add_style()`. Measured state
table and the working fix are in
[HARDWARE.md](HARDWARE.md#the-focus-indicator).

**Still not verified**

* **`app_ota_run()` is unproven.** The OTA download path is in the tree and behind
  the `APP_NET_BRINGUP` switch, but the network is not started, so no image has
  ever been downloaded with it. What is exercised is the rollback half:
  `app_ota_mark_valid()` runs on every boot.
* **IDF 5.x support is written but unexercised.** The compatibility layers in
  `app_prov.h`, the conditional provisioning component and the I2C cast are
  reasoned, not built — this machine only has 6.1. The CI workflow covers 5.4
  and 5.5 if you want that checked.
* **Audio output and input are configured but silent.** The I2S paths initialise
  and report their rates; no tone has been played and no sample recorded.
* **SD card read/write has not been tested.** The card mounts; nothing has been
  written to it.
* **The touch panel has not been touched.** It enumerates at IC id 182 and
  reports ready; no tap has been confirmed to reach LVGL.
* **Whether the encoder is truly non-quadrature** — resolved above, by
  measurement. Re-run the probe on a different board revision before assuming
  its numbers carry over.
* The `esp_lcd_st77916` **built-in** init sequence is assumed to match this
  panel. The vendor sequence is the default here, so the fallback path is
  untested.

**Deliberate deviation from the original brief**

The brief asked for an encoder *with a button*. The board has no button: the
vendor's `BTN_PIN 0` is dead code and GPIO0 drives the LED ring, while the
encoder's second contact pair (`EC2_A`/`EC2_B`) never reaches the MCU. Rather
than expose an API that cannot work, `BSP_ENC_BTN` is `GPIO_NUM_NC`, the
button is off by default, and the UI contract in
[SQUARELINE.md](SQUARELINE.md#there-is-no-push-button) is built
around rotation-plus-touch. The opt-in exists
(`Knob BSP → Encoder → Use a push button`) for anyone who finds a switch on a
free GPIO.

---

## Стенд на компьютере

Звуковую часть можно прогнать без прибора. Поведение на границах — нулевой срез, обратная
связь на единице, NaN из испорченного пресета — на столе ищется часами: прошивка, вспышка,
перезагрузка. Здесь те же файлы `components/synth_dsp` собираются под Windows и крутят
256-отсчетные блоки со скоростью порядка сотни секунд звука за секунду, а негодное
значение называется номером шага и зерном.

**Чем собирается.** Zig 0.14.1 работает как компилятор C++; ESP-IDF не нужен. Путь к
`zig.exe` берётся из `PATH`, иначе из фиксированного пути в `tools/host-stress.ps1`;
параметр `-Zig` задает его явно.
Платформенный слой — `tools/host/shim` (пустой `IRAM_ATTR`, журнал в stderr, куча с
пределом, виртуальные микросекунды, задачи через `std::thread`) и `tools/host/platform.cpp`.
Исходники прошивки не правятся: подменяется только то, чего у компьютера нет.

**Как запускать.**

```powershell
pwsh -File tools/host-stress.ps1
pwsh -File tools/host-stress.ps1 -Seed 7 -Seconds 120
pwsh -File tools/host-stress.ps1 -Blocks 1000000 -Mode random
pwsh -File tools/host-stress.ps1 -InjectNan 100
```

`-Seconds` — сколько секунд звука отрендерить; блок теперь 256 отсчётов, поэтому 20 с —
это 3750 блоков, а не 1875. `-Blocks` задаёт число блоков напрямую и важнее `-Seconds`,
`-Seed` — зерно. Без этих ключей стенд берёт бюджет по умолчанию: полный перебор плюс
2048 блоков случайного обхода (6104 блока, 32.6 с звука). Стенд делает два прохода: перебор
сеттеров со значениями `0, 1, 0.5, 0.001, 0.999, -0.0`, денормаль, `±inf`, `NaN` и
случайным числом, затем случайный обход с плавными движениями, прыжками на границы,
сменой режимов эффектов, временами дилея от самого короткого до самого длинного и высоким
темпом. Предохранитель рэка проверяет хвост каждого блока, стенд сверяет счетчик спасений
`synth_rack_rescue_count()` с предыдущим блоком, считает пик и отдельно считает не-числа в
прочитанном выходе: выход рэка — `int16`, поэтому не-число ловится предохранителем до
преобразования, а не после.

**Перебор обязателен.** Полный перебор — это 507 шагов по 8 блоков, 4056 блоков при
любом размере блока. Если бюджета не хватило, сокращённый проход не засчитывается: в
stderr и в приговоре печатается `sweep: INCOMPLETE (N of 507 steps, ... of 4056
blocks)`, строка `result` получает `(sweep incomplete)`, код возврата — 1. Зелёный
результат поэтому всегда означает, что проверены все значения таблицы, а не только
те, на которые хватило времени.

`-KeepGoing` печатает все спасения вместо первого, `-Sanitize` чинит негодные значения на
стороне стенда — это модель исправленных ограничений, а не правка прошивки. У самого
стенда (`build\host-stress\host-stress.exe`) есть диагностические ключи: `--trace`
печатает каждый шаг перебора, `--start-step N` продолжает перебор с шага N — так
продолжают после падения, когда негодное значение уводит индекс за пределы таблицы.
`--inject-nan N` намеренно кладет NaN на вход слоя в блоке N: проверка того, что стенд
вообще способен поймать не-число.

**Приговор и коды выхода.** В конце печатаются размер блока, число блоков, длительность
звука, отношение к реальному времени, пик минимум/максимум, число спасений, состояние
перебора и `result: PASS|FAIL`. Код 0 — все блоки конечны, спасений нет и перебор
завершён; код 1 — спасение, не-число на выходе, незавершённый перебор, падение процесса
или неверный запуск. Строка спасения содержит зерно, номер шага, номер блока, параметр,
подставленное значение, состояние предохранителя и несколько последних шагов:
эффект с длинной линией доносит негодное число до хвоста блока позже, и история показывает,
какой сеттер его положил. По этим числам прогон повторяется с тем же зерном. Падение, когда
негодное значение попало в индекс, который никакой предохранитель не проверяет, печатает
последний шаг и тоже возвращает 1.

**Это гейт, а не инструмент по желанию.** Перебор границ — часть проверки перед выпуском:
прогон по умолчанию обязан пройти перебор целиком и вернуть 0; незавершённый перебор —
провал, даже если все отрендеренные блоки конечны. На миллионе блоков прогон тоже должен
давать 0 — и в режиме `random`. Провал перебора означает одно из двух: спасение (негодное
значение дошло до выхода рэка) или падение (оно попало в индекс, который предохранитель
не проверяет), и в обоих случаях это незакрытая дыра в прошивке, а не помеха измерению.

**Профиль блока по частям.** `pwsh -File tools/host-stress.ps1 -Profile` собирает
`tools/host/profile.cpp` вместо перебора и печатает, куда уходит время блока: шесть состояний
патча (пустой, с эффектами, быстрый темп с коротким дилеем, дилей на четыре секунды,
перкуссия, максимум голосов), в каждом — «часть → мкс на блок → доля» по слоям и генератору,
по хорусу, дилею, ревербу, пластине, драму, драйву, компрессору и предохранителю со
сторожевым таймером, затем выбросы (блоки рядом с захватом памяти, первый удар, смена времени
дилея в обоих режимах, длина линии, четыре алгоритма реверба) и максимумы по частям с
состоянием, в котором они случились. `-ProfileBlocks` задаёт длину окна в блоках по 256
отсчётов (по умолчанию 400). Числа — этого
компьютера: движка голосов и PSRAM здесь нет, поэтому переносимы доли, а не микросекунды.

---

## Стресс на приборе

Стенд на компьютере ловит негодные значения в тракте, но не ловит то, что бывает только на
приборе: запись пресета в NVS во время игры, первое включение эффекта посреди ноты, темп,
которого генераторы ещё не видели, порчу состояния, которая переживает блок. Для этого есть
служебный режим `OBOD_STRESS`: прибор сам, без человека, прогоняет сценарии и печатает
приговор. Флаг выключен по умолчанию, и в обычной сборке файла
`components/synth_app/src/stress.c` нет вовсе — ни строки кода, ни байта в образе.

**Как включить.** `menuconfig` → «Сборка прибора (OBOD)» → «Автоматический стресс на
приборе», либо строка `CONFIG_OBOD_STRESS=y` в `sdkconfig`, затем обычные сборка и прошивка.
Всё остальное делает скрипт:

```powershell
pwsh -File tools/stress.ps1
pwsh -File tools/stress.ps1 -Port COM7 -Seconds 180
pwsh -File tools/stress.ps1 -KeepBuild
```

`-Seconds` — сколько секунд читать журнал (по умолчанию 120; полный проход занимает около
37 секунд, так что в него попадают два-три приговора). Скрипт сам ставит флаг, собирает,
прошивает, снимает поток и складывает строки `stress: verdict …` в
`build/stress-<дата>.txt`; полный журнал лежит рядом, в `build/stress-<дата>.log`. После
прогона флаг возвращается в исходное состояние, и, если не указан `-KeepBuild`, на прибор
прошивается обычная сборка. Ненулевой код возвращается на `FAIL` в любом приговоре или если
приговора нет вовсе.

**Что делает прибор.** Стресс живёт в отдельной задаче низкого приоритета (2, ядро 0) и
меняет параметры только через `synth_app_set_param()`, `synth_app_set_running()` и вызовы
пресетов — те же пути, которыми пользуется интерфейс. Одно действие на тик в 20 мс, поэтому
перебор параметров идёт не чаще 50 изменений в секунду. Сценарии идут один за другим:

- **перебор параметров** — все 86 звуковых параметров (патч и три параметра модуляции) по
  кругу: минимум, максимум, снова минимум и штатное значение. Последний шаг оставляет прибор
  играющим, а не набором нулей. Около 7 секунд.
- **темп** — лестница 30, 36, 40, 45, 60, 72, 90, 120, 150, 180, 240, 300 BPM, по секунде на
  ступень. Включены арпеджиатор (UP), сетка лида, перкуссия и синхронизированный с темпом
  дилей; время дилея на соседних ступенях чередуется между 1/16 и 1/32.
- **эффекты** — 225 изменений с шагом 40 мс: время дилея от 20 до 1500 мс и обратно, все
  деления от FREE до 1/32, переключение TAPE/XFADE, микс дилея 0↔1, четыре режима реверба,
  его размер и демпфирование, хорус (частота, глубина, микс) и все посылы. Около 9 секунд.
- **пресеты** — раз в две секунды сохранение в случайный из первых восьми слотов, одна
  видимая правка между сохранением и загрузкой, через 0,9 секунды загрузка обратно и сверка
  всех 83 значений с тем, что было записано. Около 8 секунд.
- **негодные значения** — раз в три секунды в случайный звуковой параметр обычным путём
  пишется `nan`, `inf`, `-1` или `1.5`; прочитанное значение обязано быть конечным и лежать в
  0..1, после чего возвращается прежнее. Строка `stress: bad p…` в журнале называет параметр,
  подставленное значение и то, что прочиталось.
- **отравление полюса** — раз в десять секунд отладочный вызов, скомпилированный только под
  флагом, кладёт `nan` в одно из двух состояний рэка: усиление мастера или компрессора.
  Предохранитель обязан поймать это на следующем блоке: ожидается ровно одно спасение от
  не-числа и строка `E … rescue N: …`. Если спасения нет за 500 мс, проход это отмечает.

Полный проход занимает около 37 секунд; после него печатается `verdict final`, счётчики
сбрасываются и начинается следующий проход с зерном на единицу больше. Зерно задано
константой `STRESS_SEED` в `stress.c`; для повторного прогона его можно передать сборке:
`idf.py -DSTRESS_SEED=7 build`. Приговор всегда называет использованное зерно.

**Приговор.** Одна строка раз в десять секунд и `verdict final` в конце прохода:

```
stress: verdict final seed 0x5eed2027 pass 2 block 29273 t 37.4 s peak -32110..32767
nonfinite 3 stray 0 silence 0 poison 3/3 bad 12/12 preset 3/3 miss 417 wrerr 0 reset no ok
```

Здесь зерно и номер прохода, номер блока и время от начала прохода, минимум и максимум
выхода, спасения от не-числа (все и «лишние», то есть не от отравления), от тишины, число
удачных отравлений, негодных значений и пресетов, пропуски дедлайнов, ошибки записи и
признак сброса. Последнее слово — `ok` или `FAIL`.

**Что считается провалом.** `FAIL` ставится, если спасение от не-числа произошло не из-за
сценария отравления (`stray` больше нуля), если в конце прохода выход молчит дольше двух
секунд или не было ни одного блока, если загрузка началась после аварийного сброса
(panic, сторожевой таймер, brownout), а также если не сработало само испытание: отравление
не привело к спасению, негодное значение не завернулось в 0..1 или пресет не сошёлся после
загрузки. Первые три — это отказы прибора, остальные — отказ стенда, и в обоих случаях
проход не засчитан.

---

## Как писать историю изменений

Правило для `CHANGELOG.md` и для текста страницы выпуска. Раздел написан по-русски: он про
текст, который читает владелец прибора, а не про плату. Остальной документ остается
исторической английской справкой.

**Для кого.** Для человека, у которого прибор на столе. Он открывает историю, чтобы за
минуту понять, что в приборе стало иначе и что ему это дает. Кода он не читает и про
буферы, задачи и шрифты ничего не знает.

**Образец.** История изменений Torso S-4 —
<https://docs.torsoelectronics.com/s4/changelog/>. Оттуда взят порядок, тон и вид пункта.

**Группы.** В выпуске столько групп из трех, сколько есть на самом деле:

- **Новое** — то, чего раньше не было: ручка, страница, настройка, режим;
- **Улучшения** — то, что стало удобнее, понятнее или приятнее;
- **Исправления** — то, что работало неверно, а теперь работает правильно.

Пустых групп не бывает: если в выпуске одна группа, остается только она. У первого
выпуска вместо групп допустимы «Новое» и «Чего нет» — второго не требует ни один
следующий.

**Пункт.** Одна фраза, обычно одна строка, иногда две. Начинается с жирного названия
того, что изменилось, и точкой после него:

> **Кольцо темпа.** На транспортной шторке темп теперь показан кольцом насечек — так же,
> как на страницах.

Дальше — что человек видит и что может сделать. Порядок в группе: сначала заметное,
потом мелочи. Пункты не повторяют друг друга между группами: одна и та же перемена
называется один раз.

**Что входит.** Новые ручки, страницы и настройки; изменение поведения; исправленные
ошибки; то, что убрано или переименовано, — с указанием, что вместо этого; все, что видно на
экране или слышно.

**Что не входит.** Сохранённое: нужно ли пересохранять пресет, что станет со звуками прошлых
выпусков, не пострадали ли они, какая карта переводит старые значения в новые. Порядок с
сохранённым — забота прошивки и её молчаливая работа: если звук звучит как звучал, сказать об
этом нечего, а если перестал — это ошибка, которую исправляют, а не строка в истории. Числа
реализации: пиксели, микросекунды, байты, проценты загрузки, размеры буферов и замеры
длительности. Имена функций, файлов, переменных и ключей хранилища, номера строк, хеши
коммитов, номера задач. Результаты тестов и замеров. Объяснения, как это устроено внутри, и
рассуждения о том, почему сделано так. Перечисление правок по одной, если человеку важен итог.
Восклицания, маркетинг, слова «просто» и «всего лишь».

**Тон.** Спокойный, утвердительный. Пишем, что стало, а не как это сделано и не как было
неудобно до этого.

**Порядок и даты.** Свежий выпуск сверху. У выпуска — номер и дата в виде `27.10.2026`;
дата берется из тега выпуска и не выдумывается. Список для сайта собирается из этого
файла скриптом `tools/make-changelog-json.ps1`, поэтому заголовки `## <версия>`, строка
даты, разделы `### ` и пункты `- ` сохраняются как есть: это не оформление, а разбор.

**Проверка.** Перед выпуском `node tools/changelog-check.js` сверяет список для сайта с
этим файлом. Проверка ловит расхождение версий, разделов и пунктов, но не стиль: стиль
читается глазами владельца прибора, и это единственный судья.

## Как писать документацию

Правило для страниц `web/*.html`, для `FEATURES.md` и для этого файла — всего, что читают как
инструкцию. У истории изменений свой раздел выше: она рассказывает, что стало, документация
объясняет, как этим пользоваться.

**Тон.** Сухой. Описание и последовательность действий, без оценки. Не «мощный», не
«интуитивный», не «удобно», не «к сожалению». Не «мы» и не «я»: прибор описан сам по себе.
Не «просто нажмите» и не «легко заметить» — если что-то требует пояснения, пишется пояснение.

**Что входит.** Что делает орган управления, что при этом видно на экране и что слышно, в
каком порядке выполнять действие, что происходит при крайних значениях, где лежит настройка.

**Что не входит.** Эмоции, оценка, обращения к читателю, шутки, многоточия и восклицательные
знаки. Числа реализации — пиксели, микросекунды, байты, проценты загрузки, имена функций и
файлов — на справочных страницах не нужны: для них есть раздел «Под капотом».

**Надпись с экрана — в рамку и в цвет семейства.** Имя страницы, ручки или настройки
набирается прописными, как на экране, обводится тонкой рамкой и получает цвет семейства, к
которому принадлежит на приборе: синий — тело, лиловый — голос, бирюзовый — время, зелёный —
перкуссия, розовый — rack, коричневый — микшеры, серый — настройки, светлый сине-серый —
пресеты. Те же цвета у плиток на карте разделов, поэтому надпись в тексте и плитка на приборе
читаются как одно и то же. Начертание полужирное, 600: тело страницы набрано 300, и метка
должна быть плотнее обычного слова.

В рамку идёт только надпись с прибора. Списки значений (киты, грувы, лады, фигуры акцента),
технические слова (`OBOD`, `MIDI`, `USB`, `SHA-256`), имена файлов и команды остаются обычным
текстом: рамка означает «это написано на приборе», и размывать её значение незачем.

Разметку ставит `tools/label-wrap.py`: он разбирает таблицы в `components/synth_ui/src/synth_ui.c`
и берёт семейство оттуда — имя страницы даёт цвет страницы, ручка даёт цвет страницы, на
которой стоит. У слова, которое стоит на нескольких страницах разных семейств (`CUTOFF`,
`DEPTH`, `SPEED`), решает страница документа: `CUTOFF` в `ref-drone.html` синий, он же в
`ref-lead.html` лиловый. Слова, которых нет ни среди страниц, ни среди ручек, перечислены в
скрипте руками; слово, общее для двух семейств и названное в тексте как общее (`ACCENT`),
остаётся без цвета. Скрипт правит страницы на месте и идемпотентен. Запускать после правки
текста страниц, до `tools/make-site.ps1`:

```
python tools/label-wrap.py
```

Результат сверяет `tools/label-check.js`: у каждой рамки должен быть класс семейства из тех
восьми, что есть в прошивке, и ни одного класса мимо.

