[Русский](RELEASE-NOTES.md) · **English**

# OBOD 1.3.0

A round ESP32-S3 synth controller with a 360 × 360 dial.

## What is new in 1.3.0

**A preset arrives as a slide.** A preset used to write a hundred and thirty-two values in a
single block, which is why some switches crackled — the log shows a run of late blocks on a load.
The mechanism for exactly this has been in the instrument for a while (random draws use it); the
preset simply did not. Now it does: smooth knobs travel over the SLIDE setting while stepped ones
— kit, figure, shape, voice mode — jump at once, without sweeping through the values between.
SLIDE at zero brings the instant load back.

**The crackle on switching presets.** It was my own mistake in relieving the block: on a change of
the VOICE mode the lead filter was removed and re-registered, and that operation wipes both the
parameters and the STATE of the effect — the filter was reset mid-sound and clicked. All four
copies of the filter now sit permanently with a state each; an unused one is switched off with a
zero cutoff, which costs one comparison and keeps its state. Loading a preset no longer touches
the effect chain at all.

**The crackle after the lead filter fix.** The cause is found and removed: the filter kept its
state in one shared place, and once the chord was split across buses it sat on four buses at
once — all four driving the same filter in turn and carrying the integrator charge from bus to
bus. That is heard as constant crackle. Each bus now has its own state. The block was relieved as
well: the filter runs only on the buses that carry notes in the current mode, the lead has five
groups instead of six, and the rack sum skips layers whose level and sends are zero. The average
block is 4.15 ms of 5.33.

**The lead filter works in CHORD mode as well.** Splitting the chord across buses gave each note
its place in the image — and left the filter out of work: it was attached to the layer bus only,
while in CHORD mode the notes sing on three chord buses. So CUTOFF, RES, ENV, SHAPE, K.TRCK and
MODE did nothing in a chord. The filter now sits on all four lead buses and every write of its
knobs goes to all four; the pans are untouched, since the chord buses carry their own.

**A skewed saw (SKEW).** The seventh shape in OSC — a saw with a bend, and the bend's position is
the same PW knob: at 50 % it is a triangle, nearer the edge a near-vertical front followed by a
long fall. The width knob therefore works on two shapes now, and on both it means the same thing —
the symmetry of the cycle. The six earlier shapes keep their places on the travel, so older
patches sound with the shapes they had.

**PW as an LFO destination.** The destination list has LD PW: DEPTH sets the span, SHAPE the form
and RATE the speed, and the pulse width breathes with them. It works on both shapes: duty on the
pulse, the bend on the skewed saw.

**The effects are audible out of the box.** All three MIX knobs — delay, chorus and reverb —
sat at zero, so a fresh instrument arrived completely dry. The factory value is now 80 %: delay,
chorus and reverb are heard at once. It costs about three hundred and fifty microseconds of the
block, because at a zero mix the effects were not computed at all.

**The lead has six groups instead of four.** The RELEASE knob reaches six seconds and the engine
computed the fall honestly — but the tail was cut: with four groups of three voices the fifth
note took a group from the first one, so six seconds were audible only on the last note of a
phrase. There are six groups now, and the engine's voice ceiling rises from 24 to 30: nine for
the drone, eighteen for the lead, three for the arpeggiator. A full six seconds on a dense line
at 120 still does not fit — that would need twice the voices — but on a slow line and with rests
the tail is heard in full.

**The drone's WIDTH knob now does what its name says.** Reading the code showed it went into
the pan as WIDTH × DEPTH, that DEPTH ships at zero, and that the pan only opened when the LFO's
destination included PAN — on a fresh patch the knob did nothing at all. It now spreads the
registers: LOW stays in the centre, MID moves left and HIGH right, 900 of 1000 at full travel.
The bottom is not moved because it is the anchor; the two upper registers part around it. The
drift stays movement and is switched by its own DEPTH.

**Pulse width on the lead (PW).** The sixth knob of the LEAD page, and it opens something the
instrument did not have: the engine has carried pulse width all along, but the application set
it once to half a period. The whole travel now spans the whole duty range: 5 % at the left
edge, 50 % (square) in the centre, 95 % at the right. LEAD → OSC = PULS → PW. Width is not part
of the shape crossfade, so it changes instantly and without a click, and the factory value
(the centre) is exactly the sound of every earlier patch.

**Damping of the delay's repeats (DAMP).** The sixth knob of the DELAY page, and it is what dub
has been missing: the filter sits in the feedback path, from 18 kHz (transparent) to 700 Hz
(dark), so every repeat comes back darker than the one before while the first one reads as
recorded. The factory value is zero — open — and older patches sound as they did.

**Stereo spread on the lead (SPREAD) — per note of the chord.** The three notes of a chord now
travel three engine buses, each with its own pan capture and its own place in the image: the root
slightly left, the third in the centre, the fifth slightly right, and at full travel almost — but
not quite — the edge, where a note would vanish from one channel. The knob moves exactly that;
at zero all three sit in the centre and the sound is as before. A single note and the arpeggio
stay centred with the drift they always had: the chord in stereo, the line in the middle.

The engine carries ten buses for this instead of seven: zero is the master, 1..6 are the six
layers, 7..9 the three notes of the chord. All three write into the lead's layer — a layer is a
fader and sends, not a place in the image — but each through its own pan capture, with its own
state and its own base.

**The bass filter lives in the kit alone.** TONE and RES were both a field of the kit and a knob
on the page, and the two multiplied. The BASS page is now five sectors — KIT, SNAP, NOTE, DECAY,
SUB — and the timber comes from the kit and only from the kit.

In the freed place, **NOTE, the line's pitch**: fifteen positions from −7 to +7 semitones, one
semitone apart, so the fifth and the fourth are a single turn away. The shift is applied before
the scale snaps, so the line moves and stays in key: the knob moves the note, not the register.
Measured by spectrum: the centre gives 55 Hz, +3 semitones 65.5 Hz, +7 82.5 Hz, −7 36.5 Hz.

**More sub, less distortion.** The sub is raised from 2.0 to 2.6 (+2.3 dB) and the (1 −
0.12·SUB) compensation is gone — it used to pull the whole voice down by exactly as much as the
sub was asked for. The voice goes into the scale at 0.40 instead of 0.43, the limiter's knee
rises from 0.8 to 0.85 and its slope falls from 3 to 2.2: the same peak, but the limiter barely
works, and it was the source of the distortion on low notes.

**The duck's make-up no longer steps or overloads.** It was computed as 1/(1 − 0.6·depth) and
multiplied into the samples as a block constant: the duck itself rides a per-sample ramp and the
make-up did not, so across a 12 ms attack the whole mix's gain moved in 187 Hz steps. It now has
its own 120 ms target, a +0.5 dB ceiling — without one it lifted the mix 1.7 dB into the soft
clipper, tens of samples over the knee on a hit — and a per-sample ramp.

The time budget was measured as well: a block averages 4557 us of 5333 and the longest is
5513 us, so 87 % of the budget. Misses are single and the audio queue absorbs them (`runs 1` in
the log), so they are not the source of clicks, but there is almost no headroom left and ducking
plus compression add about four hundred microseconds to a block.

**Stop/play starts everything from the top.** The transport button only cleared the stop flag,
so the instrument resumed in the middle of the bar: lead, drum and bass came in separately
because each had stopped somewhere else. A press on a stopped instrument is now a START — the
bar position and every step counter go to zero, and all sequencers begin on the first beat of
the same bar.

**The settings list scrolls to its end.** The wheel takes its movement from the arc, and the
arc's range in the list's browse mode was never changed — it stayed whatever the row under the
wheel had, and a two-position row such as MIDI IN left it at 0..1. The list therefore froze on
its second row. Browse now sets the range to the number of rows, the way the preset list always
has, and the screen-table check refuses a resolution change without it.

The release is about the bass: the instrument now has a bass part of its own, playing from the
first bar and depending on nothing but the clock and the transposition. And about the settings,
which came together on one page.

**The bass is a part of its own.** One voice, built after the three-oh-three: a band-limited
oscillator, a resonant filter, a decay-only amplitude envelope, a short filter envelope on every
note and a soft clip at the output. There is no sub-oscillator: on a bass note it produced
infrasound with no harmonics. Thirty kits in three families of ten — round, acid, trance and
psytrance — and five knobs beside them move a kit a long way: TONE, DECAY, SNAP, RES and OCT.
RES is the filter's resonance: it shifts a kit's character around where that kit already sits, so
the kits stay distinct while the knob gives the acid.

**RHYTHM is the figure.** Forty-two written patterns of sixteen steps, with VAR, LEN, GATE, SLIDE and
ACCENT — and each of them does one understandable thing. The draw is more musical. The bass figure is chosen from a density window: the pattern's index is
its density because the list is sorted, so a sparse character gets a sparse line and a dense one a
dense line, and the two extremes — a one-note pedal and a wall of sixteenths — are never drawn. The
bass cycle is only 4, 8 or 16 steps, because twelve does not divide a sixteen-step bar and walked the
ostinato against it. Gate and accent follow the figure's density: the denser the line, the shorter
the note and the rarer the accent. The tonic is drawn on the circle of fifths rather than flat: A, E,
D, G and C take two thirds of the draws between them, and the other keys stay possible.

The layer levels are not given to chance, and that is a decision: a patch whose lead sits eight
decibels over the drums sounds broken, not bold. Instead every fader gets the factory balance, a
half-decibel trim, and a lift for the layer the character pushes forward — dark characters raise the
drone, DIRT the bass, MACHINE the drums, GLASS the lead.

The drone sits on A1 and the tonic does not move it — that is its tuning. The scale does move
it: if the key has no A (C# major has A#), the drone sat outside the mode in every pause. Its
base now goes through the same quantiser as the lead's notes: on chromatic (the default) it stays
exactly as it was, and a scale without A takes it to the nearest degree, downward on a tie. The
move is smoothed by the same eight milliseconds as the note following, so a key change is a
glide. Checked against the tables: twenty-one scales by twelve tonics, the base outside the mode
zero times.

The SUB knob now reaches +4.5 dB in the low end, and its own high-pass moved from 28 Hz to 22:
at A1 the sub is 27.8 Hz and sat right on the corner, arriving three decibels down. Everything
above 60 Hz is untouched within 0.6 dB, so the gain reads as weight and not as boom.

The figures run from the sparsest to the densest, so the PAT knob walks up the list. The
notation has a ghost hit too: `o` is the root again, quieter — 0.50 against 0.78 for the weakest
ordinary step — and PSYROLL is written on it, `-o00-o00-o00-o00`: silence, ghost, two strong, four
times a bar. Measured per step, the ghost sounds at half of a strong hit (−6 dB), and it reads as a
push rather than a note.

A step's strength is quantised to three metrical levels — strong, medium and weak — rather than to
sixteen values placed by hand: a decibel and a half between neighbouring steps meant nothing and was
heard as a staircase. Measured on PSYROLL, the spread between strong steps fell from 1.2 dB to
0.3 dB, and the dip on a ghost from 9.5 dB to 6.2 dB.

The level rides instead of jumping: when a note is quieter than the level the previous note was at,
the envelope gate falls to it over 25 ms. It used to be clamped at one and the level dropped
instantly — 5.6 dB in 25 ms at the seam, now 1.7 dB.

And the figure is visible: the page draws the same ring of dots the lead has on EUCLID and
the drum on PERC SEQ — one dot per step of the cycle, filled on the notes, larger on the accents, with
the playhead walking the steps. When the cycle is four steps long the ring has four dots, and the
polyrhythm is something you see rather than something you are told.

LEN IS THE CYCLE'S LENGTH, not a limit on how far the line may play. The counter used to run to
sixteen regardless and LEN only muted the notes past its number, so the bar stayed sixteen steps
long and the line could not live in its own size. The count now runs modulo LEN: four steps means
the line repeats four times inside the drum's bar, seven means seven steps against its sixteen.
That is the polyrhythm, and it does not break the grid — the bass sits on the same sixteenths as
the drum and the lead, it just counts them in its own circle.

VAR IS THE PROBABILITY OF VARIATION, not its type. There were six characters and the knob picked a
row, answering "which kind" rather than "how much". It is now a share: how many cycles get the
octave jump, how many get an extra accent and an extra tie. Zero is a steady line, one varies
every cycle.

SLIDE is the probability of a tie, straight, from zero to one, and an accent no longer cancels it:
the note glides into the next one instead of starting again. On a 303 the accented note is exactly
the one that slides.

OCT is a five-position switch: the value is quantised, so the scale stands still instead of
creeping.

**The bass breaks nothing.** It takes exactly three things from the instrument: the tempo, the
transposition and the steps of the scale — every semitone of the line is pulled to the nearest
degree, and out of two equidistant ones the bass and the lead choose the same. It does not depend on
the arpeggiator or on the drum figure at all. It has its own level on
LEVELS — with a meter, like every other part — its own sends on REV, CHR and DEL SENDS, and its
own place in the mix. The bass level is muted by a double tap, as the other parts' levels are.

**Settings on one page.** SETUP opens from the bottom drawer and stays one page: AUDIO (SLIDE,
RND DEL, WEAK VEL, MIC), MIDI (MIDI IN), PERSONALISATION (SCREEN, RING, RING FX, MORPH), SYSTEM
(PATCH). The headings divide the list by meaning rather than by the number of sectors found on the
rim. The way out is the drawer, as the way in was: there is no separate BACK on the page.

**The drum and the line on one count.** The drum counted from an accumulator that crosses one
only after a full sixteenth: its first hit arrived 125 ms after the start, while the lead takes
its step straight from the transport position and sounded at once. The drum's zero step now
stands in the start block. The bass also took the drum's swing: the odd sixteenth waits the same
number of blocks for both, so the line and the drum agree to the block rather than roughly.

**The bass does not click.** The limiter at the voice output stepped at 0.8; it now has a smooth
knee, and the voice runs with headroom, so the limiter is not working on every bar and the level
does not breathe. The second source of clicks was the filter: on high-resonance kits the damping
fell below the filter's step and the circuit ran away.

**The bass is the amber family.** Its own row in the palette: an amber rim, an amber page, an
amber tile on the map. On the map the bass is now visible before the word is read.

**The audio no longer freezes.** While the effects task was late, the sound repeated the previous
block — and kept repeating it until the task came back. During a settings write to flash that is
hundreds of milliseconds of the same five-millisecond slice, which sounds like a frozen note. A late
block now costs exactly one repeat; after that the tail is computed in place, and if the task has
not delivered forty blocks in a row it is removed for good and everything runs in place as before
the pipeline. The statistics line now reports `fxlate` and `fxmax`.

**The crackle is gone.** It had three sources, and none of them was overdrive — all three were
arithmetic. The audio task waited for the effects tail for up to six milliseconds out of five and a
half, and on a block it did not get it emitted a constant — a dropout with two steps in it. Nobody
waits now: finished blocks sit in a ring, a late block costs a repeat of the previous one, and the
counter in the statistics reads zero over a minute. The drive's asymmetry switched its gain on every
zero crossing, a hundred and ten steps per second; the curve is symmetric now. And the bass limiter
engaged on every accented note because the peak reached 0.79 against a knee at 0.8; the headroom is
lowered, so the loudest kits now peak at 0.40..0.60. The bass is about a decibel and a half quieter
for it — the level comes from the BASS knob on LEVELS.

**Sends are post-fader.** The send used to be taken before the fader, so a layer at zero level
still fed its dry signal into the reverb, the chorus and the delay — the effect played with the
layer turned off. The fader's gain is now applied where the send leaves for the bus: once, for all
six layers. Level at zero means nothing reaches the effects.

**The reverb steps its tank every other sample.** This is the most expensive stage after the sum: 156
kilobytes of tank in PSRAM with twenty-four accesses to it on every sample. The tank now steps every
second sample — 24 kHz inside — with the lines cut to half length so the delay in seconds stays the
same, and with the coefficients left alone: the number of passes through a comb per second has not
changed, and squaring the feedback would have been a mistake (the first attempt gave a tail half as
long). Measured tail: T60 1.16 s against 1.12 s before. The price is one thing: the tail's top is cut
at twelve kilohertz — the spectral centroid reads 2381 Hz against 2965. The dry path is untouched and
the plate keeps its own topology. The device after the change: 4642–4747 us with 1.8% of blocks over
budget against 22% under the same load.

**The bass send meter shows the send.** The list of sends the meter reads named eighteen knobs and
three of the bass's were not in it. For those the function answered "not a send", the bar took the
fader's level, and turning the send knob showed nothing at all. The bass REV, CHR and DLY are now sends
like the rest: the bar is the send amount times the effect's return level.

**The draw reaches the bass too.** A fresh sound used to arrive over the previous bass: the section
stayed exactly where the last patch left it. Now the bass kit and its figure are chosen outright — a
character and the music, just as the drum kit and the groove are. SNAP, TONE, DECAY, the sub and the
resonance are drawn in the musical middle of their travel, pushed off the middle by bite the way the
drone's texture knobs are, and the sub is left out on a third of the draws so that every patch does
not stand on the same bottom. VAR, GATE, ACCENT and SLIDE are the line's playing, so they are drawn as
playing, and LEN takes one of three musical lengths: eight, twelve or sixteen steps. The bass fader and
its three sends are left alone: how much bass sits in the room is a decision about the recording, not
about the sound.

**Layer sum: a quarter of the load gone.** A layer's level and its three sends were computed on every
sample, though they glide and move by a hundredth of their travel over eight samples. They are now
folded once per eight samples, leaving a multiply of the signal by a ready number: eight multiplies per
layer instead of eighteen. Measured on the device: average 5174 → 3904 us, misses 32% → 2.8%, longest
run 45 → 0 after startup, worst 5135 against a 5333 budget. The sound is unchanged: peak 0.798, RMS
0.092, brightness 0.574 before and after.

**The rare clicks: the limiter's knee and the sub's phase.** Punch lifts a note's edge by 1.2 dB, and
on a loud kit with a sub the peak reached 0.842 against a 0.8 knee. The limiter's curve has a slope six
times below unity at the knee: half a percent past it drops the gain seven times, which is a corner
rather than a limit, and it is heard as a click. The voice now sits at 0.43 instead of 0.46, the knee
is softer, and the peak reads 0.798 — below it. The second source was the sub: on an untied note its
phase was reset to zero, where the triangle stands at one, so it stepped by a full unit — audible on a
turnaround's extra hit, where the gate is already open. The phase now starts at a quarter, where the
triangle is zero.

**The high tinkle at the start of a note is gone.** The measurement showed where it came from: the
first eight milliseconds of a note carried 27.5 dB more in the 4–10 kHz band than its own body. Probes
without the filter envelope and without the pitch kick gave more, not less — so the cause was the
cutoff opening instantly at the hit, leaving the first milliseconds almost unfiltered. The filter
envelope now rises over three milliseconds together with the gate. After the change: 4–10 kHz reads
plus 3.5 dB instead of plus 27.5, and 1.5–4 kHz plus 6.5 instead of plus 15. The 303's quack stays,
the tinkle is gone. The voice's level also now slopes between control steps instead of stepping, so a
two-millisecond attack is no longer a six-step staircase.

**A/B: odd cycles answer low.** On an odd cycle of the figure the notes in its upper half drop an
octave — the rhythm and the hook stay, but they sound from below, so the line talks instead of
repeating. This is not a transposition of the whole figure: the key stays. It works with VAR and is
off below 0.15, so one knob brings the plain figure back. Measured: on a figure with upper notes, the
35–80 Hz band rose by 1.7 dB and 80–160 fell by 1.8 — the upper notes moved down. Figures without
upper notes are untouched, as they should be.

**Punch.** A note rises 1.2 dB above its own body for ten milliseconds, and the body is trimmed by
the same amount, so the average does not grow while the hit reads in the mix. Measured: the ratio of
the envelope's peak to its middle went from 4.08 to 4.38 at the same body level. It costs one
one-pole at the control step and nothing in the per-sample path.

**The bass-to-delay send is fixed.** When the fader glide started stepping once per eight samples,
the loudest send into the delay stayed per-sample and was zeroed on seven of every eight samples:
the delay send and the dry path were gated at six kilohertz, which sounds like digital noise and
resonance when the bass is sent to the delay. That value now lives for the whole block.

**Ratchets are gone, the fader glide is eight times cheaper.** The flick inside a step is removed:
it sounded like a stutter. The turnaround on the last step of a cycle stays, reaching into the next
round. The fader and send glide used to run every sample — twenty-four one-poles per sample at a
time constant of a millisecond and a half. It now steps once per eight samples and holds its values
in between: no difference to the ear, an eighth of the work. On the device the average fell from
4745–4953 to 4452–4577 µs, and misses from 259–591 of 1900 to 113–370.

**The bass sits in the mix: the duck takes the low end only.** Ducking used to multiply the whole
bass, so the middle droped with the low end — and the middle is what keeps the line audible on small
speakers. The bass is now split by a two-pole filter at 160 Hz: only the low part follows the kick's
factor, while the top and middle stay put, and the sends take the same split pair. That is the trick
that lets a bass live with a kick instead of fighting it.

**The figure comes alive: step strength, a turnaround, a ratchet.** Each of the thirty figures
now carries its own strength for each of its sixteen steps — the downbeat louder, the weak step
quieter, with the table's rests where the figure rests. Before, the whole line had two levels, so a
sixteenth on the beat sounded exactly like one before it. The accent is still a full unit and
overrides the table: it is about the hit, the table is about the flow. The last step of a cycle
reaches into the next one — with a probability taken from VAR a turnaround plays there, a grace
note an octave up or down. On ordinary steps the same probability makes the note flick twice, the
ratchet of old bass lines. The processor is untouched: a three-slot scheduler and the same voice
once more. Measured: with VAR at zero the recording holds 224 attacks in four seconds, at VAR 0.8
it holds 306.

**OCT is off the page and SNAP is back.** The pitch kick has its own knob again, as asked: the
BASS page is now KIT, SNAP, TONE, DECAY, SUB, RES. There is no octave trim any more, and that is
no loss: a kit's own octave field sets the line's register, while the variation's octave jump stays
part of the figure. SNAP drives the pitch kick and the filter envelope's depth over its old range,
and ACCENT is back to its own work — it lifts the resonance and opens the cutoff deeper, but no
longer touches the note's pitch.

**SUB takes SNAP's seat.** The slot of the SNAP knob now holds SUB — the share of a triangle an
octave below the note. The sub sits after the filter and before the gate: a closed cutoff would
otherwise eat all of its weight, while its attack and decay belong to the note. Below twenty-eight
hertz a one-pole high-pass keeps the low end from spending headroom on notes that cannot carry it.
SNAP's work went to ACCENT: the pitch kick and the filter envelope's depth now follow the accent,
so the accented note is the one that bites, as on a 303. Measured from the recordings: the 15–40 Hz
band rose by 15.5 dB, the other bands stayed put, and the peak below forty hertz moved from 38 to
26 Hz while the fundamental stayed at 55.7.

**The send's meter is post-fader.** The send leaves for the bus after the fader, but the meter did
not know it: with the level down the fill kept moving while nothing reached the effect. The send's
reading now multiplies the fader, the send, the return and the duck — a zero in any of them empties
the fill.

**OCT and LEN click through their positions.** The value used to be rounded to a step only in the
sound, while the knob stayed continuous: the arc showed a position the sound did not have. The
position is rounded before it is written now, so finger, arc, number and sound sit on the same
step — five for OCT, thirteen for LEN.

**The filter is radical now.** The TONE knob used to travel an octave and a quarter around a
kit's own place: it coloured, but it neither opened nor closed. The range is now almost five
octaves, and the cutoff is audible at both ends. Resonance reaches the acid ring: damping is
2 − 1.9·res instead of 2 − 1.6·res, the floor is down to 0.12 and the ceiling of the knob is up to
one. The slope stays at eighteen decibels per octave: the instrument's load does not allow paying for
steepness with dropouts. The voice's level gives way as the resonance rises, keeping the peak out of the limiter. I
also fixed the cutoff's clamp: leaving the range at the top threw the filter down to twenty hertz,
so on bright kits the top of the knob was a dull thud instead of an open top. Measured from the
recordings: a spectral centroid of 340 Hz shut against 1759 Hz open, peak 0.59 at full resonance —
no clipping and no collapse.

**RES replaces DRIVE.** I took the overdrive out of the bass entirely: it gave density, but
resonance gives the same density, costs a third as much and says what it does. In its place is RES,
the filter's resonance. The kit sets its own character and the knob shifts it seven tenths either
way: on a clean kit it gives the acid, on an angry one it heads towards a whistle without reaching
it — the ceiling is 0.95, because at one the filter rings on its own without being asked. The
parameter's number in the patch has not changed, so old presets read as before. The filter is
eighteen decibels per octave like a 303, and the accent is no longer only louder: it opens the
filter deeper and lifts the resonance, which is where the quack on accented notes comes from.

**The instrument no longer stutters.** The whole block runs in one task and on a patch with all
three effects it costs 4281 us of 5333, peaking at 5273 — no deadline is ever missed. I tried the
second core: it was faster on paper, but a task stuck inside the effects tail made the sound repeat
a single block, which is audible as a hum. So it all stays on one core: one thread, no shared
locks, no repeats. What protects the sound from the chip stalling on a flash write is the output
queue, and it is twice as long now — 120 ms instead of 60. That is what keeps playing while the
cache is off for an erase.

**The sequencer ring has colours.** On PERC SEQ, LEAD EUCLID and RHYTHM the step marks tell the
lanes apart by colour: the kick is amber, the snare almost white, the tom teal, the hat a green
ring, a ghost a dim green, and a fill a hot ring across the second half of the bar. The cursor is
white and brighter on the step that is sounding. The sizes are the ones they were, so the rank
still reads at a glance and the colour answers the second question — what exactly struck.

**A tie on the bass is a tie.** SLIDE used to change almost nothing: a tied note started again,
only without the click. Now it carries into the next one — no strike on that step, a longer note,
and if the next one is higher or lower the note slides into it. On a pattern of equal notes that
is audible as one long note instead of two short ones.

**Changing the FX type no longer stutters.** The names, the sectors and the rim are rebuilt once
the wheel has stopped; the sound changes at once, and the cursor and the page stay put while that
happens.

**Animated pages no longer stutter.** The ring, the pan drift and the meters run evenly, and while
something is moving on screen the sound does not stumble.

## What is inside

A drone of three spectral parts, a lead of three voices — mono, polyphonic or as a chord — a bass in
one voice, percussion of five voices and a microphone input as a modulation source. Three
sequencers, an arpeggiator, twenty-one scales with incoming notes quantised. Effects: chorus,
ping-pong delay and a reverb in four modes, including the Dattorro plate. Twenty-four pages, one
hundred and twenty-six knobs, one hundred and thirty-one sound parameters and one hundred and
twenty-eight preset slots in NVS. Notes over USB-MIDI with transport and clock.

## What is in the archive

The project source, `dependencies.lock` with pinned component versions, the flashing page for the
browser, documentation on the hardware and the signal path, and the feature and third-party
component lists.

The built image is not part of the source archive: it lives in the repository and on the GitHub
release page — `OBOD.bin`, 1 289 328 bytes, SHA-256 `745D3168BB72BF3463D1553C41FEC98278915AFE0C10A52D933F4A8E40434007` — while the site carries
it sealed only. The source archive on the site is open to everyone, without a release code: the files
of version `1.3.0` without the built image, with the size and SHA-256 in `sources.json`
beside the archive.

## How to flash

```
pwsh -NoProfile -File .\tools\idf.ps1 -p COM4 flash
```

Or in a browser: the flashing page on the site, `tools/webflash/serve.ps1` locally. The image on
the site is sealed: the page asks for the release code, derives the key from it and decrypts the
file in the browser, and the instrument receives an already decrypted image. The release code is
one and lives in the Boosty post: posts with codes are open to any subscription tier
(boosty.to/annabiosis). Details are in `docs/RELEASE.md`.

## Known limitations

Note input is off by default and takes the only USB controller, so there is no debug COM port over
the cable. Control change, pitch bend and program change are not handled, and there is no MIDI out.
Clock from an external source does not reach the delay sync. There is no master limiter and no
dither, and no Bluetooth MIDI. The bass kit and figure, and the drum kit and groove, are stored as
a position in a list, so a preset from an earlier release may land on a different kit or figure:
the lists have grown longer.

The Russian text in [RELEASE-NOTES.md](RELEASE-NOTES.md) is the source; if the two diverge, the Russian one is right.
