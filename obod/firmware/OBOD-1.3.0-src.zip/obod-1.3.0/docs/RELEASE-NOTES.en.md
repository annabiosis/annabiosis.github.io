[Русский](RELEASE-NOTES.md) · **English**

# OBOD 1.3.0

A round ESP32-S3 synth controller with a 360 × 360 dial.

## What is new in 1.3.0

**The BASS section.** The bass is a part of its own now, with a page: its line's figure, the kit's
filter, a sub underneath, ties and NOTE — a shift of seven semitones either way. Before this it
had neither a page nor a place in the mixer.

**The RHYTHM page.** The bass's second screen: PAT, ACCENT, VAR, SLIDE, LEN, GATE and the figure's
ring, the same one the lead and the drum draw. Forty-two bass figures go by density, and LEN is the
cycle's length rather than a ban on playing past it, so the line lives in its own metre and does
not upset the grid.

**A second LFO.** Two independent channels, each with its own receiver, two depths, shape, speed
and trigger. Depths are two-sided — the middle of the travel is zero, clockwise is in phase,
anti-clockwise is against — and they travel in the patch, so a preset carries its modulation.

**The FX machine.** One slot of the rack holds ten effects on the TYPE knob, from chorus and
flanger to bitcrush and STUTTER. The A, B and C captions change with the type, and a knob the
effect does not have goes dark and takes no input.

**Six delay algorithms** on the MODE knob: DIGITAL, PINGPONG, MULTI, TAPE, FILTER, DIFFUSE. All of
them in the same point of the loop, with no new buffers.

**AUTOPLAY.** Three positions — ON, OFF and STORE, which remembers whether the transport was
running and comes back to that state.

**The sequencer ring has colours.** On PERC SEQ, LEAD EUCLID and RHYTHM the step marks tell the
lanes apart by colour: the kick amber, the snare almost white, the tom teal, the hat a green ring,
a ghost dimmed, a fill a hot ring; the cursor is white and brighter on the step that is sounding.
The sizes are the ones they were, so the rank still reads at a glance and the colour answers the
second question — what exactly struck.

**The section map is relaid.** Two rings in the new arrangement, tiles with rounded corners,
MASTER in the middle as an equal tile, the codes LF1, LF2, BSQ, PSQ, EQL and DEL. The map opens
without a pause: the geometry is worked out once at load and a frame only repaints by number.

**Settings on one page.** The list is grouped by meaning into AUDIO, MIDI, PERSONALISATION and
SYSTEM, with headings, a wide touch zone and smooth scrolling.

**Captions carry units.** TONE, PUNCH and TIMBRE on the drum are percentages, TUNE is semitones,
the hit's length is a multiplier; delay divisions use a colon — 1:8, 1:16, 1:32; sends are
percentages.

**Lead: pulse width, spread and six wave groups.** PW is driven by an LFO receiver too, SPREAD
really spreads the notes of a chord, and the wave groups give the lead more characters.

**The drone reads as it sounds.** WIDTH does what it says, the registers are decibels with a
correction for audibility, and the drone yields to the lead. SKEW left the drone's shapes: its
kink is set by a knob the page does not have.

**Animated pages no longer take the screen away from the sound.** The ring, the pan drift and the
meters run evenly, and changing the FX type no longer stutters: the page is rebuilt once the wheel
has stopped while the sound changes at once.

**Crackle is gone.** It came from the SKW shape, from switching presets, from the half-rate
reverb and from the MULTI tap, which read one position for the whole block.

**The sound no longer freezes.** The block is computed in one task: a late effects tail costs one
repeated block instead of a stuck sound.

**The patch is not written while the instrument plays.** A flash write waits for the transport to
stop, so turning a knob no longer drops the sound.

**The meters are back.** The level meters on every page showed nothing — half of them were
declared without being recalculated.

**A tie on the bass is a tie.** SLIDE carries a note into the next one: no strike on that step, a
longer note, and on different pitches the note slides into the next.

## What is inside

A drone of three spectral parts, a lead of three voices — mono, polyphonic or as a chord — a bass in
one voice, percussion of five voices and a microphone input as a modulation source. Three
sequencers, an arpeggiator, twenty-one scales with incoming notes quantised. Effects: chorus,
ping-pong delay and a reverb in four modes, including the Dattorro plate. Twenty-four pages, one
hundred and twenty-six knobs, one hundred and thirty-one sound parameters and one hundred and
twenty-eight preset slots in NVS. Notes over USB-MIDI with transport and clock.

## What is in the archive

The project source, `dependencies.lock` with pinned component versions, the flashing page for the
browser, documentation on the hardware and the signal path, and the feature and third-party
component lists.

The built image is not part of the source archive: it lives in the repository and on the GitHub
release page — `OBOD.bin`, 1 289 328 bytes, SHA-256 `745D3168BB72BF3463D1553C41FEC98278915AFE0C10A52D933F4A8E40434007` — while the site carries
it sealed only. The source archive on the site is open to everyone, without a release code: the files
of version `1.3.0` without the built image, with the size and SHA-256 in `sources.json`
beside the archive.

## How to flash

```
pwsh -NoProfile -File .\tools\idf.ps1 -p COM4 flash
```

Or in a browser: the flashing page on the site, `tools/webflash/serve.ps1` locally. The image on
the site is sealed: the page asks for the release code, derives the key from it and decrypts the
file in the browser, and the instrument receives an already decrypted image. The release code is
one and lives in the Boosty post: posts with codes are open to any subscription tier
(boosty.to/annabiosis). Details are in `docs/RELEASE.md`.

## Known limitations

Note input is off by default and takes the only USB controller, so there is no debug COM port over
the cable. Control change, pitch bend and program change are not handled, and there is no MIDI out.
Clock from an external source does not reach the delay sync. There is no master limiter and no
dither, and no Bluetooth MIDI. The bass kit and figure, and the drum kit and groove, are stored as
a position in a list, so a preset from an earlier release may land on a different kit or figure:
the lists have grown longer.

The Russian text in [RELEASE-NOTES.md](RELEASE-NOTES.md) is the source; if the two diverge, the Russian one is right.
