"""PUNCH: зеркало того, что делает прошивка, против его четырёх кадров.

Фигура собрана шестнадцатью углами на одних и тех же местах: впадина на оси, кончик, впадина
по диагонали, кончик. Четыре числа на кадр — две глубины впадин, радиус кончика и полуширина
плоской полки — берутся из synth_ui_preview.c и проводятся между кадрами так же, как в
прошивке: целыми десятыми долями, с округлением от нуля.

Обводка — не перо: многоугольник заливается, из заливки стирается слой по восьми соседям и
слой по четырём, и остаётся разница. Проверяется три вещи:

  * совпадение с четырьмя кадрами владельца, точка в точку по маске;
  * толщина линии по строкам: три пикселя на диагонали и два на прямой стороне — так
    нарисовано у него, и так должно выходить у нас;
  * чётность симметрии: фигура обязана совпадать с собой при повороте на девяносто, при
    отражениях по осям и по диагоналям.
"""
import math
import re
import sys
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")

SRC = Path("components/synth_ui/src/synth_ui_preview.c")
HDR = Path("components/synth_ui/src/synth_ui_preview.h")

ART = 44
CX = CY = 21.5
SH = ["92622d973e5468762bfaa5ba0d87c08e9e933a6ed832b763a7c160f99504d03c",
      "108b3cf0e2ac9bc6253a39447d395c85e33eab9cfeaa5fe2d9ae69883d896669",
      "fd1a736d05723f6809efb03099928b3b78250f4c76a757c9c2b960795cb4557b",
      "f88da78e783c859705729dcaab18e0c7bc97780fabfcfd393d7cc6b208a0dbf2"]
BASE = Path(r"C:\Users\Blaq\.dsh\attachments\v1\objects")
TOLERANCE = 70          # расхождений на кадр: у третьего и четвёртого лучи шире его руки


def konst(name):
    text = SRC.read_text(encoding="utf-8")
    m = re.search(r"#define\s+%s\s+\(?(-?\d+)\)?" % name, text)
    if not m:
        raise SystemExit("нет константы %s в %s" % (name, SRC))
    return int(m.group(1))


T1 = konst("PV_PU_T1")
T2 = konst("PV_PU_T2")
CENT = konst("PV_PU_CENT")
TIP0 = konst("PV_PU_TIP0")
TIP1 = konst("PV_PU_TIP1")
DIAG = konst("PV_PU_DIAG")
QUAD = konst("PV_PU_QUAD")
A = [konst("PV_PU_A%d" % i) for i in range(4)]
D = [konst("PV_PU_D%d" % i) for i in range(4)]
R = [konst("PV_PU_R%d" % i) for i in range(4)]
S = [konst("PV_PU_S%d" % i) for i in range(4)]


def mix(pos, t0, t1, a, b):
    """Целое, как в прошивке: округление от нуля, деление с усечением к нулю."""
    span = t1 - t0
    num = (b - a) * (pos - t0)
    return a + (num + (span // 2 if num >= 0 else -(span // 2))) // span * 1


def mix_exact(pos, t0, t1, a, b):
    """То же, но с делением, усекающим к нулю, как в C."""
    span = t1 - t0
    num = (b - a) * (pos - t0)
    bias = span // 2 if num >= 0 else -(span // 2)
    return a + int((num + bias) / span)


def params(q):
    t = q * 20
    if t <= T1:
        return (mix_exact(t, 0, T1, A[0], A[1]), mix_exact(t, 0, T1, D[0], D[1]),
                mix_exact(t, 0, T1, R[0], R[1]), mix_exact(t, 0, T1, S[0], S[1]))
    if t <= T2:
        return (mix_exact(t, T1, T2, A[1], A[2]), mix_exact(t, T1, T2, D[1], D[2]),
                mix_exact(t, T1, T2, R[1], R[2]), mix_exact(t, T1, T2, S[1], S[2]))
    return (mix_exact(t, T2, 1000, A[2], A[3]), mix_exact(t, T2, 1000, D[2], D[3]),
            mix_exact(t, T2, 1000, R[2], R[3]), mix_exact(t, T2, 1000, S[2], S[3]))


def corners(q):
    a, d, r, s = params(q)
    pts = []
    for quad in range(4):
        deg = (quad * QUAD, quad * QUAD + TIP0 - s, quad * QUAD + TIP0 + s,
               quad * QUAD + DIAG, quad * QUAD + TIP1 - s, quad * QUAD + TIP1 + s)
        rad = (a, r, r, d, r, r)
        for dg, rd in zip(deg, rad):
            ang = dg * math.pi / 1800.0
            pts.append((CENT + rd * math.cos(ang), CENT - rd * math.sin(ang)))
    return pts


def fill(q):
    pts = corners(q)
    n = len(pts)
    g = [[0] * ART for _ in range(ART)]
    for y in range(ART):
        yc = float(y) * 10.0
        xs = []
        for i in range(n):
            x0, y0 = pts[i]
            x1, y1 = pts[(i + 1) % n]
            if (y0 <= yc < y1) or (y1 <= yc < y0):
                xs.append(x0 + (x1 - x0) * (yc - y0) / (y1 - y0))
        xs.sort()
        for i in range(0, len(xs) - 1, 2):
            for x in range(int(math.ceil(xs[i] * 0.1)), int(math.floor(xs[i + 1] * 0.1)) + 1):
                if 0 <= x < ART:
                    g[y][x] = 1
    return g


def erode(g, eight):
    out = [[0] * ART for _ in range(ART)]
    for y in range(ART):
        for x in range(ART):
            if not g[y][x]:
                continue
            keep = True
            for dy in (-1, 0, 1):
                for dx in (-1, 0, 1):
                    if dx == 0 and dy == 0:
                        continue
                    if not eight and dx != 0 and dy != 0:
                        continue
                    xx, yy = x + dx, y + dy
                    if not (0 <= xx < ART and 0 <= yy < ART) or not g[yy][xx]:
                        keep = False
            if keep:
                out[y][x] = 1
    return out


def punch_frame(q):
    g = fill(q)
    cut = erode(g, True)
    cut = erode(cut, False)
    return [[1 if g[y][x] and not cut[y][x] else 0 for x in range(ART)] for y in range(ART)]


def his(k):
    from PIL import Image
    h = SH[k]
    p = BASE / h[:2] / h
    im = Image.open(str(p)).convert("L")
    px = im.load()
    return [[1 if px[x, y] > 110 else 0 for x in range(ART)] for y in range(ART)]


def rotated(g):
    return [[g[ART - 1 - x][y] for x in range(ART)] for y in range(ART)]


def mirrored(g, axis):
    if axis == "x":
        return [[g[y][ART - 1 - x] for x in range(ART)] for y in range(ART)]
    if axis == "y":
        return [[g[ART - 1 - y][x] for x in range(ART)] for y in range(ART)]
    return [[g[ART - 1 - x][ART - 1 - y] for x in range(ART)] for y in range(ART)]


def runs(g, y):
    out = []
    x = 0
    while x < ART:
        if g[y][x]:
            x0 = x
            while x < ART and g[y][x]:
                x += 1
            out.append(x - x0)
        else:
            x += 1
    return out


def c_row_scale():
    """Строка заливки обязана быть в тех же единицах, что и углы, — в десятых.

    Это не педантизм: в первой сборке строка считалась в пикселях, а углы были в десятых, и
    заливка находила пересечения только в первых четырёх строках — на экране выходила полоска
    вместо фигуры, а этот гейт при этом сходился, потому что считал правильно. Теперь гейт
    читает выражение из прошивки и падает, если оно не домножает строку на десять.
    """
    text = SRC.read_text(encoding="utf-8")
    m = re.search(r"const float yc = \(float\)y[^;]*;", text)
    if not m:
        raise SystemExit("нет строки заливки yc в %s" % SRC)
    if "10.0f" not in m.group(0):
        raise SystemExit("строка заливки не в десятых: %s" % m.group(0).strip())
    return m.group(0).strip()


def main():
    print("PUNCH: сверка с четырьмя кадрами владельца и проверка линии")
    print("  строка заливки: %s" % c_row_scale())
    print("  константы: T1 %d T2 %d центр %d кончики %d/%d диагональ %d"
          % (T1, T2, CENT, TIP0, TIP1, DIAG))

    worst = 0
    for k, q in enumerate((0, 16, 33, 50)):
        mine = punch_frame(q)
        theirs = his(k)
        diff = sum(1 for y in range(ART) for x in range(ART) if mine[y][x] != theirs[y][x])
        ink = sum(map(sum, mine))
        ref = sum(map(sum, theirs))
        worst = max(worst, diff)
        print("  кадр %d (q = %2d): %3d расхождений, чернил %d против %d" % (k + 1, q, diff, ink, ref))
        if diff > TOLERANCE:
            raise SystemExit("  кадр %d разошёлся сильнее допуска %d" % (k + 1, TOLERANCE))

    # Толщина по строкам: на диагонали три пикселя, на прямой стороне два.
    g = punch_frame(0)
    diag = [runs(g, y) for y in (4, 6, 8, 10)]
    flat = [runs(g, y) for y in (20, 22)]
    bad = [r for r in diag if any(v != 3 for v in r)]
    if bad:
        raise SystemExit("  диагональ не в три пикселя: %s" % diag)
    bad = [r for r in flat if any(v != 2 for v in r)]
    if bad:
        raise SystemExit("  прямая сторона не в два пикселя: %s" % flat)
    print("  толщина: диагональ по 3, прямая сторона по 2 — как у него")

    # Симметрия: поворот на четверть и три отражения.
    for q in (0, 8, 17, 25, 33, 42, 50):
        g = punch_frame(q)
        if rotated(g) != g:
            raise SystemExit("  q = %d: фигура не сходится при повороте на четверть" % q)
        for axis in ("x", "y", "d"):
            if mirrored(g, axis) != g:
                raise SystemExit("  q = %d: фигура не сходится при отражении по %s" % (q, axis))
    print("  симметрия: поворот на четверть и все отражения сходятся на семи положениях")

    print("OK: PUNCH — кольцо режется в лучи, худший кадр расходится на %d точек" % worst)
    return 0


if __name__ == "__main__":
    sys.exit(main())
