# -*- coding: utf-8 -*-
"""Подстановка чисел выпуска в заметки: размер и хеш образа, размер и хеш архива исходников.

Числа берутся из tools/webflash/manifest.json и tools/webflash/sources.json — то есть из
тех же файлов, по которым живёт страница записи. Руками в заметках не остаётся ни одного
числа, которое может разойтись с раздачей.
"""
import io
import json
import sys

sys.stdout.reconfigure(encoding="utf-8")

manifest = json.load(io.open("tools/webflash/manifest.json", encoding="utf-8"))
sources = json.load(io.open("tools/webflash/sources.json", encoding="utf-8"))

image = manifest.get("image", {})
values = {
    "{{IMAGE_SIZE}}": "{:,}".format(int(image.get("size", 0))).replace(",", " "),
    "{{IMAGE_SHA}}": str(image.get("sha256", "")).upper(),
    "{{SRC_SIZE}}": "{:,}".format(int(sources.get("size", 0))).replace(",", " "),
    "{{SRC_SHA}}": str(sources.get("sha256", "")).upper(),
}

left = 0
for path in ("docs/RELEASE-NOTES.md", "docs/RELEASE-NOTES.en.md"):
    t = io.open(path, encoding="utf-8").read()
    for key, value in values.items():
        t = t.replace(key, value)
    left += t.count("{{")
    io.open(path, "w", encoding="utf-8", newline="").write(t)

print("заметки: образ %s байт, %s" % (values["{{IMAGE_SIZE}}"], values["{{IMAGE_SHA}}"][:16]))
print("        архив %s байт, %s" % (values["{{SRC_SIZE}}"], values["{{SRC_SHA}}"][:16]))
if left:
    raise SystemExit("остались неподставленные поля: %d" % left)
