/*
 * Сборка справочника ИЗ ПРОШИВКИ.
 *
 *   node tools/site/reconcile.mjs
 *
 * Состав и порядок ручек каждого экрана берутся из таблиц KNOBS_* и PAGES[] в
 * components/synth_ui/synth_ui.c — это то, что на приборе на самом деле. Описания берутся из
 * прежнего справочника по имени ручки; для ручек, которых там не было, они выписаны здесь и
 * сверены с прошивкой (единицы и заводское значение — из synth_app_param_text()).
 *
 * Результат — tools/site/ref.js, из которого собираются страницы.
 */
import fs from 'node:fs';
import path from 'node:path';

const ROOT = path.resolve(import.meta.dirname, '..', '..');
const UI = path.join(ROOT, 'components', 'synth_ui', 'src', 'synth_ui.c');
const REF = path.join(ROOT, 'tools', 'site', 'ref.js');

const ui = fs.readFileSync(UI, 'utf8');
const old = fs.readFileSync(REF, 'utf8');

/* ── прежний справочник: описания по имени ручки и описания экранов ────────── */

const open = old.indexOf('var REF = [');
const close = old.indexOf('\n];', open);
const OLD = eval(old.slice(old.indexOf('[', open), close + 2));

const BY_NAME = new Map();
const SCREEN_DESC = new Map();
for (const fam of OLD) {
  for (const scr of fam.s) {
    SCREEN_DESC.set(scr.n, scr.d);
    for (const p of scr.p) { if (!BY_NAME.has(p[0])) { BY_NAME.set(p[0], p); } }
  }
}

/* ── прошивка: экраны в порядке карусели и их ручки ────────────────────────── */

const knobTables = {};
for (const m of ui.matchAll(/static const ui_knob_t (KNOBS_[A-Z0-9_]+)\[\]\s*=\s*\{([\s\S]*?)\n\};/g)) {
  knobTables[m[1]] = [...m[2].matchAll(/\{\s*"([^"]+)",\s*(SYNTH_PARAM_[A-Z0-9_]+)\s*\}/g)]
    .map((x) => ({ label: x[1], param: x[2] }));
}

const pagesBlock = /static const ui_page_t PAGES\[PAGE_COUNT\] = \{([\s\S]*?)\n\};/.exec(ui);
const PAGES = [...pagesBlock[1].matchAll(/\[\w+\]\s*=\s*\{\s*"([^"]*)",\s*"([^"]*)",\s*(KNOBS_[A-Z0-9_]+|NULL)/g)]
  .map((m) => ({ title: m[1], tag: m[2], knobs: m[3] === 'NULL' ? [] : (knobTables[m[3]] || []) }));

if (PAGES.length !== 25) { throw new Error('страниц в PAGES[] ' + PAGES.length); }

/* ── ручки, которых в прежнем справочнике не было ─────────────────────────── */

const NEW = {
  DRONE: {
    DRIFT: ['дрейф строя в центах: расстройка трёх регистров друг относительно друга. Ноль — ни одного цента, всё, что сохранено раньше, звучит как звучало']
  },
  LEAD: {
    SPREAD: ['разброс стерео в процентах: сколько разностного сигнала подмешано в стороны. Ноль — без разброса'],
    PW: ['ширина импульса в процентах: 50 % — меандр, ниже — узкий импульс. Действует только на форме SQR']
  },
  SCALE: {
    SPAN: ['сколько октав обходит генератор: одна, две или три. Заводское положение — две', [
      ['1 OCT', 'ноты стоят в одной октаве'],
      ['2 OCT', 'две октавы, заводское положение'],
      ['3 OCT', 'три октавы: самый широкий обход']
    ]]
  },
  BASS: {
    SNAP: ['щелчок в начале ноты, в процентах: сколько атаки подмешано к телу. Заводское — 35 %'],
    NOTE: ['смена ноты линии, −7…+7 полутонов: сдвиг идёт до прижатия к ладу, поэтому линия остаётся в складе'],
    SUB: ['доля саб-осциллятора под нотой, в процентах: на нуле саба нет']
  }
};

/* Описания экранов, которые изменились вместе с составом ручек. */
const NEW_SCREEN_DESC = {
  'DRONE': 'Форма волны трёх регистров, ширина, дрейф строя и то, следует ли дрон за лидом. База регистров — 55, 110 и 220 Гц; ручка ROOT её не двигает, строй достигается ладом.',
  'DRONE FLTR': 'Срез, резонанс и свип, общие для трёх регистров: скорость, глубина, слежение за высотой и форма угла.',
  'LEAD': 'Длина ноты, скольжение, форма волны, число голосов, разброс стерео и ширина импульса.',
  'BASS': 'Голос баса: заготовка, щелчок, смена ноты, затухание и доля саба. Линия идёт за темпом и транспозицией прибора; уровень части — на LEVELS, посылы — на страницах посылов.'
};

/* ── состав семей: какие экраны к какой семье относятся ───────────────────── */

const FAMILY = [
  ['Дрон', '#1976D2', ['DRONE', 'DRONE FLTR']],
  ['Модуляция', '#B6D400', ['LFO 1', 'LFO 2']],
  ['Лид', '#AB47BC', ['LEAD', 'LEAD TONE', 'LEAD ENV']],
  ['Генераторы', '#00796B', ['SCALE', 'LEAD EUCLID', 'LEAD ARP']],
  ['Перкуссия', '#2E7D32', ['PERC', 'PERC SEQ', 'PERC MIX']],
  ['Бас', '#D97700', ['BASS', 'RHYTHM']],
  ['Эффекты', '#E91E63', ['FX', 'DELAY', 'REVERB']],
  ['Микшер', '#5D4037', ['MASTER', 'LEVELS', 'REV SENDS', 'FX SENDS', 'DEL SENDS']],
  ['Пресеты и настройки', '#37474F', ['PRESET', 'SETUP']]
];

const byTitle = new Map(PAGES.map((p) => [p.title, p]));
const lines = [];
let knobs = 0;
let missing = 0;

lines.push('/*');
lines.push(' * Справочник OBOD: семьи → экраны → ручки.');
lines.push(' *');
lines.push(' * СОСТАВ И ПОРЯДОК РУЧЕК ВЫПИСАН ИЗ ПРОШИВКИ: таблицы KNOBS_* и PAGES[] в');
lines.push(' * components/synth_ui/src/synth_ui.c. Описания — для читателя; единицы и заводские');
lines.push(' * значения сверены с synth_app_param_text(). Собирается: node tools/site/reconcile.mjs.');
lines.push(' * Проверяется: node tools/promo-check.js — состав ручек обязан совпасть с прошивкой.');
lines.push(' */');
lines.push('');
lines.push('var REF = [');

FAMILY.forEach(([famName, colour, screens], fi) => {
  lines.push(`  { n: '${famName}', c: '${colour}', s: [`);
  screens.forEach((title, si) => {
    const page = byTitle.get(title);
    if (!page) { throw new Error('нет страницы прошивки ' + title); }
    const desc = NEW_SCREEN_DESC[title] || SCREEN_DESC.get(title) || '';
    lines.push(`    { n: '${title}', tag: '${page.tag}', d: ${JSON.stringify(desc)}, p: [`);

    page.knobs.forEach(({ label }) => {
      const prior = BY_NAME.get(label);
      const fresh = (NEW[title] || {})[label];
      const entry = fresh || (prior ? [prior[1], prior[2]] : null);
      if (!entry) {
        console.error('нет описания для ' + title + '/' + label);
        missing++;
        lines.push(`      ['${label}', ''],`);
        return;
      }
      knobs++;
      const parts = [`      ['${label}', ${JSON.stringify(entry[0])}`];
      if (entry[1] && entry[1].length) {
        parts.push(', [\n' + entry[1].map(([c, m]) => `        [${JSON.stringify(c)}, ${JSON.stringify(m)}]`).join(',\n') + '\n      ]');
      }
      parts.push('],');
      lines.push(parts.join(''));
    });

    lines.push('    ]},');
  });
  lines.push('  ]},');
  lines.push('');
});

lines.push('];');
lines.push('');

fs.writeFileSync(REF, lines.join('\n'));
console.log('справочник собран: ' + FAMILY.length + ' семей, ' + PAGES.length + ' экранов, ' +
            knobs + ' ручек' + (missing ? ', без описания ' + missing : ''));
