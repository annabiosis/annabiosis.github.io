/*
 * Сборка сайта-руководства OBOD из дизайн-системы.
 *
 *   node tools/site/build.mjs          собрать страницы в web/
 *   node tools/site/build.mjs --check  только сверить, что страницы соответствуют данным
 *
 * ДАННЫЕ ОДНИ. Справочник (семьи → экраны → ручки) читается из tools/site/ref.js — того
 * самого, что сверяет promo-check с таблицами KNOBS_* прошивки. Страницы собираются из него
 * СТАТИЧЕСКИ: на сайте нет ни таблицы данных, ни отрисовки в браузере, поэтому описание
 * ручки не может «потеряться» на одной странице и не может быть разным на двух.
 */
import fs from 'node:fs';
import path from 'node:path';
import { startPage, hwPage, changelogPage, flashPage } from './pages.mjs';

const ROOT = path.resolve(import.meta.dirname, '..', '..');
const WEB = path.join(ROOT, 'web');
const REF_FILE = path.join(ROOT, 'tools', 'site', 'ref.js');
const V = '20261112c';   /* версия ассетов в адресе: старый стиль не залипает */

/* ── данные ───────────────────────────────────────────────────────────────── */

const src = fs.readFileSync(REF_FILE, 'utf8');
const open = src.indexOf('var REF = [');
const close = src.indexOf('\n];', open);
const REF = eval(src.slice(src.indexOf('[', open), close + 2));

/* Семья справочника → страница сайта, класс цвета и код сектора прибора. Порядок — порядок
 * карты прибора: от тела к хранилищу. */
const FAMILIES = [
  { ref: 'Дрон',                file: 'ref-drone.html', fam: 'fam-drn', code: 'DRN' },
  { ref: 'Модуляция',           file: 'ref-lfo.html',   fam: 'fam-lfo', code: 'LFO' },
  { ref: 'Лид',                 file: 'ref-lead.html',  fam: 'fam-ld',  code: 'LD'  },
  { ref: 'Генераторы',          file: 'ref-time.html',  fam: 'fam-scl', code: 'GEN' },
  { ref: 'Перкуссия',           file: 'ref-perc.html',  fam: 'fam-prc', code: 'PRC' },
  { ref: 'Бас',                 file: 'ref-bass.html',  fam: 'fam-bas', code: 'BAS' },
  { ref: 'Эффекты',             file: 'ref-fx.html',    fam: 'fam-fx',  code: 'FX'  },
  { ref: 'Микшер',              file: 'ref-mix.html',   fam: 'fam-lvl', code: 'LVL' },
  { ref: 'Пресеты и настройки', file: 'ref-store.html', fam: 'fam-prs', code: 'PRS' }
];

const INTRO = {
  'Дрон': 'Три регистра, один общий фильтр и его свип. Дрон звучит сам, без нажатия клавиш; уровни регистров стоят только на LEVELS.',
  'Модуляция': 'Два независимых LFO. Каждый двигает свою ручку сам: приёмник, глубина, форма и скорость — и всё это едет в патче.',
  'Лид': 'Голос линии: длина ноты, скольжение, форма волны, фильтр и огибающая. Уровень — только на LEVELS.',
  'Генераторы': 'Лад, фигура линии и арпеджиатор — то, что решает, какие ноты звучат и в каком порядке.',
  'Перкуссия': 'Пять голосов удара, рисунок такта и баланс дорожек. Удар и его рисунок — разные экраны.',
  'Бас': 'Отдельная часть прибора: линия, её рисунок и связки. Одна нота в один момент, со своим фильтром из заготовки.',
  'Эффекты': 'Машина на десять эффектов, дилей на шесть алгоритмов и реверб. Стойка стоит после звука, до мастера.',
  'Микшер': 'Уровни частей, мастер с компрессором и три страницы посылов: что и куда уходит.',
  'Пресеты и настройки': 'Сто двадцать восемь слотов звука и служебные строки: чем прибор включается и как отвечает.'
};

const families = FAMILIES.map((f) => {
  const data = REF.find((x) => x.n === f.ref);
  if (!data) { throw new Error('в справочнике нет семьи ' + f.ref); }
  return { ...f, screens: data.s, intro: INTRO[f.ref] };
});

/* ── мелочи ───────────────────────────────────────────────────────────────── */

const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

const ICON_MOON = '<svg class="i-moon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>';
const ICON_SUN = '<svg class="i-sun" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><circle cx="12" cy="12" r="4.2"/><path d="M12 2v2.5M12 19.5V22M2 12h2.5M19.5 12H22M4.9 4.9l1.8 1.8M17.3 17.3l1.8 1.8M19.1 4.9l-1.8 1.8M6.7 17.3l-1.8 1.8" stroke-linecap="round"/></svg>';
const ICON_GRID = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>';
const ICON_SEARCH = '<svg class="search-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3" stroke-linecap="round"/></svg>';
const CARET = '<svg class="caret" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" aria-hidden="true"><path d="M9 6l6 6-6 6" stroke-linecap="round" stroke-linejoin="round"/></svg>';

const HEAD = (title, desc) => `<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
<meta name="theme-color" content="#060A09" />
<title>${esc(title)}</title>
<meta name="description" content="${esc(desc)}" />
<link rel="icon" href="assets/favicon.svg" type="image/svg+xml" />
<link rel="preconnect" href="https://fonts.googleapis.com" />
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@300;400;500;600;700&family=IBM+Plex+Mono:wght@400;500;600&display=swap" rel="stylesheet" />
<link rel="stylesheet" href="system/tokens.css?v=${V}" />
<link rel="stylesheet" href="system/base.css?v=${V}" />
<link rel="stylesheet" href="system/grid.css?v=${V}" />
<link rel="stylesheet" href="system/components.css?v=${V}" />
<script>
  (function () {
    try {
      var t = localStorage.getItem('obod-theme');
      if (!t) t = matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark';
      document.documentElement.dataset.theme = t;
    } catch (e) { document.documentElement.dataset.theme = 'dark'; }
  })();
</script>`;

function topbar(active) {
  const link = (href, label, key) =>
    `<a href="${href}"${active === key ? ' aria-current="page"' : ''}>${label}</a>`;

  return `<header class="topbar">
  <a class="brand" href="index.html">OBOD</a>
  <nav class="topnav" aria-label="Документация">
    ${link('index.html', 'Обзор', 'index')}
    ${link('start.html', 'Первый запуск', 'start')}
    ${link('ref-drone.html', 'Справочник', 'ref')}
    ${link('hw.html', 'Железо', 'hw')}
    ${link('flash.html', 'Прошивка', 'flash')}
    ${link('changelog.html', 'История', 'log')}
  </nav>
  <div class="topbar-actions">
    <button class="icon-btn theme-toggle" data-theme-toggle type="button" title="Переключить тему" aria-label="Переключить светлую и тёмную тему">${ICON_MOON}${ICON_SUN}</button>
  </div>
</header>`;
}

function tree(current) {
  const groups = families.map((f) => {
    const isHere = f.file === current;
    const rows = f.screens.map((s) =>
      `            <li><a class="tree-link" href="${f.file}#${s.tag.toLowerCase()}"><span class="tag">${s.tag}</span>${esc(s.n)}</a></li>`
    ).join('\n');

    return `        <details class="tree-group ${f.fam}"${isHere ? ' open' : ''}>
          <summary>${CARET}${esc(f.ref)}<span class="grp-code">${f.code}</span></summary>
          <ul class="tree-list">
${rows}
          </ul>
        </details>`;
  }).join('\n');

  return `      <div class="doc-tree">
        <div class="search" style="margin-bottom:var(--sp-3)">
          ${ICON_SEARCH}
          <input class="input" type="search" placeholder="Найти экран…" data-tree-filter=".tree" aria-label="Поиск по дереву разделов" />
        </div>
        <nav class="tree" aria-label="Разделы прибора">
${groups}
        </nav>
      </div>`;
}

function footer() {
  return `<footer class="footer">
  <div class="wrap">
    <div class="f-col">
      <span class="f-title">OBOD</span>
      <p class="f-note">Синтезатор-контроллер на ESP32-S3 с круглым экраном 360 × 360. Голосовой движок — ESP32Synth 2.5.0 (MIT, © 2025 Danilo Gabriel); остальное написано для этого прибора.</p>
    </div>
    <div class="f-col">
      <span class="f-title">Документация</span>
      <a href="start.html">Первый запуск</a>
      <a href="ref-drone.html">Справочник</a>
      <a href="changelog.html">История изменений</a>
    </div>
    <div class="f-col">
      <span class="f-title">Прибор</span>
      <a href="hw.html">Железо</a>
      <a href="flash.html">Прошивка</a>
      <a href="hw.html">Железо</a>
    </div>
  </div>
</footer>`;
}

/* ── страница с деревом ───────────────────────────────────────────────────── */

function shell({ title, desc, active, file, body, toc = [], extraScripts = false }) {
  const tocItems = toc.map(([id, label]) =>
    `          <li><a class="toc-link" href="#${id}">${esc(label)}</a></li>`).join('\n');

  const scripts = extraScripts
    ? `<script type="module" src="https://unpkg.com/esp-web-tools@10.4.0/dist/web/install-button.js?module"></script>
<script src="assets/unlock.js?v=${V}"></script>
<script src="assets/sources.js?v=${V}"></script>`
    : '';

  return `<!DOCTYPE html>
<html lang="ru" data-theme="dark">
<head>
${HEAD(title, desc)}
</head>
<body>
<a class="skip-link" href="#main">К содержимому</a>

${topbar(active)}

<main id="main">
  <div class="wrap">
    <div class="doc">
${tree(file)}

${body}

      <div class="doc-toc">
        <div class="toc-title">На этой странице</div>
        <ul class="toc">
${tocItems}
        </ul>
      </div>

    </div>
  </div>
</main>

${footer()}

<script src="system/ui.js?v=${V}"></script>
<script src="assets/deep-link.js?v=${V}"></script>
${scripts}
</body>
</html>`;
}

/* ── справочник ───────────────────────────────────────────────────────────── */

function paramRow(p) {
  const [name, text, values] = p;
  let valuesCell;

  if (values && values.length) {
    const opts = values.map(([code, meaning]) =>
      `<li class="opt"><b>${esc(code)}</b><span>${esc(meaning)}</span></li>`).join('\n');
    valuesCell = `<ul class="opt-list">\n${opts}\n</ul>`;
  } else {
    valuesCell = '<span class="mono muted" style="font-size:var(--fs-13)">непрерывная шкала</span>';
  }

  return `                    <tr>
                      <td class="p-name"><span class="param-code">${esc(name)}</span></td>
                      <td>${esc(text)}</td>
                      <td>${valuesCell}</td>
                    </tr>`;
}

function screenSection(scr, first) {
  const id = scr.tag.toLowerCase();

  return `          <div class="tabpanel" role="tabpanel" id="panel-${id}" aria-labelledby="tab-${id}"${first ? '' : ' hidden'}>
            <section id="${id}">
              <h2 style="font-size:var(--fs-28);margin-bottom:var(--sp-2)">Экран ${esc(scr.n)}</h2>
              <p class="muted" style="max-width:var(--measure);margin-bottom:${scr.a ? 'var(--sp-4)' : 'var(--sp-5)'}">${esc(scr.d || '')}</p>
${(scr.a || []).map(([what, does]) => `              <p class="muted" style="max-width:var(--measure);margin-bottom:var(--sp-2)"><b class="param-code" style="font-family:inherit">${esc(what)}</b> — ${esc(does)}</p>`).join('\n')}
${scr.a ? '              <div style="height:var(--sp-4)"></div>' : ''}
${scr.p.length ? `              <div class="table-scroll">
                <table class="param-table">
                  <thead><tr><th>Ручка</th><th>Описание</th><th>Значения</th></tr></thead>
                  <tbody>
${scr.p.map(paramRow).join('\n')}
                  </tbody>
                </table>
              </div>` : ''}
            </section>
          </div>`;
}

function referencePage(f) {
  const tabs = f.screens.map((s, i) =>
    `            <button class="tab" role="tab" id="tab-${s.tag.toLowerCase()}" aria-controls="panel-${s.tag.toLowerCase()}" aria-selected="${i === 0}"${i === 0 ? '' : ' tabindex="-1"'} type="button">${esc(s.n)}</button>`).join('\n');

  const panels = f.screens.map((s, i) => screenSection(s, i === 0)).join('\n\n');
  const toc = f.screens.map((s) => [s.tag.toLowerCase(), 'Экран ' + s.n]);

  const body = `      <article class="doc-main ${f.fam}">
        <nav class="crumbs" aria-label="Хлебные крошки">
          <a href="index.html">OBOD</a><span class="sep">/</span>
          <a href="ref-drone.html">Справочник</a><span class="sep">/</span>
          <span aria-current="page">${esc(f.ref)}</span>
        </nav>

        <div style="display:flex;align-items:center;gap:var(--sp-3);flex-wrap:wrap">
          <h1 style="font-size:var(--fs-48);font-weight:300">${esc(f.ref)}</h1>
          <span class="chip"><span class="dot"></span>${f.code}</span>
        </div>
        <p class="lead muted" style="font-size:var(--fs-18);margin-top:var(--sp-3);max-width:var(--measure)">${esc(f.intro)}</p>

        <div data-tabs style="margin-top:var(--sp-6)">
          <div class="tabs" role="tablist" aria-label="Экраны раздела ${esc(f.ref)}">
${tabs}
          </div>

${panels}
        </div>
      </article>`;

  return shell({
    title: 'OBOD — ' + f.ref + ' · Справочник',
    desc: f.ref + ': ' + f.screens.map((s) => s.n).join(', ') + '.',
    active: 'ref',
    file: f.file,
    body,
    toc
  });
}

/* ── обзор ────────────────────────────────────────────────────────────────── */

function overviewPage() {
  const ring = families.map((f, i) =>
    `          <circle cx="100" cy="100" r="82" fill="none" stroke="var(--${f.fam}-ink)" stroke-width="7" stroke-dasharray="47 468" stroke-dashoffset="${-i * 57}" stroke-linecap="round" transform="rotate(-90 100 100)"/>`).join('\n');

  const cards = families.map((f) => `        <div class="col-4 col-md-3">
          <a class="card fam-card ${f.fam}" href="${f.file}">
            <div class="fam-top"><span class="chip"><span class="dot"></span>${f.code}</span></div>
            <div class="nm">${esc(f.ref)}</div>
            <div class="ds">${esc(f.intro)}</div>
            <div class="fam-meta">${f.screens.map((s) => esc(s.n)).join(' · ')} — ${f.screens.length} ${f.screens.length === 1 ? 'экран' : (f.screens.length < 5 ? 'экрана' : 'экранов')}</div>
          </a>
        </div>`).join('\n');

  return `<!DOCTYPE html>
<html lang="ru" data-theme="dark">
<head>
${HEAD('OBOD — обзор прибора', 'OBOD — круглый синтезатор-контроллер: дрон, лид, бас и перкуссия под одной ручкой. Девять разделов, двадцать пять экранов.')}
</head>
<body>
<a class="skip-link" href="#main">К содержимому</a>

${topbar('index')}

<main id="main">

<section class="hero">
  <div class="wrap">
    <div class="hero-grid" style="grid-template-columns:minmax(0,1fr)">
      <div>
        <span class="eyebrow">Круглый синтезатор-контроллер</span>
        <h1>Дрон, лид, бас и перкуссия — <span class="accent">одна ручка.</span></h1>
        <p class="lead">OBOD — прибор на ESP32-S3 с круглым экраном 360 × 360. Колесо-обод меняет выбранную ручку, касание выбирает ручку или экран, удержание назначает ручку в макрос. Девять разделов, у каждого своя семья цвета.</p>
        <div class="hero-actions">
          <a class="btn btn-primary btn-lg" href="flash.html">Установить</a>
          <a class="btn btn-outline btn-lg" href="start.html">Первый запуск</a>
          <a class="btn btn-ghost btn-lg" href="ref-drone.html">Справочник</a>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="section" id="control">
  <div class="wrap">
    <div class="section-head">
      <span class="eyebrow">Как играть</span>
      <h2>Три жеста — весь прибор</h2>
    </div>
    <div class="grid">
      <div class="col-4"><div class="card"><span class="eyebrow">Поворот</span>
        <h3 style="font-size:var(--fs-22);margin:var(--sp-3) 0 var(--sp-2)">Колесо меняет ручку</h3>
        <p class="muted" style="font-size:var(--fs-14)">Обод вращает выбранную ручку. Подпись на экране называет значение и единицы — проценты, полутона, доли такта.</p></div></div>
      <div class="col-4"><div class="card"><span class="eyebrow">Касание</span>
        <h3 style="font-size:var(--fs-22);margin:var(--sp-3) 0 var(--sp-2)">Выбор ручки и экрана</h3>
        <p class="muted" style="font-size:var(--fs-14)">Касание выбирает ручку или экран. Карта разделов открывает любое семейство без паузы.</p></div></div>
      <div class="col-4"><div class="card"><span class="eyebrow">Удержание</span>
        <h3 style="font-size:var(--fs-22);margin:var(--sp-3) 0 var(--sp-2)">Ручка уходит в макрос</h3>
        <p class="muted" style="font-size:var(--fs-14)">Длинное нажатие назначает ручку в макро: одно движение меняет несколько параметров сразу.</p></div></div>
    </div>
  </div>
</section>

<section class="section" id="map">
  <div class="wrap">
    <div class="section-head">
      <span class="eyebrow">Карта прибора</span>
      <h2>Девять разделов</h2>
      <p class="lead">Порядок — порядок карты: от тела к хранилищу. Код сектора рядом с названием помогает найти страницу по экрану.</p>
    </div>
    <div class="grid grid-tight">
${cards}
    </div>
  </div>
</section>

<section class="section" id="start">
  <div class="wrap">
    <div class="section-head">
      <span class="eyebrow">Документация</span>
      <h2>С чего начать</h2>
    </div>
    <div class="grid">
      <div class="col-4"><a class="card tpl-card" href="start.html"><div class="nm">Первый запуск</div><div class="ds">Питание, обод и жесты, транспорт, сохранение пресета и клавиатура.</div><div class="fam-meta">руководство · 5 шагов</div></a></div>
      <div class="col-4"><a class="card tpl-card" href="changelog.html"><div class="nm">История изменений</div><div class="ds">Выпуски от нового к старому: новое, улучшения и исправления.</div><div class="fam-meta">актуальный выпуск · 1.3.0</div></a></div>
      <div class="col-4"><a class="card tpl-card" href="hw.html"><div class="nm">Железо</div><div class="ds">Что внутри корпуса, разъёмы, питание и чем прибор дышит.</div><div class="fam-meta">ESP32-S3R8 · 8 МБ PSRAM</div></a></div>
    </div>
  </div>
</section>

</main>

${footer()}

<script src="system/ui.js?v=${V}"></script>
</body>
</html>`;
}

/* ── запись ───────────────────────────────────────────────────────────────── */

const out = new Map();
out.set('index.html', overviewPage());
for (const f of families) { out.set(f.file, referencePage(f)); }
out.set('start.html', startPage(shell, esc));
out.set('hw.html', hwPage(shell, esc));
out.set('changelog.html', changelogPage(shell, esc));
out.set('flash.html', flashPage(shell, esc));

const check = process.argv.includes('--check');
let drift = 0;

for (const [name, html] of out) {
  const p = path.join(WEB, name);
  const old = fs.existsSync(p) ? fs.readFileSync(p, 'utf8') : '';
  if (old === html) { continue; }
  drift++;
  if (!check) { fs.writeFileSync(p, html); }
  console.log((check ? 'устарело: ' : 'записано: ') + name);
}

console.log(check
  ? (drift ? 'страниц не совпадает с данными: ' + drift : 'страницы совпадают с данными')
  : 'собрано страниц: ' + out.size);
process.exit(check && drift ? 1 : 0);
