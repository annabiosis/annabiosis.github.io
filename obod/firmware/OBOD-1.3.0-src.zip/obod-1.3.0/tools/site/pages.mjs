/*
 * Страницы, которые не собираются из справочника: запуск, железо, история.
 *
 * ДАННЫЕ ЗДЕСЬ — ВЫПИСКА ИЗ ПРИБОРА И ВЫПУСКА, и она сверяется:
 *   запуск  — поведение прошивки (AUTOPLAY, STOP, запись патча);
 *   железо  — docs/HARDWARE.md;
 *   история — tools/webflash/changelog.json, который собирается из CHANGELOG.md.
 */
import fs from 'node:fs';
import path from 'node:path';

const ROOT = path.resolve(import.meta.dirname, '..', '..');

const STEP_ICON = () => '<span class="step-num"></span>';

export function startPage(shell, esc) {
  const steps = [
    ['Включение', `
      <p>Питание — по USB-C. Прибор загружается, показывает заставку и открывает карту разделов: два кольца и девять семейств. Карта считается один раз при загрузке и открывается без паузы.</p>
      <p>Дрон звучит сам, без нажатия клавиш. Играть ли транспорту при включении, решает AUTOPLAY в SETUP: <b>ON</b> — заводское, транспорт стартует сразу; <b>OFF</b> — прибор включается молча; <b>STORE</b> — возвращает то состояние, в котором его выключили.</p>`],
    ['Обод и жесты', `
      <p>Колесо-обод вращает выбранную ручку. Подпись на экране называет значение и единицы: проценты, полутона, доли такта.</p>
      <ul>
        <li><b>Касание</b> выбирает ручку или сектор.</li>
        <li><b>Долгое нажатие</b> назначает ручку в макрос; двойное касание в макросе — переворот.</li>
        <li><b>Свайп вверх</b> открывает карту разделов, <b>свайп вниз</b> — транспортную шторку.</li>
      </ul>`],
    ['Транспорт', `
      <p>PLAY и STOP ведут себя как на драм-машине. STOP закрывает выход, но секвенсоры продолжают идти: после пуска линия входит в свою долю, а не начинает такт заново.</p>
      <p>Темп крутится на транспортной шторке, там же кнопка PRESET. Приём нот по USB-MIDI приносит и часы.</p>`],
    ['Пресет', `
      <p>Звук пишется в память, когда транспорт остановлен: запись во флеш встаёт в звук, и поэтому она ждёт STOP. Настройки пишутся сразу.</p>
      <p>Слотов 128. RND в PRESET собирает случайный звук, а RANDOM в SETUP решает, каким прибор включится — заводским, последним или новым каждый раз.</p>`],
    ['Клавиатура', `
      <p>Прибор понимает USB-MIDI: ноты, аккорды и часы. Пришедшие ноты прижимаются к ступеням выбранного лада, а дрон и бас идут за той же тоникой.</p>
      <p>Пока приём нот включён, отладочного COM-порта на кабеле нет: единственный USB-контроллер занят. Порт вернётся после выключения приёма и перезагрузки.</p>`]
  ];

  const body = `      <article class="doc-main">
        <nav class="crumbs" aria-label="Хлебные крошки">
          <a href="index.html">OBOD</a><span class="sep">/</span>
          <span aria-current="page">Первый запуск</span>
        </nav>

        <span class="eyebrow">Руководство</span>
        <h1 style="font-size:var(--fs-48);font-weight:300;margin-top:var(--sp-2)">Первый запуск</h1>
        <p class="lead muted" style="font-size:var(--fs-18);margin-top:var(--sp-3);max-width:var(--measure)">От питания до первого сохранённого пресета — пять шагов, чтобы начать играть на OBOD.</p>

        <div class="note note-info" style="margin-top:var(--sp-6)">
          <div class="note-title">Перед началом</div>
          <p>Убедитесь, что прошита актуальная версия: обновление — на странице <a href="flash.html">прошивки</a>. Образ больше мегабайта, поэтому не отключайте питание во время записи.</p>
        </div>

        <div class="steps" style="margin-top:var(--sp-7)">
${steps.map(([title, text], i) => `          <div class="step" id="step-${i + 1}">
            ${STEP_ICON()}
            <div class="step-body">
              <h3>${esc(title)}</h3>
              ${text}
            </div>
          </div>`).join('\n')}
        </div>
      </article>`;

  return shell({
    title: 'OBOD — первый запуск',
    desc: 'Включение, обод и жесты, транспорт, пресет и клавиатура: пять шагов от питания до своего звука.',
    active: 'start',
    file: 'start.html',
    body,
    toc: steps.map(([t], i) => ['step-' + (i + 1), t])
  });
}

export function hwPage(shell, esc) {
  const rows = [
    ['Процессор', 'ESP32-S3R8, два ядра LX7 на 240 МГц'],
    ['Память', '16 МБ QIO flash, 8 МБ Octal PSRAM'],
    ['Экран', '1.85″ IPS, 360 × 360, ламинация, ST77916 по QSPI'],
    ['Ввод', 'ёмкостный тач CST816S и энкодер; кнопки нет'],
    ['Выход', 'кольцо RGB, динамик через PCM5100A, мотор DRV2605L'],
    ['Микрофон', 'цифровой I2S: такт на GPIO5, данные на GPIO4'],
    ['Хранилище', 'microSD по SDMMC, четыре линии'],
    ['Питание', 'USB-C; заряд и батарея — АЦП на GPIO6']
  ];

  const notes = [
    ['Кнопки нет', 'На энкодере нет нажимной кнопки, и в демо-прошивке платы её обработка — мёртвый код. Весь интерфейс держится на колесе, касании и удержании: ENTER в LVGL не приходит никогда.'],
    ['Кольцо на strapping-пине', 'Данные кольца идут по GPIO0, а это загрузочный вывод. Кольцо нельзя тянуть до конца загрузки, иначе прибор не стартует.'],
    ['Одна шина на двоих', 'Тач CST816S и мотор DRV2605L сидят на одной шине I2C (GPIO9 и GPIO10). Мотор, включённый во время чтения тача, портит пакет.'],
    ['Звук без настройки', 'PCM5100A не требует ни I2C, ни MCLK: такт он восстанавливает из I2S. Глушение — вывод XSMT, активный низкий.'],
    ['Память под звук', 'Восемь мегабайт PSRAM заняты дилеем, ревербом, плитой и картой разделов. Звук и экран делят одну шину, поэтому кадр на анимированных страницах обновляется двадцать раз в секунду.']
  ];

  const body = `      <article class="doc-main">
        <nav class="crumbs" aria-label="Хлебные крошки">
          <a href="index.html">OBOD</a><span class="sep">/</span>
          <span aria-current="page">Железо</span>
        </nav>

        <span class="eyebrow">Прибор</span>
        <h1 style="font-size:var(--fs-48);font-weight:300;margin-top:var(--sp-2)">Железо</h1>
        <p class="lead muted" style="font-size:var(--fs-18);margin-top:var(--sp-3);max-width:var(--measure)">Что внутри корпуса и чем прибор дышит.</p>

        <div class="table-scroll" id="what" style="margin-top:var(--sp-6)">
          <table class="param-table">
            <thead><tr><th>Узел</th><th>Что стоит</th></tr></thead>
            <tbody>
${rows.map(([k, v]) => `              <tr><td class="p-name"><span class="param-code">${esc(k)}</span></td><td>${esc(v)}</td></tr>`).join('\n')}
            </tbody>
          </table>
        </div>

        <p class="muted" style="margin-top:var(--sp-6);font-size:var(--fs-14)">Полная распиновка и оговорки производителя — в репозитории, файл <span class="mono">docs/HARDWARE.md</span>.</p>
      </article>`;

  return shell({
    title: 'OBOD — железо',
    desc: 'ESP32-S3R8, 8 МБ PSRAM, экран 360 × 360, тач, энкодер без кнопки, ЦАП PCM5100A, мотор DRV2605L.',
    active: 'hw',
    file: 'hw.html',
    body,
    toc: [['what', 'Что стоит']]
  });
}

export function changelogPage(shell, esc) {
  const json = JSON.parse(fs.readFileSync(path.join(ROOT, 'tools', 'webflash', 'changelog.json'), 'utf8'));
  const versions = json.versions;

  const classes = { 'Новое': 'rs-add', 'Улучшения': 'rs-imp', 'Исправления': 'rs-fix', 'Изменения': 'rs-imp' };

  const blocks = versions.map((v, idx) => {
    const current = idx === 0;
    const sections = (v.sections || []).map((s) => `          <div class="release-section ${classes[s.title] || 'rs-imp'}">
            <h3>${esc(s.title)}</h3>
            <ul>
${s.items.map((i) => `              <li>${esc(i)}</li>`).join('\n')}
            </ul>
          </div>`).join('\n');

    return `        <section class="release" id="v${esc(v.version)}">
          <div class="release-head">
            <h2>${esc(v.version)}</h2>
            ${current ? '<span class="badge badge-accent">актуальная</span>' : ''}
            ${v.date ? `<span class="release-date">${esc(v.date)}</span>` : ''}
          </div>
${sections}
        </section>`;
  }).join('\n');

  const toc = versions.map((v) => ['v' + v.version, v.version + (v.date ? ' · ' + v.date : '')]);

  const body = `      <article class="doc-main">
        <nav class="crumbs" aria-label="Хлебные крошки">
          <a href="index.html">OBOD</a><span class="sep">/</span>
          <span aria-current="page">История изменений</span>
        </nav>

        <span class="eyebrow">Прошивка</span>
        <h1 style="font-size:var(--fs-48);font-weight:300;margin-top:var(--sp-2)">История изменений</h1>
        <p class="lead muted" style="font-size:var(--fs-18);margin-top:var(--sp-3);max-width:var(--measure)">Выпуски от нового к старому: что стало иначе в приборе и что это ему дало.</p>

${blocks}
      </article>`;

  return shell({
    title: 'OBOD — история изменений',
    desc: 'Все выпуски прошивки OBOD: новое, улучшения и исправления — коротко и по делу.',
    active: 'log',
    file: 'changelog.html',
    body,
    toc
  });
}


export function flashPage(shell, esc) {
  const body = `      <article class="doc-main">
        <nav class="crumbs" aria-label="Хлебные крошки">
          <a href="index.html">OBOD</a><span class="sep">/</span>
          <span aria-current="page">Прошивка</span>
        </nav>

        <span class="eyebrow">Прибор</span>
        <h1 style="font-size:var(--fs-48);font-weight:300;margin-top:var(--sp-2)">Прошивка</h1>
        <p class="lead muted" style="font-size:var(--fs-18);margin-top:var(--sp-3);max-width:var(--measure)">Новый выпуск записывается из браузера и открывается кодом выпуска. Образ на сайте лежит запечатанным; что изменилось в выпуске — в <a href="changelog.html#v1.3.0">истории изменений</a>.</p>

        <div class="note note-info" style="margin-top:var(--sp-6)">
          <div class="note-title">Что нужно</div>
          <p>Chrome или Edge на компьютере, кабель USB-C и код выпуска. Код чувствителен к регистру и знакам; страница выводит ключ из кода и расшифровывает образ здесь, в браузере: на прибор уходит уже открытый образ, а на диск не сохраняется ничего.</p>
        </div>

        <div class="card" style="margin-top:var(--sp-4);padding:var(--sp-5)">
          <span class="eyebrow">Где взять код</span>
          <h3 style="font-size:var(--fs-22);margin:var(--sp-2) 0 var(--sp-2)">Пост на Boosty</h3>
          <p class="muted" style="max-width:var(--measure);font-size:var(--fs-16)">Код разблокировки лежит в постах для подписчиков: любой уровень подписки открывает пост с кодом к актуальной прошивке. Код один на выпуск и одинаковый для всех, кому выпуск доступен.</p>
          <p style="margin-top:var(--sp-3);display:flex;gap:var(--sp-3);align-items:center;flex-wrap:wrap">
            <a class="btn btn-primary" href="https://boosty.to/annabiosis" rel="noopener">Подписаться на Boosty</a>
            <a href="https://boosty.to/annabiosis" rel="noopener" class="mono" style="font-size:var(--fs-14)">boosty.to/annabiosis</a>
          </p>
        </div>

        <form class="unlock" id="unlock" autocomplete="off"
              data-lock="../tools/webflash/lock.json"
              data-sealed="../tools/webflash/firmware/OBOD.bin.enc"
              data-manifest="../tools/webflash/manifest.json"
              style="margin-top:var(--sp-6)">
          <div class="field">
            <label class="field-label" for="code">Код выпуска</label>
            <div style="display:flex;gap:var(--sp-2);flex-wrap:wrap">
              <input class="input" id="code" name="code" type="text" spellcheck="false" autocomplete="off"
                     autocapitalize="off" placeholder="код из поста Boosty" aria-describedby="unlock-note" style="min-width:min(420px,100%)" />
              <button class="btn btn-primary" type="submit">Открыть образ</button>
            </div>
            <p class="field-hint" id="unlock-note">Код чувствителен к регистру и знакам. Если замок не открывается, проверьте код в посте — он один на выпуск.</p>
          </div>
        </form>

        <p id="flash-status" class="flash-status" role="status" aria-live="polite" style="margin-top:var(--sp-4)"></p>

        <div style="margin-top:var(--sp-4)">
          <esp-web-install-button id="installer" hidden>
            <button slot="activate" class="btn btn-primary btn-lg">Записать прошивку</button>
            <span slot="unsupported" class="muted">Этот браузер не умеет прошивать по USB — откройте страницу в Chrome или Edge.</span>
            <span slot="not-allowed" class="muted">Страница должна быть открыта по HTTPS, чтобы браузер дал доступ к порту.</span>
          </esp-web-install-button>
        </div>

        <p id="flash-meta" class="muted" style="margin-top:var(--sp-3);font-size:var(--fs-14)">Версия, размер и контрольная сумма образа появятся здесь после открытия кода.</p>

        <h2 id="lost" style="font-size:var(--fs-28);margin-top:var(--sp-7)">Что теряется</h2>
        <p style="max-width:var(--measure)">Браузерная запись пишет образ одним куском от начала флеша, поэтому служебная область настроек попадает под стирание: пресеты и настройки при такой прошивке теряются. Командная строка (<span class="mono">idf.py flash</span>) пишет части по своим адресам и настроек не касается.</p>
        <div class="note note-warn" style="margin-top:var(--sp-4)">
          <div class="note-title">Перед записью</div>
          <p>Сохраните нужные пресеты на компьютер, если они важны, и не отключайте питание до конца записи.</p>
        </div>

        <h2 id="sources" style="font-size:var(--fs-28);margin-top:var(--sp-7)">Исходники выпуска</h2>
        <p style="max-width:var(--measure)">Архив исходников лежит рядом, без защиты: код выпуска нужен только образу.</p>
        <p class="mono muted" data-sources="../tools/webflash/sources.json" style="font-size:var(--fs-13)">размер и SHA-256 архива появятся здесь</p>
      </article>`;

  return shell({
    title: 'OBOD — прошивка',
    desc: 'Запись прошивки OBOD из браузера: код выпуска, запечатанный образ, исходники и что при этом теряется.',
    active: 'flash',
    file: 'flash.html',
    extraScripts: true,
    body,
    toc: [['lost', 'Что теряется'], ['sources', 'Исходники выпуска']]
  });
}
