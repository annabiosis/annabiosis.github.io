"""Фигура REVERB SIZE: сверяет прошивку с восемью кадрами владельца.

Эталоны здесь — сами кадры, упакованные побитно (44 x 44, по строке за строкой).
Гейт повторяет арифметику pv_verb_size(), собирает маску при тех положениях кноба,
которые попадают ровно в кадры, и сравнивает её с эталоном точка в точку.
"""
import io
import re
import struct
import sys

sys.stdout.reconfigure(encoding="utf-8")

SRC = io.open("components/synth_ui/src/synth_ui_preview.c", encoding="utf-8").read()
HDR = io.open("components/synth_ui/src/synth_ui_preview.h", encoding="utf-8").read()

problems = []

REF = [
    "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000007ffffe00000fffffe00001c0001e0000380003e00007fffff600007ffffe60000600006600006000066000060000660000600006600006000066000060000660000600006600006000066000060000660000600006600006000066000060000660000600006600006000066000060000660000600006e0000600007c0000600007800007fffff000007ffffe000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",  # кадр 1
    "00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003fffff000007fffff00000e0000f00001c0001f0000380003b000070000730000fffffe30000fffffc30000c0000c30000c0000c30000c0000c30000c0000c30000c0000c30000c0000c30000c0000c30000c0000c30000c0000c30000c0000c30000c0000c30000c0000c30000c0000c30000c0000c70000c0000ce0000c0000dc0000c0000f80000c0000f00000fffffe00000fffffc0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",  # кадр 2
    "0000000000000000000000000000000000000000000000000000000000000000000000fffffc00001fffffc0000380003c0000700007c0000e0000ec0001c0001cc0003800038c0007000070c000e0000e0c001c0001c0c003fffff80c003fffff00c0030000300c0030000300c0030000300c0030000300c0030000300c0030000300c0030000300c0030000300c0030000300c0030000301c0030000303800300003070003000030e0003000031c0003000033800030000370000300003e0000300003c00003fffff800003fffff0000000000000000000000000000000000000000000000000000000000000000000000",  # кадр 3
    "000000000000000000000000000000000000000000000000000000000007ffffe00000fffffe00001c0001e0000380003e000070000760000e0000e60001c0001c60003800038600070000706000e0000e06001c0001c0600380003806007fffff006007ffffe006006000060060060000600600600006006006000060060060000600600600006006006000060060060000600e0060000601c0060000603800600006070006000060e0006000061c0006000063800060000670000600006e0000600007c0000600007800007fffff000007ffffe00000000000000000000000000000000000000000000000000000000000",  # кадр 4
    "0000000000000000000000000000000000000000000000003fffff000007fffff00000e0000f00001c0001f0000380003b000070000730000e0000e30001c0001c30003800038300070000703000e0000e03001c0001c03003800038030070000700300fffffe00300fffffc00300c0000c00300c0000c00300c0000c00300c0000c00300c0000c00300c0000c00700c0000c00e00c0000c01c00c0000c03800c0000c07000c0000c0e000c0000c1c000c0000c38000c0000c70000c0000ce0000c0000dc0000c0000f80000c0000f00000fffffe00000fffffc000000000000000000000000000000000000000000000000",  # кадр 5
    "00000000000000000000000000000000000001fffff800003fffff8000070000780000e0000f80001c0001d80003800039800070000718000e0000e18001c0001c18003800038180070000701800e0000e01801c0001c01803800038018070000700180e0000e00181fffffc00181fffff800181800018001818000180018180001800181800018003818000180070180001800e0180001801c0180001803801800018070018000180e0018000181c0018000183800180001870001800018e0001800019c000180001b8000180001f0000180001e00001fffffc00001fffff80000000000000000000000000000000000000",  # кадр 6
    "000000000000000000000000000fffffc00001fffffc0000380003c0000700007c0000e0000ec0001c0001cc0003800038c0007000070c000e0000e0c001c0001c0c0038000380c0070000700c00e0000e00c01c0001c00c0380003800c0700007000c0e0000e000c1c0001c000c3fffff8000c3fffff0000c3000030000c3000030001c3000030003830000300070300003000e0300003001c0300003003803000030070030000300e0030000301c0030000303800300003070003000030e0003000031c0003000033800030000370000300003e0000300003c00003fffff800003fffff000000000000000000000000000",  # кадр 7
    "00000000000000007ffffe00000fffffe00001c0001e0000380003e000070000760000e0000e60001c0001c60003800038600070000706000e0000e06001c0001c06003800038060070000700600e0000e00601c0001c00603800038006070000700060e0000e00061c0001c0006380003800067fffff000067ffffe0000e6000060001c6000060003860000600070600006000e0600006001c0600006003806000060070060000600e0060000601c0060000603800600006070006000060e0006000061c0006000063800060000670000600006e0000600007c0000600007800007fffff000007ffffe0000000000000000",  # кадр 8
]

AREA_X0 = int(re.search(r"#define\s+PV_AREA_X0\s+(\d+)", SRC).group(1))
AREA_Y0 = int(re.search(r"#define\s+PV_AREA_Y0\s+(\d+)", SRC).group(1))


def const(name):
    m = re.search(r"#define\s+%s\s+(-?\d+)" % name, SRC)
    if not m:
        problems.append("нет константы %s" % name)
        return 0
    return int(m.group(1))


FACE = const("PV_RS_FACE")
STAGES = const("PV_RS_STAGES")
AREA = const("PV_RS_AREA")

m = re.search(r"PV_RS_DEPTH\[PV_RS_STAGES\]\s*=\s*\{([^}]*)\}", SRC)
DEPTH = [int(v) for v in re.findall(r"\d+", m.group(1))] if m else []
if DEPTH != [4, 6, 10, 12, 14, 16, 18, 20]:
    problems.append("таблица глубин %s, а в кадрах 4/6/10/12/14/16/18/20" % DEPTH)
if FACE != 22 or AREA != 44 or STAGES != 8:
    problems.append("передняя грань/поле/число кадров не те: %d %d %d" % (FACE, AREA, STAGES))


def depth_at(q):
    x = q * 7
    i = x // 50
    if i >= STAGES - 1:
        d = DEPTH[STAGES - 1]
    else:
        f = x % 50
        d = DEPTH[i] + (DEPTH[i + 1] - DEPTH[i]) * f // 50
    d = (d + 1) & ~1
    return max(DEPTH[0], min(DEPTH[STAGES - 1], d))


def mask_at(q):
    d = depth_at(q)
    g = [[0] * 56 for _ in range(56)]
    off = (AREA - FACE - d) // 2
    x0 = AREA_X0 + off
    y0 = AREA_Y0 + off + d
    x1 = x0 + FACE - 1
    y1 = y0 + FACE - 1
    hi = x1 + d

    def run(xa, xb, y):
        for x in range(max(x0, xa), min(hi, xb) + 1):
            g[y][x] = 1

    def col(x, ya, yb):
        for y in range(ya, yb + 1):
            g[y][x] = 1

    run(x0, x1, y0)
    run(x0, x1, y0 + 1)
    run(x0, x1, y1 - 1)
    run(x0, x1, y1)
    col(x0, y0, y1)
    col(x0 + 1, y0, y1)
    col(x1 - 1, y0, y1)
    col(x1, y0, y1)
    run(x0 + d, x1 + d, y0 - d)
    run(x0 + d, x1 + d, y0 - d + 1)
    col(x1 + d - 1, y0 - d, y1 - d)
    col(x1 + d, y0 - d, y1 - d)
    for j in range(d):
        run(x0 + 1 + j, x0 + 3 + j, y0 - 1 - j)
        run(x1 + j, x1 + 2 + j, y0 - 1 - j)
        run(x1 - 1 + j, x1 + 1 + j, y1 - 1 - j)
    g[y0][x1 + 1] = 1
    return g


def unpack(hexstr):
    bits = "".join(format(b, "08b") for b in bytes.fromhex(hexstr))
    return [[1 if bits[y * 44 + x] == "1" else 0 for x in range(44)] for y in range(44)]


# положения кноба, попадающие ровно в кадры
QS = [0, 7, 14, 21, 29, 36, 43, 50]

for n, q in enumerate(QS):
    want = unpack(REF[n])
    mine = mask_at(q)
    a = [[mine[AREA_Y0 + y][AREA_X0 + x] for x in range(44)] for y in range(44)]
    diff = sum(1 for y in range(44) for x in range(44) if a[y][x] != want[y][x])
    if diff:
        problems.append("кадр %d (q=%d): маска расходится в %d точках" % (n + 1, q, diff))

# глубина чётная, поле по центру, поле не вылезает за 44
for q in range(0, 51):
    d = depth_at(q)
    if d % 2:
        problems.append("q=%d: глубина %d не чётная" % (q, d))
    if not DEPTH[0] <= d <= DEPTH[-1]:
        problems.append("q=%d: глубина %d вне кадров" % (q, d))
    off = (AREA - FACE - d) // 2
    if FACE + d + 2 * off != AREA:
        problems.append("q=%d: коробка не по центру поля" % q)
    mask = mask_at(q)
    for y in range(56):
        for x in range(56):
            if mask[y][x] and not (AREA_X0 <= x < AREA_X0 + 44 and AREA_Y0 <= y < AREA_Y0 + 44):
                problems.append("q=%d: точка (%d, %d) вне поля" % (q, x, y))
                break

# рост без откатов: габарит только растёт
prev = None
for q in range(0, 51):
    mask = mask_at(q)
    ys = [y for y in range(56) if any(mask[y])]
    xs = [x for x in range(56) if any(mask[y][x] for y in range(56))]
    size = (max(xs) - min(xs), max(ys) - min(ys))
    if prev is not None and size[0] < prev[0]:
        problems.append("q=%d: коробка сузилась" % q)
    prev = size

# --- куда поставлена ---------------------------------------------------------
if "PREVIEW_VERB_SIZE" not in HDR:
    problems.append("нет вида PREVIEW_VERB_SIZE в заголовке")

sw = SRC[SRC.index("static synth_preview_kind_t pv_values"):]
sw = sw[:sw.index("\n}\n")]
LABELS, pending = {}, []
for mm in re.finditer(r"case (SYNTH_PARAM_\w+):|return (PREVIEW_\w+);", sw):
    if mm.group(1):
        pending.append(mm.group(1))
    else:
        for label in pending:
            LABELS.setdefault(label, mm.group(2))
        pending = []

WANT = {
    "SYNTH_PARAM_VERB_SIZE": "PREVIEW_VERB_SIZE",
    "SYNTH_PARAM_VERB_DAMP": "PREVIEW_VERB_DAMP",
    "SYNTH_PARAM_VERB_MIX": "PREVIEW_NONE",
    "SYNTH_PARAM_SEND_LEAD": "PREVIEW_VERB_SECTOR",
}
for param, kind in WANT.items():
    if LABELS.get(param) != kind:
        problems.append("%s отдаёт %s, а должен %s" % (param, LABELS.get(param), kind))

if not re.search(r"case PREVIEW_VERB_SIZE:\s*pv_verb_size\(", SRC):
    problems.append("нет вызова pv_verb_size в переключателе")

if problems:
    print("FAIL: фигура REVERB SIZE")
    for p in problems:
        print("  -", p)
    sys.exit(1)

print("OK: REVERB SIZE — коробка 22 x 22 с глубиной 4..20, восемь кадров совпадают "
      "точка в точку, поле по центру, глубина только растёт; стоит на SIZE страницы "
      "REVERB, у MIX фигуры нет, посылы не тронуты")
