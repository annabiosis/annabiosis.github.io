"""Фигура TONE: кольцо на нитке, отражённое по вертикали и пущенное в обратном порядке.

Здесь повторена целочисленная арифметика прошивки и сверены его четыре кадра — отражённые и
взятые в обратном порядке: большой кадр отвечает низкому значению, маленький — высокому.
"""
import io
import re
import sys

sys.stdout.reconfigure(encoding="utf-8")

SRC = io.open("components/synth_ui/src/synth_ui_preview.c", encoding="utf-8").read()
HDR = io.open("components/synth_ui/src/synth_ui_preview.h", encoding="utf-8").read()

problems = []

ART = 44
CENTRE2 = 43          # удвоенный центр кольца по столбцу

# Его кадры, отражённые по вертикали: доля хода -> маска, 44 строки по 44 бита
HIS = {
    0: (
        "0000000000000000000000000006000000000060000000000600000000006000000000060000000000600000"
        "00000600000000006000000000060000000003fc00000001fff80000007c03e000000f000f000001c0003800"
        "00380001c0000700000e0000e0000070000c0000030001c000003800180000018001800000180030000000c0"
        "030000000c0030000000c0030000000c0030000000c0030000000c0030000000c0030000000c001800000180"
        "0180000018001c0000038000c0000030000e0000070000700000e0000380001c00001c0003800000f000f000"
        "0007c03e0000001fff800000003fc000000000000000"
    ),
    333: (
        "0000000000000000000000000006000000000060000000000600000000006000000000060000000000600000"
        "00000600000000006000000000060000000001f800000000fff00000001e0780000003801c0000007000e000"
        "000e0007000000c0003000000c00030000018000180000180001800001800018000018000180000180001800"
        "00180001800000c0003000000c0003000000e00070000007000e0000003801c0000001e0780000000fff0000"
        "00001f8000000000600000000006000000000060000000000600000000006000000000060000000000600000"
        "00000600000000006000000000000000000000000000"
    ),
    667: (
        "0000000000000000000000000006000000000060000000000600000000006000000000060000000000600000"
        "00000600000000006000000000060000000000f8000000003fc0000000070e00000000e0600000000c030000"
        "0000c0300000000c0300000000c03000000006070000000070e000000003fc000000001f0000000000600000"
        "0000060000000000600000000006000000000060000000000600000000006000000000060000000000600000"
        "0000060000000000600000000006000000000060000000000600000000006000000000060000000000600000"
        "00000600000000006000000000000000000000000000"
    ),
    1000: (
        "0000000000000000000000000006000000000060000000000f0000000001f800000000198000000001980000"
        "00001f8000000000f00000000006000000000060000000000600000000006000000000060000000000600000"
        "0000060000000000600000000006000000000060000000000600000000006000000000060000000000600000"
        "0000060000000000600000000006000000000060000000000600000000006000000000060000000000600000"
        "0000060000000000600000000006000000000060000000000600000000006000000000060000000000600000"
        "00000600000000006000000000000000000000000000"
    ),
}


def unpack(hexstr):
    bits = "".join(format(b, "08b") for b in bytes.fromhex(hexstr))
    if len(bits) != ART * ART:
        problems.append("маска не 44x44: %d бит" % len(bits))
    return [[1 if bits[y * ART + x] == "1" else 0 for x in range(ART)] for y in range(ART)]


# --- узлы из прошивки ---------------------------------------------------------
body = SRC[SRC.index("static const pv_tone_knot_t s_tone_knots[] = {"):]
body = body[:body.index("\n};")]
KNOTS = [(int(a), int(b), int(c)) for a, b, c in
         re.findall(r"\{\s*(\d+),\s*(\d+),\s*(\d+)\s*\},", body)]

if len(KNOTS) != 4:
    problems.append("узлов %d, а должно 4" % len(KNOTS))

X = int(re.search(r"#define\s+PV_TN_X\s+\(?(-?\d+)", SRC).group(1))
STEM_TOP = int(re.search(r"#define\s+PV_TN_STEM_TOP\s+\(?(-?\d+)", SRC).group(1))
STEM_BOT = int(re.search(r"#define\s+PV_TN_STEM_BOT\s+\(?(-?\d+)", SRC).group(1))


def between(t, which):
    for i in range(len(KNOTS) - 1):
        t0, t1 = KNOTS[i][0], KNOTS[i + 1][0]
        if t <= t1:
            v0, v1 = KNOTS[i][which], KNOTS[i + 1][which]
            num = (v1 - v0) * (t - t0)
            den = t1 - t0
            return v0 + ((num + den // 2) // den if num >= 0 else -((-num + den // 2) // den))
    return KNOTS[-1][which]


def diameter(t):
    d = between(t, 1)
    return d + (d & 1)


def top_row(t):
    return between(t, 2)


def frame(q):
    t = q * 1000 // 50
    d = diameter(t)
    high = top_row(t)
    low = high + d - 1
    cy2 = high + low
    r2_out = d * d
    r2_in = (d - 4) * (d - 4)

    g = [[0] * ART for _ in range(ART)]

    for y in range(STEM_TOP, STEM_BOT + 1):
        dy2 = 2 * y - cy2
        if dy2 * dy2 <= r2_in:
            continue
        g[y][X] = 1
        g[y][X + 1] = 1

    for y in range(high, low + 1):
        dy2 = 2 * y - cy2
        for x in range(X - d // 2, X + 1 + d // 2):
            dx2 = 2 * x - CENTRE2
            dd = dx2 * dx2 + dy2 * dy2
            if dd <= r2_out and dd > r2_in:
                g[y][x] = 1
    return g


def ink(grid):
    return sum(map(sum, grid))


def ring_rows(g):
    return [y for y in range(ART) if sum(g[y]) > 2]


# --- 1. его кадры -------------------------------------------------------------
exact = {0, 333, 1000}          # эти три обязаны сойтись точка в точку
for t, hexstr in sorted(HIS.items()):
    his = unpack(hexstr)
    mine = frame(t * 50 // 1000)
    diff = [(x, y) for y in range(ART) for x in range(ART) if mine[y][x] != his[y][x]]
    if t in exact:
        if diff:
            problems.append("доля %d: %d точек расхождения, первая %s" % (t, len(diff), diff[0]))
    else:
        # его кольцо диаметром 12 нарисовано с более толстой стенкой сверху и снизу
        extra = [p for p in diff if his[p[1]][p[0]] == 1]
        missing = [p for p in diff if mine[p[1]][p[0]] == 1]
        if missing or len(extra) > 8:
            problems.append("доля %d: лишних %d, недостающих %d — больше, чем рука"
                            % (t, len(extra), len(missing)))

# --- 2. кольцо всегда квадратное и без одиночных пикселей ---------------------
for q in range(0, 51):
    g = frame(q)
    d = diameter(q * 1000 // 50)
    rows = ring_rows(g)
    w = max(max(x for x in range(ART) if g[y][x]) - min(x for x in range(ART) if g[y][x]) + 1
            for y in rows)
    if len(rows) != d or w != d:
        problems.append("q=%d: кольцо %dx%d, а диаметр %d" % (q, w, len(rows), d))
    lit = [(x, y) for y in range(ART) for x in range(ART) if g[y][x]]
    if not all(g[y][ART - 1 - x] for x, y in lit):
        problems.append("q=%d: на боках одинокие пиксели" % q)
    if d % 2:
        problems.append("q=%d: нечётный диаметр %d" % (q, d))

# --- 3. кольцо только сжимается, нитка всегда на месте -----------------------
inks = [ink(frame(q)) for q in range(0, 51)]
if inks != sorted(inks, reverse=True):
    problems.append("кольцо не только сжимается")
if min(inks) < 2 * (STEM_BOT - STEM_TOP + 1):
    problems.append("нитка где-то короче, чем от строки %d до %d" % (STEM_TOP, STEM_BOT))
if inks[0] != ink(unpack(HIS[0])):
    problems.append("на низком значении кадр не его: %d против %d"
                    % (inks[0], ink(unpack(HIS[0]))))

# --- 4. провод ----------------------------------------------------------------
DISPATCH = SRC[SRC.index("static synth_preview_kind_t pv_values"):]
DISPATCH = DISPATCH[:DISPATCH.index("\n}\n")]
LABELS, pending = {}, []
for mm in re.finditer(r"case (SYNTH_PARAM_\w+):|return (PREVIEW_\w+);", DISPATCH):
    if mm.group(1):
        pending.append(mm.group(1))
    else:
        for label in pending:
            LABELS.setdefault(label, mm.group(2))
        pending = []

if LABELS.get("SYNTH_PARAM_PERC_TONE") != "PREVIEW_TONE":
    problems.append("PERC_TONE отдаёт %s, а должен PREVIEW_TONE"
                    % LABELS.get("SYNTH_PARAM_PERC_TONE"))
if "PREVIEW_TONE" not in HDR:
    problems.append("нет вида PREVIEW_TONE в заголовке")
if not re.search(r"case PREVIEW_TONE:\s*pv_tone\(", SRC):
    problems.append("нет вызова pv_tone в переключателе")
ox = SRC[SRC.index("static int pv_ox_for"):SRC.index("static int pv_oy_for")]
if "case PREVIEW_TONE:" not in ox:
    problems.append("PREVIEW_TONE не в списке нулевого сдвига")
if "d += d & 1;" not in SRC:
    problems.append("в pv_tone не видно округления диаметра до чётного")
if "const int cy2 = high + low;" not in SRC:
    problems.append("в pv_tone не видно удвоенного центра")

if problems:
    print("FAIL: фигура TONE")
    for p in problems:
        print("  -", p)
    sys.exit(1)

print("OK: TONE — кольцо на нитке, отражено и пущено обратно; его большой, средний и маленький "
      "кадры сходятся точка в точку, у кольца диаметром 12 его рука рисует стенку на пиксель "
      "толще (4 точки); диаметр чётный на всех 51 положениях, кольцо квадратное и без одиноких "
      "пикселей, чернила только убывают: %d -> %d" % (inks[0], inks[-1]))
