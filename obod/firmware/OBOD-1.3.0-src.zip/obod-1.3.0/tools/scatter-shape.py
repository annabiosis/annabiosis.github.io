"""SCATTER: ромб и пары полос — гейт к прошивке.

Считает то же, что pv_scatter() в synth_ui_preview.c, целыми числами в десятых: константы
читаются из исходника, ромб сравнивается по манхэттенскому расстоянию, полосы режутся на оси
и продолжаются из-под нижней кромки. Проверяется шесть вещей:

  1. ЕГО ШЕСТЬ КАДРОВ СХОДЯТСЯ. На пяти шагах фигура обязана совпасть с его кадрами; допуск
     сорок точек на кадр — это его рука, правая сторона у него на пиксель шире левой.
  2. ФИГУРА СИММЕТРИЧНА на всех пятидесяти одном положении: столбец x и столбец 43 - x
     совпадают. Ромб по формуле симметричен, пары тоже, значит и вся фигура.
  3. РОМБ ПОСТОЯННЫЙ: на всех положениях пиксели ромба одни и те же.
  4. РОМБ ЗАМКНУТ: каждый его пиксель имеет соседа по стороне, дыр в обводке нет.
  5. ПАРЫ ТОЛЬКО РАСХОДЯТСЯ: полурасстояние каждой пары не убывает с ходом ручки.
  6. ПОЛОСЫ РЕЖУТСЯ НА ОСИ: у каждой полосы строки от оси до нижней кромки ромба пустые, а
     верхнее плечо кончается ровно на оси.
"""
import re
import sys
from pathlib import Path

from PIL import Image

sys.stdout.reconfigure(encoding="utf-8")

SRC = Path("components/synth_ui/src/synth_ui_preview.c")
ART = 44
TOLERANCE = 40
BASE_DIR = Path(r"C:\Users\Blaq\.dsh\attachments\v1\objects")
SH = ("e60cd407ac7e4b9884980ce82dffdffadae4d7680a21c89afda9d439a15b5d32",
      "0482644813d93ce6cff7db5bdae3d597cee26830d51aa2461145caaf51dceebc",
      "0b4c5fbf705995c2d8ca1a8dabce254a247f81f728408032f3e88f75729b226f",
      "31463193749983889bd9087fb0e72de02b5c658997b2513bff36176f464bdba9",
      "327a06bb6510703f67cc59fd5d019b9fe85f9f2ee84cac02771d6342733623a3",
      "d785fc7df36a2c80613c2bfc4eb2cb273d8e50ef382ae4703829b2f629e12fda")


def konst(name):
    text = SRC.read_text(encoding="utf-8")
    m = re.search(r"#define\s+%s\s+\(?(-?\d+)\)?" % name, text)
    if not m:
        raise SystemExit("нет константы %s в %s" % (name, SRC))
    return int(m.group(1))


def table(name):
    text = SRC.read_text(encoding="utf-8")
    m = re.search(r"%s\s*(?:\[[^\]]*\])+\s*=\s*\{(.*?)\}\s*;" % name, text, re.S)
    if not m:
        raise SystemExit("нет таблицы %s в %s" % (name, SRC))
    body = re.sub(r"/\*.*?\*/", " ", m.group(1), flags=re.S)
    return [int(v) for v in re.findall(r"-?\d+", body)]


CX = konst("PV_SC_CX")
CY = konst("PV_SC_CY")
A10 = konst("PV_SC_A10")
B10 = konst("PV_SC_B10")
FULL = konst("PV_SC_FULL")
LO = konst("PV_SC_LO")
HI = konst("PV_SC_HI")
AXIS = konst("PV_SC_AXIS")
Y0 = konst("PV_SC_Y0")
Y1 = konst("PV_SC_Y1")
STEP = konst("PV_SC_STEP")
H1 = table("s_sc_h1")
H2 = table("s_sc_h2")


def dia(x, y):
    dx = 10 * x + 5 - CX
    dy = 10 * y + 5 - CY
    f = abs(dx) * B10 + abs(dy) * A10
    return LO <= f <= HI


def knot(tbl, t):
    i = min(t // STEP, 4)
    t0 = i * STEP
    num = (tbl[i + 1] - tbl[i]) * (t - t0)
    bias = (STEP // 2) if num >= 0 else -(STEP // 2)
    return tbl[i] + int((num + bias) / STEP)


def stripe(g, col):
    if col < 0 or col >= ART:
        return
    for y in range(Y0, AXIS + 1):
        g[y][col] = 1
    bottom = -1
    for y in range(ART - 1, -1, -1):
        if dia(col, y):
            bottom = y
            break
    for y in range(AXIS + 1 if bottom < 0 else bottom, Y1 + 1):
        g[y][col] = 1


def frame(q):
    t = q * 20
    g = [[0] * ART for _ in range(ART)]
    for y in range(ART):
        for x in range(ART):
            if dia(x, y):
                g[y][x] = 1
    stripe(g, 21)
    stripe(g, 22)
    for h in (knot(H1, t), knot(H2, t)):
        if h <= 0:
            continue
        for col in (21 - h, 22 - h, 21 + h, 22 + h):
            stripe(g, col)
    return g


def diamond():
    return [[1 if dia(x, y) else 0 for x in range(ART)] for y in range(ART)]


def mirrored(g):
    return [[g[y][ART - 1 - x] for x in range(ART)] for y in range(ART)]


def his(k):
    p = BASE_DIR / SH[k][:2] / SH[k]
    px = Image.open(str(p)).convert("L").load()
    return [[1 if px[x, y] > 110 else 0 for x in range(ART)] for y in range(ART)]


def diff(a, b):
    return sum(1 for y in range(ART) for x in range(ART) if a[y][x] != b[y][x])


def main():
    print("SCATTER: ромб и пары полос")
    print("  ромб: полуширина %.2f, полувысота %.2f, толщина по нормали около двух пикселей"
          % (A10 / 10.0, B10 / 10.0))
    print("  шаг: %d, пар две, полурасстояния %s и %s" % (STEP, H1, H2))

    worst = 0
    for k in range(6):
        g = frame(k * 10)
        d = diff(g, his(k))
        worst = max(worst, d)
        print("  кадр %d (q = %2d): h1 %2d, h2 %2d, чернил %3d против %3d, расхождений %d"
              % (k + 1, k * 10, knot(H1, k * 200), knot(H2, k * 200),
                 sum(map(sum, g)), sum(map(sum, his(k))), d))
    if worst > TOLERANCE:
        raise SystemExit("  кадр разошёлся сильнее допуска %d" % TOLERANCE)

    for q in range(51):
        if frame(q) != mirrored(frame(q)):
            raise SystemExit("  q = %d: фигура не симметрична" % q)
    print("  симметрия: все пятьдесят одно положение совпадают с отражением по вертикали")

    d0 = diamond()
    for q in range(51):
        g = frame(q)
        for y in range(ART):
            for x in range(ART):
                if d0[y][x] and not g[y][x]:
                    raise SystemExit("  q = %d: у ромба пропал пиксель (%d, %d)" % (q, x, y))
    print("  ромб: одни и те же %d пикселей на всех положениях" % sum(map(sum, d0)))

    for y in range(ART):
        for x in range(ART):
            if not d0[y][x]:
                continue
            near = ((x and d0[y][x - 1]) or (x < ART - 1 and d0[y][x + 1])
                    or (y and d0[y - 1][x]) or (y < ART - 1 and d0[y + 1][x]))
            if not near:
                raise SystemExit("  ромб: одинокий пиксель (%d, %d)" % (x, y))
    print("  ромб замкнут: одиноких пикселей нет")

    prev = (-1, -1)
    for q in range(51):
        now = (knot(H1, q * 20), knot(H2, q * 20))
        if now[0] < prev[0] or now[1] < prev[1]:
            raise SystemExit("  q = %d: пара пошла назад" % q)
        if now[0] > 15 or now[1] > 15:
            raise SystemExit("  q = %d: пара ушла за поле" % q)
        prev = now
    print("  пары только расходятся: полурасстояния не убывают, крайние доходят до пятнадцати")

    for q in (0, 10, 20, 30, 40, 50):
        g = frame(q)
        t = q * 20
        cols = {21, 22}
        for h in (knot(H1, t), knot(H2, t)):
            if h:
                cols.update((21 - h, 22 - h, 21 + h, 22 + h))
        for col in cols:
            bottom = -1
            for y in range(ART - 1, -1, -1):
                if dia(col, y):
                    bottom = y
                    break
            for y in range(AXIS + 1, bottom if bottom >= 0 else ART):
                if g[y][col] and not dia(col, y):
                    raise SystemExit("  q = %d, столбец %d: полоса не разрезана на оси" % (q, col))
            if not g[AXIS][col] or not g[Y0][col]:
                raise SystemExit("  q = %d, столбец %d: верхнее плечо не от строки %d" % (q, col, Y0))
            if bottom >= 0 and not g[bottom][col]:
                raise SystemExit("  q = %d, столбец %d: нижнее плечо не продолжено из-под кромки" % (q, col))
    print("  полосы разрезаны на оси и продолжаются из-под нижней кромки ромба")

    print("\nOK: SCATTER — ромб симметричен и постоянен, пары расходятся, кадры владельца "
          "сходятся в пределах %d точек" % TOLERANCE)
    return 0


if __name__ == "__main__":
    sys.exit(main())
