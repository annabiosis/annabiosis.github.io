"""COMP в MASTER: фигура в прошивке против двух кадров владельца.

Фигура — девять полос на оси: длина полосы есть громкость момента, и ручка COMP
выравнивает их. Крайние состояния — рисунки владельца, поэтому гейт повторяет
рисование из synth_ui_preview.c и сверяет маски на COMP 0 и COMP 50 точка в точку
с его файлами, а заодно проверяет, что числа в таблицах те самые, что вид стоит на
маске без сдвига и что ручка подключена к SYNTH_PARAM_MASTER_COMP.
"""
import re
import sys
from pathlib import Path

from PIL import Image

sys.stdout.reconfigure(encoding="utf-8")

SRC = Path("components/synth_ui/src/synth_ui_preview.c")
HDR = Path("components/synth_ui/src/synth_ui_preview.h")

SRC_T = SRC.read_text(encoding="utf-8")
HDR_T = HDR.read_text(encoding="utf-8")

ART = 44
AX0 = 6          # PV_AREA_X0: поле 44 x 44 в маске 56 x 56
AY0 = 6
MIN_HASH = "d7dfc272f093e8fba43071dc3e9cad9605e0517637a282b4d5a5d1e9dfeaa58e"
MAX_HASH = "5223cd8f1f2a49304726ded4e6e33e5aafeba8774424528a4bd403b8af5a37e6"
BASE_DIR = Path(r"C:\Users\Blaq\.dsh\attachments\v1\objects")
THRESHOLD = 110

fail = []


def note(msg):
    print("  " + msg)


def check(ok, msg):
    print(("  да  " if ok else "  НЕТ ") + msg)
    if not ok:
        fail.append(msg)


def load(h):
    px = Image.open(BASE_DIR / h[:2] / h).convert("L").load()
    return [[1 if px[x, y] > THRESHOLD else 0 for x in range(ART)] for y in range(ART)]


def nums(block):
    return [int(v) for v in re.findall(r"-?\d+", block)]


# --- таблицы и числа из кода -------------------------------------------------
print("таблицы в synth_ui_preview.c")

m = re.search(r"#define PV_COMP_BARS (\d+)", SRC_T)
check(m is not None, "есть #define PV_COMP_BARS")
nbars = int(m.group(1)) if m else 0
check(nbars == 9, "полос ровно девять")

lo = nums(re.search(r"PV_COMP_MIN\[PV_COMP_BARS\] = \{([^}]*)\}", SRC_T).group(1))
hi = nums(re.search(r"PV_COMP_MAX\[PV_COMP_BARS\] = \{([^}]*)\}", SRC_T).group(1))
note("низ: " + ", ".join(str(v) for v in lo))
note("верх: " + ", ".join(str(v) for v in hi))
check(lo == [19, 15, 6, 15, 10, 19, 13, 7, 2], "длины при нуле те, что нарисованы")
check(hi == [19, 19, 19, 17, 19, 19, 19, 15, 13], "длины на верху те, что нарисованы")
check(all(b >= a for a, b in zip(lo, hi)), "ни одна полоса не укорачивается с ходом ручки")

enum = re.search(r"static void pv_comp\(uint8_t \*m, const pv_vals_t \*v\)\s*\{\s*enum \{([^}]*)\}",
                 SRC_T).group(1)
geo = {k: int(v) for k, v in re.findall(r"(\w+)\s*=\s*(\d+)", enum)}
note("геометрия: " + ", ".join("%s=%d" % kv for kv in sorted(geo.items())))
want = {"AXIS_TOP": 21, "AXIS_BOT": 22, "BAR_LAST": 20, "BAR_FIRST": 25,
        "BAR_X0": 1, "BAR_STEP": 5, "BAR_W": 2, "BAR_DROP": 2}
check(geo == want, "оси и полосы на тех строках и столбцах, что в кадрах")


# --- рисование, повторённое здесь --------------------------------------------
def frame(t):
    g = [[0] * ART for _ in range(ART)]
    for k in range(nbars):
        a = lo[k] + ((hi[k] - lo[k]) * t + 500) // 1000
        x = geo["BAR_X0"] + k * geo["BAR_STEP"]
        for y in range(geo["BAR_LAST"] - a + 1, geo["BAR_LAST"] + 1):
            for dx in range(geo["BAR_W"]):
                g[y][x + dx] = 1
        for y in range(geo["BAR_FIRST"], geo["BAR_FIRST"] + a - geo["BAR_DROP"]):
            for dx in range(geo["BAR_W"]):
                g[y][x + dx] = 1
    xend = geo["BAR_X0"] + (nbars - 1) * geo["BAR_STEP"] + geo["BAR_W"] - 1
    for x in range(geo["BAR_X0"], xend + 1):
        g[geo["AXIS_TOP"]][x] = 1
        g[geo["AXIS_BOT"]][x] = 1
    return g


print("сверка с кадрами владельца")
for name, h, t in (("COMP 0", MIN_HASH, 0), ("COMP 50", MAX_HASH, 1000)):
    mine = frame(t)
    his = load(h)
    diff = [(x, y) for y in range(ART) for x in range(ART) if mine[y][x] != his[y][x]]
    ink = sum(map(sum, his))
    check(not diff, "%s: совпадает точка в точку (чернил %d)" % (name, ink))
    if diff:
        note("расхождений %d, первые %s" % (len(diff), diff[:6]))

print("ход ручки")
steps = [frame(t) for t in range(0, 1001, 100)]
ink = [sum(map(sum, g)) for g in steps]
diffs = [sum(1 for y in range(ART) for x in range(ART) if steps[i][y][x] != steps[i + 1][y][x])
         for i in range(len(steps) - 1)]
note("чернил по десятым: " + ", ".join(str(v) for v in ink))
note("соседние десятые доли расходятся на " + ", ".join(str(d) for d in diffs))
check(all(d > 0 for d in diffs), "каждая десятая доля хода меняет картинку")
check(ink == sorted(ink), "картинка только прибавляется: полосы подтягиваются, не опадают")
check(max(diffs) <= ink[-1] // 6, "ни один шаг не перепрыгивает шестую часть фигуры")

# --- подключение к ручке ------------------------------------------------------
print("подключение")
check(re.search(r"case SYNTH_PARAM_MASTER_COMP:\s*v->q\[0\] = \(uint8_t\)pv_q\(SYNTH_PARAM_MASTER_COMP\);\s*"
               r"return PREVIEW_COMP;", SRC_T) is not None,
      "SYNTH_PARAM_MASTER_COMP отдаёт PREVIEW_COMP и квантуется в 0..50")
check(re.search(r"case PREVIEW_COMP:.*?pv_comp\(mask", SRC_T, re.S) is not None,
      "вид нарисован в switch синтеза маски")
ox = re.search(r"static int pv_ox_for.*?case PREVIEW_COMP:", SRC_T, re.S)
check(ox is not None, "у вида нулевой сдвиг: полосы ложатся на маску сами")
check(re.search(r"PREVIEW_COMP,\s*/\*[^*]*\*/", HDR_T) is not None,
      "вид описан в заголовке")

print()
if fail:
    print("провалов: %d" % len(fail))
    for f in fail:
        print("  - " + f)
    sys.exit(1)
print("COMP: фигура сходится с обоими кадрами, ручка подключена")
