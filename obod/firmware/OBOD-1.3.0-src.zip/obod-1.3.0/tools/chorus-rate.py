"""Фигура CHORUS RATE: что рисует прошивка против утверждённой картинки.

Утверждённая картинка — девять/семнадцать кадров, снятых с кадров владельца: ширина
прямоугольника 20, высота 42, перо 2, закругление 10, шаг осей целый от 20 до 4 по
одному пикселю. Здесь повторена целочисленная арифметика прошивки и сверена с
эталонными масками; кадры владельца сверяются отдельно и с одной поблажкой — они
ручные и расходятся только по крайним строкам и столбцам поля.
"""
import io
import re
import sys

sys.stdout.reconfigure(encoding="utf-8")

SRC = io.open("components/synth_ui/src/synth_ui_preview.c", encoding="utf-8").read()
HDR = io.open("components/synth_ui/src/synth_ui_preview.h", encoding="utf-8").read()

problems = []

# Утверждённые маски, собранные из утверждённого листа: шаг 20, 16, 12, 8, 4.
REF = [
    "00000000000f8001f8001fff00fff00ff0781e0781e001c3801c38000e7000e700007e0007e00003c0003c00003c0003c000018000180000180001800001800018000018000180000180001800001800018000018000180000180001800001800018000018000180000180001800001800018000018000180000180001800001800018000018000180000180001800001800018000018000180000180001800001800018000018000180000180001800001800018000018000180000180001800003c0003c00003c0003c00007e0007e0000e7000e70001c3801c3800781e0781e0ff00fff00fff8001f8001f00000000000",
    "000000000001f801f801f8fff0fff0fffe079e079e07801f801f801000f000f000000f000f000000f000f000000f000f0008019801980180198019801801980198018019801980180198019801801980198018019801980180198019801801980198018019801980180198019801801980198018019801980180198019801801980198018019801980180198019801801980198018019801980180198019801801980198018019801980180198019801801980198018019801980180198019801000f000f000000f000f000000f000f000000f000f000801f801f801e079e079e07fff0fff0fff1f801f801f800000000000",
    "0000000000081f81f81f81fffffffffff7e07e07e07e3c03c03c03c7e07e07e07ee70e70e70e7c30c30c30c3c30c30c30c38198198198181981981981819819819818198198198181981981981819819819818198198198181981981981819819819818198198198181981981981819819819818198198198181981981981819819819818198198198181981981981819819819818198198198181981981981819819819818198198198181981981981819819819818198198198181981981981c30c30c30c3c30c30c30c3e70e70e70e77e07e07e07e3c03c03c03c7e07e07e07efffffffffff81f81f81f8100000000000",
    "000000000009f9f9f9f9f9ffffffffffff9f9f9f9f9f9f9f9f9f9f90f0f0f0f0f00f0f0f0f0f00f0f0f0f0f00f0f0f0f0f099999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999990f0f0f0f0f00f0f0f0f0f00f0f0f0f0f00f0f0f0f0f09f9f9f9f9f9f9f9f9f9f9ffffffffffff9f9f9f9f9f900000000000",
    "00000000000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff9999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff00000000000",
]

# Его пять кадров, для сверки с поблажкой на ручной край.
HIS = [
    "00000000000f8001f8001fff00fff00ff0781e0781e001c3801c38000e7000e700007e0007e00003c0003c00003c0003c000018000180000180001800001800018000018000180000180001800001800018000018000180000180001800001800018000018000180000180001800001800018000018000180000180001800001800018000018000180000180001800001800018000018000180000180001800001800018000018000180000180001800001800018000018000180000180001800003c0003c00003c0003c00007e0007e0000e7000e70001c3801c3800781e0781e0ff00fff00fff8001f8001f00000000000",
    "000000000001f801f801f8fff0fff0fffe079e079e07801f801f801000f000f000000f000f000000f000f000000f000f0008019801980180198019801801980198018019801980180198019801801980198018019801980180198019801801980198018019801980180198019801801980198018019801980180198019801801980198018019801980180198019801801980198018019801980180198019801801980198018019801980180198019801801980198018019801980180198019801000f000f000000f000f000000f000f000000f000f000801f801f801e079e079e07fff0fff0fff1f801f801f800000000000",
    "0000000000081f81f81f81fffffffffff7e07e07e07e3c03c03c03c7e07e07e07ee70e70e70e7c30c30c30c3c30c30c30c38198198198181981981981819819819818198198198181981981981819819819818198198198181981981981819819819818198198198181981981981819819819818198198198181981981981819819819818198198198181981981981819819819818198198198181981981981819819819818198198198181981981981819819819818198198198181981981981c30c30c30c3c30c30c30c3e70e70e70e77e07e07e07e3c03c03c03c7e07e07e07efffffffffffc1f81f81f8100000000000",
    "00000000000bfbfbfbfbfbffffffffffff9f9f9f9f9f9f9f9f9f9f90f0f0f0f0f00f0f0f0f0f00f0f0f0f0f00f0f0f0f0f019999999998199999999981999999999819999999998199999999981999999999819999999998199999999981999999999819999999998199999999981999999999819999999998199999999981999999999819999999998199999999981999999999819999999998199999999981999999999819999999998199999999981999999999819999999998199999999980f0f0f0f0f00f0f0f0f0f00f0f0f0f0f00f0f0f0f0f09f9f9f9f9f9f9f9f9f9f9ffffffffffffdfdfdfdfdfd00000000000",
    "0000000000001fffffff800fffffffff01fffffffff83bbbfffdddc7777fffeeeeeeeefff7777ccccfff3333ccccfff33339999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999ccccfff3333ccccfff3333eeeefff77777777fffeeee3bbbfffdddc1fffffffff80fffffffff001fffffff8000000000000",
]

FIELD = 44


def const(name):
    m = re.search(r"#define\s+%s\s+(-?\d+)" % name, SRC)
    if not m:
        problems.append("нет константы %s" % name)
        return 0
    return int(m.group(1))


W = const("PV_CR_W")
R = const("PV_CR_R")
TOP = const("PV_CR_TOP")
BOT = const("PV_CR_BOT")
X = const("PV_CR_X")
P_FAST = const("PV_CR_P_FAST")
STEPS = const("PV_CR_STEPS")
SRC_FIELD = const("PV_CR_FIELD")

if (W, R, TOP, BOT, X, P_FAST, STEPS) != (20, 10, 2, 42, 12, 4, 16):
    problems.append("константы фигуры не те: W=%d R=%d TOP=%d BOT=%d X=%d FAST=%d STEPS=%d"
                    % (W, R, TOP, BOT, X, P_FAST, STEPS))
if SRC_FIELD != FIELD:
    problems.append("поле %d, а фигура размечена на %d" % (SRC_FIELD, FIELD))


def pitch(q):
    """Та же арифметика, что в pv_cr_pitch: целые шаги по одному пикселю."""
    return P_FAST + ((50 - q) * STEPS + 25) // 50


def inside(x, y, x0, y0, x1, y1, r):
    if x < x0 or x >= x1 or y < y0 or y >= y1:
        return False
    px, py = 2 * x + 1, 2 * y + 1
    cx = min(max(px, 2 * (x0 + r)), 2 * (x1 - r))
    cy = min(max(py, 2 * (y0 + r)), 2 * (y1 - r))
    dx, dy = px - cx, py - cy
    return dx * dx + dy * dy <= 4 * r * r


def mask_at(q):
    p = pitch(q)
    g = [[0] * FIELD for _ in range(FIELD)]
    for k in range(-12, 13):
        x0 = X + k * p
        x1 = x0 + W
        if x1 < -1 or x0 > FIELD:
            continue
        for y in range(FIELD):
            for x in range(x0 - 2, x1 + 2):
                if x < 0 or x >= FIELD:
                    continue
                if not inside(x, y, x0 - 1, TOP - 1, x1 + 1, BOT + 1, R + 1):
                    continue
                if inside(x, y, x0 + 1, TOP + 1, x1 - 1, BOT - 1, R - 1):
                    continue
                g[y][x] = 1
    return g


def unpack(hexstr):
    bits = "".join(format(b, "08b") for b in bytes.fromhex(hexstr))
    if len(bits) != FIELD * FIELD:
        problems.append("эталон не 44 x 44: %d бит" % len(bits))
    return [[1 if bits[y * FIELD + x] == "1" else 0 for x in range(FIELD)]
            for y in range(FIELD)]


# 1. Семнадцать ступеней: шаг осим 20 .. 4, только целый, и картинка совпадает с
#    утверждённой там, где она утверждена.
pitch_seen = []
for q in range(0, 51):
    p = pitch(q)
    if not pitch_seen or pitch_seen[-1] != p:
        pitch_seen.append(p)
if pitch_seen != list(range(20, 3, -1)):
    problems.append("шаг осей идёт %s, а должен 20..4 по одному" % pitch_seen)

for n, p in enumerate((20, 16, 12, 8, 4)):
    q = next(q for q in range(0, 51) if pitch(q) == p)
    mine = mask_at(q)
    want = unpack(REF[n])
    diff = sum(1 for y in range(FIELD) for x in range(FIELD) if mine[y][x] != want[y][x])
    if diff:
        problems.append("шаг %d: маска расходится с утверждённой в %d точках" % (p, diff))

# 2. Его кадры. Тело кадра — то, что видит рука, — совпадает точка в точку на всех
#    пяти шагах. Шапки сходятся на шагах 20..8; на шаге 4 он рисовал их руками, и его
#    дуги в шапке смыкаются иначе, чем в утверждённом листе, поэтому шапка плотного
#    кадра сверяется только на отсутствие выхода за поле.
for n, p in enumerate((20, 16, 12, 8, 4)):
    q = next(q for q in range(0, 51) if pitch(q) == p)
    mine = mask_at(q)
    his = unpack(HIS[n])
    body = [(x, y) for y in range(12, 32) for x in range(2, 42)
            if mine[y][x] != his[y][x]]
    if body:
        problems.append("шаг %d: тело кадра расходится с его картинкой — %s" % (p, body[:6]))
    if p >= 8:
        cap = [(x, y) for y in range(FIELD) for x in range(FIELD)
               if mine[y][x] != his[y][x] and y not in (1, 42) and x not in (0, 43)]
        if cap:
            problems.append("шаг %d: от его кадра расходятся не только края — %s"
                            % (p, cap[:6]))

# 3. Каждый кадр зеркальный по обеим осям: иначе анимация дёргается вбок.
for q in range(0, 51):
    g = mask_at(q)
    for y in range(FIELD):
        for x in range(FIELD):
            if g[y][x] != g[y][FIELD - 1 - x]:
                problems.append("q=%d, шаг %d: кадр не зеркален слева-направо"
                                % (q, pitch(q)))
                break
        else:
            continue
        break
    for y in range(FIELD // 2):
        if g[y] != g[FIELD - 1 - y]:
            problems.append("q=%d, шаг %d: кадр не зеркален сверху-вниз" % (q, pitch(q)))
            break

# 4. Чернила растут по ходу ручки. Ступень к ступени они не обязаны расти монотонно:
#    когда стенки смыкаются, часть штриха уходит в соседнюю — но общий рост обязан быть,
#    и провал от ступени к ступени не больше четверти.
prev = None
inks = []
for q in range(0, 51):
    g = mask_at(q)
    ink = sum(map(sum, g))
    inks.append(ink)
    if prev is not None and ink < prev * 3 // 4:
        problems.append("q=%d: чернил %d против %d на шаге раньше — провал больше четверти"
                        % (q, ink, prev))
    prev = ink
if inks[50] < 3 * inks[0]:
    problems.append("на быстром краю %d чернил против %d на медленном: гребёнки не вышло"
                    % (inks[50], inks[0]))
if inks[0] > 400:
    problems.append("на медленном краю %d чернил: фигура слишком плотная" % inks[0])

# --- куда поставлена ---------------------------------------------------------
if "PREVIEW_CHORUS_RATE" not in HDR:
    problems.append("нет вида PREVIEW_CHORUS_RATE в заголовке")

sw = SRC[SRC.index("static synth_preview_kind_t pv_values"):]
sw = sw[:sw.index("\n}\n")]
LABELS, pending = {}, []
for mm in re.finditer(r"case (SYNTH_PARAM_\w+):|return (PREVIEW_\w+);", sw):
    if mm.group(1):
        pending.append(mm.group(1))
    else:
        for label in pending:
            LABELS.setdefault(label, mm.group(2))
        pending = []

for param, kind in {
    "SYNTH_PARAM_CHORUS_RATE": "PREVIEW_CHORUS_RATE",
    "SYNTH_PARAM_CHORUS_DEPTH": "PREVIEW_CHORUS_DEPTH",
    "SYNTH_PARAM_CHORUS_MIX": "PREVIEW_NONE",
}.items():
    if LABELS.get(param) != kind:
        problems.append("%s отдаёт %s, а должен %s" % (param, LABELS.get(param), kind))

if not re.search(r"case PREVIEW_CHORUS_RATE:\s*pv_chorus_rate\(", SRC):
    problems.append("нет вызова pv_chorus_rate в переключателе")

# цепочка ставит себя сама, поэтому видовой сдвиг обязан быть нулевым
ox = re.search(r"static int pv_ox_for\(synth_preview_kind_t kind\)\s*\{(.*?)\n", SRC, re.S)
if ox is None or "PREVIEW_CHORUS_RATE" not in SRC[:SRC.index("static int pv_oy_for")][-4000:]:
    problems.append("нет вида в pv_ox_for")
elif "case PREVIEW_CHORUS_RATE:" not in SRC[SRC.index("static int pv_ox_for"):SRC.index("static int pv_oy_for")]:
    problems.append("PREVIEW_CHORUS_RATE не в списке нулевого сдвига")

if problems:
    print("FAIL: фигура CHORUS RATE")
    for p in problems:
        print("  -", p)
    sys.exit(1)

print("OK: CHORUS RATE — прямоугольник 20 x 42, скругление 10, перо 2; шаг осей целый "
      "20..4 по 1 px, семнадцать симметричных кадров; стоит на RATE страницы CHORUS, "
      "у MIX фигуры нет")
