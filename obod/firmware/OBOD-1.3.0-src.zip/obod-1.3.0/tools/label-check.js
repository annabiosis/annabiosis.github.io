#!/usr/bin/env node
/*
 * Сверяет цветные рамки надписей с семействами прибора.
 *
 * tools/label-wrap.py ставит каждой надписи с экрана класс семейства: .lab-drone,
 * .lab-lead, .lab-gen, .lab-perc, .lab-fx, .lab-mix, .lab-view, .lab-preset. Цвет
 * рамки — обещание читателю, что эта надпись живёт на приборе в таком-то разделе.
 * Обещание держится, пока в разметке нет классов мимо списка, а в docs.css есть
 * цвет на каждое семейство прошивки.
 *
 * Проверяется три вещи:
 *
 *   - у каждой рамки в web/*.html класс из восьми, и цвет есть в docs.css;
 *   - семейства в разметке и в прошивке — одни и те же: GRP_* и GROUP_COLOR в
 *     synth_ui.c, ни одного лишнего и ни одного забытого;
 *   - рамка обнимает надпись с прибора: прописные, без строчных букв внутри.
 *
 * Запуск: node tools/label-check.js
 */

'use strict';

const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const webDir = path.join(root, 'web');
const uiFile = path.join(root, 'components', 'synth_ui', 'src', 'synth_ui.c');
const cssFile = path.join(root, 'web', 'assets', 'docs.css');

const problems = [];

function check(ok, message) {
  if (!ok) { problems.push(message); }
}

/* --- семейства прошивки --- */

const ui = fs.readFileSync(uiFile, 'utf8');

const enumBlock = ui.match(/typedef enum \{([\s\S]*?)\} nav_group_t;/);
if (!enumBlock) { throw new Error('в ' + path.relative(root, uiFile) + ' нет nav_group_t'); }

const firmware = [];
for (const m of enumBlock[1].matchAll(/^\s*(GRP_\w+)/gm)) {
  if (m[1] !== 'GRP_COUNT') { firmware.push(m[1]); }   /* GRP_COUNT — счётчик, не семейство */
}
check(firmware.length > 0, 'в nav_group_t не нашлось ни одного GRP_*');

/* Имена классов — те же слова, что у GRP_*, строчными: GRP_DRONE -> drone. */
const key = (grp) => grp.replace(/^GRP_/, '').toLowerCase();
const known = new Set(firmware.map(key));

check(ui.includes('GROUP_COLOR[GRP_COUNT]'),
      'в synth_ui.c нет таблицы GROUP_COLOR[GRP_COUNT]');

/* --- цвета в docs.css --- */

const css = fs.readFileSync(cssFile, 'utf8');
const colored = new Set();
for (const m of css.matchAll(/\.lab-(\w+)\s*\{/g)) { colored.add(m[1]); }

for (const name of known) {
  check(colored.has(name), 'docs.css: у семейства ' + name + ' нет цвета .lab-' + name);
}
for (const name of colored) {
  check(known.has(name), 'docs.css: цвет .lab-' + name + ' — семейства ' + name + ' нет в прошивке');
}

/* Начертание: метка плотнее тела страницы. */
const labRule = css.match(/\.lab \{([\s\S]*?)\}/);
check(labRule && /font-weight:\s*600/.test(labRule[1]),
      'docs.css: у .lab нет полужирного начертания (font-weight: 600)');
check(labRule && /var\(--lab-ink/.test(labRule[1]),
      'docs.css: цвет .lab не берётся из переменной --lab-ink');

/* --- разметка --- */

const files = fs.readdirSync(webDir).filter((f) => f.endsWith('.html')).sort();
const counts = new Map();
const plain = [];
let total = 0;

for (const name of files) {
  const text = fs.readFileSync(path.join(webDir, name), 'utf8');

  for (const m of text.matchAll(/<span class="([^"]*\blab\b[^"]*)">([^<]*)<\/span>/g)) {
    const classes = m[1].split(/\s+/);
    const word = m[2];
    total += 1;

    const extra = classes.filter((c) => c !== 'lab' && !/^lab-/.test(c));
    check(extra.length === 0, name + ': у рамки «' + word + '» лишний класс ' + extra.join(' '));

    const fams = classes.filter((c) => /^lab-/.test(c)).map((c) => c.slice(4));
    check(fams.length <= 1, name + ': у рамки «' + word + '» два семейства: ' + fams.join(', '));

    if (fams.length === 0) {
      plain.push(name + ': ' + word);
      continue;
    }

    const fam = fams[0];
    check(known.has(fam), name + ': у рамки «' + word + '» семейство ' + fam + ', которого нет в прошивке');
    counts.set(fam, (counts.get(fam) || 0) + 1);

    check(word.length > 0, name + ': пустая рамка');
    check(word === word.toUpperCase(),
          name + ': рамка «' + word + '» набрана не прописными, как на приборе');
  }
}

/* Без цвета остаётся одно слово — ACCENT, названное в тексте как общее для двух сеток. */
check(plain.length <= 1,
      'без цвета ' + plain.length + ' рамок: ' + plain.join('; '));

/* --- итог --- */

if (problems.length) {
  console.log('НЕ ПРОШЛО, ' + problems.length + ':');
  problems.forEach((p) => console.log('  ' + p));
  process.exit(1);
}

const list = [...known].map((k) => k + ' ' + (counts.get(k) || 0)).join(', ');
console.log('OK: ' + total + ' рамок в ' + files.length + ' страницах, семейства совпадают с прошивкой (' +
            firmware.length + '), цвет есть у каждого: ' + list +
            '; без цвета ' + plain.length + ' — слово, общее для двух сеток.');
