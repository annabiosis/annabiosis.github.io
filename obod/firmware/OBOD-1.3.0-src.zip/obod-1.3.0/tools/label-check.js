/*
 * Цвета семейств прибора на сайте.
 *
 * Проверяется то, что нельзя увидеть в диффе:
 *
 *   tokens.css называет чернила для всех девяти семейств — и в тёмной теме, и в светлой:
 *   на светлом фоне те же тона не читаются, поэтому у каждой темы свой набор;
 *   каждая семья в справочнике имеет класс-носитель .fam-*;
 *   на собранных страницах семейство носит свой класс, а метка сектора — точку цвета.
 *
 * Запуск: node tools/label-check.js
 */
'use strict';

const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const tokens = fs.readFileSync(path.join(root, 'web', 'system', 'tokens.css'), 'utf8');

/* Девять семейств и их код — те же, что на карте прибора. */
const FAMILIES = {
  'fam-drn': 'DRN',
  'fam-lfo': 'LFO',
  'fam-ld': 'LD',
  'fam-scl': 'GEN',
  'fam-prc': 'PRC',
  'fam-bas': 'BAS',
  'fam-fx': 'FX',
  'fam-lvl': 'LVL',
  'fam-prs': 'PRS'
};

const problems = [];
const check = (ok, msg) => { if (!ok) { problems.push(msg); } };

/* Тёмная тема — в :root, светлая — в блоке [data-theme="light"]. */
const lightAt = tokens.indexOf(':root[data-theme="light"]');
const darkPart = lightAt > 0 ? tokens.slice(0, lightAt) : tokens;
const lightPart = lightAt > 0 ? tokens.slice(lightAt) : '';

for (const fam of Object.keys(FAMILIES)) {
  const ink = '--' + fam.replace('fam-', 'fam-') + '-ink';
  check(darkPart.includes(ink), 'tokens.css: у ' + fam + ' нет чернил для тёмной темы (' + ink + ')');
  check(lightPart.includes(ink), 'tokens.css: у ' + fam + ' нет чернил для светлой темы (' + ink + ')');
  check(new RegExp('\\.' + fam + '\\s*\\{').test(tokens), 'tokens.css: нет класса .' + fam);
  check(new RegExp('\\.' + fam + '\\s*\\{\\s*--fam-ink').test(tokens),
        'tokens.css: класс .' + fam + ' не задаёт --fam-ink');
}

/* Страницы: семейство носит свой класс, метка — точку. */
const famPages = {
  'fam-drn': 'ref-drone.html',
  'fam-lfo': 'ref-lfo.html',
  'fam-ld': 'ref-lead.html',
  'fam-scl': 'ref-time.html',
  'fam-prc': 'ref-perc.html',
  'fam-bas': 'ref-bass.html',
  'fam-fx': 'ref-fx.html',
  'fam-lvl': 'ref-mix.html',
  'fam-prs': 'ref-store.html'
};

for (const [fam, file] of Object.entries(famPages)) {
  const p = path.join(root, 'web', file);
  check(fs.existsSync(p), 'нет страницы ' + file);
  if (!fs.existsSync(p)) { continue; }

  const html = fs.readFileSync(p, 'utf8');
  check(html.includes('doc-main ' + fam), file + ': страница не носит класс ' + fam);
  check(html.includes('<span class="dot"></span>'), file + ': у метки сектора нет точки цвета');
  check(html.includes(FAMILIES[fam]), file + ': на странице нет кода сектора ' + FAMILIES[fam]);
}

if (problems.length) {
  console.log('НЕ ПРОШЛО, ' + problems.length + ':');
  problems.forEach((p) => console.log('  ' + p));
  process.exit(1);
}

console.log('OK: девять семейств с цветом в обеих темах; каждая страница носит свой класс и код');
