# -*- coding: utf-8 -*-
"""Надписи с экрана прибора — в рамку и в цвет семейства (класс .lab .lab-xxx).

Семейство берётся из прошивки: имя страницы даёт цвет страницы, ручка — цвет
страницы, на которой она стоит. У слова, которое стоит на нескольких страницах
разных семейств (CUTOFF, DEPTH, SPEED, ENV), решает страница документа: CUTOFF в
ref-drone — дрон, он же в ref-lead — лид. Несколько слов не выводятся ни из чего
и перечислены ниже руками; слова, общие для двух семейств и названные в тексте
именно как общие (ACCENT), остаются без цвета.

Запуск из корня репозитория: python tools/label-wrap.py
"""
import collections
import glob
import io
import re
import sys

sys.stdout.reconfigure(encoding="utf-8")

UI = "components/synth_ui/src/synth_ui.c"

# Ключ класса -> семейство GRP_* в прошивке.
GROUPS = {
    "drone": "GRP_DRONE",
    "lead": "GRP_LEAD",
    "gen": "GRP_GEN",
    "perc": "GRP_PERC",
    "fx": "GRP_FX",
    "mix": "GRP_MIX",
    "view": "GRP_VIEW",
    "preset": "GRP_PRESET",
}

# Страница документа -> семейство, которым красится слово, если оно стоит на
# нескольких страницах прибора. Справочные страницы разложены по семействам.
DOC = {
    "ref-drone.html": "drone",
    "ref-lead.html": "lead",
    "ref-time.html": "gen",
    "ref-perc.html": "perc",
    "ref-fx.html": "fx",
    "ref-mix.html": "mix",
    "ref-system.html": "view",
    "ref-preset.html": "preset",
}

# Слова, которые не ручки и не страницы: значения и приёмники модуляции.
BY_LABEL = {
    "CONS": "drone",       # FOLLOW дрона
    "FULL": "drone",       # он же
    "PAN": "drone",        # приёмник модуляции, LFO — страница дрона
    "FILT+PAN": "drone",   # он же
    "PERC PIT": "perc",    # приёмники модуляции перкуссии
    "PIT+DEC": "perc",
    "PIT+ENV": "perc",
    "PITCH": "perc",       # ручки и значения страницы рисунка
    "QUANT": "perc",
    "RMB": "perc",
}

# Где страница документа не решает: слово стоит на странице другого семейства.
BY_PLACE = {
    ("ref-perc.html", "ENV"): "perc",     # огибающая удара, не огибающая лида
    ("under.html", "ENV"): "perc",
    ("under.html", "DECAY"): "perc",
    ("ref-preset.html", "FORGET"): "view",  # значения PATCH на OPTIONS
    ("ref-preset.html", "STORE"): "view",
    ("ref-preset.html", "RANDOM"): "view",
    ("under.html", "RANDOM"): "drone",   # форма LFO, а LFO — страница дрона
    ("under.html", "MODE"): "fx",        # режим времени у дилея
    ("ref-drone.html", "LOW"): "drone",   # режимы фильтра дрона, а не полосы микшера
    ("ref-drone.html", "MID"): "drone",
    ("ref-drone.html", "HIGH"): "drone",
}

# Слово общее для двух сеток и сказано именно как общее — остаётся без цвета.
NEUTRAL = {("ref.html", "ACCENT")}

WORDS = """
ACCENT ATTACK CHORUS COMP CUTOFF DAMP DECAY DENSITY DEPTH DEST DIR DRAWER DRONE DUCK ENV
FDBK FILL FOLLOW GATE GROOVE HIGH K.TRCK KIT LEAD LEN LEVELS LFO LOAD LOW MACRO MASTER MIC MID
MIX MODE MORPH NOTE OCT OCTAVE ONES OPTIONS OSC PAN PARAM PATCH PERC PITCH PORTA PRESET
PULSES PUNCH QUANT RANDOM RANGE RATE RELEASE RES RESET REVERB RING RMB RND ROTATE SAVE SCALE
SCATTER SCREEN SHAPE SIZE SLIDE SPEED STEPS SUSTAIN SWING SYNC SYSTEM TEMPO TIMBRE TIME TONE
TRANSPORT TRIG TUNE VAR VOICE VOL WIDTH FREE FULL CONS FORGET HOLD SKIP STORE
""".split()

PAIRS = ["CHR SENDS", "DEL SENDS", "DRONE FLTR", "FILT+LEAD", "FILT+PAN", "FILT+PERC",
         "LEAD ARP", "LEAD ENV", "LEAD EUCLID", "LEAD SCALE", "LEAD TONE", "LEAD+PAN",
         "LEAD+PERC", "LEAD+PNCH", "MACRO INV", "MACRO 10", "MIDI IN", "PAN+PNCH",
         "PERC PIT", "PERC SEQ", "PERC MIX", "PIT+DEC", "PIT+E+D", "PIT+ENV", "PUNCH+DEC",
         "PUNCH+PIT", "REV SENDS", "RING FX", "RND DEL", "WEAK VEL", "H.OSC", "L.OSC", "M.OSC"]

ALL = None          # собирается ниже, когда прочитаны таблицы прошивки


def alt(lab):
    return r"\s+".join(re.escape(w) for w in lab.split(" "))


SKIP = ("code", "pre", "a", "b", "strong", "h1", "h2", "h3", "h4", "title", "script", "style",
        "textarea")
TOKEN = re.compile(r"<!--.*?-->|<[^>]*>", re.S)
WRAPPED = re.compile(r'<span class="lab(?:\s[^"]*)?">([^<]*)</span>')


def read_tables(ui):
    """KNOBS_* -> подписи ручек; PAGES -> (заголовок, таблица, семейство)."""
    tables = {}
    for m in re.finditer(r"static const ui_knob_t (KNOBS_\w+)\[\] = \{(.*?)\n\};", ui, re.S):
        tables[m.group(1)] = re.findall(r'\{\s*"([^"]+)"', m.group(2))

    body = ui[ui.index("static const ui_page_t PAGES[PAGE_COUNT] = {"):]
    body = body[:body.index("\n};")]

    pages = []
    for chunk in body.split("[PAGE_")[1:]:
        m = re.match(r"\w+\]\s*=\s*\{\"([^\"]+)\",\s*\"([^\"]+)\",\s*(\w+)", chunk)
        g = re.search(r"(GRP_\w+)", chunk)
        if m and g:
            pages.append((m.group(1), m.group(3), g.group(1)))
    return tables, pages


def build_maps(ui):
    tables, pages = read_tables(ui)
    by_group = {v: k for k, v in GROUPS.items()}

    titles = {title: by_group[grp] for title, _tab, grp in pages if grp in by_group}

    knobs = collections.defaultdict(set)
    for _title, tab, grp in pages:
        for lab in tables.get(tab, []):
            if grp in by_group:
                knobs[lab].add(by_group[grp])
    return titles, knobs


TITLES, KNOBS = build_maps(io.open(UI, encoding="utf-8").read())

# Список надписей: ручной — для того, что на экране есть, а ручкой не является
# (шторка, транспорт, макрос), и прошивочный — каждая ручка и каждая страница. Второй
# растёт сам: новая ручка попадает в документацию уже в рамке, без правки скрипта.
ALL = sorted(set(WORDS) | set(PAIRS) | set(KNOBS) | set(TITLES), key=len, reverse=True)

# Точка в конце фразы надписи не мешает: «LEAD EUCLID.» — это пара и точка после неё.
# Точка внутри слова — мешает: так в K.TRCK не находится TRCK, а в MIX.json — MIX.
PATTERN = re.compile(r"(?<![\w+&./-])(" + "|".join(alt(x) for x in ALL) + r")(?![\w+&/-])(?!\.\w)")


def family(lab, page):
    """Семейство надписи: страница прибора, место, своя ручка, и лишь потом страница документа.

    Своя ручка идёт раньше страницы документа: WEAK VEL живёт на OPTIONS и остаётся
    серой даже на странице про ударные, а CUTOFF, DEPTH и SPEED стоят на нескольких
    страницах сразу, и у них решает страница документа.
    """
    if (page, lab) in NEUTRAL:
        return None
    if lab in TITLES:
        return TITLES[lab]
    if (page, lab) in BY_PLACE:
        return BY_PLACE[(page, lab)]
    if lab in BY_LABEL:
        return BY_LABEL[lab]
    found = KNOBS.get(lab, ())
    if len(found) == 1:
        return next(iter(found))
    return DOC.get(page)


def wrap_text(t, page):
    def put(m):
        lab = " ".join(m.group(1).split())      # перенос строки в разметке — обычный пробел
        fam = family(lab, page)
        cls = "lab" if fam is None else "lab lab-" + fam
        return '<span class="%s">%s</span>' % (cls, lab)

    return PATTERN.sub(put, t)


def process(t, page):
    out, pos, depth = [], 0, 0
    for m in TOKEN.finditer(t):
        text = t[pos:m.start()]
        if text:
            out.append(wrap_text(text, page) if depth == 0 else text)
        tag = m.group(0)
        if tag.startswith("<!--"):
            out.append(tag)                      # комментарий не трогаем и внутрь не смотрим
            pos = m.end()
            continue
        mm = re.match(r"</?\s*([a-zA-Z0-9]+)", tag)
        nm = (mm.group(1).lower() if mm else "")
        skip = nm in SKIP or 'class="lab' in tag
        selfclosed = tag.endswith("/>") or nm in ("br", "hr", "img", "meta", "link", "input")
        if skip and not selfclosed:
            depth = max(0, depth - 1) if tag.startswith("</") else depth + 1
        out.append(tag)
        pos = m.end()
    tail = t[pos:]
    if tail:
        out.append(wrap_text(tail, page) if depth == 0 else tail)
    return "".join(out)


total = 0
counts = collections.Counter()
plain = collections.Counter()
for path in sorted(glob.glob("web/*.html")):
    page = path.replace("\\", "/").split("/")[-1]
    text = io.open(path, encoding="utf-8", newline="").read()
    text = WRAPPED.sub(lambda m: m.group(1), text)      # прежние рамки снимаются: цвет мог смениться
    text = process(text, page)
    io.open(path, "w", encoding="utf-8", newline="").write(text)
    n = text.count('<span class="lab')
    total += n
    for m in re.finditer(r'<span class="lab(?: lab-(\w+))?">', text):
        counts[m.group(1) or "—"] += 1
    print("%-24s %4d" % (path, n))

print("всего:", total)
print("по семействам:", ", ".join("%s %d" % (k, v) for k, v in counts.most_common()))
