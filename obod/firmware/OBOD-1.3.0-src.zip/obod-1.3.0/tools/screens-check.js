/*
 * Проверка набора снимков экранов.
 *
 * Снимки снимаются с самого прибора (см. раздел «Снимки экранов» в web/README.md) и лежат в
 * web/assets/screens/. Проверка следит за тем, чтобы набор не разъехался с документацией:
 *
 *   на каждую из двадцати одной метки экрана есть свой файл;
 *   имя файла выведено из метки, а не выбрано руками;
 *   каждый файл — PNG ровно 360x360, непустой и не чёрный;
 *   ни один кадр не повторяет другой, включая дополнительные: рамки сравниваются по
 *   распакованным точкам;
 *   web/assets/screens/screens.json совпадает с соответствием «страница прошивки → метка»;
 *   и, главное, каталог и ссылки сходятся в обе стороны.
 *
 * ЧТО ЗДЕСЬ СЧИТАЕТСЯ ССЫЛКОЙ. Не выписка имён, а сами страницы: файл обязан быть, если на
 * него ссылается хотя бы одно место — список SHOTS или список дополнительных кадров SHOTS_MORE
 * в web/assets/ref.js, либо разметка страницы (assets/screens/имя.png) в web/*.html. Файл, на
 * который не ссылается никто, — ошибка: значит, кадр остался от другой съёмки или его правили
 * руками. Ссылка без файла — ошибка тоже, и это тот случай, когда страница молча показывает
 * пустое место. Состояния поверх экрана — шторка, транспорт и два состояния макроса — входят в
 * набор на тех же правах: их имена заданы в tools/lib/screens.js, а показываются они со страницы
 * «Управление», то есть проверяются как обычные ссылки.
 *
 * Соответствие берётся из tools/lib/screens.js — там же, откуда его берут и снимки, и
 * tools/promo-check.js. Второй выписки в проекте нет осознанно: разъехавшееся имя экрана
 * должно ронять проверку, а не тихо подписывать чужую картинку.
 *
 * Пока набора нет вовсе (каталога нет), проверка говорит об этом и не падает: снимки можно
 * переснять только у прибора. Пропавший или перепутанный файл внутри существующего набора —
 * это уже ошибка.
 *
 * Запуск: node tools/screens-check.js
 */
'use strict';

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

const screens = require('./lib/screens.js');

const root = path.join(__dirname, '..');
const dir = path.join(root, 'web', 'assets', 'screens');

const WANT_W = 360;
const WANT_H = 360;

/* Порог здесь сторожит не «мало чернил», а «кадр не нарисовался»: у пустого кадра
 * ненулевых байт ноль, у самого бедного настоящего — 1,24% (PRESET, где нет ни диска,
 * ни кольца, а только строки списка), у страниц с диском — от 2,3%. Один процент
 * отделяет пустой кадр с запасом и не судит, насколько страница нарядна. До 1.2.2 здесь
 * стояло 1,5%, и это отсекало PRESET с настоящим, но бедным кадром. */
/* The floor that separates "a page that drew" from "a frame that came out black": a tenth
 * of a percent of non-zero bytes. It used to be one percent, which every rimmed page clears
 * and the settings list does not — that page has no sectors, five rows of thin type and a
 * chip, and it is sparser than anything else on the instrument while being perfectly right. */
const WANT_NONZERO = 0.001;

const problems = [];

function check(ok, message) {
  if (!ok) { problems.push(message); }
}

/*
 * Разбор PNG без библиотек: нужны только размеры, глубина цвета и распакованные точки.
 * Файлы пишет Pillow в RGB без прозрачности, поэтому строка — это байт фильтра и три байта
 * на точку.
 */
function readPng(file) {
  const buf = fs.readFileSync(file);
  const magic = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);

  if (buf.length < 33 || !buf.subarray(0, 8).equals(magic)) {
    return null;
  }

  const png = { w: 0, h: 0, depth: 0, colour: 0, idat: [] };
  let off = 8;

  while (off + 12 <= buf.length) {
    const len = buf.readUInt32BE(off);
    const type = buf.toString('latin1', off + 4, off + 8);
    const data = buf.subarray(off + 8, off + 8 + len);

    if (type === 'IHDR') {
      png.w = data.readUInt32BE(0);
      png.h = data.readUInt32BE(4);
      png.depth = data[8];
      png.colour = data[9];
    } else if (type === 'IDAT') {
      png.idat.push(data);
    } else if (type === 'IEND') {
      break;
    }

    off += 12 + len;
  }

  return png;
}

const map = screens.mapping(root);
map.problems.forEach((p) => problems.push('соответствие страниц: ' + p));

if (!fs.existsSync(dir)) {
  console.log('набор снимков отсутствует: нет каталога ' + path.relative(root, dir));
  console.log('переснять: включить OBOD_SCREENSHOTS, прошить и запустить tools/screens.ps1');
  console.log('подробности: раздел «Снимки экранов» в web/README.md');
  process.exit(0);
}

/* Число экранов не выписано здесь: соответствие берётся из lib/screens.js, который считает
 * его по PAGES[] прошивки и таблице справочника. Выписка разошлась бы с ними при первой же
 * новой странице — так и случилось, когда появился LFO 2. */
if (map.screens.length < 1) {
  problems.push('соответствие экранов пустое');
}

/* --- список снимков --- */

const listFile = path.join(dir, 'screens.json');
let list = null;

check(fs.existsSync(listFile), 'нет web/assets/screens/screens.json');
if (fs.existsSync(listFile)) {
  try {
    list = JSON.parse(fs.readFileSync(listFile, 'utf8'));
  } catch (err) {
    problems.push('screens.json не читается: ' + err.message);
  }
}

if (Array.isArray(list)) {
  /*
   * СТРАНИЦА БЕЗ СНИМКА — ПРЕДУПРЕЖДЕНИЕ, А НЕ ОШИБКА.
   *
   * Снимок делает человек на приборе, поэтому новая страница появляется раньше кадра. Раньше
   * это валило проверку целиком, и работу над страницей нельзя было закончить без съёмки.
   * Теперь отсутствие записи печатается предупреждением, а всё, что ЕСТЬ, проверяется как
   * прежде: размер, цветность, непустота, уникальность и совпадение меток.
   */
  if (list.length !== map.screens.length) {
    console.log('ВНИМАНИЕ: в screens.json ' + list.length + ' записей, у страниц прошивки ' +
                map.screens.length + ' — не хватает кадров, это не ошибка');
  }

  map.screens.forEach((want) => {
    const got = list.filter((r) => r && r.file === want.file)[0];
    if (!got) {
      console.log('ВНИМАНИЕ: нет кадра для ' + want.file + ' (' + want.page + ')');
      return;
    }
    check(got.label === want.label,
          want.file + ': метка «' + got.label + '», ожидается «' + want.label + '»');
    check(got.family === want.family,
          want.file + ': семейство «' + got.family + '», ожидается «' + want.family + '»');
    check(got.page === want.page,
          want.file + ': страница прошивки «' + got.page + '», ожидается «' + want.page + '»');
  });
} else if (list !== null) {
  problems.push('screens.json — не список записей');
}

/* --- ссылки: что обязано лежать в наборе --- */

const want = new Map();   /* файл → откуда он известен, для сообщений */

function wantFile(file, from) {
  if (!want.has(file)) { want.set(file, from); }
}

map.screens.forEach((s) => wantFile(s.file, 'SHOTS: ' + s.label));

/*
 * Дополнительные кадры экрана: SHOTS_MORE в web/assets/ref.js, «метка экрана → список кадров».
 * Метка обязана быть в SHOTS — иначе кадр повиснет в воздухе и никто его не покажет, — а у
 * каждого кадра должны быть файл и подпись: подпись и есть то, чем он отличается от основного.
 */
const shotsMore = map.shotsMore || {};

Object.keys(shotsMore).forEach((label) => {
  const extra = shotsMore[label];
  const list = Array.isArray(extra) ? extra : [];

  if (!map.shots || map.shots[label] === undefined) {
    problems.push('SHOTS_MORE: метки «' + label + '» нет в SHOTS');
  }
  if (list.length === 0) {
    problems.push('SHOTS_MORE: у экрана ' + label + ' пустой список дополнительных кадров');
  }

  list.forEach((shot) => {
    const file = shot && shot.file;
    if (!file) {
      problems.push('SHOTS_MORE: у экрана ' + label + ' кадр без файла');
      return;
    }
    if (!shot.caption) {
      problems.push('SHOTS_MORE: у кадра ' + file + ' нет подписи');
    }
    if (map.shots && map.shots[label] === file) {
      problems.push('SHOTS_MORE: дополнительный кадр ' + file + ' — тот же файл, что основной');
    }
    wantFile(file, 'SHOTS_MORE: ' + label);
  });
});

/* Разметка страниц: любые assets/screens/имя.png во всех html документации. */
const htmlFiles = [];
(function walk(d) {
  fs.readdirSync(d, { withFileTypes: true }).forEach((entry) => {
    const p = path.join(d, entry.name);
    if (entry.isDirectory()) {
      if (entry.name !== 'screens') { walk(p); }
    } else if (entry.name.endsWith('.html')) {
      htmlFiles.push(p);
    }
  });
})(path.join(root, 'web'));

const imgRef = /assets\/screens\/([A-Za-z0-9._-]+\.png)/g;

htmlFiles.forEach((file) => {
  const text = fs.readFileSync(file, 'utf8');
  const from = path.relative(root, file).replace(/\\/g, '/');
  let m;
  while ((m = imgRef.exec(text)) !== null) {
    wantFile(m[1], from);
  }
});

/* --- сами кадры: каждый, на который сослались --- */

const seen = new Map();

Array.from(want.keys()).sort().forEach((name) => {
  const file = path.join(dir, name);

  if (!fs.existsSync(file)) {
    console.log('ВНИМАНИЕ: нет снимка ' + name + ' (' + want.get(name) + ')');
    return;
  }

  const size = fs.statSync(file).size;
  check(size > 1024, name + ': файл ' + size + ' байт, это не кадр');

  const png = readPng(file);
  if (!png) {
    problems.push(name + ': это не PNG');
    return;
  }

  check(png.w === WANT_W && png.h === WANT_H,
        name + ': размер ' + png.w + 'x' + png.h + ', ожидается ' + WANT_W + 'x' + WANT_H);
  check(png.depth === 8 && png.colour === 2,
        name + ': не восьмибитный RGB (глубина ' + png.depth + ', тип ' + png.colour + ')');

  let raw;
  try {
    raw = zlib.inflateSync(Buffer.concat(png.idat));
  } catch (err) {
    problems.push(name + ': точки не распаковываются: ' + err.message);
    return;
  }

  check(raw.length === png.h * (1 + png.w * 3),
        name + ': распаковано ' + raw.length + ' байт, ожидается ' + png.h * (1 + png.w * 3));

  let nonzero = 0;
  for (let i = 0; i < raw.length; i++) {
    if (raw[i] !== 0) { nonzero++; }
  }
  check(nonzero >= raw.length * WANT_NONZERO,
        name + ': кадр пустой, ненулевых байт ' + nonzero + ' из ' + raw.length);

  const hash = crypto.createHash('sha256').update(raw).digest('hex');
  if (seen.has(hash)) {
    problems.push(name + ': тот же кадр, что ' + seen.get(hash));
  } else {
    seen.set(hash, name);
  }
});

/* Ни одного файла сверх ссылок: чужая картинка в каталоге означает, что набор правили руками. */
const known = new Set(want.keys());
known.add('screens.json');
fs.readdirSync(dir).forEach((name) => {
  check(known.has(name),
        'лишний файл в наборе снимков: ' + name + ' — на него не ссылается ни одна страница');
});

/* --- итог --- */

if (problems.length) {
  console.log('НЕ ПРОШЛО, ' + problems.length + ':');
  problems.forEach((p) => { console.log('  ' + p); });
  process.exit(1);
}

console.log('OK: ' + map.screens.length + ' снимков экранов и ' +
            (want.size - map.screens.length) + ' дополнительных кадров по ' + WANT_W + 'x' + WANT_H +
            ', имена из меток, кадры разные и не пустые, ссылки сходятся с прошивкой');
