"""PUNCH на голосе: что ручка делает с атакой и со щелчком, по числам из прошивки.

Фигура проверяется в tools/punch-shape.py. Здесь — звук, и проверяется он тем же способом,
что и остальные гейты: константы читаются из synth_perc.cpp, а арифметика удара повторяется
целиком, без порта всего голоса, потому что ручка трогает ровно две вещи.

  1. В СЕРЕДИНЕ ХОДА ГОЛОС ТОТ ЖЕ, ЧТО БЫЛ. Атака равна ровно PERC_ATTACK_MS, доля битера
     умножается на единицу, добавочного щелчка нет, и счётчик удержания щелчка совпадает с
     прежней длиной атаки — то есть на 0.5 не меняется ни одно число, которое читает голос.
  2. КРАЯ ХОДА — ЭТО АТАКА В ВОСЕМЬ МИЛЛИСЕКУНД И В ВОСЬМУЮ ДОЛЮ МИЛЛИСЕКУНДЫ. Нижний край
     обязан быть слышимой волной, верхний — ступенькой: обе границы проверяются в отсчётах.
  3. РУЧКА СЛЫШНА НА КАЖСТОМ БАРАБАНЕ, А НЕ ТОЛЬКО НА БОЧКЕ. У битера есть предел: выше
     двух октав от низа PITCH его доля равна нулю, и это все хэты и половина снейров. Поэтому
     выше середины голос получает щелчок, который битеру не принадлежит, и проверка требует,
     чтобы на хэте он был, а на 0.5 его не было вовсе.
  4. НИ ОДНО ЧИСЛО НЕ УХОДИТ ИЗ ПОРЯДКА. Атака не может стать короче одного отсчёта, а
     добавочный щелчок не может стать отрицательным: и то и другое проверяется на краях и
     на выбросах, включая бесконечность.

Печатается таблица по семи положениям ручки: атака в отсчётах и в миллисекундах, множитель
битера, добавочный щелчок на хэте и на бочке.
"""

import math
import re
import sys
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")

SRC = Path("components/synth_dsp/src/synth_perc.cpp")
SR = 48000


def fconst(name):
    text = SRC.read_text(encoding="utf-8")
    m = re.search(r"constexpr\s+float\s+%s\s*=\s*([-0-9.eEf]+)f?\s*;" % name, text)
    if not m:
        raise SystemExit("нет константы %s в %s" % (name, SRC))
    return float(m.group(1).rstrip("f"))


ATTACK_MS = fconst("PERC_ATTACK_MS")
CLICK_GAIN = fconst("PERC_CLICK_GAIN")
CLICK_MS = fconst("PERC_CLICK_MS")
BEATER_OCT = fconst("PERC_BEATER_OCT")
P_ATTACK_OCT = fconst("PERC_PUNCH_ATTACK_OCT")
P_CLICK_MIN = fconst("PERC_PUNCH_CLICK_MIN")
P_CLICK_SPAN = fconst("PERC_PUNCH_CLICK_SPAN")
P_EXTRA = fconst("PERC_PUNCH_EXTRA")
P_EXTRA_FROM = fconst("PERC_PUNCH_EXTRA_FROM")


def punch_numbers(punch):
    """То, что perc_strike() считает из положения ручки."""
    attack_ms = ATTACK_MS * math.pow(2.0, (0.5 - punch) * P_ATTACK_OCT)
    attack_left = int(SR * attack_ms * 0.001 + 0.5)
    if attack_left < 1:
        attack_left = 1
    beater_mul = P_CLICK_MIN + P_CLICK_SPAN * punch
    extra = ((punch - P_EXTRA_FROM) * 2.0 * P_EXTRA * CLICK_GAIN) if punch > P_EXTRA_FROM else 0.0
    hold = int(SR * ATTACK_MS * 0.001 + 0.5)
    if hold < 1:
        hold = 1
    return attack_ms, attack_left, beater_mul, extra, hold


def beater_share(pitch_hz):
    """Доля битера из perc_strike(): единица на низу PITCH и ноль через две октавы."""
    octaves = math.log2(pitch_hz / PITCH_MIN_HZ)
    if octaves >= BEATER_OCT:
        return 0.0
    return 1.0 - (max(0.0, octaves) / BEATER_OCT)


PITCH_MIN_HZ = 35.0     # PERC_PITCH_MIN_HZ, начало шкалы PITCH


def main():
    print("PUNCH на голосе: атака и щелчок, числа из synth_perc.cpp")
    print("  константы: атака %.3f мс, щелчок %.3f, предел битера %.1f октавы, "
          "размах ручки %.0f октав" % (ATTACK_MS, CLICK_GAIN, BEATER_OCT, P_ATTACK_OCT))
    print()
    print("  ручка  атака мс   отсчётов  битер   хэт 1000 Гц   бочка 50 Гц")

    for punch in (0.0, 0.25, 0.5, 0.625, 0.75, 0.875, 1.0):
        attack_ms, attack_left, beater_mul, extra, hold = punch_numbers(punch)
        hat = CLICK_GAIN * beater_share(1000.0) * beater_mul + extra
        kick = CLICK_GAIN * beater_share(50.0) * beater_mul + extra
        print("  %.3f  %8.4f  %8d  %5.2f  %11.4f  %11.4f"
              % (punch, attack_ms, attack_left, beater_mul, hat, kick))

    # 1. Середина: ни одного изменения.
    attack_ms, attack_left, beater_mul, extra, hold = punch_numbers(0.5)
    assert abs(attack_ms - ATTACK_MS) < 1e-9, "в середине атака не равна PERC_ATTACK_MS"
    assert attack_left == int(SR * ATTACK_MS * 0.001 + 0.5), "в середине атака не та же"
    assert abs(beater_mul - 1.0) < 1e-9, "в середине битер не умножается на единицу"
    assert extra == 0.0, "в середине появился добавочный щелчок"
    assert hold == attack_left, "в середине удержание щелчка не равно прежней атаке"
    print("\n  середина хода: атака %.3f мс, битер x%.2f, добавочного щелчка нет — голос прежний"
          % (attack_ms, beater_mul))

    # 2. Края: восемь миллисекунд и восьмая доля.
    lo_ms, lo_left, _, _, _ = punch_numbers(0.0)
    hi_ms, hi_left, _, _, _ = punch_numbers(1.0)
    assert abs(lo_ms - ATTACK_MS * 8.0) < 1e-6, "нижний край не в восемь раз длиннее"
    assert abs(hi_ms - ATTACK_MS / 8.0) < 1e-6, "верхний край не в восемь раз короче"
    assert lo_left > 300, "нижний край короче семи миллисекунд"
    assert hi_left >= 1, "верхний край короче одного отсчёта"
    print("  края: %.3f мс (%d отсчётов) и %.4f мс (%d отсчётов)"
          % (lo_ms, lo_left, hi_ms, hi_left))

    # 3. Хэт: битер его не достаёт, значит ручка обязана дать щелчок сама.
    assert beater_share(1000.0) == 0.0, "битер дотягивается до хэта — проверка не про то"
    _, _, _, extra_top, _ = punch_numbers(1.0)
    _, _, _, extra_mid, _ = punch_numbers(0.5)
    assert extra_top > 0.0, "на верху ручки у хэта нет щелчка"
    assert extra_mid == 0.0, "на середине у хэта появился щелчок"
    assert CLICK_GAIN * beater_share(1000.0) + extra_top > 0.05, "на хэте верх ручки еле слышен"
    print("  хэт: доля битера 0.00, добавочный щелчок на верху %.3f (у бочки доля битера %.2f)"
          % (extra_top, beater_share(50.0)))

    # 4. Порядок: атака не короче отсчёта, щелчок не отрицателен, выбросы не ломают.
    for punch in (-1.0, 0.0, 0.5, 1.0, 2.0, float("nan"), float("inf")):
        p = punch
        if not (p >= 0.0):
            p = 0.0
        elif p > 1.0:
            p = 1.0
        attack_ms, attack_left, beater_mul, extra, hold = punch_numbers(p)
        assert attack_left >= 1, "атака короче отсчёта при %r" % punch
        assert extra >= 0.0, "добавочный щелчок отрицателен при %r" % punch
        assert beater_mul >= 0.0, "множитель битера отрицателен при %r" % punch
    print("  порядок: атака не короче отсчёта, щелчок не отрицателен, nan и бесконечность зажаты")

    print("\nOK: PUNCH — голос трогает ровно две вещи, в середине не меняет ничего, "
          "на хэте слышен через свой щелчок")
    return 0


if __name__ == "__main__":
    sys.exit(main())
