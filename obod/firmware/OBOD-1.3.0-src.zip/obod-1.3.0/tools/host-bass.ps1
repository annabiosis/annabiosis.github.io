# ---------------------------------------------------------------------------
# The bass layer as WAV files, rendered by the firmware's own DSP on the desktop.
#
# The bench in tools/host-stress.ps1 proves the audio path does not fall over; this
# script answers the other question, the one only an ear can usually answer: what does
# the bass sound like. It builds tools/host/bass_wav.cpp against the same sources with
# the same Zig, renders four seconds per kit into build\bass, and then (if Python with
# numpy is present) prints the numbers beside each take: peak, RMS, the fundamental,
# the level of the first six harmonics and the biggest sample-to-sample jump.
#
#   pwsh -File tools/host-bass.ps1
#   pwsh -File tools/host-bass.ps1 -Kits 0,7,19
#   pwsh -File tools/host-bass.ps1 -Seconds 6 -Tone 0.5 -Decay 0.7 -Drive 0
# ---------------------------------------------------------------------------
[CmdletBinding()]
param(
    [int[]]$Kits = @(),
    [double]$Seconds = 4,
    [double]$Tone = -1,
    [double]$Decay = -1,
    [double]$Res = -1,
    [double]$Len = -1,
[double]$Sub = -1,
    [double]$Slide = -1,
    [double]$Gate = -1,
    [double]$Pat = -1,
    [double]$Var = -1,
    [double]$Accent = -1,
    [string]$Zig = '',
    [switch]$NoBuild
)

$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $PSScriptRoot
$hostDir = Join-Path $root 'tools\host'
$buildDir = Join-Path $root 'build\bass'
$exe = Join-Path $buildDir 'bass_wav.exe'

New-Item -ItemType Directory -Force -Path $buildDir | Out-Null

if (-not $NoBuild) {
    if (-not $Zig) {
        $onPath = Get-Command zig -ErrorAction SilentlyContinue
        if ($onPath) {
            $Zig = $onPath.Source
        } else {
            $Zig = 'C:\Users\Blaq\.dsh\toolchains\zig-x86_64-windows-0.14.1\zig.exe'
        }
    }

    if (-not (Test-Path $Zig)) {
        throw "host-bass: compiler not found at $Zig"
    }

    $dspSources = @(Get-ChildItem -Path (Join-Path $root 'components\synth_dsp\src') -Filter '*.cpp' |
                    Sort-Object Name |
                    ForEach-Object { $_.FullName })

    $sources = $dspSources + @(
        (Join-Path $hostDir 'platform.cpp'),
        (Join-Path $hostDir 'bass_wav.cpp')
    )

    $zigArgs = @(
        'c++',
        '-O2',
        '-std=c++17',
        '-fno-math-errno',
        '-I', (Join-Path $root 'components\synth_dsp\include'),
        '-I', (Join-Path $root 'components\synth_dsp\src'),
        '-I', (Join-Path $root 'components\synth_core\src'),
        '-I', (Join-Path $hostDir 'shim'),
        '-I', $hostDir
    ) + $sources + @('-o', $exe)

    Write-Host "host-bass: compiling $($dspSources.Count) DSP sources with zig"
    & $Zig @zigArgs
    if ($LASTEXITCODE -ne 0) {
        Write-Host "host-bass: compile failed with exit code $LASTEXITCODE" -ForegroundColor Red
        exit $LASTEXITCODE
    }
}

if ($Kits.Count -eq 0) {
    $Kits = 0..29
}

foreach ($kit in $Kits) {
    $exeArgs = @("$kit", "$Seconds", "$Tone", "$Decay", "$Res", "$Gate", "$Pat", "$Var", "$Accent", "$Slide", "-1", "$Len", "$Sub")
    & $exe @exeArgs
    if ($LASTEXITCODE -ne 0) {
        Write-Host "host-bass: kit $kit failed with exit code $LASTEXITCODE" -ForegroundColor Red
        exit $LASTEXITCODE
    }
}
