<#
.SYNOPSIS
    Прогнать автоматический стресс на приборе и вернуть обычную прошивку.

.DESCRIPTION
    Прибор должен быть прошит сборкой с включённым OBOD_STRESS. Скрипт делает всё сам:
    ставит CONFIG_OBOD_STRESS=y в sdkconfig, собирает, прошивает в указанный порт,
    читает журнал заданное время, вытаскивает строки «stress: verdict ...» и складывает
    их в build/stress-<дата>.txt. Полный журнал остаётся рядом, в build/stress-<дата>.log:
    по нему видно, что было до приговора — строки спасения, перегрузки, сбросы.

    После прогона флаг возвращается в то состояние, в котором был до запуска, и, если не
    указан -KeepBuild, собирается и прошивается обычная сборка. Именно поэтому скрипт
    годится для проверки перед выпуском: на приборе не остаётся служебного режима.

    Приговор — одна строка с зерном, номером блока и временем, пиком выхода, числом
    спасений от не-числа и от тишины, пропусками дедлайнов, ошибками записи и признаком
    сброса. Заканчивается словом ok или FAIL. Скрипт возвращает 0, только если приговоры
    есть и ни один не заканчивается на FAIL; иначе — ненулевой код.

    Порт открывается заново после каждого перечисления: у этого прибора COM4 — встроенный
    USB-Serial-JTAG, и прошивка сбрасывает его, убивая открытый дескриптор. Чтение идёт
    через .NET SerialPort, без Python и без idf.py monitor: monitor интерактивен и требует
    Ctrl+] для выхода.

    Устройство режима и что считается провалом — в разделе «Стресс на приборе» файла
    docs/FRAMEWORK.md.

.EXAMPLE
    pwsh -File tools/stress.ps1
    pwsh -File tools/stress.ps1 -Port COM7 -Seconds 180
    pwsh -File tools/stress.ps1 -KeepBuild
#>
#Requires -Version 5.1
[CmdletBinding()]
param(
    [string] $Port = 'COM4',
    [int]    $Seconds = 120,
    [switch] $KeepBuild
)

$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.Encoding]::UTF8

$Root = Split-Path -Parent $PSScriptRoot
$Sdk  = Join-Path $Root 'sdkconfig'
$Build = Join-Path $Root 'build'
$Idf   = Join-Path $PSScriptRoot 'idf.ps1'

if (-not (Test-Path $Sdk)) {
    throw "нет $Sdk — это не чекаут прошивки"
}
if (-not (Test-Path $Build)) {
    New-Item -ItemType Directory -Path $Build | Out-Null
}

$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$verdictPath = Join-Path $Build "stress-$stamp.txt"
$logPath     = Join-Path $Build "stress-$stamp.log"
$sdkBefore   = [IO.File]::ReadAllText($Sdk)

# Флаг ставится в ту же секцию, где живёт флаг снимков. Строку «не задан» надо убрать:
# иначе в sdkconfig окажутся оба ответа, и какой из них прочитает Kconfig, зависит от
# порядка строк.
function Enable-StressFlag {
    $text = [IO.File]::ReadAllText($Sdk)

    if ($text -match '(?m)^\s*CONFIG_OBOD_STRESS=y\s*$') {
        return
    }

    $text = [regex]::Replace($text, '(?m)^[ \t]*CONFIG_OBOD_STRESS=.*\r?\n?', '')
    $text = [regex]::Replace($text, '(?m)^[ \t]*#\s*CONFIG_OBOD_STRESS is not set\r?\n?', '')

    $marker = '# end of Сборка прибора (OBOD)'
    if ($text.Contains($marker)) {
        $text = $text.Replace($marker, "CONFIG_OBOD_STRESS=y`r`n$marker")
    } else {
        $text = $text.TrimEnd() + "`r`nCONFIG_OBOD_STRESS=y`r`n"
    }

    [IO.File]::WriteAllText($Sdk, $text)
}

function Invoke-Idf {
    param([string[]] $IdfArgs, [string] $What)

    & $Idf @IdfArgs
    if ($LASTEXITCODE -ne 0) {
        throw "$What завершилось с кодом $LASTEXITCODE"
    }
}

# Один проход по порту. Возвращает все прочитанные строки; полный журнал пишется сразу,
# чтобы он уцелел, даже если чтение оборвётся.
function Read-StressLog {
    param([string] $Name, [int] $ForSeconds, [string] $Path)

    $deadline = (Get-Date).AddSeconds($ForSeconds)
    $lines = New-Object System.Collections.Generic.List[string]
    $writer = New-Object System.IO.StreamWriter($Path, $false, [Text.UTF8Encoding]::new($false))
    $writer.AutoFlush = $true
    $serial = $null

    function Open-Port {
        param([string] $PortName)

        $until = (Get-Date).AddSeconds(15)
        while ($true) {
            $s = New-Object System.IO.Ports.SerialPort
            $s.PortName       = $PortName
            $s.BaudRate       = 115200
            $s.Parity         = [System.IO.Ports.Parity]::None
            $s.DataBits       = 8
            $s.StopBits       = [System.IO.Ports.StopBits]::One
            $s.Handshake      = [System.IO.Ports.Handshake]::None
            $s.ReadBufferSize = 65536
            $s.ReadTimeout    = 300
            $s.DtrEnable      = $false
            $s.RtsEnable      = $false

            try {
                $s.Open()

                # Сброс под уже открытым портом: сразу после прошивки порт занят, и чтение
                # начиналось только после загрузки, теряя старт журнала и приговоры. Тот же
                # импульс, что делает esptool: RTS низкий-высокий-низкий.
                $s.DtrEnable = $false
                $s.RtsEnable = $true
                Start-Sleep -Milliseconds 150
                $s.RtsEnable = $false
                Start-Sleep -Milliseconds 50

                return $s
            }
            catch {
                if ((Get-Date) -ge $until) { throw }
                Start-Sleep -Milliseconds 300
            }
        }
    }

    try {
        $serial = Open-Port $Name
        Write-Host ("порт {0}, читаю {1} с" -f $Name, $ForSeconds)

        while ((Get-Date) -lt $deadline) {
            try {
                $line = $serial.ReadLine().TrimEnd("`r", "`n")
                $lines.Add($line)
                $writer.WriteLine($line)

                if ($line -match 'stress:|rack: rescue|Guru Meditation|rst:0x|abort') {
                    Write-Host $line
                }
            }
            catch [System.TimeoutException] {
                continue
            }
            catch {
                Write-Host ("порт пропал ({0}); открываю снова" -f $_.Exception.Message)
                try { $serial.Close() } catch { }
                Start-Sleep -Milliseconds 300
                try { $serial = Open-Port $Name } catch { Start-Sleep -Milliseconds 300 }
            }
        }
    }
    finally {
        if ($serial) { try { $serial.Close() } catch { } }
        $writer.Close()
    }

    return $lines
}

$exitCode = 0
$verdicts = @()

try {
    Enable-StressFlag

    # Сборка переиспользовала прежнюю конфигурацию и шила тот же образ: esp-idf писал
    # «No changed sectors found», стресс-программа в образ не попадала. Удаление
    # sdkconfig.json в каталоге сборки заставляет CMake перечитать конфигурацию.
     = Join-Path  'config/sdkconfig.json'
    if (Test-Path ) {
        Remove-Item  -Force
    }

    Invoke-Idf -What 'сборка со стрессом' -IdfArgs @('build')
    Invoke-Idf -What 'прошивка со стрессом' -IdfArgs @('-p', $Port, 'flash')

    $lines = Read-StressLog -Name $Port -ForSeconds $Seconds -Path $logPath

    $verdicts = @($lines | Where-Object { $_ -match 'stress: verdict .*\b(ok|FAIL)\s*$' })
    $finals   = @($verdicts | Where-Object { $_ -match 'stress: verdict final ' })
    $failed   = @($verdicts | Where-Object { $_ -match '\bFAIL\s*$' })

    $header = @(
        "# стресс на приборе, порт $Port, $Seconds с, $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')",
        "# полный журнал: $logPath",
        "# приговоров: $($verdicts.Count), полных: $($finals.Count), провалов: $($failed.Count)"
    )

    if ($verdicts.Count -eq 0) {
        $header += '# приговора нет: прибор не дошёл до конца прохода или порт молчал'
        $header | Set-Content -Path $verdictPath -Encoding UTF8
        Write-Host 'приговора нет — прогон не засчитан' -ForegroundColor Red
        $exitCode = 1
    }
    else {
        $header + $verdicts | Set-Content -Path $verdictPath -Encoding UTF8
        Write-Host ("приговоров {0}, полных {1}, провалов {2}" -f `
                    $verdicts.Count, $finals.Count, $failed.Count)

        if ($failed.Count -gt 0) {
            Write-Host 'есть приговор FAIL — прогон не пройден' -ForegroundColor Red
            $exitCode = 1
        }
        elseif ($finals.Count -eq 0) {
            Write-Host 'полного приговора нет: -Seconds короче одного прохода' -ForegroundColor Yellow
        }
    }

    Write-Host ("приговоры: {0}" -f $verdictPath)
    Write-Host ("журнал:    {0}" -f $logPath)
}
catch {
    Write-Host ("ошибка: {0}" -f $_.Exception.Message) -ForegroundColor Red
    $exitCode = 2
}
finally {
    if ($KeepBuild) {
        Write-Host 'служебная сборка и флаг оставлены (-KeepBuild)'
    }
    else {
        [IO.File]::WriteAllText($Sdk, $sdkBefore)

        try {
            Invoke-Idf -What 'обычная сборка' -IdfArgs @('build')
            Invoke-Idf -What 'прошивка обычной сборки' -IdfArgs @('-p', $Port, 'flash')
            Write-Host 'обычная сборка возвращена на прибор'
        }
        catch {
            Write-Host ("не удалось вернуть обычную сборку: {0}" -f $_.Exception.Message) -ForegroundColor Red
            if ($exitCode -eq 0) { $exitCode = 2 }
        }
    }
}

exit $exitCode
