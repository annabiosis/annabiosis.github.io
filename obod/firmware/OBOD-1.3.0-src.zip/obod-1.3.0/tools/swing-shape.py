"""Фигура SWING: что рисует прошивка против кадров владельца.

Линейка внизу не двигается никогда, марки сверху опаздывают; ближе шести пикселей они не
стоят, потому что запоздавшая толкает следующую. Здесь повторена целочисленная арифметика
прошивки и сверена с его шестью кадрами точка в точку.
"""
import io
import re
import sys

sys.stdout.reconfigure(encoding="utf-8")

SRC = io.open("components/synth_ui/src/synth_ui_preview.c", encoding="utf-8").read()
HDR = io.open("components/synth_ui/src/synth_ui_preview.h", encoding="utf-8").read()

problems = []

# его шесть кадров, d = 0, 2, 4, 6, 8, 10
HIS = [
    "0000000000000000000000601806018066018060180660180601806601806018066018060180660180601806601806018066018060180660180601806601806018066018060180660180601806601806018066018060180660180601806601806018066018060180660180601806000000000000000000000000000000000000000000003fffffffffc7fffffffffe60180601806601806018066018060180660180601806601806018066018060180660000600006600006000066000060000660000600006600000000066000000000660000000006600000000067fffffffffe3fffffffffc0000000000000000000000",
    "0000000000000000000000600606006066006060060660060600606600606006066006060060660060600606600606006066006060060660060600606600606006066006060060660060600606600606006066006060060660060600606600606006066006060060660060600606000000000000000000000000000000000000000000003fffffffffc7fffffffffe60180601806601806018066018060180660180601806601806018066018060180660000600006600006000066000060000660000600006600000000066000000000660000000006600000000067fffffffffe3fffffffffc0000000000000000000000",
    "0000000000000000000000600186001866001860018660018600186600186001866001860018660018600186600186001866001860018660018600186600186001866001860018660018600186600186001866001860018660018600186600186001866001860018660018600186000000000000000000000000000000000000000000003fffffffffc7fffffffffe60180601806601806018066018060180660180601806601806018066018060180660000600006600006000066000060000660000600006600000000066000000000660000000006600000000067fffffffffe3fffffffffc0000000000000000000000",
    "0000000000000000000000600061800616000618006160006180061600061800616000618006160006180061600061800616000618006160006180061600061800616000618006160006180061600061800616000618006160006180061600061800616000618006160006180061000000000000000000000000000000000000000000003fffffffffc7fffffffffe60180601806601806018066018060180660180601806601806018066018060180660000600006600006000066000060000660000600006600000000066000000000660000000006600000000067fffffffffe3fffffffffc0000000000000000000000",
    "0000000000000000000000600018600186000186001860001860018600018600186000186001860001860018600018600186000186001860001860018600018600186000186001860001860018600018600186000186001860001860018600018600186000186001860001860018000000000000000000000000000000000000000000003fffffffffc7fffffffffe60180601806601806018066018060180660180601806601806018066018060180660000600006600006000066000060000660000600006600000000066000000000660000000006600000000067fffffffffe3fffffffffc0000000000000000000000",
    "0000000000000000000000600006180066000061800660000618006600006180066000061800660000618006600006180066000061800660000618006600006180066000061800660000618006600006180066000061800660000618006600006180066000061800660000618006000000000000000000000000000000000000000000003fffffffffc7fffffffffe60180601806601806018066018060180660180601806601806018066018060180660000600006600006000066000060000660000600006600000000066000000000660000000006600000000067fffffffffe3fffffffffc0000000000000000000000",
]

FIELD = 44


def const(name):
    m = re.search(r"#define\s+%s\s+(-?\d+)" % name, SRC)
    if not m:
        problems.append("нет константы %s" % name)
        return 0
    return int(m.group(1))


STEP = const("PV_SW_STEP")
GAP = const("PV_SW_GAP")
DELAY = const("PV_SW_DELAY")
MARK_W = const("PV_SW_MARK_W")
MARK_TOP = const("PV_SW_MARK_TOP")
MARK_BOT = const("PV_SW_MARK_BOT")
BOX_X0 = const("PV_SW_BOX_X0")
BOX_X1 = const("PV_SW_BOX_X1")
BOX_Y0 = const("PV_SW_BOX_Y0")
BOX_Y1 = const("PV_SW_BOX_Y1")
PEN = const("PV_SW_PEN")
SRC_FIELD = const("PV_SW_FIELD")

if (STEP, GAP, DELAY, MARK_W, MARK_TOP, MARK_BOT) != (10, 6, 10, 2, 2, 19):
    problems.append("константы марок не те: STEP=%d GAP=%d DELAY=%d W=%d TOP=%d BOT=%d"
                    % (STEP, GAP, DELAY, MARK_W, MARK_TOP, MARK_BOT))
if (BOX_X0, BOX_X1, BOX_Y0, BOX_Y1, PEN) != (1, 42, 24, 41, 2):
    problems.append("коробка не та: x %d..%d, y %d..%d, перо %d"
                    % (BOX_X0, BOX_X1, BOX_Y0, BOX_Y1, PEN))
if SRC_FIELD != FIELD:
    problems.append("поле %d, а фигура размечена на %d" % (SRC_FIELD, FIELD))


def delay(q):
    """Та же арифметика, что в pv_swing: целые пиксели 0..10 по всему ходу."""
    return (q * DELAY + 25) // 50


def marks(q):
    out = []
    prev = -100
    for j in range(5):
        x = STEP * j + (delay(q) if j % 2 else 0)
        if x < prev + GAP:
            x = prev + GAP
        prev = x
        out.append(x)
    return out


def frame(q):
    g = [[0] * FIELD for _ in range(FIELD)]
    for y in range(BOX_Y0, BOX_Y1 + 1):
        for x in range(BOX_X0, BOX_X1 + 1):
            edge_x = x < BOX_X0 + PEN or x > BOX_X1 - PEN
            edge_y = y < BOX_Y0 + PEN or y > BOX_Y1 - PEN
            if not (edge_x or edge_y):
                continue
            if x in (BOX_X0, BOX_X1) and y in (BOX_Y0, BOX_Y1):
                continue
            g[y][x] = 1
    for tick_x, tick_bot in ((11, 31), (21, 35), (31, 31)):
        for y in range(BOX_Y0 + PEN, tick_bot + 1):
            for i in range(MARK_W):
                g[y][tick_x + i] = 1
    for x0 in marks(q):
        for y in range(MARK_TOP, MARK_BOT + 1):
            for i in range(MARK_W):
                x = x0 + 1 + i
                if 0 <= x < FIELD:
                    g[y][x] = 1
    return g


def unpack(hexstr):
    bits = "".join(format(b, "08b") for b in bytes.fromhex(hexstr))
    return [[1 if bits[y * FIELD + x] == "1" else 0 for x in range(FIELD)]
            for y in range(FIELD)]


# 1. Его шесть кадров: d = 0, 2, 4, 6, 8, 10 — точка в точку.
for n, d in enumerate((0, 2, 4, 6, 8, 10)):
    q = next(q for q in range(0, 51) if delay(q) == d)
    mine = frame(q)
    his = unpack(HIS[n])
    diff = [(x, y) for y in range(FIELD) for x in range(FIELD) if mine[y][x] != his[y][x]]
    if diff:
        problems.append("d = %d: расходится с его кадром в %d точках, например %s"
                        % (d, len(diff), diff[:6]))

# 2. Одиннадцать положений, по одному пикселю, и линейка не двигается ни в одном.
ladder = []
for q in range(0, 51):
    d = delay(q)
    if not ladder or ladder[-1] != d:
        ladder.append(d)
if ladder != list(range(0, DELAY + 1)):
    problems.append("опаздывание идёт %s, а должно 0..10 по одному" % ladder)

ruler = None
for q in range(0, 51):
    g = frame(q)
    box = [[g[y][x] for x in range(FIELD)] if y >= BOX_Y0 else None for y in range(FIELD)]
    part = [row for row in box if row is not None]
    if ruler is None:
        ruler = part
    elif part != ruler:
        problems.append("q=%d: линейка сдвинулась или изменилась" % q)

# 3. Марки только едут вправо, ближе шести пикселей не стоят, и хотя бы одна уходит за край.
prev = None
for q in range(0, 51):
    m = marks(q)
    if prev is not None and any(a < b for a, b in zip(m, prev)):
        problems.append("q=%d: марка поехала назад (%s против %s)" % (q, m, prev))
    for a, b in zip(m, m[1:]):
        if b - a < GAP:
            problems.append("q=%d: марки ближе %d px (%s)" % (q, GAP, m))
    prev = m
if marks(50)[-1] + 1 < FIELD:
    problems.append("на всём ходу последняя марка не уходит за поле: %s" % marks(50))

# 4. Не выходит за поле 44 x 44.
for q in range(0, 51):
    g = frame(q)
    if len(g) != FIELD or any(len(r) != FIELD for r in g):
        problems.append("q=%d: кадр не 44 x 44" % q)

# --- куда поставлена ---------------------------------------------------------
if "PREVIEW_SWING" not in HDR:
    problems.append("нет вида PREVIEW_SWING в заголовке")

sw = SRC[SRC.index("static synth_preview_kind_t pv_values"):]
sw = sw[:sw.index("\n}\n")]
LABELS, pending = {}, []
for mm in re.finditer(r"case (SYNTH_PARAM_\w+):|return (PREVIEW_\w+);", sw):
    if mm.group(1):
        pending.append(mm.group(1))
    else:
        for label in pending:
            LABELS.setdefault(label, mm.group(2))
        pending = []

for param, kind in {
    "SYNTH_PARAM_PERC_SWING": "PREVIEW_SWING",
    "SYNTH_PARAM_PERC_GROOVE": "PREVIEW_GROOVE",
    "SYNTH_PARAM_PERC_SPEED": "PREVIEW_NONE",
}.items():
    # отсутствие case значит ветку default, а она отдаёт пустую фигуру
    if LABELS.get(param, "PREVIEW_NONE") != kind:
        problems.append("%s отдаёт %s, а должен %s" % (param, LABELS.get(param, "PREVIEW_NONE"), kind))

if not re.search(r"case PREVIEW_SWING:\s*pv_swing\(", SRC):
    problems.append("нет вызова pv_swing в переключателе")

ox = SRC[SRC.index("static int pv_ox_for"):SRC.index("static int pv_oy_for")]
if "case PREVIEW_SWING:" not in ox:
    problems.append("PREVIEW_SWING не в списке нулевого сдвига")

if problems:
    print("FAIL: фигура SWING")
    for p in problems:
        print("  -", p)
    sys.exit(1)

print("OK: SWING — пять марок 2 px в строках 2..19, линейка 1..42 x 24..41 с тремя "
      "насечками не двигается; опаздывание 0..10 px по 1 px, одиннадцать положений, "
      "шесть кадров владельца совпадают точка в точку; стоит на SWING страницы PERC SEQ")
