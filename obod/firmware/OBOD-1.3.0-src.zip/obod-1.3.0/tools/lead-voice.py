"""MONO И POLY НА СТРАНИЦЕ LEAD.

Владелец попросил ручку, у которой два состояния и одно имя для каждого — и проверка держит
то, что эти два состояния ОБЕЩАЮТ, потому что обещание здесь звуковое, а ошибка тихая: ручка
переключается, надпись меняется, а лид продолжает играть как раньше.

  * Параметр — последний в патче, два положения, заводское POLY. Патч, записанный до ручки,
    читает 0 % и приходит в MONO: это звук, с которым он был сделан.
  * POLY — четыре группы: шаг, пришедший пока звучит хвост предыдущего, берёт следующую, а
    пятый забирает самую старую ноту линии.
  * MONO — одна группа, та же самая: каждая нота перезапускает её, релиз обрезается следующей
    нотой, и глиссандо идёт от ноты этой же группы, потому что другой у линии нет.
  * Клавиши в MONO звучат последним пальцем: аллокатор отдаёт ту же группу, а не свободную.
  * Переключение в MONO закрывает лишние группы сразу, с note-off: лид, у которого звучат
    четыре ноты, не монофонический, и ждать, пока доиграют хвосты, значит показывать POLY.
  * Ручка стоит на странице LEAD четвёртой, и сайт перечисляет её на том же месте.

Run: python tools/lead-voice.py
"""
import re
import sys

sys.stdout.reconfigure(encoding="utf-8")

APP = "components/synth_app/src/synth_app.cpp"
HDR = "components/synth_app/include/synth_app.h"
SETTINGS = "components/app_settings/include/app_settings.h"
UI = "components/synth_ui/src/synth_ui.c"
PREVIEW = "components/synth_ui/src/synth_ui_preview.c"
PREVIEWH = "components/synth_ui/src/synth_ui_preview.h"
REF = "web/assets/ref.js"
PAGE = "web/ref-lead.html"
FEATURES = "FEATURES.md"
FEATURES_EN = "FEATURES.en.md"
FAIL = []


def fail(msg):
    FAIL.append(msg)


def ok(msg):
    print("  " + msg)


def read(p):
    return open(p, encoding="utf-8", errors="replace").read()


def body(text, needle):
    """Тело функции от её определения до парной закрывающей скобки."""
    m = re.search(re.escape(needle) + r"\s*\n\{", text)
    if not m:
        raise SystemExit("не найдено определение: " + needle)
    i = m.end() - 1
    depth = 0
    for j in range(i, len(text)):
        if text[j] == "{":
            depth += 1
        elif text[j] == "}":
            depth -= 1
            if depth == 0:
                return text[i:j + 1]
    raise SystemExit("не закрыто тело: " + needle)


def brace_block(text, needle):
    """Блок после `needle` до парной закрывающей скобки — для тел внутри тела."""
    i = text.index(needle)
    depth = 0
    for j in range(i + len(needle), len(text)):
        if text[j] == "{":
            depth += 1
        elif text[j] == "}":
            depth -= 1
            if depth == 0:
                return text[i:j + 1]
    raise SystemExit("не закрыт блок: " + needle)


app = read(APP)
hdr = read(HDR)
settings = read(SETTINGS)
ui = read(UI)
preview = read(PREVIEW)
previewh = read(PREVIEWH)
ref = read(REF)
page = read(PAGE)
features = read(FEATURES)
features_en = read(FEATURES_EN)

# ---------------------------------------------------------------- 1. параметр
print("1. параметр в конце патча")
if "SYNTH_PARAM_LEAD_VOICE," not in hdr:
    fail("нет SYNTH_PARAM_LEAD_VOICE")
enum = hdr[hdr.index("SYNTH_PARAM_LEAD_FENV_SHAPE"):hdr.index("SYNTH_PARAM_SET_SCREEN")]
order = re.findall(r"^\s*(SYNTH_PARAM_[A-Z0-9_]+),", enum, re.M)
if order[-1] != "SYNTH_PARAM_LEAD_VOICE":
    fail("параметр не последний в патче: последний " + (order[-1] if order else "нет"))
if 'COUNT == 107' not in app:
    fail("патч не на 107 параметров")
if "APP_SETTINGS_PATCH_MAX 107" not in settings or "APP_PRESET_PARAM_MAX 107" not in settings:
    fail("хранилище и рекорд пресета не на 107")
if not re.search(r"#define\s+LEAD_VOICE_DEFAULT\s+1\.0f", app):
    fail("заводское не POLY")
if "case SYNTH_PARAM_LEAD_VOICE:\n        /* Two, one detent each: MONO at 0, POLY at 100. */\n        return 2;" not in app:
    fail("у параметра не два положения")
if '"POLY" : "MONO"' not in app:
    fail("надпись не POLY/MONO")
else:
    ok("последний в патче, 107, два положения, заводское POLY, надпись словом")

# ---------------------------------------------------------------- 2. применитель
print("2. переключение")
if "case SYNTH_PARAM_LEAD_VOICE:      apply_lead_voice(v);      break;" not in app:
    fail("параметр не приходит в apply_lead_voice")
vote = body(app, "static void apply_lead_voice(float v01)")
if "s_lead_poly = poly;" not in vote:
    fail("применитель не пишет режим")
for want in ("LEAD_GEN_GROUP + 1", "lead_group_off(g);", "LEAD_NOTE_FREE"):
    if want not in vote:
        fail("в MONO не закрываются лишние группы: нет " + want)
if "if (!poly)" not in vote:
    fail("лишние группы не закрываются только при переходе в MONO")
else:
    ok("флаг режима, лишние группы закрываются через note-off")

# ---------------------------------------------------------------- 3. генератор
print("3. линия генератора")
non = body(app, "static void lead_note_on(float hz, float velocity, uint32_t gate_blocks)")
if "if (!s_lead_poly) {" not in non:
    fail("линия не спрашивает режим")
mono = brace_block(non, "if (!s_lead_poly)")
if "group = LEAD_GEN_GROUP;" not in mono:
    fail("в MONO линия берёт не свою группу")
if "oldest_gen" in mono:
    fail("в MONO линия всё ещё ищет свободную группу")
if "if (s_lead_poly) {" not in non:
    fail("глиссандо не различает режимы")
glide = brace_block(non, "if (s_lead_poly)")
if "s_gen_last_hz" not in glide:
    fail("в POLY глиссандо не от предыдущей ноты линии")
else:
    ok("MONO — одна группа без поиска, POLY — свободная или самая старая")

# ---------------------------------------------------------------- 4. клавиши
print("4. клавиши")
alloc = body(app, "static int lead_group_alloc(int note)")
if "if (!s_lead_poly) {\n        return LEAD_GEN_GROUP;\n    }" not in alloc:
    fail("в MONO клавиши не сводятся к одной группе")
if "oldest" not in alloc:
    fail("в POLY пропала кража самой старой ноты")
else:
    ok("в MONO последний палец, в POLY свободная или самая старая")

# ---------------------------------------------------------------- 5. страница
print("5. страница LEAD и сайт")
i = ui.index("KNOBS_LEAD[] = {") + len("KNOBS_LEAD[] = {")
knobs = ui[i:ui.index("};", i)]
names = re.findall(r'\{\s*"([^"]+)"\s*,\s*SYNTH_PARAM_([A-Z0-9_]+)\s*\}', knobs)
if names != [("GATE", "SEQ_GATE"), ("PORTA", "LEAD_PORTA"), ("OSC", "LEAD_WAVE"),
             ("VOICE", "LEAD_VOICE")]:
    fail("порядок секторов не GATE, PORTA, OSC, VOICE: %r" % (names,))
if "PREVIEW_LEAD_VOICE" not in previewh or "static void pv_lead_voice" not in preview:
    fail("у ручки нет фигуры")
else:
    ok("четвёртый сектор VOICE, фигура есть")

if "['VOICE'," not in ref:
    fail("сайт не знает VOICE")
else:
    # Сектор VOICE стоит после OSC и перед концом списка страницы: первой строкой после
    # вложенного списка форм волны. Порядок на экране — GATE, PORTA, OSC, VOICE.
    head = ref.index("['GATE',")
    tail = ref.index("['VOICE',", head)
    if ref.index("['OSC',", head) > tail or ref.index("['PORTA',", head) > tail:
        fail("VOICE стоит в списке сайта не последним")
if "VOICE — это два инструмента в одном" not in page:
    fail("страница лида не объясняет VOICE")
else:
    ok("сайт называет VOICE и объясняет оба режима")

# ---------------------------------------------------------------- 6. доки
print("6. FEATURES")
if "**MONO и POLY на странице LEAD" not in features:
    fail("FEATURES.md не называет MONO и POLY")
if "**MONO and POLY on the LEAD page" not in features_en:
    fail("FEATURES.en.md не называет MONO и POLY")
else:
    ok("оба FEATURES называют ручку и что она делает")

print("")
if FAIL:
    print("НЕ ПРОШЛО, %d:" % len(FAIL))
    for f in FAIL:
        print("  - " + f)
    sys.exit(1)

print("OK: MONO и POLY — параметр в конце патча, одна группа против четырёх, "
      "клавиши последним пальцем, сектор VOICE на странице LEAD")
