/*
 * Проверка справочника документации против прошивки.
 *
 * Источник данных переехал с промо-страницы на набор страниц документации:
 *
 *   web/assets/ref.js       таблица REF — категория → экран → параметр
 *   web/assets/pages.js     список страниц руководства
 *   web/*.html              тексты страниц: ими проверяются числа, которые страницы
 *                           называют сами
 *
 * Проверяется то же, что и раньше, когда справочник жил на одной промо-странице: порядок и состав
 * экранов, имена ручек, число позиций у списочных параметров, наличие описания у каждого
 * параметра и у каждой позиции, цвета семейств и совпадение текста схемы с .mmd.
 * Кругов на страницах нет, и их проверки здесь нет: они лежат отдельным файлом
 * tools/promo-rings.js.
 *
 * Эталоны выписаны из прошивки: экраны и ручки — из таблиц KNOBS_* в
 * components/synth_ui/src/synth_ui.c, число позиций — из synth_app_param_steps() в
 * components/synth_app/src/synth_app.cpp, цвета — из GROUP_COLOR.
 *
 * Запуск: node tools/promo-check.js
 */
const fs = require('fs');
const path = require('path');
const vm = require('vm');

/* Соответствие «номер страницы прошивки → метка экрана»: считается по прошивке и по таблице
 * REF, и его же берут снимки экранов. Второй выписки в проекте нет. */
const screenMap = require('./lib/screens.js');

const root = path.join(__dirname, '..');
const web = path.join(root, 'web');

const refSource = fs.readFileSync(path.join(web, 'assets', 'ref.js'), 'utf8');

/*
 * Страницы собирают разметку из таблицы REF. Чтобы добраться до таблицы, скрипт
 * исполняется на пустом DOM: ему нужны только getElementById и createElement.
 *
 * Файл намеренно не в строгом режиме: объявление var внутри eval иначе не вышло бы
 * наружу, и REF было бы не прочитать.
 */
function stub() {
  return {
    className: '', style: {}, dataset: {}, children: [],
    innerHTML: '', textContent: '',
    appendChild(child) { this.children.push(child); return child; },
    setAttribute() {},
    querySelector() { return null; },
  };
}

const nodes = {};
global.document = {
  getElementById(id) { return nodes[id] || (nodes[id] = stub()); },
  createElement() { return stub(); },
  querySelectorAll() { return []; },
};
global.window = { addEventListener() {}, removeEventListener() {} };

/* Таблица данных плюс функции её отрисовки: заодно проверяется синтаксис файла. */
eval(refSource);

/*
 * Оболочка страниц — не данные, но её синтаксис проверяется так же, как раньше
 * проверялся синтаксис встроенных скриптов промо-страницы. Исполнять её нечем: ей нужен
 * настоящий DOM, поэтому она только разбирается.
 */
for (const name of ['pages.js', 'docs.js']) {
  const file = path.join(web, 'assets', name);
  new vm.Script(fs.readFileSync(file, 'utf8'), { filename: file });
}

/* Все страницы набором: в них ищутся числа, которые страницы называют сами. */
const site = fs.readdirSync(web)
  .filter((name) => name.endsWith('.html'))
  .map((name) => fs.readFileSync(path.join(web, name), 'utf8'))
  .join('\n');

/* Двадцать две страницы в порядке карусели: имя экрана и его ручки. */
const EXPECT = [
  ['DRONE',        ['H.OSC', 'M.OSC', 'L.OSC', 'WIDTH', 'FOLLOW']],
  ['DRONE FLTR',   ['RES', 'CUTOFF', 'RATE', 'DEPTH', 'K.TRCK', 'MODE']],
  ['LFO 1',        ['DEST', 'DEPTH', 'DEPTH2', 'DEST2', 'SHAPE', 'SPEED']],
  ['LFO 2',        ['DEST', 'DEPTH', 'DEPTH2', 'DEST2', 'SHAPE', 'SPEED']],
  ['LEAD',         ['GATE', 'PORTA', 'OSC', 'VOICE']],
  ['LEAD TONE',    ['CUTOFF', 'RES', 'ENV', 'SHAPE', 'K.TRCK', 'MODE']],
  ['LEAD ENV',     ['ATTACK', 'DECAY', 'SUSTAIN', 'RELEASE']],
  ['SCALE',        ['SCALE', 'NOTE', 'OCT', 'DENSITY', 'OCTAVE']],
  ['LEAD EUCLID',  ['STEPS', 'PULSES', 'ROTATE', 'ACCENT', 'SCATTER', 'RESET']],
  ['LEAD ARP',     ['DIR', 'SPEED', 'LEN', 'RANGE', 'ACCENT']],
  ['PERC',         ['KIT', 'TONE', 'DECAY', 'PUNCH', 'TIMBRE', 'TUNE']],
  ['PERC SEQ',     ['GROOVE', 'VAR', 'FILL', 'SWING', 'SPEED', 'ACCENT']],
  ['PERC MIX',     ['KICK', 'SNARE', 'HAT', 'TOM']],
  ['BASS',         ['KIT', 'OCT', 'TONE', 'DECAY', 'SNAP', 'DRIVE']],
  ['RHYTHM',       ['PAT', 'VAR', 'LEN', 'GATE', 'SLIDE', 'ACCENT']],
  ['FX',           ['TYPE', 'MIX', 'A', 'B', 'C', 'VERB']],
  ['DELAY',        ['MIX', 'FDBK', 'TIME', 'MODE', 'DAMP', 'VERB']],
  ['REVERB',       ['ALGO', 'MIX', 'SIZE', 'DAMP']],
  ['MASTER',       ['VOL', 'COMP', 'DUCK', 'SRC', 'REL', 'SIDE']],
  ['LEVELS',       ['LEAD', 'PERC', 'BASS', 'LOW', 'MID', 'HIGH']],
  ['REV SENDS',    ['LEAD', 'PERC', 'BASS', 'LOW', 'MID', 'HIGH']],
  ['FX SENDS',     ['LEAD', 'PERC', 'BASS', 'LOW', 'MID', 'HIGH']],
  ['DEL SENDS',    ['LEAD', 'PERC', 'BASS', 'LOW', 'MID', 'HIGH']],
  ['PRESET',       []],
  ['SETUP',        ['SLIDE', 'RND DEL', 'WEAK VEL', 'MIC', 'MIDI IN',
                    'SCREEN', 'RING', 'RING FX', 'MORPH', 'PATCH']],
];

/*
 * Списочные параметры, позиции которых расписаны, и их число по прошивке.
 *
 * Ручки SCALE, NOTE и OCT сюда не входят осознанно: это ноты, октавы и лады, каждая
 * позиция у них — название ноты, номер октавы или название лада, а не решение инструмента.
 * Прошивка объявляет их списками,
 * страница описывает только сами ручки.
 *
 * RESET остался ОДНОЙ ручкой — на LEAD EUCLID. Ключ PERC SEQ/RESET ушёл вместе с эвклидовой
 * сеткой перкуссии: у ударных теперь партия (GROOVE), а не фигура, и жест «встать на первый
 * шаг» там нечего двигать. Параметр SYNTH_PARAM_PERC_RESET в прошивке остался — номер
 * параметра адресует пресеты, — но ручки у него больше нет, и странице его называть нечего.
 *
 * PERC/QUANT тоже ушёл: высота удара больше не притягивается к ладу ручкой, потому что
 * высота теперь у кита, а PERC QUANT остался мёртвым слотом по той же причине.
 *
 * DRONE/H.OSC, DRONE/M.OSC и DRONE/L.OSC — три ключа вместо одного DRONE/WAVE: ручка WAVE
 * стала тремя ручками, по одной на регистр, и у каждой тот же шестипозиционный список, что
 * был у неё одной. DRONE/FOLLOW — режим следования за лидом, теперь ТРИ позиции: STAY убран,
 * и его место занял SCALE, который и так был заводским. DRONE/K.TRCK и LEAD/K.TRCK — новая
 * пара: непрерывные проценты без списка позиций, поэтому в LISTS их нет, но ручками они
 * стали, и обе страницы выросли на одну.
 *
 * PERC SEQ/ACCENT наоборот здесь: он был непрерывной ручкой силы акцента, а стал
 * списком рисунков из восьми позиций, и каждая позиция — решение о ритме, которое
 * стоит назвать на странице. Число ручек и параметров от этого не изменилось.
 *
 * LEAD EUCLID/ACCENT — теперь СВОЙ параметр, а не второй экран перкуссионного: рисунок
 * акцента у каждой части один и тот же по устройству (восемь фигур, WEAK VEL для слабых
 * долей), но выбор у них независимый, и оба экрана обязаны это сказать. Списки у обоих
 * ключей одинаковой длины, потому что список фигур общий, — но позиции за ним стоят разные.
 */
const LISTS = {
  'DRONE/H.OSC': 6,
  'DRONE/M.OSC': 6,
  'DRONE/L.OSC': 6,
  'DRONE/FOLLOW': 3,
  'LFO/DEST': 20,
    'LFO/DEST2': 20,
  'LFO/SHAPE': 8,
  'LFO/TRIG': 5,
  'LEAD/OSC': 6,
  'LEAD ARP/DIR': 8,
  'LEAD ARP/SPEED': 13,
  'LEAD ARP/RANGE': 6,
  'LEAD EUCLID/ACCENT': 8,
  'LEAD ARP/ACCENT': 8,
  /* Бас: тридцать заготовок, тридцать рисунков, шесть характеров такта и та же фигура
   * акцента, что у остальных трёх частей. */
  'BASS/KIT': 30,
  'RHYTHM/PAT': 30,
  'RHYTHM/VAR': 6,
  'RHYTHM/ACCENT': 8,
  'PERC/KIT': 28,
  'PERC SEQ/GROOVE': 32,
  'PERC SEQ/ACCENT': 8,
  'PERC SEQ/SPEED': 7,
  'DELAY/SYNC': 12,
  'DELAY/MODE': 6,
  'REVERB/ALGO': 4,
  'SETUP/RING FX': 4,
  'LEAD EUCLID/RESET': 6,
  'SETUP/PATCH': 3,
  'SETUP/SLIDE': 5,
  'SETUP/RND DEL': 2,
  'SETUP/MIDI IN': 2,
  'SETUP/MORPH': 11,
};

/*
 * Списочные параметры, у которых позиция — не решение инструмента, а число, и их число
 * позиций по прошивке.
 *
 * WEAK VEL — первый такой: synth_app_param_steps() объявляет у неё 128 позиций, потому что
 * это велосити движка, целые 0..127, и каждое число — своя сила удара. Перечислять их на
 * странице значило бы выписать 128 строк, из которых читателю нужны три: 127, 80 и 0.
 * Поэтому требование к странице другое, и оно проверяется ниже: не список позиций, а
 * названная шкала — оба края и заводское значение. Ключ обязан быть либо в LISTS, либо
 * здесь, и ни в обоих сразу: иначе «позиций нет» означало бы «прошивка списка не знает»,
 * то есть опечатку в имени ручки, а не осознанное исключение.
 */
const PLAIN_LISTS = {
  'SETUP/WEAK VEL': 128,
};

/* Девять цветов семейств — ступени GROUP_COLOR: кайма и яркий тон модуляции. */
const COLORS = ['#1976D2', '#B6D400', '#AB47BC', '#00796B', '#2E7D32', '#D97700',
                '#E91E63', '#5D4037', '#37474F', '#546E7A'];

const problems = [];

function check(ok, message) {
  if (!ok) { problems.push(message); }
}

/* --- таблица --- */

check(REF.length === 9, 'семейств ' + REF.length + ', ожидается 9');

const screens = [];
REF.forEach(function (cat) {
  check(COLORS.indexOf(cat.c) >= 0, 'чужой цвет семейства: ' + cat.c + ' у ' + cat.n);
  cat.s.forEach(function (scr) { screens.push(scr); });
});

check(screens.length === EXPECT.length,
      'экранов ' + screens.length + ', ожидается ' + EXPECT.length);

EXPECT.forEach(function (want, i) {
  const got = screens[i];
  if (!got) { return; }

  check(got.n === want[0],
        'экран ' + (i + 1) + ': ' + got.n + ', ожидается ' + want[0]);

  const names = got.p.map(function (p) { return p[0]; });
  check(names.join(' · ') === want[1].join(' · '),
        got.n + ': ручки ' + (names.join(' · ') || 'нет') +
        ', ожидается ' + (want[1].join(' · ') || 'нет'));

  if (got.p.length === 0) {
    check(!!got.d, got.n + ': у экрана без ручек нет описания');
  }

  got.p.forEach(function (p) {
    const where = got.n + '/' + p[0];
    const list = LISTS[where];
    const plain = PLAIN_LISTS[where];

    check(typeof p[1] === 'string' && p[1].trim().length > 4,
          where + ': нет описания параметра');

    check(!(typeof list === 'number' && typeof plain === 'number'),
          where + ': объявлен и списком позиций, и числовым списком');

    if (p[2]) {
      check(typeof list === 'number', where + ': позиции описаны, но прошивка списка не знает');
      if (typeof list === 'number') {
        check(p[2].length === list,
              where + ': позиций ' + p[2].length + ', ожидается ' + list);
      }
      check(typeof plain !== 'number', where + ': числовой список, а позиции расписаны');
      p[2].forEach(function (q) {
        check(typeof q[1] === 'string' && q[1].trim().length > 2,
              where + '/' + q[0] + ': нет описания позиции');
      });
    } else {
      check(typeof list !== 'number',
            where + ': прошивка объявляет список, а позиций на странице нет');
    }
  });
});

const knobs = screens.reduce(function (n, s) { return n + s.p.length; }, 0);
check(knobs === 137, 'ручек ' + knobs + ', ожидается 136');

/*
 * Порядок страниц прибора — против самой прошивки, а не против выписки.
 *
 * EXPECT выше выписан из прошивки руками и до сих пор ни с чем не сверялся: сверялась только
 * таблица REF, то есть выписка с выпиской. Теперь порядок и имена страниц читает
 * tools/lib/screens.js прямо из перечисления page_id_t и таблицы PAGES[] в
 * components/synth_ui/src/synth_ui.c, и эта же связка называет файлы снимков экранов. Так
 * страница, переставленная в прошивке или переименованная, роняет проверку здесь, а не
 * подписывает чужой картинкой страницу в документации.
 */
const firmware = screenMap.mapping(root);
firmware.problems.forEach(function (p) { check(false, 'страницы прибора: ' + p); });
check(firmware.pages.join(' · ') === EXPECT.map(function (e) { return e[0]; }).join(' · '),
      'порядок и имена страниц прибора не совпадают с выпиской: ' + firmware.pages.join(' · '));

/*
 * Ни один параметр больше не показан дважды: 100 ручек — это 100 разных значений. Было 103,
 * пока у MASTER стояли DRIVE и ALGO, а у SYSTEM — DRIVE; перегруз ушёл из прибора целиком. Пять
 * уровней живут только на LEVELS, ENV удара — только на PERC, а ENV, LEVEL и уровни
 * дрона со своих страниц убраны. Поэтому на LEVELS у каждой ручки сказано, что она
 * единственная, а не «та же, что на странице части».
 *
 * Часть ручек ведёт настройки, а не параметры патча. MIDI IN и MORPH — последние две на
 * странице OPTIONS, и в пресет они не входят: MORPH — время перехода голоса между формами
 * волны, оно живёт в app_settings (APP_SET_WAVE_MORPH) и не двигается случайным звуком, а
 * её список объявлен в synth_app.cpp рядом с движковым setWaveSmooth(). Два параметра патча
 * ручки не имеют вовсе: темп секвенсора (живёт на экране транспорта) и резонанс перкуссии.
 * Числа сверены скриптом по перечислению SYNTH_PARAM_* и таблицам KNOBS_*.
 */
const levels = screens.filter(function (s) { return s.n === 'LEVELS'; })[0];
if (levels) {
  levels.p.forEach(function (p) {
    check(p[1].indexOf('только здесь') >= 0,
          'LEVELS/' + p[0] + ': не сказано, что уровень есть только на этой странице');
  });
}

/*
 * ACCENT теперь у каждой части свой, и это надо сказать вслух на обоих экранах: читатель
 * справочника, привыкший к общему рисунку, иначе решит, что ручки связаны по-прежнему.
 */
['PERC SEQ', 'LEAD EUCLID'].forEach(function (name) {
  const scr = screens.filter(function (s) { return s.n === name; })[0];
  if (!scr) { return; }
  const accent = scr.p.filter(function (p) { return p[0] === 'ACCENT'; })[0];
  check(accent && accent[1].indexOf('независимый') >= 0,
        name + '/ACCENT: не сказано, что рисунок независим от второй части');
});

/* --- числовые списки --- */

/*
 * У них проверяется не список позиций, а шкала: оба края, заводское значение и число
 * делений ручки. Ключ ищется на странице, поэтому опечатка в имени экрана или ручки
 * здесь так же видна, как и в LISTS.
 */
Object.keys(PLAIN_LISTS).forEach(function (where) {
  const parts = where.split('/');
  const scr = screens.filter(function (s) { return s.n === parts[0]; })[0];
  const p = scr && scr.p.filter(function (q) { return q[0] === parts[1]; })[0];

  check(!!p, where + ': экрана или ручки с таким ключом на странице нет');
  if (!p) { return; }

  const steps = PLAIN_LISTS[where] - 1;
  check(p[1].indexOf('от 0 до 127') >= 0, where + ': не названы оба края шкалы, 0..127');
  check(p[1].indexOf('заводское 80') >= 0, where + ': не названо заводское значение 80');
  check(p[1].indexOf('разницы нет') >= 0, where + ': не сказано, что 127 — разницы нет');
  check(p[1].indexOf(steps + ' делений') >= 0,
        where + ': не сказано, что делений у ручки ' + steps);
});

/* --- числа, которые страницы называют сами --- */

/*
 * Числа в подвале каждой страницы: ручек и параметров ровно столько, сколько их в
 * прошивке. Раньше здесь стояли выписанные руками 116 и 110 — они отстали от прибора
 * на тридцать параметров, и проверка держала страницы в этом вранье.
 */
const appSource = fs.readFileSync(
  path.join(root, 'components', 'synth_app', 'src', 'synth_app.cpp'), 'utf8');
const patchMatch = /static_assert\(SYNTH_PARAM_PATCH_COUNT == (\d+)/.exec(appSource);
const params = patchMatch ? Number(patchMatch[1]) : -1;

check(site.indexOf(params + ' параметров') >= 0,
      'страницы не называют ' + params + ' параметров');
check(site.indexOf(knobs + ' ручек') >= 0, 'страницы не называют ' + knobs + ' ручек');

/* --- итог --- */

if (problems.length) {
  console.log('НЕ ПРОШЛО, ' + problems.length + ':');
  problems.forEach(function (p) { console.log('  ' + p); });
  process.exit(1);
}

console.log('OK: ' + REF.length + ' семейств, ' + screens.length + ' экранов, ' +
            knobs + ' ручек, ' + Object.keys(LISTS).length +
            ' списочных параметров и ' + Object.keys(PLAIN_LISTS).length +
            ' числовой список совпадают с прошивкой');
