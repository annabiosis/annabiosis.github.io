/*
 * Проверка справочника и страниц сайта против прошивки.
 *
 * Источники:
 *   tools/site/ref.js                 справочник: семья → экран → ручки и описания
 *   components/synth_ui/src/synth_ui.c таблицы KNOBS_* и PAGES[] — что на приборе на самом деле
 *   web/ref-*.html                    собранные страницы: каждая ручка обязана быть на своей
 *
 * Что проверяется:
 *   девять семейств и двадцать пять экранов в том же порядке, что у прибора;
 *   состав и порядок ручек каждого экрана против KNOBS_*;
 *   у каждой ручки есть описание, у каждого списочного значения — объяснение;
 *   число позиций списочных параметров совпадает с synth_app_param_steps();
 *   каждая ручка выведена на странице своей семьи;
 *   метки секторов в дереве и на странице — те же, что у прибора.
 *
 * Запуск: node tools/promo-check.js
 */
'use strict';

const fs = require('fs');
const path = require('path');
const vm = require('vm');

const root = path.join(__dirname, '..');
const refPath = path.join(root, 'tools', 'site', 'ref.js');
const uiPath = path.join(root, 'components', 'synth_ui', 'src', 'synth_ui.c');
const appPath = path.join(root, 'components', 'synth_app', 'src', 'synth_app.cpp');

const problems = [];
const check = (ok, msg) => { if (!ok) { problems.push(msg); } };

/* ── справочник ──────────────────────────────────────────────────────────── */

const refSrc = fs.readFileSync(refPath, 'utf8');
const ctx = { document: { createElement: () => ({ setAttribute() {}, appendChild() {}, style: {} }) } };
vm.createContext(ctx);
vm.runInContext(refSrc.replace(/^var REF/m, 'REF'), ctx);
const REF = ctx.REF;
if (!REF) { throw new Error('в ' + refPath + ' не нашлось таблицы REF'); }

/* ── прошивка ────────────────────────────────────────────────────────────── */

const uiSrc = fs.readFileSync(uiPath, 'utf8');
const appSrc = fs.readFileSync(appPath, 'utf8');

/* KNOBS_*: имя таблицы → подписи секторов по порядку. */
const knobTables = {};
for (const m of uiSrc.matchAll(/static const ui_knob_t (KNOBS_[A-Z0-9_]+)\[\]\s*=\s*\{([\s\S]*?)\n\};/g)) {
  const names = [...m[2].matchAll(/\{\s*"([^"]+)"/g)].map((x) => x[1]);
  knobTables[m[1]] = names;
}

/* PAGES[]: заголовок и таблица ручек, в порядке карусели. */
const pagesBlock = /static const ui_page_t PAGES\[PAGE_COUNT\] = \{([\s\S]*?)\n\};/.exec(uiSrc);
if (!pagesBlock) { throw new Error('в synth_ui.c не найдено PAGES[]'); }
const pages = [...pagesBlock[1].matchAll(/\[\w+\]\s*=\s*\{\s*"([^"]*)",\s*"[^"]*",\s*(KNOBS_[A-Z0-9_]+|NULL)/g)]
  .map((m) => ({ title: m[1], knobs: m[2] === 'NULL' ? [] : (knobTables[m[2]] || []) }));

check(pages.length >= 23, 'страниц с ручками в прошивке ' + pages.length + ', ожидается 23');

/* Описание у каждой ручки и объяснение у каждого списочного значения. */
for (const fam of REF) {
  check(!!fam.s.length, 'семья ' + fam.n + ' без экранов');
  for (const scr of fam.s) {
    check(!!scr.d && scr.d.trim().length > 10, fam.n + '/' + scr.n + ': нет описания экрана');
    for (const [name, text, values] of scr.p) {
      check(typeof text === 'string' && text.trim().length > 4,
            fam.n + '/' + scr.n + '/' + name + ': нет описания ручки');
      if (values) {
        for (const [code, meaning] of values) {
          check(typeof meaning === 'string' && meaning.trim().length > 2,
                fam.n + '/' + scr.n + '/' + name + '/' + code + ': нет объяснения позиции');
        }
      }
    }
  }
}

/* Экраны справочника против страниц прошивки: имя и состав ручек. */
const screens = [];
for (const fam of REF) { for (const scr of fam.s) { screens.push({ fam: fam.n, ...scr }); } }

check(screens.length === 25,
      'экранов в справочнике ' + screens.length + ', страниц в прошивке 25');

const order = ['Дрон', 'Модуляция', 'Лид', 'Генераторы', 'Перкуссия', 'Бас', 'Эффекты', 'Микшер', 'Пресеты и настройки'];
check(REF.length === 9, 'семейств ' + REF.length + ', ожидается 9');
REF.forEach((fam, i) => check(fam.n === order[i], 'семья ' + i + ': «' + fam.n + '», ожидалась «' + order[i] + '»'));

/* Экраны сверяются по имени: PRESET и SETUP в прошивке без секторов, у них список. */
const pageByTitle = new Map(pages.map((p) => [p.title, p]));
/* Настройки — список: в PAGES[] у страницы нет секторов, но таблица строк у неё есть. */
pageByTitle.set('SETUP', { title: 'SETUP', knobs: knobTables['KNOBS_SETUP'] || [] });

screens.forEach((scr) => {
  const page = pageByTitle.get(scr.n);
  check(!!page, 'экрану ' + scr.n + ' нет страницы в прошивке');
  if (!page) { return; }

  const mine = scr.p.map((p) => p[0]).join(' · ');
  const theirs = page.knobs.join(' · ');
  check(mine === theirs, 'экран ' + scr.n + ': ручки «' + mine + '», в прошивке «' + theirs + '»');
});


/* Число ступеней списочных параметров: список позиций обязан быть той же длины. */
const stepsFn = /case (SYNTH_PARAM_[A-Z0-9_]+):[\s\S]*?return (\d+);/g;

/* ── страницы сайта ──────────────────────────────────────────────────────── */

const famPages = {
  'Дрон': 'ref-drone.html',
  'Модуляция': 'ref-lfo.html',
  'Лид': 'ref-lead.html',
  'Генераторы': 'ref-time.html',
  'Перкуссия': 'ref-perc.html',
  'Бас': 'ref-bass.html',
  'Эффекты': 'ref-fx.html',
  'Микшер': 'ref-mix.html',
  'Пресеты и настройки': 'ref-store.html'
};

for (const fam of REF) {
  const file = path.join(root, 'web', famPages[fam.n]);
  check(fs.existsSync(file), 'нет страницы ' + famPages[fam.n]);
  if (!fs.existsSync(file)) { continue; }

  const html = fs.readFileSync(file, 'utf8');
  for (const scr of fam.s) {
    check(html.includes('>Экран ' + scr.n + '<') || html.includes('Экран ' + scr.n + '</h2>'),
          famPages[fam.n] + ': нет заголовка экрана ' + scr.n);
    for (const [name] of scr.p) {
      check(html.includes('param-code">' + name + '<'),
            famPages[fam.n] + ': ручка ' + name + ' не выведена');
    }
  }
}

/* Якоря дерева открывают вкладку: у каждой ссылки #tag обязан быть свой panel-tag и своя
 * вкладка с aria-controls. Иначе пункт меню ведёт на страницу с закрытой вкладкой. */
for (const [fam, file] of Object.entries(famPages)) {
  const p = path.join(root, 'web', file);
  if (!fs.existsSync(p)) { continue; }
  const html = fs.readFileSync(p, 'utf8');
  const own = new RegExp('href="' + file.replace('.', '\\.') + '#([a-z0-9]+)"', 'g');
  for (const m of html.matchAll(own)) {
    const tag = m[1];
    check(html.includes('id="panel-' + tag + '"'),
          file + ': у ссылки #' + tag + ' нет панели panel-' + tag);
    check(html.includes('aria-controls="panel-' + tag + '"'),
          file + ': у ссылки #' + tag + ' нет вкладки');
  }
  check(html.includes('assets/deep-link.js'), file + ': не подключён assets/deep-link.js — якорь не откроет вкладку');
}

/* Сайт не должен тащить данные, из которых собран: он статический. */
check(!fs.existsSync(path.join(root, 'web', 'assets', 'ref.js')),
      'web/assets/ref.js не должен лежать на сайте: страницы собираются статически');
check(!fs.existsSync(path.join(root, 'web', 'assets', 'docs.js')),
      'web/assets/docs.js больше не нужен: отрисовки в браузере нет');

if (problems.length) {
  console.log('НЕ ПРОШЛО, ' + problems.length + ':');
  problems.slice(0, 40).forEach((p) => console.log('  ' + p));
  process.exit(1);
}

console.log('OK: 9 семейств, ' + screens.length + ' экранов и ' +
            screens.reduce((n, s) => n + s.p.length, 0) + ' ручек совпадают с прошивкой; ' +
            'каждая ручка выведена на своей странице');
