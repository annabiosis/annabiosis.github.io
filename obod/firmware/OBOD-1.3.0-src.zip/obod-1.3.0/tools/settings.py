"""The two settings pages: no figure on SYSTEM, and OPTIONS in the larger face.

The owner's two orders in one gate, because they are one page pair:

  1. SYSTEM draws nothing. SCREEN, RING, RING FX and MIC are the panel's own
     housekeeping, and a symbol standing in for a value the readout already prints is
     the picture that teaches the eye to stop reading. The four knobs answer
     PREVIEW_NONE, and the three kinds they alone used — MIC, RING, RING MODE — are
     gone from the file and the header, together with the two arc helpers nothing else
     wanted.
  2. OPTIONS is set in the larger face. Its title is the only word of seven, it
     measures the full 80 px the sector blocks leave between them, and the owner took
     the touch over the smaller face: "если налезет куда-то — пусть".

The widths are measured from the faces the firmware draws, through ring_clearance.py's
own reader, so this cannot agree with a face that has been regenerated.

Run: python tools/settings.py
"""
import importlib.util
import re
import sys

sys.stdout.reconfigure(encoding="utf-8")

SRC_UI = "components/synth_ui/src/synth_ui.c"
SRC_PV = "components/synth_ui/src/synth_ui_preview.c"
HDR_PV = "components/synth_ui/src/synth_ui_preview.h"

PROBLEMS = []


def check(cond, msg):
    if not cond:
        PROBLEMS.append(msg)


def read(path):
    with open(path, encoding="utf-8", errors="replace") as fh:
        return fh.read()


ui = read(SRC_UI)
pv = read(SRC_PV)
hdr = read(HDR_PV)

# ---------------------------------------------------------------- 1. SYSTEM is plain

print("1. SYSTEM без фигур")
SETTING = ("SYNTH_PARAM_SET_SCREEN", "SYNTH_PARAM_SET_RING",
           "SYNTH_PARAM_SET_RINGMODE", "SYNTH_PARAM_SET_MIC")

disp = pv[pv.index("static synth_preview_kind_t pv_values"):]
for param in SETTING:
    # A chain of case labels ending in PREVIEW_NONE is how the file says "no figure".
    m = re.search(r"case %s:(?:\s*case [A-Z_0-9]+:)*\s*return PREVIEW_NONE;" % param, disp)
    check(m is not None, "%s всё ещё отдаёт картинку" % param)

for kind in ("PREVIEW_MIC", "PREVIEW_RING_MODE", "PREVIEW_RING"):
    check(re.search(r"\b%s\b" % kind, pv) is None, "%s остался в отрисовке" % kind)
    check(re.search(r"\b%s\b" % kind, hdr) is None, "%s остался в заголовке" % kind)

for fn in ("pv_mic", "pv_ring_mode", "pv_ring", "pv_dot_arc", "pv_circle_arc"):
    check(re.search(r"\b%s\b" % fn, pv) is None, "%s остался в файле" % fn)

# The two arc helpers were the only users of the step walk; the figures that remain must
# not have taken a copy of it.
check(pv.count("PV_COS[") >= 2, "таблица косинусов больше никому не нужна — проверь, что удалил не то")
print("   четыре ручки отвечают PREVIEW_NONE, три вида и два помощника удалены")

# ---------------------------------------------------------------- 2. OPTIONS is large

print("2. OPTIONS крупным шрифтом")
m = re.search(r"#define\s+TITLE_BIG_CHARS\s+(\d+)", ui)
check(m is not None, "нет TITLE_BIG_CHARS")
budget = int(m.group(1)) if m else 0
check(budget == 7, "бюджет заголовка %d, а OPTIONS просит семь" % budget)

check("title_fits_big(p->title) ? &lv_font_anbscreen_20 : &lv_font_anbscreen_14" in ui,
      "выбор шрифта заголовка не тот, что описан")

# Every page title, as PAGES[] spells it.
titles = re.findall(r'\[PAGE_[A-Z0-9_]+\]\s*=\s*\{"([^"]+)",\s*"([^"]+)"', ui)
check(len(titles) >= 20, "нашёл всего %d заголовков — таблица PAGES не разобрана" % len(titles))

spec = importlib.util.spec_from_file_location("rc", "tools/ring_clearance.py")
rc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rc)

worst = []
for full, _chip in titles:
    longest = max(full.split(" "), key=len)
    check(len(longest) <= budget,
          "у заголовка %r самое длинное слово %r не влезает в бюджет" % (full, longest))
    worst.append((rc.advance(longest, rc.F20), full, longest))

worst.sort(reverse=True)
print("   самый широкий заголовок в 20 px: %r — %.1f px (столбец 80)" % (worst[0][1], worst[0][0]))
for w, full, _ in worst[:3]:
    print("      %-12s %5.1f px" % (full, w))

check(worst[0][1] == "OPTIONS", "самый широкий заголовок теперь %r, а не OPTIONS" % worst[0][1])
# Without kerning the measure is the wider of the two; the note's 80 px is with kerning.
check(78.0 <= worst[0][0] <= 84.0,
      "OPTIONS мерит %.1f px без кернинга — столбец изменился, пересчитай" % worst[0][0])
print("   все %d заголовков влезают в бюджет, OPTIONS — единственное слово из семи" % len(titles))

print()
if PROBLEMS:
    for p in PROBLEMS:
        print("ПРОВАЛ: " + p)
    sys.exit(1)
print("настройки: SYSTEM без фигур, OPTIONS крупным шрифтом")
