/*
 * Logging, to stderr, with the level letter and the tag.
 *
 * The rescue lines are the reason this exists: they are the only account of why the fuse
 * fired, and the bench has to show them exactly as the instrument prints them. Format
 * strings and arguments are the DSP's own; nothing is interpreted here.
 */
#pragma once

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    HOST_LOG_DEBUG = 0,
    HOST_LOG_INFO,
    HOST_LOG_WARN,
    HOST_LOG_ERROR
} host_log_level_t;

void host_log_line(host_log_level_t level, const char *tag, const char *fmt, ...);

/* ESP-IDF's "milliseconds since boot", which the rack stores in its rescue record. On
 * the host that is the virtual clock, so a report from a run is still meaningful. */
uint32_t esp_log_timestamp(void);

#ifdef __cplusplus
}
#endif

#define ESP_LOGD(tag, fmt, ...) host_log_line(HOST_LOG_DEBUG, tag, fmt, ##__VA_ARGS__)
#define ESP_LOGI(tag, fmt, ...) host_log_line(HOST_LOG_INFO, tag, fmt, ##__VA_ARGS__)
#define ESP_LOGW(tag, fmt, ...) host_log_line(HOST_LOG_WARN, tag, fmt, ##__VA_ARGS__)
#define ESP_LOGE(tag, fmt, ...) host_log_line(HOST_LOG_ERROR, tag, fmt, ##__VA_ARGS__)
