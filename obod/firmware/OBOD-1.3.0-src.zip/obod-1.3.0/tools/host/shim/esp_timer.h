/*
 * Virtual microseconds.
 *
 * The audio sources read the clock for one thing only: the timestamp on a rescue line.
 * The host bench moves that clock itself, one block at a time, so a run is deterministic
 * and a long stretch of audio costs no real time. Nothing here sleeps or spins.
 */
#pragma once

#include <stdint.h>

/*
 * Частота ядра для стадийного хронометража: на устройстве это CONFIG_ESP_DEFAULT_CPU_FREQ_MHZ
 * из sdkconfig, а на стенде его нет — и сборка стенда падала, стоило включить STAGE_TIMING.
 * Стенд меряет время по своим часам, поэтому число здесь нужно только чтобы файл собрался.
 */
#ifndef CONFIG_ESP_DEFAULT_CPU_FREQ_MHZ
#define CONFIG_ESP_DEFAULT_CPU_FREQ_MHZ 240
#endif

#ifdef __cplusplus
extern "C" {
#endif

int64_t esp_timer_get_time(void);

#ifdef __cplusplus
}
#endif
