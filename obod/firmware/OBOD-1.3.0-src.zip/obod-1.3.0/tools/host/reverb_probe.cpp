/*
 * THE REVERB'S TAIL, ON THE DESKTOP, AS NUMBERS.
 *
 * Владелец попросил экономить, и самое дорогое место — резервуар реверберации. Экономия, которая
 * меняет хвост, должна быть измерена: этот драйвер бьёт по реверберации одним импульсом и печатает
 * время спада до минус шестидесяти и spectral centroid хвоста. Так видно, сохранились ли время и
 * характер пространства, а не только то, что звук не пропал.
 */
#include <chrono>
#include <math.h>
#include <thread>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "synth_dsp.h"
#include "synth_dsp_private.h"
#include "platform.h"

namespace {

constexpr int kBlock = SYNTH_BLOCK_SAMPLES;
constexpr int kRate = SYNTH_SAMPLE_RATE;

} // namespace

int main(int argc, char **argv)
{
    const float size = (argc > 1) ? (float)atof(argv[1]) : 0.6f;
    const float damp = (argc > 2) ? (float)atof(argv[2]) : 0.4f;
    const int   mode = (argc > 3) ? atoi(argv[3]) : SYNTH_REVERB_HALL;

    host_platform_init();
    synth_dsp_init(kRate);
    synth_reverb_init(kRate);
    synth_reverb_set(size, damp, 1.0f, mode);

    /*
     * ПУЛ ЗАБИРАЕТ ОТДЕЛЬНАЯ ЗАДАЧА, как на приборе: пока она не ответила, реверберация
     * молчит. На столе задача — настоящий поток, поэтому здесь надо дать ей время и
     * прокрутить несколько тихих блоков, иначе импульс уйдёт в пустоту.
     */
    for (int tries = 0; tries < 200 && !synth_reverb_prefetch(); tries++) {
        float zero[kBlock] = {0};
        float sl[kBlock] = {0};
        float sr2[kBlock] = {0};

        synth_reverb_process(kBlock, zero, sl, sr2);
        std::this_thread::sleep_for(std::chrono::milliseconds(20));
    }

    const int total = kRate * 5;
    float send[kBlock] = {0};
    float wl[kBlock] = {0};
    float wr[kBlock] = {0};

    /* Энергия по сотым долям секунды и спектр первой четверти секунды. */
    static float energy[50];
    static float spec[60000];
    int spec_n = 0;
    int pos = 0;

    for (int b = 0; b * kBlock < total; b++) {
        for (int i = 0; i < kBlock; i++) {
            send[i] = (b == 0 && i == 0) ? 1.0f : 0.0f;
        }

        synth_reverb_process(kBlock, send, wl, wr);
        if (b == 0) {
            fprintf(stderr, "отладка: пул %d, первые отсчёты %g %g %g %g | %g %g %g %g\n",
                    (int)synth_reverb_prefetch(), (double)wl[0], (double)wl[1], (double)wl[2],
                    (double)wl[3], (double)wl[4], (double)wl[5], (double)wl[6], (double)wl[7]);
        }

        for (int i = 0; i < kBlock; i++) {
            const int t = b * kBlock + i;
            const int slot = t / (kRate / 100);

            if (slot < 50) {
                energy[slot] += wl[i] * wl[i] + wr[i] * wr[i];
            }
            if (t < kRate / 4 && spec_n < 60000) {
                spec[spec_n++] = wl[i];
            }
            pos++;
        }
    }

    /* Время спада: отсчёт идёт от ПИКА, а не от первого слота — хвост сначала набирает
     * энергию, и наклон надо снимать после вершины. */
    float peak = 0.0f;
    int ip = 0;

    for (int i = 0; i < 50; i++) {
        if (energy[i] > peak) {
            peak = energy[i];
            ip = i;
        }
    }

    int i5 = -1, i20 = -1;

    for (int i = ip; i < 50; i++) {
        const float db = 10.0f * log10f((energy[i] + 1e-30f) / (peak + 1e-30f));

        if (i5 < 0 && db < -5.0f) {
            i5 = i;
        }
        if (i20 < 0 && db < -20.0f) {
            i20 = i;
        }
    }

    float t60 = 0.0f;

    if (i5 >= 0 && i20 > i5) {
        t60 = (float)(i20 - i5) / 100.0f * (60.0f / 15.0f);
    }

    /* Spectral centroid хвоста: сумма частоты на энергию, делённая на энергию. Простым
     * перебором по окнам в тысячу отсчётов, чтобы не тянуть сюда FFT. */
    double num = 0.0, den = 0.0;

    for (int w = 0; w + 1024 < spec_n; w += 512) {
        for (int k = 1; k < 128; k++) {
            double re = 0.0, im = 0.0;
            const double wr2 = -2.0 * 3.14159265358979 * (double)k / 1024.0;

            for (int n = 0; n < 1024; n++) {
                const double a = wr2 * (double)n;
                re += (double)spec[w + n] * cos(a);
                im += (double)spec[w + n] * sin(a);
            }

            const double mag = re * re + im * im;
            num += mag * ((double)k * (double)kRate / 1024.0);
            den += mag;
        }
    }

    printf("реверберация: размер %.2f, демпфирование %.2f, режим %d\n", (double)size, (double)damp, mode);
    printf("  T60 %.2f с, centroid хвоста %.0f Гц\n", (double)t60, den > 0.0 ? num / den : 0.0);
    printf("  энергия по сотым от пика: ");
    for (int i = 0; i < 30; i += 2) {
        printf("%.0f ", (double)(10.0f * log10f((energy[i] + 1e-30f) / (peak + 1e-30f))));
    }
    printf("\n");
    return 0;
}
