/*
 * СТУПЕНЬКИ ГРОМКОСТИ БАСА, ЧЕСТНАЯ МЕТРИКА.
 *
 * Ступенька — это не разница уровней двух нот (акцент и призрак и должны отличаться), а
 * СКАЧОК: уровень меняется мгновенно вместо того, чтобы ехать. Мерить надо огибающую, а не
 * RMS одного окошка в миллисекунду: на 55 Гц в миллисекунде меньше одной десятой периода, и
 * такое «окошко» меряет фазу волны, а не громкость.
 *
 * Здесь весь рендер лежит в памяти, и на каждой границе шага берётся RMS за 25 мс до неё и за
 * 25 мс после. Разница — это и есть ступенька. На 120 BPM шаг 125 мс, так что окошко в 25 мс
 * мерит именно начало ноты, а не соседей.
 *
 *   bass_steps.exe              рисунок 40, длина 16, акцент 0.35, гейт 0.35
 *   bass_steps.exe 27 16 0.35 0.95
 */
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "synth_dsp.h"
#include "platform.h"

#define MAX_SAMPLES (1200 * SYNTH_BLOCK_SAMPLES)
#define MAX_BOUNDS 256

static float g_buf[MAX_SAMPLES];

static double rms_of(int from, int to)
{
    if (from < 0) {
        from = 0;
    }
    if (to > MAX_SAMPLES) {
        to = MAX_SAMPLES;
    }
    if (to <= from) {
        return 0.0;
    }

    double s = 0.0;

    for (int i = from; i < to; i++) {
        s += (double)g_buf[i] * (double)g_buf[i];
    }

    return sqrt(s / (double)(to - from));
}

int main(int argc, char **argv)
{
    const int pat = (argc > 1) ? atoi(argv[1]) : 40;
    const float len01 = (argc > 2) ? (float)atof(argv[2]) / 12.0f : 1.0f;
    const float accent = (argc > 3) ? (float)atof(argv[3]) : 0.35f;
    const float gate = (argc > 4) ? (float)atof(argv[4]) : 0.35f;

    host_platform_init();
    synth_dsp_init(SYNTH_SAMPLE_RATE);
    synth_bass_set_tempo(120.0f);
    synth_bass_set(SYNTH_BASS_LEN, len01);
    synth_bass_set(SYNTH_BASS_ACCENT, accent);
    synth_bass_set(SYNTH_BASS_GATE, gate);
    synth_bass_set(SYNTH_BASS_PAT, (float)pat / 41.0f + 0.0001f);

    const int wind = SYNTH_SAMPLE_RATE * 25 / 1000;
    int bound[MAX_BOUNDS];
    int bound_step[MAX_BOUNDS];
    int nb = 0;
    int filled = 0;
    int prev = -1;

    for (int b = 0; b < 1200 && filled + SYNTH_BLOCK_SAMPLES <= MAX_SAMPLES; b++) {
        synth_layers_clear(256);
        synth_bass_block(256);

        const float *out = synth_layer_l(SYNTH_LAYER_BASS);
        const int st = synth_bass_step();

        memcpy(&g_buf[filled], out, sizeof(float) * SYNTH_BLOCK_SAMPLES);

        if (b >= 300 && st != prev && nb < MAX_BOUNDS) {
            bound[nb] = filled;
            bound_step[nb] = st;
            nb++;
        }

        filled += SYNTH_BLOCK_SAMPLES;
        prev = st;
    }

    printf("рисунок %d, длина %d, гейт %.2f, окончено %d границ\n", synth_bass_pattern(),
           synth_bass_steps(), (double)gate, nb);

    double worst = 0.0;
    int worst_step = -1;

    for (int i = 0; i < nb; i++) {
        const int at = bound[i];
        const double before = rms_of(at - wind, at);
        const double after = rms_of(at, at + wind);

        if (before < 0.01 || after < 0.01) {
            continue;   /* тишина перед нотой: это не ступенька, а начало с паузы */
        }

        const double d = 20.0 * log10(after / before);

        printf("  граница шага %2d: до %.4f, после %.4f, %+6.1f дБ\n", bound_step[i], before,
               after, d);

        if (d < worst) {
            worst = d;
            worst_step = bound_step[i];
        }
    }

    /*
     * УРОВЕНЬ КАЖДОГО ШАГА, по настоящим границам. Шаг в 125 мс не кратен блоку в 5.33 мс,
     * поэтому окно, отсчитанное от начала рендера, уезжает и меряет половину соседнего шага.
     * Границы взяты из счётчика баса: между двумя соседними границами и есть шаг.
     *
     * Это отвечает на главный вопрос: если при ОДИНАКОВОЙ силе шага уровень ползёт вместе с
     * высотой ноты, ступенька не в силе, а в фильтре — фиксированный срез пропускает больше
     * гармоник у верхней ноты.
     */
    printf("уровень по шагам (окно — шаг целиком):\n");

    for (int i = 0; i + 1 < nb; i++) {
        double r = rms_of(bound[i], bound[i + 1]);

        if (r <= 1e-9) {
            continue;
        }

        printf("  шаг %2d: %6.4f  %+6.1f дБ%s\n", bound_step[i], r, 20.0 * log10(r),
               (synth_bass_is_onset(bound_step[i]) ? "" : "   (пусто)"));
    }

    printf("худшая ступенька: %+.1f дБ (на шаге %d)\n", worst, worst_step);
    return 0;
}
