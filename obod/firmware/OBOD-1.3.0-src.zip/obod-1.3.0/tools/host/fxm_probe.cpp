/*
 * БЫСТРАЯ ПРОВЕРКА ЭФФЕКТ-МАШИНЫ НА СТОЛЕ.
 *
 * Гоняет синус через каждый тип и печатает среднеквадратичное на выходе: ноль или тишина
 * значат, что эффект не звучит вовсе, а разница с входом — насколько он вообще вмешивается.
 */
#include <math.h>
#include <time.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "synth_dsp.h"
#include "synth_dsp_private.h"
#include "platform.h"

#define N SYNTH_BLOCK_SAMPLES

int main(void)
{
    host_platform_init();
    synth_dsp_init(SYNTH_SAMPLE_RATE);
    synth_fx_machine_set_tempo(120.0f, 1);

    static float l[N];
    static float r[N];

    printf("%-10s %8s %8s %8s\n", "тип", "вход", "выход", "разница");

    for (int type = 0; type < SYNTH_FXM_COUNT; type++) {
        const clock_t t_type = clock();
        synth_fx_machine_set_type(type);
        synth_fx_machine_reset_state();
        synth_fx_machine_set_params(0.30f, 0.60f, 0.50f);

        double in = 0.0;
        double out = 0.0;
        double diff = 0.0;

        for (int b = 0; b < 400; b++) {
            for (int i = 0; i < N; i++) {
                const float ph = (float)(b * N + i) / (float)SYNTH_SAMPLE_RATE;
                const float v = 0.4f * sinf(2.0f * 3.14159265f * 220.0f * ph);

                l[i] = v;
                r[i] = v;
            }

            static float in_l[N];
            memcpy(in_l, l, sizeof(in_l));

            synth_fx_machine_process(N, l, r);

            if (b >= 200) {
                for (int i = 0; i < N; i++) {
                    in += (double)in_l[i] * in_l[i];
                    out += (double)l[i] * l[i];
                    diff += fabs((double)l[i] - in_l[i]);
                }
            }
        }

        const double ms_per_block = 1000.0 * (double)(clock() - t_type) / (double)CLOCKS_PER_SEC;
        printf("%-10d %8.4f %8.4f %8.4f  %6.1f us/block\n", type, sqrt(in / 51200.0),
               sqrt(out / 51200.0), diff / 51200.0, ms_per_block * 1000.0 / 400.0);
        fflush(stdout);
    }

    return 0;
}
