#include <cstdio>
#include <cstdlib>
/*
 * THE BASS, ON THE DESKTOP, AS A FILE.
 *
 * Владелец судит голос на слух, а я слышать не могу: три переделки ушли в прошивку и
 * вернулись словами «тихо», «низко», «щёлкает». Этот драйвер рендерит слой баса ровно так,
 * как его рендерит прибор — те же исходники DSP, тот же блок 256, тот же секвенсор — и
 * складывает результат в WAV. Дальше его можно померить: основной тон, гармоники, уровень,
 * разрывы на атаках.
 *
 *   tools\host-bass.ps1            все тридцать заготовок, по четыре секунды
 *   tools\host-bass.ps1 -Kit 5     одна заготовка
 *
 * Ничего из этого не входит в прошивку: драйвер живёт в tools\host и собирается зигом вместе
 * с остальными исходниками компонента.
 */
#include <chrono>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "synth_dsp.h"
#include "platform.h"

namespace {

constexpr int kBlock = SYNTH_BLOCK_SAMPLES;

void put_u16(FILE *f, uint16_t v)
{
    fputc(v & 0xFF, f);
    fputc((v >> 8) & 0xFF, f);
}

void put_u32(FILE *f, uint32_t v)
{
    put_u16(f, (uint16_t)(v & 0xFFFF));
    put_u16(f, (uint16_t)(v >> 16));
}

bool write_wav(const char *path, const float *mono, int count, int rate)
{
    FILE *f = fopen(path, "wb");

    if (f == NULL) {
        return false;
    }

    const uint32_t data = (uint32_t)count * 2u;
    const uint32_t riff = 36u + data;

    fwrite("RIFF", 1, 4, f);
    put_u32(f, riff);
    fwrite("WAVEfmt ", 1, 8, f);
    put_u32(f, 16);
    put_u16(f, 1);            /* PCM */
    put_u16(f, 1);            /* mono */
    put_u32(f, (uint32_t)rate);
    put_u32(f, (uint32_t)rate * 2u);
    put_u16(f, 2);
    put_u16(f, 16);
    fwrite("data", 1, 4, f);
    put_u32(f, data);

    for (int i = 0; i < count; i++) {
        int v = (int)lrintf(mono[i] * 32767.0f);

        if (v > 32767) {
            v = 32767;
        }
        if (v < -32768) {
            v = -32768;
        }
        put_u16(f, (uint16_t)(int16_t)v);
    }

    fclose(f);

    return true;
}

}  // namespace

extern "C" void synth_host_trace(int step, int len, int pat)
{
    fprintf(stderr, "trace step %d len %d pat %d\n", step, len, pat);
}

int main(int argc, char **argv)
{
    int   kit = 0;
    float seconds = 4.0f;
    float tone = -1.0f;
    float decay = -1.0f;
    float res = -1.0f;
    float gate = -1.0f;
    float pat = -1.0f;
    float var = -1.0f;
    float accent = -1.0f;
    float slide = -1.0f;
    float len = -1.0f;
    float sub = -1.0f;
    int   mask = -1;

    if (argc > 1) {
        kit = atoi(argv[1]);
    }
    if (argc > 2) {
        seconds = (float)atof(argv[2]);
    }
    if (argc > 3) {
        tone = (float)atof(argv[3]);
    }
    if (argc > 4) {
        decay = (float)atof(argv[4]);
    }
    if (argc > 5) {
        res = (float)atof(argv[5]);
    }
    if (argc > 6) {
        gate = (float)atof(argv[6]);
    }
    if (argc > 7) {
        pat = (float)atof(argv[7]);
    }
    if (argc > 8) {
        var = (float)atof(argv[8]);
    }
    if (argc > 9) {
        accent = (float)atof(argv[9]);
    }
    if (argc > 10) {
        slide = (float)atof(argv[10]);
    }
    if (argc > 11) {
        mask = atoi(argv[11]);
    }
    if (argc > 12) {
        len = (float)atof(argv[12]);

        if (argc > 13) {
            sub = (float)atof(argv[13]);
        }
    }

    host_platform_init();
    synth_dsp_init(SYNTH_SAMPLE_RATE);

    synth_bass_set_tempo(120.0f);
    synth_bass_set_root_hz(55.0f);
    synth_bass_set_playing(true);
    synth_bass_set(SYNTH_BASS_KIT, (float)kit / 29.0f);

    if (tone >= 0.0f)   { synth_bass_set(SYNTH_BASS_NOTE, tone); }   /* слот 2: смена ноты */
    if (decay >= 0.0f)  { synth_bass_set(SYNTH_BASS_DECAY, decay); }
    if (res >= 0.0f)    { synth_bass_set(SYNTH_BASS_DRIVE, res); }  /* номер прежний, суть новая */
    if (gate >= 0.0f)   { synth_bass_set(SYNTH_BASS_GATE, gate); }
    if (pat >= 0.0f)    { synth_bass_set(SYNTH_BASS_PAT, pat); }
    if (var >= 0.0f)    { synth_bass_set(SYNTH_BASS_VAR, var); }
    if (accent >= 0.0f) { synth_bass_set(SYNTH_BASS_ACCENT, accent); }
    if (slide >= 0.0f)  { synth_bass_set(SYNTH_BASS_SLIDE, slide); }
    if (len >= 0.0f)    { synth_bass_set(SYNTH_BASS_LEN, len); }

    if (sub >= 0.0f)    { synth_bass_set(SYNTH_BASS_SNAP, sub); }   /* слот SNAP теперь саб */

    /* Фигура акцентов: чётные шаги, как у большинства рисунков. Без маски акцентов не
     * бывает вовсе, и ручку ACCENT нечем проверить. */
    synth_bass_set_accent_mask(0x5555u);
    if (mask >= 0)      { synth_bass_set_scale_mask((uint16_t)mask); }

    const int total = (int)(seconds * (float)SYNTH_SAMPLE_RATE);
    float *out = (float *)calloc((size_t)total, sizeof(float));

    if (out == NULL) {
        return 1;
    }

    int written = 0;
    const auto bench_t0 = std::chrono::steady_clock::now();

    while (written < total) {
        float *l = synth_layer_l(SYNTH_LAYER_BASS);

        synth_layers_clear(kBlock);
        synth_bass_block(kBlock);

        /* The layer buffer is the voice's own output; a second read would be the rack's,
         * and the rack adds the fader and the sends, which are the app's business. */
        l = synth_layer_l(SYNTH_LAYER_BASS);

        int n = total - written;

        if (n > kBlock) {
            n = kBlock;
        }

        for (int i = 0; i < n; i++) {
            out[written + i] = l[i];
        }

        written += n;
    }

    char path[512];
    snprintf(path, sizeof(path), "build\\bass\\kit%02d.wav", kit);

    if (!write_wav(path, out, total, SYNTH_SAMPLE_RATE)) {
        free(out);
        return 1;
    }

    /* One line of numbers beside the file: the peak and the RMS of the whole take, so a
     * silent kit is visible without opening the wave. */
    float peak = 0.0f;
    double sum = 0.0;

    /*
     * Яркость: доля энергии выше килогерца, посчитанная одним полюсом высоких частот, а не
     * преобразованием Фурье. Для сравнения двух прогонов одного и того же кита этого хватает:
     * полюс стоит на 250 Гц и его состояние — это и есть «сколько там верха».
     */
    double bright = 0.0;
    float hp_x = 0.0f;
    float hp_y = 0.0f;
    const float hp_a = 1.0f / (1.0f + 6.2831853f * 250.0f / (float)SYNTH_SAMPLE_RATE);

    for (int i = 0; i < total; i++) {
        const float a = fabsf(out[i]);

        if (a > peak) {
            peak = a;
        }
        sum += (double)out[i] * (double)out[i];

        hp_y = hp_a * (hp_y + out[i] - hp_x);
        hp_x = out[i];
        bright += (double)hp_y * (double)hp_y;
    }

    const double rms_v = sqrt(sum / (double)total);
    const float brightness = (sum > 0.0) ? (float)(sqrt(bright / sum)) : 0.0f;

    {
        const auto bench_t1 = std::chrono::steady_clock::now();
        const double us = std::chrono::duration<double, std::micro>(bench_t1 - bench_t0).count();
        int blocks = written / kBlock;
        if (blocks > 0) {
            /* Из блока вычитается запись wav: она не про голос. */
            printf("bench: %d blocks, %.3f us/block\n", blocks, us / (double)blocks);
        }
    }

    printf("kit %02d  peak %.3f  rms %.3f  bright %.3f  %s\n", kit, peak,
           (float)rms_v, (double)brightness, path);

    free(out);

    return 0;
}
