/*
 * РАЗБРОС СТЕРЕО ЛИДА: ширина без потери суммы.
 *
 * Проверяет две вещи числами: с разбросом стороны расходятся (боковой сигнал L-R растёт), а
 * сумма L+R остаётся прежней — то есть моно-совместимость не потеряна. Панорама при измерении
 * стоит по центру и без дрейфа, чтобы мерился именно разброс.
 *
 *   spread_probe.exe 0.0
 *   spread_probe.exe 1.0
 */
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "synth_dsp.h"
#include "platform.h"

#define BLOCK SYNTH_BLOCK_SAMPLES

int main(int argc, char **argv)
{
    const float spread = (argc > 1) ? (float)atof(argv[1]) : 0.0f;

    host_platform_init();
    synth_dsp_init(SYNTH_SAMPLE_RATE);
    synth_dsp_set_lead_spread(spread);

    int16_t ep[8];
    memset(ep, 0, sizeof(ep));
    ep[0] = 0;      /* панорама по центру */
    ep[1] = 0;      /* дрейфа нет */
    ep[6] = 1;      /* включено */
    ep[7] = SYNTH_LAYER_LEAD;

    static int32_t bus[BLOCK];
    double sum_energy = 0.0;
    double side_energy = 0.0;
    long n = 0;

    float ph = 0.0f;
    const float inc = 220.0f / (float)SYNTH_SAMPLE_RATE;

    for (int b = 0; b < 400; b++) {
        for (int i = 0; i < BLOCK; i++) {
            const float v = 0.25f * sinf(ph * 6.2831853f);
            ph += inc;
            if (ph >= 1.0f) {
                ph -= 1.0f;
            }
            bus[i] = (int32_t)(v * 32768.0f);
        }

        synth_layers_clear(BLOCK);
        synth_fx_pan_capture(bus, BLOCK, ep, nullptr);

        if (b < 20) {
            continue;   /* первый блок — состояние all-pass пустое */
        }

        const float *l = synth_layer_l(SYNTH_LAYER_LEAD);
        const float *r = synth_layer_r(SYNTH_LAYER_LEAD);

        for (int i = 0; i < BLOCK; i++) {
            const double s = (double)l[i] + (double)r[i];
            const double d = (double)l[i] - (double)r[i];
            sum_energy += s * s;
            side_energy += d * d;
            n++;
        }
    }

    const double sum_rms = sqrt(sum_energy / (double)n);
    const double side_rms = sqrt(side_energy / (double)n);

    printf("разброс %.2f: сумма %.5f, сторона %.5f (%+.1f дБ к сумме)\n", (double)spread,
           sum_rms, side_rms,
           20.0 * log10((side_rms > 1e-9 ? side_rms : 1e-9) / (sum_rms > 1e-9 ? sum_rms : 1e-9)));
    return 0;
}
