/*
 * БАС: САБ И ИСКАЖЕНИЯ, ЧИСЛАМИ.
 *
 * Владелец: «много искажений даёт звук баса, особенно на низах» и «SUB плохо слышно».
 * Стенд играет одну длинную ноту (рисунок 0, гейт во весь шаг, длинный спад) и считает:
 *   - уровень основного тона f0 (это то, что слышно как «нота»);
 *   - уровень саба f0/2 (то, что даёт вес);
 *   - суммарные искажения: сумма гармоник 2..10 к основному тону, в процентах и дБ;
 *   - пик: если он уходит за колено ограничителя, искажения растут.
 *
 *   bass_thd.exe 0 1.0    kit, sub
 */
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "synth_dsp.h"
#include "platform.h"

#define BLOCK SYNTH_BLOCK_SAMPLES

static double goertzel(const float *x, int n, double hz, double fs)
{
    const double w = 2.0 * 3.14159265358979323846 * hz / fs;
    const double c = 2.0 * cos(w);
    double s0 = 0.0, s1 = 0.0, s2 = 0.0;

    for (int i = 0; i < n; i++) {
        s0 = (double)x[i] + c * s1 - s2;
        s2 = s1;
        s1 = s0;
    }

    const double re = s1 - s2 * cos(w);
    const double im = s2 * sin(w);

    return sqrt(re * re + im * im) * 2.0 / (double)n;
}

int main(int argc, char **argv)
{
    const int kit = (argc > 1) ? atoi(argv[1]) : 0;
    const float sub = (argc > 2) ? (float)atof(argv[2]) : 1.0f;
    const float oct = (argc > 3) ? (float)atof(argv[3]) : 0.5f;

    host_platform_init();
    synth_dsp_init(SYNTH_SAMPLE_RATE);
    synth_bass_set_tempo(60.0f);
    synth_bass_set_root_hz(55.0f);   /* тоника баса: A1 */
    synth_bass_set(SYNTH_BASS_KIT, (float)kit / 29.0f + 0.001f);
    synth_bass_set(SYNTH_BASS_PAT, 0.0001f);          /* одна нота на такт */
    synth_bass_set(SYNTH_BASS_LEN, 1.0f);
    synth_bass_set(SYNTH_BASS_GATE, 1.0f);
    synth_bass_set(SYNTH_BASS_DECAY, 1.0f);
    synth_bass_set(SYNTH_BASS_SNAP, sub);             /* слот 4: количество саба */
    synth_bass_set(SYNTH_BASS_ACCENT, 0.0f);
    synth_bass_set_accent_mask(0u);
    synth_bass_set(SYNTH_BASS_NOTE, oct);   /* слот 2: октава линии */            /* слот 2: октава, центр */

    static float buf[48 * 1024];
    int n = 0;
    double peak = 0.0;

    /* Два такта по 250 мс на 60 BPM; берём второй и срезаем начало ноты. */
    for (int b = 0; b < 400 && n + BLOCK < (int)(sizeof(buf) / sizeof(buf[0])); b++) {
        synth_layers_clear(BLOCK);
        synth_bass_block(BLOCK);

        const float *out = synth_layer_l(SYNTH_LAYER_BASS);

        if (b >= 200) {
            memcpy(&buf[n], out, sizeof(float) * BLOCK);
            n += BLOCK;
        }
        for (int i = 0; i < BLOCK; i++) {
            if (b >= 200 && fabs((double)out[i]) > peak) {
                peak = fabs((double)out[i]);
            }
        }
    }

    const double fs = (double)SYNTH_SAMPLE_RATE;

    /*
     * ЧАСТОТА НОТЫ — ПОИСКОМ, А НЕ ПО ФОРМУЛЕ. Так проверяется и октава: если ручка стоит не
     * по центру, пик уходит на октаву вверх или вниз, и это видно числом.
     */
    double note = 55.0;
    {
        double best = 0.0;
        for (double hz = 20.0; hz <= 300.0; hz += 0.5) {
            const double a1 = goertzel(buf, n > 8192 ? 8192 : n, hz, fs);
            if (a1 > best) {
                best = a1;
                note = hz;
            }
        }
        printf("пик спектра: %.1f Гц (сила %.4f)\n", note, best);
    }
    const double fund = goertzel(buf, n, note, fs);
    const double subf = goertzel(buf, n, note * 0.5, fs);

    double harm = 0.0;
    for (int h = 2; h <= 10; h++) {
        const double a = goertzel(buf, n, note * (double)h, fs);
        harm += a * a;
    }
    harm = sqrt(harm);

    printf("кит %2d, саб %.2f: пик %.3f, основной %.4f, саб %.4f (%+.1f дБ к основному)\n",
           kit, (double)sub, peak, fund, subf,
           20.0 * log10((subf > 1e-9 ? subf : 1e-9) / (fund > 1e-9 ? fund : 1e-9)));
    printf("   искажения: гармоники 2..10 = %.1f %% от основного (%+.1f дБ)\n",
           100.0 * harm / (fund > 1e-9 ? fund : 1e-9),
           20.0 * log10((harm > 1e-9 ? harm : 1e-9) / (fund > 1e-9 ? fund : 1e-9)));
    return 0;
}
