/* Что движок думает о рисунке: ноты, сила, акценты. Для проверки таблицы без ушей. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "synth_dsp.h"
#include "synth_dsp_private.h"
#include "platform.h"

int main(int argc, char **argv)
{
    const int pat = (argc > 1) ? atoi(argv[1]) : 40;
    const float len = (argc > 2) ? (float)atof(argv[2]) : 1.0f;

    host_platform_init();
    synth_dsp_init(SYNTH_SAMPLE_RATE);
    synth_bass_set(SYNTH_BASS_LEN, len);

    synth_bass_set(SYNTH_BASS_PAT, (float)pat / 41.0f + 0.0001f);

    /* Полблока тишины: ступень и рисунок доезжают до состояния в блоке, как на приборе. */
    for (int b = 0; b < 4; b++) {
        synth_bass_block(256);
    }

    printf("запрошен рисунок %d, движок говорит %d, шагов %d\n",
           pat, synth_bass_pattern(), synth_bass_steps());

    for (int k = 0; k < 16; k++) {
        printf("  шаг %2d: нота %d, акцент %d\n", k, synth_bass_is_onset(k), synth_bass_is_accent(k));
    }

    /*
     * ПЕРЕЗАПУСК С ПЕРВОГО ШАГА. Сначала бас надо увести с нуля: восемь блоков на 120 —
     * это несколько шестнадцатых, счётчик уйдёт вперёд. Потом synth_bass_restart(), один
     * блок — и счётчик обязан стоять на нуле, а голос звучать: пуск с начала, а не пуск с
     * середины, который слышал владелец.
     */
    synth_bass_set_tempo(120.0f);
    for (int b = 0; b < 24; b++) {
        synth_bass_block(256);
    }
    const int before = synth_bass_step();

    synth_bass_restart();
    const int just = synth_bass_step();

    synth_bass_block(256);
    const int after = synth_bass_step();
    const float env = synth_bass_env();

    printf("перезапуск: было %d, после сброса %d, через блок %d, огибающая %.3f\n",
           before, just, after, (double)env);

    int bad = 0;
    if (before == 0) {
        printf("ПРОВАЛ: бас не ушёл с первого шага, проверять нечего\n");
        bad = 1;
    }
    if (just != 0 || after != 0) {
        printf("ПРОВАЛ: после сброса счётчик не на нуле\n");
        bad = 1;
    }
    if (!(env > 0.05f)) {
        printf("ПРОВАЛ: на первом шаге после сброса нет ноты\n");
        bad = 1;
    }
    printf("%s\n", bad ? "ПРОВАЛ: перезапуск баса не работает"
                        : "ок: бас начинает с первого шага");
    return bad;
}
