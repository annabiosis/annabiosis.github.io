/*
 * The drum kit, its styles, its figures, and now the timbres themselves — rendered to files
 * that can be listened to.
 *
 * The voice is the firmware's own: components/synth_dsp/src/synth_perc.cpp, compiled
 * unchanged through the platform seam the stress bench uses. Everything above the voice is
 * the design being auditioned:
 *
 *   ROLES. One set of knobs, four lanes: KICK, SNARE, HAT, TOM, each a recipe — centre,
 *   gate, pitch fall, body. HAT and SNARE also have an ALTERNATE: the open hat and the rim.
 *
 *   FIGURES. Each lane has a Euclidean figure: hits spread over sixteen steps, then
 *   rotated. VARIATION re-draws a figure at the bar line and adds ghost notes; FILL fills
 *   the second half of the last bar of a cycle; SWING makes the second sixteenth wait.
 *
 *   TIMBRES. A drum is not the same drum at every velocity. Three things move the sound:
 *   VELOCITY (a harder hit is brighter, longer and has more body), PER-HIT JITTER (a few
 *   cents of pitch, a few percent of gate) and MOTION (a slow per-lane walk that changes
 *   the centre and the gate from bar to bar). TIMBRE is the knob that scales all three, and
 *   the alternates: the same knob that makes a figure live also lets a lane change voice.
 *
 *   CONTROL. Per lane, three knobs: TONE (a transpose in semitones), DECAY (a multiplier on
 *   the gate) and BODY (a multiplier on the tone under the noise). The kit chooses where
 *   they start; the knobs move from there, so the same kit can be tight or fat.
 *
 * WHAT THIS IS NOT. Nothing here is committed to synth_app or the UI. The numbers are the
 * audition; the files below are the audition.
 *
 * Build and run: tools/perc-kit.ps1 — the WAVs land in build/perc-kit/.
 */
#include "platform.h"
#include "synth_dsp.h"

#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>

namespace {

constexpr int SUB = 32;              /* the grain an event is placed at: 0.67 ms */
constexpr int SAMPLE_RATE = 48000;
constexpr int BARS = 12;
constexpr int STEPS = 16;
constexpr int BPM = 108;

/* The module's mappings, read the way the display reads them. */
constexpr float PITCH_MIN_HZ = 35.0f;
constexpr float PITCH_OCTAVES = 7.65f;
constexpr float DECAY_MIN_MS = 20.0f;
constexpr float DECAY_SPAN = 6.2288f;
constexpr float ENV_MAX_OCT = 5.0f;

float pitch01(float hz)
{
    const float v = std::log2(hz / PITCH_MIN_HZ) / PITCH_OCTAVES;
    return v < 0.0f ? 0.0f : (v > 0.99f ? 0.99f : v);
}

float decay01(float ms)
{
    const float v = std::log2(ms / DECAY_MIN_MS) / DECAY_SPAN;
    return v < 0.0f ? 0.0f : (v > 1.0f ? 1.0f : v);
}

float env01(float octaves)
{
    const float v = octaves / ENV_MAX_OCT;
    return v < 0.0f ? 0.0f : (v > 1.0f ? 1.0f : v);
}

float clampf(float v, float lo, float hi)
{
    return v < lo ? lo : (v > hi ? hi : v);
}

/* ------------------------------------------------------------------------- */
/* The kit: four lanes, each with a voice and an alternate                     */

struct role {
    float pitch_hz;
    float decay_ms;
    float env_oct;
    float body;
    float level;
};

enum lane { LANE_KICK, LANE_SNARE, LANE_HAT, LANE_TOM, LANE_COUNT };

struct kit {
    const char *name;
    role voice[LANE_COUNT];
    role alt[LANE_COUNT];
    float hat_metal;
    int   hits[LANE_COUNT];     /* the default Euclidean figure, per bar */
    float ghost;
    int   cycle;
};

const kit KIT_TIGHT = {
    "TIGHT",
    { { 46.0f, 340.0f, 3.2f, 0.92f, 1.00f },
      { 340.0f, 100.0f, 0.8f, 0.04f, 0.90f },
      { 6400.0f, 38.0f, 0.2f, 0.00f, 0.65f },
      { 160.0f, 140.0f, 1.4f, 0.50f, 0.85f } },
    { { 74.0f, 130.0f, 1.2f, 0.45f, 0.95f },
      { 720.0f,  58.0f, 0.6f, 0.30f, 0.80f },
      { 5000.0f, 150.0f, 0.2f, 0.00f, 0.55f },
      { 240.0f, 110.0f, 1.2f, 0.40f, 0.80f } },
    0.55f, { 3, 2, 8, 0 }, 0.10f, 2,
};

const kit KIT_MINI = {
    "MINI",
    { { 41.0f, 480.0f, 3.6f, 0.95f, 1.00f },
      { 330.0f, 120.0f, 0.9f, 0.05f, 0.90f },
      { 6200.0f, 45.0f, 0.2f, 0.00f, 0.70f },
      { 165.0f, 190.0f, 1.6f, 0.55f, 0.90f } },
    { { 70.0f, 160.0f, 1.4f, 0.50f, 0.95f },
      { 700.0f,  60.0f, 0.6f, 0.32f, 0.80f },
      { 4800.0f, 240.0f, 0.2f, 0.00f, 0.60f },
      { 250.0f, 140.0f, 1.4f, 0.45f, 0.82f } },
    0.85f, { 3, 2, 8, 0 }, 0.18f, 4,
};

const kit KIT_BROKEN = {
    "BROKEN",
    { { 37.0f, 620.0f, 3.9f, 0.98f, 1.00f },
      { 300.0f, 160.0f, 1.2f, 0.08f, 0.92f },
      { 5600.0f, 60.0f, 0.25f, 0.00f, 0.66f },
      { 150.0f, 260.0f, 2.0f, 0.45f, 0.90f } },
    { { 62.0f, 200.0f, 1.6f, 0.40f, 0.95f },
      { 640.0f,  70.0f, 0.8f, 0.25f, 0.82f },
      { 4200.0f, 300.0f, 0.2f, 0.00f, 0.58f },
      { 220.0f, 170.0f, 1.6f, 0.38f, 0.82f } },
    1.00f, { 4, 3, 6, 0 }, 0.30f, 2,
};

const role ROLE_TODAY = { 700.0f, 110.0f, 0.5f, 0.15f, 0.90f };

/* ------------------------------------------------------------------------- */
/* The knobs                                                                   */

struct knobs {
    float variation;    /* 0..1 figures: re-draws at the bar line, ghosts */
    float fill;         /* 0..1 the last bar of a cycle */
    float swing;        /* 0..0.6 how late the second sixteenth sits */
    float timbre;       /* 0..1 velocity coupling, jitter, motion, alternates */
    float tone_st[LANE_COUNT];     /* semitones, per lane */
    float decay_mul[LANE_COUNT];   /* multiplier on the gate */
    float body_mul[LANE_COUNT];    /* multiplier on the tone under the noise */
};

struct event {
    int at;
    role r;
    float velocity;
    float metal;
};

void perc_set(const role &r)
{
    synth_perc_set(pitch01(r.pitch_hz), 0.0f, decay01(r.decay_ms), env01(r.env_oct),
                   clampf(r.level, 0.0f, 1.0f), clampf(r.body, 0.0f, 1.0f),
                   SYNTH_PERC_PUNCH_NEUTRAL);
}

void render_pass(const std::vector<event> &events, int total, std::vector<float> &l,
                 std::vector<float> &r)
{
    l.assign(total, 0.0f);
    r.assign(total, 0.0f);

    std::vector<float> sl(SUB), sr(SUB), rev(SUB), cl(SUB), cr(SUB), dl(SUB), dr(SUB);

    size_t next = 0;
    for (int pos = 0; pos < total; pos += SUB) {
        const int n = (pos + SUB <= total) ? SUB : (total - pos);

        while (next < events.size() && events[next].at < pos + n) {
            perc_set(events[next].r);
            synth_perc_trigger(events[next].velocity, 1.0f);
            next++;
        }

        synth_perc_process(n, l.data() + pos, r.data() + pos, rev.data(), 0.0f,
                           cl.data(), cr.data(), 0.0f, dl.data(), dr.data(), 0.0f);
    }
}

void apply_metal(std::vector<float> &l, std::vector<float> &r, int from, int length, float depth)
{
    if (depth <= 0.0f) {
        return;
    }
    const float w1 = 2.0f * 3.14159265358979f * 4300.0f / (float)SAMPLE_RATE;
    const float w2 = w1 * 1.737f;
    for (int i = 0; i < length; i++) {
        const int k = from + i;
        if (k < 0 || k >= (int)l.size()) {
            break;
        }
        const float t = (float)i / (float)length;
        const float fade = (t > 0.75f) ? (1.0f - t) / 0.25f : 1.0f;
        const float m = (0.6f * std::sin(w1 * i) + 0.4f * std::sin(w2 * i + 0.7f)) * depth * fade;
        l[k] *= (1.0f + m);
        r[k] *= (1.0f + m);
    }
}

/* ------------------------------------------------------------------------- */
/* Randomness, seeded so every file is the same file                           */

uint32_t g_seed = 0x51ed270bu;

float rnd()
{
    g_seed ^= g_seed << 13;
    g_seed ^= g_seed >> 17;
    g_seed ^= g_seed << 5;
    return (float)(g_seed >> 8) / 16777216.0f;
}

float rnd_sym()
{
    return rnd() * 2.0f - 1.0f;
}

void euclid(int hits, int rot, bool out[STEPS])
{
    for (int i = 0; i < STEPS; i++) {
        out[i] = false;
    }
    if (hits <= 0) {
        return;
    }
    if (hits >= STEPS) {
        for (int i = 0; i < STEPS; i++) {
            out[i] = true;
        }
        return;
    }
    for (int i = 0; i < hits; i++) {
        int pos = (int)((float)i * (float)STEPS / (float)hits + 0.5f) % STEPS;
        pos = (pos + rot + STEPS) % STEPS;
        out[pos] = true;
    }
}

/* THE TIMBRE OF ONE HIT. The kit's recipe is the starting point; velocity, a slow motion
 * and a per-hit jitter move it. At TIMBRE 0 none of them do, and the hit is the recipe. */
role hit_role(const kit &k, int lane, float velocity, float timbre, float motion_pitch_st,
              float motion_decay, const knobs &kn, bool alternate)
{
    role r = alternate ? k.alt[lane] : k.voice[lane];

    /* A harder hit is brighter, a little longer and has more body under it. The velocity
     * coupling is the part that costs nothing and is heard most. */
    const float vel_pitch = timbre * 0.55f * (velocity - 0.7f);
    const float vel_decay = 1.0f + timbre * 0.30f * (velocity - 0.7f);
    const float vel_body = 1.0f + timbre * 0.55f * (velocity - 0.7f);

    /* A few cents and a few percent, per hit: the difference between a part and a table. */
    const float jit_pitch = timbre * 0.18f * rnd_sym();
    const float jit_decay = 1.0f + timbre * 0.05f * rnd_sym();
    const float jit_level = 1.0f + timbre * 0.06f * rnd_sym();

    const float st = kn.tone_st[lane] + motion_pitch_st + vel_pitch + jit_pitch;

    r.pitch_hz *= std::exp2(st / 12.0f);
    r.decay_ms *= kn.decay_mul[lane] * motion_decay * vel_decay * jit_decay;
    r.decay_ms = clampf(r.decay_ms, DECAY_MIN_MS, 1500.0f);
    r.body = clampf(r.body * kn.body_mul[lane] * vel_body, 0.0f, 1.0f);
    r.level = clampf(r.level * jit_level, 0.0f, 1.0f);
    r.pitch_hz = clampf(r.pitch_hz, 35.0f, 8000.0f);

    return r;
}

/* ------------------------------------------------------------------------- */
/* The part                                                                    */

void build_groove(const kit &k, const knobs &kn, std::vector<event> &out, int bar_len, int step,
                  int bars, unsigned mask)
{
    bool fig[LANE_COUNT][STEPS];
    for (int l = 0; l < LANE_COUNT; l++) {
        euclid(k.hits[l], 0, fig[l]);
    }

    for (int b = 0; b < bars; b++) {
        const bool cycle_end = ((b + 1) % k.cycle) == 0;
        const bool filled = cycle_end && (rnd() < kn.fill);

        /* The slow walk: per lane, per bar. At TIMBRE 0 it is zero, so nothing moves. */
        float motion_pitch[LANE_COUNT];
        float motion_decay[LANE_COUNT];
        for (int l = 0; l < LANE_COUNT; l++) {
            motion_pitch[l] = kn.timbre * 1.6f * rnd_sym();
            motion_decay[l] = 1.0f + kn.timbre * 0.12f * rnd_sym();
        }

        /* At the bar line a lane may be re-drawn: a new rotation, or one hit more or less. */
        if (b > 0) {
            for (int l = 0; l < LANE_COUNT; l++) {
                if (k.hits[l] <= 0) {
                    continue;
                }
                if (rnd() < kn.variation * 0.8f) {
                    const int rot = (int)(rnd() * 3.0f) - 1;
                    euclid(k.hits[l] + ((rnd() < 0.3f) ? 1 : 0), rot, fig[l]);
                }
            }
        }

        for (int s = 0; s < STEPS; s++) {
            int at = b * bar_len + s * step;
            if (s % 2 == 1) {
                at += (int)((float)step * kn.swing);
            }
            at += (int)((rnd() - 0.5f) * 0.0016f * (float)SAMPLE_RATE);

            const bool beat = (s % 4) == 0;
            const float accent = beat ? 1.0f : 0.70f;
            const float ghost_vel = 0.22f + 0.12f * rnd();

            if (filled && s >= 8) {
                out.push_back({ at, hit_role(k, LANE_SNARE, 0.35f + 0.045f * (float)(s - 8),
                                             kn.timbre, motion_pitch[LANE_SNARE],
                                             motion_decay[LANE_SNARE], kn, false),
                                0.35f + 0.045f * (float)(s - 8), 0.0f });
                continue;
            }

            for (int l = 0; l < LANE_COUNT; l++) {
                if (!fig[l][s] || (mask & (1u << l)) == 0u) {
                    continue;
                }
                /* The alternate voice: at TIMBRE 1 a lane can change voice, which is what
                 * makes a hat become an open hat and a snare become a rim. */
                const bool alt = (rnd() < kn.timbre * 0.22f) && l != LANE_KICK;
                const float metal = (l == LANE_HAT) ? k.hat_metal : 0.0f;
                out.push_back({ at, hit_role(k, l, accent, kn.timbre, motion_pitch[l],
                                             motion_decay[l], kn, alt),
                                accent, metal });
            }

            /* Ghosts: an empty step may still be touched, quietly. */
            const float ghost_p = (mask & (1u << LANE_HAT)) ? kn.variation * k.ghost : 0.0f;
            if (ghost_p > 0.0f && rnd() < ghost_p) {
                out.push_back({ at, hit_role(k, LANE_HAT, ghost_vel, kn.timbre,
                                             motion_pitch[LANE_HAT], 1.0f, kn, false),
                                ghost_vel, k.hat_metal });
            }
        }

        if (cycle_end && !filled) {
            out.push_back({ b * bar_len + 14 * step + (int)((float)step * kn.swing),
                            hit_role(k, LANE_HAT, 0.5f, kn.timbre, 0.0f, 1.0f, kn, true),
                            0.5f, k.hat_metal });
        }
    }
}

/* ------------------------------------------------------------------------- */
/* WAV                                                                         */

void write_wav(const std::string &path, const std::vector<float> &l, const std::vector<float> &r,
               float peak_target)
{
    float peak = 1.0e-9f;
    for (size_t i = 0; i < l.size(); i++) {
        peak = std::fmax(peak, std::fabs(l[i]));
        peak = std::fmax(peak, std::fabs(r[i]));
    }
    const float gain = peak_target / peak;

    const uint32_t frames = (uint32_t)l.size();
    const uint32_t data_bytes = frames * 4;
    FILE *f = std::fopen(path.c_str(), "wb");
    if (!f) {
        std::printf("не удалось открыть %s\n", path.c_str());
        return;
    }

    auto put32 = [&](uint32_t v) { std::fwrite(&v, 4, 1, f); };
    auto put16 = [&](uint16_t v) { std::fwrite(&v, 2, 1, f); };

    std::fwrite("RIFF", 1, 4, f);
    put32(36 + data_bytes);
    std::fwrite("WAVEfmt ", 1, 8, f);
    put32(16);
    put16(1);
    put16(2);
    put32((uint32_t)SAMPLE_RATE);
    put32((uint32_t)SAMPLE_RATE * 4);
    put16(4);
    put16(16);
    std::fwrite("data", 1, 4, f);
    put32(data_bytes);

    for (uint32_t i = 0; i < frames; i++) {
        for (int c = 0; c < 2; c++) {
            const float x = (c == 0 ? l[i] : r[i]) * gain;
            const float y = std::tanh(x * 1.1f) / std::tanh(1.1f);
            const int16_t s = (int16_t)std::lround(y * 32767.0f);
            std::fwrite(&s, 2, 1, f);
        }
    }
    std::fclose(f);
    std::printf("  %-46s %5.1f с  пик %+.1f дБ\n", path.c_str(),
                (float)frames / (float)SAMPLE_RATE, 20.0f * std::log10(peak * gain));
}

void render_groove(const kit &k, const knobs &kn, const std::string &path, int bars, float peak,
                   unsigned mask = 0x0Fu)
{
    const int step = (int)((60.0f / (float)BPM / 4.0f) * (float)SAMPLE_RATE + 0.5f);
    const int bar_len = step * STEPS;
    const int total = bar_len * bars + SAMPLE_RATE;

    std::vector<event> ev;
    build_groove(k, kn, ev, bar_len, step, bars, mask);

    std::vector<event> pitched, hats;
    for (const event &e : ev) {
        /* A hat is identified by its centre, not by a lane number, because the alternate of
         * the hat lane is the open hat and both take the metal. */
        if (e.metal > 0.0f) {
            hats.push_back(e);
        } else {
            pitched.push_back(e);
        }
    }

    std::vector<float> pl, pr, hl, hr;
    synth_perc_init((uint32_t)SAMPLE_RATE);
    render_pass(pitched, total, pl, pr);
    synth_perc_init((uint32_t)SAMPLE_RATE);
    render_pass(hats, total, hl, hr);

    for (const event &e : hats) {
        const int len = (int)((e.r.decay_ms > 120.0f ? 0.30f : 0.13f) * (float)SAMPLE_RATE);
        apply_metal(hl, hr, e.at, len, k.hat_metal);
    }

    for (int i = 0; i < total; i++) {
        hl[i] *= 0.5f;
        hr[i] *= 0.5f;
    }

    std::vector<float> l(total), r(total);
    for (int i = 0; i < total; i++) {
        l[i] = pl[i] + hl[i];
        r[i] = pr[i] + hr[i];
    }
    write_wav(path, l, r, peak);
}

knobs flat_knobs()
{
    knobs kn{};
    for (int l = 0; l < LANE_COUNT; l++) {
        kn.tone_st[l] = 0.0f;
        kn.decay_mul[l] = 1.0f;
        kn.body_mul[l] = 1.0f;
    }
    return kn;
}

/* One recipe, three hits at three velocities, out on its own: the way to hear a single drum
 * without the rest of the kit deciding for it. */
void render_hits(const role &r, const std::string &path, int total)
{
    std::vector<event> ev;
    const int start = (int)(0.05f * (float)SAMPLE_RATE);
    const float vels[3] = { 1.0f, 0.55f, 0.8f };
    for (int k = 0; k < 3; k++) {
        ev.push_back({ start + k * (int)(0.55f * (float)SAMPLE_RATE), r, vels[k], 0.0f });
    }
    synth_perc_init((uint32_t)SAMPLE_RATE);
    std::vector<float> l, r2;
    render_pass(ev, total, l, r2);
    write_wav(path, l, r2, 0.62f);
}

}  // namespace

int main(int argc, char **argv)
{
    host_platform_init();
    synth_perc_init((uint32_t)SAMPLE_RATE);

    const std::string dir = (argc > 1) ? argv[1] : "build/perc-kit";

    /* 0. THE KICK ALONE, BEFORE AND AFTER: the recipe this kit has had (55 Hz, 320 ms, body
     * 0.85) against the one it is being given (41 Hz, 480 ms, body 0.95), and then the same
     * drum on the figure it plays in the kit. */
    {
        const role old_kick = { 55.0f, 320.0f, 3.0f, 0.85f, 1.00f };
        const role new_kick = { 41.0f, 480.0f, 3.6f, 0.95f, 1.00f };
        const role sub_kick = { 35.0f, 640.0f, 4.2f, 1.00f, 1.00f };
        render_hits(old_kick, dir + "/perc-kick-old.wav", (int)(3.4f * (float)SAMPLE_RATE));
        render_hits(new_kick, dir + "/perc-kick-new.wav", (int)(3.4f * (float)SAMPLE_RATE));
        render_hits(sub_kick, dir + "/perc-kick-sub.wav", (int)(3.4f * (float)SAMPLE_RATE));
    }

    /* 1. THE SAME KIT AND FIGURES, WITH THE TIMBRE KNOB AT THREE POSITIONS. The first file is
     * the dead one: every hit identical, which is what the complaint was about. */
    {
        knobs kn = flat_knobs();
        kn.variation = 0.15f;
        kn.fill = 0.5f;
        kn.swing = 0.14f;
        kn.timbre = 0.0f;
        render_groove(KIT_MINI, kn, dir + "/perc-timbre-off.wav", BARS, 0.62f);
    }
    {
        knobs kn = flat_knobs();
        kn.variation = 0.15f;
        kn.fill = 0.5f;
        kn.swing = 0.14f;
        kn.timbre = 0.5f;
        render_groove(KIT_MINI, kn, dir + "/perc-timbre-mid.wav", BARS, 0.62f);
    }
    {
        knobs kn = flat_knobs();
        kn.variation = 0.15f;
        kn.fill = 0.5f;
        kn.swing = 0.14f;
        kn.timbre = 1.0f;
        render_groove(KIT_MINI, kn, dir + "/perc-timbre-full.wav", BARS, 0.62f);
    }

    /* 2. ONE LANE AT A TIME, so that the timbre knob is heard against itself: the same
     * figure of the same drum, dead and alive. */
    {
        for (int pass = 0; pass < 2; pass++) {
            knobs kn = flat_knobs();
            kn.variation = 0.0f;
            kn.fill = 0.0f;
            kn.swing = 0.14f;
            kn.timbre = pass ? 1.0f : 0.0f;
            const std::string tag = pass ? "-full" : "-off";
            render_groove(KIT_MINI, kn, dir + "/perc-lane-snare" + tag + ".wav", 4, 0.62f,
                          1u << LANE_SNARE);
            render_groove(KIT_MINI, kn, dir + "/perc-lane-hat" + tag + ".wav", 4, 0.62f,
                          1u << LANE_HAT);
        }
    }

    /* 3. THE LANE KNOBS MOVING. The kick's gate shortens across the file, the hat's tone
     * falls a fourth: the same kit, played by the controls. */
    {
        for (int b = 0; b < BARS; b += 4) {
            knobs kn = flat_knobs();
            kn.variation = 0.10f;
            kn.fill = 0.4f;
            kn.swing = 0.14f;
            kn.timbre = 0.35f;
            const int stage = b / 4;                      /* 0, 1, 2 */
            kn.decay_mul[LANE_KICK] = 1.0f - 0.28f * (float)stage;
            kn.tone_st[LANE_HAT] = -5.0f * (float)stage;
            kn.body_mul[LANE_KICK] = 1.0f + 0.12f * (float)stage;
            const std::string name = dir + "/perc-timbre-knobs-" + std::to_string(stage) + ".wav";
            render_groove(KIT_MINI, kn, name, 4, 0.62f);
        }
    }

    return 0;
}
