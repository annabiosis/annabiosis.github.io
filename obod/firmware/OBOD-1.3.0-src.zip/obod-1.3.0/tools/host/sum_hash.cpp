/*
 * КОНТРОЛЬНАЯ СУММА ВЫХОДА СТОЙКИ.
 *
 * Нужна, чтобы менять горячий цикл суммы и видеть, что звук не поехал: одинаковые слои,
 * одинаковые посылы, одинаковый дакинг — и число на выходе. Сравниваются два прогона:
 * до правки и после. Разница в последнем разряде — это другой порядок сложений, и её
 * видно числом, а не на слух.
 *
 *   sum_hash.exe > before.txt
 *   ...правка...
 *   sum_hash.exe > after.txt
 *   fc before.txt after.txt   (или глазами: строки одинаковы)
 */
#include <math.h>
#include <time.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "synth_dsp.h"
#include "platform.h"

#define BLOCK SYNTH_BLOCK_SAMPLES

int main(void)
{
    host_platform_init();
    synth_dsp_init(SYNTH_SAMPLE_RATE);
    synth_rack_boot_arm();
    synth_rack_set_gate(1.0f);
    synth_rack_set_transport(1.0f);
    synth_rack_set_master(0.8f);
    synth_rack_set_duck(0.5f);
    synth_rack_set_duck_rel(0.4f);

    /* Все слои живые, у каждого свой уровень и свои посылы: так в цикле суммы работает
     * каждый путь — и сухой, и три посыла. */
    for (int k = 0; k < SYNTH_NUM_LAYERS; k++) {
        synth_rack_set_layer_level(k, 0.20f + 0.05f * (float)k);
        synth_rack_set_reverb_send(k, 0.10f + 0.03f * (float)k);
        synth_rack_set_chorus_send(k, 0.06f + 0.02f * (float)k);
        synth_rack_set_delay_send(k, 0.08f + 0.04f * (float)k);
    }

    synth_rack_set_delay(9000.0f, 0.35f, 0.25f, false);
    synth_rack_set_chorus(0.4f, 0.5f, 0.3f);
    synth_rack_set_reverb(0.6f, 0.5f, 0.35f, 1);

    static int16_t out[BLOCK * 2];
    const clock_t t_start = clock();
    double acc = 0.0;
    double peak = 0.0;

    for (int b = 0; b < 400; b++) {
        synth_layers_clear(BLOCK);

        for (int k = 0; k < SYNTH_NUM_LAYERS; k++) {
            float *l = synth_layer_l(k);
            float *r = synth_layer_r(k);
            const float inc = (60.0f + 37.0f * (float)k) / (float)SYNTH_SAMPLE_RATE;

            for (int i = 0; i < BLOCK; i++) {
                const float ph = (float)((b * BLOCK + i) % 4800) / 4800.0f;
                const float v = 0.12f * sinf(ph * 6.2831853f * (1.0f + inc * 100.0f));

                l[i] = v;
                r[i] = v * (1.0f - 0.1f * (float)k);
            }
        }

        if ((b % 8) == 0) {
            synth_perc_trigger(0.9f, 1.0f);
        }

        float pl[BLOCK];
        float pr[BLOCK];
        float srev[BLOCK];
        float schl[BLOCK];
        float schr[BLOCK];
        float sdll[BLOCK];
        float sdlr[BLOCK];

        synth_perc_process(BLOCK, pl, pr, srev, 0.3f, schl, schr, 0.2f, sdll, sdlr, 0.2f);
        synth_dsp_set_perc_env(synth_perc_env());

        synth_rack_process(BLOCK, out);

        for (int i = 0; i < BLOCK * 2; i++) {
            const double v = (double)out[i];
            acc += v * v;
            if (fabs(v) > peak) {
                peak = fabs(v);
            }
        }
    }

    const double ms = 1000.0 * (double)(clock() - t_start) / (double)CLOCKS_PER_SEC;

    printf("время на 400 блоков %.1f мс, на блок %.3f мс\n", ms, ms / 400.0);
    printf("энергия %.6f\n", acc);
    printf("пик %.6f\n", peak);

    /* Хеш последних блоков — по нему видно, если поехал порядок сложений. */
    uint32_t h = 2166136261u;

    for (int b = 396; b < 400; b++) {
        for (int i = 0; i < BLOCK * 2; i++) {
            const float v = (float)out[i];
            uint32_t bits;
            memcpy(&bits, &v, sizeof(bits));
            h = (h ^ bits) * 16777619u;
        }
    }
    printf("хеш %08x\n", (unsigned)h);
    return 0;
}
