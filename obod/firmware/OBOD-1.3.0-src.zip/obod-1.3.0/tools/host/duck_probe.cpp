/*
 * ДАКИНГ: ХРУСТ ОТ ВЫСОКИХ ЗНАЧЕНИЙ.
 *
 * Владелец: «высокие значения дакинга приводят к слышимым помехам, похожим на хруст или
 * перегрузку». Гипотеза: компенсация дакинга (makeup) считалась раз в блок и умножалась на
 * сэмплы как постоянная, а на атаке в 12 мс она проходит весь путь за два-три блока — то есть
 * усиление всего микса скачет ступенями по 187 Гц. Плюс компенсация поднимает микс на 1.7 дБ
 * поверх того, что уже стоит на пороге мягкого клиппера.
 *
 * Стенд играет ровный тон на всех слоях, бьёт бочкой и меряет две вещи:
 *   - пик выхода и число сэмплов выше порога клиппера (перегрузка);
 *   - скачок на границе блока против скачка внутри блока (ступеньки по 187 Гц).
 *
 *   duck_probe.exe           дакинг 1.0
 *   duck_probe.exe 0.3       дакинг 0.3
 */
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "synth_dsp.h"
#include "platform.h"

#define BLOCK SYNTH_BLOCK_SAMPLES

int main(int argc, char **argv)
{
    const float duck = (argc > 1) ? (float)atof(argv[1]) : 1.0f;

    host_platform_init();
    synth_dsp_init(SYNTH_SAMPLE_RATE);
    synth_perc_init(SYNTH_SAMPLE_RATE);

    synth_rack_set_duck(duck);
    synth_rack_set_duck_rel(0.35f);
    synth_rack_set_master(0.8f);
    synth_rack_boot_arm();   /* без этого мастер стоит на нуле: заслонка загрузки */

    /* Ударная: без своих ручек она молчит, а молчащая ударная не качает дакинг. */
    synth_perc_set(0.45f, 0.40f, 0.55f, 0.50f, 1.0f, 0.50f, 0.50f, 0.00f);
    synth_rack_set_perc_send(0.0f);
    synth_rack_set_gate(1.0f);
    synth_rack_set_transport(1.0f);

    for (int k = 0; k < SYNTH_NUM_LAYERS; k++) {
        synth_rack_set_layer_level(k, 0.30f);
        synth_rack_set_reverb_send(k, 0.0f);
        synth_rack_set_chorus_send(k, 0.0f);
        synth_rack_set_delay_send(k, 0.0f);
    }

    /* Ровный тон на всех слоях: дакинг на нём виден как изменение усиления. */
    static int16_t out[BLOCK * 2];
    double worst_boundary = 0.0;
    double worst_inside = 0.0;
    int over_knee = 0;
    int over_full = 0;
    double peak = 0.0;
    int prev_sample = 0;
    int sample_index = 0;

    float phase = 0.0f;
    const float inc = 110.0f / (float)SYNTH_SAMPLE_RATE;

    /* Двенадцать блоков на удар: на 120 BPM шестнадцатая — это 46.9 блока, так что удары
     * редкие и дакинг успевает и открыться, и отпустить. */
    for (int b = 0; b < 1200; b++) {
        synth_layers_clear(BLOCK);

        for (int k = 0; k < SYNTH_NUM_LAYERS; k++) {
            float *l = synth_layer_l(k);
            float *r = synth_layer_r(k);
            float ph = phase;

            for (int i = 0; i < BLOCK; i++) {
                const float v = 0.06f * sinf(ph * 6.2831853f);
                l[i] = v;
                r[i] = v;
                ph += inc;
                if (ph >= 1.0f) {
                    ph -= 1.0f;
                }
            }
        }

        phase += inc * (float)BLOCK;
        while (phase >= 1.0f) {
            phase -= 1.0f;
        }

        if ((b % 47) == 0) {
            synth_perc_trigger(1.0f, 1.0f);
        }

        float pl[BLOCK];
        float pr[BLOCK];
        float srev[BLOCK];
        float schl[BLOCK];
        float schr[BLOCK];
        float sdll[BLOCK];
        float sdlr[BLOCK];

        synth_perc_process(BLOCK, pl, pr, srev, 0.0f, schl, schr, 0.0f, sdll, sdlr, 0.0f);
        synth_dsp_set_perc_env(synth_perc_env());

        synth_rack_process(BLOCK, out);

        double block_peak = 0.0;

        for (int i = 0; i < BLOCK * 2; i++) {
            const double v = (double)out[i] * (1.0 / 32768.0);
            const int left = (i & 1) == 0;

            if (left && fabs(v) > block_peak) {
                block_peak = fabs(v);
            }
            const double a = fabs(v);

            if (a > peak) {
                peak = a;
            }
            if (a > 0.80) {
                over_knee++;
            }
            if (a > 1.0) {
                over_full++;
            }

            /* Скачок между соседними сэмплами: на границе блока он и есть ступенька
             * усиления, внутри блока — обычная производная тона. */
            if (sample_index > 0) {
                const double d = fabs(v - prev_sample);

                if ((sample_index & 1) == 0) {
                    if (d > worst_boundary) {
                        worst_boundary = d;
                    }
                } else if (d > worst_inside) {
                    worst_inside = d;
                }
            }

            prev_sample = (int)v;
            sample_index++;
        }

        sample_index = 0;   /* каждый блок начинается с границы */

        if (b >= 44 && b <= 56) {
            printf("  блок %2d: пик %.5f%s\n", b, block_peak,
                   ((b % 47) == 0) ? "   <- удар" : "");
        }
    }

    printf("дакинг %.2f: пик %.3f, выше порога клиппера %d сэмплов, выше полной шкалы %d\n",
           (double)duck, peak, over_knee, over_full);
    printf("худший скачок на границе блока %.5f, внутри блока %.5f (отношение %.1f)\n",
           worst_boundary, worst_inside,
           (worst_inside > 1e-9) ? (worst_boundary / worst_inside) : 0.0);
    return 0;
}
