"""Проверка фигур LFO: все восемь форм SHAPE должны быть видны, а пять волн — ещё и
стоять на своём месте.

Зачем. У фигуры модуляции было восемь значений, а обход формы шёл через таблицу волн
осциллятора с другими номерами: SQUARE рисовался пилой, SAW — меандром, RANDOM и MIC
ложились в нулевую линию, EXP+ шёл шумом, EXP- не рисовался вовсе. На экране это
выглядело так, что графика экспоненциальных форм пропала. Ни одна проверка этого не
видела: фигуры рисуются в буфер маски, и в снимках экранов их нет — предпросмотр виден
только пока крутят ручку.

Что здесь проверяется. Числа, которые ложатся в буфер маски: высоты семи волн
(pv_sweep) и микрофонной огибающей (pv_lfo). У волн проверяется ещё и место — поле,
середина, столбец разрыва, решётка случайной фигуры и зеркальность конвертов, потому что
именно эти свойства владелец принимал по картинке: «вертикальные линии строго
вертикальны», «частота растёт из центра», «ступени на сетке», «ENV+ — зеркало ENV-».

Почему это зеркало, а не сборка кода. Таблицы PV_CSIN, PV_COS, PV_SIN и
PV_MIC_ENV читаются из самого synth_ui_preview.c, поле и середина — из enum внутри
pv_sweep(), поэтому данные разойтись не могут. Формулы повторены здесь второй раз — так
же, как random-model.js повторяет правила броска из synth_app.cpp, — и если pv_sweep()
изменится, эту проверку придётся поправить вместе с ней. Сторож, который молча отстал
от кода, хуже отсутствия сторожа, поэтому в каждом случае ниже назван источник.

Запуск: python tools/lfo-shapes.py
"""

import math
import re
import sys

sys.stdout.reconfigure(encoding='utf-8')

SOURCE = 'components/synth_ui/src/synth_ui_preview.c'
SYNTH = 'components/synth_app/src/synth_app.cpp'

FIELD = re.compile(r'#define\s+PV_FX0\s+(\d+)\s*\n#define\s+PV_FX1\s+(\d+)')
FIELD_Y = re.compile(r'#define\s+PV_FY0\s+(\d+)\s*\n#define\s+PV_FY1\s+(\d+)')

# Поле волны: enum в начале pv_sweep().
SWEEP_ENUM = re.compile(
    r'static void pv_sweep\(uint8_t \*m, const pv_vals_t \*v\)\s*\{\s*'
    r'enum \{([^}]*)\};')
# Обрезка штриха по полю фигуры: блоки вне 44 x 44 не рисуются.
AREA = re.compile(r'#define\s+PV_AREA_([XY][01])\s+(\d+)')

W = H = 56


def read_table(text, name):
    match = re.search(r'static const int\d+_t %s\[\d+\] = \{([^}]*)\}' % name, text)
    if not match:
        raise SystemExit('FAIL: нет таблицы %s в %s' % (name, SOURCE))
    return [int(value) for value in match.group(1).replace('\n', ' ').split(',') if value.strip()]


def tab(table, position):
    """Линейная выборка между точками — так же, как pv_tab() в фигуре."""
    position = max(0.0, min(float(len(table) - 1), position))
    low = int(position)
    high = min(low + 1, len(table) - 1)
    return table[low] + (table[high] - table[low]) * (position - low)


def div_round(a, b):
    """Округление половины от нуля — pv_div_round() в synth_ui_preview.c."""
    return (a + b // 2) // b if a >= 0 else -((-a + b // 2) // b)


class Sweep:
    """Зеркало pv_sweep(): маска 56 x 56, поле 8..46, середина 27.

    Поле и амплитуда берутся из enum в самом pv_sweep(), ширина блока — из
    PV_AREA_*, таблицы — из файла. Формула отсчётов (32 / 64 / 128 на пол-оборота,
    оборот и два) повторена здесь: в прошивке она записана кодом, а не таблицей.
    """

    def __init__(self, text):
        match = SWEEP_ENUM.search(text)
        if not match:
            raise SystemExit('FAIL: не найден enum поля в pv_sweep() (%s)' % SOURCE)
        values = dict()
        for part in match.group(1).split(','):
            if '=' not in part:
                continue
            key, value = part.split('=')
            values[key.strip()] = int(value.strip())
        for key in ('FX', 'RIGHT', 'MID', 'AMP'):
            if key not in values:
                raise SystemExit('FAIL: в enum pv_sweep() нет %s' % key)
        self.fx = values['FX']
        self.right = values['RIGHT']
        self.mid = values['MID']
        self.amp = values['AMP']

        area = dict(AREA.findall(text))
        self.ax0, self.ax1 = int(area['X0']), int(area['X1'])
        self.ay0, self.ay1 = int(area['Y0']), int(area['Y1'])

        self.csin = read_table(text, 'PV_CSIN')
        self.ccos = read_table(text, 'PV_COS')
        self.cenv = read_table(text, 'PV_CENV')

    # --- штрих ---------------------------------------------------------------
    def _stamp(self, mask, x, y):
        for dy in (0, 1):
            for dx in (0, 1):
                xx, yy = x + dx, y + dy
                if 0 <= xx < W and 0 <= yy < H:
                    mask[yy][xx] = 1

    def _fine(self, mask, x0, y0, x1, y1):
        dx, dy = abs(x1 - x0), abs(y1 - y0)
        sx = 1 if x1 >= x0 else -1
        sy = 1 if y1 >= y0 else -1
        steps = max(dx, dy)
        if steps == 0:
            if self.ax0 <= x0 <= self.ax1 and self.ay0 <= y0 <= self.ay1:
                self._stamp(mask, x0, y0)
            return
        for i in range(steps + 1):
            x = x0 + sx * div_round(dx * i, steps)
            y = y0 + sy * div_round(dy * i, steps)
            if self.ax0 <= x <= self.ax1 and self.ay0 <= y <= self.ay1:
                self._stamp(mask, x, y)

    # --- хеш случайной фигуры -----------------------------------------------
    @staticmethod
    def rnd(seed, i):
        """pv_rnd(): те же 32 бита, что в прототипе и в прошивке."""
        x = (seed * 2654435761 + i * 40503 + 12345) & 0xFFFFFFFF
        x ^= x >> 13
        x = (x * 1274126177) & 0xFFFFFFFF
        x ^= x >> 16
        return x >> 8

    def _saw_y(self, k, samples, depth):
        """pv_saw_y(): спуск пилы, отсчитанный от середины."""
        m = (((2 * k - samples) % 128) + 128) % 128
        return self.mid - div_round(depth * (128 - 2 * m), 128)

    # --- фигура --------------------------------------------------------------
    def mask(self, depth_q, rate_q, shape, seed=1):
        """depth_q и rate_q — 0..50, как q[0] и q[1] в прошивке."""
        depth = div_round(depth_q * self.amp, 50)
        width = self.right - self.fx
        raw = 32 + rate_q * 32 // 25 if rate_q <= 25 else 64 + (rate_q - 25) * 64 // 25
        samples = ((raw + 3) // 4) * 4
        phase0 = 16 - samples // 2
        mask = [[0] * W for _ in range(H)]

        def x_of(k):
            return self.fx + div_round(width * k, samples)

        def at(k):
            return (phase0 + k) & 63

        def y_of(value):
            return self.mid - div_round(depth * value, 1000)

        if shape == 4:
            inner = [self.fx + 10, self.fx + 20, self.fx + 30]
            level = [self.fx, self.fx + 10, self.fx + 20, self.fx + 30, self.right]
            bands = 2 + (1 if rate_q >= 17 else 0) + (1 if rate_q >= 34 else 0)
            keyed = sorted(((self.rnd(seed, i), v) for i, v in enumerate(inner)))
            bounds = sorted(v for _, v in keyed[:bands - 1])
            levels = []
            for b in range(bands):
                h = self.rnd(seed, 10 + b)
                idx = ((h * 5) >> 24) % 5
                if b and idx == levels[b - 1]:
                    idx = (idx + 1) % 5
                levels.append(idx)
            y_at = lambda b: self.mid + div_round((level[levels[b]] - self.mid) * depth_q, 50)
            x0 = self.fx
            yprev = y_at(0)
            for b in range(bands):
                y = y_at(b)
                x1 = self.right if b == bands - 1 else bounds[b]
                self._fine(mask, x0, y, x1, y)
                if b:
                    self._fine(mask, x0, yprev, x0, y)
                x0, yprev = x1, y
            return mask, dict(bands=bands, bounds=bounds, levels=list(levels))

        if shape == 0:
            px, py = self.fx, y_of(self.csin[at(0)])
            for k in range(1, samples + 1):
                x, y = x_of(k), y_of(self.csin[at(k)])
                self._fine(mask, px, py, x, y)
                px, py = x, y
            return mask, dict(samples=samples)

        if shape == 1:
            px, py = self.fx, y_of(self.csin[at(0)])
            for m in range(-8, 9):
                k = samples // 2 + 32 * m
                if k <= 0 or k >= samples:
                    continue
                x = x_of(k)
                y = y_of(1000 if self.csin[at(k)] >= 0 else -1000)
                self._fine(mask, px, py, x, y)
                px, py = x, y
            self._fine(mask, px, py, self.right, y_of(self.csin[at(samples)]))
            return mask, dict(samples=samples)

        if shape == 2:
            first = min([k for k in (samples // 2 + 32 * m for m in range(-8, 9))
                         if 0 < k < samples] or [samples])
            lv = 1 if self.ccos[at(first // 2)] >= 0 else -1
            px, py = self.fx, self.mid - lv * depth
            for m in range(-8, 9):
                k = samples // 2 + 32 * m
                if k <= 0 or k >= samples:
                    continue
                x = x_of(k)
                self._fine(mask, px, py, x, py)
                lv = -lv
                y = self.mid - lv * depth
                self._fine(mask, x, py, x, y)
                px, py = x, y
            self._fine(mask, px, py, self.right, py)
            return mask, dict(samples=samples)

        if shape in (5, 6):
            # ENV: конверт на весь размах за оборот, скачок в центре картинки.
            # ENV+ — та же таблица PV_CENV, прочитанная с конца.
            reverse = shape == 5
            jumps = [k for k in (samples // 2 + 64 * m for m in range(-4, 5))
                     if 0 <= k <= samples]
            for k in jumps:
                x = x_of(k)
                self._fine(mask, x, self.mid - depth, x, self.mid + depth)
            cuts = sorted({0} | {j for j in jumps if 0 < j < samples} | {samples})
            walks = []
            for a, b in zip(cuts, cuts[1:]):
                if a == b:
                    walks.append([])
                    continue
                px = py = 0
                ys = []
                for s in range(17):
                    k = a + (b - a) * s // 16
                    ks = (samples - k) if reverse else k
                    ph = ((ks - samples // 2) % 64 + 64) % 64
                    j = max(0, min(32, div_round(ph * 32, 64)))
                    x = x_of(k)
                    y = self.mid - div_round(depth * self.cenv[j], 1000)
                    ys.append(y)
                    if s:
                        self._fine(mask, px, py, x, y)
                    px, py = x, y
                walks.append(ys)
            return mask, dict(samples=samples, jumps=jumps, walks=walks)

        jumps = [k for k in (samples // 2 + 64 * m for m in range(-4, 5))
                 if 0 <= k <= samples]
        for k in jumps:
            x = x_of(k)
            self._fine(mask, x, self.mid - depth, x, self.mid + depth)
        cuts = sorted(set([0] + jumps + [samples]))
        for a, b in zip(cuts, cuts[1:]):
            if a == b:
                continue
            ya = self.mid - depth if a in jumps else self._saw_y(a, samples, depth)
            yb = self.mid + depth if b in jumps else self._saw_y(b, samples, depth)
            self._fine(mask, x_of(a), ya, x_of(b), yb)
        return mask, dict(samples=samples, jumps=jumps)


def shape_values(shape, sin_table, mic, steps):
    """Высота фигуры на шаге 0..steps-1, -1..1; то же, что pv_lfo() считает для x.

    Источник каждой строки — switch в pv_lfo() и mod_wave() в synth_app.cpp.
    """
    if shape == 0:                                  # SINE
        return tab(sin_table, steps[1] * 16.0) * 0.01
    if shape == 1:                                  # TRI
        return 4.0 * abs(steps[1] - 0.5) - 1.0
    if shape == 2:                                  # SQUARE
        return 1.0 if steps[1] < 0.5 else -1.0
    if shape == 3:                                  # SAW
        return 1.0 - 2.0 * steps[1]
    if shape == 5:                                  # EXP+
        return -math.exp(-6.0 * (1.0 - steps[1]))
    if shape == 6:                                  # EXP-
        return -math.exp(-6.0 * steps[1])
    if shape == 7:                                  # MIC, 0..1, только вверх
        return tab(mic, steps[1] * 15.0) * 0.01
    raise SystemExit('FAIL: форма %d не разобрана проверкой' % shape)


def ink_cells(mask):
    return [(x, y) for y in range(H) for x in range(W) if mask[y][x]]


def rows_at(mask, x):
    return [y for y in range(H) if mask[y][x]]


def columns_at(mask, y):
    return [x for x in range(W) if mask[y][x]]


def main():
    text = open(SOURCE, encoding='utf-8').read()
    synth = open(SYNTH, encoding='utf-8').read()

    field = FIELD.search(text)
    field_y = FIELD_Y.search(text)
    if not field or not field_y:
        raise SystemExit('FAIL: не найдено поле фигуры в %s' % SOURCE)

    x0, x1 = int(field.group(1)), int(field.group(2))
    y0, y1 = int(field_y.group(1)), int(field_y.group(2))
    middle = (y0 + y1) // 2
    amp = (y1 - y0) // 2

    # Синус фигуры берётся из той таблицы, которой её рисует pv_sweep: оборот
    # на 64 отсчёта, тысячные. Здесь она сводится к 16 точкам на оборот, как
    # x100 — одна точка на 22,5 градуса, четыре отсчёта таблицы.
    csin = read_table(text, 'PV_CSIN')
    sin_table = [int(round(csin[(i * 4) % 64] / 10.0)) for i in range(16)]
    mic = read_table(text, 'PV_MIC_ENV')

    names = ['SINE', 'TRI', 'SQUARE', 'SAW', 'RANDOM', 'EXP+', 'EXP-', 'MIC']

    # Имена и порядок — из списка режимов LFO в synth_app.cpp, а не из головы:
    # если список переставят, проверка скажет об этом, а не проверит не то.
    match = re.search(r'"SINE",\s*"TRI",\s*"SQUARE",\s*"SAW",\s*"RANDOM",\s*"EXP\+",\s*"EXP-",\s*"MIC"', synth)
    if not match:
        raise SystemExit('FAIL: список форм LFO в %s не тот, что ждёт проверка' % SYNTH)

    problems = []
    print('форма    размах  доля поля  направление')

    # --- микрофонная огибающая: её по-прежнему рисует pv_lfo() ------------------
    for shape in (7,):
        heights = []
        for index in range(x1 - x0 + 1):
            phase = index / float(x1 - x0)
            heights.append(round(middle - shape_values(shape, sin_table, mic,
                                                       (phase, phase)) * amp))
        span = max(heights) - min(heights)
        share = span / float(2 * amp)
        lowest, highest = max(heights), min(heights)
        side = []
        if lowest > middle:
            side.append('вниз')
        if highest < middle:
            side.append('вверх')
        if not side:
            side.append('в обе стороны')
        print('%-8s %6d  %9.2f  %s' % (names[shape], span, share, ' и '.join(side)))
        if span < 4:
            problems.append('%s: размах %d точки — фигура ложится в линию' % (names[shape], span))
        if share > 1.02:
            problems.append('%s: размах больше поля (%.2f)' % (names[shape], share))
        if max(heights) > middle + 1:
            problems.append('%s: MIC заходит ниже центра, а огибающая идёт 0..1' % names[shape])

    # --- семь волн: их рисует pv_sweep() --------------------------------------
    sweep = Sweep(text)
    for shape in range(7):
        for rate_q in (0, 13, 25, 38, 50):
            mask, info = sweep.mask(50, rate_q, shape, seed=1000 + rate_q)
            cells = ink_cells(mask)
            if not cells:
                problems.append('%s (rate %d): фигура пустая' % (names[shape], rate_q))
                continue
            ys = [y for _, y in cells]
            span = max(ys) - min(ys)
            if rate_q == 25:
                side = 'в обе стороны'
                if min(ys) > sweep.mid + 1:
                    side = 'вниз'
                elif max(ys) < sweep.mid - 1:
                    side = 'вверх'
                print('%-8s %6d  %9.2f  %s'
                      % (names[shape], span - 1, (span - 1) / float(2 * sweep.amp), side))
            if span < sweep.amp - 2:
                problems.append('%s (rate %d): размах %d — фигура ложится в линию'
                                % (names[shape], rate_q, span))
            low, high = sweep.mid - sweep.amp, sweep.mid + sweep.amp + 1
            if min(ys) < low or max(ys) > high:
                problems.append('%s (rate %d): фигура вышла из поля (%d..%d)'
                                % (names[shape], rate_q, min(ys), max(ys)))

        # DEPTH 0 — одна средняя линия.
        zero, _ = sweep.mask(0, 25, shape, seed=1000)
        if sorted({y for _, y in ink_cells(zero)}) not in ([sweep.mid, sweep.mid + 1],):
            problems.append('%s: при DEPTH 0 фигура не легла в среднюю линию' % names[shape])

    # Центр: вершина синуса и треугольника, перепад меандра и скачок пилы стоят
    # на центральном столбце — это и значит «частота растёт из центра».
    centre = (sweep.mid, sweep.mid + 1)
    for shape in (0, 1):
        mask, _ = sweep.mask(50, 50, shape)
        cells = ink_cells(mask)
        top = min(y for _, y in cells)
        xs = sorted({x for x, y in cells if y == top})
        if not (centre[0] in xs or centre[1] in xs):
            problems.append('%s: вершина не на центральном столбце (%s)' % (names[shape], xs))

    for shape in (2, 3, 5, 6):
        mask, info = sweep.mask(50, 25, shape)      # один оборот — перепад в центре
        jump_rows = rows_at(mask, sweep.mid)
        near_rows = rows_at(mask, sweep.mid - 1)
        if len(jump_rows) < 2 * sweep.amp - 4:
            problems.append('%s: на центральном столбце нет перепада (%d строк)'
                            % (names[shape], len(jump_rows)))
        # У меандра и пилы соседний столбец — полка; у конверта там сама кривая,
        # которая у скачка крута, поэтому ширина перепада проверяется только у них.
        if shape in (2, 3) and len(near_rows) > 8:
            problems.append('%s: перепад шире двух пикселей — вертикаль наклонная'
                            % names[shape])
        jumps = info.get('jumps')
        if jumps is not None and info['samples'] // 2 not in jumps:
            problems.append('%s: скачок не в центре картинки' % names[shape])

    # Конверты: ENV+ — это ENV-, отражённый по горизонтали, а сам ENV- не
    # симметричен, иначе зеркало было бы неотличимо от исходного.
    def column_top(mask, x):
        rows = rows_at(mask, x)
        return min(rows) if rows else None

    for rate_q in (13, 25, 38, 50):
        down, info_down = sweep.mask(50, rate_q, 6)
        up, info_up = sweep.mask(50, rate_q, 5)
        down_segments = info_down['walks']
        up_segments = info_up['walks']
        if len(down_segments) != len(up_segments):
            problems.append('ENV (rate %d): у ENV- и ENV+ разное число сегментов'
                            % rate_q)
            continue
        far = 0
        for i, seg in enumerate(up_segments):
            mirror = list(reversed(down_segments[len(down_segments) - 1 - i]))
            for y_up, y_down in zip(seg, mirror):
                if abs(y_up - y_down) > 2:
                    far += 1
        if far > 2:
            problems.append('ENV (rate %d): ENV+ не зеркало ENV- (%d точек высоты)'
                            % (rate_q, far))
        left = column_top(down, sweep.mid - 5)
        right = column_top(down, sweep.mid + 5)
        if left is not None and right is not None and abs(right - left) < 6:
            problems.append('ENV (rate %d): конверт симметричен, зеркало неотличимо'
                            % rate_q)

    # Случайная: уровни и стыки стоят на решётке, зерно пересобирает расклад, а
    # глубина её не трогает — это три разных свойства одного рисунка.
    grid_rows = {sweep.fx, sweep.fx + 10, sweep.fx + 20, sweep.fx + 30, sweep.right}
    grid_cols = {sweep.fx + 10, sweep.fx + 20, sweep.fx + 30}
    for rate_q in (0, 13, 25, 38, 50):
        mask, info = sweep.mask(50, rate_q, 4, seed=1000 + rate_q)
        for x, y in ink_cells(mask):
            on_row = (y in grid_rows) or (y - 1 in grid_rows)
            on_col = (x in grid_cols) or (x - 1 in grid_cols)
            if not (on_row or on_col):
                problems.append('RANDOM (rate %d): ступень вне решётки в (%d,%d)'
                                % (rate_q, x, y))
                break
        if info['bands'] != 2 + (rate_q >= 17) + (rate_q >= 34):
            problems.append('RANDOM (rate %d): полок %d' % (rate_q, info['bands']))

    same = [sweep.mask(50, 25, 4, seed=1000)[0] == sweep.mask(50, 25, 4, seed=1000)[0]]
    other = [sweep.mask(50, 25, 4, seed=1000)[0] == sweep.mask(50, 25, 4, seed=1001)[0]]
    if not same[0]:
        problems.append('RANDOM: одно зерно даёт разные картинки')
    if other[0]:
        problems.append('RANDOM: другое зерно не пересобирает расклад')

    def structure(depth_q, seed=1000):
        mask, info = sweep.mask(depth_q, 25, 4, seed=seed)
        cols = sorted({x for x in range(W) if len(rows_at(mask, x)) > 12})
        return info['levels'], cols

    if structure(50) != structure(100):
        problems.append('RANDOM: расклад меняется от DEPTH, а должен только размах')

    # DEPTH двигает размах у каждой формы: это то, ради чего ручка стоит. Случайная
    # однажды перестала ему подчиняться — её ступени масштабировались темпом, — и
    # проверка, которая этого не видит, пропускает такую ошибку. Поэтому здесь
    # измеряется размах на двух глубинах, а не «поле не пустое».
    for shape in (0, 1, 2, 3, 4, 5, 6):
        spans = []
        for depth_q in (10, 50):
            mask, _ = sweep.mask(depth_q, 25, shape, seed=1000)
            ys = [y for _, y in ink_cells(mask)]
            spans.append(max(ys) - min(ys) if ys else 0)
        if not spans[1] > spans[0] > 0:
            problems.append('%s: размах не растёт от DEPTH (%d -> %d)'
                            % (names[shape], spans[0], spans[1]))

    if problems:
        print('FAIL: фигуры форм LFO разошлись с прототипом и с mod_wave()')
        for problem in problems:
            print('  - ' + problem)
        sys.exit(1)

    print('OK: все восемь форм LFO рисуются, поле, середина и решётка на месте, '
          'односторонние формы совпадают с mod_wave()')


if __name__ == '__main__':
    main()
