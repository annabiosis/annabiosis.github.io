"""DENSITY: шестнадцать колец в synth_ui_preview.c против образца владельца.

Читает таблицы из C, снова собирает кадры и держит четыре вещи:

  * на 100 % кадр совпадает с его файлом пиксель в пиксель, кольцо — его восемь байт;
  * колец ровно шестнадцать, шаг сетки десять, поле с третьего столбца;
  * число колец не уходит от процентов больше чем на одно и по ходу ручки только растёт,
    а пороги лежат по одному в каждом из шестнадцати отрезков хода;
  * выбор картинки, отрисовка, сдвиг и заголовок знают про фигуру.

Run: python tools/density-shape.py
"""
import re
import sys

from PIL import Image

sys.stdout.reconfigure(encoding="utf-8")

SRC = "components/synth_ui/src/synth_ui_preview.c"
HDR = "components/synth_ui/src/synth_ui_preview.h"
BASE = r"C:\Users\Blaq\.dsh\attachments\v1\objects"
HIS = "78856a5d93b58c7edd8c17eb224e32f3597483e19c14e92a60bc68ad53084459"
ART = 44
FAIL = []


def fail(msg):
    FAIL.append(msg)


def ok(msg):
    print("  " + msg)


src = open(SRC, encoding="utf-8", errors="replace").read()


def arr(name):
    m = re.search(r"%s\s*\[[^\]]*\]\s*=\s*\{([^}]*)\}" % name, src)
    if not m:
        fail("не нашёл таблицу %s" % name)
        return []
    return [int(v, 0) for v in re.findall(r"0[xX][0-9A-Fa-f]+|\d+", m.group(1))]


print("1. таблицы в прошивке")
m = re.search(r"#define\s+PV_DENSITY_CELLS\s+(\d+)", src)
CELLS = int(m.group(1)) if m else 0
DOT = arr("PV_DENSITY_DOT")
TOSS = arr("PV_DENSITY_TOSS")
if CELLS != 4:
    fail("сетка %d x %d, а образец четырёхклеточный" % (CELLS, CELLS))
if len(DOT) != 8:
    fail("в кольце %d строк вместо восьми" % len(DOT))
if DOT != [0x3C, 0x7E, 0xE7, 0xC3, 0xC3, 0xE7, 0x7E, 0x3C]:
    fail("кольцо не то: %s" % [hex(v) for v in DOT])
if len(TOSS) != CELLS * CELLS:
    fail("порогов %d вместо %d" % (len(TOSS), CELLS * CELLS))
if FAIL:
    for f in FAIL:
        print("ПРОВАЛ: " + f)
    sys.exit(1)
ok("%d клеток, кольцо %s, порогов %d" % (CELLS * CELLS, " ".join("%02X" % v for v in DOT), len(TOSS)))

# ---------------------------------------------------------------- модель из этих таблиц

X0, Y0, STEP, QMAX = 3, 3, 10, 50


def visible(q, cell):
    return TOSS[cell] < q


def count(q):
    return sum(1 for c in range(CELLS * CELLS) if visible(q, c))


def frame(q):
    g = [[0] * ART for _ in range(ART)]
    for row in range(CELLS):
        for col in range(CELLS):
            if not visible(q, row * CELLS + col):
                continue
            ox, oy = X0 + col * STEP, Y0 + row * STEP
            for y in range(8):
                for x in range(8):
                    if (DOT[y] >> (7 - x)) & 1:
                        g[oy + y][ox + x] = 1
    return g


def his():
    px = Image.open("%s\\%s\\%s" % (BASE, HIS[:2], HIS)).convert("L").load()
    return [[1 if px[x, y] > 110 else 0 for x in range(ART)] for y in range(ART)]


print("2. образец владельца, 100 %")
diff = [(x, y) for y in range(ART) for x in range(ART) if frame(QMAX)[y][x] != his()[y][x]]
if diff:
    fail("кадр на 100 %% расходится в %d пикселях, первые %s" % (len(diff), diff[:6]))
ok("на 100 %% совпадает с образцом, расхождений %d" % len(diff))

print("3. сетка")
g = frame(QMAX)
if count(QMAX) != CELLS * CELLS:
    fail("на 100 %% колец %d вместо %d" % (count(QMAX), CELLS * CELLS))
ring = [[g[Y0 + y][X0 + x] for x in range(8)] for y in range(8)]
if ring != [[(DOT[y] >> (7 - x)) & 1 for x in range(8)] for y in range(8)]:
    fail("первое кольцо стоит не в левом верхнем углу сетки")
want_cols = {X0 + i * STEP + k for i in range(CELLS) for k in range(8)}
got_cols = {x for x in range(ART) if any(g[y][x] for y in range(ART))}
got_rows = {y for y in range(ART) if any(g[y][x] for x in range(ART))}
if got_cols != want_cols or got_rows != want_cols:
    fail("чернила стоят не по сетке: столбцы %s, строки %s" % (sorted(got_cols), sorted(got_rows)))
if count(0) != 0:
    fail("на нуле остаётся %d колец — должно быть пусто")
ok("шестнадцать колец с шагом 10, поле с третьего столбца, на нуле пусто")

print("4. пороги и число колец")
if min(TOSS) != 0:
    fail("первый порог %d: на самом низу должно оставаться одно кольцо" % min(TOSS))
if max(TOSS) != QMAX - 1:
    fail("последний порог %d: на сотне должны стоять все шестнадцать" % max(TOSS))
if len(set(TOSS)) != len(TOSS):
    fail("пороги повторяются: %s" % TOSS)
counts = [count(q) for q in range(QMAX + 1)]
for q, n in enumerate(counts):
    want = (CELLS * CELLS) * q / float(QMAX)
    if abs(n - want) > 1.0:
        fail("на %d %%%% колец %d при ожидании %.1f" % (2 * q, n, want))
if any(b < a for a, b in zip(counts, counts[1:])):
    fail("число колец падает по ходу ручки: %s" % counts)
# каждый из шестнадцати равных отрезков хода — ровно один порог
width = (QMAX + 1) / float(CELLS * CELLS)
for i in range(CELLS * CELLS):
    lo, hi = i * width, (i + 1) * width
    inside = [t for t in TOSS if lo <= t < hi]
    if len(inside) != 1:
        fail("в отрезке %.1f..%.1f порогов %d, а не один" % (lo, hi, len(inside)))
ok("пороги по одному на шестнадцать отрезков; колец %s" %
   " ".join(str(counts[q]) for q in (0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50)))

print("5. подключение")
if not re.search(r"case SYNTH_PARAM_DENSITY:(?:(?!case ).)*?return PREVIEW_DENSITY;", src, re.S):
    fail("DENSITY не отдаёт PREVIEW_DENSITY")
if "case PREVIEW_DENSITY:   pv_density(mask, &v);   break;" not in src:
    fail("нет вызова pv_density в отрисовке")
block = src[src.index("static int pv_ox_for"):]
block = block[:block.index("static int pv_oy_for")]
if "case PREVIEW_DENSITY:" not in block:
    fail("PREVIEW_DENSITY не стоит в списке без смещения")
hdr = open(HDR, encoding="utf-8", errors="replace").read()
mm = re.search(r"PREVIEW_DENSITY,\s*/\*(.*?)\*/", hdr)
if not mm:
    fail("нет строки PREVIEW_DENSITY в заголовке")
elif "ring" not in mm.group(1):
    fail("заголовок не описывает кольца: %s" % mm.group(1).strip())
ok("выбор картинки, отрисовка, сдвиг и заголовок — в порядке")

print()
if FAIL:
    for f in FAIL:
        print("ПРОВАЛ: " + f)
    sys.exit(1)
print("DENSITY: всё сходится")
