"""Иконки DELAY MODE: прошивка против двух картинок владельца.

Обе иконки лежат в прошивке таблицами 44 x 6, а здесь — те же картинки побитно.
Гейт собирает таблицы прошивки обратно в маску, сравнивает с эталоном точка в точку
и проверяет, что сектор MODE выбирает катушку на TAPE и перекрёсток на XFADE.
"""
import io
import re
import sys

sys.stdout.reconfigure(encoding="utf-8")

SRC = io.open("components/synth_ui/src/synth_ui_preview.c", encoding="utf-8").read()
HDR = io.open("components/synth_ui/src/synth_ui_preview.h", encoding="utf-8").read()

problems = []

REF = {
    "TAPE":
        "0000000000000007fe00000003fffc000000fc03f000003e0007c0000780001e0000e00f0070001c01f80380038039c01c0070030c00e00e0030c00700c0030c00301c0030c0038180030c0018380030c001c300039c000c30001f8000c70000f0000e60ff000ff0661ff801ff866381c6381c66300cf300c66300cf300c66381c6381c661ff801ff8660ff000ff0670000f0000e30001f8000c300039c000c380030c001c180030c00181c0030c00380c0030c00300e0030c0070070030c00e0038039c01c001c01f8038000e00f0070000780001e00003e0007c00000fc03f0000003fffc00000007fe000000000000000",
    "CROSS":
        "00000000000200000000043800000001c1e000000078078000001e001e0000078000780001e00001e00078000007801e0c00001e0780c0000079e18c000001f818c000001f818c0000079e18c00001e0780c00007801e0c0001e060780000780601e0001e0c6007800780c6001e01e18c6000787818c60001e7818c60001e1e18c6000780780c6001e001e0c60078000780601e00001e06078000007801e0c00001e0780c0000079f18c000001fb18c000001fb18c0000079f18c00001e0780c00007801e0c0001e000780000780001e0001e00000780078000001e01e0000000783800000001c2000000000400000000000",
}

AREA_X0 = int(re.search(r"#define\s+PV_AREA_X0\s+(\d+)", SRC).group(1))
AREA_Y0 = int(re.search(r"#define\s+PV_AREA_Y0\s+(\d+)", SRC).group(1))


def table(name):
    m = re.search(r"PV_MODE_%s\[44 \* 6\]\s*=\s*\{(.*?)\n\};" % name, SRC, re.S)
    if not m:
        problems.append("нет таблицы PV_MODE_%s" % name)
        return None
    vals = [int(v, 16) for v in re.findall(r"0x([0-9A-Fa-f]{2})", m.group(1))]
    if len(vals) != 44 * 6:
        problems.append("PV_MODE_%s: байт %d, а нужно 264" % (name, len(vals)))
        return None
    return [vals[i:i + 6] for i in range(0, 44 * 6, 6)]


def art(name):
    rows = table(name)
    if rows is None:
        return None
    g = [[0] * 44 for _ in range(44)]
    for y in range(44):
        for b in range(6):
            for k in range(8):
                x = b * 8 + k
                if x < 44 and rows[y][b] & (0x80 >> k):
                    g[y][x] = 1
    return g


def unpack(hexstr):
    bits = "".join(format(b, "08b") for b in bytes.fromhex(hexstr))
    return [[1 if bits[y * 44 + x] == "1" else 0 for x in range(44)] for y in range(44)]


for name in ("TAPE", "CROSS"):
    want = unpack(REF[name])
    mine = art(name)
    if mine is None:
        continue
    diff = [(x, y) for y in range(44) for x in range(44) if mine[y][x] != want[y][x]]
    if diff:
        problems.append("иконка %s расходится с картинкой в %d точках, например %s"
                        % (name, len(diff), diff[:6]))
    ink = sum(map(sum, mine))
    if ink < 100:
        problems.append("иконка %s почти пустая: %d точек" % (name, ink))

# иконка стоит на маске целиком, значит сдвиг вида должен быть нулевым
ox = SRC[SRC.index("static int pv_ox_for"):]
ox = ox[:ox.index("\n}\n")]
if not re.search(r"case PREVIEW_DELAY_MODE:[^\n]*\n(?:[^\n]*\n)*?\s*return 0;", ox):
    problems.append("у PREVIEW_DELAY_MODE ненулевой сдвиг: иконка съедет с центра")

# выбор иконки по режиму
body = SRC[SRC.index("static void pv_delay_mode"):]
body = body[:body.index("\n}\n")]
if "v->q[0] == 0" not in body or "PV_MODE_TAPE" not in body or "PV_MODE_CROSS" not in body:
    problems.append("pv_delay_mode не выбирает иконку по режиму")

# сектор MODE на месте и смотрит в свою фигуру
if "PREVIEW_DELAY_MODE" not in HDR:
    problems.append("нет вида PREVIEW_DELAY_MODE в заголовке")
if not re.search(r"case SYNTH_PARAM_DELAY_TIMEMODE:(?:(?!case ).)*?return PREVIEW_DELAY_MODE;", SRC, re.S):
    problems.append("MODE не отдаёт PREVIEW_DELAY_MODE")
if not re.search(r"case PREVIEW_DELAY_MODE:\s*pv_delay_mode\(", SRC):
    problems.append("нет вызова pv_delay_mode в переключателе")

if problems:
    print("FAIL: иконки DELAY MODE")
    for p in problems:
        print("  -", p)
    sys.exit(1)

print("OK: DELAY MODE — две иконки 44 x 44 в таблицах 44 x 6, катушка на TAPE и "
      "перекрёсток на XFADE, обе совпадают с картинками точка в точку; сектор MODE "
      "страницы DELAY больше ничего не рисует")
