"""Гейт фигуры REVERB DAMP: четыре кольца и их дуги против пяти кадров владельца.

Модель повторяет прошивку: те же квадраты радиусов, тот же ход u из четырёх четвертей,
те же углы начала и тот же тест сектора через два луча.
"""
import io
import math
import re
import sys

from PIL import Image

sys.stdout.reconfigure(encoding="utf-8")

SRC = io.open("components/synth_ui/src/synth_ui_preview.c", encoding="utf-8").read()
HDR = io.open("components/synth_ui/src/synth_ui_preview.h", encoding="utf-8").read()

BASE = r"C:\Users\Blaq\.dsh\attachments\v1\objects"
FRAMES = [
    "70/701b92d51ac970bb83e6bb028a741643c88c4db34e6548c0e35d876303aa7acb",
    "f0/f07265161e2a35f4e30e05c4e2f6786b551e0807e33451e04e8744d643c2c36a",
    "79/7989f42fd3c7593f6f1ab612c85c8d24776da8141fafe8ae407bb499f3d59734",
    "03/038adabb7579f71bdaa448ddb030dc86c471bd32e8fe4dff3d334aff26db77cf",
    "e3/e3969c705c4686432904fa4005b9409d927b6d81d84a71e22e8db5f11bcd748e",
]
TOLERANCE = 12

problems = []

# --- разбор прошивки ---------------------------------------------------------
m = re.search(r"PV_DAMP_EDGE\[4\]\[2\]\s*=\s*\{(.*?)\};", SRC, re.S)
if not m:
    problems.append("нет таблицы PV_DAMP_EDGE")
    EDGE = [(42, 38), (30, 26), (18, 14), (6, 2)]
else:
    EDGE = [tuple(int(v) for v in pair) for pair in
            re.findall(r"\{\s*(\d+)\s*,\s*(\d+)\s*\}", m.group(1))]
    if EDGE != [(42, 38), (30, 26), (18, 14), (6, 2)]:
        problems.append("радиусы колец не те: %s" % (EDGE,))

m = re.search(r"PV_DAMP_START\[4\]\s*=\s*\{([^}]*)\};", SRC)
if not m:
    problems.append("нет таблицы PV_DAMP_START")
    START = [0, 0, 180, 0]
else:
    START = [int(v) for v in re.findall(r"-?\d+", m.group(1))]
    if START != [0, 0, 180, 0]:
        problems.append("углы начала колец не те: %s" % (START,))

if "4.0f / 50.0f" not in SRC:
    problems.append("ход фигуры больше не четыре четверти на весь knob")

# --- модель ------------------------------------------------------------------
def clamp01(x):
    return 0.0 if x < 0.0 else (1.0 if x > 1.0 else x)


def sector_has(dx, dy, start, sweep):
    if sweep <= 0.5:
        return False
    if sweep >= 359.5:
        return True
    negate = sweep > 180.0
    a = start + sweep if negate else start
    b = start + 360.0 if negate else start + sweep
    k = math.pi / 180.0
    inside = (math.cos(a * k) * dy - math.sin(a * k) * dx >= 0.0 and
              math.cos(b * k) * dy - math.sin(b * k) * dx <= 0.0)
    return (not inside) if negate else inside


def frame(q):
    u = q * 4.0 / 50.0
    sweeps = [360.0]
    for k in range(1, 4):
        sweeps.append(180.0 * (clamp01(u - (k - 1)) + clamp01(u - k)))
    m = [[0] * 44 for _ in range(44)]
    for y in range(44):
        for x in range(44):
            dx = 2.0 * x - 43.0
            dy = 43.0 - 2.0 * y
            d2 = dx * dx + dy * dy
            for k in range(4):
                ro, ri = EDGE[k]
                if d2 > ro * ro or d2 < ri * ri:
                    continue
                if sector_has(dx, dy, START[k], sweeps[k]):
                    m[y][x] = 1
                    break
    return m


def his(key):
    im = Image.open(BASE + "\\" + key.replace("/", "\\")).convert("L")
    return [[1 if im.getpixel((x, y)) > 128 else 0 for x in range(44)] for y in range(44)]


for n, key in enumerate(FRAMES):
    want = his(key)
    mine = frame(n * 50.0 / 4.0)
    diff = [(x, y) for y in range(44) for x in range(44) if mine[y][x] != want[y][x]]
    if len(diff) > TOLERANCE:
        problems.append("кадр %d расходится с картинкой в %d точках (предел %d), например %s"
                        % (n + 1, len(diff), TOLERANCE, diff[:8]))
    ink = sum(map(sum, mine))
    if ink < 200:
        problems.append("кадр %d почти пустой: %d точек" % (n + 1, ink))

# плотность обязана только расти, а ступени стоять на своих местах
prev = -1
for q in range(0, 51, 5):
    ink = sum(map(sum, frame(float(q))))
    if ink < prev:
        problems.append("с ростом DAMP фигура беднеет: %d после %d" % (ink, prev))
    prev = ink

# --- привязка к сектору ------------------------------------------------------
if "PREVIEW_VERB_DAMP" not in HDR:
    problems.append("нет вида PREVIEW_VERB_DAMP в заголовке")
if not re.search(r"case SYNTH_PARAM_VERB_DAMP:(?:(?!case ).)*?return PREVIEW_VERB_DAMP;",
                 SRC, re.S):
    problems.append("DAMP не отдаёт PREVIEW_VERB_DAMP")
if not re.search(r"case PREVIEW_VERB_DAMP:\s*pv_verb_damp\(", SRC):
    problems.append("нет вызова pv_verb_damp в переключателе")

# и стоит по центру: сдвиг вида нулевой, поле симметрично
ox = SRC[SRC.index("static int pv_ox_for"):]
ox = ox[:ox.index("\n}\n")]
if not re.search(r"case PREVIEW_VERB_DAMP:[^\n]*\n(?:[^\n]*\n)*?\s*return 0;", ox):
    problems.append("у PREVIEW_VERB_DAMP ненулевой сдвиг: кольца съедут с центра")

outer = frame(0.0)
xs = [x for x in range(44) if any(outer[y][x] for y in range(44))]
ys = [y for y in range(44) if any(outer[y])]
if min(xs) != min(ys) or 43 - max(xs) != 43 - max(ys):
    problems.append("внешнее кольцо стоит не по центру: поля %d/%d и %d/%d"
                    % (min(xs), 43 - max(xs), min(ys), 43 - max(ys)))

if problems:
    print("FAIL: фигура REVERB DAMP")
    for p in problems:
        print("  -", p)
    sys.exit(1)

print("OK: REVERB DAMP — четыре кольца 21/15/9/3, три внутренних приходят изнутри "
      "четвертями по половине оборота, пять ступеней сходятся с кадрами владельца "
      "(предел %d точки), плотность только растёт, кольца по центру, сдвиг нулевой"
      % TOLERANCE)
