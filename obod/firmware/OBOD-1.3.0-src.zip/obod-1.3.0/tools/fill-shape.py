"""Фигура FILL: что рисует прошивка против его образца и против самой себя по ходу ручки.

Снято с его файла 1:1: шестнадцать клеток сеткой 4 x 4 с шагом десять, коробка глифа 6 x 6,
квадраты 2 x 2, 4 x 4 и 6 x 6 по центру коробки. Заполнение идёт с последней клетки назад по
порядку чтения, каждый шаг ручки поднимает на одну ступень одну клетку за фронтом — впереди
стоит лесенка из трёх размеров.
"""
import io
import re
import sys

sys.stdout.reconfigure(encoding="utf-8")

SRC = io.open("components/synth_ui/src/synth_ui_preview.c", encoding="utf-8").read()
HDR = io.open("components/synth_ui/src/synth_ui_preview.h", encoding="utf-8").read()

problems = []

FIELD = 44
HIS_Q = 31
HIS = (
    "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003f0000000783f00000c0783f00000c0783f0000000783f0000000003f0000000000000000000000000000000000000000000000fc3f0fc3f00fc3f0fc3f00fc3f0fc3f00fc3f0fc3f00fc3f0fc3f00fc3f0fc3f0000000000000000000000000000000000000000000000fc3f0fc3f00fc3f0fc3f00fc3f0fc3f00fc3f0fc3f00fc3f0fc3f00fc3f0fc3f000000000000000000000000000000000000000000000"
)


def const(name, text=SRC):
    m = re.search(r"#define\s+%s\s+\(?(-?\d+)" % name, text)
    if not m:
        problems.append("нет константы %s" % name)
        return 0
    return int(m.group(1))


CELL = const("PV_FI_CELL")
ORIGIN = const("PV_FI_ORIGIN")
BOX = const("PV_FI_BOX")
LEVELS = const("PV_FI_LEVELS")
CELLS = const("PV_FI_CELLS")

if (CELL, ORIGIN, BOX, LEVELS, CELLS) != (10, 4, 6, 3, 16):
    problems.append("константы сетки не те: %s" % ((CELL, ORIGIN, BOX, LEVELS, CELLS),))

UNITS = CELLS + LEVELS - 1


def units_of(q):
    """Та же арифметика, что в pv_fill: (q * 18 + 25) / 50."""
    return (q * UNITS + 25) // 50


def levels(q):
    """Ступень каждой клетки по порядку заполнения, с нуля — последняя клетка."""
    u = units_of(q)
    out = []
    for k in range(CELLS):
        level = u - k
        if level <= 0:
            out.extend([0] * (CELLS - k))
            break
        out.append(LEVELS if level > LEVELS else level)
    return out


def frame(q):
    g = [[0] * FIELD for _ in range(FIELD)]
    for k, level in enumerate(levels(q)):
        if level == 0:
            continue
        s = CELLS - 1 - k
        side = 2 * level
        off = (BOX - side) // 2
        x0 = ORIGIN + (s % 4) * CELL + off
        y0 = ORIGIN + (s // 4) * CELL + off
        for y in range(y0, y0 + side):
            for x in range(x0, x0 + side):
                g[y][x] = 1
    return g


def unpack(hexstr):
    bits = "".join(format(b, "08b") for b in bytes.fromhex(hexstr))[:FIELD * FIELD]
    return [[1 if bits[y * FIELD + x] == "1" else 0 for x in range(FIELD)]
            for y in range(FIELD)]


# --- 1. его образец -----------------------------------------------------------
his = unpack(HIS)
mine = frame(HIS_Q)
diff = [(x, y) for y in range(FIELD) for x in range(FIELD) if mine[y][x] != his[y][x]]
if diff:
    problems.append("его образец не сходится: %d точек, первая %s" % (len(diff), diff[0]))

# --- 2. ход ручки -------------------------------------------------------------
inks = []
frames = []
for q in range(0, 51):
    g = frame(q)
    frames.append(g)
    inks.append(sum(map(sum, g)))

if inks[0] != 0:
    problems.append("при нуле поле не пустое")
if inks[50] != CELLS * BOX * BOX:
    problems.append("в конце залито %d из %d" % (inks[50], CELLS * BOX * BOX))
for q in range(50):
    if inks[q + 1] < inks[q]:
        problems.append("на q=%d пятно уменьшилось" % q)
    if inks[q + 1] == inks[q] and units_of(q + 1) != units_of(q):
        problems.append("на q=%d единица прошла, а картинка та же" % q)

distinct = {repr(g) for g in frames}
if len(distinct) != UNITS + 1:
    problems.append("разных картинок %d, а единиц %d" % (len(distinct), UNITS))

# лесенка: очередь не пятится, частичные клетки стоят подряд у её конца, а целых ровно
# столько, сколько единиц прошло за вычетом двух ступеней разгона
for q in range(0, 51):
    lv = levels(q)
    units = units_of(q)
    if any(lv[i] < lv[i + 1] for i in range(CELLS - 1)):
        problems.append("на q=%d очередь не по порядку" % q)
    partial = [i for i, l in enumerate(lv) if 0 < l < LEVELS]
    if len(partial) > LEVELS - 1:
        problems.append("на q=%d частичных клеток %d" % (q, len(partial)))
    if partial and partial != list(range(partial[0], partial[0] + len(partial))):
        problems.append("на q=%d частичные клетки не подряд" % q)
    want_touched = min(CELLS, units)
    want_big = max(0, min(CELLS, units - (LEVELS - 1)))
    if sum(1 for l in lv if l > 0) != want_touched:
        problems.append("на q=%d тронуто %d клеток, а прошло %d единиц"
                        % (q, sum(1 for l in lv if l > 0), units))
    if sum(1 for l in lv if l == LEVELS) != want_big:
        problems.append("на q=%d целых клеток %d, а должно %d"
                        % (q, sum(1 for l in lv if l == LEVELS), want_big))

# --- 3. провод -----------------------------------------------------------------
DISPATCH = SRC[SRC.index("static synth_preview_kind_t pv_values"):]
DISPATCH = DISPATCH[:DISPATCH.index("\n}\n")]
LABELS, pending = {}, []
for mm in re.finditer(r"case (SYNTH_PARAM_\w+):|return (PREVIEW_\w+);", DISPATCH):
    if mm.group(1):
        pending.append(mm.group(1))
    else:
        for label in pending:
            LABELS.setdefault(label, mm.group(2))
        pending = []

if LABELS.get("SYNTH_PARAM_PERC_FILL") != "PREVIEW_FILL":
    problems.append("PERC_FILL отдаёт %s, а должен PREVIEW_FILL"
                    % LABELS.get("SYNTH_PARAM_PERC_FILL"))
if "PREVIEW_FILL" not in HDR:
    problems.append("нет вида PREVIEW_FILL в заголовке")
if not re.search(r"case PREVIEW_FILL:\s*pv_fill\(", SRC):
    problems.append("нет вызова pv_fill в переключателе")
ox = SRC[SRC.index("static int pv_ox_for"):SRC.index("static int pv_oy_for")]
if "case PREVIEW_FILL:" not in ox:
    problems.append("PREVIEW_FILL не в списке нулевого сдвига")
if not re.search(r"const int units = \(\(int\)v->q\[0\] \* PV_FI_UNITS \+ 25\) / 50;", SRC):
    problems.append("в pv_fill не та арифметика хода ручки")
if "const int s = PV_FI_CELLS - 1 - k;" not in SRC:
    problems.append("в pv_fill не видно обратного порядка чтения")

if problems:
    print("FAIL: фигура FILL")
    for p in problems:
        print("  -", p)
    sys.exit(1)

print("OK: FILL — шестнадцать клеток сеткой 4 x 4, коробка 6 x 6, квадраты 2 / 4 / 6 по центру; "
      "заливка идёт с последней клетки назад по порядку чтения волной из %d единиц, впереди "
      "лесенка не длиннее двух частичных; образец владельца совпадает точка в точку, при нуле "
      "поле пустое, в конце залито %d пикселей" % (UNITS, CELLS * BOX * BOX))
