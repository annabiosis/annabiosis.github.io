# Сборка страниц документации OBOD для сайта.
#
# Копирует web/ в папку obod репозитория сайта и переписывает то немногое, что
# отличается у копии от источника:
#
#   - ссылки на документы закрытого репозитория (../docs/*.md, ../tools/webflash/README.md)
#     становятся обычным текстом: на сайте этих файлов нет;
#   - отдельная страница схемы указывает на diagram.html, который на сайте лежит рядом;
#   - манифест прошивки, образ и список изменений берутся из папки страницы:
#     manifest.json, firmware/OBOD.bin и changelog.json;
#   - в каждую страницу добавляется работник области: в корне сайта раньше стоял работник
#     таймера с широким охватом и мог отдать из кэша чужую страницу.
#
# Запуск: pwsh -File tools\make-site.ps1
#         pwsh -File tools\make-site.ps1 -Site D:\somewhere\annabiosis.github.io\obod
[CmdletBinding()]
param(
  [string]$Site = (Join-Path $PSScriptRoot '..\..\annabiosis.github.io\obod')
)

$ErrorActionPreference = 'Stop'
$web = Join-Path $PSScriptRoot '..\web'
$site = [IO.Path]::GetFullPath($Site)

if (-not (Test-Path $web)) { throw "нет папки web: $web" }
if (-not (Test-Path (Join-Path $site '..'))) { throw "нет папки сайта: $site" }

"источник: $web"
"назначение: $site"

# Страницы и общие ассеты заменяются целиком, остальное на сайте своё. Старые страницы
# не удаляются списком: имена новых те же, и копирование их перезапишет, а diagram.html
# со схемой на сайте живёт отдельно, и его терять нельзя.
if (-not (Test-Path $site)) { New-Item -ItemType Directory -Path $site | Out-Null }
if (Test-Path (Join-Path $site 'assets')) { Remove-Item (Join-Path $site 'assets') -Recurse -Force }
Copy-Item (Join-Path $web '*') $site -Recurse -Force
if (Test-Path (Join-Path $site 'README.md')) { Remove-Item (Join-Path $site 'README.md') -Force }

# Страницы, которых больше нет в наборе, убираются и из копии: иначе на сайте остаются
# осиротевшие файлы, на которые уже никто не ссылается, но которые открываются по адресу.
# diagram.html — своя страница сайта со схемой тракта, её не трогаем.
$keep = @('diagram.html')
Get-ChildItem $site -Filter '*.html' -File | Where-Object {
  $keep -notcontains $_.Name -and -not (Test-Path (Join-Path $web $_.Name))
} | ForEach-Object {
  Remove-Item $_.FullName -Force
  "убран осиротевший файл: $($_.Name)"
}

$shield = @'
<script>
  // Работник таймера раньше стоял в корне сайта и получал запросы всех разделов: он
  // ждёт сеть 800 мс и при задержке отдаёт из кэша свою страницу, а образ прошивки
  // больше мегабайта и в этот срок не укладывается. Свой работник с более длинным
  // охватом перекрывает старую регистрацию для этой папки.
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', function () {
      navigator.serviceWorker.register('sw.js', { scope: './' }).catch(function () {});
    });
  }
</script>
'@

$changed = 0
Get-ChildItem $site -Filter '*.html' -File | ForEach-Object {
  $text = [IO.File]::ReadAllText($_.FullName)
  $before = $text

  # Исходники выпуска переписываются ПЕРВЫМИ: правило ниже снимает ссылки в репозиторий,
  # оставляя текст, и архив, который на сайте есть, попал бы под него вместе с документами,
  # которых на сайте нет. Имя архива содержит версию, поэтому правило общее.
  $text = $text.Replace('../tools/webflash/sources.json', 'sources.json')
  $text = [regex]::Replace($text, '\.\./tools/webflash/firmware/(OBOD-[0-9.]+-src\.zip)',
                           'firmware/$1')

  # Ссылки на документы репозитория: остаётся только их текст.
  $text = [regex]::Replace($text, '<a href="\.\./(docs|tools)/[^"]*">([^<]*)</a>', '$2')

  # Схема: на сайте она лежит отдельной страницей рядом.
  $text = $text.Replace('../docs/signal-chain/obod-signal-chain.html', 'diagram.html')
  $text = $text.Replace('src="../docs/signal-chain/vendor/mermaid.min.js"', 'src="vendor/mermaid.min.js"')

  # Прошивка: манифест, замок выпуска, запечатанный образ и список изменений в папке
  # страницы. Открытый OBOD.bin на сайт не попадает вовсе: страница расшифровывает
  # запечатанный файл в браузере, и другой копии образа на сайте нет.
  $text = $text.Replace('../tools/webflash/manifest.json', 'manifest.json')
  $text = $text.Replace('../tools/webflash/lock.json', 'lock.json')
  $text = $text.Replace('../tools/webflash/firmware/OBOD.bin.enc', 'firmware/OBOD.bin.enc')
  $text = $text.Replace('../tools/webflash/firmware/OBOD.bin', 'firmware/OBOD.bin')
  $text = $text.Replace('../tools/webflash/changelog.json', 'changelog.json')

  if ($text -notmatch 'serviceWorker\.register') {
    $eol = if ($text.Contains("`r`n")) { "`r`n" } else { "`n" }
    $text = $text.Replace('</body>', ($shield -replace "`r`n", $eol) + '</body>')
  }

  [IO.File]::WriteAllText($_.FullName, $text)
  if ($text -ne $before) { $changed++ }
}

"страниц собрано: " + (Get-ChildItem $site -Filter '*.html' -File).Count
"страниц изменено против источника: $changed"

# Замок, запечатанный образ и манифест кладутся рядом со страницей записи: страница
# читает их по относительным путям, и на сайте эти пути короткие. Открытый образ здесь
# не копируется никогда — tools/webflash/seal.ps1 делает .enc, а .bin остаётся в
# репозитории.
$artifacts = @(
  @{ From = 'webflash\manifest.json';            To = 'manifest.json' },
  @{ From = 'webflash\lock.json';                To = 'lock.json' },
  @{ From = 'webflash\firmware\OBOD.bin.enc';   To = 'firmware\OBOD.bin.enc' },
  @{ From = 'webflash\sources.json';            To = 'sources.json' }
)

# Архив исходников называется путём из sources.json, а не угадывается по шаблону: страница
# ссылается на то же имя, и разойтись им нечем.
$sourcesFile = Join-Path $PSScriptRoot 'webflash\sources.json'
if (Test-Path -LiteralPath $sourcesFile) {
  $sources = Get-Content -LiteralPath $sourcesFile -Raw | ConvertFrom-Json
  $zipFrom = Join-Path $PSScriptRoot ('webflash\' + ($sources.path -replace '/', '\'))
  if (Test-Path -LiteralPath $zipFrom) {
    $artifacts += @{ From = ('webflash\' + ($sources.path -replace '/', '\')); To = $sources.path }
  }
  else {
    "нет $zipFrom — сначала pwsh -File tools/make-sources.ps1 -Version $($sources.version)"
  }
}
foreach ($a in $artifacts) {
  $from = Join-Path $PSScriptRoot $a.From
  $to = Join-Path $site $a.To
  if (-not (Test-Path -LiteralPath $from)) {
    "нет $from — сначала pwsh -File tools/webflash/merge.ps1 и pwsh -File tools/webflash/seal.ps1"
    continue
  }
  $dir = Split-Path -Parent $to
  if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir | Out-Null }
  Copy-Item -LiteralPath $from -Destination $to -Force
  "опубликовано: " + $a.To
}

# Архив исходников прошлого выпуска больше не нужен: страница ссылается на один файл, а
# старые версии лежат на странице выпуска в GitHub. Убираем их, чтобы сайт не рос на
# несколько мегабайт с каждым выпуском.
$currentZip = if ($sources) { Split-Path -Leaf $sources.path } else { '' }
Get-ChildItem (Join-Path $site 'firmware') -Filter 'OBOD-*-src.zip' -File -ErrorAction SilentlyContinue |
  Where-Object { $_.Name -ne $currentZip } |
  ForEach-Object {
    Remove-Item -LiteralPath $_.FullName -Force
    "убран архив прошлого выпуска: firmware/$($_.Name)"
  }

# Открытый образ на сайте — это утечка: если он там остался с прошлой публикации,
# убираем. Страница его больше не просит, а скачать его мог кто угодно.
$stale = Join-Path $site 'firmware\OBOD.bin'
if (Test-Path -LiteralPath $stale) {
  Remove-Item -LiteralPath $stale -Force
  "убран открытый образ с сайта: firmware/OBOD.bin"
}

# Список изменений собирает merge.ps1 из CHANGELOG.md; на сайте он лежит рядом с
# манифестом, потому что вкладка «Из браузера» читает его оттуда же, откуда образ.
$changelog = Join-Path $PSScriptRoot 'webflash\changelog.json'
if (Test-Path -LiteralPath $changelog) {
  Copy-Item -LiteralPath $changelog -Destination (Join-Path $site 'changelog.json') -Force
  "список изменений: changelog.json"
}
else {
  "список изменений: нет $changelog — сначала pwsh -File tools/webflash/merge.ps1"
}

"проверка: " + ((
  Get-ChildItem $site -Filter '*.html' -File |
  Where-Object { [IO.File]::ReadAllText($_.FullName) -match '\.\./(docs|tools)/' }
).Count) + ' страниц со ссылками в репозиторий'
