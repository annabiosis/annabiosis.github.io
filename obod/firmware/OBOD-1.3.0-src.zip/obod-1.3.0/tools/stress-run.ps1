# Стресс на приборе: запуск и отчёт.
#
# Делает всё сам и возвращает прибор на обычную сборку:
#   1. ставит CONFIG_OBOD_STRESS=y и заставляет CMake перечитать конфигурацию;
#   2. собирает и прошивает служебный образ;
#   3. открывает порт, СБРАСЫВАЕТ плату под открытым портом и пишет журнал;
#   4. вытаскивает строки «stress: verdict» в отдельный файл и печатает их;
#   5. снимает флаг, собирает и прошивает обычный образ.
#
# Код возврата 0 только если приговоры есть и ни один не заканчивается на FAIL.
#
#   pwsh -File tools/stress-run.ps1
#   pwsh -File tools/stress-run.ps1 -Port COM4 -Seconds 120

[CmdletBinding()]
param(
    [string] $Port = 'COM4',
    [int]    $Seconds = 90
)

$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.Encoding]::UTF8

$Root  = Split-Path -Parent $PSScriptRoot
$Sdk   = Join-Path $Root 'sdkconfig'
$Build = Join-Path $Root 'build'
$Idf   = Join-Path $PSScriptRoot 'idf.ps1'
$Cap   = Join-Path $Root 'build\proto-env\boot_capture.py'

# Питон: тот, что на PATH (в этой среде — рантайм DSH), иначе известный путь.
$Py = (Get-Command python -ErrorAction SilentlyContinue).Source
if (-not $Py) {
    $Py = 'C:\Users\Blaq\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe'
}

$stamp  = Get-Date -Format 'yyyyMMdd-HHmmss'
$log    = Join-Path $Build "stress-$stamp.log"
$txt    = Join-Path $Build "stress-$stamp.txt"

function Set-Stress([bool] $on)
{
    $text = [IO.File]::ReadAllText($Sdk)

    # Обе строки убираются, иначе в файле окажутся оба ответа и Kconfig выберет не тот.
    $text = [regex]::Replace($text, '(?m)^[ \t]*CONFIG_OBOD_STRESS=.*\r?\n?', '')
    $text = [regex]::Replace($text, '(?m)^[ \t]*#\s*CONFIG_OBOD_STRESS is not set\r?\n?', '')

    if ($on) {
        $text = $text.TrimEnd() + "`r`nCONFIG_OBOD_STRESS=y`r`n"
    } else {
        $text = $text.TrimEnd() + "`r`n# CONFIG_OBOD_STRESS is not set`r`n"
    }

    [IO.File]::WriteAllText($Sdk, $text)

    # Без этого CMake переиспользует прежнюю конфигурацию и шьёт тот же образ.
    $cfg = Join-Path $Build 'config/sdkconfig.json'
    if (Test-Path $cfg) {
        Remove-Item $cfg -Force
    }
}

function Invoke-Step([string[]] $IdfArgs, [string] $What)
{
    & $Idf @IdfArgs
    if ($LASTEXITCODE -ne 0) {
        throw "$What завершилось с кодом $LASTEXITCODE"
    }
}

$exit = 1

try {
    Set-Stress $true
    Invoke-Step @('build') 'сборка со стрессом'
    Invoke-Step @('-p', $Port, 'flash') 'прошивка со стрессом'

    Start-Sleep -Seconds 4
    & $Py $Cap $Port $Seconds $log | Out-Null

    $verdicts = @()

    if (Test-Path $log) {
        $verdicts = Select-String -Path $log -Pattern 'stress: verdict' |
                    ForEach-Object { $_.Line.Trim() }
    }

    if ($verdicts.Count -gt 0) {
        $verdicts | Set-Content -Path $txt -Encoding UTF8
        $verdicts | ForEach-Object { Write-Host $_ }

        $failed = @($verdicts | Where-Object { $_ -match 'FAIL\s*$' })
        $exit = if ($failed.Count -eq 0) { 0 } else { 1 }
        Write-Host ("приговоров: {0}, с FAIL: {1}" -f $verdicts.Count, $failed.Count)
    } else {
        Write-Host 'приговоров нет — журнал пуст или стресс не запустился' -ForegroundColor Red
        $exit = 1
    }
}
finally {
    Set-Stress $false
    & $Idf build | Out-Null
    & $Idf -p $Port flash | Out-Null
    Write-Host 'обычная сборка возвращена на прибор'
}

exit $exit
