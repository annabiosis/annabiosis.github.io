"""ФОРМА ОГИБАЮЩЕЙ ФИЛЬТРА ЛИДА: AR вместо ADSR, длина от GATE, глубина до упоров.

Владелец попросил три вещи одним заходом, и проверка держит каждую из них, потому что каждая
ломается тихо: звук меняется, а ошибка не видна.

  * Огибающая фильтра — AR. В фильтре нет ступеней спада и сюстейна, спад начинается, как
    только атака дошла до верха (одноразовая огибающая), а запуск идёт по СЧЁТЧИКУ нот в
    слоте 4: гейт остаётся поднятым, когда шаги перекрываются, и его фронт больше ничего не
    говорит. На уровне огибающая перезапускалась бы каждый блок, пока нота держится.
  * Длина огибающей — четверть по темпу, умноженная на GATE, с потолком 3 с; ручка SHAPE
    делит её между атакой и релизом. Шестнадцатая (длина ноты) для медленных ступеней мала:
    на 120 BPM это 62 мс.
  * Глубина ENV — проценты хода до упора, а не октавы по фиксированной шкале, поэтому упор
    достигается на любом CUTOFF; в прошивку по-прежнему уходят центиоктавы.
  * Четыре ручки LEAD ENV — огибающая громкости голосов лида, а не фильтра.
  * Нот у лида четыре: четвёртая группа занимает голоса 21..23, группу арпа — 24..26 нет,
    арпеджиатор стоит на 21..23, и весь движок заполнен ровно до MAX_VOICES.

Run: python tools/lead-env-shape.py
"""
import re
import sys

sys.stdout.reconfigure(encoding="utf-8")

APP = "components/synth_app/src/synth_app.cpp"
HDR = "components/synth_app/include/synth_app.h"
DSP = "components/synth_dsp/src/synth_lead_filter.cpp"
DSPH = "components/synth_dsp/include/synth_dsp.h"
UI = "components/synth_ui/src/synth_ui.c"
PREVIEW = "components/synth_ui/src/synth_ui_preview.c"
REF = "web/assets/ref.js"
FAIL = []


def fail(msg):
    FAIL.append(msg)


def ok(msg):
    print("  " + msg)


def read(p):
    return open(p, encoding="utf-8", errors="replace").read()


def body(text, needle, kind="static"):
    """Тело функции, начиная с её объявления и до парной закрывающей скобки.

    Ищется ОПРЕДЕЛЕНИЕ, а не объявление вперёд: у нескольких помощников этой правки
    объявление стоит выше по файлу, и поиск по первой встрече уводил бы в чужое тело.
    """
    m = re.search(re.escape(needle) + r"\s*\n\{", text)
    if not m:
        raise SystemExit("не найдено определение: " + needle)
    at = m.start()
    i = m.end() - 1
    depth = 0
    for j in range(i, len(text)):
        if text[j] == "{":
            depth += 1
        elif text[j] == "}":
            depth -= 1
            if depth == 0:
                return text[at:j + 1]
    raise SystemExit("не найдено тело: " + needle)


app = read(APP)
hdr = read(HDR)
dsp = read(DSP)
dsph = read(DSPH)
ui = read(UI)
preview = read(PREVIEW)
ref = read(REF)

# ---------------------------------------------------------------- 1. параметр
print("1. параметр в конце патча")
count = re.search(r"static_assert\(SYNTH_PARAM_PATCH_COUNT == (\d+)", app)
if not count or count.group(1) != "107":
    fail("патч не на 107 параметров")
if "SYNTH_PARAM_LEAD_FENV_SHAPE" not in hdr:
    fail("в перечислении нет SYNTH_PARAM_LEAD_FENV_SHAPE")

# вставлен после ARP_ACCENT и до SET_SCREEN — то есть в конец патча, а не в середину
tail = hdr[hdr.index("SYNTH_PARAM_ARP_ACCENT"):]
order = [m.group(1) for m in re.finditer(r"^\s*(SYNTH_PARAM_[A-Z0-9_]+),", tail, re.M)]
if order[:2] != ["SYNTH_PARAM_ARP_ACCENT", "SYNTH_PARAM_LEAD_FENV_SHAPE"]:
    fail("новая ручка стоит не сразу после ARP_ACCENT: %s" % order[:3])
if "SYNTH_PARAM_LEAD_FENV_SHAPE" in hdr[hdr.index("SYNTH_PARAM_SET_SCREEN"):]:
    fail("новая ручка попала в блок настроек")
else:
    ok("APPEND: последняя в патче, настройки не сдвинуты")

limit = re.search(r"#define APP_SETTINGS_PATCH_MAX (\d+)", read("components/app_settings/include/app_settings.h"))
if not limit or limit.group(1) != "107":
    fail("потолок блоба не вырос до 107")

# ---------------------------------------------------------------- 2. AR в фильтре
print("2. AR в фильтре лида")
stages = re.search(r"enum \{\s*(ST_[A-Z_ =0-9,\s]+?)\};", dsp)
if not stages:
    fail("не найдено перечисление ступеней огибающей")
elif "ST_DECAY" in stages.group(1) or "ST_SUSTAIN" in stages.group(1):
    fail("в фильтре остались ступени спада или сюстейна")
if "bool  gate_prev" not in dsp and "bool gate_prev" not in dsp:
    fail("нет памяти о фронте гейта")
if "retrig != st.retrig" not in dsp:
    fail("огибающая запускается не по счётчику нот")
if "0, 4," not in body(app, "static void lead_fenv_retrigger(void)"):
    fail("счётчик нот не уходит в слот 4 фильтра")
if "lead_fenv_retrigger();" not in body(
        app, "static void lead_note_on(float hz, float velocity, uint32_t gate_blocks)"):
    fail("генератор не поднимает счётчик нот")
if "if (!gate && st.stage == ST_ATTACK)" not in dsp:
    fail("упавший гейт больше не обрывает атаку")
if "if (st.env >= 0.99f) {" not in dsp or dsp.index("st.env = 1.0f") > dsp.index("case ST_RELEASE:"):
    fail("спад не начинается сам после атаки: огибающая не одноразовая")
if "(int32_t)ep[4]" not in dsp:
    fail("ep[4] не читается как счётчик нот")
if "ep[5] is the filter's MODE" not in dsp:
    fail("в фильтре не сказано, что ep[5] — режим, а не уровень")
if "float sustain" in dsp:
    fail("в фильтре остался уровень сюстейна")
else:
    ok("ступени: IDLE, ATTACK, RELEASE; запуск по счётчику нот; спад сам после атаки")

# ---------------------------------------------------------------- 3. длина от GATE
print("3. длина огибающей")
times = body(app, "static void lead_fenv_times_apply(void)")
if "lead_fenv_ms()" not in times:
    fail("времена огибающей не берутся из её длины")
msf = body(app, "static float lead_fenv_ms(void)")
if "SYNTH_PARAM_SEQ_GATE" not in msf:
    fail("длина огибающей не читает GATE")
if "(60000.0f / bpm) * gate" not in msf:
    fail("длина огибающей считается не от четверти по темпу")
if "LEAD_FENV_TIME_MAX_MS" not in msf:
    fail("у длины огибающей нет потолка")
if "#define LEAD_FENV_TIME_MAX_MS  3000.0f" not in app:
    fail("потолок длины не 3 с")
if "SYNTH_PARAM_LEAD_FENV_SHAPE" not in times:
    fail("деление длины на атаку и релиз не читает SHAPE")
if "0, 3, (int16_t)(a + 0.5f)" not in times or "0, 6, (int16_t)(r + 0.5f)" not in times:
    fail("атака и релиз не уходят в слоты 3 и 6 фильтра")
if "lead_fenv_times_apply();" not in body(app, "static void lead_filter_gate(int on)"):
    fail("гейт не пересчитывает времена перед фронтом")
if "case SYNTH_PARAM_SEQ_GATE:" not in app or "lead_fenv_times_apply();" not in \
        app[app.index("case SYNTH_PARAM_SEQ_GATE:"):][:160]:
    fail("смена GATE не пересчитывает времена")
else:
    ok("четверть × GATE → длина, SHAPE делит на атаку и релиз, гейт пересчитывает")

# ---------------------------------------------------------------- 4. глубина до упоров
print("4. глубина до упоров")
if "#define LEAD_FC_FLOOR_HZ" not in app or "#define LEAD_FC_CEIL_HZ" not in app:
    fail("нет упоров глубины")
if "LEAD_ENV_MIN_OCT" in app or "LEAD_ENV_MAX_OCT" in app:
    fail("старая шкала в октавах ещё жива")
env = body(app, "static void apply_lead_env(float v01)")
if "lead_env_oct_for(v01, fc)" not in env or "lead_fc_base_for(s_cur[SYNTH_PARAM_LEAD_CUTOFF])" not in env:
    fail("глубина не считается от текущего среза")
oct_for = body(app, "static float lead_env_oct_for(float v01, float fc)")
for want in ("LEAD_FC_CEIL_HZ", "LEAD_FC_FLOOR_HZ", "fabsf(p)"):
    if want not in oct_for:
        fail("в расчёте глубины нет " + want)
if "apply_lead_env(s_cur[SYNTH_PARAM_LEAD_ENV]);" not in body(app, "static void apply_lead_cutoff(float v01)"):
    fail("глубина не пересчитывается вместе со срезом")
if '"%+d%%"' not in app:
    fail("глубина показывается не в процентах")
else:
    ok("проценты до упора, октавы от среза и трекинга, отсчёт в процентах")

# ---------------------------------------------------------------- 5. громкость
print("5. четыре ручки ENV — громкость")
for name in ("apply_lead_attack", "apply_lead_decay", "apply_lead_sustain", "apply_lead_release"):
    m = re.search(r"static void %s\(float v01\)\s*\{([^}]*)\}" % name, app)
    if not m:
        fail("нет %s" % name)
    elif "apply_lead_amp_env();" not in m.group(1):
        fail("%s не пишет огибающую громкости" % name)
    elif "setBusFXParam" in m.group(1):
        fail("%s всё ещё пишет в фильтр" % name)
amp = body(app, "static void apply_lead_amp_env(void)")
for want in ("SYNTH_PARAM_LEAD_ATTACK", "SYNTH_PARAM_LEAD_DECAY",
             "SYNTH_PARAM_LEAD_SUSTAIN", "SYNTH_PARAM_LEAD_RELEASE",
             "LEAD_CONFIGURED_VOICES", "setEnv("):
    if want not in amp:
        fail("в огибающей громкости нет " + want)
if "setBusFXParam" in amp:
    fail("громкость всё ещё пишется в фильтр")
if "LEAD_AMP_ATTACK_DEFAULT_MS    40.0f" not in app:
    fail("заводская атака не 40 мс")
if "(220.0f / 255.0f)" not in app:
    fail("заводской сюстейн не 220/255")
if "lead_time_for(s_cur[SYNTH_PARAM_LEAD_RELEASE])" not in app:
    fail("хвост MIDI не читает ручку RELEASE")
else:
    ok("setEnv по всем голосам лида, заводские 40/250/0.86/500, хвост MIDI по ручке")

# ---------------------------------------------------------------- 6. перекрытие шагов
print("6. шаги секвенсора перекрываются")
sig = "static void lead_note_on(float hz, float velocity, uint32_t gate_blocks)"
if sig not in app:
    fail("генератор не получает длину гейта")
non = body(app, sig)
if "== LEAD_NOTE_FREE" not in non:
    fail("генератор не ищет свободную группу")
if "oldest_gen" not in non:
    fail("генератор не крадёт свою самую старую ноту")
if "lead_fenv_retrigger();" not in non:
    fail("генератор не перезапускает огибающую фильтра")
if "s_lead_group_hz[group] = s_gen_last_hz;" not in non:
    fail("глиссандо генератора не от предыдущей ноты линии")
if "static uint16_t s_gen_gate[LEAD_GROUPS];" not in app:
    fail("нет счётчика гейта по группам")
if "static uint16_t s_gen_tail[LEAD_GROUPS];" not in app:
    fail("нет счётчика хвоста по группам")
tick = body(app, "static void lead_gen_tick(void)")
for want in ("s_gen_gate[g]--", "s_gen_tail[g]--", "noteOff", "SYNTH_PARAM_LEAD_RELEASE",
             "LEAD_NOTE_FREE"):
    if want not in tick:
        fail("в тике генератора нет " + want)
if "\n    lead_gen_tick();" not in app:
    fail("тик генератора не вызывается")
if "s_seq_gate_left == 0 && midi_note_active()" not in app:
    fail("общий счётчик гейта всё ещё закрывает всю линию")
if "lead_note_on(hz, arp_velocity(), gate_blocks);" not in app:
    fail("арп не передаёт гейт в ноту генератора")
alloc = body(app, "static int lead_group_alloc(int note)")
if "lead_group_off(g);" not in alloc:
    fail("клавиша бросает ноты генератора без note-off: повисшие ноты")
if "s_lead_note[g] = LEAD_NOTE_FREE;\n            s_gen_gate[g]" in alloc:
    fail("таблица чистится в обход note-off")
if "seq_trigger(gate_blocks);" not in app:
    fail("секвенсор не передаёт гейт в триггер")
else:
    ok("группа на шаг, гейт и хвост по группам, общий счётчик больше не закрывает всё")

# ---------------------------------------------------------------- 7. четыре ноты
print("7. четыре ноты лида")
for pat, want in ((r"#define LEAD_GROUPS\s+(\d+)", "4"),
                  (r"#define LEAD_GROUP_VOICES\s+(\d+)", "3"),
                  (r"#define MAX_VOICES\s+(\d+)", "24")):
    m = re.search(pat, app if "MAX_VOICES" not in pat else read("components/synth_core/src/ESP32Synth_Config.hpp"))
    if not m or m.group(1) != want:
        fail("ожидалось %s = %s" % (pat, want))
if "LEAD_VOICE_BASE           9" not in app:
    fail("база голосов лида сдвинулась")
# 9 + (4+1)*3 = 24, то есть последний голос движка занят группой арпа
base = 9
voices = (4 + 1) * 3
if base + voices != 24:
    fail("раскладка не сходится с MAX_VOICES: %d" % (base + voices))
if re.search(r"static int16_t\s+s_lead_note\[LEAD_GROUP_COUNT\] = \{[^}]*\}", app).group(0).count("LEAD_NOTE_FREE") != 5:
    fail("таблица групп не на пять записей")
if "the player's four groups" not in app:
    fail("в комментарии аллокатора не четыре группы")
if "четыре" not in read("FEATURES.md"):
    fail("FEATURES не знает про четыре ноты")
else:
    ok("4 группы × 3 голоса = 12, арп на 21..23, движок заполнен ровно")

# ---------------------------------------------------------------- 7. страница и фигура
print("8. страница LEAD TONE и фигура")
knobs = re.search(r"static const ui_knob_t KNOBS_TONE\[\] = \{(.*?)\n\};", ui, re.S).group(1)
labels = re.findall(r'\{\s*"([^"]+)"\s*,\s*(SYNTH_PARAM_[A-Z0-9_]+)', knobs)
if [n for n, _ in labels] != ["CUTOFF", "RES", "ENV", "SHAPE", "K.TRCK", "MODE"]:
    fail("ручки LEAD TONE: %s" % [n for n, _ in labels])
if ("SHAPE", "SYNTH_PARAM_LEAD_FENV_SHAPE") not in labels:
    fail("на LEAD TONE нет SHAPE")
site = re.search(r"\{ n: 'LEAD TONE'.*?\n    \]\},", ref, re.S)
if not site:
    fail("на сайте нет страницы LEAD TONE")
else:
    names = re.findall(r"\['([A-Z.]+)'", site.group(0))
    if names != [n for n, _ in labels]:
        fail("сайт: %s, прошивка: %s" % (names, [n for n, _ in labels]))
if "PREVIEW_LEAD_FENV_SHAPE" not in preview:
    fail("нет фигуры для SHAPE")
if "case SYNTH_PARAM_LEAD_FENV_SHAPE:" not in preview:
    fail("фигура не подключена к параметру")
if "pv_lead_fenv_shape(mask" not in preview:
    fail("фигура не рисуется")
else:
    ok("шесть секторов, порядок совпадает с сайтом, фигура есть")

print()
if FAIL:
    print("НЕ ПРОШЛО, %d:" % len(FAIL))
    for f in FAIL:
        print("  - " + f)
    sys.exit(1)
print("OK: AR вместо ADSR, длина от четверти и GATE (потолок 3 с), глубина до упоров, громкость на четырёх ручках, четыре ноты, шаги перекрываются")
