"""Гейт фигуры ACCENT: знаки, сетка 4x4 и совпадение с масками прошивки."""
import re
import sys

sys.stdout.reconfigure(encoding="utf-8")

SRC = "components/synth_ui/src/synth_ui_preview.c"
APP = "components/synth_app/src/synth_app.cpp"

src = open(SRC, encoding="utf-8").read()
app = open(APP, encoding="utf-8").read()
problems = []


def popcount(v):
    return bin(v).count("1")


# --- знаки -------------------------------------------------------------------
block = src[src.index("static const uint8_t ACCENT_MARK[2][6] = {"):]
block = block[:block.index("\n};")]
rows = [[int(v, 16) for v in re.findall(r"0x([0-9A-Fa-f]{2})", r)]
        for r in re.findall(r"\{([^}]*)\}", block)]
if len(rows) != 2 or any(len(r) != 6 for r in rows):
    problems.append("ACCENT_MARK: ждали 2 знака по 6 строк, нашли %s"
                    % [len(r) for r in rows])
else:
    accent, weak = rows

    def ink(r):
        return sum(popcount(v) for v in r)

    def cells(r):
        out = set()
        for y, v in enumerate(r):
            for x in range(6):
                if v & (0x20 >> x):
                    out.add((x, y))
        return out

    centre = {(2, 2), (3, 2), (2, 3), (3, 3)}
    sides = {(1, 2), (1, 3), (2, 1), (3, 1), (4, 2), (4, 3), (2, 4), (3, 4)}

    if ink(accent) != 32:
        problems.append("акцент: закрашено %d, ждали 32 (6x6 без четырёх углов)" % ink(accent))
    if any(accent[y] != 0x3F for y in (1, 2, 3, 4)):
        problems.append("акцент: у квадрата не прямые боковины")
    if accent[0] != 0x1E or accent[5] != 0x1E:
        problems.append("акцент: верх и низ не симметричны")
    if ink(weak) != 12:
        problems.append("слабый: закрашено %d, ждали 12 (круг 4x4)" % ink(weak))
    if cells(weak) != (sides | centre):
        problems.append("слабый: не сплошной круг")
    if weak[0] or weak[5] or any(weak[y] & 0x21 for y in range(6)):
        problems.append("слабый: залез в край ячейки")

    # третьего знака быть не должно: глухие шаги не рисуются вовсе
    if "ACCENT_MARK[3]" in src:
        problems.append("в таблице всё ещё три знака")
    if "ring" in src[src.index("static void pv_accent"):src.index("static void pv_accent") + 2000].lower():
        problems.append("в фигуре осталось кольцо")

# --- сетка -------------------------------------------------------------------
ge = re.search(r"enum \{ CELL = (\d+), X0 = (\d+), Y0 = (\d+)", src)
if not ge:
    problems.append("pv_accent: не нашёл геометрию ячейки")
else:
    CELL, X0, Y0 = (int(g) for g in ge.groups())
    if CELL != 10:
        problems.append("шаг ячейки %d, ждали 10 (та же решётка, что у случайной формы)" % CELL)
    if (X0, Y0) != (10, 10):
        problems.append("начало сетки (%d,%d), ждали (10,10)" % (X0, Y0))
    last = X0 + 3 * CELL + 6
    if last > 46:
        problems.append("правый край фигуры %d, за полем (46)" % last)
    if not re.search(r"for \(int k = 0; k < 16; k\+\+\)", src):
        problems.append("pv_accent: не шестнадцать шагов")

# --- маски и имена -----------------------------------------------------------
mb = app[app.index("static const uint16_t ACCENT_MASK[] = {"):]
mb = mb[:mb.index("\n};")]
masks = [int(v, 16) for v in re.findall(r"(0x[0-9A-Fa-f]{4})u", mb)]
nb = app[app.index("static const char *const ACCENT_NAME[ACCENT_COUNT] = {"):]
nb = nb[:nb.index("\n};")]
names = re.findall(r'"([^"]+)"', nb)
if len(masks) != 8:
    problems.append("фигур %d, ждали 8" % len(masks))
if len(names) != len(masks):
    problems.append("имён %d, масок %d" % (len(names), len(masks)))
if any(len(n) > 5 for n in names):
    problems.append("слишком длинное имя: %s" % [n for n in names if len(n) > 5])


def marked(mask, step, n):
    if mask == 0:
        return False
    return bool(mask & (1 << ((step % n))))

# --- совпадение с масками ----------------------------------------------------
acc_idx = src.index("static const uint8_t ACCENT_MARK")
use = src[src.index("static void pv_accent(uint8_t *m"):]
if "synth_app_accent_marks" not in use:
    problems.append("pv_accent не спрашивает прошивку, какие шаги помечены")

for mask, name in zip(masks, names):
    for n in (16, 7, 5):
        want = sum(1 for k in range(16) if marked(mask, k, n))
        if mask == 0 and want:
            problems.append("%s: OFF помечает шаги" % name)
        if mask and want == 0:
            problems.append("%s: при n=%d не помечено ни одного шага" % (name, n))
        if mask and popcount(mask & 0xFFFF) > 6 and n == 16:
            problems.append("%s: больше шести акцентов (%d)" % (name, popcount(mask)))

# При нулевом слабом в поле остаются только акценты: ни одного знака слабого шага.
if not re.search(r"if \(!marked && weak_off\) \{\s*\n\s*continue;", src):
    problems.append("pv_accent: глухой шаг всё ещё рисуется")

if problems:
    print("FAIL: фигура ACCENT разошлась с прошивкой")
    for p in problems:
        print("  - " + p)
    sys.exit(1)

print("OK: фигура ACCENT — 16 шагов сеткой 4x4, два знака, глухие шаги не рисуются, "
      "маски те же, что у звука")
