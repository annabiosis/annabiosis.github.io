"""Фигура VAR: дерево, которое растёт снизу, против его рисунка и само по себе по ходу ручки.

Геометрия снята с его файла 1:1: ствол в две колонки от строки 41 вверх, три развилки,
перекладины в две строки с подрезанными нижними углами, ветви и веточки по два пикселя.
Здесь повторена целочисленная арифметика прошивки (доли хода в тысячных, рост в 256-х) и
прочитана её таблица ветвей.
"""
import io
import re
import sys

sys.stdout.reconfigure(encoding="utf-8")

SRC = io.open("components/synth_ui/src/synth_ui_preview.c", encoding="utf-8").read()
HDR = io.open("components/synth_ui/src/synth_ui_preview.h", encoding="utf-8").read()

problems = []

ART = 44
HIS = (
    "00000000000000000000006066198660660661986606606619866066066198660660661986606606619866066066198660660661986606606619866067fe7f9fe7fe3fc3f0fc3fc0600c0300600600c0300600600c0300600600c0300600600c0300600600c0300600600c0300600600c03006007ffc03ffe003ff801ffc00018000180000180001800001800018000018000180000180001800001800018000018000180000180001800001fffff800000fffff0000000060000000000600000000006000000000060000000000600000000006000000000060000000000600000000006000000000000000000000000000"
)

FIELD = 44


def unpack(hexstr):
    bits = "".join(format(b, "08b") for b in bytes.fromhex(hexstr))[:ART * ART]
    return [[1 if bits[y * ART + x] == "1" else 0 for x in range(ART)]
            for y in range(ART)]


# --- таблица ветвей из прошивки ----------------------------------------------
body = SRC[SRC.index("static const pv_var_seg_t s_var_segs[] = {"):]
body = body[:body.index("\n};")]
ROWS = re.findall(r"\{\s*(\d+),\s*(\d+),\s*(\d+),\s*(\d+),\s*(\d+),\s*(\d+)\s*\},", body)

if len(ROWS) != 22:
    problems.append("ветвей в таблице %d, а должно 22" % len(ROWS))

SEGS = [tuple(int(v) for v in row) for row in ROWS]


def frame(q):
    """Кадр при положении ручки q: та же арифметика, что в pv_var()."""
    g = [[0] * ART for _ in range(ART)]
    t = q * 1000 // 50

    for kind, a, b0, b1, start, end in SEGS:
        if t <= start:
            continue
        f = 256 if t >= end else (t - start) * 256 // (end - start)
        if f <= 0:
            continue
        if kind == 0:
            rows = b0 - b1 + 1
            h = (f * rows + 128) // 256
            for y in range(b0 - h + 1, b0 + 1):
                g[y][a] = 1
                g[y][a + 1] = 1
            continue
        c2 = a + b1
        half2 = b1 - a
        w = f * half2 // 256
        lo = (c2 - w + 1) // 2
        hi = (c2 + w) // 2
        for x in range(lo, hi + 1):
            g[b0][x] = 1
        low_lo = lo + 1 if hi - lo >= 2 else lo
        low_hi = hi - 1 if hi - lo >= 2 else hi
        for x in range(low_lo, low_hi + 1):
            g[b0 + 1][x] = 1
    return g


def ink(grid):
    return sum(map(sum, grid))


def attached(grid):
    lit = {(x, y) for y in range(ART) for x in range(ART) if grid[y][x]}
    if not lit:
        return True
    root = max(lit, key=lambda c: (c[1], -c[0]))
    seen, stack = {root}, [root]
    while stack:
        x, y = stack.pop()
        for nx, ny in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)):
            if (nx, ny) in lit and (nx, ny) not in seen:
                seen.add((nx, ny))
                stack.append((nx, ny))
    return seen == lit


# --- 1. полное дерево = его рисунок ------------------------------------------
his = unpack(HIS)
full = frame(50)
diff = [(x, y) for y in range(ART) for x in range(ART) if full[y][x] != his[y][x]]
if diff:
    problems.append("полное дерево не сходится: %d точек, первая %s" % (len(diff), diff[0]))

# --- 2. рост ------------------------------------------------------------------
inks = [ink(frame(q)) for q in range(0, 51)]
if inks[0] != 0:
    problems.append("при нуле поле не пустое")
for q in range(50):
    if inks[q + 1] < inks[q]:
        problems.append("на q=%d дерево уменьшилось" % q)

bad = [q for q in range(0, 51) if not attached(frame(q))]
if bad:
    problems.append("кадры с висящим в воздухе: %s" % bad[:8])

if len({repr(frame(q)) for q in range(0, 51)}) < 30:
    problems.append("кадров слишком мало разных: %d"
                    % len({repr(frame(q)) for q in range(0, 51)}))

# --- 3. центральная ветвь ведёт, боковые отстают ------------------------------
BY_A = {}
for kind, a, b0, b1, start, end in SEGS:
    BY_A.setdefault(a, []).append((kind, b0, b1, start, end))


def window(a, b1):
    for kind, b0, b1x, start, end in BY_A[a]:
        if b1x == b1:
            return start, end
    return None


central = window(16, 13)          # vLb — центральная ветвь
outer_left = window(5, 13)        # vLa — крайняя левая
outer_right = window(37, 13)      # vRb — крайняя правая
last_twig = max((s for s in SEGS if s[0] == 0 and s[2] == 10), key=lambda s: s[5])

if not central or not outer_left or not outer_right:
    problems.append("не нашлись ветви для сверки: центральная и две крайние")
else:
    if central[1] > 500:
        problems.append("центральная ветвь кончается на %d, а должна вести до половины хода"
                        % central[1])
    CENTRAL_SPAN = central[1] - central[0]
    for name, w in (("левая", outer_left), ("правая", outer_right)):
        span = w[1] - w[0]
        if span < 2 * CENTRAL_SPAN:
            problems.append("крайняя %s ветвь идёт всего в %.1f раза дольше центральной"
                            % (name, span / float(CENTRAL_SPAN)))
        if w[1] - central[1] < 100:
            problems.append("крайняя %s ветвь кончается всего на %d позже центральной"
                            % (name, w[1] - central[1]))
    if central[0] > outer_left[0]:
        problems.append("центральная ветвь трогается позже крайней левой")

if last_twig[5] < 950:
    problems.append("последняя веточка кончается на %d, а должна на самом конце" % last_twig[5])

for kind, a, b0, b1, start, end in SEGS:
    if end > 1000 or start >= end:
        problems.append("окно ветви на столбце %d испорчено: %d..%d" % (a, start, end))

# --- 4. провод ----------------------------------------------------------------
DISPATCH = SRC[SRC.index("static synth_preview_kind_t pv_values"):]
DISPATCH = DISPATCH[:DISPATCH.index("\n}\n")]
LABELS, pending = {}, []
for mm in re.finditer(r"case (SYNTH_PARAM_\w+):|return (PREVIEW_\w+);", DISPATCH):
    if mm.group(1):
        pending.append(mm.group(1))
    else:
        for label in pending:
            LABELS.setdefault(label, mm.group(2))
        pending = []

if LABELS.get("SYNTH_PARAM_PERC_VARIATION") != "PREVIEW_VAR":
    problems.append("PERC_VARIATION отдаёт %s, а должен PREVIEW_VAR"
                    % LABELS.get("SYNTH_PARAM_PERC_VARIATION"))
if "PREVIEW_VAR" not in HDR:
    problems.append("нет вида PREVIEW_VAR в заголовке")
if not re.search(r"case PREVIEW_VAR:\s*pv_var\(", SRC):
    problems.append("нет вызова pv_var в переключателе")
ox = SRC[SRC.index("static int pv_ox_for"):SRC.index("static int pv_oy_for")]
if "case PREVIEW_VAR:" not in ox:
    problems.append("PREVIEW_VAR не в списке нулевого сдвига")
if "const int t = (int)v->q[0] * 1000 / 50;" not in SRC:
    problems.append("в pv_var не та арифметика хода ручки")
if "const int low_lo = (hi - lo >= 2) ? lo + 1 : lo;" not in SRC:
    problems.append("в pv_var не видно подрезки нижней строки перекладины")

if problems:
    print("FAIL: фигура VAR")
    for p in problems:
        print("  -", p)
    sys.exit(1)

print("OK: VAR — дерево снизу, %d ветвей в таблице, полное дерево совпадает с его рисунком "
      "точка в точку (%d пикселей); центральная ветвь кончается на %d, крайние на %d и %d, "
      "последняя веточка ровно на %d; в воздухе не висит ничего ни на одном из 51 положения"
      % (len(SEGS), ink(full), central[1], outer_left[1], outer_right[1], last_twig[5]))
