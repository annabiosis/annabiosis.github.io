"""Фигура GROOVE: что рисует прошивка против таблицы грувов и образца владельца.

Глифы сняты с его файла 1:1: круг радиусом четыре, ромб-обводка в два пикселя, квадрат
4 x 4; том — тот же ромб поменьше, призрачный хэт — квадрат 2 x 2. Здесь повторена
целочисленная арифметика прошивки, прочитана её таблица грувов и сверено всё, что видно.
"""
import io
import re
import sys

sys.stdout.reconfigure(encoding="utf-8")

SRC = io.open("components/synth_ui/src/synth_ui_preview.c", encoding="utf-8").read()
HDR = io.open("components/synth_ui/src/synth_ui_preview.h", encoding="utf-8").read()
APP = io.open("components/synth_app/src/synth_app.cpp", encoding="utf-8").read()
APPH = io.open("components/synth_app/include/synth_app.h", encoding="utf-8").read()

problems = []

# его образец 44 x 44, ромб там ещё залитый
HIS = (
    "0000000000000000000000000000000000781e0000c00fc3f0001e01fe7f8783f01fe7f8787f81fe7f8787f81fe7f8783f00fc3f0001e00781e0000c0000000000000000000000003000000000078000000000fc000780001fe000780001fe000780000fc0007800007800000000030000000000000000000000000000000078000000c00fc000001e01fe000783f01fe000787f81fe000787f81fe000783f00fc000001e0078000000c0000000000000000000000003000000000078000000000fc000780001fe000780001fe000780000fc000780000780000000003000000000000000000000000000000000000000000"
)

FIELD = 44
CELL = 10
ORIGIN = 3
GLYPH = 8

# его образец по клеткам: 0 кик, 1 снейр, 2 хэт, -1 пусто
SAMPLE = [0, 0, 2, 1,
          1, -1, 2, -1,
          0, -1, 2, 1,
          1, -1, 2, -1]


def const(name):
    m = re.search(r"#define\s+%s\s+(-?\d+)" % name, SRC)
    if not m:
        problems.append("нет константы %s" % name)
        return 0
    return int(m.group(1))


if (const("PV_GR_CELL"), const("PV_GR_ORIGIN"), const("PV_GR_GLYPH"), const("PV_GR_FIELD")) \
        != (CELL, ORIGIN, GLYPH, FIELD):
    problems.append("константы сетки не те")


def dx(lx):
    return 2 * lx - 7


def glyph(kind, lx, ly):
    """Та же арифметика, что в pv_gr_cell."""
    if kind == 0:
        return dx(lx) ** 2 + dx(ly) ** 2 <= 64
    if kind == 1:
        d = abs(dx(lx)) + abs(dx(ly))
        return 4 < d <= 8
    if kind == 2:
        return 2 <= lx <= 5 and 2 <= ly <= 5
    if kind == 3:
        d = abs(dx(lx)) + abs(dx(ly))
        return 2 < d <= 6
    if kind == 4:
        return 3 <= lx <= 4 and 3 <= ly <= 4
    return False


def cell_mask(kind):
    return [[glyph(kind, lx, ly) for lx in range(GLYPH)] for ly in range(GLYPH)]


def draw(kinds):
    g = [[0] * FIELD for _ in range(FIELD)]
    for s, kind in enumerate(kinds):
        if kind < 0:
            continue
        col, row = s % 4, s // 4
        for ly in range(GLYPH):
            for lx in range(GLYPH):
                if glyph(kind, lx, ly):
                    g[ORIGIN + row * CELL + ly][ORIGIN + col * CELL + lx] = 1
    return g


def unpack54(hexstr):
    bits = "".join(format(b, "08b") for b in bytes.fromhex(hexstr))
    bits = bits[:FIELD * FIELD]
    return [[1 if bits[y * FIELD + x] == "1" else 0 for x in range(FIELD)]
            for y in range(FIELD)]


# --- 1. глифы против его образца ---------------------------------------------
his = unpack54(HIS)
mine = draw(SAMPLE)

for s, kind in enumerate(SAMPLE):
    if kind not in (0, 2):
        continue
    col, row = s % 4, s // 4
    for ly in range(GLYPH):
        for lx in range(GLYPH):
            y = ORIGIN + row * CELL + ly
            x = ORIGIN + col * CELL + lx
            if mine[y][x] != his[y][x]:
                problems.append("шаг %d (%s): глиф не как в его образце"
                                % (s, "кик" if kind == 0 else "хэт"))

# снейр: внешний край его, внутри вырез 4 x 4 — ровно намеченное изменение
for s, kind in enumerate(SAMPLE):
    if kind != 1:
        continue
    col, row = s % 4, s // 4
    for ly in range(GLYPH):
        for lx in range(GLYPH):
            y = ORIGIN + row * CELL + ly
            x = ORIGIN + col * CELL + lx
            if mine[y][x] and not his[y][x]:
                problems.append("шаг %d: у ромба появились пиксели вне его края" % s)
            if his[y][x] and not mine[y][x] and not (2 <= lx <= 5 and 2 <= ly <= 5):
                problems.append("шаг %d: у ромба стёрто не только нутро" % s)

# --- 2. глифы различимы между собой ------------------------------------------
masks = {k: cell_mask(k) for k in range(5)}
for a in range(5):
    if not any(any(r) for r in masks[a]):
        problems.append("глиф %d пустой" % a)
    for b in range(a + 1, 5):
        if masks[a] == masks[b]:
            problems.append("глифы %d и %d совпадают" % (a, b))

# --- 3. таблица грувов и приоритет -------------------------------------------
text = APP[APP.index("static const perc_groove_t s_perc_grooves"):]
text = text[:text.index("\n};")]
rows = re.findall(r"\{\s*\{\s*(0x[0-9A-Fa-f]+)\s*,\s*(0x[0-9A-Fa-f]+)\s*,\s*(0x[0-9A-Fa-f]+)\s*,"
                  r"\s*(0x[0-9A-Fa-f]+)\s*\},\s*(0x[0-9A-Fa-f]+),", text)
if len(rows) != 24:
    problems.append("грувов в таблице %d, а должно 24" % len(rows))

seen = set()
for n, (kick, snare, hat, tom, ghost) in enumerate(rows):
    masks_row = [int(kick, 16), int(snare, 16), int(hat, 16), int(tom, 16), int(ghost, 16)]
    kinds = []
    for s in range(16):
        bit = 1 << s
        kind = -1
        for lane, mask in enumerate(masks_row):
            if mask & bit:
                kind = lane
                break
        kinds.append(kind)
    if all(k < 0 for k in kinds):
        problems.append("грув %d пустой" % (n + 1))
    seen.update(k for k in kinds if k >= 0)
    g = draw(kinds)
    if sum(map(sum, g)) < 60:
        problems.append("грув %d: чернил всего %d" % (n + 1, sum(map(sum, g))))

if seen != {0, 1, 2, 3, 4}:
    problems.append("в рисунке не встречаются глифы: %s" % sorted(seen))

# --- 4. где взят рисунок -----------------------------------------------------
if "void synth_app_groove_pattern(int index, uint16_t out[4], uint16_t *ghost);" not in APPH:
    problems.append("нет объявления synth_app_groove_pattern в заголовке приложения")
if "extern \"C\" void synth_app_groove_pattern" not in APP:
    problems.append("нет определения synth_app_groove_pattern")

if "PREVIEW_GROOVE" not in HDR:
    problems.append("нет вида PREVIEW_GROOVE в заголовке")

sw = SRC[SRC.index("static synth_preview_kind_t pv_values"):]
sw = sw[:sw.index("\n}\n")]
LABELS, pending = {}, []
for mm in re.finditer(r"case (SYNTH_PARAM_\w+):|return (PREVIEW_\w+);", sw):
    if mm.group(1):
        pending.append(mm.group(1))
    else:
        for label in pending:
            LABELS.setdefault(label, mm.group(2))
        pending = []

if LABELS.get("SYNTH_PARAM_PERC_GROOVE") != "PREVIEW_GROOVE":
    problems.append("PERC_GROOVE отдаёт %s, а должен PREVIEW_GROOVE"
                    % LABELS.get("SYNTH_PARAM_PERC_GROOVE"))

if not re.search(r"case PREVIEW_GROOVE:\s*pv_groove\(", SRC):
    problems.append("нет вызова pv_groove в переключателе")

ox = SRC[SRC.index("static int pv_ox_for"):SRC.index("static int pv_oy_for")]
if "case PREVIEW_GROOVE:" not in ox:
    problems.append("PREVIEW_GROOVE не в списке нулевого сдвига")

# приоритет в самом коде прошивки: кик раньше снейра, снейр раньше хэта, хэт раньше тома
order = re.search(r"pv_groove.*?lane\[0\].*?lane\[1\].*?lane\[2\].*?lane\[3\].*?ghost",
                  SRC, re.S)
if not order:
    problems.append("в pv_groove не видно порядка КИК, СНЕЙР, ХЭТ, ТОМ, ПРИЗРАК")

if problems:
    print("FAIL: фигура GROOVE")
    for p in problems:
        print("  -", p)
    sys.exit(1)

print("OK: GROOVE — шестнадцать шагов сеткой 4 x 4, клетка 10 px, глиф 8: круг КИК, "
      "ромб-обводка СНЕЙР, квадрат ХЭТ, малый ромб ТОМ, квадрат 2 x 2 ПРИЗРАК; приоритет "
      "КИК > СНЕЙР > ХЭТ > ТОМ > ПРИЗРАК, двадцать четыре рисунка читаются из таблицы "
      "прошивки, круг и квадрат совпадают с образцом владельца точка в точку")
