"""Гейт фигур посыла: кольца реверба, ромбы дилея, капсулы хоруса.

Проверяет, что в прошивке те же числа, что сняты с кадров владельца 1:1, что
фигура меняется ступенями по четверти, что линии не слипаются и что новые виды
достались только ручкам MIX — сами эффекты и их прочие ручки остались на своих
фигурах.
"""
import re
import sys

sys.stdout.reconfigure(encoding="utf-8")

SRC = "components/synth_ui/src/synth_ui_preview.c"
HDR = "components/synth_ui/src/synth_ui_preview.h"

src = open(SRC, encoding="utf-8").read()
hdr = open(HDR, encoding="utf-8").read()
problems = []

VERB = [20, 16, 12, 8, 4]
DELAY = [5, 10, 15, 20, 25]
CHORUS_P = [0, 10, 16, 18, 20]
CAP_R = 11
CAP_T = CAP_L = 7
CAP_B = CAP_RT = 49


def table(name, count, expect):
    m = re.search(r"static const uint8_t %s\[\w+\] = \{([^}]*)\}" % name, src)
    if not m:
        problems.append("нет таблицы %s" % name)
        return None
    got = [int(v) for v in re.findall(r"\d+", m.group(1))]
    if len(got) != count:
        problems.append("%s: %d чисел, ждали %d" % (name, len(got), count))
    if got != expect:
        problems.append("%s = %s, ждали %s" % (name, got, expect))
    return got


# --- признаки видов ----------------------------------------------------------
for kind in ("PREVIEW_VERB_SECTOR", "PREVIEW_DELAY_SECTOR", "PREVIEW_CHORUS_SECTOR"):
    if kind not in hdr:
        problems.append("в заголовке нет вида %s" % kind)
    elif kind not in src:
        problems.append("вид %s объявлен, но нигде не используется" % kind)

# ключ кеша: вид вырос до шести бит
if not re.search(r"\(v\.active & 0x03u\) << 6", src):
    problems.append("ключ кеша не сдвинут под шесть бит вида: старшие виды столкнутся")
if not re.search(r"<< \(8 \+ 6 \* i\)", src):
    problems.append("значения в ключе не сдвинуты вслед за видом")

# --- какие ручки получили фигуру ---------------------------------------------
# Ветки pv_values склеены: у нескольких ручек общий return. Поэтому идём по
# switch подряд и каждую метку case относим к тому виду, который встретится
# следующим.
sw = src[src.index("static synth_preview_kind_t pv_values"):]
sw = sw[:sw.index("\n}\n")]
LABELS = {}
pending = []
for m in re.finditer(r"case (SYNTH_PARAM_\w+):|return (PREVIEW_\w+);", sw):
    if m.group(1):
        pending.append(m.group(1))
    else:
        for label in pending:
            LABELS.setdefault(label, m.group(2))
        pending = []


def mapping(param):
    if param not in LABELS:
        problems.append("pv_values: нет ветки %s" % param)
        return None
    return LABELS[param]


# Фигуры живут на страницах посылов: по пять секторов на эффект.
SECTIONS = {
    "PREVIEW_VERB_SECTOR": tuple("SYNTH_PARAM_SEND_%s" % s
                                 for s in ("LEAD", "PERC", "LOW", "MID", "HIGH")),
    "PREVIEW_DELAY_SECTOR": tuple("SYNTH_PARAM_DLY_SEND_%s" % s
                                  for s in ("LEAD", "PERC", "LOW", "MID", "HIGH")),
    "PREVIEW_CHORUS_SECTOR": tuple("SYNTH_PARAM_CHR_SEND_%s" % s
                                   for s in ("LEAD", "PERC", "LOW", "MID", "HIGH")),
}
for kind, params in SECTIONS.items():
    for param in params:
        got = mapping(param)
        if got != kind:
            problems.append("%s отдаёт %s, а весь раздел посыла должен показывать %s"
                            % (param, got, kind))

# эффекты не тронуты: у них свои фигуры и своих фигур посыла быть не должно
EFFECTS = {
    "SYNTH_PARAM_VERB_MIX": "PREVIEW_NONE",
    "SYNTH_PARAM_VERB_SIZE": "PREVIEW_VERB_SIZE",
    "SYNTH_PARAM_VERB_DAMP": "PREVIEW_VERB_DAMP",
    "SYNTH_PARAM_VERB_MODE": "PREVIEW_VERB_MODE",
    "SYNTH_PARAM_DELAY_MIX": "PREVIEW_NONE",
    "SYNTH_PARAM_DELAY_FEEDBACK": "PREVIEW_DELAY_FEEDBACK",
    "SYNTH_PARAM_DELAY_TIME": "PREVIEW_NONE",
    "SYNTH_PARAM_DELAY_SYNC": "PREVIEW_NONE",
    "SYNTH_PARAM_DELAY_TIMEMODE": "PREVIEW_DELAY_MODE",
    "SYNTH_PARAM_CHORUS_RATE": "PREVIEW_CHORUS_RATE",
    "SYNTH_PARAM_CHORUS_DEPTH": "PREVIEW_CHORUS_DEPTH",
}
for param, kind in EFFECTS.items():
    got = mapping(param)
    if got != kind:
        problems.append("%s отдаёт %s, а фигура эффекта должна остаться %s"
                        % (param, got, kind))

# и фигуры эффектов, и их код на месте
for fn in ("pv_verb_damp(", "pv_verb_mode(", "pv_delay(", "pv_delay_mode(", "pv_delay_sync(",
           "pv_chorus("):
    if not re.search(r"static void %s" % re.escape(fn), src):
        problems.append("пропала фигура эффекта %s" % fn.rstrip("("))

# --- лестницы ----------------------------------------------------------------
verb = table("PV_SEND_VERB_R", 5, VERB)
delay = table("PV_SEND_DELAY_R", 5, DELAY)
chorus_p = table("PV_SEND_CHORUS_P", 5, CHORUS_P)

if verb:
    if any(a - b != 4 for a, b in zip(verb, verb[1:])):
        problems.append("кольца стоят не через четыре: %s" % verb)
    if verb[0] != 20 or verb[-1] != 4:
        problems.append("кольца не от 20 до 4: %s" % verb)

if delay:
    if any(b - a < 5 for a, b in zip(delay, delay[1:])):
        problems.append("ромбы ближе пяти пикселей: %s" % delay)
    # штрих три пикселя: между соседними ромбами обязано остаться два пикселя воздуха
    # штрих полосы — плюс-минус пиксель, поэтому воздух между ромбами это
    # (b - 1) - (a + 1); меньше двух быть не должно
    for a, b in zip(delay, delay[1:]):
        if (b - a) - 2 < 2:
            problems.append("между ромбами %d и %d меньше двух пикселей воздуха" % (a, b))
    if delay[0] != 5 or delay[-1] != 25:
        problems.append("ромбы не от 5 до 25: %s" % delay)

if chorus_p:
    if chorus_p != sorted(chorus_p):
        problems.append("сдвиг капсул не растёт: %s" % chorus_p)
    if chorus_p[0] != 0:
        problems.append("на нуле капсулы должны совпадать, сдвиг %d" % chorus_p[0])
    if chorus_p[-1] + CAP_L > CAP_RT - CAP_L:
        problems.append("на сотне капсулы проходят друг сквозь друга")

# --- капсула -----------------------------------------------------------------
m = re.search(r"#define PV_SEND_CAP_R (\d+)", src)
if not m or int(m.group(1)) != CAP_R:
    problems.append("радиус угла капсулы не %d (снят с кадров)" % CAP_R)
for name, want in (("PV_SEND_CAP_T", CAP_T), ("PV_SEND_CAP_B", CAP_B),
                   ("PV_SEND_CAP_L", CAP_L), ("PV_SEND_CAP_RT", CAP_RT)):
    m = re.search(r"#define %s (\d+)" % name, src)
    if not m or int(m.group(1)) != want:
        problems.append("%s не %d" % (name, want))

tail = src[src.index("static void pv_send_chorus"):]
tail = tail[:tail.index("\n}\n")]
if "x0 + 4" not in tail or "x1 - 4" not in tail:
    problems.append("штрих капсулы не два пикселя внутрь (ждём x0 + 4, x1 - 4 в удвоенных)")
if "PV_SEND_CAP_R - 2" not in tail:
    problems.append("внутренний радиус капсулы не на два меньше внешнего")

# --- ступени и рисование -----------------------------------------------------
if not re.search(r"pv_div_round\(q \* 4, 50\)", src):
    problems.append("нет ступеней по четверти: ждали pv_div_round(q * 4, 50)")

ring = src[src.index("static void pv_send_verb"):src.index("static void pv_send_delay")]
if "hypot" in ring or "sqrt" in ring:
    problems.append("в кольцах появился корень: считаем квадраты расстояний")
diam = src[src.index("static void pv_send_delay"):src.index("static bool pv_send_rr_in")]
if "hypot" in diam or "sqrt" in diam:
    problems.append("в ромбах появился корень")

# фигуры обязаны рисовать в области 44x44 и без общего сдвига
if not re.search(r"case PREVIEW_VERB_SECTOR:[^\n]*\n[^\n]*case PREVIEW_DELAY_SECTOR:[^\n]*\n"
                 r"[^\n]*case PREVIEW_CHORUS_SECTOR:[^\n]*\n[^\n]*return 0;", src):
    problems.append("новые виды не получили нулевой сдвиг: фигура уедет с центра")

for call, fn in (("PREVIEW_VERB_SECTOR", "кольца"),
                 ("PREVIEW_DELAY_SECTOR", "ромбы"),
                 ("PREVIEW_CHORUS_SECTOR", "капсулы")):
    if call not in src:
        problems.append("вид %s не вызывает свою фигуру (%s)" % (call, fn))

if problems:
    print("FAIL: фигуры посыла разошлись с прошивкой")
    for p in problems:
        print("  - " + p)
    sys.exit(1)

print("OK: разделы посыла — реверб кольца 20/16/12/8/4, дилей ромбы 5/10/15/20/25 "
      "с шагом пять (между линиями два пикселя), хорус капсулы радиусом 11 сходятся "
      "с 0 до 20; фигура у всех пяти секторов каждого раздела посылов, "
      "а страницы эффектов остались со своими фигурами")
