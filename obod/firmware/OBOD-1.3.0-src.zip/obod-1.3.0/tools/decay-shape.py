"""Фигура DECAY: огибающая одного удара.

Здесь повторена арифметика прошивки и сверены его четыре кадра. Его наклон нарисован рукой —
ступенями через четыре, четыре, четыре, четыре, четыре, четыре, три, четыре строки, и в четырёх
местах посреди наклона линия у него на пиксель толще; прошивка рисует ровную целочисленную
линию, поэтому кадры сходятся не точка в точку, а с допуском, который здесь и записан.
"""
import io
import re
import sys

sys.stdout.reconfigure(encoding="utf-8")

SRC = io.open("components/synth_ui/src/synth_ui_preview.c", encoding="utf-8").read()
HDR = io.open("components/synth_ui/src/synth_ui_preview.h", encoding="utf-8").read()

problems = []

ART = 44

# Его кадры: доля хода -> маска
HIS = {
    0: (
                "0000000000000000000000600000000006000000000070000000000700000000007000000000070000000000"
        "780000000007800000000078000000000780000000006c0000000006c0000000006c0000000006e000000000"
        "6600000000066000000000660000000006700000000063000000000630000000006300000000063800000000"
        "61800000000618000000006180000000061c0000000060c0000000060c0000000060c0000000060600000000"
        "6060000000060600000000606000000006030000000060300000000603000000006030000000060180000000"
        "ffffffffffffffffffffff0000000000000000000000"
    ),
    333: (
                "000000000007ff800000007ff8000000060180000000600c0000000600c0000000600c0000000600c0000000"
        "6006000000060060000000600600000006006000000060030000000600300000006003000000060038000000"
        "6001800000060018000000600180000006001c0000006000c0000006000c0000006000c0000006000e000000"
        "6000600000060006000000600060000006000700000060003000000600030000006000300000060001800000"
        "60001800000600018000006000180000060000c0000060000c0000060000c0000060000c0000060000600000"
        "ffffffffffffffffffffff0000000000000000000000"
    ),
    667: (
                "000000000007ffffe000007ffffe000006000060000060000300000600003000006000030000060000300000"
        "60000180000600001800006000018000060000180000600000c0000600000c0000600000c0000600000e0000"
        "6000006000060000060000600000600006000007000060000030000600000300006000003000060000038000"
        "6000001800060000018000600000180006000001c0006000000c0006000000c0006000000c00060000006000"
        "6000000600060000006000600000060006000000300060000003000600000030006000000300060000001800"
        "ffffffffffffffffffffff0000000000000000000000"
    ),
    1000: (
                "000000000007fffffff8007fffffff8006000000180060000000c0060000000c0060000000c0060000000c00"
        "6000000060060000000600600000006006000000060060000000300600000003006000000030060000000380"
        "600000001806000000018060000000180600000001c0600000000c0600000000c0600000000c0600000000e0"
        "6000000006060000000060600000000606000000007060000000030600000000306000000003060000000018"
        "6000000001860000000018600000000186000000000c6000000000c6000000000c6000000000c60000000006"
        "ffffffffffffffffffffff0000000000000000000000"
    ),
}

TOLERANCE = 12      # пикселей на кадр: наклон у него ступенчатый и местами толще


def unpack(hexstr):
    bits = "".join(format(b, "08b") for b in bytes.fromhex(hexstr))
    if len(bits) != ART * ART:
        problems.append("маска не 44x44: %d бит" % len(bits))
    return [[1 if bits[y * ART + x] == "1" else 0 for x in range(ART)] for y in range(ART)]


def num(name):
    m = re.search(r"#define\s+%s\s+\(?(-?\d+)" % name, SRC)
    if not m:
        problems.append("нет константы %s" % name)
        return 0
    return int(m.group(1))


BASE0 = num("PV_DC_BASE0")
BASE1 = num("PV_DC_BASE1")
TOP0 = num("PV_DC_TOP0")
WALL = num("PV_DC_WALL")
WALL_BOT = num("PV_DC_WALL_BOT")
SLOPE0 = num("PV_DC_SLOPE0")
RUN = num("PV_DC_RUN")
SPAN = num("PV_DC_SPAN")
SHELF_MIN = num("PV_DC_SHELF_MIN")


def shelf(q):
    return SHELF_MIN + (6 * q + 5) // 10


def frame(q):
    p = shelf(q)
    g = [[0] * ART for _ in range(ART)]

    for y in (BASE0, BASE1):
        for x in range(ART):
            g[y][x] = 1

    for y in range(TOP0, WALL_BOT + 1):
        g[y][WALL] = 1
        g[y][WALL + 1] = 1

    for y in range(TOP0, TOP0 + 2):
        for x in range(WALL, p + 1):
            g[y][x] = 1

    for y in range(SLOPE0, WALL_BOT + 1):
        left = p - 1 + ((y - SLOPE0) * RUN + SPAN // 2) // SPAN
        g[y][left] = 1
        g[y][left + 1] = 1
    return g


def ink(g):
    return sum(map(sum, g))


# --- 1. его кадры -------------------------------------------------------------
for t, hexstr in sorted(HIS.items()):
    his = unpack(hexstr)
    q = t * 50 // 1000
    mine = frame(q)
    diff = sum(1 for y in range(ART) for x in range(ART) if mine[y][x] != his[y][x])
    if diff > TOLERANCE:
        problems.append("доля %d: %d точек расхождения, а допуск %d" % (t, diff, TOLERANCE))
    if ink(mine) - ink(his) not in range(-TOLERANCE, TOLERANCE + 1):
        problems.append("доля %d: чернил %d против его %d" % (t, ink(mine), ink(his)))

# --- 2. полка только растёт, наклон всегда тот же -----------------------------
shelves = [shelf(q) for q in range(0, 51)]
if shelves != sorted(shelves):
    problems.append("полка где-то укоротилась")
if shelves[0] != SHELF_MIN or shelves[-1] != 32:
    problems.append("полка идёт %d..%d, а должна %d..32" % (shelves[0], shelves[-1], SHELF_MIN))

for q in range(0, 51):
    g = frame(q)
    p = shelf(q)
    # подвал на месте во всю ширину
    if any(g[BASE0][x] != 1 or g[BASE1][x] != 1 for x in range(ART)):
        problems.append("q=%d: подвал не во всю ширину" % q)
    # стенка на месте
    if any(g[y][WALL] != 1 or g[y][WALL + 1] != 1 for y in range(TOP0, WALL_BOT + 1)):
        problems.append("q=%d: стенка с дыркой" % q)
    # нижний конец наклона стоит на подвале и не вылезает из поля
    foot = p - 1 + ((WALL_BOT - SLOPE0) * RUN + SPAN // 2) // SPAN
    if foot + 1 >= ART:
        problems.append("q=%d: наклон вылезает за поле, нога на %d" % (q, foot))
    if g[WALL_BOT][foot] != 1 or g[WALL_BOT][foot + 1] != 1:
        problems.append("q=%d: наклон не стоит на подвале" % q)
    # верхний конец наклона примыкает к полке
    head = p - 1 + ((SLOPE0 - SLOPE0) * RUN + SPAN // 2) // SPAN
    if g[SLOPE0][head] != 1:
        problems.append("q=%d: наклон не примыкает к полке" % q)
    # наклон непрерывен по строкам
    prev = head
    for y in range(SLOPE0, WALL_BOT + 1):
        now = p - 1 + ((y - SLOPE0) * RUN + SPAN // 2) // SPAN
        if now < prev or now - prev > 1:
            problems.append("q=%d: наклон рвётся на строке %d" % (q, y))
        prev = now

# --- 3. провод ----------------------------------------------------------------
DISPATCH = SRC[SRC.index("static synth_preview_kind_t pv_values"):]
DISPATCH = DISPATCH[:DISPATCH.index("\n}\n")]
LABELS, pending = {}, []
for mm in re.finditer(r"case (SYNTH_PARAM_\w+):|return (PREVIEW_\w+);", DISPATCH):
    if mm.group(1):
        pending.append(mm.group(1))
    else:
        for label in pending:
            LABELS.setdefault(label, mm.group(2))
        pending = []

if LABELS.get("SYNTH_PARAM_PERC_LENGTH") != "PREVIEW_PERC_LENGTH":
    problems.append("PERC_LENGTH отдаёт %s, а должен PREVIEW_PERC_LENGTH"
                    % LABELS.get("SYNTH_PARAM_PERC_LENGTH"))
if "PREVIEW_PERC_LENGTH" not in HDR:
    problems.append("нет вида PREVIEW_PERC_LENGTH в заголовке")
if not re.search(r"case PREVIEW_PERC_LENGTH:\s*pv_perc_length\(", SRC):
    problems.append("нет вызова pv_perc_length в переключателе")
ox = SRC[SRC.index("static int pv_ox_for"):SRC.index("static int pv_oy_for")]
if "case PREVIEW_PERC_LENGTH:" not in ox:
    problems.append("PREVIEW_PERC_LENGTH не в списке нулевого сдвига")
if "const int p = PV_DC_SHELF_MIN + (6 * (int)v->q[0] + 5) / 10;" not in SRC:
    problems.append("в pv_perc_length не та арифметика полки")

if problems:
    print("FAIL: фигура DECAY")
    for p in problems:
        print("  -", p)
    sys.exit(1)

worst = 0
for t, hexstr in sorted(HIS.items()):
    his = unpack(hexstr)
    mine = frame(t * 50 // 1000)
    worst = max(worst, sum(1 for y in range(ART) for x in range(ART) if mine[y][x] != his[y][x]))

print("OK: DECAY — огибающая одного удара; подвал, стенка и полка на месте на всех 51 "
      "положениях, полка идёт %d..%d, наклон непрерывен и стоит на подвале; его четыре кадра "
      "сходятся с допуском %d пикселей, худший кадр расходится на %d"
      % (shelves[0], shelves[-1], TOLERANCE, worst))
