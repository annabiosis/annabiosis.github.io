"""PUNCH: ручки BODY больше нет — ни на странице PERC, ни приёмником модуляции.

Ручку BODY на странице PERC заменил PUNCH, а приёмник модуляции остался прежним: в списке
DEST стояло BODY, и модуляция двигала тело кита — то, чего на экране больше нет. Проверка
держит три вещи:

  * в таблице приёмников нет BODY, есть PUNCH и три пары с ним, порядок и число те же;
  * модуляция двигает атаку удара, а не тело кита: приём идёт через указатель на PUNCH,
    который читается в момент удара, и в перкуссионный голос уходит он же;
  * витрина и тексты называют ручку так же, как прошивка: таблица DEST в web/assets/ref.js
    совпадает с MOD_DESTS по составу и порядку, перечни ручек страницы PERC — с KNOBS_PERC,
    а в абзацах про страницу и на схеме сигнала стоит PUNCH.

История выпусков (CHANGELOG.md, docs/RELEASE-NOTES*) не сверяется: там BODY — то, что было в
выпуске, и переписывать прошлое проверка не даёт.

Run: python tools/punch-dest.py
"""
import re
import sys

sys.stdout.reconfigure(encoding="utf-8")

APP = "components/synth_app/src/synth_app.cpp"
UI = "components/synth_ui/src/synth_ui.c"
REF = "web/assets/ref.js"
RINGS = "tools/promo-rings.js"
PROMO = "tools/promo-check.js"
FAIL = []


def fail(msg):
    FAIL.append(msg)


def ok(msg):
    print("  " + msg)


def read(p):
    return open(p, encoding="utf-8", errors="replace").read()


src = read(APP)

print("1. таблица приёмников")
block = src[src.index("static const mod_dest_t MOD_DESTS[]"):]
block = block[:block.index("};")]
dests = [(m.group(1), m.group(2)) for m in
         re.finditer(r'\{\s*"([^"]+)"\s*,\s*([A-Z_ |]+?)\s*\}', block)]
if len(dests) != 18:
    fail("приёмников %d вместо восемнадцати" % len(dests))
names = [n for n, _ in dests]
for bad in [n for n in names if "BODY" in n]:
    fail("в приёмниках остался %s" % bad)
for want in ("PUNCH", "PUNCH+PIT", "PUNCH+DEC", "LEAD+PNCH", "PAN+PNCH"):
    if want not in names:
        fail("нет приёмника %s" % want)
if names[-1] != "ALL":
    fail("последний приёмник %s, а не ALL" % names[-1])
if not re.search(r"MD_PUNCH\s*=\s*1u\s*<<\s*6", src):
    fail("бит MD_PUNCH не на шестом месте — значит, сдвинулись чужие")
if "MD_BODY" in src:
    fail("в прошивке остался бит MD_BODY")
ok("приёмников %d, из них пять про атаку: %s" %
   (len(dests), ", ".join(n for n in names if "PUNCH" in n or "PNCH" in n)))

print("2. маршрутизация: атака, а не тело кита")
block = src[src.index("static void perc_apply_mod"):]
block = block[:block.index("\n}\n")]
if "float *punch01" not in block:
    fail("perc_apply_mod не принимает PUNCH")
if "bits & (MD_PITCH | MD_ENV | MD_DEC | MD_PUNCH)" not in block:
    fail("ранний выход не знает про PUNCH")
if "*punch01 = clamp01f(*punch01 + depth * 0.3f);" not in block:
    fail("модуляция не двигает атаку")
if "r->body" in block:
    fail("модуляция всё ещё двигает тело кита")
strike = src[src.index("static void perc_strike(int lane, float velocity01)"):]
strike = strike[:strike.index("\n}\n")]
if strike.index("float punch01 = perc_punch01();") > strike.index("perc_apply_mod(&r, &punch01);"):
    fail("PUNCH читается после модуляции — удар получит значение ручки, а не приёмника")
if "r.body,\n                   punch01);" not in strike:
    fail("в голос уходит не модулированная атака")
ok("приёмник — PUNCH, и он же уходит в голос")

print("3. витрина называет ручку так же")
ref = read(REF)
dest_block = ref[ref.index("['DEST',"):]
dest_block = dest_block[:dest_block.index("]],")]
# Первое имя — сама ручка DEST, дальше её позиции в том же порядке, что в MOD_DESTS.
site_dests = re.findall(r"\['([A-Z0-9+ ]+)',", dest_block)[1:]
if site_dests != names:
    for i, (a, b) in enumerate(zip(site_dests, names)):
        if a != b:
            fail("приёмник %d: на витрине %s, в прошивке %s" % (i + 1, a, b))
            break
    if len(site_dests) != len(names):
        fail("на витрине %d приёмников, в прошивке %d" % (len(site_dests), len(names)))

ui = read(UI)
knobs = re.search(r"static const ui_knob_t KNOBS_PERC\[\]\s*=\s*\{([\s\S]*?)\n\};", ui).group(1)
knob_names = re.findall(r'\{\s*"([^"]+)"', knobs)

perc_page = ref[ref.index("n: 'PERC', tag: 'PERC'"):]
perc_page = perc_page[:perc_page.index("n: 'PERC SEQ'")]
site_knobs = re.findall(r"^      \['([A-Z0-9 .%+-]+)',", perc_page, re.M)
if site_knobs != knob_names:
    fail("ручки PERC на витрине %s, в прошивке %s" % (site_knobs, knob_names))

rings = read(RINGS)
m = re.search(r"\{ t: 'PERC',[^}]*?k: \[([^\]]*)\]", rings)
if not m:
    fail("в tools/promo-rings.js нет страницы PERC")
else:
    ring_knobs = re.findall(r"'([^']+)'", m.group(1))
    if ring_knobs != knob_names:
        fail("витрина колец: ручки PERC %s, в прошивке %s" % (ring_knobs, knob_names))

promo = read(PROMO)
m = re.search(r"\[\s*'PERC',\s*\[([^\]]*)\]", promo)
if not m:
    fail("в tools/promo-check.js нет перечня PERC")
else:
    promo_knobs = re.findall(r"'([^']+)'", m.group(1))
    if promo_knobs != knob_names:
        fail("promo-check: ручки PERC %s, в прошивке %s" % (promo_knobs, knob_names))
ok("DEST, ручки PERC, кольца и promo-check — по прошивке")

print("4. тексты и схема")
texts = {
    "FEATURES.md": read("FEATURES.md"),
    "FEATURES.en.md": read("FEATURES.en.md"),
    "web/ref-perc.html": read("web/ref-perc.html"),
    "tools/promo-rings.js": rings,
    "docs/signal-chain/obod-signal-chain.mmd": read("docs/signal-chain/obod-signal-chain.mmd"),
    "web/under.html": read("web/under.html"),
}
# Единственное место, где старое имя остаётся, — абзац про старые ручки: они и есть прошлое.
OLD = r"\*\*(?:Старые ручки удара|The old hit knobs)\*\*[\s\S]*?(?=\n- \*\*)"
for path in ("FEATURES.md", "FEATURES.en.md"):
    m = re.search(OLD, texts[path])
    if not m:
        fail("%s: не нашёл абзаца про старые ручки" % path)
    elif "PUNCH" not in m.group(0):
        fail("%s: в абзаце про старые ручки нет PUNCH — читатель не узнает, куда делось BODY" % path)
    texts[path] = re.sub(OLD, "", texts[path])
for path, text in texts.items():
    if re.search(r"BODY\b", text):
        where = [ln.strip()[:80] for ln in text.split("\n") if re.search(r"BODY\b", ln)]
        fail("%s всё ещё говорит BODY: %s" % (path, where[:2]))
for path in ("FEATURES.md", "FEATURES.en.md", "web/ref-perc.html", "tools/promo-rings.js"):
    if "PUNCH" not in texts[path]:
        fail("%s не называет PUNCH" % path)
if "PITCH/ENV/DECAY/PUNCH" not in texts["web/under.html"]:
    fail("схема сигнала на странице не знает PUNCH")
if "атака удара" not in perc_page:
    fail("описание страницы PERC на витрине не говорит, что делает PUNCH")
ok("абзацы, витрина и схема перешли на PUNCH")

print()
if FAIL:
    for f in FAIL:
        print("ПРОВАЛ: " + f)
    sys.exit(1)
print("PUNCH: всё сходится")
