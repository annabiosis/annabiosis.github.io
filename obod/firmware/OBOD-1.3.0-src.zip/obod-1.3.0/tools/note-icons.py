"""Иконки списка NOTE: прошивка против двенадцати картинок владельца.

Двенадцать иконок лежат одной таблицей PV_NOTE_ICONS[12][44 * 6] в порядке списка —
C, C#, D, D#, E, F, F#, G, G#, A, A#, B. Гейт собирает их обратно в маски, сверяет с
файлами точка в точку, проверяет порядок, ширину каждой иконки и то, что вид подключён
к SYNTH_PARAM_ROOT с нулевым сдвигом: иконка должна стоять там, где её нарисовали, а не
съезжать с поля.
"""
import io
import re
import sys
from pathlib import Path

from PIL import Image

sys.stdout.reconfigure(encoding="utf-8")

SRC = Path("components/synth_ui/src/synth_ui_preview.c")
HDR = Path("components/synth_ui/src/synth_ui_preview.h")
APP = Path("components/synth_app/src/synth_app.cpp")

SRC_T = SRC.read_text(encoding="utf-8")
HDR_T = HDR.read_text(encoding="utf-8")
APP_T = APP.read_text(encoding="utf-8")

ART = 44
NAMES = ("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
HASH = ("452edfc8c951c6eeef7866ddddce509294e650c1792929832951c8eff4ac867f",
        "55a94fe55c5105d9db7f1b23d3ca30a0a971b830ff9005952b04beaebfeb1322",
        "84ea036bd2fabd2e82e7fe613523f3fe53a8361b5108c681cea8861384b78949",
        "6a2a0bacddd282d06a29e6ade9f0a81cef8f2a5ba4175e7e9463c7eea31683c4",
        "cc1b7046656ae3c42d14411623701f705c7b242281ce7a58c2da63cb3698afe4",
        "bf234cf24a0ff93515758fcdf548e678da14e9f81fa643b5b9dcb5aa5bdb9a99",
        "886d7c6c37e3b3c9f419c93a2653d0ee3803e58d509ed05f3ac32749fcc81d86",
        "4c4ea96dc7ae781dfcb41ae31e60ff5cd8d1cf0cebd3b0bf800e9cd51a6757cc",
        "5fe88d401668cb8f1a9a47019f39ae3029ef9f4631a26f63d96dfd7f97d0d3d6",
        "b8960a9008ae890b9f16670d6d24c3e1b07d53ad943409c25cec8851af5a8990",
        "70ff88de022557dc4e7c230beb31885aa4e16c9127b64bc73ff0e0348f696b2f",
        "0ad00084bcbe94a18a4289ec88939606d3c270da3f0eaccc4dc417c46fde1724")
BASE_DIR = Path(r"C:\Users\Blaq\.dsh\attachments\v1\objects")

# Ширина фигуры по порядку списка: раскрывается от C к E, стоит во всё поле до G и
# закрывается к B. Это и есть «динамика» набора, которую владелец смотрел ползунком.
WIDTHS = (26, 33, 38, 43, 44, 44, 44, 44, 43, 38, 33, 26)

problems = []


def icon(name):
    img = Image.open(str(BASE_DIR / HASH[NAMES.index(name)][:2] / HASH[NAMES.index(name)]))
    px = img.convert("L").load()
    return [[1 if px[x, y] > 110 else 0 for x in range(ART)] for y in range(ART)]


def firmware():
    m = re.search(r"PV_NOTE_ICONS\[12\]\[44 \* 6\]\s*=\s*\{(.*?)\n\};", SRC_T, re.S)
    if not m:
        problems.append("нет таблицы PV_NOTE_ICONS[12][44 * 6]")
        return []
    parts = re.findall(r"\{\s*/\*\s*([A-G]#?)\s*\*/(.*?)\},", m.group(1), re.S)
    if len(parts) != 12:
        problems.append("в таблице %d иконок, а нужно 12" % len(parts))
    out = []
    for name, body in parts:
        vals = [int(v, 16) for v in re.findall(r"0x([0-9A-Fa-f]{2})", body)]
        if len(vals) != ART * 6:
            problems.append("%s: байт %d, а нужно %d" % (name, len(vals), ART * 6))
            continue
        g = [[0] * ART for _ in range(ART)]
        for y in range(ART):
            for b in range(6):
                for k in range(8):
                    x = b * 8 + k
                    if x < ART and vals[y * 6 + b] & (0x80 >> k):
                        g[y][x] = 1
        out.append((name, g))
    return out


def width(g):
    xs = [x for x in range(ART) if any(g[y][x] for y in range(ART))]
    return (max(xs) - min(xs) + 1) if xs else 0


def diff(a, b):
    return sum(1 for y in range(ART) for x in range(ART) if a[y][x] != b[y][x])


fw = firmware()

if [n for n, _ in fw] != list(NAMES):
    problems.append("порядок в таблице %s, а список идёт %s"
                    % ([n for n, _ in fw], list(NAMES)))

for name, g in fw:
    want = icon(name)
    d = diff(g, want)
    if d:
        problems.append("%s расходится с картинкой в %d точках" % (name, d))
        continue
    ys = [y for y in range(ART) if any(g[y])]
    if (min(ys), max(ys)) != (2, 41):
        problems.append("%s стоит по строкам %d..%d, а не 2..41" % (name, min(ys), max(ys)))
    if width(g) != WIDTHS[NAMES.index(name)]:
        problems.append("%s шириной %d, а по набору %d"
                        % (name, width(g), WIDTHS[NAMES.index(name)]))

if len(fw) == 12 and not problems:
    steps = [diff(fw[i][1], fw[i + 1][1]) for i in range(11)]
    if min(steps) < 100:
        problems.append("соседние иконки почти одинаковы: %s" % steps)

if not re.search(r"#define\s+PV_NOTE_COUNT\s+12\b", SRC_T):
    problems.append("нет #define PV_NOTE_COUNT 12")

if "PREVIEW_NOTE" not in HDR_T:
    problems.append("нет вида PREVIEW_NOTE в заголовке")

# вид упакован в шесть бит ключа: седьмой бит занят фокусом
m = re.search(r"typedef enum \{(.*?)\}\s*synth_preview_kind_t;", HDR_T, re.S)
if not m:
    problems.append("не нашёл перечисление видов")
else:
    body = re.sub(r"/\*.*?\*/", " ", m.group(1), flags=re.S)
    kinds = re.findall(r"\b(PREVIEW_[A-Z_0-9]+)\b", body)
    if "PREVIEW_NOTE" not in kinds:
        problems.append("PREVIEW_NOTE не в перечислении")
    elif kinds.index("PREVIEW_NOTE") > 63:
        problems.append("PREVIEW_NOTE %d-й, а ключ хранит шесть бит вида"
                        % kinds.index("PREVIEW_NOTE"))

if not re.search(r"case SYNTH_PARAM_ROOT:(?:(?!case ).)*?pv_index\(SYNTH_PARAM_ROOT,\s*"
                 r"PV_NOTE_COUNT\)(?:(?!case ).)*?return PREVIEW_NOTE;", SRC_T, re.S):
    problems.append("NOTE не отдаёт PREVIEW_NOTE через pv_index по PV_NOTE_COUNT")

if not re.search(r"case PREVIEW_NOTE:\s*pv_note\(", SRC_T):
    problems.append("нет вызова pv_note в переключателе отрисовки")

if not re.search(r"static void pv_note\(uint8_t \*m, const pv_vals_t \*v\)\s*\{\s*"
                 r"pv_icon\(m, PV_NOTE_ICONS\[v->q\[0\]\]\);", SRC_T):
    problems.append("pv_note не отдаёт иконку позиции списка")

ox = SRC_T[SRC_T.index("static int pv_ox_for"):]
ox = ox[:ox.index("\n}\n")]
if not re.search(r"case PREVIEW_NOTE:[^\n]*\n(?:[^\n]*\n)*?\s*return 0;", ox):
    problems.append("у PREVIEW_NOTE ненулевой сдвиг: иконка съедет с поля")

# порядок списка: индекс 0 — это C, индекс 11 — B
if not re.search(r"12 \* \(oct \+ 2\) \+ note", APP_T):
    problems.append("тоника считается не как 12 * (oct + 2) + note: индекс 0 может быть не C")
if not re.search(r"s_param\[SYNTH_PARAM_ROOT\]\)\s*\*\s*11\.0f", APP_T):
    problems.append("ROOT не считается как 0..11: у списка должно быть двенадцать позиций")

if problems:
    print("FAIL: иконки списка NOTE")
    for p in problems:
        print("  -", p)
    sys.exit(1)

steps = [diff(fw[i][1], fw[i + 1][1]) for i in range(11)]
print("OK: NOTE — двенадцать иконок 44 x 44 в порядке C..B, все совпадают с картинками "
      "точка в точку, строки 2..41, ширина %s; соседние расходятся на %s точек; "
      "вид подключён к SYNTH_PARAM_ROOT с нулевым сдвигом"
      % ("/".join(str(w) for w in WIDTHS), ", ".join(str(s) for s in steps)))
