# Упаковка исходников выпуска для сайта.
#
# Архив собирается не из рабочего дерева, а из самого тега: `git archive` берёт ровно то
# дерево, на которое указывает v<версия>, поэтому в архив не попадают ни `build/`, ни
# `managed_components/`, ни правки, сделанные после тега. Это и есть смысл файла: то, что на
# сайте называется «исходники выпуска», должно совпадать с тем, что помечено тегом, а не с
# тем, что сейчас лежит в рабочей папке.
#
# Готовый образ в архив не входит. В теге он есть — файл `tools/webflash/firmware/OBOD.bin`
# лежит в репозитории, — но архив называется исходниками, а не выпуском, и класть в него
# двоичный образ значит раздавать без кода то, что на странице записи закрыто кодом. Поэтому
# папка firmware исключена из архива целиком: ни открытого образа, ни печати в нём нет.
#
# Архив идёт на сайт без защиты: код выпуска спрашивают только за готовый образ. Поэтому
# рядом с архивом кладётся `sources.json` — версия, размер и SHA-256, — чтобы страница
# называла то же, что и проверка, и чтобы подменённый файл был виден.
#
# Запуск: pwsh -File tools\make-sources.ps1 -Version 1.2.2
[CmdletBinding()]
param(
    [string] $Version = '',
    [string] $Repo = (Join-Path $PSScriptRoot '..')
)

$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.Encoding]::UTF8

$Repo = [IO.Path]::GetFullPath($Repo)
$webflash = Join-Path $PSScriptRoot 'webflash'
$firmware = Join-Path $webflash 'firmware'

if (-not $Version) {
    $cmake = Get-Content (Join-Path $Repo 'CMakeLists.txt') -Raw
    if ($cmake -notmatch 'project\s*\(\s*guition_knob\s+VERSION\s+([0-9]+\.[0-9]+\.[0-9]+)') {
        throw 'не нашёл версию в CMakeLists.txt — задайте её ключом -Version'
    }
    $Version = $Matches[1]
}

$tag = "v$Version"
& git -C $Repo rev-parse --verify --quiet "refs/tags/$tag" | Out-Null
if ($LASTEXITCODE -ne 0) {
    throw "нет тега $tag — выпуск сначала помечается тегом, архив собирается из него"
}

if (-not (Test-Path -LiteralPath $firmware)) {
    New-Item -ItemType Directory -Path $firmware -Force | Out-Null
}

$name = "OBOD-$Version-src.zip"
$zip = Join-Path $firmware $name
$tmp = Join-Path $env:TEMP "obod-$Version-src.zip"
$prefix = "obod-$Version/"

if (Test-Path -LiteralPath $tmp) { Remove-Item -LiteralPath $tmp -Force }
# -o идёт до «--»: после него git считает аргументы путями, и ключ вывода попал бы в архив.
& git -C $Repo archive --format=zip --prefix=$prefix -o $tmp "$tag" -- . ':(exclude)tools/webflash/firmware'
if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $tmp)) {
    throw "git archive не собрал архив тега $tag"
}
Move-Item -LiteralPath $tmp -Destination $zip -Force

# Проверка архива. Открываем его как zip и смотрим, что внутри то, что обещано на странице:
# дерево с корнем по версии, CMakeLists с этой версией, список изменений с ней же в первом
# разделе, закреплённые версии компонентов, описание выпуска и исходник приложения.
Add-Type -AssemblyName System.IO.Compression.FileSystem
$archive = [IO.Compression.ZipFile]::OpenRead($zip)
$names = @($archive.Entries | ForEach-Object { $_.FullName })
$cmakeEntry = $archive.GetEntry($prefix + 'CMakeLists.txt')
$changelogEntry = $archive.GetEntry($prefix + 'CHANGELOG.md')
$cmakeText = ''
$changelogText = ''
if ($cmakeEntry) {
    $reader = New-Object IO.StreamReader($cmakeEntry.Open())
    $cmakeText = $reader.ReadToEnd()
    $reader.Dispose()
}
if ($changelogEntry) {
    $reader = New-Object IO.StreamReader($changelogEntry.Open())
    $changelogText = $reader.ReadToEnd()
    $reader.Dispose()
}
$archive.Dispose()

$problems = @()
if ($names.Count -lt 100) { $problems += "в архиве всего $($names.Count) файлов" }
if (-not $cmakeEntry) { $problems += "нет $($prefix)CMakeLists.txt" }
elseif ($cmakeText -notmatch [regex]::Escape("VERSION $Version")) {
    $problems += "в CMakeLists.txt нет VERSION $Version"
}
if (-not $changelogEntry) { $problems += "нет $($prefix)CHANGELOG.md" }
elseif ($changelogText -notmatch "(?m)^##\s+$([regex]::Escape($Version))\s*$") {
    $problems += "в CHANGELOG.md первым разделом не $Version"
}
foreach ($need in @('dependencies.lock', 'docs/RELEASE-NOTES.md', 'components/synth_app/src/synth_app.cpp')) {
    if (-not ($names -contains ($prefix + $need))) { $problems += "нет $need" }
}
if (@($names | Where-Object { $_.StartsWith($prefix + 'build/') }).Count -gt 0) {
    $problems += 'в архиве есть build/'
}
if (@($names | Where-Object { $_ -match '/firmware/OBOD' }).Count -gt 0) {
    $problems += 'в архиве лежит готовый образ'
}

if ($problems.Count) {
    "ПРОВАЛ: архив не тот, что обещан"
    $problems | ForEach-Object { "  - $_" }
    exit 1
}

$hash = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash
$size = (Get-Item -LiteralPath $zip).Length

$sources = [ordered]@{
    version = $Version
    tag     = $tag
    path    = "firmware/$name"
    size    = $size
    sha256  = $hash
    files   = $names.Count
    note    = 'Исходники выпуска без защиты и без готового образа: код выпуска нужен только образу.'
}
$json = ($sources | ConvertTo-Json -Depth 4)
[IO.File]::WriteAllText((Join-Path $webflash 'sources.json'), $json + "`n", (New-Object Text.UTF8Encoding($false)))

"==> Готово: $zip"
"    версия $Version, файлов $($names.Count), $size байт"
"    SHA-256 $hash"
"sources.json: версия $Version, $size байт, файлов $($names.Count)"
