# -*- coding: utf-8 -*-
"""Картинка -> кадр иконки превью. Печатает строки C и ASCII-проверку.

    python tools/icon2c.py picture.png CHORD

Картинка должна быть 44x44 (или меньше — тогда она выравнивается по центру поля).
Печатает то, что вставляется в таблицу `PV_*_ICONS` в synth_ui_preview.c, и рядом
то же самое, собранное обратно из чисел, чтобы ошибка переноса была видна глазами.
"""
import sys

from PIL import Image

FIELD = 44          # ширина поля, пиксели
ROW_BYTES = 6       # 44 бита в строке, добитые до шести байт (48)


def main(argv):
    if len(argv) < 3:
        raise SystemExit("usage: icon2c.py picture.png NAME")
    path, name = argv[1], argv[2].upper()

    im = Image.open(path).convert("L")
    if im.width > FIELD or im.height > FIELD:
        raise SystemExit("картинка %dx%d, поле %dx%d" % (im.width, im.height, FIELD, FIELD))

    px = im.load()
    ox = (FIELD - im.width) // 2
    oy = (FIELD - im.height) // 2

    rows = []
    bits = [[0] * FIELD for _ in range(FIELD)]
    for y in range(im.height):
        for x in range(im.width):
            if px[x, y] > 128:
                bits[oy + y][ox + x] = 1

    print("    {   /* %s */" % name)
    for y in range(FIELD):
        line = []
        for byte in range(ROW_BYTES):
            v = 0
            for i in range(8):
                v <<= 1
                x = byte * 8 + i
                if x < FIELD and bits[y][x]:
                    v |= 1
            line.append("0x%02X" % v)
        line = ", ".join(line) + ","
        if y < FIELD - 1:
            line += ""
        rows.append("        " + line)
    print("\n".join(rows))
    print("    },")

    print()
    print("/* проверка: то же, собранное обратно из чисел */")
    for y in range(FIELD):
        print("%2d %s" % (y, "".join("#" if bits[y][x] else "." for x in range(FIELD))))


if __name__ == "__main__":
    main(sys.argv)
