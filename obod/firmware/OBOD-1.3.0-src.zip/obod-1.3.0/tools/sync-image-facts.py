# -*- coding: utf-8 -*-
"""Числа собранного образа — в прозу: размер приложения, размер образа, SHA-256, свободное место.

Одна и та же строка живёт в пяти местах: `web/under.html`, `docs/RELEASE.md`, `FEATURES.md`,
`FEATURES.en.md` и в описании выпуска. Руками её переписывать значит однажды забыть — и
документация назовёт чужой образ. Поэтому числа берутся из манифеста и из собранного файла, а
этот скрипт правит прозу.

Запуск после каждой пересборки образа:

    python tools/sync-image-facts.py
"""
import io
import json
import os
import re
import sys

sys.stdout.reconfigure(encoding="utf-8")

PARTITION = 0x400000


def human(n):
    return "{:,}".format(int(n)).replace(",", " ")


def main():
    manifest = json.load(io.open("tools/webflash/manifest.json", encoding="utf-8"))
    image = manifest.get("image", {})
    image_size = int(image.get("size", 0))
    image_sha = str(image.get("sha256", "")).upper()

    app = os.path.getsize("build/guition_knob.bin")
    free = int(round((PARTITION - app) * 100.0 / PARTITION))

    facts = {
        "app": human(app),
        "image": human(image_size),
        "sha": image_sha,
        "free": str(free),
    }

    edited = []

    def sub(path, pattern, repl, count=1):
        t = io.open(path, encoding="utf-8").read()
        new, n = re.subn(pattern, repl, t, count=count, flags=re.S)
        if n == 0:
            raise SystemExit("не найдено в %s: %s" % (path, pattern[:60]))
        io.open(path, "w", encoding="utf-8", newline="").write(new)
        edited.append(path)

    # «Под капотом» — единственное место, где числа стоят рядом с процентом свободы.
    sub("web/under.html",
        r"Приложение занимает [\d  ]+ байт, склеенный образ для прошивки — [\d  ]+ байт,\s*"
        r"SHA-256 <code>[0-9A-F]+</code>;\s*в разделе приложения свободно \d+%\.",
        "Приложение занимает {app} байт, склеенный образ для прошивки — {image} байт,\n"
        "            SHA-256 <code>{sha}</code>;\n"
        "            в разделе приложения свободно {free}%.".format(**facts))

    sub("FEATURES.md",
        r"приложение занимает \*\*[\d  ]+ байт\*\*, склеенный образ для прошивки — \*\*[\d  ]+",
        "приложение занимает **{app} байт**, склеенный образ для прошивки — **{image}".format(**facts))

    # Числа в английском тексте стоят с пробелами, как и в русском: проверка сверяет их с
    # манифестом посимвольно, и запятая сделала бы строку «чужим» числом.
    sub("FEATURES.en.md",
        r"the application occupies \*\*[\d  ,]+ bytes\*\*, the merged image for flashing is \*\*[\d  ,]+"
        r"\s*bytes\*\*, \*\*\d+%\*\* of the application partition is free",
        "the application occupies **{app} bytes**, the merged image for flashing is **{image}\n"
        "  bytes**, **{free}%** of the application partition is free".format(**facts))

    # Процедура выпуска: размер приложения со свободным местом и образ с хешем.
    sub("docs/RELEASE.md",
        r"версия в описании приложения [\d.]+, размер приложения [\d  ]+ байт, в разделе\s*"
        r"приложения свободно \d+%\.",
        "версия в описании приложения {ver}, размер приложения {app} байт, в разделе\n"
        "приложения свободно {free}%.".format(ver=manifest.get("version", ""), **facts))

    sub("docs/RELEASE.md",
        r"образ занимает [\d  ]+ байт, SHA-256\s*`[0-9A-F]+`",
        "образ занимает {image} байт, SHA-256\n`{sha}`".format(**facts))

    print("образ {image} байт, {sha}".format(**facts))
    print("приложение {app} байт, свободно {free}%".format(**facts))
    for path in sorted(set(edited)):
        print("правлено:", path)


if __name__ == "__main__":
    main()
