/*
 * Проверка колец витрины против прошивки.
 *
 * Круги витрины рисует tools/promo-rings.js: таблица RING_PAGES называет страницы прибора,
 * их заголовки и перечни ручек, таблица RING_FIRST — угол, на котором стоит центр первого
 * сектора раскладки на 1..6 ручек. И то, и другое — выписка из прошивки, и эта выписка уже
 * разъезжалась: перечни ручек отстали от таблиц KNOBS_*, а заголовки двух страниц настроек —
 * от таблицы PAGES[]. Проверка читает обе стороны и сверяет их:
 *
 *   components/synth_ui/src/synth_ui.c   перечисление page_id_t и таблица PAGES[] — порядок
 *                                        страниц, их заголовок, метка плитки и таблица
 *                                        KNOBS_*; таблицы RIM_* — раскладки секторов;
 *   tools/promo-rings.js                 RING_PAGES и RING_FIRST.
 *
 * Страница ищется по заголовку — тому же слову, что нарисовано в середине циферблата
 * прибора, — как это делает и tools/lib/screens.js. Перечень ручек обязан совпасть составом
 * и порядком: порядок и есть раскладка секторов по ободу. Углы RING_FIRST считаются из
 * таблиц RIM_* тем же счётом, что и в rim_anchor(): центр первого сектора — начало плюс
 * половина разворота, переведённый из отсчёта LVGL (ноль в трёх часах) в отсчёт CSS (ноль
 * в двенадцати).
 *
 * Запуск: node tools/rings-check.js
 */
'use strict';

const fs = require('fs');
const path = require('path');
const vm = require('vm');

const root = path.join(__dirname, '..');
const uiFile = path.join(root, 'components', 'synth_ui', 'src', 'synth_ui.c');
const promoFile = path.join(root, 'tools', 'promo-rings.js');

const problems = [];

function check(ok, message) {
  if (!ok) { problems.push(message); }
}

/* --- прошивка --- */

/* Таблицы KNOBS_*: имя таблицы — список подписей секторов в порядке таблицы. */
function readKnobTables(src) {
  const tables = new Map();
  const table = /static const ui_knob_t (KNOBS_[A-Z0-9_]+)\[\]\s*=\s*\{([\s\S]*?)\n\};/g;
  let m;

  while ((m = table.exec(src)) !== null) {
    const sectors = [];
    const knob = /\{\s*"([^"]+)"/g;
    let k;

    while ((k = knob.exec(m[2])) !== null) { sectors.push(k[1]); }

    tables.set(m[1], sectors);
  }

  return tables;
}

/* Порядок страниц — значения перечисления page_id_t: страницы идут подряд с нуля. */
function readPageOrder(src) {
  const body = src.match(/typedef enum\s*\{([\s\S]*?)\}\s*page_id_t\s*;/);
  if (!body) { throw new Error('в ' + uiFile + ' не найдено перечисление page_id_t'); }

  const order = [];
  body[1].split('\n').forEach((line) => {
    const m = line.match(/^\s*(PAGE_[A-Z0-9_]+)\s*(?:=\s*(\d+)\s*)?,?/);
    if (m) { order.push({ id: m[1], index: m[2] === undefined ? order.length : Number(m[2]) }); }
  });

  return order
    .filter((p) => p.id !== 'PAGE_COUNT')
    .sort((a, b) => a.index - b.index);
}

/*
 * Таблица PAGES[]: заголовок, метка плитки, таблица ручек и заявленное их число.
 *
 * Число, объявленное рядом с таблицей, — не источник данных, а то, что обязано с ней сойтись:
 * если оно разошлось, секторов на ободе столько, сколько в таблице, а не сколько написано.
 */
function readPages(src, tables) {
  const start = src.indexOf('static const ui_page_t PAGES[PAGE_COUNT] = {');
  if (start < 0) { throw new Error('в ' + uiFile + ' не найдена таблица PAGES[]'); }

  const end = src.indexOf('\n};', start);
  const body = src.slice(start, end < 0 ? src.length : end);
  const entry = /\[(PAGE_[A-Z0-9_]+)\]\s*=\s*\{\s*"([^"]*)",\s*"([^"]*)",\s*([A-Za-z_][A-Za-z0-9_]*)\s*,\s*(NK\(\s*[A-Za-z_][A-Za-z0-9_]*\s*\)|\d+)\s*,\s*([A-Za-z_][A-Za-z0-9_]*)/g;
  const rows = new Map();
  let m;

  while ((m = entry.exec(body)) !== null) {
    rows.set(m[1], { title: m[2], tile: m[3], table: m[4], count: m[5].trim(),
                     view: m[6] });
  }

  return readPageOrder(src).map((p) => {
    const row = rows.get(p.id);
    if (!row) { throw new Error('у страницы ' + p.id + ' нет строки в таблице PAGES[]'); }

    /* Страница-список (VIEW_SETTINGS) не носит секторов: её строки живут в KNOBS_SETUP, а
     * не в таблице, которую называет PAGES[]. Число рядом с NULL — ноль, и сверять его с
     * длиной таблицы нечего. */
    const listPage = row.view === 'VIEW_SETTINGS';
    const tableName = listPage ? 'KNOBS_SETUP' : row.table;
    const knobs = tableName === 'NULL' ? [] : tables.get(tableName);
    if (!knobs) {
      throw new Error('страница ' + p.id + ' ссылается на ' + tableName +
                      ', которой в файле нет');
    }

    if (listPage) {
      /* A list page has no sectors on its rim, whatever its rows are: the rows stand in a
       * column and the ring is whole, like the preset page. The rows themselves are checked
       * against the reference by promo-check, which reads KNOBS_SETUP. */
      return { id: p.id, title: row.title, tile: row.tile, knobs: [], rows: knobs };
    }

    const nk = row.count.match(/^NK\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)$/);
    if (nk) {
      check(nk[1] === row.table,
            'страница ' + row.title + ': число ручек выведено из ' + nk[1] +
            ', а таблица у неё ' + row.table);
    } else {
      check(Number(row.count) === knobs.length,
            'страница ' + row.title + ': объявлено ручек ' + row.count + ', в ' +
            row.table + ' их ' + knobs.length);
    }

    return { id: p.id, title: row.title, tile: row.tile, knobs: knobs };
  });
}

/* Таблицы RIM_*: развёртки секторов, каждая — пара «начало, конец» по часовой стрелке.
 * Имя — это и есть число секторов, которое таблица обслуживает: одна таблица на счёт, и
 * шести секторам отвечает RIM_6 у всех страниц сразу — OPTIONS, трёх страниц посылов и
 * LEAD EUCLID. Пять секторов — RIM_5, в том числе у PERC и PERC SEQ. */
function readRims(src) {
  const rims = new Map();
  const table = /static const rim_span_t (RIM_[0-9]+)(\[\s*[0-9]*\s*\])?\s*=\s*\{([\s\S]*?)\n\};/g;
  let m;

  while ((m = table.exec(src)) !== null) {
    const spans = [];
    const span = /\{\s*(-?\d+)\s*,\s*(-?\d+)\s*\}/g;
    let s;

    while ((s = span.exec(m[3])) !== null) {
      spans.push({ start: Number(s[1]), end: Number(s[2]) });
    }

    rims.set(m[1], spans);
  }

  return rims;
}

/*
 * Центр первого сектора раскладки в градусах CSS — тот же счёт, что в rim_anchor():
 * у полного обода середины нет, поэтому он приколот к верху.
 */
function firstCentreCss(spans) {
  const s = spans[0];
  let sweep = s.end - s.start;
  if (sweep <= 0) { sweep += 360; }

  const mid = sweep >= 360 ? 270 : (s.start + Math.floor(sweep / 2)) % 360;
  return ((mid + 90) % 360 + 360) % 360;
}

/* --- витрина --- */

/*
 * RING_PAGES и RING_FIRST читаются исполнением файла на пустой заглушке DOM: ему нужны
 * только document и window, а mountRings() при загрузке не вызывается. Заодно проверяется
 * синтаксис самого файла.
 */
function readPromo(file) {
  const context = {
    console: console,
    document: {
      getElementById() { return null; },
      createElement() { return null; },
      querySelectorAll() { return []; },
    },
    window: { addEventListener() {}, removeEventListener() {} },
  };
  context.globalThis = context;
  vm.createContext(context);
  vm.runInContext(fs.readFileSync(file, 'utf8'), context, { filename: file });

  if (!Array.isArray(context.RING_PAGES)) {
    throw new Error('в tools/promo-rings.js нет таблицы RING_PAGES');
  }
  if (!context.RING_FIRST || typeof context.RING_FIRST !== 'object') {
    throw new Error('в tools/promo-rings.js нет таблицы RING_FIRST');
  }

  return { pages: context.RING_PAGES, first: context.RING_FIRST };
}

/* --- сверка --- */

let firmware;
let promo;

try {
  const src = fs.readFileSync(uiFile, 'utf8');
  const tables = readKnobTables(src);

  if (tables.size === 0) {
    throw new Error('в ' + uiFile + ' не найдено ни одной таблицы KNOBS_*');
  }

  const pages = readPages(src, tables);

  const rims = readRims(src);
  if (rims.size === 0) {
    throw new Error('в ' + uiFile + ' не найдено ни одной таблицы RIM_*');
  }

  /* Одна таблица на число секторов: у шести это RIM_6, и её же рисуют обе страницы с
   * рисунком. Отдельной «повёрнутой» раскладки в прошивке больше нет. */
  const byCount = new Map();

  rims.forEach((spans, name) => {
    const count = name.match(/^RIM_([0-9]+)$/);
    if (!count) {
      check(false, 'раскладка ' + name + ' не учтена проверкой углов');
      return;
    }
    byCount.set(Number(count[1]), spans);
  });

  firmware = { pages: pages, rims: byCount };
  promo = readPromo(promoFile);
} catch (err) {
  console.log('НЕ ПРОШЛО, 1:');
  console.log('  ' + err.message);
  process.exit(1);
}

check(promo.pages.length === firmware.pages.length,
      'записей в RING_PAGES ' + promo.pages.length + ', страниц в PAGES[] ' +
      firmware.pages.length);

/* Заголовки: у страницы прибора и у записи витрины это одно и то же слово, поэтому запись
 * ищется по нему. Две записи с одним заголовком — это уже несоответствие само по себе. */
const byTitle = new Map();
promo.pages.forEach((p, i) => {
  const title = p && p.t;

  if (!title) {
    check(false, 'RING_PAGES: запись ' + (i + 1) + ' без заголовка');
    return;
  }
  if (byTitle.has(title)) {
    check(false, 'RING_PAGES: две записи с заголовком «' + title + '»');
    return;
  }

  byTitle.set(title, { page: p, index: i });
});

firmware.pages.forEach((want, i) => {
  const got = byTitle.get(want.title);

  if (!got) {
    const other = promo.pages[i];
    check(false, 'страница ' + (i + 1) + ': прибор называет её «' + want.title +
                 '», а витрина на этом месте ' +
                 (other && other.t ? '«' + other.t + '»' : 'ничего не называет'));
    return;
  }

  if (got.index !== i) {
    check(false, 'порядок RING_PAGES: «' + want.title + '» стоит в витрине ' +
                 (got.index + 1) + '-й, в PAGES[] — ' + (i + 1) + '-й');
  }

  check(got.page.c === want.tile,
        'RING_PAGES/' + want.title + ': метка плитки «' + got.page.c +
        '», на приборе «' + want.tile + '»');

  const knobs = got.page.k;
  if (!Array.isArray(knobs)) {
    check(false, 'RING_PAGES/' + want.title + ': k не список ручек');
    return;
  }

  check(knobs.join(' · ') === want.knobs.join(' · '),
        'RING_PAGES/' + want.title + ': ручки ' + (knobs.join(' · ') || 'нет') +
        ', в прошивке ' + (want.knobs.join(' · ') || 'нет'));
});

/* Углы: RING_FIRST обязан совпасть с центрами первых секторов таблиц RIM_*, а ключ без
 * таблицы — это раскладка, которой в прошивке нет. */
firmware.rims.forEach((spans, count) => {
  if (spans.length === 0) {
    check(false, 'RIM_' + count + ' пуста');
    return;
  }

  const want = firstCentreCss(spans);
  const got = promo.first[count];

  check(got === want,
        'RING_FIRST[' + count + '] = ' + (got === undefined ? 'нет' : got) +
        ', из RIM_' + count + ' выходит ' + want);
});

Object.keys(promo.first).forEach((key) => {
  check(firmware.rims.has(Number(key)),
        'RING_FIRST: ключ ' + key + ', а таблицы RIM_' + key + ' в прошивке нет');
});

/* Каждое число ручек на странице обязано иметь раскладку и угол: иначе обод этой страницы
 * остаётся без секторов. Страница с рисунком — такая же страница и берёт таблицу по числу
 * ручек: у LEAD EUCLID их шесть, у PERC SEQ пять. */
firmware.pages.forEach((p) => {
  const n = p.knobs.length;
  if (n === 0) { return; }

  check(firmware.rims.has(n),
        'страница «' + p.title + '»: ' + n + ' ручек, а таблицы RIM_' + n + ' в прошивке нет');
  check(promo.first[n] !== undefined,
        'страница «' + p.title + '»: ' + n + ' ручек, а в RING_FIRST нет ключа ' + n);
});

/* --- итог --- */

if (problems.length) {
  console.log('НЕ ПРОШЛО, ' + problems.length + ':');
  problems.forEach((p) => console.log('  ' + p));
  process.exit(1);
}

const knobs = firmware.pages.reduce((n, p) => n + p.knobs.length, 0);

console.log('OK: ' + firmware.pages.length + ' страниц и ' + knobs +
            ' ручек совпадают с прошивкой, заголовки и метки плиток тоже, ' +
            firmware.rims.size + ' раскладок RIM_* сходятся с RING_FIRST');
