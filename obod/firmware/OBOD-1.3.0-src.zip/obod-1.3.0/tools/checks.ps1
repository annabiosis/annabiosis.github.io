# Прогон всех проверок выпуска. Пишет по строке на проверку.
#
# Живёт в tools, а не в build: build стирается на «чистой сборке» (tools/idf.ps1 fullclean),
# и лежавший там скрипт пропадал ровно перед выпуском. build/checks.ps1 — тонкая обёртка,
# которая зовёт этот файл, поэтому привычная команда остаётся прежней.
$ErrorActionPreference = 'Continue'
$py = 'C:\Users\Blaq\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe'
$ok = 0
$bad = @()

function Step($name, $cmd, $caller) {
    Write-Host ("--- " + $name)
    $out = & $caller $cmd 2>&1 | Out-String
    $code = $LASTEXITCODE
    if ($code -eq 0) {
        $script:ok++
        $last = ($out -split "`n" | Where-Object { $_.Trim() } | Select-Object -Last 1)
        Write-Host ("OK  " + $name + "  " + $last)
    } else {
        $script:bad += $name
        Write-Host ("FAIL " + $name + " (код " + $code + ")")
        ($out -split "`n" | Select-Object -Last 8) | ForEach-Object { Write-Host ("    " + $_) }
    }
}

Set-Location (Split-Path -Parent $PSScriptRoot)

Step 'changelog-check' 'tools\changelog-check.js' { param($c) node $c }
Step 'image-meta-check' 'tools\image-meta-check.js' { param($c) node $c }
Step 'docs-check' 'tools\docs-check.js' { param($c) node $c }
Step 'label-check' 'tools\label-check.js' { param($c) node $c }
Step 'promo-check' 'tools\promo-check.js' { param($c) node $c }
Step 'rings-check' 'tools\rings-check.js' { param($c) node $c }
Step 'font-metrics-check' 'tools\font-metrics-check.js' { param($c) node $c }
Step 'ring_clearance' 'tools\ring_clearance.py' { param($c) & $py $c }
Step 'editor-selftest' 'tools\editor\server.js' { param($c) node $c --selftest }
Step 'check_ui_tables' 'tools\check_ui_tables.ps1' { param($c) pwsh -NoProfile -File $c }
Step 'perc_check' 'tools\perc_check.py' { param($c) & $py $c }
Step 'perc_body_check' 'tools\perc_body_check.py' { param($c) & $py $c }
Step 'perc_kick_check' 'tools\perc_kick_check.py' { param($c) & $py $c }
Step 'delay_mode_check' 'tools\delay_mode_check.py' { param($c) & $py $c }
Step 'seq_reset_check' 'tools\seq_reset_check.py' { param($c) & $py $c }
Step 'follow_check' 'tools\follow_check.py' { param($c) & $py $c }
Step 'lfo-shapes' 'tools\lfo-shapes.py' { param($c) & $py $c }
Step 'host-stress' 'tools\host-stress.ps1' { param($c) pwsh -NoProfile -File $c }
Step 'random-check' 'tools\random-check.ps1' { param($c) pwsh -NoProfile -File $c }

Write-Host ''
Write-Host ("ИТОГО: ok " + $ok + " из 19; провалились: " + ($(if ($bad.Count) { $bad -join ', ' } else { 'нет' })))

if ($bad.Count -gt 0) { exit 1 }
exit 0
