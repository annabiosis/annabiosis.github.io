"""TIMBRE: гребёнка на дуге — гейт к прошивке.

Считает то же, что pv_timbre() в synth_ui_preview.c, целыми числами: константы читаются прямо
из исходника, дуга сравнивается по квадратам расстояний, верх зубьев идёт по прямой с
округлением от нуля. Проверяется семь вещей:

  1. ДВА ЕГО КАДРА СХОДЯТСЯ. Он нарисовал ровную гребёнку и хаотичную; на нуле и на максимуме
     фигура обязана совпасть с его картинками — расхождение только там, где его рука
     разошлась с окружностью (допуск 6 точек на кадр).
  2. ДУГА СИММЕТРИЧНА. Основание и нулевое положение совпадают с отражением по вертикали:
     столбец x и столбец 43 - x одинаковы. Это и было причиной переделки — в его кадре
     половины расходились, в формуле сойтись обязаны.
  3. ТОЛЩИНА ДУГИ — ДВА ПИКСЕЛЯ ПО НОРМАЛИ. Радиусы 9.00 и 11.00, проверяется по числам из
     прошивки, а не на глаз.
  4. ЗУБ НЕ ВИСИТ В ВОЗДУХЕ. Каждый зуб кончается там, где начинается основание, и на всех
     пятидесяти одном положении между верхом зуба и его низом нет пустого пикселя.
  5. ЗУБЬЯ НЕ ВЫХОДЯТ ИЗ ПОЛЯ и не наезжают друг на друга: семь штук, шаг шесть, ширина два.
  6. ВЕРХ ИДЁТ В ОДНУ СТОРОНУ. У каждого зуба верх на всём ходу меняется монотонно — ручка не
     может вернуть зуб назад.
  7. ВЫШЕ НУЛЯ ВЕРХ НЕ СИММЕТРИЧЕН НАРОЧНО: разброс — это и есть то, ради чего ручка.
"""
import math
import re
import sys
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")

SRC = Path("components/synth_ui/src/synth_ui_preview.c")
ART = 44
TOLERANCE = 6
BASE_DIR = Path(r"C:\Users\Blaq\.dsh\attachments\v1\objects")
SH = ("b95c6630651d67602eee69b97625630d0dc73ab4a9d8b8efaab105ca87f366fd",
      "05e279156446f4709eccef9da832c8271abe5a6720217baad4c6124eff9bbdec")


def konst(name):
    text = SRC.read_text(encoding="utf-8")
    m = re.search(r"#define\s+%s\s+\(?(-?\d+)\)?" % name, text)
    if not m:
        raise SystemExit("нет константы %s в %s" % (name, SRC))
    return int(m.group(1))


def table(name):
    text = SRC.read_text(encoding="utf-8")
    m = re.search(r"%s\s*(?:\[[^\]]*\])+\s*=\s*\{(.*?)\}\s*;" % name, text, re.S)
    if not m:
        raise SystemExit("нет таблицы %s в %s" % (name, SRC))
    body = re.sub(r"/\*.*?\*/", " ", m.group(1), flags=re.S)
    return [int(v) for v in re.findall(r"-?\d+", body)]


CX = konst("PV_TI_CX")
CY = konst("PV_TI_CY")
RIN2 = konst("PV_TI_RIN2")
ROUT2 = konst("PV_TI_ROUT2")
X0 = konst("PV_TI_X0")
STEP = konst("PV_TI_STEP")
N = konst("PV_TI_N")
FLOOR = konst("PV_TI_FLOOR")
HOLE_X0 = konst("PV_TI_HOLE_X0")
HOLE_X1 = konst("PV_TI_HOLE_X1")

TOP_MIN = table("s_ti_top_min")
TOP_MAX = table("s_ti_top_max")
BOTTOM = table("s_ti_bottom")


def mix(a, b, t):
    num = (b - a) * t
    bias = 500 if num >= 0 else -500
    return a + int((num + bias) / 1000)


def base_mask():
    g = [[0] * ART for _ in range(ART)]
    for y in range(ART):
        if y > FLOOR + 1:
            break
        dy = 10 * y + 5 - CY
        for x in range(ART):
            dx = 10 * x + 5 - CX
            d2 = dx * dx + dy * dy
            ring = RIN2 <= d2 <= ROUT2
            floor = y >= FLOOR and HOLE_X0 <= x <= HOLE_X1 and d2 >= RIN2
            if ring or floor:
                g[y][x] = 1
    return g


BASE = base_mask()


def frame(q, mono=False):
    t = q * 20
    g = [row[:] for row in BASE]
    for i in range(N):
        top = mix(TOP_MIN[i], TOP_MAX[i], t)
        for c in range(2):
            x = X0 + STEP * i + c
            for y in range(top, BOTTOM[2 * i + c] + 1):
                g[y][x] = 1
    return g


def mirrored(g):
    return [[g[y][ART - 1 - x] for x in range(ART)] for y in range(ART)]


def his(k):
    from PIL import Image
    p = BASE_DIR / SH[k][:2] / SH[k]
    px = Image.open(str(p)).convert("L").load()
    return [[1 if px[x, y] > 110 else 0 for x in range(ART)] for y in range(ART)]


def diff(a, b):
    return sum(1 for y in range(ART) for x in range(ART) if a[y][x] != b[y][x])


def main():
    print("TIMBRE: гребёнка на дуге")
    print("  константы: центр (%d, %d) десятых, радиусы %.2f и %.2f пикселя, "
          "толщина %.2f" % (CX, CY, math.sqrt(RIN2) / 10.0, math.sqrt(ROUT2) / 10.0,
                            (math.sqrt(ROUT2) - math.sqrt(RIN2)) / 10.0))
    print("  зубья: %d штук, шаг %d, ширина 2, от x = %d" % (N, STEP, X0))

    # 1. Его кадры.
    for k, q in enumerate((0, 50)):
        mine = frame(q)
        d = diff(mine, his(k))
        print("  кадр %d (q = %2d): %d расхождений, чернил %d против %d"
              % (k + 1, q, d, sum(map(sum, mine)), sum(map(sum, his(k)))))
        if d > TOLERANCE:
            raise SystemExit("  кадр %d разошёлся сильнее допуска %d" % (k + 1, TOLERANCE))

    # 2. Симметрия основания и нуля.
    if BASE != mirrored(BASE):
        raise SystemExit("  основание не симметрично")
    if frame(0) != mirrored(frame(0)):
        raise SystemExit("  на нуле гребёнка не симметрична")
    print("  симметрия: основание и ноль совпадают с отражением по вертикали")

    # 3. Толщина по нормали.
    thick = (math.sqrt(ROUT2) - math.sqrt(RIN2)) / 10.0
    if abs(thick - 2.0) > 0.001:
        raise SystemExit("  толщина дуги %.3f, а не два пикселя" % thick)
    print("  толщина дуги: ровно %.2f пикселя по нормали" % thick)

    # 4. Зуб не висит в воздухе: между верхом и низом нет пропусков, низ лежит на основании.
    for q in range(51):
        g = frame(q)
        for i in range(N):
            for c in range(2):
                x = X0 + STEP * i + c
                ys = [y for y in range(ART) if g[y][x]]
                if ys != list(range(min(ys), max(ys) + 1)):
                    raise SystemExit("  q = %d, столбец %d: в зубе дыра" % (q, x))
    print("  зубья: ни одного пропуска ни в одном столбце ни на одном положении")

    # 5. Поля и наложений.
    for i in range(N):
        for c in range(2):
            x = X0 + STEP * i + c
            if x < 0 or x >= ART:
                raise SystemExit("  зуб выходит из поля: столбец %d" % x)
        if i and X0 + STEP * i - (X0 + STEP * (i - 1) + 1) < 1:
            raise SystemExit("  зубья %d и %d наезжают друг на друга" % (i, i - 1))
    print("  зубья стоят в поле и между ними всегда есть просвет")

    # 6. Верх идёт в одну сторону.
    for i in range(N):
        tops = [mix(TOP_MIN[i], TOP_MAX[i], q * 20) for q in range(51)]
        if tops != sorted(tops) and tops != sorted(tops, reverse=True):
            raise SystemExit("  зуб %d: верх ходит не в одну сторону" % (i + 1))
        if min(tops) < 0 or max(tops) > ART - 1:
            raise SystemExit("  зуб %d: верх выходит из поля" % (i + 1))
    print("  верх каждого зуба идёт монотонно от дуги к его высоте на максимуме")

    # 7. Выше нуля разброс нарочно несимметричен.
    asym = [q for q in range(51) if frame(q) != mirrored(frame(q))]
    if not asym or asym[0] == 0:
        raise SystemExit("  выше нуля фигура осталась симметричной — разброса нет")
    print("  разброс: начиная с q = %d фигура перестаёт быть симметричной, и это нарочно"
          % asym[0])

    print("\nOK: TIMBRE — дуга ровная и симметричная, кадры владельца сходятся, "
          "верх зубьев ходит в одну сторону")
    return 0


if __name__ == "__main__":
    sys.exit(main())
