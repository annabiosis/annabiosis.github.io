#!/usr/bin/env node
/*
 * Сверяет tools/webflash/changelog.json с CHANGELOG.md — по всем версиям.
 *
 * Список собирает tools/make-changelog-json.ps1, а он запускается при выпуске:
 * правка CHANGELOG.md без пересборки оставляет на странице прошивки и на странице
 * истории старый список, и заметить это можно только глазами. Между тем именно там
 * видно, что изменилось в образе, который предлагают записать.
 *
 * Проверка повторяет разбор из генератора и падает, если файл отстал. Сверяется
 * каждая версия, а не только последняя: страница истории обещает всю историю, и
 * потерянная версия — такая же ошибка, как потерянный пункт.
 *
 * Заодно проверяется, что до списка можно дойти и что он не раздвоился: страница
 * истории читает файл целиком, она есть в списке страниц, а страницы записи —
 * прошивка в документации и страница локального сервера — держат только ссылку на
 * неё, с якорем последнего выпуска. Списка на них нет: он там отставал от
 * CHANGELOG.md, и текст приходилось бы править в двух местах.
 *
 * Запуск: node tools/changelog-check.js
 */

'use strict';

const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const changelogPath = path.join(root, 'CHANGELOG.md');
const jsonPath = path.join(root, 'tools', 'webflash', 'changelog.json');

function fail(message) {
  console.error('changelog-check: ' + message);
  process.exit(1);
}

function rel(target) {
  return path.relative(root, target).split(path.sep).join('/');
}

/*
 * Разбор тот же, что в make-changelog-json.ps1: версия — заголовок второго уровня,
 * первый знак которого цифра; раздел — «### »; пункт — «- ». Строки с отступом
 * продолжают пункт. Одинаковые разделы внутри версии склеиваются: в файле заголовок
 * «### Ритм» стоит дважды, и на странице это читалось бы как два раздела подряд.
 */
function parseVersions(markdown) {
  const lines = markdown.split(/\r?\n/);
  const versions = [];

  let current = null;
  let section = null;
  let item = null;

  const flushItem = () => {
    if (item !== null && section) {
      section.items.push(item);
    }
    item = null;
  };

  const closeVersion = () => {
    flushItem();
    if (current) {
      versions.push(current);
    }
    current = null;
    section = null;
  };

  for (const line of lines) {
    const version = /^##\s+(\d[0-9A-Za-z.-]*)\s*$/.exec(line);
    if (version) {
      closeVersion();
      current = { version: version[1], sections: [] };
      continue;
    }
    if (/^##\s+/.test(line)) {
      // Заголовок второго уровня, но не версия: всё, что под ним, в список не идёт.
      closeVersion();
      continue;
    }
    if (!current) continue;

    const heading = /^###\s+(.+?)\s*$/.exec(line);
    if (heading) {
      flushItem();
      const same = current.sections.find((s) => s.title === heading[1]);
      if (same) {
        section = same;
      } else {
        section = { title: heading[1], items: [] };
        current.sections.push(section);
      }
      continue;
    }
    const bullet = /^-\s+(.*)$/.exec(line);
    if (bullet) {
      if (!section) {
        // Пункт до первого «### » — свежая работа, дописанная сверху. Раньше он молча
        // пропадал: в 1.3.0 так исчезли 108 пунктов из 149. Разбор здесь обязан повторять
        // генератор, иначе проверка согласится с потерянным списком. Раздел заводится только
        // под пункт, поэтому пустых разделов в списке не бывает.
        section = { title: 'Изменения', items: [] };
        current.sections.push(section);
      }

      flushItem();
      item = bullet[1].trim();
      continue;
    }
    if (item !== null && /^\s+\S/.test(line)) {
      item = item + ' ' + line.trim();
      continue;
    }
    if (item !== null && line.trim() === '') flushItem();
  }
  closeVersion();

  return versions;
}

if (!fs.existsSync(changelogPath)) fail('нет ' + rel(changelogPath));

const expected = parseVersions(fs.readFileSync(changelogPath, 'utf8'));
if (!expected.length) fail('в ' + rel(changelogPath) + ' нет ни одной версии');

if (!fs.existsSync(jsonPath)) {
  fail('нет ' + rel(jsonPath) + ' — соберите его: pwsh -File tools/make-changelog-json.ps1');
}

let actual;
try {
  actual = JSON.parse(fs.readFileSync(jsonPath, 'utf8'));
} catch (error) {
  fail('не читается ' + rel(jsonPath) + ': ' + error.message);
}

const got = Array.isArray(actual.versions) ? actual.versions : [];
if (!got.length) {
  fail(rel(jsonPath) + ' без списка versions — соберите заново: ' +
       'pwsh -File tools/make-changelog-json.ps1');
}

const hint = ' Пересоберите: pwsh -File tools/make-changelog-json.ps1';

if (got.length !== expected.length) {
  const want = expected.map((v) => v.version).join(', ');
  const have = got.map((v) => v.version).join(', ');
  fail('версий в ' + rel(jsonPath) + ' — ' + got.length + ' (' + have + '), в ' +
       rel(changelogPath) + ' — ' + expected.length + ' (' + want + ').' + hint);
}

let items = 0;
for (let i = 0; i < expected.length; i++) {
  const want = expected[i];
  const have = got[i] || {};
  const where = 'версия ' + (i + 1);

  if (have.version !== want.version) {
    fail(where + ': в файле «' + have.version + '», в CHANGELOG.md «' + want.version + '»' +
         ' — порядок или состав версий разошёлся.' + hint);
  }

  if (have.date !== undefined && !/^\d{4}-\d{2}-\d{2}$/.test(String(have.date))) {
    fail(where + ' (' + want.version + '): дата «' + have.date + '» не в виде 2026-10-26');
  }

  const wantSections = want.sections;
  const haveSections = Array.isArray(have.sections) ? have.sections : [];
  if (haveSections.length !== wantSections.length) {
    fail(where + ' (' + want.version + '): разделов в файле — ' + haveSections.length +
         ', в CHANGELOG.md — ' + wantSections.length + '.' + hint);
  }

  for (let s = 0; s < wantSections.length; s++) {
    const wantSection = wantSections[s];
    const haveSection = haveSections[s] || {};
    const at = where + ' (' + want.version + '), раздел ' + (s + 1) +
               ' («' + wantSection.title + '»)';

    if (haveSection.title !== wantSection.title) {
      fail(at + ': в файле «' + haveSection.title + '»');
    }

    const haveItems = Array.isArray(haveSection.items) ? haveSection.items : [];
    if (haveItems.length !== wantSection.items.length) {
      fail(at + ': пунктов в файле — ' + haveItems.length +
           ', в CHANGELOG.md — ' + wantSection.items.length + '.' + hint);
    }

    for (let k = 0; k < wantSection.items.length; k++) {
      if (haveItems[k] !== wantSection.items[k]) {
        fail(at + ', пункт ' + (k + 1) + ' разошёлся.\n' +
             '  в файле:     ' + haveItems[k] + '\n' +
             '  в CHANGELOG: ' + wantSection.items[k] + hint);
      }
      if (!wantSection.items[k]) fail(at + ', пункт ' + (k + 1) + ' пуст');

      /*
       * Выделение в пункте допустимо и ожидаемо: пункт начинается с жирного названия
       * того, что изменилось. Разметкой списка считается другое — оставленный маркер
       * «- » в начале или в середине пункта: страница рисует пункт текстом, и маркер
       * попал бы на неё как есть.
       */
      if (/^-\s/.test(wantSection.items[k]) || /\s-\s/.test(wantSection.items[k])) {
        fail(at + ', пункт ' + (k + 1) + ' остался с разметкой списка');
      }
      if ((wantSection.items[k].match(/\*\*/g) || []).length % 2) {
        fail(at + ', пункт ' + (k + 1) + ': выделение ** не закрыто');
      }
      items++;
    }
  }
}

/*
 * Страницы записи: списка изменений на них нет. Вместо него одна ссылка на страницу
 * истории, и ведёт она на якорь того выпуска, который предлагают записать, — иначе
 * человек читал бы историю не того образа.
 *
 * Отсюда три требования. Ссылка с якорем последней версии — есть. Разметки списка
 * (#changes, #changes-body) — нет: вернувшийся список снова начнёт отставать от
 * CHANGELOG.md. И данные страница не читает: список показывает только страница
 * истории, второй загрузчик означал бы вторую копию показа.
 */
const latest = got[0].version;

const flashers = [
  path.join(root, 'tools', 'webflash', 'index.html'),
  path.join(root, 'web', 'flash.html'),
];

for (const file of flashers) {
  if (!fs.existsSync(file)) fail('нет ' + rel(file));
  const html = fs.readFileSync(file, 'utf8');

  const anchor = 'changelog.html#v' + latest;
  if (!html.includes(anchor)) {
    fail(rel(file) + ': нет ссылки ' + anchor + ' — со страницы записи некуда перейти ' +
         'за списком изменений');
  }

  if (/id="changes/.test(html)) {
    fail(rel(file) + ': вернулся раздел #changes со списком изменений. Список живёт ' +
         'на странице истории, на странице записи остаётся только ссылка');
  }

  if (/data-source="[^"]*changelog\.json"/.test(html)) {
    fail(rel(file) + ': страница снова читает changelog.json — список изменений ' +
         'показывает только страница истории');
  }
}

/* Загрузчик списка странице записи больше не нужен: она ничего не рисует сама. */
const flashPath = path.join(root, 'web', 'flash.html');
if (/assets\/changelog\.js/.test(fs.readFileSync(flashPath, 'utf8'))) {
  fail('web/flash.html: подключён assets/changelog.js, а списка на странице нет — ' +
       'скрипт нужен только странице истории');
}

/*
 * Версия в манифесте и последняя версия в истории — одна и та же. Якорь ссылки
 * берётся из истории, версия записи — из манифеста, и разойтись им нельзя: иначе
 * ссылка «что нового» открывала бы чужой выпуск.
 */
const manifestPath = path.join(root, 'tools', 'webflash', 'manifest.json');
if (fs.existsSync(manifestPath)) {
  let manifest;
  try {
    manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
  } catch (error) {
    fail('не читается ' + rel(manifestPath) + ': ' + error.message);
  }
  if (manifest.version !== latest) {
    fail('версия в ' + rel(manifestPath) + ' — ' + manifest.version + ', последняя в ' +
         rel(jsonPath) + ' — ' + latest + ': ссылка на историю ведёт не на тот выпуск.' +
         hint);
  }
}

/* Страница истории: тот же файл, тот же путь, что у страницы прошивки. */
const historyPath = path.join(root, 'web', 'changelog.html');
if (!fs.existsSync(historyPath)) {
  fail('нет ' + rel(historyPath) + ' — страницы истории изменений');
}
const history = fs.readFileSync(historyPath, 'utf8');

/* СТРАНИЦА ИСТОРИИ СОБИРАЕТСЯ СТАТИЧЕСКИ: список выпусков лежит в самой странице, а не
 * приходит запросом. Проверяем поэтому то, что видно и без браузера: якорь на каждый выпуск
 * и сами пункты последнего выпуска. */
for (const v of expected) {
  if (!history.includes('id="v' + v.version + '"')) {
    fail(rel(historyPath) + ': нет выпуска v' + v.version + ' — страница истории неполная');
  }
}
const newest = expected[0];
const firstItem = (newest.sections[0] && newest.sections[0].items[0]) || '';
const probe = firstItem.slice(0, 40);
if (probe && !history.includes(probe.replace(/&/g, '&amp;').replace(/</g, '&lt;'))) {
  fail(rel(historyPath) + ': первый пункт выпуска ' + newest.version + ' не попал на страницу');
}
if (/data-source="[^"]*changelog\.json"/.test(history)) {
  fail(rel(historyPath) + ': страница снова читает changelog.json, хотя список в ней статический');
}

/* Навигация: без пункта в шапке и подвале до истории не дойти. Дерево на сайте статическое,
 * поэтому проверяются ссылки в самой странице истории и в шапке любой страницы. */
for (const f of ['index.html', 'flash.html']) {
  const p = path.join(root, 'web', f);
  if (!fs.existsSync(p)) { fail('нет ' + rel(p)); continue; }
  if (!/href="changelog\.html/.test(fs.readFileSync(p, 'utf8'))) {
    fail(rel(p) + ': нет ссылки на changelog.html — до истории не дойти');
  }
}

const sitePath = path.join(root, 'tools', 'make-site.ps1');
if (!fs.existsSync(sitePath)) fail('нет ' + rel(sitePath));
const site = fs.readFileSync(sitePath, 'utf8');
if (!site.includes("'../tools/webflash/changelog.json'") || !site.includes("'changelog.json'")) {
  fail(rel(sitePath) + ': не переписывает путь к списку изменений на соседний файл');
}

const versions = expected.map((v) => v.version).join(', ');
console.log(
  'OK: ' + rel(jsonPath) + ' совпадает с ' + rel(changelogPath) + ' — версий ' +
  expected.length + ' (' + versions + '), пунктов ' + items +
  '; страница истории на месте, страницы записи ведут на неё ссылкой #v' + latest +
  ' и списка не держат.'
);
