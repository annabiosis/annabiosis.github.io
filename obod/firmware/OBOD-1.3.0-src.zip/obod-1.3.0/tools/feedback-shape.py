"""Фигура DELAY FEEDBACK: проверяет геометрию в прошивке по кадрам владельца.

Сверяется не картинка, а правила: девять полос через пять пикселей, по две шириной,
лестница внешних высот, зазоры, совпадение шести ступеней с кадрами, плавность между
ними и то, что фигура стоит только на FDBK страницы DELAY.
"""
import io
import re
import sys

sys.stdout.reconfigure(encoding="utf-8")

SRC = io.open("components/synth_ui/src/synth_ui_preview.c", encoding="utf-8").read()
HDR = io.open("components/synth_ui/src/synth_ui_preview.h", encoding="utf-8").read()
UI = io.open("components/synth_ui/src/synth_ui.c", encoding="utf-8").read()

problems = []


def const(name, where=SRC):
    m = re.search(r"#define\s+%s\s+(-?\d+)" % name, where)
    if not m:
        problems.append("нет константы %s" % name)
        return 0
    return int(m.group(1))


def table(name):
    m = re.search(r"%s\[[^\]]*\]\s*=\s*\{([^}]*)\}" % name, SRC)
    if not m:
        problems.append("нет таблицы %s" % name)
        return []
    return [int(v) for v in re.findall(r"-?\d+", m.group(1))]


BARS = const("PV_FB_BARS")
PITCH = const("PV_FB_PITCH")
BAR_W = const("PV_FB_W")
X0 = const("PV_FB_X0")
MID = const("PV_FB_MID")
GAP = const("PV_FB_GAP")
GAP_HI = const("PV_FB_GAP_HI")
GAP_NEAR = const("PV_FB_GAP_NEAR")
LADDER = table("PV_FB_LADDER")
SIN10 = table("PV_FB_SIN10")

if BARS != 9:
    problems.append("полос %d, а в кадрах их девять" % BARS)
if PITCH != 5 or BAR_W != 2 or X0 != 1 or MID != 22:
    problems.append("шаг/ширина/начало/середина не те: %d %d %d %d" % (PITCH, BAR_W, X0, MID))
if LADDER != [5, 7, 10, 15, 20]:
    problems.append("лестница %s, а в кадрах полувысоты 5/7/10/15/20" % LADDER)
if (GAP, GAP_HI, GAP_NEAR) != (5, 8, 3):
    problems.append("зазоры %s/%s/%s, а в кадрах 5/8/3" % (GAP, GAP_HI, GAP_NEAR))
if len(SIN10) != 10 or SIN10[0] != 0 or max(SIN10) != 100:
    problems.append("таблица фазы не та: %s" % SIN10)

# --- модель, повторяющая арифметику прошивки ---------------------------------
def ladder_at(t):
    if t <= 0:
        return LADDER[0] * 100
    if t >= 400:
        return LADDER[4] * 100
    i, f = divmod(t, 100)
    return LADDER[i] * 100 + (LADDER[i + 1] - LADDER[i]) * f


def bars(q):
    """(высота, зазор) каждой полосы в пикселях при q из 0..50."""
    k = 100 + 10 * q
    phase = SIN10[q % 10]
    out = []
    for i in range(BARS):
        d = abs(i - 4)
        half = LADDER[4] * 100
        if d > 0:
            t = k - 100 * d + 100 + (20 * phase * d) // 400
            half = ladder_at(t)
            if k < 200:
                half = LADDER[0] * 100 + (half - LADDER[0] * 100) * (k - 100) // 100
        gap = 0
        if d == 0:
            f = max(0, min(100, k - 200))
            s = f * f * (300 - 2 * f) // 10000
            gap = GAP * 100 + (GAP_HI - GAP) * s * 100 // 100
        elif d == 1:
            gap = GAP_NEAR * 100
        out.append(((half + 50) // 100, (gap + 50) // 100))
    return out


# --- шесть кадров владельца --------------------------------------------------
STAGES = [
    ([10, 10, 10, 10, 40, 10, 10, 10, 10], [0, 0, 0, 6, 10, 6, 0, 0, 0]),
    ([10, 10, 14, 20, 40, 20, 14, 10, 10], [0, 0, 0, 6, 10, 6, 0, 0, 0]),
    ([10, 14, 20, 30, 40, 30, 20, 14, 10], [0, 0, 0, 6, 16, 6, 0, 0, 0]),
    ([14, 20, 30, 40, 40, 40, 30, 20, 14], [0, 0, 0, 6, 16, 6, 0, 0, 0]),
    ([20, 30, 40, 40, 40, 40, 40, 30, 20], [0, 0, 0, 6, 16, 6, 0, 0, 0]),
    ([30, 40, 40, 40, 40, 40, 40, 40, 30], [0, 0, 0, 6, 16, 6, 0, 0, 0]),
]

for n, (heights, gaps) in enumerate(STAGES, 1):
    q = 10 * (n - 1)
    got = bars(q)
    my_h = [2 * h for h, _ in got]
    my_g = [2 * g for _, g in got]
    if my_h != heights:
        problems.append("кадр %d: высоты %s, а должно быть %s" % (n, my_h, heights))
    if my_g != gaps:
        problems.append("кадр %d: зазоры %s, а должно быть %s" % (n, my_g, gaps))

# --- где именно стоят полосы: маска 44 x 44 и сравнение с кадрами ------------
AREA_X0 = int(re.search(r"#define\s+PV_AREA_X0\s+(\d+)", SRC).group(1))
AREA_Y0 = int(re.search(r"#define\s+PV_AREA_Y0\s+(\d+)", SRC).group(1))


def picture(q):
    """Маска 56 x 56 в том виде, в каком её соберёт pv_delay_feedback()."""
    mask = [[0] * 56 for _ in range(56)]
    for i, (h, g) in enumerate(bars(q)):
        x = AREA_X0 + X0 + i * PITCH
        spans = ((AREA_Y0 + MID - h, AREA_Y0 + MID - 1 - g),
                 (AREA_Y0 + MID + g, AREA_Y0 + MID - 1 + h))
        for y0, y1 in spans:
            for y in range(y0, y1 + 1):
                for dx in range(BAR_W):
                    mask[y][x + dx] = 1
    return mask


def expected(heights, gaps):
    """Тот же кадр, собранный прямо из таблиц владельца, без арифметики лестницы."""
    mask = [[0] * 56 for _ in range(56)]
    for i, (h2, g2) in enumerate(zip(heights, gaps)):
        h, g = h2 // 2, g2 // 2
        x = AREA_X0 + X0 + i * PITCH
        spans = ((AREA_Y0 + MID - h, AREA_Y0 + MID - 1 - g),
                 (AREA_Y0 + MID + g, AREA_Y0 + MID - 1 + h))
        for y0, y1 in spans:
            for y in range(y0, y1 + 1):
                for dx in range(BAR_W):
                    mask[y][x + dx] = 1
    return mask


for n, (heights, gaps) in enumerate(STAGES, 1):
    mine, want = picture(10 * (n - 1)), expected(heights, gaps)
    bad = sum(1 for y in range(56) for x in range(56) if mine[y][x] != want[y][x])
    if bad:
        problems.append("кадр %d: маска расходится с кадром в %d точках" % (n, bad))

# поле: ни одна точка не выходит за 44 x 44
for q in range(0, 51, 5):
    mask = picture(q)
    for y in range(56):
        for x in range(56):
            if mask[y][x] and not (AREA_X0 <= x < AREA_X0 + 44 and AREA_Y0 <= y < AREA_Y0 + 44):
                problems.append("шаг %d: точка (%d, %d) вне поля" % (q, x, y))
                break

# --- плавность: рост не больше двух пикселей на шаг кноба --------------------
prev = bars(0)
jumps = []
for q in range(1, 51):
    cur = bars(q)
    for (h0, g0), (h1, g1) in zip(prev, cur):
        if h1 > h0 + 1 or g1 > g0 + 1:
            jumps.append((q, h1 - h0, g1 - g0))
    if any(h1 < h0 or g1 < g0 for (h0, g0), (h1, g1) in zip(prev, cur)):
        problems.append("шаг %d: фигура поехала назад" % q)
    prev = cur
if jumps:
    problems.append("скачки на шагах %s" % jumps[:6])

# края: первый кадр только центром, последний — почти прямоугольник
first = bars(0)
if [h for h, _ in first] != [5] * 4 + [20] + [5] * 4:
    problems.append("внизу хода поднят не только центр: %s" % [h for h, _ in first])
last = bars(50)
if [h for h, _ in last][1:8] != [20] * 7:
    problems.append("наверху хода подняты не все средние полосы: %s" % [h for h, _ in last])

# --- куда фигура поставлена --------------------------------------------------
if "PREVIEW_DELAY_FEEDBACK" not in HDR:
    problems.append("нет вида PREVIEW_DELAY_FEEDBACK в заголовке")

sw = SRC[SRC.index("static synth_preview_kind_t pv_values"):]
sw = sw[:sw.index("\n}\n")]
LABELS, pending = {}, []
for m in re.finditer(r"case (SYNTH_PARAM_\w+):|return (PREVIEW_\w+);", sw):
    if m.group(1):
        pending.append(m.group(1))
    else:
        for label in pending:
            LABELS.setdefault(label, m.group(2))
        pending = []

WANT = {
    "SYNTH_PARAM_DELAY_FEEDBACK": "PREVIEW_DELAY_FEEDBACK",
    "SYNTH_PARAM_DELAY_MIX": "PREVIEW_NONE",
    "SYNTH_PARAM_DELAY_SYNC": "PREVIEW_NONE",
    "SYNTH_PARAM_VERB_MIX": "PREVIEW_NONE",
    "SYNTH_PARAM_CHORUS_MIX": "PREVIEW_NONE",
    "SYNTH_PARAM_DELAY_TIME": "PREVIEW_NONE",
    "SYNTH_PARAM_DLY_SEND_LEAD": "PREVIEW_DELAY_SECTOR",
    "SYNTH_PARAM_DLY_SEND_HIGH": "PREVIEW_DELAY_SECTOR",
}
for param, kind in WANT.items():
    got = LABELS.get(param)
    if got != kind:
        problems.append("%s отдаёт %s, а должен %s" % (param, got, kind))

if not re.search(r"case PREVIEW_DELAY_FEEDBACK:\s*pv_delay_feedback\(", SRC):
    problems.append("нет вызова pv_delay_feedback в переключателе")
if "SYNTH_PARAM_DELAY_FEEDBACK" not in UI:
    problems.append("параметр FDBK пропал со страницы DELAY")

if problems:
    print("FAIL: фигура DELAY FEEDBACK")
    for p in problems:
        print("  -", p)
    sys.exit(1)

print("OK: DELAY FEEDBACK — девять полос через пять пикселей с зазором в середине, "
      "шесть ступеней совпадают с кадрами, между ними шаг не больше пикселя; "
      "стоит на FDBK страницы DELAY, у MIX фигуры нет, посылы не тронуты")
