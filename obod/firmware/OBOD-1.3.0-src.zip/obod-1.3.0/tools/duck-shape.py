"""DUCK: the figure in synth_ui_preview.c against the owner's six drawings.

Reads the C source, re-derives the picture in Python, and holds four things:

  * the six 44 x 44 drawings of the owner come back row for row in the bars, and the ball
    lands inside the few pixels his hand drew unevenly;
  * the ball is a circle symmetric about both axes with a two-pixel stroke;
  * it enters row by row — nothing, then one row, then two — and only then rides with
    the bars;
  * the dispatch, the offset table and the header all know about the figure.

Run: python tools/duck-shape.py
"""
import re
import sys

from PIL import Image

sys.stdout.reconfigure(encoding="utf-8")

SRC = "components/synth_ui/src/synth_ui_preview.c"
HDR = "components/synth_ui/src/synth_ui_preview.h"
BASE = r"C:\Users\Blaq\.dsh\attachments\v1\objects"
ART = 44
FAIL = []


def fail(msg):
    FAIL.append(msg)


def ok(msg):
    print("  " + msg)


src = open(SRC, encoding="utf-8", errors="replace").read()


def arr(name, pattern):
    m = re.search(r"%s\s*\[[^\]]*\]\s*=\s*\{([^}]*)\}" % pattern, src)
    if not m:
        fail("не нашёл таблицу %s" % name)
        return []
    return [int(v) for v in re.findall(r"-?\d+", m.group(1))]


def define(name):
    m = re.search(r"#define\s+%s\s+(\d+)" % name, src)
    if not m:
        fail("не нашёл #define %s" % name)
        return 0
    return int(m.group(1))


print("1. таблицы в прошивке")
NB = define("PV_DUCK_BARS")
PROFILE = arr("PV_DUCK_PROFILE", "PV_DUCK_PROFILE")
CAP = arr("PV_DUCK_CAP", "PV_DUCK_CAP")
LEVEL = arr("PV_DUCK_LEVEL", "PV_DUCK_LEVEL")
if NB != 9:
    fail("полос должно быть девять, а не %d" % NB)
if len(PROFILE) != NB or len(CAP) != NB:
    fail("профиль и кончики должны быть по девять")
if len(LEVEL) != 6:
    fail("уровней должно быть шесть")
if PROFILE != [0, -3, -4, 0, 3, 6, 8, 9, 9]:
    fail("профиль впадины не тот: %s" % PROFILE)
if CAP != [1, 0, 2, 2, 2, 0, 0, 0, 0]:
    fail("кончики не те: %s" % CAP)
if LEVEL != [190, 190, 170, 130, 90, 70]:
    fail("уровни не те: %s" % LEVEL)
if FAIL:
    for f in FAIL:
        print("ПРОВАЛ: " + f)
    sys.exit(1)
ok("полос ровно девять, профиль %s, уровни %s" % (PROFILE, LEVEL))

# ---------------------------------------------------------------- the model, from the C

AXIS_TOP, AXIS_BOT, UP_LAST, LO_FIRST = 21, 22, 20, 25
BAR_X0, BAR_STEP, BAR_W, DROP = 1, 5, 2, 2
RING_CX2, RING_IN, RING_OUT, RING_D, STEM_X = 19, 4, 6, 11, 9


def level(q):
    q = max(0, min(50, q))
    i = q // 10
    if i >= 5:
        return LEVEL[5]
    a, b = LEVEL[i], LEVEL[i + 1]
    return a + (b - a) * (q - i * 10) // 10


def bar(q, k):
    dip = 10 if q >= 10 else q
    v10 = level(q) + dip * PROFILE[k]
    v = (v10 + 5) // 10 if v10 >= 0 else -((-v10 + 5) // 10)
    return max(0, min(19, v))


def ball(q):
    """Только шар: кольцо между радиусами 4 и 6 плюс нить. Пусто, если шара нет."""
    g = [[0] * ART for _ in range(ART)]
    r = 20 - bar(q, 0) if q >= 10 else -1 + (2 * q) // 10
    if r < 0:
        return g
    for half in (0, 1):
        cy2 = 2 * r - RING_D if half == 0 else 86 - (2 * r - RING_D)
        for y in range(ART):
            uy = 2 * y - cy2
            for x in range(ART):
                ux = 2 * x - RING_CX2
                d2 = ux * ux + uy * uy
                if RING_IN ** 2 * 4 <= d2 <= RING_OUT ** 2 * 4:
                    g[y][x] = 1
        lo = 0 if half == 0 else (cy2 + RING_D) // 2 + 1
        hi = (cy2 - RING_D) // 2 - 1 if half == 0 else 43
        for y in range(max(0, lo), min(ART - 1, hi) + 1):
            g[y][STEM_X] = 1
            g[y][STEM_X + 1] = 1
    return g


def frame(q):
    g = [[0] * ART for _ in range(ART)]
    for k in range(NB):
        a = bar(q, k)
        x = BAR_X0 + k * BAR_STEP
        top = UP_LAST - a + 1
        bot = LO_FIRST + a - DROP - 1
        for y in range(top, UP_LAST + 1):
            for dx in range(BAR_W):
                g[y][x + dx] = 1
        for y in range(LO_FIRST, bot + 1):
            for dx in range(BAR_W):
                g[y][x + dx] = 1
        if a < 19 and CAP[k]:
            cx = x + (0 if CAP[k] == 1 else 1)
            g[top - 1][cx] = 1
            g[bot + 1][cx] = 1
    for x in range(BAR_X0, BAR_X0 + (NB - 1) * BAR_STEP + BAR_W):
        g[AXIS_TOP][x] = 1
        g[AXIS_BOT][x] = 1
    b = ball(q)
    for y in range(ART):
        for x in range(ART):
            if b[y][x]:
                g[y][x] = 1
    return g


def lengths(g):
    """Длины полос сверху и снизу — по непрерывному ряду от оси наружу."""
    up, lo = [], []
    for k in range(NB):
        x = BAR_X0 + k * BAR_STEP
        y = UP_LAST
        while y >= 0 and g[y][x] and g[y][x + 1]:
            y -= 1
        up.append(UP_LAST - y)
        y = LO_FIRST
        while y < ART and g[y][x] and g[y][x + 1]:
            y += 1
        lo.append(y - LO_FIRST)
    return up, lo


print("2. кадры владельца")
HIS = ("0bdc9225e140b53e5a1ccbc42b6c83de94e3255f6bda254433c2921d3916d482",
       "10652281204208a82005df79b5fce66db7d0864350a26e362da1c27e94985118",
       "65f0562f188af853525685e6ea9f078086a1df5a727316839a28d86ea3541fb9",
       "952a4c574ef91d54a212b8c8690180f1d513f76bf40fb1831472212b59cd9ae7",
       "7b2c0a30a7ac8459a06582cbe9bdb9dfa0d62685fe0600346ab02714c42a0956",
       "fba091a49464db4ab6ba6f1fde54f68da60b5d7dfeda2198fa9cc8514f6e7327")


def his(h):
    px = Image.open("%s\\%s\\%s" % (BASE, h[:2], h)).convert("L").load()
    return [[1 if px[x, y] > 110 else 0 for x in range(ART)] for y in range(ART)]


for i, (h, q) in enumerate(zip(HIS, (0, 10, 20, 30, 40, 50))):
    mine, theirs = frame(q), his(h)
    up_a, lo_a = lengths(mine)
    up_b, lo_b = lengths(theirs)
    if up_a != up_b or lo_a != lo_b:
        fail("кадр %d: длины не те\n    мои %s / %s\n    его %s / %s"
             % (i + 1, up_a, lo_a, up_b, lo_b))
    diff = sum(1 for y in range(ART) for x in range(ART) if mine[y][x] != theirs[y][x])
    if diff > 8:
        fail("кадр %d: рисунок расходится в %d пикселях" % (i + 1, diff))
    ok("кадр %d (DUCK %d): длины %s, весь рисунок расходится в %d px"
       % (i + 1, q, up_a, diff))

print("3. шар — ровный круг с обводкой два пикселя")
for q in (10, 20, 30, 40, 50):
    g = ball(q)
    rows = [y for y in range(ART) if any(g[y][x] for x in range(ART))]
    bad_x = sum(1 for y in rows for x in range(4, 12) if g[y][x] != g[y][RING_CX2 - x])
    if bad_x:
        fail("шар на DUCK %d несимметричен по x: %d" % (q, bad_x))
    widths = sorted({sum(1 for x in range(ART) if g[y][x]) for y in rows})
    if max(widths) < 4:
        fail("шар на DUCK %d тоньше двух пикселей" % q)
g = ball(50)
top_rows = [y for y in range(22) if any(g[y][x] for x in range(ART))]
for y in top_rows:
    if any(g[y][x] != g[43 - y][x] for x in range(ART)):
        fail("строка %d не зеркальна строке %d" % (y, 43 - y))
        break
ok("симметричен по обеим осям, нижний — зеркало верхнего")

print("4. вход построчный")
seen = [sum(1 for y in range(0, 22) if any(ball(q)[y][x] for x in range(ART)))
        for q in range(0, 21)]
if seen[0] != 0:
    fail("на DUCK 0 шара быть не должно, а он в %d строках" % seen[0])
if 1 not in seen:
    fail("шар не появляется одной строкой — сразу %d" % min(n for n in seen if n))
first = next(q for q, n in enumerate(seen) if n)
if seen[first] != 1:
    fail("первый кадр с шаром показывает %d строк вместо одной" % seen[first])
if any(b < a for a, b in zip(seen, seen[1:])):
    fail("число строк шара падает по ходу: %s" % seen)
ok("на 0 шара нет, одна строка на %d, дальше только рост: %s" % (first, seen))

print("5. шар приклеен к полосам и едет с ними")
for q in (10, 15, 25, 35, 45, 50):
    if 20 - bar(q, 0) != UP_LAST - bar(q, 0):
        fail("на DUCK %d шар не на строку выше полос" % q)
ok("низ шара всегда на строку выше полос")

print("6. длина, впадина и потолок")
if bar(50, 0) != 7 or bar(50, 8) != 16:
    fail("на DUCK 50 полосы не те: %s" % [bar(50, k) for k in range(NB)])
if bar(0, 0) != 19 or bar(0, 8) != 19:
    fail("на DUCK 0 полосы должны стоять в потолке")
if bar(10, 1) != 16 or bar(10, 2) != 15:
    fail("впадина на втором кадре не та")
if bar(50, 2) >= bar(50, 0):
    fail("на DUCK 50 третья полоса не ниже первой")
rows = [bar(50, k) for k in range(NB)]
if rows != [7, 4, 3, 7, 10, 13, 15, 16, 16]:
    fail("на DUCK 50 длины не как в кадре: %s" % rows)
ok("длины по концам и в середине совпадают с рисунками")

print("7. подключение")
if "PREVIEW_DUCK:            /* the bars and the balls are laid on the mask itself */" not in src:
    fail("PREVIEW_DUCK не попал в таблицу смещений")
if "case PREVIEW_DUCK:      pv_duck(mask, &v);      break;" not in src:
    fail("нет вызова pv_duck в отрисовке")
if "pv_tab(PV_DUCK" in src:
    fail("старая таблица PV_DUCK ещё используется")
if "static const int8_t PV_DUCK[16]" in src:
    fail("старая таблица PV_DUCK осталась в файле")
hdr = open(HDR, encoding="utf-8", errors="replace").read()
m = re.search(r"PREVIEW_DUCK,\s*/\*(.*?)\*/", hdr)
if not m:
    fail("нет строки PREVIEW_DUCK в заголовке")
elif "ball" not in m.group(1):
    fail("заголовок не описывает шар: %s" % m.group(1).strip())
block = src[src.index("static int pv_ox_for"):]
block = block[:block.index("static int pv_oy_for")]
if "PREVIEW_DUCK" not in block:
    fail("PREVIEW_DUCK не стоит в списке без смещения")
ok("отрисовка, смещение, заголовок и старая таблица — в порядке")

print()
if FAIL:
    for f in FAIL:
        print("ПРОВАЛ: " + f)
    sys.exit(1)
print("DUCK: всё сходится")
