"""Фигура CHORUS DEPTH: что рисует прошивка против утверждённой картинки.

Эталоны — маски, которые владелец утвердил; его собственные пять кадров тоже лежат
здесь и сверяются с допуском: в двух кадрах дуги округлены по-своему на несколько
пикселей, и требовать совпадения до точки нельзя.
"""
import io
import re
import sys

sys.stdout.reconfigure(encoding="utf-8")

SRC = io.open("components/synth_ui/src/synth_ui_preview.c", encoding="utf-8").read()
HDR = io.open("components/synth_ui/src/synth_ui_preview.h", encoding="utf-8").read()

problems = []

# маски, утверждённые владельцем
REF = [
    "000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001f800000000fff00000001e0780000003801c0000007000e000000e0007000000c0003000000c0003000001800018000018000180000180001800001800018000018000180000180001800000c0003000000c0003000000e00070000007000e0000003801c0000001e0780000000fff000000001f800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",  # ступень 1
    "0000000000000000000000000000000000000000000000000000000000000000000000000000000001f800000000fff00000001e0780000003801c0000007f9fe000000fffff000001e1f87800003c39c3c0000787fe1e0000f8fff1f0000d9e079b0000dbc03db00019f801f980019f801f980018d801b180018d801b180019f801f980019f801f98000dbc03db0000d9e079b0000f8fff1f0000787fe1e00003c39c3c00001e1f87800000fffff0000007f9fe0000003801c0000001e0780000000fff000000001f8000000000000000000000000000000000000000000000000000000000000000000000000000000000",  # ступень 2
    "000000000000000000000000000000000000000000000000000000000001f800000000fff00000001e0780000003801c0000007000e000000e0007000000fe07f000003fffffc0000781f81e0000f80f01f0001d81f81b80039839c19c003183fc18c00318fff18c0060de07b060060fe07f060060f606f060060f606f060060fe07f060060de07b0600318fff18c003183fc18c0039839c19c001d81f81b8000f80f01f0000781f81e00003fffffc00000fe07f000000e00070000007000e0000003801c0000001e0780000000fff000000001f800000000000000000000000000000000000000000000000000000000000",  # ступень 3
    "00000000000000000000000000000000000001f800000000fff00000001e0780000003801c0000007000e000000e0007000000c0003000000c0003000001f801f80000fff0fff0001f879e1f8003981f819c007180f018e00e180f018700c0c0f030300c0c0f03030180e1f870181807fffe0181803f9fc0181803f9fc0181807fffe018180e1f870180c0c0f030300c0c0f030300e180f0187007180f018e003981f819c001f879e1f8000fff0fff00001f801f800000c0003000000c0003000000e00070000007000e0000003801c0000001e0780000000fff000000001f80000000000000000000000000000000000000",  # ступень 4
    "0000000000000001f800000000fff00000001e0780000003801c0000007000e000000e0007000000c0003000000c00030000018000180000180001800007e0007e0003ffc03ffc00799e0799e00e1870e18701c0c39c3038380c1f8301c300e0f0700c30070f0e00c6003861c0066001e6780066000fff00066000fff00066001e6780066003861c00630070f0e00c300e0f0700c380c1f8301c1c0c39c30380e1870e18700799e0799e003ffc03ffc0007e0007e000018000180000180001800000c0003000000c0003000000e00070000007000e0000003801c0000001e0780000000fff000000001f8000000000000000",  # ступень 5
]

# его кадры, для допуска
HIS = [
    "000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001f800000000fff00000001e0780000003801c0000007000e000000e0007000000c0003000000c0003000001800018000018000180000180001800001800018000018000180000180001800000c0003000000c0003000000e00070000007000e0000003801c0000001e0780000000fff000000001f800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",  # кадр 1
    "0000000000000000000000000000000000000000000000000000000000000000000000000000000001f800000000fff00000001e0780000003801c0000007f9fe000000fffff000001e1f87800003c39c3c0000787fe1e0000f8fff1f0000d9e079b0000dbc03db00019f801f980019f801f980018d801b180018d801b180019f801f980019f801f98000dbc03db0000d9e079b0000f8fff1f0000787fe1e00003c39c3c00001e1f87800000fffff0000007f9fe0000003801c0000001e0780000000fff000000001f8000000000000000000000000000000000000000000000000000000000000000000000000000000000",  # кадр 2
    "000000000000000000000000000000000000000000000000000000000001f800000000fff00000001e0780000003801c0000007000e000000e0007000000fe07f000003fffffc00007c1f83e0000f80f01f0001d81f81b80039839c19c003183fc18c00318fff18c0060df0fb060060fe07f060060f606f060060f606f060060fe07f060060df0fb0600318fff18c003183fc18c0039839c19c001d81f81b8000f80f01f00007c1f83e00003fffffc00000fe07f000000e00070000007000e0000003801c0000001e0780000000fff000000001f800000000000000000000000000000000000000000000000000000000000",  # кадр 3
    "00000000000000000000000000000000000001f800000000fff00000001e0780000003801c0000007000e000000e0007000000c0003000000c0003000001f801f80000fff0fff0001f879e1f8003981f819c007180f018e00e180f018700c1c0f030300c0c0f83030180e1f870181807fffe0181803f9fc0181803f9fc0181807fffe018180e1f870180c0c0f030300c0c0f030300e180f0187007180f018e003981f819c001f879e1f8000fff0fff00001f801fc00000c0003000000c0003000000e00070000007000e0000003801c0000001e0780000000fff000000001f80000000000000000000000000000000000000",  # кадр 4
    "0000000000000001f800000000fff00000001e0780000003801c0000007000e000000e0007000000c0003000000c00030000018000180000180001800007e0007e0003ffc03ffc00799e0799e00e1870e18701c0c39c3038380c1f8301c300e0f0700c30070f0e00c6003861c0066001e6780066000fff00066000fff00066001e6780066003861c00630070f0e00c300e0f0700c380c1f8301c1c0c39c30380e1870e18700799e0799e003ffc03ffc0007e0007e000018000180000180001800000c0003000000c0003000000e00070000007000e0000003801c0000001e0780000000fff000000001f8000000000000000",  # кадр 5
]

AREA_X0 = int(re.search(r"#define\s+PV_AREA_X0\s+(\d+)", SRC).group(1))
AREA_Y0 = int(re.search(r"#define\s+PV_AREA_Y0\s+(\d+)", SRC).group(1))


def const(name):
    m = re.search(r"#define\s+%s\s+(-?\d+)" % name, SRC)
    if not m:
        problems.append("нет константы %s" % name)
        return 0
    return int(m.group(1))


R = const("PV_CD_R")
THICK = const("PV_CD_THICK")
STAGES = const("PV_CD_STAGES")

m = re.search(r"PV_CD_SPREAD\[PV_CD_STAGES\]\s*=\s*\{([^}]*)\}", SRC)
SPREAD = [int(v) for v in re.findall(r"\d+", m.group(1))] if m else []
if SPREAD != [0, 4, 6, 8, 10]:
    problems.append("таблица разъездов %s, а в кадрах 0/4/6/8/10" % SPREAD)
if R != 22 or THICK != 4 or STAGES != 5:
    problems.append("радиус/толщина/число кадров не те: %d %d %d" % (R, THICK, STAGES))


def spread(q):
    u = q * 8
    i = u // 100
    f = u % 100
    if i >= STAGES - 1:
        return 2 * SPREAD[STAGES - 1]
    num = 200 * SPREAD[i] + 2 * (SPREAD[i + 1] - SPREAD[i]) * f
    return (num + 50) // 100


def mask_at(q):
    s2 = spread(q)
    cx = 2 * AREA_X0 + 44
    cy = 2 * AREA_Y0 + 44
    ox = (0, 0, -s2, s2)
    oy = (-s2, s2, 0, 0)
    g = [[0] * 56 for _ in range(56)]
    for y in range(44):
        py = 2 * (AREA_Y0 + y) + 1
        for x in range(44):
            px = 2 * (AREA_X0 + x) + 1
            for k in range(4):
                dx = px - (cx + ox[k])
                dy = py - (cy + oy[k])
                d2 = dx * dx + dy * dy
                if d2 <= R * R and d2 >= (R - THICK) * (R - THICK):
                    g[AREA_Y0 + y][AREA_X0 + x] = 1
                    break
    return g


def unpack(hexstr):
    bits = "".join(format(b, "08b") for b in bytes.fromhex(hexstr))
    return [[1 if bits[y * 44 + x] == "1" else 0 for x in range(44)] for y in range(44)]


for n, q in enumerate((0, 12, 25, 38, 50)):
    want = unpack(REF[n])
    mine = mask_at(q)
    a = [[mine[AREA_Y0 + y][AREA_X0 + x] for x in range(44)] for y in range(44)]
    diff = sum(1 for y in range(44) for x in range(44) if a[y][x] != want[y][x])
    if diff:
        problems.append("ступень %d (q=%d): маска расходится с утверждённой в %d точках"
                        % (n + 1, q, diff))

# допуск к его кадрам: дуги в двух кадрах он округлил по-своему
for n, q in enumerate((0, 12, 25, 38, 50)):
    want = unpack(HIS[n])
    mine = mask_at(q)
    a = [[mine[AREA_Y0 + y][AREA_X0 + x] for x in range(44)] for y in range(44)]
    diff = sum(1 for y in range(44) for x in range(44) if a[y][x] != want[y][x])
    if diff > 10:
        problems.append("кадр %d (q=%d): от его картинки %d точек, больше допуска 10"
                        % (n + 1, q, diff))

# разъезд только растёт, фигура не вылезает за поле
prev = -1
for q in range(0, 51):
    s2 = spread(q)
    if s2 < prev:
        problems.append("q=%d: кольца сдвинулись назад" % q)
    prev = s2
    if s2 % 2:
        pass
    if s2 > 2 * SPREAD[-1]:
        problems.append("q=%d: разъезд %d больше кадра" % (q, s2))
    mask = mask_at(q)
    for y in range(56):
        for x in range(56):
            if mask[y][x] and not (AREA_X0 <= x < AREA_X0 + 44 and AREA_Y0 <= y < AREA_Y0 + 44):
                problems.append("q=%d: точка (%d, %d) вне поля" % (q, x, y))
                break

# фигура не сужается с ходом
prev = None
for q in range(0, 51):
    mask = mask_at(q)
    ys = [y for y in range(56) if any(mask[y])]
    xs = [x for x in range(56) if any(mask[y][x] for y in range(56))]
    size = (max(xs) - min(xs), max(ys) - min(ys))
    if prev is not None and (size[0] < prev[0] or size[1] < prev[1]):
        problems.append("q=%d: фигура сузилась" % q)
    prev = size

# --- куда поставлена ---------------------------------------------------------
if "PREVIEW_CHORUS_DEPTH" not in HDR:
    problems.append("нет вида PREVIEW_CHORUS_DEPTH в заголовке")

sw = SRC[SRC.index("static synth_preview_kind_t pv_values"):]
sw = sw[:sw.index("\n}\n")]
LABELS, pending = {}, []
for mm in re.finditer(r"case (SYNTH_PARAM_\w+):|return (PREVIEW_\w+);", sw):
    if mm.group(1):
        pending.append(mm.group(1))
    else:
        for label in pending:
            LABELS.setdefault(label, mm.group(2))
        pending = []

WANT = {
    "SYNTH_PARAM_CHORUS_DEPTH": "PREVIEW_CHORUS_DEPTH",
    "SYNTH_PARAM_MOTION_DEPTH": "PREVIEW_CHORUS_DEPTH",
    "SYNTH_PARAM_CHORUS_RATE": "PREVIEW_CHORUS_RATE",
    "SYNTH_PARAM_CHORUS_MIX": "PREVIEW_NONE",
    "SYNTH_PARAM_DELAY_FEEDBACK": "PREVIEW_DELAY_FEEDBACK",
    "SYNTH_PARAM_VERB_SIZE": "PREVIEW_VERB_SIZE",
}
for param, kind in WANT.items():
    if LABELS.get(param) != kind:
        problems.append("%s отдаёт %s, а должен %s" % (param, LABELS.get(param), kind))

if not re.search(r"case PREVIEW_CHORUS_DEPTH:\s*pv_chorus_depth\(", SRC):
    problems.append("нет вызова pv_chorus_depth в переключателе")

if problems:
    print("FAIL: фигура CHORUS DEPTH")
    for p in problems:
        print("  -", p)
    sys.exit(1)

print("OK: CHORUS DEPTH — четыре кольца радиусом 11 и толщиной два, разъезд крестом "
      "0/4/6/8/10 в половинах пикселя; стоит на DEPTH страницы CHORUS и на WIDTH "
      "страницы DRONE, у RATE своя фигура (см. chorus-rate.py), у MIX фигуры нет")
