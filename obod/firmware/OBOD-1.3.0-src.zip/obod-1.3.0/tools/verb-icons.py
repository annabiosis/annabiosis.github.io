"""Иконки типов реверба: прошивка против четырёх картинок владельца.

Четыре таблицы 44 x 6, по одной на алгоритм, в порядке SYNTH_REVERB_*. Гейт собирает
их обратно в маски, сверяет с картинками точка в точку и проверяет то, на чём владелец
споткнулся в прошлый раз: каждая иконка должна стоять по центру поля, а не со сдвигом.
"""
import io
import re
import sys

sys.stdout.reconfigure(encoding="utf-8")

SRC = io.open("components/synth_ui/src/synth_ui_preview.c", encoding="utf-8").read()
HDR = io.open("components/synth_ui/src/synth_ui_preview.h", encoding="utf-8").read()
DSP = io.open("components/synth_dsp/include/synth_dsp.h", encoding="utf-8").read()

problems = []

REF = {
    "ROOM":
        "0000000000000000000000001fffffffc003fffffffc0078000000c00f8000000c01d8000000c0398000000c0718000000c0e18000000c1c18000000c3818000000c3018000000c3018000000c3018000000c3018000000c3018000000c3018000000c3018000000c3018000000c3018000000c3018000000c3018000000c3018000000c3018000000c3018000000c3018000000c3018000000c3018000000c3018000000c3018000000c301fffffffc303fffffffc3070000003830e0000007031c000000e0338000001c0370000003803e0000007003c000000e003fffffffc003fffffff8000000000000000000000000",
    "HALL":
        "000000000007fffffffffe7fffffffffe7800000001e7c00000003e6e000000076670000000e6638000001c661c0000038660e0000070660700000e06603fffffc06601fffff806601800018066018000180660180001806601800018066018000180660180001806601800018066018000180660180001806601800018066018000180660180001806601800018066018000180660180001806601800018066018000180660180001806601fffff806603fffffc0660700000e0660e0000070661c00000386638000001c6670000000e66e0000000767c00000003e7800000001e7fffffffffe7fffffffffe00000000000",
    "CATH":
        "0000000000000007fe00000003fffc000000fc03f000003e0007c0000780001e0000e0000070001c00000380038000001c0070000000e00e0000000700c0000000301c000000038180000000183800000001c3000000000c3000000000c7000000000e60000000006600000000066000000000660001f800066000fff00066001e0780066003801c0066007000e006600e0007006600c0003006600c00030066018000180660180001806601800018066018000180660180001806601800018066018000180660180001806601800018066018000180660180001806601800018067fffffffffe7fffffffffe00000000000",
    "PLAT":
        "000000000000000000000000000000000000000000000000000000000000000000000007ffffc00000fffffe00001c0001c00003800038000070000700000e0000e00001c0001c00003800038000070000700000e0000e00001c0001ffc00380003ffe0070000701c00e0000e03801c0001c070038000380e0070000701c00e0000e03801c0001c070038000380e007fffff01c003ffffe038000070000700000e0000e00001c0001c00003800038000070000700000e0000e00001c0001c0000380003800007fffff000003ffffe00000000000000000000000000000000000000000000000000000000000000000000000",
}

AREA_X0 = int(re.search(r"#define\s+PV_AREA_X0\s+(\d+)", SRC).group(1))
AREA_Y0 = int(re.search(r"#define\s+PV_AREA_Y0\s+(\d+)", SRC).group(1))

# порядок алгоритмов в движке: иконки обязаны идти так же
ALIAS = {"ROOM": "ROOM", "HALL": "HALL", "CATHEDRAL": "CATH", "PLATE": "PLAT"}
if "SYNTH_REVERB_ROOM" in DSP and "SYNTH_REVERB_MODE_COUNT" in DSP:
    block = DSP[DSP.index("SYNTH_REVERB_ROOM"):DSP.index("SYNTH_REVERB_MODE_COUNT")]
    ORDER = [ALIAS[name] for name in re.findall(r"SYNTH_REVERB_(\w+)", block)
             if name in ALIAS]
else:
    problems.append("не нашёл порядок SYNTH_REVERB_*")
    ORDER = ["ROOM", "HALL", "CATH", "PLAT"]


def table(name):
    m = re.search(r"PV_ALGO_%s\[44 \* 6\]\s*=\s*\{(.*?)\n\};" % name, SRC, re.S)
    if not m:
        problems.append("нет таблицы PV_ALGO_%s" % name)
        return None
    vals = [int(v, 16) for v in re.findall(r"0x([0-9A-Fa-f]{2})", m.group(1))]
    if len(vals) != 44 * 6:
        problems.append("PV_ALGO_%s: байт %d, а нужно 264" % (name, len(vals)))
        return None
    return [vals[i:i + 6] for i in range(0, 44 * 6, 6)]


def art(name):
    rows = table(name)
    if rows is None:
        return None
    g = [[0] * 44 for _ in range(44)]
    for y in range(44):
        for b in range(6):
            for k in range(8):
                x = b * 8 + k
                if x < 44 and rows[y][b] & (0x80 >> k):
                    g[y][x] = 1
    return g


def unpack(hexstr):
    bits = "".join(format(b, "08b") for b in bytes.fromhex(hexstr))
    return [[1 if bits[y * 44 + x] == "1" else 0 for x in range(44)] for y in range(44)]


for name in ("ROOM", "HALL", "CATH", "PLAT"):
    want = unpack(REF[name])
    mine = art(name)
    if mine is None:
        continue
    diff = [(x, y) for y in range(44) for x in range(44) if mine[y][x] != want[y][x]]
    if diff:
        problems.append("иконка %s расходится с картинкой в %d точках, например %s"
                        % (name, len(diff), diff[:6]))
        continue

    # центрирование: поля габарита слева и справа (сверху и снизу) должны быть равны
    xs = [x for x in range(44) if any(mine[y][x] for y in range(44))]
    ys = [y for y in range(44) if any(mine[y])]
    if not xs:
        problems.append("иконка %s пустая" % name)
        continue
    left, right = min(xs), 43 - max(xs)
    top, bottom = min(ys), 43 - max(ys)
    if abs(left - right) > 1:
        problems.append("иконка %s стоит не по центру по горизонтали: поля %d и %d"
                        % (name, left, right))
    if abs(top - bottom) > 1:
        problems.append("иконка %s стоит не по центру по вертикали: поля %d и %d"
                        % (name, top, bottom))

# порядок иконок в выборе
sel = SRC[SRC.index("static void pv_verb_mode"):]
sel = sel[:sel.index("\n}\n")]
order_in_code = re.findall(r"PV_ALGO_(\w+)", sel)
if order_in_code != ORDER:
    problems.append("порядок иконок %s, а в движке %s" % (order_in_code, ORDER))

# сдвиг вида нулевой: иначе иконки съедут
ox = SRC[SRC.index("static int pv_ox_for"):]
ox = ox[:ox.index("\n}\n")]
if not re.search(r"case PREVIEW_VERB_MODE:[^\n]*\n(?:[^\n]*\n)*?\s*return 0;", ox):
    problems.append("у PREVIEW_VERB_MODE ненулевой сдвиг: иконка съедет с центра")

if "PREVIEW_VERB_MODE" not in HDR:
    problems.append("нет вида PREVIEW_VERB_MODE в заголовке")
if not re.search(r"case SYNTH_PARAM_VERB_MODE:(?:(?!case ).)*?return PREVIEW_VERB_MODE;",
                 SRC, re.S):
    problems.append("ALGO не отдаёт PREVIEW_VERB_MODE")
if not re.search(r"case PREVIEW_VERB_MODE:\s*pv_verb_mode\(", SRC):
    problems.append("нет вызова pv_verb_mode в переключателе")

if problems:
    print("FAIL: иконки типов реверба")
    for p in problems:
        print("  -", p)
    sys.exit(1)

print("OK: типы реверба — четыре иконки 44 x 44 в порядке ROOM / HALL / CATH / PLAT, "
      "все совпадают с картинками точка в точку и стоят по центру поля, сдвиг вида "
      "нулевой; сектор ALGO страницы REVERB показывает иконку алгоритма")
