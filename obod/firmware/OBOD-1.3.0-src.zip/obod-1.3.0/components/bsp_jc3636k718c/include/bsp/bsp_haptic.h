/*
 * Haptic feedback through the LRA vibration motor.
 *
 * THERE IS NO HAPTIC GPIO ON THIS BOARD.
 *
 * The motor is driven by a DRV2605L (U13) sitting on the same I2C bus as the
 * touch controller, at address 0x5A. Its IN/TRIG pin is tied to ground and EN
 * is tied to 3V3, so the part is permanently enabled and the only way to make
 * it vibrate is to talk to it over I2C.
 *
 * The DRV2605L has a ROM of 123 haptic effects and can play them
 * autonomously: bsp_haptic_play_effect() writes two registers and returns, and
 * the waveform continues without the CPU. That is what the UI should use —
 * a detent click must not block the render loop.
 *
 * bsp_haptic_pulse() additionally offers a sustained buzz for the cases where
 * a fixed-length vibration is wanted (an alarm, a long-press acknowledgement).
 * It drives the part in real-time-playback mode and stops it from a timer, so
 * it does not block either.
 */
#pragma once

#include <stdbool.h>
#include <stdint.h>
#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

/*
 * A few of the built-in ROM effects, for readability at call sites. Any value
 * from 1 to 123 is accepted by bsp_haptic_play_effect(); 0 means "no effect"
 * and is used to terminate a waveform sequence.
 *
 * Library 6 (LRA) is selected at init, so these numbers map to the LRA effect
 * table.
 */
typedef enum {
    BSP_HAPTIC_STRONG_CLICK_100 = 1,
    BSP_HAPTIC_SHARP_CLICK_100  = 4,
    BSP_HAPTIC_SOFT_BUMP_100    = 7,
    BSP_HAPTIC_DOUBLE_CLICK_100 = 10,
    BSP_HAPTIC_TRIPLE_CLICK_100 = 12,
    BSP_HAPTIC_STRONG_BUZZ_100  = 14,
    BSP_HAPTIC_BUZZ_1_100       = 47,
    BSP_HAPTIC_PULSING_1_100    = 52,
} bsp_haptic_effect_t;

/* Default feedback strength for bsp_haptic_pulse(), 0..127. */
#define BSP_HAPTIC_RTP_DEFAULT 0x60

/*
 * Probe and configure the driver, including a best-effort auto-calibration.
 *
 * Returns ESP_ERR_NOT_FOUND when nothing answers at 0x5A. That is not fatal:
 * a board revision without the motor, or a failed part, should still boot a
 * working UI.
 */
esp_err_t bsp_haptic_init(void);
esp_err_t bsp_haptic_deinit(void);

bool bsp_haptic_is_available(void);

/*
 * Play one ROM effect. Returns immediately; the driver plays the waveform on
 * its own. Anything already playing is replaced.
 *
 * `effect` is 1..123, or 0 to stop.
 */
esp_err_t bsp_haptic_play_effect(uint8_t effect);

/* Short click — the feedback for a detent or a tap. */
esp_err_t bsp_haptic_tick(void);

/*
 * Sustained vibration for `duration_ms`, at `strength` (0..127, 0 selects
 * BSP_HAPTIC_RTP_DEFAULT). Non-blocking: the stop is scheduled on a timer.
 *
 * Requests longer than BSP_HAPTIC_MAX_PULSE_MS are clamped — an LRA held on
 * for seconds gets hot and sounds awful.
 */
esp_err_t bsp_haptic_pulse(uint32_t duration_ms);
esp_err_t bsp_haptic_pulse_strength(uint32_t duration_ms, uint8_t strength);

/* Stop any effect or pulse immediately. */
esp_err_t bsp_haptic_stop(void);

/*
 * Re-run auto-calibration.
 *
 * The DRV2605L needs this to characterise the particular LRA it is driving;
 * it runs once automatically at init. Re-run it after a firmware update that
 * changes CONTROL1..3, or if feedback feels weak or mushy.
 */
esp_err_t bsp_haptic_calibrate(void);

/*
 * Raw STATUS register from the last calibration, or 0 if none has run.
 * Useful when feedback is present but weak: pair it with the calibration
 * values logged during init.
 */
uint8_t bsp_haptic_calibration_status(void);

#ifdef __cplusplus
}
#endif
