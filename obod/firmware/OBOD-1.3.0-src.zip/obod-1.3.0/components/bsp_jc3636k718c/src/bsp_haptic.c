/*
 * DRV2605L haptic driver — see bsp_haptic.h for why this is I2C and not a
 * GPIO.
 *
 * Register offsets and mode values follow the DRV2605/DRV2605L datasheet
 * (TI SLOS854). They are easy to get wrong by one: FEEDBACK_CTRL is 0x1A, not
 * 0x18, and the real-time playback mode is 5, not 4 (4 is audio-to-vibration).
 * Both mistakes produce a chip that talks happily on I2C and never moves.
 *
 * The init and effect sequences mirror those used by a shipping firmware for
 * this exact board, which works in open loop against the ROM library — no
 * auto-calibration. That is the default here too; see
 * CONFIG_BSP_HAPTIC_AUTO_CALIBRATE.
 */

#include "bsp/bsp_haptic.h"

#include <string.h>

#include "esp_check.h"
#include "esp_log.h"
#include "esp_timer.h"

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "bsp/bsp_pins.h"
#include "bsp_i2c.h"

static const char *TAG = "bsp.haptic";

/* --- Register map --------------------------------------------------------- */
#define DRV2605_REG_STATUS       0x00
#define DRV2605_REG_MODE         0x01
#define DRV2605_REG_RTP          0x02  /* real-time playback amplitude */
#define DRV2605_REG_LIBRARY      0x03
#define DRV2605_REG_WAVESEQ1     0x04
#define DRV2605_REG_WAVESEQ2     0x05
#define DRV2605_REG_GO           0x0C
#define DRV2605_REG_OVERDRIVE    0x0D
#define DRV2605_REG_SUSTAIN_POS  0x0E
#define DRV2605_REG_SUSTAIN_NEG  0x0F
#define DRV2605_REG_BRAKE        0x10
#define DRV2605_REG_RATED_VOLT   0x16  /* auto-cal input */
#define DRV2605_REG_OD_CLAMP     0x17  /* auto-cal input */
#define DRV2605_REG_A_CAL_COMP   0x18  /* auto-cal result, read-only */
#define DRV2605_REG_A_CAL_BEMF   0x19  /* auto-cal result, read-only */
#define DRV2605_REG_FEEDBACK     0x1A  /* actuator type and gains */
#define DRV2605_REG_CONTROL1     0x1B
#define DRV2605_REG_CONTROL2     0x1C
#define DRV2605_REG_CONTROL3     0x1D
#define DRV2605_REG_CONTROL4     0x1E
#define DRV2605_REG_CONTROL5     0x1F
#define DRV2605_REG_OL_LRA       0x20
#define DRV2605_REG_LRA_PERIOD   0x22

/* --- MODE (0x01) ----------------------------------------------------------
 * Bits [2:0] select the mode; bit 6 is STANDBY, bit 7 is DEV_RESET.
 */
#define DRV2605_MODE_INT_TRIG    0x00  /* play the WAVESEQ on GO */
#define DRV2605_MODE_RTP         0x05  /* drive amplitude straight from RTP */
#define DRV2605_MODE_AUTOCAL     0x07  /* run auto-calibration on GO */
#define DRV2605_MODE_STANDBY     0x40
#define DRV2605_MODE_DEV_RESET   0x80

/* --- LIBRARY (0x03) ------------------------------------------------------- */
#define DRV2605_LIBRARY_LRA      6

/*
 * --- FEEDBACK_CTRL (0x1A) -------------------------------------------------
 * N_ERM_LRA = 1 (LRA), FB_BRAKE_FACTOR = 3, LOOP_GAIN = 1, BEMF_GAIN = 2.
 */
#define DRV2605_FEEDBACK_LRA     0xB6

/* --- STATUS (0x00) -------------------------------------------------------- */
#define DRV2605_STATUS_DIAG_RESULT 0x08

#define DRV2605_I2C_TIMEOUT_MS   100
#define DRV2605_I2C_FREQ_HZ      400000

/* Auto-calibration takes a few hundred milliseconds; give it a hard ceiling
 * so a dead part cannot stall boot. */
#define DRV2605_CAL_TIMEOUT_MS   2000
#define DRV2605_CAL_POLL_MS      20

#define BSP_HAPTIC_MAX_PULSE_MS  2000

static i2c_master_dev_handle_t s_dev;
static esp_timer_handle_t      s_pulse_timer;
static bool                    s_available;
static uint8_t                 s_cal_status;

/* -------------------------------------------------------------------------- */
/* Register access                                                            */
/* -------------------------------------------------------------------------- */

static esp_err_t reg_write(uint8_t reg, uint8_t value)
{
    const uint8_t buffer[2] = { reg, value };
    return i2c_master_transmit(s_dev, buffer, sizeof(buffer), DRV2605_I2C_TIMEOUT_MS);
}

static esp_err_t reg_read(uint8_t reg, uint8_t *value)
{
    return i2c_master_transmit_receive(s_dev, &reg, 1, value, 1, DRV2605_I2C_TIMEOUT_MS);
}

/*
 * Put the actuator configuration back the way the ROM library expects it.
 *
 * Written before every effect rather than only at init: two register writes at
 * 400 kHz cost microseconds, and it makes playback immune to anything else
 * having poked the mode or the library in the meantime.
 */
static esp_err_t apply_actuator_config(void)
{
    ESP_RETURN_ON_ERROR(reg_write(DRV2605_REG_MODE, DRV2605_MODE_INT_TRIG), TAG, "mode");
    return reg_write(DRV2605_REG_LIBRARY, DRV2605_LIBRARY_LRA);
}

/* -------------------------------------------------------------------------- */
/* Pulse timer                                                                */
/* -------------------------------------------------------------------------- */

static void pulse_stop_cb(void *arg)
{
    (void)arg;
    if (!s_available) {
        return;
    }
    /* Drop the drive, then park the part back in waveform mode so the next
     * bsp_haptic_play_effect() works without touching MODE again. */
    reg_write(DRV2605_REG_RTP, 0);
    reg_write(DRV2605_REG_MODE, DRV2605_MODE_INT_TRIG);
}

/* -------------------------------------------------------------------------- */
/* Public API                                                                 */
/* -------------------------------------------------------------------------- */

esp_err_t bsp_haptic_init(void)
{
    if (s_available) {
        return ESP_OK;
    }

    ESP_RETURN_ON_ERROR(bsp_i2c_init(), TAG, "i2c bus");
    i2c_master_bus_handle_t bus = bsp_i2c_get_bus();
    if (!bus) {
        return ESP_ERR_INVALID_STATE;
    }

    /* A plain register read is the presence test: the DRV2605L has no ID
     * register, so anything that answers at 0x5A is it. */
    if (i2c_master_probe(bus, BSP_HAPTIC_I2C_ADDR, DRV2605_I2C_TIMEOUT_MS) != ESP_OK) {
        ESP_LOGW(TAG, "no DRV2605L at 0x%02X — haptics disabled", BSP_HAPTIC_I2C_ADDR);
        return ESP_ERR_NOT_FOUND;
    }

    const i2c_device_config_t dev_cfg = {
        .dev_addr_length = I2C_ADDR_BIT_LEN_7,
        .device_address  = BSP_HAPTIC_I2C_ADDR,
        .scl_speed_hz    = DRV2605_I2C_FREQ_HZ,
    };
    ESP_RETURN_ON_ERROR(i2c_master_bus_add_device(bus, &dev_cfg, &s_dev),
                        TAG, "i2c_master_bus_add_device");

    /* Reset, then let the part settle before configuring it. */
    ESP_RETURN_ON_ERROR(reg_write(DRV2605_REG_MODE, DRV2605_MODE_DEV_RESET),
                        TAG, "device reset");
    vTaskDelay(pdMS_TO_TICKS(10));

    /*
     * Configure the actuator while the part is in standby — after DEV_RESET it
     * is already there, and configuring it live risks a jolt as the gains
     * change under a running output stage.
     */
    ESP_RETURN_ON_ERROR(reg_write(DRV2605_REG_FEEDBACK, DRV2605_FEEDBACK_LRA),
                        TAG, "feedback config");
    ESP_RETURN_ON_ERROR(reg_write(DRV2605_REG_LIBRARY, DRV2605_LIBRARY_LRA),
                        TAG, "library select");

    /* Clear the waveform slots and the drive-shaping offsets so no residue
     * colours the first effect. */
    reg_write(DRV2605_REG_WAVESEQ1,   0);
    reg_write(DRV2605_REG_WAVESEQ2,   0);
    reg_write(DRV2605_REG_OVERDRIVE,  0);
    reg_write(DRV2605_REG_SUSTAIN_POS, 0);
    reg_write(DRV2605_REG_SUSTAIN_NEG, 0);
    reg_write(DRV2605_REG_BRAKE,      0);

    /* Leave standby. */
    ESP_RETURN_ON_ERROR(reg_write(DRV2605_REG_MODE, DRV2605_MODE_INT_TRIG),
                        TAG, "leave standby");

    s_available = true;

    const esp_timer_create_args_t timer_args = {
        .callback        = pulse_stop_cb,
        .arg             = NULL,
        .dispatch_method = ESP_TIMER_TASK,
        .name            = "haptic_stop",
    };
    ESP_RETURN_ON_ERROR(esp_timer_create(&timer_args, &s_pulse_timer),
                        TAG, "esp_timer_create");

    ESP_LOGI(TAG, "DRV2605L ready at 0x%02X (LRA, ROM library %d)",
             BSP_HAPTIC_I2C_ADDR, DRV2605_LIBRARY_LRA);

#if CONFIG_BSP_HAPTIC_AUTO_CALIBRATE
    /* Best effort: a part that fails calibration still buzzes, just less
     * precisely, so this never fails init. */
    bsp_haptic_calibrate();
#else
    ESP_LOGI(TAG, "auto-calibration skipped (open-loop ROM playback)");
#endif

    return ESP_OK;
}

bool bsp_haptic_is_available(void)
{
    return s_available;
}

esp_err_t bsp_haptic_play_effect(uint8_t effect)
{
    if (!s_available) {
        return ESP_ERR_NOT_SUPPORTED;
    }
    if (effect > 123) {
        return ESP_ERR_INVALID_ARG;
    }

    esp_timer_stop(s_pulse_timer); /* harmless if idle */

    ESP_RETURN_ON_ERROR(apply_actuator_config(), TAG, "actuator config");
    ESP_RETURN_ON_ERROR(reg_write(DRV2605_REG_WAVESEQ1, effect), TAG, "seq1");
    /* A zero in the second slot terminates the sequence after one effect. */
    ESP_RETURN_ON_ERROR(reg_write(DRV2605_REG_WAVESEQ2, 0), TAG, "seq2");

    if (effect == 0) {
        return ESP_OK;
    }
    /* GO self-clears once the waveform finishes. */
    return reg_write(DRV2605_REG_GO, 1);
}

esp_err_t bsp_haptic_tick(void)
{
    return bsp_haptic_play_effect(BSP_HAPTIC_STRONG_CLICK_100);
}

esp_err_t bsp_haptic_pulse_strength(uint32_t duration_ms, uint8_t strength)
{
    if (!s_available) {
        return ESP_ERR_NOT_SUPPORTED;
    }
    if (duration_ms == 0) {
        return bsp_haptic_stop();
    }
    if (duration_ms > BSP_HAPTIC_MAX_PULSE_MS) {
        ESP_LOGW(TAG, "pulse clamped to %d ms", BSP_HAPTIC_MAX_PULSE_MS);
        duration_ms = BSP_HAPTIC_MAX_PULSE_MS;
    }
    if (strength > 127) {
        strength = 127;
    }

    esp_timer_stop(s_pulse_timer);

    /* Real-time playback: the RTP register sets the drive amplitude directly
     * and the part holds it until the register is written back to zero. */
    ESP_RETURN_ON_ERROR(reg_write(DRV2605_REG_MODE, DRV2605_MODE_RTP), TAG, "rtp mode");
    ESP_RETURN_ON_ERROR(reg_write(DRV2605_REG_RTP, strength), TAG, "rtp level");

    return esp_timer_start_once(s_pulse_timer, (uint64_t)duration_ms * 1000ULL);
}

esp_err_t bsp_haptic_pulse(uint32_t duration_ms)
{
    return bsp_haptic_pulse_strength(duration_ms, BSP_HAPTIC_RTP_DEFAULT);
}

esp_err_t bsp_haptic_stop(void)
{
    if (!s_available) {
        return ESP_ERR_NOT_SUPPORTED;
    }

    esp_timer_stop(s_pulse_timer);

    reg_write(DRV2605_REG_RTP, 0);
    /* GO = 0 aborts a waveform sequence mid-flight; STANDBY forces the output
     * stage off regardless of what the sequencer thinks it is doing. */
    reg_write(DRV2605_REG_GO, 0);
    esp_err_t err = reg_write(DRV2605_REG_MODE,
                              DRV2605_MODE_INT_TRIG | DRV2605_MODE_STANDBY);
    vTaskDelay(pdMS_TO_TICKS(2));
    reg_write(DRV2605_REG_MODE, DRV2605_MODE_INT_TRIG);
    return err;
}

esp_err_t bsp_haptic_calibrate(void)
{
    if (!s_available) {
        return ESP_ERR_NOT_SUPPORTED;
    }

    /*
     * The datasheet's recommended order for an LRA:
     *   1. select the LRA actuator (already done at init);
     *   2. load the rated voltage and the overdrive clamp;
     *   3. run auto-calibration;
     *   4. read back the compensation values.
     *
     * Auto-calibration only works while the part is out of standby and not
     * mid-waveform, hence the explicit mode write first.
     */
    ESP_LOGI(TAG, "auto-calibrating");

    /* Typical LRA values. Auto-calibration refines the result from here. */
    ESP_RETURN_ON_ERROR(reg_write(DRV2605_REG_RATED_VOLT, 0x3E), TAG, "rated voltage");
    ESP_RETURN_ON_ERROR(reg_write(DRV2605_REG_OD_CLAMP, 0x8C), TAG, "od clamp");

    ESP_RETURN_ON_ERROR(reg_write(DRV2605_REG_MODE, DRV2605_MODE_AUTOCAL),
                        TAG, "auto cal mode");
    ESP_RETURN_ON_ERROR(reg_write(DRV2605_REG_GO, 1), TAG, "auto cal start");

    /* GO clears when the routine finishes. */
    bool finished = false;
    for (int waited = 0; waited < DRV2605_CAL_TIMEOUT_MS; waited += DRV2605_CAL_POLL_MS) {
        uint8_t go = 1;
        if (reg_read(DRV2605_REG_GO, &go) == ESP_OK && (go & 0x01) == 0) {
            finished = true;
            break;
        }
        vTaskDelay(pdMS_TO_TICKS(DRV2605_CAL_POLL_MS));
    }

    uint8_t status   = 0;
    uint8_t cal_comp = 0;
    uint8_t cal_bemf = 0;
    ESP_RETURN_ON_ERROR(reg_read(DRV2605_REG_STATUS, &status), TAG, "status");
    reg_read(DRV2605_REG_A_CAL_COMP, &cal_comp);
    reg_read(DRV2605_REG_A_CAL_BEMF, &cal_bemf);
    s_cal_status = status;

    /* Park the part back in waveform mode whatever happened, so a failed
     * calibration cannot leave it stuck. */
    esp_err_t err = apply_actuator_config();

    if (!finished) {
        ESP_LOGW(TAG, "calibration timed out after %d ms (status 0x%02X)",
                 DRV2605_CAL_TIMEOUT_MS, status);
        return ESP_ERR_TIMEOUT;
    }

    ESP_LOGI(TAG, "calibration done: A_CAL_COMP=0x%02X A_CAL_BEMF=0x%02X status=0x%02X%s",
             cal_comp, cal_bemf, status,
             (status & DRV2605_STATUS_DIAG_RESULT) ? " (DIAG_RESULT set)" : "");

    return err;
}

uint8_t bsp_haptic_calibration_status(void)
{
    return s_cal_status;
}

esp_err_t bsp_haptic_deinit(void)
{
    if (!s_available) {
        return ESP_OK;
    }

    esp_timer_stop(s_pulse_timer);
    reg_write(DRV2605_REG_MODE, DRV2605_MODE_INT_TRIG | DRV2605_MODE_STANDBY);

    if (s_pulse_timer) {
        esp_timer_delete(s_pulse_timer);
        s_pulse_timer = NULL;
    }
    if (s_dev) {
        i2c_master_bus_rm_device(s_dev);
        s_dev = NULL;
    }

    s_available = false;
    return ESP_OK;
}
