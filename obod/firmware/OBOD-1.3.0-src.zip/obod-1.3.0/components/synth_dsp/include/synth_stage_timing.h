#pragma once

#include <stdint.h>

/*
 * STAGE TIMING — what each stage of a block costs, measured on the instrument.
 *
 * A block is 256 samples at 48 kHz, so its budget is 5333 us. "The block takes 4.4 ms" says
 * how far the whole is from the deadline and nothing about where the time went; the only
 * useful answer on a chip with no profiler attached is one timer read per stage per block,
 * accumulated, and printed where it can be read from a serial log.
 *
 * OFF BY DEFAULT, and off means absent: every counter, call site and branch below sits
 * behind this flag, so a build with it at 0 costs the release image nothing.
 *
 * HOW THE TWO KINDS OF STAGE ARE TIMED, and why there are two:
 *
 *   block-level stages (the rack's summing, percussion, the three effects, the
 *   filters, the engine's own render) are timed with esp_timer_get_time() around the call.
 *   One pair of reads per stage per block, which is noise against 5333 us.
 *
 *   the per-sample part of the output stage — the compressor and the master gain + soft
 *   clip — cannot be split with that timer: two reads per SAMPLE is 512 reads a block, and
 *   on this chip that is tenths of a microsecond each, which would cost more than either
 *   stage and would inflate the very block it is measuring. Those two are timed with
 *   esp_cpu_get_cycle_count(), a register read, and converted to microseconds once at the
 *   end of the block.
 *
 * WHAT IS MEASURED IS DISJOINT. The engine's render contains the drone and the lead filter
 * callbacks, so the "layers" stage is reported with those two subtracted — the stages add
 * up to the block rather than overlapping, which is what makes the remainder mean anything.
 *
 * The statistics task reads the window, resets it, and prints one line per stage once every
 * ten seconds. The lines read `stage: <name> avg <us> us, max <us> us, <pct>% of budget`
 * beside the `stats:` line the firmware already prints, so one capture shows whether the
 * block overran and which stage it overran in.
 *
 * IT MEASURES. IT DOES NOT SET ANYTHING. The three runs it was first used for (compressor
 * and drive, compressor off, drive off) had their patch installed by a temporary table that
 * is not in this file and is not in this build: what remains is the instrument, not the
 * experiment.
 */
#ifndef STAGE_TIMING
#define STAGE_TIMING             0
#endif

#if STAGE_TIMING

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    SYNTH_STAGE_LAYERS = 0,   /* the engine's render and the layer capture, minus the filters */
    SYNTH_STAGE_DRONE,        /* the drone filter's bus FX, inside the engine's render */
    SYNTH_STAGE_LEAD,         /* the lead filter's bus FX, inside the engine's render */
    SYNTH_STAGE_CHORUS,
    SYNTH_STAGE_DELAY,
    SYNTH_STAGE_REVERB,
    SYNTH_STAGE_PERC,         /* the drum, summed into the rack's buses */
    SYNTH_STAGE_COMP,         /* the master compressor, per sample */
    SYNTH_STAGE_SUM,          /* the summing loop: fader glides, sends, dry crossfades */
    SYNTH_STAGE_GATE,         /* gate ramp, the returns sum, master gain and soft clip */
    SYNTH_STAGE_CONTROL,      /* parameters, MIDI, sequencer, microphone — outside the render */
    SYNTH_STAGE_REMAINDER,    /* the block minus every stage above */
    SYNTH_STAGE_COUNT
} synth_stage_t;

/* One stage's time, added to the block that is running. A stage that is called more than
 * once per block — the drone filter is called once per register — is added once per call
 * and reads as the block's total. */
void synth_stage_add(synth_stage_t stage, uint32_t us);

/* What the stage has cost so far in the block that is running. This is what the audio task
 * reads to work out the remainder; it is not the previous block's published figure. */
uint32_t synth_stage_block_us(synth_stage_t stage);

/* Publishes the block: every stage's total goes into the window, the maxima are taken on the
 * block's totals, and the counters start again. One call per block, at its end. */
void synth_stage_block(void);

/* The ten-second window: reads the sums and the maxima and starts a new window. A block in
 * flight at the moment of the read is lost from the average, which is one block in 1875. */
void synth_stage_window(uint32_t *sum_us, uint32_t *max_us, uint32_t *blocks);

const char *synth_stage_name(synth_stage_t stage);

/* The block's budget in microseconds: 256 samples at 48 kHz, rounded down. */
uint32_t synth_stage_budget_us(void);

#ifdef __cplusplus
}
#endif

#endif /* STAGE_TIMING */
