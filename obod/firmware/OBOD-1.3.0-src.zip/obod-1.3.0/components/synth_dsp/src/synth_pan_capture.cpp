#include "synth_dsp.h"
#include "synth_dsp_private.h"

#include <math.h>

/*
 * Pan capture: the point where a mono bus becomes a stereo layer.
 *
 * THE DRIFT
 *   A single periodic LFO reads as an obvious back-and-forth sway — the ear
 *   locks onto the period within a few cycles. So the pan position is a sum of
 *   three decorrelated sources: two sine LFOs whose rates are close to but not
 *   equal to each other and to nothing else in the instrument, plus a slewed
 *   random walk that retargets every few seconds. The combination does not
 *   repeat on any human timescale, which is what makes it read as drift rather
 *   than as vibrato.
 *
 *   The weights are normalised, so the pan position stays inside
 *   base +/- depth no matter how the walk is set.
 *
 * THE SMOOTHING
 *   The LFOs are evaluated once per block (2.7 ms at 48 kHz), but the *gains*
 *   are interpolated across the block. That costs two adds per sample and is
 *   smooth at any drift rate; evaluating sin/cos per sample would cost far more
 *   for something inaudible.
 *
 * THE PAN LAW
 *   Equal power: gl^2 + gr^2 == 1, so a layer keeps its loudness as it moves.
 *   A linear law would dip audibly in the middle of a sweep.
 */

namespace {

struct PanState {
    float    ph1;           /* drift LFO 1 phase, 0..1 */
    float    ph2;           /* drift LFO 2 phase, 0..1 */
    float    walk;          /* slewed random walk, -1..1 */
    float    walk_target;   /* where the walk is heading */
    float    walk_accum_ms; /* time since the walk last picked a target */
    float    pan;           /* pan applied at the end of the previous block */
    float    env;           /* envelope of this layer, 0..1, for the ring */
    uint32_t rng;
};

/*
 * КАНАЛОВ БОЛЬШЕ, ЧЕМ СЛОЁВ.
 *
 * 0..5 — сами слои, 6..8 — три шины аккорда лида: у каждой своя панорама, а пишут все три в
 * один слой (LEAD), потому что слой — это фейдер и посылы, а не место в стерео. Состояние
 * поэтому индексируется КАНАЛОМ, а не слоем: иначе три захвата делили бы одну панораму и
 * перебивали друг друга.
 */
#define PAN_CHANNELS (SYNTH_NUM_LAYERS + 3)
static const uint8_t s_chan_layer[PAN_CHANNELS] = {
    SYNTH_LAYER_DRONE_LOW, SYNTH_LAYER_DRONE_MID, SYNTH_LAYER_DRONE_HIGH,
    SYNTH_LAYER_LEAD, SYNTH_LAYER_BASS, SYNTH_LAYER_AUX,
    SYNTH_LAYER_LEAD, SYNTH_LAYER_LEAD, SYNTH_LAYER_LEAD,
};

PanState s_pan[PAN_CHANNELS];

/*
 * РАЗБРОС СТЕРЕО ЛИДА.
 *
 * Лид живёт одной моно-шиной, поэтому «ширина» здесь — декорреляция, а не панорама: два
 * однополюсных all-pass с разными коэффициентами дают разностный сигнал d, каналы получают
 * x + d и x - d, и сумма остаётся ровно 2x. Моно-совместимость сохраняется, а стороны
 * расходятся по фазе — на аккорде это слышно как ширина, на одной ноте почти нет. Памяти не
 * нужно: all-pass это четыре состояния, а не линия задержки.
 *
 * Коэффициенты разные и разного знака: одинаковые дали бы одинаковую групповую задержку в
 * обоих каналах, то есть снова моно.
 */




/* The same envelope, readable from the UI. Kept outside PanState because that struct
 * holds the drift, and this is telemetry: nothing in the audio path ever reads it back.
 * Zero-initialised, which is also the right value at boot. */
float s_env[SYNTH_NUM_LAYERS];
float s_lfo[SYNTH_NUM_LAYERS];

/* The note this drift has already restarted on. See synth_drone_lfo_epoch(). */
static uint32_t s_pan_epoch_seen;
float    s_inv_sample_rate = 1.0f / (float)SYNTH_SAMPLE_RATE;

/* xorshift32. Cheap, has no shared libc state, and is more than good enough for
 * deciding where a drone should sit in the stereo field. */
inline float rnd_bipolar(uint32_t &s)
{
    s ^= s << 13;
    s ^= s >> 17;
    s ^= s << 5;
    /* 24 bits -> 0..2 -> -1..1 */
    return (float)(s >> 8) * (1.0f / 8388608.0f) - 1.0f;
}

} // namespace

float synth_layer_pan(int layer)
{
    if (layer < 0 || layer >= SYNTH_NUM_LAYERS) {
        return 0.0f;
    }
    return s_pan[layer].pan;
}

float synth_layer_env(int layer)
{
    if (layer < 0 || layer >= SYNTH_NUM_LAYERS) {
        return 0.0f;
    }
    return s_env[layer];
}

float synth_layer_lfo(int layer)
{
    if (layer < 0 || layer >= SYNTH_NUM_LAYERS) {
        return 0.0f;
    }
    return s_lfo[layer];
}

void synth_pan_capture_init(uint32_t sample_rate)
{
    s_inv_sample_rate = 1.0f / (float)sample_rate;

    for (int i = 0; i < PAN_CHANNELS; i++) {
        PanState &st = s_pan[i];
        st.ph1 = 0.0f;
        st.ph2 = 0.0f;
        st.walk = 0.0f;
        st.walk_target = 0.0f;
        st.walk_accum_ms = 0.0f;
        st.pan = 0.0f;
        /* Distinct seeds, so the layers never move as a block. */
        st.rng = 0x9E3779B9u ^ ((uint32_t)i * 0x85EBCA6Bu);
        if (st.rng == 0) {
            st.rng = 1;
        }
    }
}

void synth_fx_pan_capture(int32_t *bus_buffer, int samples, int16_t *ep, int32_t *es)
{
    /* All state lives in s_pan[]; see the note in synth_dsp.h. */
    (void)es;

    if (!ep[6]) {
        return;
    }
    /* ep[7] — КАНАЛ, а не слой: см. s_chan_layer выше. */
    const int chan = ep[7];
    if (chan < 0 || chan >= PAN_CHANNELS) {
        return;
    }
    const int layer = s_chan_layer[chan];
    if (samples <= 0) {
        return;
    }
    if (samples > SYNTH_BLOCK_SAMPLES) {
        samples = SYNTH_BLOCK_SAMPLES;
    }

    PanState &st = s_pan[chan];
    const float dt = (float)samples * s_inv_sample_rate;

    /*
     * The trigger, the same one the filter's LFO obeys: a new note restarts the drift, and in
     * ONE SHOT the drift runs to the end of its shape and stays there. The epoch is checked
     * rather than a flag taken, because the filter has already read this note by now.
     */
    {
        const uint32_t epoch = synth_drone_lfo_epoch();

        if (epoch != s_pan_epoch_seen) {
            s_pan_epoch_seen = epoch;

            for (int i = 0; i < PAN_CHANNELS; i++) {
                s_pan[i].ph1 = 0.0f;
                s_pan[i].ph2 = 0.0f;
            }
        }
    }

    const bool one_shot = (synth_drone_lfo_mode() == 3);

    /* --- the three drift sources ------------------------------------------ */
    st.ph1 += (float)ep[2] * 0.001f * dt;          /* ep is milliHertz */
    if (st.ph1 >= 1.0f) {
        st.ph1 = one_shot ? 1.0f : (st.ph1 - 1.0f);
    }
    st.ph2 += (float)ep[3] * 0.001f * dt;
    if (st.ph2 >= 1.0f) {
        st.ph2 = one_shot ? 1.0f : (st.ph2 - 1.0f);
    }

    const float period_ms = (ep[4] > 0) ? (float)ep[4] : 4000.0f;
    st.walk_accum_ms += (float)samples * 1000.0f * s_inv_sample_rate;
    if (st.walk_accum_ms >= period_ms) {
        st.walk_accum_ms -= period_ms;
        st.walk_target = rnd_bipolar(st.rng);
    }

    /* One-pole slew towards the walk target, time constant a third of the
     * retarget period, so it never arrives abruptly. dt is far smaller than the
     * time constant, so the linear form is accurate. */
    float slew = dt * 3.0f / (period_ms * 0.001f);
    if (slew > 0.5f) {
        slew = 0.5f;                                /* keep it stable if misconfigured */
    }
    st.walk += (st.walk_target - st.walk) * slew;

    const float lfo1 = sinf(st.ph1 * 6.28318531f);
    const float lfo2 = sinf(st.ph2 * 6.28318531f);

    const float w1 = 0.45f;
    const float w2 = 0.30f;
    const float w3 = (float)ep[5] * 0.00025f;       /* 0..1000 -> 0..0.25 */
    const float norm = w1 + w2 + w3;

    /*
     * The microphone as the source of the drift, when the SHAPE knob is on MIC.
     *
     * It REPLACES the three drift sources rather than joining them, and it does so with
     * the flag rather than with a shape code: this FX has all eight parameter slots
     * spoken for, so there is nowhere to put a seventh value, and the envelope is
     * published once per block by the application instead. The LFOs and the walk keep
     * their state above, so leaving MIC puts the drift back where it would have been.
     *
     * The envelope is 0..1 where the drift is -1..1, so the pan is base + depth * env:
     * like the filter's cutoff, it starts at the base and moves one way from it.
     */
    float mod;
    if (synth_mic_mod_replaces()) {
        mod = synth_mic_mod_env();
    } else {
        mod = (w1 * lfo1 + w2 * lfo2 + w3 * st.walk) / norm;
    }

    s_lfo[layer] = mod;                             /* telemetry: what the drift does now */

    const float base = (float)ep[0] * 0.001f;       /* -1000..1000 -> -1..1 */
    const float depth = (float)ep[1] * 0.001f;      /* 0..1000 -> 0..1 */

    float pan = base + depth * mod;
    if (pan < -1.0f) {
        pan = -1.0f;
    } else if (pan > 1.0f) {
        pan = 1.0f;
    }

    const float gl_to = sqrtf(0.5f * (1.0f - pan));
    const float gr_to = sqrtf(0.5f * (1.0f + pan));
    const float gl_from = sqrtf(0.5f * (1.0f - st.pan));
    const float gr_from = sqrtf(0.5f * (1.0f + st.pan));
    st.pan = pan;

    const float dgl = (gl_to - gl_from) / (float)samples;
    const float dgr = (gr_to - gr_from) / (float)samples;

    float *l = synth_layer_l(layer);
    float *r = synth_layer_r(layer);

    float gl = gl_from;
    float gr = gr_from;
    int32_t peak = 0;

    for (int i = 0; i < samples; i++) {
        /* The engine's bus is int32 but scaled to 16-bit full scale: a single
         * voice at maximum volume already reaches about +/-32766. */
        const int32_t raw = bus_buffer[i];
        const int32_t mag = (raw < 0) ? -raw : raw;
        if (mag > peak) {
            peak = mag;
        }

        const float x = (float)raw * (1.0f / 32768.0f);

        l[i] += x * gl;
        r[i] += x * gr;

        gl += dgl;
        gr += dgr;
    }

    /*
     * The envelope, for the ring's reactive mode: this block's peak, instant on the way
     * up and one-pole on the way down over roughly 140 ms.
     *
     * The two rates are the point. An instant attack puts a strike at full brightness on
     * the block it happens in, which is what makes it read as a flash rather than as a
     * swell. One fixed release then decides how long a hit glows, and 140 ms is long
     * enough to see from across a room and short enough that consecutive sixteenths stay
     * separate. expf() once per layer per block costs about a thousandth of what the same
     * curve per sample would.
     */
    const float block_s = (float)samples * s_inv_sample_rate;
    const float release = 1.0f - expf(-block_s / 0.14f);
    const float level = (float)peak * (1.0f / 32768.0f);

    float env = st.env;
    if (level > env) {
        env = level;
    } else {
        env += (level - env) * release;
    }
    if (env > 1.0f) {
        env = 1.0f;
    }
    st.env = env;
    s_env[layer] = env;
}
