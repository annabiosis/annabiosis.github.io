#include "synth_dsp.h"
#include "synth_dsp_private.h"
#include "synth_stage_timing.h"

#if STAGE_TIMING
#include "esp_timer.h"
#endif

#include <math.h>

/*
 * Lead filter: TPT/ZDF state-variable low pass with an AR of its own.
 *
 * THE ENVELOPE IS AN AR AND NOT AN ADSR, and that is the owner's call. The filter
 * opens and closes once per note: an attack that rises to full and a release that
 * falls from wherever the attack reached, with no decay plateau and no sustain level
 * between them. Two segments instead of four, and the two are the whole shape of the
 * note's corner — a plucked filter and a swelling one differ in nothing else.
 *
 * THE LENGTH COMES FROM THE NOTE, not from a knob of its own. The application sizes
 * both segments from the gate of the note it is about to play: the sixth knob of the
 * TONE page splits that length between the attack and the release, so at -100 % the
 * attack is a millisecond and the release owns the rest, at 0 % they are equal, and
 * at +100 % the attack owns it and the release is a millisecond. The envelope is
 * ONE-SHOT: the release begins when the attack has arrived, whether or not the gate
 * is still open, because the two segments have already been given the whole gate
 * between them. A held key therefore gets the same closed corner at the end of the
 * gate that a short note gets, which is what "the length is the note's" means.
 *
 * THE TRIGGER IS THE RISING EDGE. Not the gate level: an envelope that started again
 * whenever it found itself idle under a gate still held would retrigger itself for as
 * long as the gate lasted, once per block. The level is still read, because a gate
 * that falls in the middle of an attack must release from where the attack got to
 * rather than sit at that level forever.
 *
 * WHY THIS IS NOT THE DRONE FILTER WITH DIFFERENT SETTINGS
 *   The drone's filter is modulated by a free-running LFO, because a drone is a
 *   texture held for minutes and its movement has to be slow and unrelated to
 *   anything else in the instrument. The lead is PLAYED. Its filter has to open
 *   on the note and close again afterwards, and the shape of that opening is most
 *   of what makes a plucked sound plucked. One is free-running, the other is
 *   triggered; that is not a setting, it is a different machine. The SVF
 *   underneath is the same one, for the same reasons spelled out in
 *   synth_drone_filter.cpp.
 *
 * LOGARITHMIC IN BOTH SENSES
 *   Each envelope segment is a one-pole curve rather than a straight line: it
 *   leaves quickly and approaches its target asymptotically. That is what an
 *   analogue envelope does, and it is why a short decay reads as a strike rather
 *   than as a fade. The time constant is time/4.6, so a segment is within 1% of
 *   its target after the time that was asked for.
 *
 *   And the cutoff moves in OCTAVES: fc = base * 2^(amount_oct * env). Mapping
 *   the envelope linearly onto Hz would spend most of its travel in the top
 *   octave, where the ear barely notices it, and race through the bottom, where
 *   it notices everything. The same decision is made for the drone's LFO sweep,
 *   and for the same reason.
 *
 * WHY THE COEFFICIENTS ARE COMPUTED AT A CONTROL RATE BUT APPLIED CONTINUOUSLY
 *   The envelope is evaluated per sample, because a 3 ms attack is under two
 *   blocks long and a per-block envelope would be a staircase. The coefficients
 *   are not: tanf() per sample would cost more than the entire rest of the block,
 *   so the expensive part — the exponential, the tangent and the division — is
 *   still done once every LEAD_COEF_DIV samples.
 *
 *   That is not enough on its own. Holding the coefficients between updates
 *   leaves the CUTOFF moving in steps of up to 2.5x of g near the top of a 3 ms
 *   attack, and each step is a small discontinuity in the filter's transfer
 *   function: an audible tick on the note, one per 32 samples, that fades as the
 *   attack is lengthened. The drone's filter has the same control-rate
 *   coefficient computation and gets away with it only because it low-passes its
 *   modulated cutoff over 8 ms first; the lead had no such thing on the envelope
 *   contribution.
 *
 *   So the coefficients the filter actually runs on are now INTERPOLATED: each
 *   update computes the new set, and over the LEAD_COEF_DIV samples that follow,
 *   a1, a2 and a3 walk to it linearly, one step per sample. The cost is three
 *   float adds, the three loads and the three stores that keep the six numbers in
 *   the state struct. Measured on the built object, the per-sample path goes from
 *   43 instructions to 52, i.e. +21 % of a loop whose tangent, exponential and
 *   division stay where they were, at the control rate. Over a 128-sample block
 *   that is about 1150 extra instructions on one bus, a few microseconds.
 *
 *   When the cutoff is not moving the two sets are identical, the step is
 *   exactly zero, and adding a zero float is exact — a stationary cutoff runs
 *   through the same arithmetic it always did.
 *
 *   Interpolation bounds how far a coefficient can move between two samples. It
 *   does not stop the number it is walking towards from arriving in corners: the
 *   target still changes once per LEAD_COEF_DIV samples, and a straight line into
 *   a corner is still a corner. A resonant SVF does not forgive that either. Its
 *   integrators hold the charge of the old cutoff and cannot be told about the
 *   new one: the output at the sample the coefficients change is
 *   ic2eq*(1 - a3) + a2*ic1eq + a3*x, so a step in a2 and a3 moves the output by
 *   its own amount, which is why the tick that survived the interpolation is
 *   louder with more resonance, quieter as the attack is lengthened (the same
 *   travel, more updates to spend it over) and absent when the cutoff stands
 *   still. That is the lead filter's own transient, and no amount of care in HOW
 *   the coefficients are installed removes it; the cutoff itself has to stop
 *   moving in corners.
 *
 *   The drone's filter never had this problem, for the reason given above: it
 *   low-passes its modulated cutoff before the tangent, so the number the
 *   coefficients are built from is smooth. The lead now does the same, per
 *   sample, with a 1.5 ms constant. 1.5 and not the drone's 8: the drone's LFO
 *   reaches 6 Hz and a slower smoother would eat the sweep it exists to pass,
 *   while the lead's modulation is a 3 ms attack, which IS the sound. What that
 *   buys, measured on a float32 replica of both loops, a 3 ms attack at Q = 1:
 *   the worst corner in the coefficient trajectory (the second difference of a3,
 *   which is what rings) falls from 3.0e-3 to 8.9e-4, 3.4x or 10.6 dB, and the
 *   worst output step the moving coefficients cause falls from 6.4 to 2.8 of
 *   32768. What it costs on the other side is attack: the cutoff the filter runs
 *   on now reaches 50 % of its octave travel 2.4 ms after the note (1.1 ms
 *   before), 90 % at 4.4 ms (2.1 ms), and the top of the travel is 0.972 of the
 *   octave amount asked for instead of 0.997, because the envelope has started
 *   its decay before the smoothed cutoff has finished rising. The other end of
 *   the range, 2 ms, would take the corner down to 6.8e-4 and push the 90 % point
 *   out to 5.0 ms; 0.75 ms would cut the added smear by a quarter (50 % point at
 *   2.1 ms) and still take 1.9x off the corner.
 *
 *   The cost of the smoother itself is one load, one subtract, one fused
 *   multiply-add and one store per sample, plus the compare and the select that
 *   land the value on its target exactly instead of parking a few tens of ulp
 *   short of it — so a cutoff that has stopped moving is bit for bit the cutoff
 *   this file computed before the smoother existed, not a value a few ulp off it
 *   that would sit there for the rest of the note. Measured on the built object,
 *   the post-envelope per-sample path goes from 53 instructions to 62, +17 %,
 *   about 1150 extra instructions over a 128-sample block — the same order as the
 *   interpolation above it. Its recurrence is two FP operations deep against the
 *   integrator recurrence's four, so what it adds is issue slots rather than a
 *   longer critical path.
 *
 *   That is also why the resonance is smoothed over the whole block rather than
 *   per sample: it is a knob, not a modulator.
 */

namespace {

/* 48 kHz / 32 = 1.5 kHz. */
#define LEAD_COEF_DIV 32

/* Time constant of the modulated-cutoff smoother, in seconds: 1.5 ms is 72
 * samples at 48 kHz. It has to round the corner that a control-rate coefficient
 * update leaves in the cutoff, and it has to stay under the 3 ms the cutoff
 * envelope's attack defaults to, or the smear it puts on that attack is worse
 * than the tick it removes — at 1.5 ms the attack is already visibly stretched;
 * see the note at the top of the file for the numbers, and for the 0.75 and 2 ms
 * alternatives the same measurement gives. */
#define LEAD_FC_TAU 0.0015f

enum {
    ST_IDLE = 0,
    ST_ATTACK,
    ST_RELEASE
};

struct LeadState {
    float ic1eq;        /* integrator states */
    float ic2eq;
    float env;          /* 0..1 */
    int   stage;
    bool  gate_prev;    /* the gate on the previous block: the falling edge cuts an attack */
    int32_t retrig;     /* ep[4] on the previous block: a different value is a note */
    float cutoff;       /* smoothed base cutoff, Hz */
    float fc_tgt;       /* modulated cutoff of the latest coefficient update, Hz */
    float fc_sm;        /* that, through the one-pole: the number tanf() is fed */
    float g;            /* TPT coefficient */
    float k;            /* 1/Q */
    float a1;           /* the set the filter is running on RIGHT NOW: it moves */
    float a2;           /* every sample between a1t/a2t/a3t of the previous */
    float a3;           /* update and those of the latest one */
    float a1t;          /* the set the current ramp is heading for */
    float a2t;
    float a3t;
    float a1s;          /* per-sample increment of that ramp */
    float a2s;
    float a3s;
    bool  coef_primed;  /* false until the first set has been computed */
    int   coef_left;    /* samples until the next coefficient update */
};

/* The lead filter exists once, so its state is one struct rather than an array
 * indexed by ep[7]: there is no second lead bus to keep separate, and a spare
 * ep[] slot would have to come from somewhere. */
/*
 * СОСТОЯНИЕ НА КАЖДУЮ ШИНУ.
 *
 * Фильтр стоит на четырёх шинах лида: слой и три шины аккорда. Пока состояние было одно на
 * файл, все четыре копии гоняли один фильтр по очереди — интеграторы переносили заряд с шины
 * на шину, и вместо четырёх отфильтрованных сигналов выходил мусор. Владелец услышал это как
 * постоянный треск сразу после того, как фильтр появился на шинах аккорда.
 */
/*
 * ШЕСТЬ СЛОТОВ: ЧЕТЫРЕ ШИНЫ (пока фильтр стоял на шинах) И ДВА КАНАЛА СЛОЯ (теперь).
 *
 * Фильтр переехал на сумму: панорама каждой ноты ставится до него, а фильтруется уже
 * собранный слой лида — левый и правый канал. Слотов поэтому шесть: старые четыре остались,
 * чтобы не переписывать заведённую нумерацию, а 4 и 5 — каналы слоя.
 */
#define LEAD_FILTER_SLOTS 6
LeadState s_lead[LEAD_FILTER_SLOTS];

float s_inv_sample_rate = 1.0f / (float)SYNTH_SAMPLE_RATE;

/* Per-sample coefficient of the modulated-cutoff smoother. */
float s_fc_a = 1.0f;

/* Per-sample one-pole coefficient for a segment that should land within 1% of
 * its target after `ms` milliseconds. */
float seg_rate(float ms, float dt)
{
    if (ms < 0.5f) {
        ms = 0.5f;
    }
    const float tau = ms * (1.0f / 4.6f) * 0.001f;
    float a = dt / tau;
    if (a > 1.0f) {
        a = 1.0f;
    }
    return a;
}

} // namespace

void synth_lead_filter_init(uint32_t sample_rate)
{
    s_inv_sample_rate = 1.0f / (float)sample_rate;

    for (int i = 0; i < LEAD_FILTER_SLOTS; i++) {
        s_lead[i] = LeadState{};
    }

    /*
     * The smoother's coefficient, from the exponential rather than from a divide
     * per sample: 1 - exp(-dt/tau) is the exact one-pole step for a time constant
     * tau, and dt/tau would be 0.70 % larger here (dt is 20.8 us against 1.5 ms),
     * which is the same filter at a 0.7 % shorter constant. The exponential is
     * paid for once.
     */
    s_fc_a = 1.0f - expf(-s_inv_sample_rate / LEAD_FC_TAU);

    for (int i = 0; i < LEAD_FILTER_SLOTS; i++) {
        s_lead[i].ic1eq = 0.0f;
        s_lead[i].ic2eq = 0.0f;
        s_lead[i].env = 0.0f;
        s_lead[i].stage = ST_IDLE;
        s_lead[i].gate_prev = false;
        s_lead[i].retrig = 0;
        s_lead[i].cutoff = 0.0f;
        s_lead[i].fc_tgt = 0.0f;
        s_lead[i].fc_sm = 0.0f;
        s_lead[i].g = 0.0f;
        s_lead[i].k = 1.0f;
        s_lead[i].a1 = 1.0f;
        s_lead[i].a2 = 0.0f;
        s_lead[i].a3 = 0.0f;
        s_lead[i].a1t = 1.0f;
        s_lead[i].a2t = 0.0f;
        s_lead[i].a3t = 0.0f;
        s_lead[i].a1s = 0.0f;
        s_lead[i].a2s = 0.0f;
        s_lead[i].a3s = 0.0f;
        s_lead[i].coef_primed = false;
        s_lead[i].coef_left = 0;
    }
}

/*
 * The rescue, from synth_rack.cpp's fuse.
 *
 * The two integrators are the filter's memory of the signal and are the only state that can
 * stay poisoned by a non-finite sample; they are cleared unconditionally, and that is
 * microseconds. Everything else here is a defence against the poison having reached the
 * ENVELOPE or the coefficients as well: if any of those is not a number, the state is put
 * back on the path the first block after a note takes — cutoff unset (which makes the next
 * block take the knob's value), coefficients unprimed (which makes the next control update
 * install a fresh set outright), stage idle.
 *
 * The cautious case is deliberately not "reset everything": clearing a cutoff that is still
 * walking would be a step in a filter that is being rescued, not a step out of the rescue.
 * Only values that are already non-finite are replaced.
 */
void synth_lead_filter_reset_state(void)
{
    /* Спасение — на ВСЕ слоты: если один фильтр ушёл в NaN, остальные обязаны быть целы,
     * иначе треск вернётся с другой шины. */
    for (int i = 0; i < LEAD_FILTER_SLOTS; i++) {
        LeadState &st = s_lead[i];

        st.ic1eq = 0.0f;
        st.ic2eq = 0.0f;
        st.coef_left = 0;

        if (!(st.env >= 0.0f)) {        /* NaN fails this, and so does a negative */
                st.env = 0.0f;
                st.stage = ST_IDLE;
                st.gate_prev = false;
                st.retrig = 0;
        }

        const bool sane = isfinite(st.cutoff) && isfinite(st.fc_tgt) && isfinite(st.fc_sm)
                       && isfinite(st.g) && isfinite(st.k)
                       && isfinite(st.a1) && isfinite(st.a2) && isfinite(st.a3)
                       && isfinite(st.a1t) && isfinite(st.a2t) && isfinite(st.a3t)
                       && isfinite(st.a1s) && isfinite(st.a2s) && isfinite(st.a3s);

        if (!sane) {
            /* Zero cutoff is the module's own "take the knob on the next block" value. */
                st.cutoff = 0.0f;
                st.fc_tgt = 0.0f;
                st.fc_sm = 0.0f;
                st.g = 0.0f;
                st.k = 1.0f;
                st.a1 = st.a1t = 1.0f;
                st.a2 = st.a2t = 0.0f;
                st.a3 = st.a3t = 0.0f;
                st.a1s = st.a2s = st.a3s = 0.0f;
                st.coef_primed = false;
        }    }

}

/* Как отсчёт приходит в фильтр и как уходит обратно: у шины движка это int32 в полной
 * шкале 16 бит, у слоя — float. Всё, что между ними, считает в float в обоих случаях. */
template <typename T>
static inline float lead_sample_in(T v);

template <>
inline float lead_sample_in<int32_t>(int32_t v)
{
    return (float)v * (1.0f / 32768.0f);
}

template <>
inline float lead_sample_in<float>(float v)
{
    return v;
}

template <typename T>
static inline void lead_sample_out(T &dst, float y, float k, float v1, float v2, float x);

template <>
inline void lead_sample_out<int32_t>(int32_t &dst, float y, float k, float v1, float v2, float x)
{
    (void)k;
    (void)v1;
    (void)v2;
    (void)x;

    /* Resonance can push the output past full scale; the rack limits the sum, but this
     * keeps a single bus from overflowing int32 first. */
    float out = y * 32768.0f;

    if (out > 2147483000.0f) {
        out = 2147483000.0f;
    } else if (out < -2147483000.0f) {
        out = -2147483000.0f;
    }
    dst = (int32_t)out;
}

template <>
inline void lead_sample_out<float>(float &dst, float y, float k, float v1, float v2, float x)
{
    (void)k;
    (void)v1;
    (void)v2;
    (void)x;

    /* Слой — обычный float: стойка сама ограничивает сумму. */
    dst = y;
}

template <typename T>
static void synth_fx_lead_filter_body(int slot, T *bus_buffer, int samples, int16_t *ep, int32_t *es)
{
    (void)es;   /* state lives in s_lead; see the note in synth_dsp.h */

    /*
     * ep[0] is the base cutoff and doubles as "configured". setBusFX() memsets
     * ep[], so a slot that has not been set up yet reads as zero — and a filter
     * whose cutoff is zero would silence the lead rather than bypass it. There is
     * no separate enable slot because all eight are spoken for.
     */
    if (ep[0] <= 0) {
        return;
    }
    if (samples <= 0) {
        return;
    }
    if (samples > SYNTH_BLOCK_SAMPLES) {
        samples = SYNTH_BLOCK_SAMPLES;
    }

    if (slot < 0 || slot >= LEAD_FILTER_SLOTS) {
        return;
    }
    LeadState &st = s_lead[slot];
    const float dt = s_inv_sample_rate;
    const float fc_max = 0.45f / s_inv_sample_rate;

    /* --- the trigger, and the gate -----------------------------------------
     *
     * WHAT STARTS THE ENVELOPE IS ep[4], A COUNTER OF NOTE-ONS, and not the gate.
     *
     * The gate's rising edge was the trigger while the lead was monophonic: it
     * rose when the note started and fell when the note ended. The sequencer is no
     * longer monophonic — a step that arrives while the previous note is still
     * ringing takes ANOTHER group, not the same one — so the gate now stays up
     * across steps and its edge can no longer say "a note started". The counter
     * can: the app bumps it for every note it opens, and a value that differs from
     * the last one seen is a note, whether or not the gate ever moved.
     *
     * A retrigger starts from wherever the envelope currently is rather than from
     * zero. A note that follows another one closely then continues out of its
     * predecessor instead of restarting with a step, which is both what an
     * analogue envelope does and one less click in a fast phrase.
     *
     * THE FALLING GATE KEEPS ONE JOB: a gate that ends in the middle of the attack
     * releases from wherever the attack got to, which is what an envelope longer
     * than the note it was given must do — the corner is already open, and the
     * rest of the note fades it shut rather than dropping it. The envelope is
     * one-shot either way, so a held gate re-triggers nothing: a test on the LEVEL
     * would find the envelope idle under a held gate and start it again once per
     * block, which is the reason the trigger is an edge or a counter and never the
     * level.
     *
     * ep[4] IS FREE FOR THIS because the AR has no decay: the slot held the
     * envelope's decay time while it was an ADSR, and nothing else reads it. The
     * two sides only ever have to DISAGREE, so the counter may wrap and neither
     * end needs to know where the other started.
     */
    const bool gate = (ep[7] != 0);
    const int32_t retrig = (int32_t)ep[4];
    if (retrig != st.retrig) {
        st.retrig = retrig;
        st.stage = ST_ATTACK;
    } else if (!gate && st.stage == ST_ATTACK) {
        st.stage = ST_RELEASE;
    }
    st.gate_prev = gate;

    const float env_oct = (float)ep[2] * 0.01f;     /* centioctaves -> octaves */
    /* ep[5] is the filter's MODE, not a sustain level: the envelope has no sustain
     * since the AR replaced the ADSR, and the slot was borrowed by the mode knob
     * when that arrived. Reading it as a level here was the old behaviour's; see
     * the note in synth_dsp.h. */

    /* --- base cutoff, smoothed once per block ------------------------------ */
    float target = (float)ep[0];
    /* The lower test is negated: a cutoff that has gone non-finite — the slot holds a
     * frequency the application computed, and 0 times an overflowed depth is a NaN —
     * lands on the floor instead of poisoning the coefficients. */
    if (!(target >= 20.0f)) {
        target = 20.0f;
    } else if (target > fc_max) {
        target = fc_max;
    }

    if (st.cutoff <= 0.0f) {
        st.cutoff = target;                         /* first block: no ramp from zero */
    } else {
        float a = (float)samples * s_inv_sample_rate / 0.015f;
        if (a > 1.0f) {
            a = 1.0f;
        }
        st.cutoff += (target - st.cutoff) * a;
    }

    float q = (float)ep[1] * 0.01f;
    if (!(q >= 0.5f)) {
        q = 0.5f;
    } else if (q > 20.0f) {
        q = 20.0f;
    }
    st.k = 1.0f / q;

    /* ep[3] is the attack of this note and ep[6] its release, both in milliseconds
     * and both sized by the application from the note's gate and the SHAPE knob.
     * ep[4] is not a time at all any more: it is the note-on COUNTER read at the top
     * of this block, and an AR has no decay segment to give the slot back to. */
    const float a_atk = seg_rate((float)ep[3], dt);
    const float a_rel = seg_rate((float)ep[6], dt);

    for (int i = 0; i < samples; i++) {
        /* --- envelope, per sample ----------------------------------------- */
        switch (st.stage) {
        case ST_ATTACK:
            st.env += (1.0f - st.env) * a_atk;
            if (st.env >= 0.99f) {
                st.env = 1.0f;
                /* ONE-SHOT: the release follows the attack of its own accord.
                 * The two segments were given the whole gate between them, so
                 * waiting for the gate to fall first would hold the corner open
                 * past the note. */
                st.stage = ST_RELEASE;
            }
            break;

        case ST_RELEASE:
            st.env -= st.env * a_rel;
            if (st.env <= 0.0005f) {
                st.env = 0.0f;
                st.stage = ST_IDLE;
            }
            break;

        default:
            st.env = 0.0f;
            break;
        }

        /* --- coefficients, at the control rate ---------------------------- */
        if (st.coef_left <= 0) {
            st.coef_left = LEAD_COEF_DIV;

            float fc = st.cutoff * exp2f(env_oct * st.env);
            if (!(fc >= 20.0f)) {
                fc = 20.0f;
            } else if (fc > fc_max) {
                fc = fc_max;
            }

            if (!st.coef_primed) {
                /* The first set is installed outright, and so is the first
                 * cutoff. There is no previous value to come from, and with the
                 * envelope at rest that target IS the base cutoff, so the
                 * smoother starts on it rather than walking up to it from zero:
                 * the first sample of the first note sees fc_sm == fc_tgt ==
                 * st.cutoff, the same g the old code built, bit for bit, and the
                 * step the smoother takes is exactly +0.0f. */
                st.fc_tgt = fc;
                st.fc_sm = fc;
            } else {
                st.fc_tgt = fc;
            }

            st.g = tanf(3.14159265f * st.fc_sm * s_inv_sample_rate);
            const float a1 = 1.0f / (1.0f + st.g * (st.g + st.k));
            const float a2 = st.g * a1;
            const float a3 = st.g * a2;

            if (!st.coef_primed) {
                /* The first set is installed outright. There is no previous set
                 * to come from, and the note must start on the filter the old
                 * code started on, so nothing is ramped here. */
                st.coef_primed = true;
                st.a1 = st.a1t = a1;
                st.a2 = st.a2t = a2;
                st.a3 = st.a3t = a3;
                st.a1s = 0.0f;
                st.a2s = 0.0f;
                st.a3s = 0.0f;
            } else {
                /*
                 * The previous ramp has had exactly LEAD_COEF_DIV samples to
                 * arrive at a1t/a2t/a3t, so that is where the filter should
                 * already be. Assigning rather than reading the accumulated
                 * value makes the endpoint exact instead of slightly rounded,
                 * and it is what makes the stationary case a zero step: when the
                 * new set equals the old one, a1s comes out exactly +0.0f and
                 * a1 + 0.0f is a1, bit for bit.
                 */
                st.a1 = st.a1t;
                st.a2 = st.a2t;
                st.a3 = st.a3t;
                st.a1t = a1;
                st.a2t = a2;
                st.a3t = a3;

                const float inv_div = 1.0f / (float)LEAD_COEF_DIV;
                st.a1s = (a1 - st.a1) * inv_div;
                st.a2s = (a2 - st.a2) * inv_div;
                st.a3s = (a3 - st.a3) * inv_div;
            }
        }
        st.coef_left--;

        /*
         * One step of the one-pole on the modulated cutoff, on every sample.
         *
         * The target, if it moved at all, moved at the coefficient update above;
         * the smoothing has to happen here, not there, because a target that only
         * changes once per 32 samples is a staircase and it is the corners of
         * that staircase — not its steps — that the filter turns into a tick.
         * Running the pole by hand between updates costs the same whether the
         * cutoff is moving or not, and when it is not moving fc_tgt - fc_sm is
         * exactly +0.0f, so the step is exact and a stationary cutoff runs
         * through arithmetic that is bit for bit the old one.
         *
         * The pole cannot land on its target on its own: the step shrinks until
         * the addition rounds it away, and the value parks up to 0.5 ulp / a
         * short of it — 4.3e-6 of itself, 36 ulp and 0.011 Hz for a cutoff at
         * 2.6 kHz — and stays there for the rest of the note. So when the addition
         * changes nothing, the value takes the target outright, and what tanf()
         * is fed is the target exactly rather than within tens of ulp of it. The
         * correction that lands it is at most that same 4.3e-6, it happens once,
         * 18.7 ms after the cutoff stopped moving, and the coefficient ramp moves
         * up to 3.3e-2 of itself in a single sample of a 3 ms attack.
         */
        const float fc_next = st.fc_sm + (st.fc_tgt - st.fc_sm) * s_fc_a;
        st.fc_sm = (fc_next == st.fc_sm) ? st.fc_tgt : fc_next;

        /* One linear step of the ramp. Three adds per sample, plus the loads and
         * stores that keep a1/a2/a3 and their increments in the state struct;
         * the tangent, the exponential and the division stay at the control
         * rate. */
        st.a1 += st.a1s;
        st.a2 += st.a2s;
        st.a3 += st.a3s;

        /* --- the filter ---------------------------------------------------- */
        const float x = lead_sample_in<T>(bus_buffer[i]);

        const float v3 = x - st.ic2eq;
        const float v1 = st.a1 * st.ic1eq + st.a2 * v3;
        const float v2 = st.ic2eq + st.a2 * st.ic1eq + st.a3 * v3;
        st.ic1eq = 2.0f * v1 - st.ic1eq;
        st.ic2eq = 2.0f * v2 - st.ic2eq;

        /* The mode is a cross-fade between the three outputs of the same state,
         * exactly as in the drone filter: 0 is the low pass with no arithmetic at
         * all, so a stored patch sounds bit for bit as it did before the knob. */
        const int fmode = ep[5];
        float y;
        if (fmode <= 0) {
            y = v2;                                 /* low pass, bit for bit */
        } else if (fmode >= 100) {
            y = x - st.k * v1 - v2;                 /* high pass */
        } else if (fmode < 50) {
            const float t = (float)fmode * 0.02f;
            y = v2 * (1.0f - t) + v1 * t;
        } else {
            const float t = (float)(fmode - 50) * 0.02f;
            y = v1 * (1.0f - t) + (x - st.k * v1 - v2) * t;
        }

        lead_sample_out<T>(bus_buffer[i], y, st.k, v1, v2, x);
    }
}

/*
 * The published callback, with the stage measured around it — the drone filter's twin, and
 * for the same reason: this runs inside the engine's render and returns from several
 * places, so the timer goes around the call and not inside it. See synth_drone_filter.cpp.
 */
/* Один вход на слот: движок передаёт только указатель на функцию, поэтому «какая это шина»
 * знает не аргумент, а вот эта обёртка. */
static void lead_filter_entry(int slot, int32_t *bus_buffer, int samples, int16_t *ep, int32_t *es)
{
#if STAGE_TIMING
    const int64_t t0 = esp_timer_get_time();
    synth_fx_lead_filter_body(slot, bus_buffer, samples, ep, es);
    synth_stage_add(SYNTH_STAGE_LEAD, (uint32_t)(esp_timer_get_time() - t0));
#else
    synth_fx_lead_filter_body(slot, bus_buffer, samples, ep, es);
#endif
}

/*
 * ПАРАМЕТРЫ ФИЛЬТРА СЛОЯ.
 *
 * Раньше они ходили через слоты эффекта шины (setBusFXParam), потому что фильтр стоял на
 * шинах. Теперь он стоит в стойке, на слое, и шины у него нет — параметры приходят сюда.
 * Раскладка слотов сохранена один в один: 0 срез, 1 добротность, 2 глубина огибающей,
 * 3 атака, 4 счётчик нот, 5 режим, 6 спад, 7 заслонка.
 */
static int16_t s_layer_ep[8];

void synth_lead_filter_param(uint8_t id, int16_t value)
{
    if (id < 8u) {
        s_layer_ep[id] = value;
    }
}

/*
 * СЛОЙ ЛИДА ЧЕРЕЗ ФИЛЬТР.
 *
 * Слой — это float, а тело фильтра работает с int32 в полной шкале 16 бит, как шина движка.
 * Поэтому канал переводится туда и обратно; на 256 сэмплах это около тысячи преобразований,
 * то есть заметно меньше, чем стоит сам фильтр.
 *
 * Заслонка закрыта или срез нулевой — фильтра нет вовсе: тело выходит на первом сравнении,
 * и цена такого вызова почти нулевая.
 */
void synth_lead_filter_layer(float *l, float *r, int samples)
{
    if (l == nullptr || r == nullptr || samples <= 0) {
        return;
    }
    if (samples > SYNTH_BLOCK_SAMPLES) {
        samples = SYNTH_BLOCK_SAMPLES;
    }
    if (s_layer_ep[0] <= 0) {
        return;
    }

    /*
     * Слой обрабатывается прямо в float: тело шаблонное, преобразований нет вовсе. Раньше
     * здесь стоял временный int32-буфер и две тысячи преобразований на блок — с потерей
     * разрядности до 16 бит.
     */
    synth_fx_lead_filter_body<float>(4, l, samples, s_layer_ep, nullptr);
    synth_fx_lead_filter_body<float>(5, r, samples, s_layer_ep, nullptr);
}

void synth_fx_lead_filter(int32_t *bus_buffer, int samples, int16_t *ep, int32_t *es)
{
    lead_filter_entry(0, bus_buffer, samples, ep, es);
}

void synth_fx_lead_filter_chord1(int32_t *bus_buffer, int samples, int16_t *ep, int32_t *es)
{
    lead_filter_entry(1, bus_buffer, samples, ep, es);
}

void synth_fx_lead_filter_chord2(int32_t *bus_buffer, int samples, int16_t *ep, int32_t *es)
{
    lead_filter_entry(2, bus_buffer, samples, ep, es);
}

void synth_fx_lead_filter_chord3(int32_t *bus_buffer, int samples, int16_t *ep, int32_t *es)
{
    lead_filter_entry(3, bus_buffer, samples, ep, es);
}
