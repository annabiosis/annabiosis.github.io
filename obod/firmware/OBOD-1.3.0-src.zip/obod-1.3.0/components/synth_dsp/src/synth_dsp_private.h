/* Internal wiring between the synth_dsp translation units. Not installed. */
#pragma once

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

void synth_pan_capture_init(uint32_t sample_rate);
void synth_drone_filter_init(uint32_t sample_rate);
void synth_lead_filter_init(uint32_t sample_rate);
void synth_rack_init(void);
void synth_mic_mod_init(void);

/*
 * The microphone's envelope and the flag that lets it replace an LFO, written by
 * synth_dsp_set_mic_env() and read by the filter and the pan capture every block.
 * In the private header because the two readers are inside the component and nothing
 * outside it has any business reading the envelope back.
 */
float synth_mic_mod_env(void);
bool  synth_mic_mod_replaces(void);

/*
 * The block published by synth_dsp_mic_publish(), for synth_fx_mic_in(). Returns NULL
 * (and a count of zero) when nothing is published.
 */
const float *synth_mic_block(int *count);

/*
 * ZEROING A LINE WITHOUT HOLDING THE MEMORY BUS.
 *
 * A megabyte and a half of PSRAM is not an amount of memset that can run between two
 * audio blocks: done in one call it saturates the bus the audio task fetches instructions
 * from, and every block it lasts is a missed deadline. This writes the range in pieces of
 * a few kilobytes and yields a tick between them, so the longest continuous burst stays
 * under the block time. The module's claim task calls it; nothing on the audio side does.
 *
 * The range must be ordinary memory: no device registers, no DMA descriptors.
 */
void synth_fx_zero(void *dst, size_t bytes);

/*
 * ЭФФЕКТ-МАШИНА: одна позиция стойки, несколько недорогих эффектов. Тип — номер в списке,
 * три параметра (A, B, C) по числу свободных секторов страницы.
 */

void synth_fx_machine_init(uint32_t sample_rate);
void synth_fx_machine_reset_state(void);
void synth_fx_machine_set_type(int type);
void synth_fx_machine_set_params(float a, float b, float c);
void synth_fx_machine_set_tempo(float bpm, int running);
int  synth_fx_machine_type(void);
void synth_fx_machine_process(int samples, float *l, float *r);

void synth_chorus_init(uint32_t sample_rate);
void synth_chorus_set(float rate_hz, float depth01, float mix01);
void synth_chorus_process(int samples, float *l, float *r);

void synth_delay_init(uint32_t sample_rate);
void synth_delay_set(float time_samples, float feedback01, float mix01);


/* Демпфирование повторов: фильтр в цепи обратной связи, 0 — прозрачно, 1 — глухо. */
void synth_delay_set_damp(float v01);
/* Whether the rack's delay MIX is above zero. The delay's own mix is always full wet —
 * the rack owns the balance — so this is the only thing that can tell the module the
 * player has actually asked for the effect, and therefore the only thing allowed to
 * start a lazy claim before the boot prefetch has run. See synth_fx_delay.cpp. */
void synth_delay_set_active(bool active);
/* Tape or crossfade — how a CHANGE OF TIME arrives. See synth_fx_delay.cpp. */
void synth_delay_set_mode(bool crossfade);
void synth_delay_process(int samples, float *l, float *r);
/* The repeats' loop gain in force, for the rescue line in synth_rack.cpp. */
float synth_delay_feedback(void);

void synth_reverb_init(uint32_t sample_rate);
void synth_reverb_set(float size01, float damp01, float mix01, int mode);
void synth_reverb_process(int samples, const float *send, float *wet_l, float *wet_r);

/*
 * The plate, a second topology the reverb dispatches to when its mode says so. It owns its
 * own PSRAM block and is claimed only while that mode is chosen, so the two engines are
 * never both resident. The crossfade that hides a mode change belongs to the reverb, which
 * owns the mode; the plate writes the wet with the MIX already applied.
 */
void synth_plate_init(uint32_t sample_rate);
void synth_plate_set(float size01, float damp01, float mix01);
void synth_plate_process(int samples, const float *send, float *wet_l, float *wet_r);

/*
 * The boot prefetch, one effect at a time.
 *
 * Each call asks its module to take its block if it has not already, and answers whether
 * the block is ready. The request is idempotent: the prefetch task may call it until the
 * module's own claim task has finished. See synth_dsp.cpp for the task that runs them in
 * order, and synth_fx_delay.cpp for why the memory is taken after boot rather than at the
 * first turn of a mix knob.
 */
bool synth_delay_prefetch(void);
bool synth_reverb_prefetch(void);
bool synth_plate_prefetch(void);

/*
 * THE RESCUE, called from the rack's fuse and from nothing else.
 *
 * A non-finite sample cannot be removed by arithmetic: NaN times zero is NaN and every
 * comparison against NaN is false, so one bad sample in a pole, an integrator or a line is
 * there for the rest of the session. Each of these puts its module's recursive state back on
 * its TARGETS rather than on zero — after a rescue the instrument must sound like the knobs
 * say, not like a muted one — and each is safe to call at any time, from the audio task.
 *
 * The three large lines are not zeroed here. Their modules own a low-priority task already
 * (the one that claimed them), and zeroing a megabyte and a half in the audio task is the
 * measured forty milliseconds this design exists to keep out of it: reset_state() marks the
 * line dirty and the process loop returns silence until the task has cleared it.
 */
void synth_chorus_reset_state(void);
void synth_delay_reset_state(void);
void synth_reverb_reset_state(void);
void synth_plate_reset_state(void);
void synth_lead_filter_reset_state(void);
void synth_drone_filter_reset_state(void);
void synth_perc_reset_state(void);

/*
 * THE RETURN HAS COME BACK UP FROM ZERO, called from the rack's gate and from nothing else.
 *
 * Not a rescue and not a clear: the two lines keep whatever phrase they were left holding,
 * and each module stops READING its line until the tap has been overwritten by what the
 * restarted effect wrote — see s_fill in synth_fx_delay.cpp. That is what makes a return
 * that is raised mid-phrase open on the material that is being played rather than on the
 * material it was switched off in, at the price of one store in the audio task instead of
 * a megabyte and a half of PSRAM traffic.
 *
 * Called on the block the gate opens, before the module's process() for that block.
 */
void synth_chorus_restart(void);
void synth_delay_restart(void);

#ifdef __cplusplus
/*
 * A fractional read from a circular line, which is what a modulated or a
 * tempo-locked delay needs and what a fixed integer tap does not. Shared by the
 * chorus and the delay so that the wrap arithmetic exists once.
 *
 * The limits are TOTAL, and that is not decoration — it is the difference between
 * a line that is merely misread and one that is read off the end of its own
 * allocation.
 *
 * A line of fewer than three samples has no room between the write pointer and
 * the oldest sample it is allowed to read: the two limits contradict each other,
 * the delay comes out below one, and pos lands PAST the write pointer instead of
 * behind it. It cannot happen with the lengths the two callers cut (64 samples is
 * their own floor), and it costs nothing to make that a property of this function
 * rather than a promise the callers make to it.
 *
 * A NaN delay passes every comparison there is, and (int)NaN is an undefined
 * conversion: on this chip it lands on INT_MIN, so the read goes eight gigabytes
 * below the line, which is a LoadProhibited and a reboot rather than a wrong
 * sample. That is why the lower limit is written as the NEGATION of the test the
 * value has to pass — a NaN fails it and is pulled back with the values below one
 * instead of slipping through both.
 */
static inline float synth_fx_read(const float *line, int len, int write, float delay)
{
    if (!line || len < 3 || write < 0 || write >= len) {
        return 0.0f;
    }

    const float max_delay = (float)(len - 2);
    if (!(delay >= 1.0f)) {
        delay = 1.0f;
    } else if (delay > max_delay) {
        delay = max_delay;
    }

    float pos = (float)write - delay;
    if (pos < 0.0f) {
        pos += (float)len;
    }

    const int   i0 = (int)pos;
    const float t  = pos - (float)i0;
    const int   i1 = (i0 + 1 >= len) ? 0 : i0 + 1;
    return line[i0] + (line[i1] - line[i0]) * t;
}
#endif
