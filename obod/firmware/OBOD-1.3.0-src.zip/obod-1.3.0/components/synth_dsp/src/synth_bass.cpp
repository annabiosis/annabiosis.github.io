/*
 * The bass: a sequencer and one voice, filling SYNTH_LAYER_BASS.
 *
 * WHY ITS OWN LAYER
 *   The drums and the drones come out of the engine's own buses; the bass does not. Its
 *   line is generated a block at a time beside the engine's render, because a sequencer
 *   that has to place a note on an exact sample cannot be built out of the engine's
 *   note interface, and because the layer is where the instrument's own additions have
 *   always lived: the rack gives it a fader, three sends and a meter without knowing what
 *   is in it.
 *
 * THE VOICE
 *   A saw and a square an octave down, a two-pole lowpass with its own envelope, a pitch
 *   envelope for the attack, and a soft clip. That is a bass guitar's shape as far as this
 *   instrument is concerned: the sub gives the note its weight, the saw its edge, the
 *   filter the movement, the clip the density. One voice and no more — a bass line is one
 *   note at a time, and a second voice would only ever be heard as a smear.
 *
 * THE LINE
 *   A pattern is sixteen steps, one bar. A kit says what the notes sound like; a pattern
 *   says where they are; VAR is the character that reads the pattern a little differently
 *   from take to take: it may jump the whole bar up an octave, it may tie a note into the
 *   next one, and it may lean on a note. All three are coin flips per bar or per note, so
 *   the same pattern played for a minute is never quite the same twice — which is the
 *   point of a drone instrument that must not sound like a loop.
 *
 *   THE BAR ALWAYS FINISHES. A pattern shorter than the bar (LEN) leaves the rest of the
 *   bar silent, but the clock keeps counting: the next bar starts where the next bar
 *   starts, whatever the pattern did, so a change of pattern never shifts the beat.
 */

#include "synth_dsp.h"

#include <math.h>
#include <string.h>

namespace {

/* ------------------------------------------------------------------------- */
/* Parameters, all 0..1 as the app's patch holds them.                        */
/* ------------------------------------------------------------------------- */

/*
 * Управляющая частота: раз в восемь сэмплов (0.17 мс). Огибающая, которая идёт сто
 * миллисекунд, на таком шаге не ступенька, а на процессоре это в шесть раз меньше работы.
 */
#define CONTROL_STRIDE 8

enum {
    P_KIT = 0,
    P_SNAP,     /* слот 1: ручка SNAP; раньше здесь стояла октава */
    P_NOTE,     /* слот 2: смена ноты, -7..+7 полутонов; раньше здесь стоял срез */
    P_DECAY,
    P_SUB,      /* доля саб-осциллятора; номер прежний, был P_SNAP */
    P_RES,          /* резонанс фильтра; в патче это поле по-прежнему зовётся DRIVE */
    P_PAT,
    P_VAR,
    P_LEN,
    P_GATE,
    P_SLIDE,
    P_ACCENT,
    P_COUNT
};

struct Kit {
    int8_t  octave;      /* where this kit sits, in octaves about the root */
    uint16_t decay_ms;   /* how long the note falls from its peak to its sustain */
    uint8_t snap;        /* pitch envelope depth, in semitones */
    uint8_t tone;        /* base cutoff, 0..255 mapped to 45 Hz .. 1.6 kHz */
    uint8_t drive;       /* 0..255 */
    uint8_t sub;         /* the triangle's share, 0..255 */
    uint8_t wave;        /* 0 = saw, 255 = square, and everything between */
    uint8_t res;         /* resonance, 0..255 */
    uint8_t fenv;        /* the filter's own envelope, 0..255 mapped to 0..36 semitones */
    uint8_t sus;         /* the sustain level, 0..255 */
};

/*
 * Тридцать заготовок.
 *
 * Это не тридцать инструментов: один голос, услышанный через тридцать наборов чисел, в трёх
 * семьях по десять — круглые (низко, мало резонанса, есть остаток уровня), кислотные (пила,
 * резонанс, короткий спад) и перегруженные (меандр, привод, длинный спад). Поля по порядку:
 * октава, спад, бросок высоты, срез, привод, суб, форма волны, резонанс, глубина фильтра,
 * остаток уровня. Заготовка — точка отсчёта, а не патч: пять ручек рядом двигают её далеко.
 */
const Kit KITS[30] = {
    /* round: срез низко, но не в подвале: 100..150 по полю — это 200..700 Гц */
    {  0, 300,  1, 110,  20,  0,  40,  80, 110, 120 },
    {  0, 380,  0,  95,  10,  0,  20,  60,  90, 150 },
    {  0, 460,  1,  85,  10,  0,  30,  70, 100, 140 },
    {  0, 340,  1, 105,  20,  0,  60,  90, 120, 130 },
    {  0, 180,  2, 125,  40,  0,  90, 120, 140,  80 },
    {  0, 150,  1,  90,  20,  0,  50,  70,  80,  60 },
    {  0, 250,  0,  80,  10,  0,  20,  50,  70, 130 },
    {  0, 300,  1, 115,  30,  0, 110, 140, 120, 100 },
    {  0, 420,  0,  75,   0,  0,  10,  40,  60, 170 },
    {  0, 520,  1,  80,  20,  0,  40,  60,  80, 160 },
    /* acid: пила, высокий резонанс, короткий спад — срез открыт, гармоники на месте */
    {  0, 220,  2, 160,  50,  0,  10, 200, 200,  60 },
    {  0, 200,  2, 190,  50,  0,   0, 220, 220,  50 },
    {  0, 180,  3, 170,  60,  0,  20, 240, 210,  50 },
    {  0, 160,  3, 180,  60,  0,   0, 210, 190,  40 },
    {  0, 240,  2, 150,  40,  0,  30, 180, 180,  70 },
    {  0, 140,  4, 200,  70,  0,  10, 230, 200,  30 },
    {  0, 130,  5, 220,  60,  0,   0, 210, 230,  20 },
    {  0, 200,  3, 240,  80,  0,  20, 250, 220,  40 },
    {  0, 150,  4, 210,  90,  0,   0, 245, 210,  30 },
    {  0, 260,  1, 230,  30,  0,  60, 190, 170,  60 },
    /* trance: короткие ноты, средний срез, резонанс — роллинг и офф-бит, а не тяжёлый низ */
    {  0, 120,  1, 120,  20,  0,  0, 150, 170,  20 },
    {  0, 100,  1, 110,  30,  0,  0, 170, 190,  10 },
    {  0,  90,  2, 140,  40,  0,  0, 190, 220,   0 },
    {  0, 160,  0, 100,  10,  0,  0, 130, 150,  40 },
    {  0, 130,  3, 170,  60,  0,  0, 230, 210,   0 },
    {  0, 210,  0,  80,  10,  0,  0, 100, 120,  60 },
    {  0, 140,  2, 150,  90,  0,  0, 200, 200,  20 },
    {  0,  70,  4, 180,  30,  0,  0, 160, 180,   0 },
    {  0, 260,  1, 130,  25,  0,  0, 140, 160,  50 },
    {  0, 180,  1, 110,  40,  0,  0, 180, 190,  30 },
};

/*
 * Thirty rhythms, as sixteen steps of one bar each.
 *
 * The symbol is where the note sits above the root, in semitones: '.' is a rest, '0' the
 * root, and the letters carry on up to '9' and then 'a'..'f' for ten to fifteen. A bar of
 * a bass line is a rhythm and a contour at once, and writing both as one string keeps the
 * table readable and keeps the two from drifting apart.
 *
 * 'x' is the root an octave up — the one note that has to be written down as a different
 * thing from the root, because a bass line's hook is usually that note.
 */
/*
 * СИЛА ШАГА.
 *
 * Шестнадцать полубайтов на заготовку: сколь сильно бьётся нота на этом шаге. Выведено из
 * метрики рисунка — сильная доля громче, слабая тише, — поэтому рисунок качает, а не дрожит.
 * Ноль значит паузу и стоит там же, где пауза в рисунке. Размах 0.55..1.0, акцент выше.
 */
const char *const STEP_VEL[42] = {
    "f000000000000000",  /*  0   1 */
    "f0000000e0000000",  /*  1   2 */
    "00b000b000b000b0",  /*  2   4 */
    "e000d000e000d000",  /*  3   4 */
    "e0090000e0090000",  /*  4   4 */
    "f0b0d0b000000000",  /*  5   4 */
    "f000d000e000d000",  /*  6   4 */
    "000b000b000b000b",  /*  7   4 */
    "f000f000f000f000",  /*  8   4 */
    "f0007000e0007000",  /*  9   4 */
    "f000e000e000e000",  /* 10   4 */
    "00b00800e00900b0",  /* 11   5 */
    "e00900b00800d000",  /* 12   5 */
    "e000d000e0b0d000",  /* 13   5 */
    "f000d000e000d0b0",  /* 14   5 */
    "f000d000e000d0b0",  /* 15   5 */
    "f00b00d000d00a00",  /* 16   5 */
    "00d000d00b000b0b",  /* 17   5 */
    "f000d000e0b0d0b0",  /* 18   6 */
    "f00b0a00f00b0a00",  /* 19   6 */
    "f00b00d00a00f00b",  /* 20   6 */
    "f000f0d0f000f0d0",  /* 21   6 */
    "00d007d000d007d0",  /* 22   6 */
    "f00b00d00b00e00b",  /* 23   6 */
    "070b0070e0070b00",  /* 24   6 */
    "e0b0d0b0e0b0d0b0",  /* 25   8 */
    "e0b900b0e0b900b0",  /* 26   8 */
    "f0b0d0b0e0b0d0b0",  /* 27   8 */
    "f00bf00bf00bf00b",  /* 28   8 */
    "7070707070707070",  /* 29   8 */
    "07d007d007d007d0",  /* 30   8 */
    "f070e070e070e070",  /* 31   8 */
    "f0d00b0be0d00b0b",  /* 32   8 */
    "f007e007e007e007",  /* 33   8 */
    "e0b0d8090809d0b0",  /* 34   9 */
    "f0b0d0b0e0b0d0b9",  /* 35   9 */
    "e0b908b0e0b908b0",  /* 36  10 */
    "f0db0bd0e0db0bd0",  /* 37  10 */
    "f0b908b908b0d8b0",  /* 38  11 */
    "f0b9d0b9e0b9d0b9",  /* 39  12 */
    "07db07db07db07db",  /* 40  12 */
    "f7db7bd7e7db7bd7",  /* 41  16 */
};

const char *const PATTERNS[42] = {
    "0...............",      /* BLANK    одна нота */
    "0.......0.......",      /* SPACE    воздух */
    "..0...0...0...0.",      /* OFFBEAT  между долями */
    "0...0...0...0...",      /* STAB     четвертями */
    "0..0....0..0....",      /* JAB      короткие тычки */
    "0.0.0.0.........",      /* HALF     половина такта */
    "7...5...3...2...",      /* DESCEND  спуск */
    "...0...0...0...0",      /* LATE     нота опаздывает */
    "0...1...2...3...",      /* CRAWL    малыми шагами */
    "0...o...0...o...",      /* DUBGHOST четверти с призвуком */
    "0...3...5...7...",      /* SEEKER   поиск вверх по такту */
    "..0..0..0..0..0.",      /* OFF16    офф-бит шестнадцатыми */
    "0..0..0..0..0...",      /* TRIPLET  триоль: пять нот на такт */
    "0...0...0.0.0...",      /* PUMP     качание через долю */
    "0...0...0...0.x.",      /* SLIDE    длинные ноты под связку */
    "0...0...0...3.5.",      /* PICKUP   подход к доле */
    "0..0..0...0..0..",      /* FLOW     текущий рисунок */
    "..0...0..0...0.0",      /* SKANK    сдвиг через такт */
    "0...0...0.4.5.7.",      /* CLIMB    подъём к концу */
    "0..0.0..0..0.0..",      /* SHUFFLE  качание поперёк */
    "0..x..0..x..0..x",      /* BASSX    октава через две */
    "0...0.0.0...0.0.",      /* EIGHTH   восьмыми со сдвигом */
    "..0..o0...0..o0.",      /* SKIP     перескок с призвуком */
    "0..2..0..2..0..2",      /* WALKER   шаг на две доли */
    ".o.0..o.0..o.0..",      /* HALFGHOST половина с призвуком */
    "0.0.0.0.0.0.0.0.",      /* ROLL     шестнадцатыми, ровно */
    "0.00..0.0.00..0.",      /* GALLOP   галоп */
    "0.x.0.x.0.x.0.x.",      /* OCT8     скачки на октаву */
    "0..00..00..00..0",      /* ROLL3    тройной роллинг */
    "o.o.o.o.o.o.o.o.",      /* PSYGHOST призраки восьмыми */
    ".o0..o0..o0..o0.",      /* PULSE    пульс через три доли */
    "0.o.0.o.0.o.0.o.",      /* HOP      скачок с призвуком */
    "0.0..0.00.0..0.0",      /* SLIP     соскальзывание */
    "0..o0..o0..o0..o",      /* TRIPGHOST триоль с призвуком */
    "0.0.00.0.0.00.0.",      /* PSYSHIFT пси-роллинг со сдвигом */
    "0.0.0.0.0.0.0.00",      /* DRIVE16  роллинг с толчком в конце */
    "0.00.00.0.00.00.",      /* ROLL2    роллинг с двойным ударом */
    "0.00.30.0.00.30.",      /* ACID     кислотный ход */
    "0.00.000.00.000.",      /* RUN16    бег шестнадцатыми */
    "0.x00.x00.x00.x0",      /* OCT16    октава внутри роллинга */
    ".o00.o00.o00.o00",      /* PSYROLL  призрак и два сильных: пси-ролл */
    "0o00o00o0o00o00o",      /* ROLLGHOST роллинг с призвуками */
};

/* Число рисунков здесь и BASS_PAT_COUNT в synth_app.h обязаны совпадать: имя на экране и звук
 * выбираются по одному и тому же числу, и разойтись они не должны молча. */
static_assert((int)(sizeof(PATTERNS) / sizeof(PATTERNS[0])) == 42,
              "BASS_PAT_COUNT в synth_app.h разошёлся с таблицей рисунков");


/* Seconds of one sixteenth at 120 bpm: the fallback before the app says anything. */
constexpr float kDefaultBpm = 120.0f;

/*
 * VAR — ДОЛЯ ВАРИАЦИЙ, А НЕ ИХ ВИД.
 *
 * Сначала здесь стояла таблица из шести характеров, и ручка выбирала строку: STEADY, JUMP,
 * WALK, ROLL, DRIVE, DROP. Владелец сказал, что это не вероятность и что непонятно, — и был
 * прав: ручка отвечала на вопрос «что именно», а не «насколько». Теперь она отвечает на
 * второй: сколько тактов получает октавный скачок, сколько — добавочный акцент и сколько —
 * добавочную связку. Рисунок при этом остаётся рисунком: за него отвечает PAT, и двадцать
 * девять фигур никуда не делись.
 */
constexpr float VAR_JUMP = 0.50f;    /* доля тактов со скачком при VAR = 1 */
constexpr float VAR_ACCENT = 0.30f;  /* и доля добавочных акцентов */
constexpr float VAR_TIE = 0.30f;     /* и доля добавочных связок */

/* THE ENVELOPE'S STAGES. A bass note is not a pluck: it is struck, it falls to a level and
 * then it HOLDS there for as long as the step lasts, and only then does it let go. The first
 * version of this voice had no sustain at all — an exponential to nothing — which is why the
 * notes were short and the kits sounded alike: almost all of what a kit says lives in the
 * sustain and in how the filter moves over it. */
enum { ST_OFF = 0, ST_ATT, ST_DEC, ST_SUS, ST_REL };

/*
 * THE VOICE, AND WHY IT IS THIS VOICE.
 *
 * Владелец сказал: за основу взять TB-303. Это не вкус, это набор решений, которые вместе и
 * дают тот самый бас, и каждое из них здесь есть:
 *
 *   - один осциллятор, пила ИЛИ меандр, без кроссфейда между ними и без второго голоса:
 *     переключение, а не смесь (поле wave заготовки);
 *   - четырёхполюсный фильтр-лестница с резонансом почти до самовозбуждения, а не два
 *     однополюсника: резонанс и есть «квак», без него нота просто глухая;
 *   - огибающая ГРОМКОСТИ без сустейна: нота падает от удара к остатку и живёт столько,
 *     сколько задал DECAY. Именно это делает бас щипковым, а не органным;
 *   - огибающая ФИЛЬТРА со своим, более коротким спадом: срез открывается на ударе и
 *     закрывается быстрее ноты — отсюда «бау»;
 *   - акцент поднимает и громкость, и глубину фильтра, и резонанс, как акцентная схема 303;
 *   - слайд — глиссандо на связке, а не новая нота.
 *
 * Суб-октава (треугольник) осталась, но она выведена из основного пути: на 303 её нет, и
 * больше четверти в смесь она не идёт — это добавка веса для мягких заготовок, а не голос.
 */
/*
 * THE VOICE, AND WHAT IT COSTS.
 *
 * Владелец: «нужно очень оптимально и дешёво реализовать дорожку баса, но в то же время
 * качественно звучащую». Отсюда два правила, и оба записаны здесь, потому что нарушить их
 * легко, а заметить — только ушами.
 *
 * ЦЕНА. Всё, что не обязано быть посепмпльным, считается на управляющей частоте: огибающие,
 * срез, глиссанде, бросок высоты — раз в восемь сэмплов (0.17 мс, шесть тысяч раз в секунду).
 * На каждый сэмпл остаётся: фаза, polyBLEP на пиле, фильтр из двух полюсов и один мягкий клип.
 * Ни одного expf, ни одного tanf и ни одного деления в посепмпльном пути, кроме одного клипа.
 *
 * ЗВУК. Голос по-прежнему 303: огибающая громкости без сустейна (удар и спад к остатку),
 * своя более короткая огибающая фильтра, резонансный фильтр и акцент, поднимающий уровень,
 * глубину фильтра и резонанс.
 *
 *   пила/меандр   polyBLEP: две ветки у разрыва, внутри цикла — ничего
 *   фильтр        TPT-состояние: v3 = x - ic2; v1 = a1*ic1 + a2*v3; v2 = ic2 + a2*ic1 + a3*v3;
 *                 ic1 = 2*v1 - ic1; ic2 = 2*v2 - ic2; выход — v2. Устойчив при любом g, потому
 *                 что это топология с предыскажением, а не прямая форма.
 *   клип          один на выходе слоя, и только когда пик выше 0.7.
 */
/*
 * КОЛЕНО ОГРАНИЧИТЕЛЯ. 0.85 и наклон 2.2: голос заходит за колено только на самых густых
 * заготовках и на самом верху SUB, и заходит мягко. Стенд bass_thd собирает ту же ветку с
 * коленом повыше, чтобы измерить, сколько ограничитель добавляет к волне.
 */
#ifndef BASS_LIMIT_KNEE
#define BASS_LIMIT_KNEE 0.85f
#endif
#ifndef BASS_LIMIT_SLOPE
#define BASS_LIMIT_SLOPE 2.2f
#endif

/*
 * СПАД ЗАСЛОНКИ, КОГДА НОВАЯ НОТА ТИШЕ ТЕКУЩЕГО УРОВНЯ. 25 мс: это меньше четверти шага на
 * 120 BPM, поэтому акцент слышен сразу, но уровень ведёт наклоном, а не прыгает.
 */
#ifndef BASS_ATT_FALL_S
#define BASS_ATT_FALL_S 0.025f
#endif

struct Voice {
    float    phase;      /* the oscillator, 0..1 */
    float    amp;        /* the level the note is at, 0..1 */
    float    punch;      /* 1 -> 0 за десять миллисекунд: край ноты */
    float    vca_run;    /* заслонка на этом сэмпле: ведёт, а не шагает */
    float    vca_inc;    /* её наклон на текущем управляющем шаге */
    float    peak;       /* velocity, and more of it when the step is accented */
    float    sus;        /* the level the decay falls to (0 for a pure 303 kit) */
    float    att;        /* заслонка атаки: от уровня прошлой ноты, может стоять и выше 1 */
    float    att_step;   /* шаг вверх за управляющий шаг: 2 мс */
    float    att_fall;   /* шаг вниз: 25 мс, когда новая нота тише текущего уровня */
    float    dec_env;    /* 1 -> 0: the VCA envelope, which has no sustain */
    float    dec_step;
    float    rel;        /* 1 -> 0 once the gate ends, with the decay's own time */
    float    rel_step;
    float    fenv;       /* the filter's own envelope, 1 -> 0, shorter than the VCA's */
    float    fenv_step;
    float    fenv_up;     /* шаг всхода огибающей фильтра за три миллисекунды */
    float    fenv_semis; /* how far it opens the filter, in semitones */
    uint8_t  cut_tick;   /* срез пересчитывается через один управляющий шаг */
    float    sub_ph;     /* фаза саба */
    float    sub_lp;     /* обрез саба */
    float    pitch_env;  /* semitones, decays to zero */
    float    pitch_step;
    float    hz;
    float    hz_target;  /* what a tie glides to */
    float    glide;      /* per control step */
    float    acc;        /* 0 or 1: this note is accented */
    float    acc_res;    /* множитель затухания: акцент поднимает резонанс */
    float    lp, bp;     /* the state-variable filter's two states */
    float    lp3;        /* третий полюс: 18 дБ на октаву, как у триста третьего */
    float    f, q;       /* its coefficients, taken at control rate */
    uint8_t  stage;
    int32_t  gate_left;  /* control steps until the note lets go */
    bool     gate_done;
    bool     on;
    bool     tie;        /* this note glides into the next one */
};

struct Seq {
    float    step_ph;    /* 0..1, the fraction of a step carried between blocks */
    bool     started;    /* the first step of the bar has been struck */
    int      pending;    /* blocks still to wait, the swing of an odd step */
    float    swing;      /* 0..0.6 of a half step, the drum's swing, read every block */
    int      step;       /* 0..len-1 */
    int      len;        /* длина цикла в шагах: LEN, 4..16 */
    int      bar_shift;  /* semitones the whole bar is transposed by, from VAR */
    bool     playing;
    uint32_t rng;

    /* Сбивка и дробь: до трёх добавочных ударов внутри шага. */
    float    orn_ph[3];   /* доля шага, на которой бьётся добавочный удар */
    float    orn_vel[3];
    int8_t   orn_semi[3];
    uint32_t cycle;       /* номер круга рисунка: нечётные отвечают низом */
    uint8_t  orn_n;
    uint8_t  orn_i;
};

float    s_params[P_COUNT];
Voice    s_voice;
Seq      s_seq;
uint32_t s_rate = SYNTH_SAMPLE_RATE;
float    s_inv_rate = 1.0f / (float)SYNTH_SAMPLE_RATE;
float    s_bpm = kDefaultBpm;
float    s_env_pub;      /* telemetry: the envelope the ring reads */
int      s_kit_cur = -1;
int      s_pat_cur = -1;
uint16_t s_accent_mask = 0u;   /* bit per step of the bar, from the app's figure */
/* Двенадцать классов ступеней лада, бит на полутон: бас играет в тональности прибора. */
uint16_t s_scale_mask = 0x0FFFu;

/*
 * Сглаженные значения двух ручек, которые слышны поверх живой ноты: тембр (срез) и привод.
 * Цели лежат в s_params[], а здесь — то, что реально читает голос. Одна поль на управляющем
 * шаге, около восемнадцати миллисекунд: медленнее руки, быстрее слуха.
 */
float s_tone_cur = 0.45f;
float s_res_cur = 0.5f;      /* резонанс: ручка ведёт, а не прыгает */

/* Часы прибора, приходящие из приложения каждый блок: идёт ли время и какая доля такта. */
float s_ext_phase = 0.0f;
bool  s_ext_running = false;
bool  s_ext_seen = false;   /* прибор уже сказал, где он: до этого бас идёт сам */
float s_knob_glide = 0.0f;
float s_punch_step = 0.5f;   /* спад панча: десять миллисекунд */
float    s_root_hz = 55.0f;    /* the instrument's tonic, two octaves down (A1 at boot) */

inline uint32_t rnd_next()
{
    s_seq.rng ^= s_seq.rng << 13;
    s_seq.rng ^= s_seq.rng >> 17;
    s_seq.rng ^= s_seq.rng << 5;
    return s_seq.rng;
}

inline float rnd01()
{
    return (float)(rnd_next() >> 8) * (1.0f / 16777216.0f);
}

inline bool coin(float p)
{
    return rnd01() < p;
}

/*
 * ПОЛУТОН, ПРИЖАТЫЙ К ЛАДУ.
 *
 * Владелец: «скейл должен влиять на бас». Маска приходит из прибора теми же двенадцатью
 * классами, что и у лида, и каждый полутон линии прижимается к ближайшей ступени; при равном
 * расстоянии берётся нижняя — то же правило, что в seq_scale_note() у приложения, чтобы бас и
 * лид выбирали одну и ту же ноту из двух равноудалённых. Всё, что выше октавы, прижимается
 * внутри своей октавы, поэтому переносы на октаву остаются переносами.
 *
 * Маска 0x0FFF означает «лад не задан»: тогда полутон возвращается как есть, и рисунок
 * баса читается буквально.
 */
int scale_fit(int semi)
{
    if (s_scale_mask == 0x0FFFu) {
        return semi;
    }

    int oct = semi / 12;
    int pc = semi - oct * 12;

    if (pc < 0) {
        pc += 12;
        oct--;
    }

    if ((s_scale_mask >> pc) & 1u) {
        return semi;
    }

    for (int d = 1; d <= 6; d++) {
        int down = pc - d;
        int up = pc + d;

        if (down >= 0 && ((s_scale_mask >> down) & 1u)) {
            return oct * 12 + down;
        }

        if (up < 12 && ((s_scale_mask >> up) & 1u)) {
            return oct * 12 + up;
        }
    }

    return semi;
}

/* Сила шага из таблицы: 0 пауза, 1..7 слабая доля, 8..11 средняя, 12..15 сильная. */
float pattern_velocity(int pat, int step)
{
    /*
     * ПРИЗРАК: 'o' в рисунке — это нота, но тихая.
     *
     * Таблица силы шага — про метрику: сильная доля громче слабой. Призраку нужен уровень
     * НИЖЕ размаха обычных долей, иначе он перестаёт быть призвуком и становится обычной
     * нотой. Поэтому для 'o' таблица не читается вовсе: ответ один и тот же, 0.50 — слышно,
     * что доля живая, и слышно, что она слабая.
     */
    if (PATTERNS[pat][step & 15] == 'o') {
        /* Призрак остаётся явно слабее сильной доли, но не провалом: 0.50 это −6 дБ от
         * удара, а прежние 0.32 — почти −10 дБ, и в линии через шаг это качало громкость
         * на десять децибел каждые 250 мс. */
        return 0.50f;
    }

    const char *s = STEP_VEL[pat];
    const int v = (s[step & 15] <= '9') ? (s[step & 15] - '0') : (s[step & 15] - 'a' + 10);

    if (v <= 0) {
        return 0.0f;
    }

    /*
     * ТРИ УРОВНЯ, А НЕ ШЕСТНАДЦАТЬ.
     *
     * Таблица силы шага держит шестнадцать значений, и они расставлены по рисункам вручную —
     * то есть дрожь между соседними долями в один-два децибела не значит ничего: она не
     * сильная доля и не слабая, она просто другое число. На слух это ступенька громкости.
     * Метрика же знает три роли: сильная доля, средняя и слабая. Порядок таблицы сохранён —
     * какой шаг сильнее какого, решает рисунок, — но значений теперь три.
     */
    if (v >= 12) {
        return 1.00f;      /* сильная доля */
    }
    if (v >= 8) {
        return 0.88f;      /* средняя */
    }
    return 0.78f;          /* слабая */
}

/* The step's symbol, resolved to a semitone above the root, or -1 for a rest. */
int pattern_semitone(int pat, int step)
{
    const char *s = PATTERNS[pat];
    const char c = s[step & 15];

    if (c == '.') {
        return -1;
    }
    if (c == 'x') {
        return 12;
    }
    /* 'o' — призрачный удар: та же тоника, только тише. См. pattern_velocity(). */
    if (c == 'o') {
        return 0;
    }
    if (c >= '0' && c <= '9') {
        return c - '0';
    }
    if (c >= 'a' && c <= 'f') {
        return 10 + (c - 'a');
    }

    return 0;
}

/*
 * Корень линии, в герцах: тоника прибора, отведённая на две октавы вниз (её ставит
 * приложение через synth_bass_set_root_hz), октавная ручка баса и скачок такта.
 *
 * Первая версия стояла на жёстких 55 Гц: бас всегда играл в ля, в какой бы тональности ни
 * был патч. Владелец просил независимости «кроме клока и транспорта» — транспозиция и есть
 * то, что бас обязан брать у прибора.
 */
float root_hz()
{
    /*
     * РУЧКИ ОКТАВЫ БОЛЬШЕ НЕТ.
     *
     * Регистр линии ставит поле октавы самой заготовки (тридцать наборов, у каждого своё), и
     * этого хватает: владелец убрал подстройку октавы со страницы, чтобы вернуть на неё SNAP.
     * Здесь остаётся перенос на октаву от вариации — он часть рисунка, а не настройка.
     */
    float hz = s_root_hz * powf(2.0f, (float)s_seq.bar_shift / 12.0f);

    /*
     * НИЖНЯЯ ГРАНИЦА СТОИТ НА КОРНЕ, А НЕ НА КАЖДОЙ НОТЕ.
     *
     * На корпусе прибора нет ничего, что воспроизвело бы двадцать семь герц: нота ниже
     * сорока одного — это тишина с расходом хода динамика. Но если зажимать каждую ноту,
     * то при OCT вниз все ноты линии сходятся в одну и та же высоту, и рисунок становится
     * метрономом. Зажатый корень сохраняет интервалы: линия живёт в 41..165 Гц.
     */
    if (!(hz >= 41.0f)) {
        hz = 41.0f;
    }
    if (hz > 165.0f) {
        hz = 165.0f;
    }

    return hz;
}

float note_hz(int semitone)
{
    /* Полутоны рисунка неотрицательны, поэтому нота не бывает ниже корня, а корень уже
     * зажат. Зажим здесь — только на случай мусора в поле шага. */
    float hz = root_hz() * powf(2.0f, (float)semitone / 12.0f);

    /* Пол — 27 Гц: ручка октавы опускает линию до A0 (27.5 Гц), и это нижняя нота, которую
     * прибор играет осмысленно. Выше 400 Гц бас не идёт. */
    if (!(hz >= 27.0f && hz <= 400.0f)) {
        hz = (hz < 27.0f) ? 27.0f : 400.0f;
    }

    return hz;
}

/*
 * THE COST OF A SAMPLE.
 *
 * The first version of this voice called expf(), powf() and tanhf() per sample — three library
 * calls sixty thousand times a second, on the one task that must never miss a block. That is
 * what the stutter was: not the bass being loud, but the bass being slow, and the audio task
 * arriving late while a finger was on the screen.
 *
 * What is left is arithmetic: the filter's coefficient is computed once a block (its cutoff is
 * a 15 ms pole, so block rate is 300 times faster than it moves), the pitch envelope reads a
 * bit-trick exponential that is within two percent over the octave it travels, and the drive
 * is a Pade approximation of tanh that is exact to three decimals over the range it sees.
 */
/*
 * 2^x по битовому трюку Шраудольфа.
 *
 * Формула: биты (x + 126.94269504) * 2^23 — это и есть 2^x с точностью до трёх процентов.
 *
 * Здесь была ошибка, которая стоила нескольких переделок голоса: множитель стоял 12102203
 * вместо 8388608, и результат умножался на два в пятьдесят шестой. Срез заготовки выходил
 * 5*10^19 Гц, зажимался защитой в 20 Гц — и весь бас с первой версии играл через фильтр на
 * двадцати герцах: тихо, низко, без гармоник, и ни одна правка заготовок этого не меняла.
 *
 * Ошибка приближения не больше 3% (это 0.05 полутона), и она постоянна: на слух это не
 * ловится, а стоит два умножения и приведение к целому.
 */
inline float fast_exp2(float x)
{
    union { uint32_t i; float f; } u;

    u.i = (uint32_t)(int32_t)((x + 126.94269504f) * 8388608.0f);

    return u.f;
}

/*
 * A bounded soft clip: y = x / (1 + |x|), which is exactly linear near zero, never leaves
 * [-1, 1], and costs a compare and a multiply.
 *
 * The first attempt was the Pade (3,2) of tanh — accurate, cheap, and UNBOUNDED: for large x it
 * grows like x/9, so a drive above about four did not saturate the note, it amplified it without
 * limit. That is what took the instrument's sound apart: every bass note turned into a wall of
 * clipped drone. A clipper has to be bounded before it is anything else.
 */
inline float soft_clip(float x)
{
    const float ax = fabsf(x);

    return x * (1.0f / (1.0f + ax));
}

/*
 * polyBLEP: сглаживание разрыва пилы в двух сэмплах у перехода фазы.
 *
 * Наивная пила на басовой ноте даёт алиасинг на каждой гармонике выше Найквиста, и это
 * слышно не как «грязно», а как щелчки на атаке — то, на что владелец и жаловался. Цена —
 * два сравнения на сэмпл, ветка только у разрыва.
 */
/* Шаг огибающей обязан быть в (0,1): всё остальное — не число, а катастрофа в фильтре. */
inline float step_clamp(float s)
{
    if (!(s > 0.0f && s < 1.0f)) {
        return 0.9999f;
    }
    return s;
}

/*
 * Обратное dt приходит готовым: внутри сэмпла делить нечего. dt меняется только на
 * управляющем шаге, а сэмплов между ними восемь — восьмикратная экономия на делении.
 */
inline float poly_blep(float t, float dt, float inv_dt)
{
    if (t < dt) {
        t *= inv_dt;

        return t + t - t * t - 1.0f;
    }
    if (t > 1.0f - dt) {
        t = (t - 1.0f) * inv_dt;

        return t * t + t + t + 1.0f;
    }

    return 0.0f;
}

/* A one-pole coefficient for a cutoff in Hz. */
float one_pole(float hz)
{
    if (hz < 20.0f) {
        hz = 20.0f;
    }
    if (hz > (float)s_rate * 0.45f) {
        hz = (float)s_rate * 0.45f;
    }

    return 1.0f - expf(-6.28318f * hz * s_inv_rate);
}

/*
 * Срез заготовки: 30 Гц .. 5 кГц по полю 0..255 — диапазон ручки CUTOFF у 303. Прошлая
 * карта кончалась на 1.6 кГц, и все заготовки сидели в одной полосе глухоты; у 303 верх
 * среза и есть то, из-за чего одна нота квакает, а другая бубнит. TONE открывает или
 * закрывает всё это примерно на две октавы.
 */
float cutoff_hz()
{
    const Kit &k = KITS[s_kit_cur < 0 ? 0 : s_kit_cur];
    const float base = 45.0f * fast_exp2((float)k.tone * (1.0f / 255.0f) * 5.40f);

    /*
     * РАЗМАХ РУЧКИ — ПОЧТИ ПЯТЬ ОКТАВ.
     *
     * Было 0.6..2.5, то есть чуть больше октавы: TONE красил заготовку, но не открывал и не
     * закрывал фильтр. 0.22..5.8 — это от глухого стука до звона на грани слышимости, и
     * разница между положениями ручки слышна без вслушивания.
     */
        /*
     * СРЕЗ — ТОЛЬКО ИЗ КИТА.
     *
     * Здесь стоял множитель 0.22 + 4.5*ручка: срез был и полем заготовки, и ручкой на
     * странице, и они умножались. Владелец: «настройки TONE и RES хранятся внутри кита, а еще
     * и выведены, так быть не должно — фильтр баса пусть только в китах хранится». Множителя
     * больше нет: заготовка — единственное место, где живёт тембр, а страница баса вместо
     * этого получила октаву.
     */
    const float macro = 1.0f;

    return base * macro;
}

/* ------------------------------------------------------------------------- */
/* The sequencer                                                             */
/* ------------------------------------------------------------------------- */

/*
 * Обрез саба: однополюсный, ниже 22 Гц. Считается раз в блок.
 *
 * Было 28 Гц, и это стояло прямо на сабе: у ноты A1 (55 Гц) саб — это 27.8 Гц, то есть ровно
 * на срезе, и он приходил в сумму ослабленным на три децибела. Двадцать два герца оставляют
 * его целым, а всё, что ниже — гул, которого не слышно и который только ест запас.
 */
static float sub_hp_coef(void)
{
    float k = 1.0f - expf(-6.2831853f * 22.0f * s_inv_rate);

    if (!(k > 0.0f)) {
        k = 0.0001f;
    }

    return (k > 0.5f) ? 0.5f : k;
}

void start_note(int semitone, float velocity, bool slide_from_before)
{
    const Kit &k = KITS[s_kit_cur < 0 ? 0 : s_kit_cur];

    const float gate = 0.25f + s_params[P_GATE] * 3.75f;             /* 0.25..4 шага */

    /* Глиссандо связки — доля шага, а не жёсткие 60 мс: на медленном темпе связка должна
     * петь, на быстром — успевать до следующей ноты. 45 % шага при 120 BPM это 56 мс. */
    const float step_s = 60.0f / (s_bpm * 4.0f);
    float glide_s = step_s * 0.45f;

    if (glide_s < 0.030f) { glide_s = 0.030f; }
    if (glide_s > 0.160f) { glide_s = 0.160f; }
    float decay_s = ((float)k.decay_ms * (0.40f + s_params[P_DECAY] * 4.6f)) * 0.001f;
    /*
     * ОКТАВА ЛИНИИ — СВОЯ РУЧКА.
     *
     * Владелец: «нужна дополнительная настройка, позволяющая отклоняться по октаве, но всё же
     * не нарушая общий склад». Сдвиг на целую октаву класс ступени не меняет, поэтому склад
     * остаётся целым при любом положении ручки: бас опускается в подвал или уходит вверх, но
     * нота по-прежнему из тональности. Регистр заготовки складывается с этим сдвигом.
     */
    /*
     * СМЕНА НОТЫ, А НЕ ОКТАВЫ.
     *
     * Пятнадцать положений: −7..+7 полутонов, шаг в один полутон. Сдвиг идёт ДО scale_fit(),
     * поэтому линия и сдвигается, и остаётся в складе: прижатие к маске лада срабатывает уже
     * на сдвинутой ноте. Квинта (+7) и кварта (+5) доступны прямо, а не через две ручки.
     */
    const int note_shift = (int)lroundf(s_params[P_NOTE] * 14.0f) - 7;
    const float hz = note_hz(scale_fit(semitone + k.octave * 12 + note_shift));

    /* Спад не короче тридцати миллисекунд: exp(-1/0) — это бесконечность в огибающей. */
    if (!(decay_s > 0.030f)) {
        decay_s = 0.030f;
    }

    /*
     * СВЯЗКА — ЭТО НОТА, КОТОРАЯ НЕ КОНЧИЛАСЬ, А ПОЕХАЛА.
     *
     * Глиссандо здесь было и раньше, но огибающую связка не поднимала: нота продолжала
     * спадать, и через шаг звучала втрое тише обычной (RMS 0.030 против 0.11). В миксе
     * такого глиссандо не слышно — отсюда «не слышу слайдов при любом значении». Заслонка
     * тоже не продлевалась, поэтому связка могла закрыться посреди глиссандо.
     *
     * СВЯЗКА НИЧЕГО НЕ ПЕРЕЗАПУСКАЕТ. Было так: связка берёт всё, что берёт обычная нота,
     * кроме удара, — огибающую заново от текущего уровня и спад заново. На слух это выходило
     * вторым ударом без щелчка, а на рисунке из одинаковых нот, каких большинство, ручка не
     * меняла почти ничего: RMS отличался на два процента, и владелец сказал «не слышно, что
     * делает». Теперь связка — ПРОДОЛЖЕНИЕ: огибающая идёт как шла, заслонка продлевается на
     * новую длину, высота ползёт в следующую ноту за время глиссандо. Две ноты на рисунке
     * становятся одной длинной и без второго удара — это и есть tie с легато.
     *
     * ЗАСЛОНКА СЧИТАЕТСЯ В УПРАВЛЯЮЩИХ ШАГАХ, как и в обычной ветке: здесь не было деления
     * на CONTROL_STRIDE, поэтому связка держала ноту в восемь раз дольше обычной и линия
     * слипалась в гудение.
     *
     * И СВЯЗКА ВОЗМОЖНА ТОЛЬКО С ЖИВОЙ НОТЫ: если заслонка уже закрылась, это не
     * продолжение, а пропуск, и бьёт обычная нота. Условие внизу это и проверяет.
     */
    /* Спад заслонки — та же величина для связки и для обычной ноты. Время задано макросом:
     * стенд bass_steps собирает ту же ветку с BASS_ATT_FALL_S около нуля, чтобы измерить
     * ступеньку ДО правки на том же коде. */
    const float att_fall = (float)CONTROL_STRIDE / (BASS_ATT_FALL_S * (float)s_rate);

    if (slide_from_before && s_voice.on && s_voice.tie && !s_voice.gate_done) {
        s_voice.hz_target = hz;
        s_voice.tie = true;

        /* Огибающие и заслонка не трогаются вовсе: это та же нота, и уровень на стыке
         * непрерывен сам по себе — ни ступеньки, ни щелчка. */
        s_voice.acc_res = 1.0f;   /* связка не акцентируется */

        s_voice.gate_done = false;
        s_voice.gate_left = (int32_t)(gate * (float)s_rate / ((s_bpm / 60.0f) * 4.0f)
                                      / (float)CONTROL_STRIDE);

        s_voice.glide = 1.0f - expf(-(float)CONTROL_STRIDE / (glide_s * (float)s_rate));
        return;
    }

    float snap = (float)k.snap * (0.2f + s_params[P_SNAP] * 0.8f);

    if (snap > 6.0f) {
        snap = 6.0f;
    }

    s_voice.hz = hz;
    s_voice.hz_target = hz;
    s_voice.glide = 1.0f - expf(-(float)CONTROL_STRIDE / (glide_s * (float)s_rate));

    s_voice.stage = ST_ATT;
    s_voice.att_step = (float)CONTROL_STRIDE / (0.002f * (float)s_rate);
    s_voice.fenv_up = (float)CONTROL_STRIDE / (0.003f * (float)s_rate);

    /* Атака с уровня прошлой ноты: сброс в ноль — ступенька, то есть щелчок. */
    const float was = (s_voice.on && velocity > 0.001f) ? s_voice.amp / velocity : 0.0f;

    /*
     * СТУПЕНЬКА ГРОМКОСТИ, А НЕ ЩЕЛЧОК.
     *
     * Здесь стоял зажим в единицу: нота тише текущего уровня роняла его мгновенно, и в линии
     * это слышно ступенькой — призрак после сильной доли падал на 17 дБ за миллисекунду.
     * Теперь заслонка может стоять выше единицы и опускается к ней за 25 мс: уровень на стыке
     * тот же (peak * att = amp прошлой ноты), щелчка нет, а падение стало наклоном.
     */
    s_voice.att = (was < 0.0f) ? 0.0f : ((was > 4.0f) ? 4.0f : was);
    s_voice.att_fall = att_fall;
    s_voice.punch = 1.0f;
    s_voice.peak = velocity;
    s_voice.sus = ((float)k.sus * (1.0f / 255.0f)) * 0.45f;
    s_voice.dec_env = 1.0f;
    s_voice.dec_step = step_clamp(expf(-6.9078f / (decay_s * (float)s_rate
                                                  / (float)CONTROL_STRIDE)));

    float rel_s = decay_s * 0.55f;

    if (rel_s < 0.020f) {
        rel_s = 0.020f;
    }

    s_voice.rel = 1.0f;
    s_voice.rel_step = step_clamp(expf(-6.9078f / (rel_s * (float)s_rate
                                                  / (float)CONTROL_STRIDE)));
    s_voice.gate_done = false;
    s_voice.gate_left = (int32_t)(gate * (float)s_rate / ((s_bpm / 60.0f) * 4.0f)
                                  / (float)CONTROL_STRIDE);

    /*
     * САБ СТАРТУЕТ С НУЛЕВОГО ПЕРЕХОДА.
     *
     * Треугольник в нуле фазы стоит на единице, поэтому сброс в ноль давал скачок с текущего
     * значения на единицу. На добавочном ударе сбивки заслонка уже открыта, и скачок слышен
     * щелчком. Четверть фазы — это ноль треугольника: значение на стыке совпадает.
     */
    if (!slide_from_before) {
        s_voice.sub_ph = 0.25f;
    }

    s_voice.pitch_env = snap;
    s_voice.pitch_step = step_clamp(expf(-6.9078f / (0.030f * (float)s_rate
                                                     / (float)CONTROL_STRIDE)));

    /* Огибающая фильтра: своя, короче ноты, до тридцати полутонов. */
    s_voice.fenv = 0.0f;
    s_voice.fenv_step = step_clamp(expf(-6.9078f / (decay_s * 0.55f * (float)s_rate
                                                   / (float)CONTROL_STRIDE)));
    s_voice.fenv_semis = (float)k.fenv * (30.0f / 255.0f) * (0.50f + s_params[P_SNAP] * 0.8f);

    /*
     * АКЦЕНТ — ЭТО КВАК, А НЕ ТОЛЬКО ГРОМЧЕСТЬ.
     *
     * Акцентированная нота открывает фильтр на половину глубже и поднимает резонанс на
     * пятую часть: у триста третьего акцент устроен именно так, и именно он даёт «квак»,
     * который слышно поверх бочки. Ручка ACCENT задаёт, сколько этого добра нужно.
     */
    if (s_voice.acc > 0.5f) {
        s_voice.fenv_semis *= 1.0f + 0.55f * s_params[P_ACCENT];
        s_voice.acc_res = 1.0f - 0.20f * s_params[P_ACCENT];
    } else {
        s_voice.acc_res = 1.0f;
    }

    if (!s_voice.on) {
        /* Фильтр держит состояние прошлой ноты: на резонансе это готовый щелчок. */
        s_voice.lp = 0.0f;
        s_voice.bp = 0.0f;
        s_voice.lp3 = 0.0f;
        }

    s_voice.on = true;
}

/* One step of the bar. Called by the block renderer when the clock crosses a step. */
/* Зажечь добавочный удар: тот же голос ещё раз, короткой заслонкой. */
static void fire_ornament(int semi, float vel)
{
    const float step_s = 15.0f / ((s_bpm > 1.0f) ? (s_bpm * 4.0f) : 480.0f);

    start_note(semi, vel, false);
    s_voice.tie = false;
    s_voice.acc = 0.0f;
    s_voice.gate_left = (int32_t)(step_s * 0.30f * (float)s_rate);
    s_voice.gate_done = false;
}

/* Сработали ли добавочные удары на этой доле шага. */
static void service_ornaments(void)
{
    while (s_seq.orn_i < s_seq.orn_n && s_seq.step_ph >= s_seq.orn_ph[s_seq.orn_i]) {
        fire_ornament((int)s_seq.orn_semi[s_seq.orn_i], s_seq.orn_vel[s_seq.orn_i]);
        s_seq.orn_i++;
    }
}

void run_step()
{
    /* Счёт рисунков берётся у самой таблицы: раньше здесь стояло 29, и с сорока двумя
     * рисунками ручка перестала попадать в те, что правее тридцатого. */
    const float pat_span = (float)((int)(sizeof(PATTERNS) / sizeof(PATTERNS[0])) - 1);
    const int pat = (int)floorf(s_params[P_PAT] * pat_span + 0.5f);
    const int len = 4 + (int)floorf(s_params[P_LEN] * 12.0f + 0.5f); /* 4..16 */

    /*
     * ДЛИНА — ЭТО ДЛИНА ЦИКЛА.
     *
     * Было так: шаг всё равно шёл до шестнадцати, а длина только запрещала играть дальше неё.
     * Ноты замолкали, такт оставался шестнадцатишаговым, и бас не мог жить в своём размере.
     * Теперь счётчик идёт по модулю длины: при LEN в четыре шага линия повторяется четыре
     * раза за такт перкуссии, при семи — семь шагов против её шестнадцати. Это и есть та
     * полиритмия, которую просил владелец.
     */
    s_seq.len = (len < 1) ? 1 : len;
    s_seq.orn_n = 0;
    s_seq.orn_i = 0;

    s_pat_cur = pat;

    /* VAR — доля вариаций: сколько циклов вообще варьируется. */
    const float var = s_params[P_VAR];

    /* Решение о скачке принимается один раз на цикл, на его первом шаге. */
    if (s_seq.step == 0) {
        s_seq.bar_shift = 0;

        if (coin(var * VAR_JUMP)) {
            s_seq.bar_shift = coin(0.5f) ? 12 : -12;
        }
    }

    if (s_seq.step >= len) {
        return;
    }

    int semi = pattern_semitone(pat, s_seq.step);

    /*
     * ОТВЕТ НИЗОМ на нечётном круге: верхняя половина фигуры уходит на октаву вниз. Ритм тот
     * же, хук тот же, но звучит снизу — так линия не повторяется, а разговаривает.
     */
    if (var > 0.15f && (s_seq.cycle & 1u) && semi >= 7) {
        semi -= 12;
    }

    if (semi < 0) {
        return;
    }

    /*
     * Акцент — из ФИГУРЫ, а не из монеты: тот же рисунок из восьми, что на ударных, в
     * секвенсоре и в арпеджиаторе, только свой. Связка остаётся монетой — она про игру, а не
     * про рисунок, — но акцентированная нота связку отменяет: твёрдый удар, который ещё и
     * тянется, это смаз.
     */
    /*
     * SLIDE — ЭТО ВЕРОЯТНОСТЬ СВЯЗКИ, И БОЛЬШЕ НИЧЕГО.
     *
     * Было: ручка, придавленная множителем 0.75 и потолком 0.9, плюс прибавка от характера
     * такта, а акцентированная нота связку отменяла. В итоге ручка почти ничего не меняла.
     * Теперь она прямо задаёт долю склеенных нот, и акцент связку не отменяет: у 303
     * акцентированная нота как раз и тянется в следующую.
     */
    float slide_p = s_params[P_SLIDE] + var * VAR_TIE;

    if (slide_p > 1.0f) { slide_p = 1.0f; }

    const bool mask_accent = ((s_accent_mask >> (s_seq.step & 15)) & 1u) != 0u;
    const bool accent = mask_accent || coin(var * VAR_ACCENT);
    const bool tie = coin(slide_p);

    s_voice.acc = accent ? 1.0f : 0.0f;

    /*
     * СИЛА ИЗ ТАБЛИЦЫ, АКЦЕНТ СВЕРХУ.
     *
     * Было две ступени на всю линию: 1.0 и 0.72. Теперь у каждого шага своя сила из таблицы,
     * а акцент остаётся полной единицей — он про удар, таблица про течение.
     */
    const float vel = accent ? 1.0f : pattern_velocity(pat, s_seq.step);

    start_note(semi, (vel > 0.0f) ? vel : 0.72f, true);
    s_voice.tie = tie;

    /*
     * СБИВКА К КРУГУ. Последний шаг цикла замахивается в следующий: грейс-нота на октаву
     * вверх или вниз через две трети шага. Это не украшение ради украшения — без неё линия
     * замыкается в кольцо, и на четвёртом круге слух перестаёт её слышать.
     */
    if (var > 0.05f && s_seq.step == s_seq.len - 1 && coin(var * VAR_ACCENT)) {
        s_seq.orn_ph[0] = coin(0.5f) ? 0.62f : 0.70f;
        s_seq.orn_semi[0] = (int8_t)(semi + (coin(0.5f) ? 12 : -12));
        s_seq.orn_vel[0] = (vel > 0.0f) ? vel * 0.85f : 0.8f;
        s_seq.orn_n = 1;
    }

    /*
     * РЕТЧЕТОВ НЕТ.
     *
     * Владелец их убрал: «ретчеты из баслиний надо убрать». Дробь звучала как заикание, а не
     * как толчок. Сбивка на последнем шаге цикла осталась — она держит замах в следующий круг,
     * и её владелец оставил.
     */
}

} // namespace

/* ------------------------------------------------------------------------- */
/* Public API                                                                 */
/* ------------------------------------------------------------------------- */

void synth_bass_init(uint32_t sample_rate)
{
    s_rate = (sample_rate > 0) ? sample_rate : SYNTH_SAMPLE_RATE;
    s_inv_rate = 1.0f / (float)s_rate;

    /* Шаг сглаживания ручек: 18 мс на управляющем шаге (6 кГц). */
    s_knob_glide = 1.0f - expf(-(float)CONTROL_STRIDE / (0.018f * (float)s_rate));
    s_punch_step = 1.0f - expf(-(float)CONTROL_STRIDE / (0.010f * (float)s_rate));
    memset(&s_voice, 0, sizeof s_voice);
    memset(&s_seq, 0, sizeof s_seq);
    s_seq.rng = 0x1F3D5B79u;
    /* Играет вместе со всем прибором, с первого такта после включения: у баса нет своей
     * кнопки, и ждать транспорта ему нечего. */
    s_seq.playing = true;
    s_seq.bar_shift = 0;

    for (int i = 0; i < P_COUNT; i++) {
        s_params[i] = 0.5f;
    }
    /* The page's defaults, before the app's patch overwrites them: a plain round kit, the
     * first pattern, whole-bar length, gate half open, no slide, a little accent. */
    s_params[P_KIT] = 0.0f;
    s_params[P_SNAP] = 0.35f;
    s_params[P_NOTE] = 0.5f;      /* смена ноты на месте: индекс 7 из 0..14 */
    s_params[P_DECAY] = 0.4f;
    s_params[P_SUB] = 0.0f;      /* саба нет, пока его не попросили */
    s_params[P_RES] = 0.5f;       /* резонанс ровно на месте заготовки */
    s_params[P_PAT] = 0.0f;
    s_params[P_VAR] = 0.0f;      /* ноль: линия ровная, вариаций нет */
    s_params[P_LEN] = 1.0f;
    s_params[P_GATE] = 0.5f;
    s_params[P_SLIDE] = 0.15f;
    s_params[P_ACCENT] = 0.25f;
    s_kit_cur = 0;
    s_pat_cur = 0;
    s_env_pub = 0.0f;
}

void synth_bass_set(int id, float value01)
{
    if (id < 0 || id >= P_COUNT) {
        return;
    }
    if (value01 < 0.0f) {
        value01 = 0.0f;
    } else if (value01 > 1.0f) {
        value01 = 1.0f;
    }
    s_params[id] = value01;

    if (id == P_KIT) {
        s_kit_cur = (int)floorf(value01 * 29.0f + 0.5f);
    }

}

float synth_bass_get(int id)
{
    if (id < 0 || id >= P_COUNT) {
        return 0.0f;
    }
    return s_params[id];
}

void synth_bass_set_tempo(float bpm)
{
    s_bpm = (bpm < 20.0f) ? 20.0f : ((bpm > 300.0f) ? 300.0f : bpm);
}

void synth_bass_set_root_hz(float hz)
{
    if (hz < 20.0f) {
        hz = 20.0f;
    } else if (hz > 200.0f) {
        hz = 200.0f;
    }
    s_root_hz = hz;
}

/* Акценты приходят маской: приложение собирает её из своей таблицы фигур. */
void synth_bass_set_scale_mask(uint16_t mask)
{
    s_scale_mask = (uint16_t)(mask & 0x0FFFu);

    if (s_scale_mask == 0u) {
        s_scale_mask = 0x0FFFu;
    }
}

void synth_bass_set_accent_mask(uint16_t mask)
{
    s_accent_mask = mask;
}

void synth_bass_set_swing(float frac)
{
    if (frac < 0.0f) {
        frac = 0.0f;
    }
    if (frac > 1.0f) {
        frac = 1.0f;
    }

    s_seq.swing = frac;
}

void synth_bass_sync_phase(int running, float phase01)
{
    if (phase01 < 0.0f) {
        phase01 = 0.0f;
    } else if (phase01 >= 1.0f) {
        phase01 = 1.0f - 1.0e-6f;
    }

    s_ext_phase = phase01;
    s_ext_running = (running != 0);
    s_ext_seen = true;
}

/*
 * ПУСК С ПЕРВОГО ШАГА.
 *
 * Бас подтягивает свой шаг к доле такта прибора по кратчайшему пути, и это правильно, пока
 * время идёт вперёд. Но перезапуск — это скачок назад, а скачок ровно на половину такта для
 * такой подтяжки неотличим от «стоять на месте»: бас спокойно продолжил бы с середины, и
 * первая доля нового такта осталась бы без ноты. Поэтому кнопка транспорта ставит счётчик
 * здесь, явно, а не надеется на сравнение долей.
 *
 * Звучащая нота не снимается: у неё есть своя длина, как у лида, и обрывать её на пуске —
 * это щелчок в начале каждого такта. Нулевой шаг всё равно перезапустит голос в ближайшем
 * блоке (см. ветку started в synth_bass_block).
 */
void synth_bass_restart(void)
{
    s_seq.started = false;
    s_seq.step = 0;
    s_seq.step_ph = 0.0f;
    s_seq.pending = 0;
    s_seq.orn_i = 0;
    s_seq.orn_n = 0;
    s_seq.cycle = 0;
}

void synth_bass_set_playing(bool on)
{
    if (on && !s_seq.playing) {
        s_seq.started = false;
    s_seq.pending = 0;
        s_seq.step = 0;
        s_seq.step_ph = 0.0f;
        s_seq.len = 16;
    }
    s_seq.playing = on;

    if (!on) {
        s_voice.on = false;
        s_voice.amp = 0.0f;
        s_voice.vca_run = 0.0f;
        s_voice.vca_inc = 0.0f;
        s_voice.stage = ST_OFF;
        s_voice.gate_left = 0;
    }
}

float synth_bass_env()
{
    return s_env_pub;
}

int synth_bass_kit(void)
{
    return s_kit_cur;
}

int synth_bass_pattern(void)
{
    return s_pat_cur;
}

/*
 * ЧТО РИСУЕТ КОЛЬЦО НА СТРАНИЦЕ RHYTHM.
 *
 * Те же четыре вопроса, что задают лид и ударка своим рисункам: где сейчас шаг, сколько шагов в
 * цикле, есть ли нота на этом шаге и акцент ли он. Отвечает сам модуль, потому что рисунок и
 * акценты — его состояние: кольцо, считающее их заново, могло бы нарисовать не то, что играется.
 */
int synth_bass_step(void)
{
    return (int)s_seq.step;
}

int synth_bass_steps(void)
{
    return (s_seq.len > 0) ? (int)s_seq.len : 16;
}

int synth_bass_is_onset(int position)
{
    if (position < 0 || position >= synth_bass_steps()) {
        return 0;
    }
    return (pattern_semitone(s_pat_cur, position) >= 0) ? 1 : 0;
}

/*
 * ЧТО СТОИТ НА ФИЛЬТРЕ, ДЛЯ ЭКРАНА.
 *
 * Срез уже считается движком (cutoff_hz) — он зависит и от заготовки, и от ручки TONE, поэтому
 * второго такого же расчёта в интерфейсе быть не должно: он бы разошёлся с тем, что слышно.
 * Добротность считается из того же резонанса, которым живёт SVF: q там коэффициент затухания,
 * а добротность — обратная ему.
 */
float synth_bass_cutoff_hz(void)
{
    return cutoff_hz();
}

float synth_bass_q(void)
{
    const Kit &k = KITS[s_kit_cur < 0 ? 0 : s_kit_cur];
    /* Резонанс — тоже только из заготовки; см. cutoff_hz(). */
    float res = (float)k.res * (1.0f / 255.0f);

    if (!(res >= 0.0f)) { res = 0.0f; }
    if (res > 0.95f)   { res = 0.95f; }

    float q = (2.0f - 1.9f * res) * s_voice.acc_res;
    if (!(q > 0.12f)) { q = 0.12f; }

    return 1.0f / q;
}

/* Подпись рисунка: номер, маска акцентов и длина цикла в одном числе. Кольцу её довольно,
 * чтобы понять, что рисунок сменился, не спрашивая шестнадцать шагов по одному. */
int synth_bass_figure(void)
{
    return ((int)s_pat_cur << 16) ^ ((int)s_accent_mask << 4) ^ (int)synth_bass_steps();
}

int synth_bass_is_accent(int position)
{
    if (position < 0 || position >= synth_bass_steps()) {
        return 0;
    }
    return ((s_accent_mask >> (position & 15)) & 1u) != 0u ? 1 : 0;
}

/*
 * One block: the clock, the notes in it, and the voice that plays them.
 *
 * The block is walked sample by sample with the step boundary inside the loop, because a
 * sequencer that quantises to the block would put every note 5.3 ms away from the beat and
 * the bass is the one part where that is audible against the drums.
 */
/*
 * Один блок: часы, ноты в нём и голос, который их играет.
 *
 * Блок идёт по сэмплам, а граница шага берётся внутри цикла: секвенсор, который
 * квантует по блоку, ставит каждую ноту на 5.3 мс от доли, а бас — единственная часть,
 * где это слышно против ударных.
 *
 * ЦЕНА СЭМПЛА: фаза, polyBLEP (две ветки у разрыва), фильтр из двух полюсов, умножение на
 * огибающую, один ограничитель. Ни одного деления, ни одного экспонента в этом пути —
 * огибающие, срез и коэффициент фильтра идут на управляющей частоте, раз в восемь сэмплов.
 */
void synth_bass_block(int samples)
{
    if (samples <= 0) {
        return;
    }
    if (samples > SYNTH_BLOCK_SAMPLES) {
        samples = SYNTH_BLOCK_SAMPLES;
    }

    float *l = synth_layer_l(SYNTH_LAYER_BASS);
    float *r = synth_layer_r(SYNTH_LAYER_BASS);

    const float bps = s_bpm / 60.0f;                          /* beats per second */
    const float step_samples = (float)s_rate / (bps * 4.0f);   /* a sixteenth */
    const Kit &k = KITS[(s_kit_cur < 0) ? 0 : s_kit_cur];

    /*
     * РЕЗОНАНС: ЗАГОТОВКА СВОИМ, РУЧКА СВОИМ.
     *
     * Поле заготовки задаёт её собственный характер, ручка сдвигает его на семь десятых в обе
     * стороны — на чистой заготовке даёт кислоту, на злой уводит в свист. Потолок 0.95, а не
     * единица: на единице добротность уходит в бесконечность, и фильтр начинает звенеть сам,
     * не спрашивая ноты.
     */
    /* Резонанс — тоже только из заготовки; см. cutoff_hz(). */
    float res = (float)k.res * (1.0f / 255.0f);

    if (!(res >= 0.0f)) { res = 0.0f; }
    if (res > 0.95f)   { res = 0.95f; }

    const bool  square = k.wave >= 128;
    /* Срез пересчитывается на каждом управляющем шаге из сглаженной ручки: за блок ручка
     * успевает пройти часть пути, и один пересчёт на блок дал бы тот же шаг, от которого
     * уходим. */
    float base_hz = cutoff_hz();

    float hz_now = s_voice.hz;
    float vca_now = 0.0f;

    /* Коэффициенты фильтра и шаг фазы меняются на управляющем шаге, а нужны на каждом
     * сэмпле: держим их в регистрах блока и возвращаем в голос один раз, в конце. */
    float f_coef = s_voice.f;
    float q_coef = s_voice.q;
    float g3 = (f_coef * 2.0f) / (1.0f + f_coef);
    float dt_step = hz_now * s_inv_rate;
    float inv_dt = (dt_step > 0.0f) ? (1.0f / dt_step) : 0.0f;

    /*
     * ШАГ СТАВИТСЯ НА ГРАНИЦУ БЛОКА, А НЕ НА СЭМПЛ ВНУТРИ НЕГО.
     *
     * Ударные во всём приборе отсчитываются в звуковом такте ударной машины: доля, дробная
     * к блоку, переносится между блоками, но удар бьёт в начале блока. Бас, который ставил
     * шаг по сэмплу, был точнее и поэтому не совпадал с ударной — расхождение до 5.3 мс, а
     * это на шестнадцатой при 120 ровно четыре процента шага: бочка и бас мазали друг о
     * друга. Та же сетка, что у ударной, и есть «ровно».
     */
    /*
     * ПЕРВЫЙ ШАГ БЬЁТ СРАЗУ, В БЛОКЕ ПУСКА, — и ударная теперь тоже: её копитель ждал
     * полной шестнадцатой, и барабан всегда шёл на шаг позади линии. У обоих нулевой шаг
     * стоит на одном блоке, поэтому счёт у них один.
     */
    if (s_seq.playing && !s_seq.started) {
        s_seq.started = true;
        s_seq.step = 0;
        s_seq.step_ph = 0.0f;
        s_seq.len = 16;
        s_seq.pending = 0;
        run_step();
    }
    else if (s_seq.playing) {
        /*
         * Качка не своя: она приходит из ударных и откладывает нечётный шаг на столько же
         * блоков, на сколько его откладывает барабан. Та же дробь, тот же расчёт в блоках —
         * поэтому шаги совпадают до блока, а не «примерно».
         */
        if (s_seq.pending > 0) {
            s_seq.pending--;
            if (s_seq.pending == 0) {
                run_step();
            }
        }

        /*
         * ЧАСЫ ЧУЖИЕ, ШАГ СВОЙ.
         *
         * Прибор говорит, где он сейчас: доля такта в долях единицы и идёт ли время. Бас
         * держит свой шаг, но подтягивает его к этой доле — иначе два маятника (такт в целых
         * блоках у перкуссии и шестнадцатая в сэмплах у баса) расходятся такт за тактом.
         *
         * Мелкое расхождение выбирается плавно, по пятой части за блок: это меньше двух
         * миллисекунд на шестнадцатой и на слух не читается как сдвиг. Крупное — после
         * остановки, смены темпа, включения — ставится сразу, иначе бас полз бы к сетке
         * секунду. Ноль берётся по модулю длины цикла: у баса свой размер, у прибора шестнадцать.
         */
        if (s_ext_seen && !s_ext_running) {
            /* Транспорт стоит: шаг не идёт, голос отпускается, как у остальных частей. */
            s_voice.on = false;
            s_voice.amp = 0.0f;
            s_voice.stage = ST_OFF;
            s_voice.gate_left = 0;
            s_seq.pending = 0;
        } else {
            if (s_ext_seen) {
                const float len_f = (float)s_seq.len;
                const float target = fmodf(s_ext_phase * 16.0f, len_f);
                const float cur = (float)s_seq.step + s_seq.step_ph;
                float err = target - cur;
                const float half = len_f * 0.5f;

                if (err > half) {
                    err -= len_f;
                } else if (err < -half) {
                    err += len_f;
                }

                if (err > 0.5f || err < -0.5f) {
                    /* Крупное расхождение: ставим на сетку сразу. */
                    s_seq.step = (int)target % s_seq.len;
                    s_seq.step_ph = target - (float)s_seq.step;
                    s_seq.pending = 0;
                } else {
                    s_seq.step_ph += err * 0.2f;
                }
            }

            s_seq.step_ph += (float)samples / step_samples;
            service_ornaments();

            const float step_blocks = step_samples / (float)samples;
            const int   swing_blocks = (int)(s_seq.swing * 0.5f * step_blocks + 0.5f);

            while (s_seq.step_ph >= 1.0f) {
                s_seq.step_ph -= 1.0f;
                s_seq.step = (s_seq.step + 1) % s_seq.len;

                if (s_seq.step == 0) {
                    s_seq.cycle++;
                }

                if ((s_seq.step & 1) && swing_blocks > 0 && s_seq.pending == 0) {
                    s_seq.pending = swing_blocks;
                } else {
                    run_step();
                }
            }
        }
    }

    for (int i = 0; i < samples; i++) {
        if (!s_voice.on) {
            l[i] = 0.0f;
            r[i] = 0.0f;
            continue;
        }

        /*
         * Управляющий шаг: раз в восемь сэмплов. Огибающие, срез, коэффициент и глиссандо —
         * то, что не обязано быть посепмпльным.
         */
        if ((i & (CONTROL_STRIDE - 1)) == 0) {
            /*
             * Ручки, которые слышны поверх живой ноты, ведут, а не шагают. Считается здесь,
             * до того как срез и привод прочитаны ниже в этом же управляющем шаге.
             */
            /* Ручки среза и резонанса убраны: и то и другое живёт в заготовке и меняется
             * только вместе с ней, а это событие, а не глайд. */

            if (s_voice.gate_left > 0 && --s_voice.gate_left == 0) {
                s_voice.gate_done = true;
            }

            /* Панч: ноль через десять миллисекунд после удара, один однополюсник на шаг. */
            s_voice.punch += (0.0f - s_voice.punch) * s_punch_step;

            if (s_voice.att < 1.0f) {
                s_voice.att += s_voice.att_step;
                if (s_voice.att > 1.0f) {
                    s_voice.att = 1.0f;
                }
            } else if (s_voice.att > 1.0f) {
                /* Новая нота тише прошлого уровня: заслонка ведёт вниз наклоном, а не
                 * прыгает. Это и есть лечение ступеньки. */
                s_voice.att -= s_voice.att_fall;
                if (s_voice.att < 1.0f) {
                    s_voice.att = 1.0f;
                }
            }

            if (!s_voice.gate_done) {
                s_voice.dec_env *= s_voice.dec_step;
                if (s_voice.dec_env < 0.0005f) {
                    s_voice.dec_env = 0.0f;
                }
            } else {
                s_voice.rel *= s_voice.rel_step;

                if (s_voice.rel < 0.0008f) {
                    s_voice.rel = 0.0f;
                    s_voice.on = false;
                    s_voice.stage = ST_OFF;
                    s_voice.amp = 0.0f;
                    s_voice.lp = 0.0f;
                    s_voice.bp = 0.0f;
                    l[i] = 0.0f;
                    r[i] = 0.0f;
                    continue;
                }
            }

            /* Всход огибающей фильтра: срез открывается за три миллисекунды вместе с заслонкой. */
            if (s_voice.fenv < 1.0f) {
                s_voice.fenv += s_voice.fenv_up;

                if (s_voice.fenv > 1.0f) {
                    s_voice.fenv = 1.0f;
                }
            }

            s_voice.fenv *= s_voice.fenv_step;
            if (!(s_voice.fenv > 0.002f)) {
                s_voice.fenv = 0.0f;
            } else if (s_voice.fenv > 1.0f) {
                s_voice.fenv = 1.0f;
            }

            vca_now = s_voice.peak * s_voice.att
                    * (s_voice.sus + (1.0f - s_voice.sus) * s_voice.dec_env)
                    * s_voice.rel;

            /*
             * НАКЛОН, А НЕ СТУПЕНЬКА.
             *
             * Уровень считается раз в восемь сэмплов. Если держать его до следующего шага,
             * атака идёт лестницей, и её ступени слышны высоким призвуком на начале ноты.
             * Между шагами заслонка ведёт наклоном: одно сложение на сэмпл.
             */
            s_voice.vca_inc = (vca_now - s_voice.vca_run) * (1.0f / (float)CONTROL_STRIDE);
            s_voice.amp = vca_now;

            /* Высота: глиссандо связки и бросок удара. */
            s_voice.hz += (s_voice.hz_target - s_voice.hz) * s_voice.glide;
            hz_now = s_voice.hz * (1.0f + s_voice.pitch_env * 0.05776f);   /* 2^(p/12), p мал */
            s_voice.pitch_env *= s_voice.pitch_step;

            if (s_voice.pitch_env < 0.005f) {
                s_voice.pitch_env = 0.0f;
            }

            /*
             * Коэффициенты фильтра: f = 2*sin(pi*fc/sr), q = 2 - 1.6*res. Оба зажаты так,
             * чтобы схема оставалась устойчивой при любом положении ручек: f не выше 0.9,
             * q не ниже 0.3. Состояние-переменная в прямой форме устойчива при f <= 1.
             */
            /*
             * Срез пересчитывается через один управляющий шаг. Огибающая фильтра ползёт
             * экспонентой с постоянной в десятки миллисекунд, восьми сэмплов разрешения ей
             * хватало с запасом — шестнадцати тоже: разница на слух нулевая, а fast_exp2 и
             * полином синуса уходят вдвое реже. Между пересчётами остаются прежние f и q.
             */
            s_voice.cut_tick ^= 1u;

            if (s_voice.cut_tick == 0u) {
            base_hz = cutoff_hz();

            float fc = base_hz * fast_exp2(s_voice.fenv * s_voice.fenv_semis * (1.0f / 12.0f));

            /*
             * ГРАНИЦЫ ЗАЖИМАЮТ ПО ОТДЕЛЬНОСТИ.
             *
             * Здесь стояло «не в диапазоне — значит двадцать герц», и это было безобидно,
             * пока срез ходил на октаву с четвертью: до верхней границы он не доставал.
             * С размахом в пять октав яркая заготовка на верху TONE даёт одиннадцать
             * килогерц, и прежний зажим превращал верх ручки в глухой удар — ровно
             * наоборот задуманному.
             */
            const float fc_top = 0.20f * (float)s_rate;

            if (!(fc >= 20.0f)) {
                fc = 20.0f;
            } else if (fc > fc_top) {
                fc = fc_top;
            }

            const float x = 3.14159265f * fc * s_inv_rate;
            float f_tgt = 2.0f * (x - x * x * x * 0.1667f);   /* 2*sin(x), рядом с нулём */

            if (f_tgt > 0.9f) {
                f_tgt = 0.9f;
            }

            /*
             * Срез подходит к цели за четыре управляющих шага (0.7 мс), а не прыжком.
             * Прыжок коэффициента при живом состоянии фильтра — это ступенька на выходе:
             * на каждой атаке, где огибающая фильтра сбрасывается в единицу, слышен щелчок.
             * Четыре шага не слышны как свип и убирают ступеньку.
             */
            s_voice.f += (f_tgt - s_voice.f) * 0.25f;

            /*
             * ЗАТУХАНИЕ НЕ НИЖЕ КОЭФФИЦИЕНТА — ЭТО И ЕСТЬ УСТОЙЧИВОСТЬ СХЕМЫ.
             *
             * У этой схемы резонанс живёт, пока затухание q больше шага f; как только q
             * уходит ниже, полюса выходят из круга и фильтр за пару сэмплов разгоняется
             * до упора. На кислотных заготовках резонанс 200..250 по полю — это q 0.43 —
             * и срез, открытый огибающей на двадцать шесть полутонов, поднимал f до 0.45:
             * звон переходил в ступеньку на выходе и в тот самый щелчок. Зажим держит q
             * чуть выше f, поэтому резонанс наверху ослабляется сам, а не срывается.
             */
            /*
             * РЕЗОНАНС ГЛУБЖЕ.
             *
             * Было 2 − 1.6·res с полом 0.3: на самом верху ручки фильтр звенел, но до
             * свиста не доходил. Стало 2 − 1.9·res с полом 0.12 — на верху это тот самый
             * кислотный звон. Срыва нет: ниже стоит зажим «q не ниже f + 0.10», он и держит
             * схему, ослабляя резонанс только там, где он иначе вышел бы из круга.
             */
            float q = (2.0f - 1.9f * res) * s_voice.acc_res;

            if (!(q > 0.12f)) {
                q = 0.12f;
            }

            /*
             * Затухание подходит к цели так же, как срез: четырьмя шагами. Прыжок
             * коэффициента при живом состоянии фильтра — ступенька на выходе, то есть
             * щелчок на каждой ноте, а с акцентом она ещё больше.
             */
            s_voice.q += (q - s_voice.q) * 0.25f;

            /* Граница устойчивости — уже после движения и на текущем срезе. */
            if (s_voice.q < s_voice.f + 0.10f) {
                s_voice.q = s_voice.f + 0.10f;
            }
            }

            f_coef = s_voice.f;
            q_coef = s_voice.q;

            /* Полюс третьего порядка: тот же срез, билинейная однополюсная форма. */
            g3 = (f_coef * 2.0f) / (1.0f + f_coef);

            dt_step = hz_now * s_inv_rate;
            inv_dt = (dt_step > 0.0f) ? (1.0f / dt_step) : 0.0f;
        }

        /* --- посепмпльно --- */

        s_voice.vca_run += s_voice.vca_inc;

        if (s_voice.vca_run < 0.0f) {
            s_voice.vca_run = 0.0f;
        }

        const float sub_amt = s_params[P_SUB];
        const float sub_hp = sub_hp_coef();

        s_voice.phase += dt_step;
        if (s_voice.phase >= 1.0f) {
            s_voice.phase -= 1.0f;
        }

        float x;

        if (square) {
            x = (s_voice.phase < 0.5f) ? 0.7f : -0.7f;

            float t2 = s_voice.phase + 0.5f;

            if (t2 >= 1.0f) {
                t2 -= 1.0f;
            }

            x -= poly_blep(s_voice.phase, dt_step, inv_dt);
            x += poly_blep(t2, dt_step, inv_dt);
        } else {
            x = 2.0f * s_voice.phase - 1.0f - poly_blep(s_voice.phase, dt_step, inv_dt);
        }

        /* Состояние-переменная: hp -> bp -> lp. Резонанс — это q в обратной связи; сам вход
         * фильтра считается ниже, уже после привода. */
        /*
         * ПРИВОД ДО ФИЛЬТРА.
         *
         * Осциллятор входит в фильтр уже искажённым — так устроен триста третий, и в этом
         * весь «квак»: резонанс выпячивает ту гармонику, которая попала в срез, а срез
         * ходит по гармоникам огибающей. После фильтра искажать нечего: там уже синусоида,
         * и получается не грязь, а сплющивание.
         *
         * Кривая u/(1+|u|) в нуле имеет наклон единицу: на малом приводе она прозрачна.
         * Сверху она ограничена единицей, поэтому фильтр никогда не получает горячий вход
         * и резонанс не раскачивается.
         */
        const float hp = x - s_voice.lp - q_coef * s_voice.bp;

        s_voice.bp += f_coef * hp;
        s_voice.lp += f_coef * s_voice.bp;

        /* Третий полюс: тот же срез, что у схемы, шестью децибелами круче. */
        s_voice.lp3 += g3 * (s_voice.lp - s_voice.lp3);
        x = s_voice.lp3;

        /*
         * САБ ПОСЛЕ ФИЛЬТРА И ДО ЗАСЛОНКИ.
         *
         * После фильтра — закрытый срез иначе съел бы весь саб, а вес нужен при любом
         * положении TONE. До заслонки — у него должна быть та же атака и тот же спад, что у
         * ноты: саб это часть ноты, а не подложка.
         *
         * Треугольник, а не синус: у него есть нечётные гармоники, и на слабых колонках,
         * которые двадцать семь герц не воспроизводят, вес всё равно слышен.
         */
        if (sub_amt > 0.0f) {
            s_voice.sub_ph += dt_step * 0.5f;

            if (s_voice.sub_ph >= 1.0f) {
                s_voice.sub_ph -= 1.0f;
            }

            const float tri = 4.0f * fabsf(s_voice.sub_ph - 0.5f) - 1.0f;

            s_voice.sub_lp += sub_hp * (tri - s_voice.sub_lp);
            /*
             * САБ ГРОМЧЕ: 2.0 — это +4.5 дБ к полосе 20..60 Гц при ручке SUB на максимуме, и
             * пик голоса при этом остаётся 0.886 на самой густой заготовке (ROLLGHOST): выше
             * колена ограничителя, но колено гладкое, и это сжатие, а не ступенька. Множитель
             * стоит на самом сабе, а не на голосе целиком, поэтому край ноты и середина не
             * меняются. Замер: полосы 60..120 и выше при SUB = 1 в пределах 0.6 дБ от прежних.
             */
            x += (tri - s_voice.sub_lp) * sub_amt * 2.6f;
        }

        /*
         * ГОЛОС В УРОВЕНЬ ОСТАЛЬНЫХ ЧАСТЕЙ, С ЗАПАСОМ ДО ОГРАНИЧИТЕЛЯ.
         *
         * При 0.95 пик голоса на живых патчах упирался в колено ограничителя каждый такт:
         * слой шёл плоским сверху, уровень дышал на каждой ноте, и микс «прыгал» вместе с
         * ним — это не перегрузка, а работа ограничителя, который не отпускает. 0.55
         * оставляет пик в 0.5 и сажает звук в шкалу наполовину; громкость раздела берётся
         * ручкой BASS на LEVELS, а не запасом в голосе.
         */
        /* Глубокий резонанс поднимает пик: убираем до 1.4 дБ на самом верху ручки. */
        /*
         * Панч в уровень: край ноты на 1.2 дБ выше тела, тело на столько же тише — средняя
         * громкость не растёт, а удар читается в миксе.
         */
        /*
         * КОМПЕНСАЦИЯ САБА УБРАНА, ГОЛОС ЧУТЬ ТИШЕ.
         *
         * Здесь стояло (1 - 0.12*sub): чем больше саба просили, тем сильнее давился весь голос,
         * то есть ручка SUB работала сама против себя. Владелец: «саб плохо слышно из-за
         * кривых равной громкости». Теперь саб поднимается (2.6 вместо 2.0), компенсации нет,
         * а голос в шкалу идёт 0.40 вместо 0.43 — пик остаётся прежним, но низ в нём весит
         * больше, а гармоник меньше.
         */
        x *= s_voice.vca_run * (0.98f + 0.13f * s_voice.punch) * 0.40f * (1.0f - 0.16f * res);

        /*
         * ОГРАНИЧИТЕЛЬ С ГЛАДКИМ КОЛЕНОМ, А НЕ С ПОРОГОМ.
         *
         * Было так: пока |x| не больше 0.8 — пропускаем как есть, а как только больше —
         * отдаём x/(1+|x|). В точке 0.8 первое даёт 0.8, второе 0.444: разрыв в треть
         * шкалы на одном сэмпле. Это и был щелчок на громких заготовках и на приводах:
         * не перегрузка, а ступенька ограничителя. Здесь кривая сходится с линейной по
         * значению и по наклону (0.8 + 0.2*over/(1+over), over = (|x|-0.8)/0.2), сверху
         * упирается в единицу и стоит одну ветку и одно деление в редком сэмпле.
         */
        if (x > BASS_LIMIT_KNEE || x < -BASS_LIMIT_KNEE) {
            const float ax_out = (x < 0.0f) ? -x : x;
            const float over = (ax_out - BASS_LIMIT_KNEE) * BASS_LIMIT_SLOPE;
            const float y = BASS_LIMIT_KNEE + (1.0f - BASS_LIMIT_KNEE) * (over / (1.0f + over));

            x = (x < 0.0f) ? -y : y;
        }

        l[i] = x;
        r[i] = x;

    }

    s_voice.f = f_coef;
    s_voice.q = q_coef;

    s_env_pub = s_voice.amp;
}
