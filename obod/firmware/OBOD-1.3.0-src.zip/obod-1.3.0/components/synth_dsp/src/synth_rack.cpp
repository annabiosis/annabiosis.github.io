#include "esp_attr.h"
#include "synth_dsp.h"

/*
 * Есть ли под нами FreeRTOS. На стенде хоста его нет, и там весь конвейер сводится к прежнему
 * последовательному вызову: проверяется то же самое, только на одном потоке.
 */
#if defined(ESP_PLATFORM) && defined(__has_include)
#if __has_include("freertos/semphr.h")
#define RACK_FX_TASK 0   /* выключен: повтор блока при застрявшей задаче слышен гулом */
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#endif
#endif

#ifndef RACK_FX_TASK
#define RACK_FX_TASK 0
#endif

#include <string.h>
#include "synth_dsp_private.h"
#include "synth_stage_timing.h"

#include "esp_heap_caps.h"
#include "esp_log.h"
#include "esp_timer.h"

#if STAGE_TIMING
#include "esp_cpu.h"
#endif

#include <math.h>

/*
 * The stereo rack: the only genuinely two-channel thing in the signal path.
 *
 * Everything the engine produces is mono. It is panned and captured per layer
 * before it gets here, so by the time the layers arrive they are two channels of
 * float, and this is where they are summed, treated and limited.
 *
 *   layers -> sum -> chorus -> delay -> + reverb -> soft clip -> DAC
 *   perc   ->  ^       ^                  ^
 *                      |                  |
 *                   dry sum        per-layer send bus
 *
 * The percussion joins at the sum, after the layers, because it is not an engine
 * bus: it has no layer to be captured from, and one voice with one level and one
 * send wants no more than that. It goes through the chorus and the delay with
 * everything else, which is what those two being in the chain rather than on sends
 * means.
 *
 * The reverb hangs off a send rather than sitting in the chain because it is the
 * one effect that invents a space, and because a send is the only way to let the
 * lead be wet while the drone stays dry. The chorus and the delay sit in the
 * chain because both are parallel-by-design already: each has a mix control, so
 * the dry signal passes through them untouched at any setting.
 *
 * The scratch this needs is claimed on first use, not at boot: see the note in
 * claim_scratch(). Until then the rack takes the dry path below, which is what
 * the instrument does with every effect switched off anyway.
 */

/* The master's waveform, double-buffered: the writer fills the back and flips the front. */
static float s_scope[2][SYNTH_SCOPE_POINTS];
static volatile int s_scope_front;

namespace {

constexpr const char *TAG = "rack";



float s_layer_level[SYNTH_NUM_LAYERS];
float s_send_rev[SYNTH_NUM_LAYERS];
float s_send_chr[SYNTH_NUM_LAYERS];
float s_send_dly[SYNTH_NUM_LAYERS];

/*
 * The same nine numbers again, but as the values the block is actually using.
 *
 * A knob is a staircase of detents. A level that follows it directly is therefore a staircase
 * in amplitude, and a staircase in amplitude is a click at every step: on a dense patch it is
 * heard as noise laid over the sound for as long as the hand keeps moving, and it is exactly
 * what a fader must not do. Each of these walks to its target on every sample with the same
 * one-pole as the master, so a detent becomes a 12 ms ramp instead of a step.
 *
 * The targets are the ones the setters write; these are the ones the sum reads. Nothing else
 * changes: a preset that arrives sets nine targets and is in force 12 ms later, which is
 * shorter than the block it would otherwise click in.
 */
float s_layer_level_cur[SYNTH_NUM_LAYERS];
float s_send_rev_cur[SYNTH_NUM_LAYERS];
float s_send_chr_cur[SYNTH_NUM_LAYERS];
float s_send_dly_cur[SYNTH_NUM_LAYERS];
float s_level_glide;        /* шаг однополюсника на отсчёт, 12 мс */
float s_perc_send_rev = 0.0f;
float s_perc_send_chr = 0.0f;
float s_perc_send_dly = 0.0f;

/* The duck: how far the drum pushes the drone's low end, and how far it has pushed it. */
float s_duck = 0.0f;

/*
 * САЙДЧЕЙН ПОСЫЛОВ.
 *
 * Сколько удара забирает у хвостов: при единице посыл закрывается на пике дакинга, при
 * нуле — не трогается вовсе. Отдельного сигнала не нужно: s_duck_smooth уже посчитан.
 */
float s_side = 0.0f;

/*
 * ПОЛОСА ДАКА: низ баса.
 *
 * Два однополюсных каскадом — двенадцать децибел на октаву. Шесть мало (середина лезет под
 * дак), двадцать четыре дорого, а двенадцати хватает, чтобы под множитель бочки ушло только
 * «тело», а не вся нота.
 */
static float s_sc_l[2];      /* левый канал: полюс первый и второй */
static float s_sc_r[2];
static float s_sc_k = 0.02f; /* срез 160 Гц при 48 кГц */

void synth_rack_set_band_rate(float rate)
{
    if (rate > 1000.0f) {
        s_sc_k = 1.0f - expf(-6.2831853f * 160.0f / rate);
    }
}
float s_duck_smooth = 0.0f;
float s_duck_rel = 0.35f;
float s_duck_makeup = 1.0f;      /* цель компенсации, медленная: 120 мс */
float s_duck_makeup_cur = 1.0f;  /* она же, ведомая за сэмпл: без ступенек на границе блока */
float s_duck_makeup_glide = 0.0f;/* однополюсник на сэмпл, 4 мс */  /* сколько уровня возвращается всему миксу за дакинг */   /* 0..1: отпускание дакинга, см. synth_rack_set_duck_rel() */
float s_duck_prev = 1.0f;    /* the gain the previous block finished on */

float s_master = 1.0f;

/*
 * The master gain, and the two numbers that make it a ramp rather than a write.
 *
 * LEVEL is a gain the player rides while the instrument is sounding — that is most
 * of what a LEVEL knob is for — and a gain that is written once per control tick is
 * a gain in steps of whatever the knob's resolution is. At 15 ms the pole is slow
 * enough to be silent on the way and fast enough that the knob is still the knob: a
 * step of a tenth is within a thousandth of its destination after four and a half
 * time constants, which is 68 ms, and the value lands on the knob's own number
 * rather than a few ulp short of it, because `l * 1.0f` returning `l` unchanged is
 * the promise every control on this instrument is built around.
 */
constexpr float MASTER_GLIDE_MS = 15.0f;
float s_master_cur = 1.0f;
float s_master_glide = 0.0f;

/*
 * THE BOOT FADE, and the three numbers that make it one.
 *
 * The instrument used to make its first sound in the first block after the audio task
 * started — which is before the screens are built, before the settings and the presets
 * have been read, and while the flash is busy. On a reboot that is heard as stutter, and
 * none of it is the instrument. The output is therefore held at exactly zero until
 * main() has finished bringing everything up, then released over a measured ramp.
 *
 * 150 ms first, so the last burst of boot work is behind us before anything is heard;
 * then 700 ms of linear amplitude. Linear and not logarithmic: at this length a log ramp
 * jumps away from zero and then crawls, which is audibly a swell rather than a fade.
 *
 * THE GAIN IS A MULTIPLIER ON THE MASTER, not on the layers. The layers are summed and
 * scaled by their own faders before the rack, so a factor there would have to be applied
 * to every part and would depend on how many of them are sounding; here it is one number
 * on the one gain every sample already passes through, and the balance between the parts
 * is untouched. At 1.0 it is exactly a multiply by one, so the settled output is
 * bit-for-bit the output this rack made before the fade existed.
 *
 * It lives on the audio side and is counted in SAMPLES, not milliseconds: the audio task
 * cannot read a wall clock without another dependency on esp_timer, and a block is not
 * a fixed slice of its own timeline anyway. The arm flag is written by the application
 * task and read here; one aligned word, no lock, and no data travels with it.
 */
constexpr float BOOT_FADE_DELAY_MS = SYNTH_BOOT_FADE_DELAY_MS;
constexpr float BOOT_FADE_MS       = SYNTH_BOOT_FADE_MS;
constexpr uint32_t BOOT_FADE_DELAY_SAMPLES =
    (uint32_t)((float)SYNTH_SAMPLE_RATE * (BOOT_FADE_DELAY_MS / 1000.0f));
constexpr uint32_t BOOT_FADE_SAMPLES =
    (uint32_t)((float)SYNTH_SAMPLE_RATE * (BOOT_FADE_MS / 1000.0f));

volatile uint32_t s_boot_arm_request;   /* 1 once main() has finished the boot */
bool     s_boot_armed;
bool     s_boot_done;                   /* the fade has arrived at exactly 1.0 */
uint32_t s_boot_samples;                /* samples rendered since the arm */
uint32_t s_boot_block_base;             /* sample index of this block's first sample */

/* The gain at sample `t` after the arm: zero, then a straight line, then exactly one. */
IRAM_ATTR inline float boot_gain_at(uint32_t t)
{
    if (t < BOOT_FADE_DELAY_SAMPLES) {
        return 0.0f;
    }

    const uint32_t f = t - BOOT_FADE_DELAY_SAMPLES;
    if (f >= BOOT_FADE_SAMPLES) {
        return 1.0f;
    }

    /* A constant reciprocal, so the per-sample cost is one multiply and no divide. */
    return (float)f * (1.0f / (float)BOOT_FADE_SAMPLES);
}

/*
 * One block's worth of the boot clock, at the top of the block and before any of it is
 * rendered. The block that spans the end of the delay or the end of the fade is the
 * reason the gain is worked out per sample in the loops below rather than interpolated
 * from two block-boundary values: 256 samples do not divide either boundary.
 */
inline void boot_gate_prepare(int samples)
{
    if (!s_boot_armed && s_boot_arm_request != 0u) {
        s_boot_armed = true;
        s_boot_done = false;
        s_boot_samples = 0;
    }

    s_boot_block_base = s_boot_armed ? s_boot_samples : 0u;

    if (s_boot_armed) {
        s_boot_samples += (uint32_t)(unsigned)samples;
        s_boot_done = (s_boot_samples >= BOOT_FADE_DELAY_SAMPLES + BOOT_FADE_SAMPLES);
    }
}

IRAM_ATTR inline float boot_gain_sample(int i)
{
    /* Per sample, not per block: the block that spans 40800 contains samples on both
     * sides of the end of the ramp, and it must finish the straight line rather than
     * jump to one when the block's total crosses the mark. boot_gain_at() is already
     * exactly 1 at and after the last sample, so no branch on s_boot_done is needed
     * here; that flag is for the watchdog and the telemetry. */
    return boot_gain_at(s_boot_block_base + (uint32_t)(unsigned)i);
}

/* The balances, ramped for the same reason the master gain is: each one is a gain on the dry
 * and on the effect's own answer at once, so a jump in it is a step in both directions. The
 * reverb's is applied here rather than inside the effect; the chorus's and the delay's scale
 * what those two ADDED to the reverb's send bus, which is why a step in either of them is
 * heard only when the reverb is being listened to — the room carries it, the dry path does not.
 */
constexpr float MIX_GLIDE_MS = 15.0f;
float s_reverb_mix_cur = 0.0f;
float s_reverb_mix_glide = 0.0f;
float s_chorus_mix_cur = 0.0f;
float s_chorus_mix_glide = 0.0f;
float s_delay_mix_cur = 0.0f;
float s_delay_mix_glide = 0.0f;

/*
 * The master compressor. The numbers and the reasoning are in the note on
 * synth_rack_set_comp() in the header; this is the state that carries them.
 *
 * s_comp_on is the whole of the cost. At the bottom of the knob's travel the stage is
 * jumped over rather than computed with neutral numbers, so an instrument that never
 * asks for compression pays one branch per sample and sounds exactly as it did before
 * the stage existed.
 */
constexpr float COMP_THRESH_DB   = -24.0f;  /* where the top of the travel puts the threshold */
constexpr float COMP_RATIO_MAX   = 8.0f;
constexpr float COMP_KNEE_DB     = 6.0f;
constexpr float COMP_ATTACK_MS   = 25.0f;
constexpr float COMP_RELEASE_MS  = 250.0f;
constexpr float COMP_SC_HP_HZ    = 150.0f;
constexpr float COMP_MAKEUP_FRAC = 0.5f;

/*
 * КОМПЕНСАЦИЯ ДАКИНГА.
 *
 * Дакинг вычитает уровень из всего, кроме удара, и это слышно как «стало тихо» — ровно то,
 * что владелец и сказал. Настоящий компрессор тут не спасает: он поднимает только то, что
 * ВЫШЕ порога, а придавленный микс как раз уходит под него, и тогда он не делает ничего.
 *
 * Поэтому у дакинга есть своя компенсация: чем глубже он вдавлен, тем больше усиления
 * возвращается всему миксу, включая удар. Возвращается не всё (иначе дакинг слышен только
 * как щелчок по остальным партиям, а не как освобождённое место под удар), а 60 %: микс
 * проседает заметно меньше, а дырка под бочкой остаётся.
 *
 * Компенсация стоит на мастере, ПОСЛЕ дакинга и после барабана, — то есть именно там, где
 * её и просили: она не может вернуть то, что ещё не вычтено.
 */
constexpr float DUCK_MAKEUP_FRAC = 0.6f;

/*
 * ПОТОЛОК КОМПЕНСАЦИИ И ЕЁ СОБСТВЕННАЯ СКОРОСТЬ.
 *
 * frac 0.6 при полной глубине даёт +1.7 дБ на весь микс, а микс тут же идёт в мягкий клиппер,
 * порог которого 0.8: замер стендом duck_probe дал 74 сэмпла выше порога на удар. Компенсация
 * ограничена половиной децибела — она возвращает часть снятого, но не поднимает микс выше того,
 * на чём он сведён. И ведёт её медленный однополюсник в 120 мс, чтобы она возвращала СРЕДНИЙ
 * уровень, а не качалась вместе с каждым ударом.
 */
constexpr float DUCK_MAKEUP_MAX = 1.06f;    /* +0.5 дБ */
constexpr float DUCK_MAKEUP_MS  = 120.0f;
constexpr float DUCK_MAKEUP_GLIDE_MS = 4.0f;

/*
 * ХОД РУЧКИ ДАКИНГА.
 *
 * Полезный диапазон оказался в первой трети: выше 25-30 % дакинг вместе с компенсацией уже
 * клипует, и остальные две трети хода не значат ничего, кроме «ещё хуже». Поэтому весь ход
 * ручки сжат до 30 % прежней глубины: положение, которое раньше читалось как 30 %, теперь
 * читается как 100 %, и весь ход стал рабочим.
 *
 * Масштаб стоит в сеттере, а не в ручке и не в раскладке: макрос, мод и патч передают то же
 * число, что и палец, и все они должны получить одну и ту же глубину.
 */
constexpr float DUCK_TRAVEL = 0.30f;
constexpr float COMP_DB_PER_OCT  = 6.020599913f;   /* 20 * log10(2) */

/*
 * HOW LONG THE GAIN TAKES TO ARRIVE WHERE THE KNOB PUT IT, in milliseconds, and
 * why the stage needs a number of its own.
 *
 * Everything on this knob that is heard as a level — the threshold, the ratio and
 * the makeup — is a TARGET here, and this one pole is what actually moves: the
 * gain in force walks to the curve's answer over 12 ms instead of being installed
 * between two samples. A gain that steps is a click, and on a drone held for
 * minutes a click on every detent of the knob is the loudest thing in the
 * instrument.
 *
 * 12 ms, inside the range a level control is usually given: long enough that the
 * step is spread over 576 samples and cannot be heard as a step at all, short
 * enough that the compression is where the knob says it is before the hand has
 * left it. The compressor's own attack is 25 ms, so this is faster than the
 * detector it feeds and does not colour the timing of the stage.
 *
 * The same pole does a second job for nothing. COMP_GAIN_EVERY evaluates the curve
 * at 3 kHz, so the gain the curve asks for arrives as a staircase, and this walks
 * across the treads. Those two jobs used to be one: the gain was interpolated
 * across the sixteen samples to the next curve, which is 0.33 ms end to end — the
 * difference between a glide and a step is exactly that number.
 */
constexpr float COMP_GAIN_GLIDE_MS = 12.0f;

/*
 * How often the static curve is evaluated, in samples. The ENVELOPE runs on every
 * sample; this is only the log-and-exponential part of the gain computer, and 16 puts it
 * at 3 kHz. See rack_out() for what that costs and why it had to change.
 */
constexpr int COMP_GAIN_EVERY = 16;

/*
 * THE GATE'S RAMP, and why the gate stopped being a switch.
 *
 * The gate is asked to open and close by things that happen between two samples — a note
 * arriving over USB MIDI while the transport is stopped, the STOP button itself — and a
 * switch throws the whole signal away in ONE sample. A step in the waveform is a click,
 * and on a drone that is held for minutes it is the loudest thing in the instrument. So
 * the gate is a gain that a one-pole walks between 0 and 1, one step per SAMPLE.
 *
 * WHY PER SAMPLE AND NOT PER BLOCK. At the block rate of 187.5 Hz, a 5 ms pole steps by a
 * third of its remaining distance per block, which is a gain jump of a third of the
 * signal — exactly the step the ramp exists to remove. The drone filter's smoother can
 * afford to run once per block because it moves a cutoff, which is a coefficient; this
 * one moves the sample itself. The coefficient is built the same way the lead filter's
 * is — 1 - exp(-dt/tau), computed once per block because only dt and tau go into it.
 *
 * THE TWO DIRECTIONS HAVE DIFFERENT TIME CONSTANTS, and that is the whole design of the
 * ramp rather than a detail of it:
 *
 *   OPENING is 1.5 ms, the lead filter smoother's own time constant and chosen there for
 *   the same job (rounding a corner without smearing what the corner leads to). It is
 *   short because WHAT OPENS THE GATE IS A NOTE, and the attack of that note IS the note:
 *   a drum struck with the gate shut — a channel-2 note with the transport stopped — has
 *   its attack rendered in the first block, and a 5 ms pole would still be at 41% of the
 *   way when the first block ended, which is a soft stick. A drum pattern played with
 *   STOP down is not an edge case, so the ramp cannot eat the hit.
 *
 *   CLOSING is 5 ms, 34 ms to within -60 dB. It is longer because WHAT IT CLOSES ON is
 *   usually the DRONE, which is continuous and low: a 55 Hz voice faded out in 1.5 ms is
 *   a thump. Nothing is waiting on the close — a note's own release has already finished
 *   by the time the tail that held the gate expires, and STOP is an instruction to be
 *   silent, not an instruction to be silent instantly.
 *
 * BOTH ENDS SNAP to exactly 0 and exactly 1. The first keeps the closed state
 * bit-exactly silent. The second keeps the open state bit-for-bit what it was before
 * this ramp existed, because multiplying a sample by 1.0f returns it unchanged — the
 * promise every control on this instrument is built around.
 */
constexpr float GATE_OPEN_TAU_S  = 0.0015f;
constexpr float GATE_CLOSE_TAU_S = 0.005f;
constexpr float GATE_FLOOR = 0.001f;   /* -60 dB: near enough to call it arrived */

/* One sample of that ramp, towards gate_target (0 or 1). */
IRAM_ATTR inline float gate_step(float g, float coef, float target)
{
    g += (target - g) * coef;

    if (target > 0.0f) {
        if (g > 1.0f - GATE_FLOOR) {
            g = 1.0f;
        }
    } else if (g < GATE_FLOOR) {
        g = 0.0f;
    }
    return g;
}

bool  s_comp_on = false;
float s_comp_slope = 0.0f;          /* 1 - 1/ratio */
float s_comp_thresh_db = 0.0f;
float s_comp_makeup_db = 0.0f;
float s_comp_att = 0.0f;            /* one-pole coefficients, 0..1 */
float s_comp_rel = 0.0f;
float s_comp_hp = 0.0f;
float s_comp_hp_xl = 0.0f, s_comp_hp_yl = 0.0f;   /* side-chain high-pass, one per channel */
float s_comp_hp_xr = 0.0f, s_comp_hp_yr = 0.0f;
float s_comp_env = 0.0f;            /* the linked envelope, linear */
float s_comp_gain = 1.0f;           /* the gain in force: what the samples are multiplied by */
float s_comp_gain_to = 1.0f;        /* what the curve last asked for; s_comp_gain walks to it */
float s_comp_glide = 0.0f;          /* per-sample one-pole coefficient of that walk */
int   s_comp_tick = 0;              /* samples until the next curve */

/*
 * Scratch for one block: nine blocks of 256 floats, 9 KB, in PSRAM.
 *
 * The dry pair, the reverb's mono send and its answer, and one stereo bus each for the
 * chorus and the delay. Three blocks more than when the two small effects worked in place
 * on the dry pair, and that is the point of the change: an effect that only ever sees its
 * own bus cannot alter the dry path at all, which is what makes its knob a return level
 * rather than a balance — see the chain in synth_rack_process.
 */
float *s_dry_l    = nullptr;
float *s_dry_r    = nullptr;
float *s_send_bus = nullptr;   /* the reverb's, mono */
float *s_wet_l    = nullptr;
float *s_wet_r    = nullptr;
float *s_chr_l    = nullptr;   /* the chorus's, stereo */
float *s_chr_r    = nullptr;
float *s_dly_l    = nullptr;   /* the delay's, stereo */
float *s_dly_r    = nullptr;

/*
 * НАБОР ХВОСТА. Те же девять буферов, но отдельные: первая половина блока складывает своё в
 * s_dry_*, s_send_bus, s_chr_*, s_dly_*, и на границе копирует результат сюда. Дальше хвост
 * трогает только этот набор, поэтому его можно считать на другом ядре, пока первая половина
 * складывает следующий блок в свой.
 *
 * Девять килобайт и одна копия на блок — около десяти микросекунд из пяти тысяч.
 */
struct FxBuffers {
    float dry_l[SYNTH_BLOCK_SAMPLES];
    float dry_r[SYNTH_BLOCK_SAMPLES];
    float send[SYNTH_BLOCK_SAMPLES];
    float chr_l[SYNTH_BLOCK_SAMPLES];
    float chr_r[SYNTH_BLOCK_SAMPLES];
    float dly_l[SYNTH_BLOCK_SAMPLES];
    float dly_r[SYNTH_BLOCK_SAMPLES];
    float wet_l[SYNTH_BLOCK_SAMPLES];
    float wet_r[SYNTH_BLOCK_SAMPLES];
};

static FxBuffers s_fx;

bool s_scratch = false;   /* the gate, set only once every pointer above is valid */
bool s_want_fx = false;   /* somebody has asked for an effect since boot */
bool s_gate    = true;    /* generators connected; what the transport and the input ASK for */
float s_gate_gain = 1.0f; /* that, through the ramp above: the number actually applied */

/*
 * THE FUSE'S OWN STATE. See rack_rescue().
 *
 * s_hold_l/r are the last output pair the instrument produced before something went bad.
 * They are what the rescue's own block is filled with: a block of the last good sample is a
 * flat spot two and a half milliseconds long and a step of one sample's difference at each
 * end, while a block of zeros is a full-scale step down and back up — a click at the exact
 * moment the instrument is trying to recover inaudibly.
 *
 * s_rescue_count is the number of rescues since boot. The line that reports one is built
 * here and printed by the statistics task: a UART wait among these blocks is longer than
 * a block, so the rescue pins the state and returns without touching the console.
 */
int16_t  s_hold_l;
int16_t  s_hold_r;
volatile uint32_t s_rescue_count;

/*
 * THE SILENCE WATCHDOG'S STATE.
 *
 * The transport and the drone's levels are settings the application and the knobs already
 * keep. `s_zero_samples` is how much audio the output has been exactly silent for, counted
 * in samples rather than blocks so a block that is not 128 long cannot skew the threshold.
 *
 * `s_watch_samples` is the clock the detector is armed on: the first four seconds after the
 * audio task starts are excluded, because that is where the effects claim their scratch,
 * the drone's 2.5 s attack rises from zero, and a block can legitimately be silent. It
 * counts samples, so it needs no timer and cannot be thrown by a block that ran long.
 *
 * The rest is the rescue trail: the two counters, the serial that tells the application a
 * rescue happened, and the pinned state the boot after a reset reads back.
 */
constexpr uint32_t SILENCE_ARM_S   = 4;   /* seconds of boot excluded from the watchdog */
constexpr uint32_t SILENCE_LIMIT_S = 1;   /* how long the output may be exactly zero */

volatile uint32_t s_transport;      /* the transport as the application sees it */
uint64_t s_watch_samples;           /* samples rendered since the first block */
uint32_t s_zero_samples;            /* consecutive samples of exact silence */
uint32_t s_silence_count;           /* rescues caused by a silent output */
uint32_t s_nonfinite_count;         /* rescues caused by a bad number */
volatile uint32_t s_rescue_serial;  /* bumped on every rescue; readers compare it */
synth_rack_rescue_t s_last_rescue;

#if CONFIG_OBOD_STRESS
/*
 * The stress mode's own window on the output, kept beside the fuse because both read
 * the same finished block. Written by the audio task, read and reset by the stress
 * task; every field is an aligned 32-bit word, so the handover is a set of plain
 * loads and stores. No lock, for the reason the reset's comment in synth_dsp.h gives.
 */
static volatile int32_t  s_stress_peak_min = 32767;
static volatile int32_t  s_stress_peak_max = -32768;
static volatile uint32_t s_stress_blocks;
static volatile uint32_t s_stress_last_sound_ms;

/* One pass over the block already written. Samples are int16, so the signed extremes
 * are the peak pair the verdict reports; `any` is the same test the silence watchdog
 * makes, without a second reading of the block. */
static void stress_observe(const int16_t *out, int samples)
{
    int32_t lo = s_stress_peak_min;
    int32_t hi = s_stress_peak_max;
    uint32_t any = 0;

    for (int i = 0; i < samples * 2; i++) {
        const int32_t v = out[i];

        if (v < lo) {
            lo = v;
        }
        if (v > hi) {
            hi = v;
        }
        any |= (uint32_t)(uint16_t)out[i];
    }

    s_stress_peak_min = lo;
    s_stress_peak_max = hi;
    s_stress_blocks = s_stress_blocks + 1u;

    if (any != 0u) {
        s_stress_last_sound_ms = esp_log_timestamp();
    }
}
#endif

/* The reverb's mix, kept here as well because the BALANCE between dry and wet is applied at
 * the end of the chain, where the two are actually summed. See the output loop. */
float s_reverb_mix = 0.0f;

/* The chorus's and the delay's MIX, which is the RETURN LEVEL of each: how loud its answer
 * comes back beside a dry path that stays whole. See the chain in synth_rack_process. */
float s_chorus_mix = 0.0f;
/* Посыл мокрого сигнала эффект-машины в реверб: 0 — возврат только в сухое, как было. */
static float s_fx_verb;
float s_delay_mix  = 0.0f;

/*
 * WHERE A RETURN STOPS BEING A RETURN.
 *
 * Zero on the knob has to mean zero work behind it. An effect whose answer is going to be
 * multiplied by nothing used to cost almost nothing because its memory had not been taken
 * yet; since the prefetch it costs a line of PSRAM read, treated and rewritten on every
 * block. So the three gates in synth_rack_process() ask the level IN FORCE, and only an
 * effect that is being heard is computed at all.
 *
 * The test is a threshold rather than `== 0` because the level is the same 15 ms pole the
 * master uses: a knob turned down stays audible for those 15 ms, and the effect behind it is
 * stopped on the block after the level has ARRIVED at zero. -80 dB is twenty decibels below
 * the last bit of the output converter, so nothing dropped here could have been heard.
 */
constexpr float MIX_OFF_FLOOR = 1.0e-4f;

/*
 * THE DRY CROSSFADE: what makes a return an insert.
 *
 * A return level alone can only ADD. The dry path stays whole however far the knob goes, so
 * the loudest the room can be is the dry PLUS the room, and the player never hears the
 * instrument *inside* the effect the way a chain insert lets him. The send that feeds the
 * room is taken from the layer before its fader and the reverb's own wet gain is -11 dB
 * against the dry, so even a fully open return leaves the dry on top of it.
 *
 * The crossfade removes the dry as the effect takes over. For the reverb it is PER LAYER,
 * because its send is per layer: a layer whose send is closed keeps its dry whole no matter
 * what the return does, which is what "the lead in the room, the drone dry" means. For the
 * delay it is one factor on the whole dry pair, because the delay sits on the bus rather
 * than on the layers, and its input is blended the same way — a bus insert has to hear what
 * it replaces.
 *
 * THE AMOUNT is send x return, so a closed send and a closed return both mean "no crossfade":
 * the first because the layer is not in the effect, the second because the effect is not in
 * the mix. That product is also what keeps the middle of the travel honest — the dry can
 * only go as the wet is actually arriving, never before it.
 *
 * THE CURVE is 1 - a^4: the dry stays whole through the first half of the travel, where the
 * wet is still small, and leaves only as the wet actually arrives. The summed power (dry and
 * wet taken as uncorrelated, which is how the ear adds them) then moves by under a decibel
 * across the whole travel and does not hole in the middle — a linear or squared duck removes
 * the dry faster than the answer can replace it, which is the dip this shape avoids. The wet
 * is normalised by the RETURN_GAIN below, the inverse of the effect's measured wet gain: the
 * reverb's answer arrives 11 dB under the dry and the delay's 3 to 4 dB under it, and a
 * crossfade against an answer that quiet would be a fade into a hole.
 *
 * WHY THE GAINS ARE FIXED RATHER THAN MEASURED AT RUNTIME. The reverb's wet/dry was measured
 * across the four modes, both damping ends and the size travel, and the delay's across its
 * feedback. At the sizes the instrument ships with the room sits at -11 .. -13 dB under the
 * dry; it climbs with the room's own buildup as the size approaches one, to the dry's own
 * level, where a tonal source also decides the answer — whichever partials land on the combs'
 * resonances. The delay's follows its feedback, -4 dB with none to +0.4 dB at 0.9.
 *
 * A gain measured from the running programme would ride it, which is audible pumping — worse
 * than a known spread in decibels. The numbers are calibrated once, from measurements, and
 * what happens at the settings where the room's own build-up outgrows a fixed number is the
 * next block.
 */
constexpr float DELAY_RETURN_GAIN  = 1.25f;   /* +1.9 dB, against the delay's -3 dB */

/*
 * THE ROOM'S COMPENSATION IS NOT ONE NUMBER, because the room's own answer is not one level.
 *
 * A reverb fed a steady tone builds up until its combs stop growing, and how far they grow is
 * what SIZE sets. Measured on a fully open send, the answer sits 15 dB under the dry in a
 * small hall and arrives AT the dry's level in the largest cathedral. One fixed gain can be
 * right at one point of that range only, and it was calibrated at the sizes the instrument
 * ships with. At the top of the travel it put the wet eleven decibels over the instrument and
 * the output fused against its ceiling — measured at 0.00 dBFS against -16 dBFS on the
 * release — so the limiter flattened everything the drive had done. That is what "the
 * overdrive in the before position stopped working" sounds like, and it is not the drive.
 *
 * So the gain tapers, and only where the measurement says the build-up runs away: it is the
 * calibrated +9.2 dB up to SIZE 0.75, then falls in gain decibels, linearly in size, to the
 * value that lands the answer one decibel under the dry at a fully open knob. Below 0.75
 * nothing moved, so the sizes the instrument ships with keep the numbers measured for them.
 *
 * The end points come from the size-one measurements: 10^((-1 - wet_db) / 20) with the wet at
 * +2.2 dB ROOM, -2.7 HALL, +2.0 CATHEDRAL and -5.0 PLATE, all against a -1 dB target.
 */
constexpr float REVERB_RETURN_GAIN = 2.9f;    /* +9.2 dB: calibrated at the shipped sizes */

/* Solved from the size-one measurements: 10^((-1 - wet_db) / 20). */
static const float REVERB_RET_GAIN_TOP[4] = { 0.78f, 1.22f, 0.79f, 1.52f };

float s_reverb_ret_gain = REVERB_RETURN_GAIN;

static float reverb_gain_for(float size01, int mode)
{
    if (!(size01 >= 0.0f)) {
        size01 = 0.0f;
    } else if (size01 > 1.0f) {
        size01 = 1.0f;
    }
    if (mode < 0 || mode >= SYNTH_REVERB_MODE_COUNT) {
        mode = SYNTH_REVERB_HALL;
    }

    if (size01 <= 0.75f) {
        return REVERB_RETURN_GAIN;
    }

    /* Linear in gain decibels from +9.2 dB at 0.75 down to the size-one end point. */
    const float t = (size01 - 0.75f) * 4.0f;   /* 0 at 0.75, 1 at 1.0 */
    const float db = 20.0f * log10f(REVERB_RETURN_GAIN)
                   + (20.0f * log10f(REVERB_RET_GAIN_TOP[mode]) - 20.0f * log10f(REVERB_RETURN_GAIN)) * t;
    return expf(db * 0.1151292546f);   /* 10^(db/20) */
}

/*
 * One step of a return level's pole, with the arrival at zero snapped onto the target.
 *
 * The master's pole never snaps, because a master level is a gain the player rides and its
 * target is its own number. A return's bottom is a switch, and a switch has to be a state
 * rather than an asymptote: without the snap the level never reaches zero, the gate above
 * never closes, and the effect is paid for forever to deliver silence.
 */
IRAM_ATTR inline float mix_step(float cur, float target, float glide)
{
    if (target <= 0.0f && cur <= MIX_OFF_FLOOR) {
        return 0.0f;
    }

    const float next = cur + (target - cur) * glide;
    return (next == cur) ? target : next;
}

/*
 * Whether any part sends to a bus at all — asked once per block, never per sample.
 *
 * A send level is the same 15 ms pole the returns use, so the test is against the floor: a
 * part whose send has arrived at nothing contributes nothing, and one that is still on its
 * way down is still counted. Both the target and the value in force are asked, because a
 * send that has just been raised is a bus that is about to be read and a send that has just
 * been lowered is one that is still being read.
 */
IRAM_ATTR inline bool sends_live(const float *target, const float *cur)
{
    for (int layer = 0; layer < SYNTH_NUM_LAYERS; layer++) {
        if (target[layer] > 0.0f || cur[layer] > MIX_OFF_FLOOR) {
            return true;
        }
    }
    return false;
}

/*
 * What the last block's gates decided for the two effects that own a line. The edge from
 * false to true is where the module is told the return has come back up from zero; there is
 * nothing else to remember about it, because the restart itself is one store.
 */
bool s_chorus_run;

/*
 * АБЛЯЦИЯ СУММЫ — ВРЕМЕННЫЙ ИНСТРУМЕНТ, НЕ ДЛЯ РЕЛИЗА.
 *
 * 0 — как есть, 1 — без посылов, 2 — без сайдчейна баса, 3 — без цикла по слоям вовсе
 * (остаётся только рампа дака и записи). Нужен, чтобы замером стадии понять, куда уходят
 * 791 мкс, а не догадываться.
 */
#ifndef SUM_ABLATE
#define SUM_ABLATE 0
#endif
bool s_delay_run;

/*
 * Soft clipper.
 *
 *   g(x) = x + 0.5x^3 - 0.5x^5   on [-1, 1],   g(1) = 1, g'(1) = 0
 *
 * Unity gain and exactly linear at low level, exactly full scale at x = 1 with
 * zero slope, so there is no hard corner where it starts to bite. Below about
 * 0.2 it is transparent to within 0.2 dB; the curvature only shows up when the
 * drone is already loud, where it reads as gentle compression.
 *
 * This matters because the engine clips hard: its output stage is a saturating
 * CLAMPS instruction and it does not scale headroom by voice count, so one
 * voice at full volume already reaches full scale and nine of them summed would
 * wrap the int32 bus before the clamp ever saw it.
 *
 * It sits after the effects, so the reverb's tail is limited along with
 * everything else. A reverb that can push the output past full scale is a reverb
 * that turns a quiet passage into a loud one the moment the tail arrives.
 */
/*
 * МЯГКОЕ НАСЫЩЕНИЕ ВМЕСТО ЖЁСТКОГО ПОТОЛКА.
 *
 * Здесь стоял кубический клип с обрезкой по единице: до единицы он мягкий, а выше —
 * плоская полка, то есть ровно тот клип, который владелец иногда слышит. Теперь кривая
 * асимптотическая: колено начинается на 0.80 и потолок около 0.967, полки нет вовсе.
 *
 * Деление на сэмпл на мастере — это две операции на канал, около двадцати пяти
 * микросекунд на блок: на фоне пяти тысяч это ничто. (У ограничителя ударки деление
 * стоило дорого, потому что вызывалось четыре раза на сэмпл в горячем цикле.)
 *
 * Низ не срезается: кривая действует на всю полосу одинаково, а прибор подключают к
 * большим динамикам, где низ и есть звук.
 */
IRAM_ATTR inline float soft_clip(float x)
{
    /*
     * БЕЗ ДЕЛЕНИЯ.
     *
     * Здесь стояло T + (a - T) / (1 + (a - T) * K). Деление в мягкой плавающей точке на
     * этом камне дорого, а срабатывало оно ровно на громких местах — то есть на ударных,
     * и звук начинал спотыкаться именно там. Та же идея сделана куском с падающим
     * наклоном: до 0.80 пропускаем как есть, дальше наклон 0.60, а с 0.25 за коленом —
     * 0.15. Полки нет до 0.995, дальше упираемся в потолок.
     */
    /*
     * КОЛЕНО МАСТЕРА ПОДНЯТО: 0.80 -> 0.95.
     *
     * Мягкое ограничение начиналось на 0.80, то есть на громких китах работало почти
     * всегда — это и был последний источник «перегруза», который маскировал разницу между
     * китами. Теперь оно вмешивается только у самой полной шкалы.
     */
    const float T = 0.80f;
    const float a = fabsf(x);

    if (a <= T) {
        return x;
    }

    const float u = a - T;
    float y;

    if (u <= 0.25f) {
        y = T + u * 0.60f;
    } else {
        y = T + 0.15f + (u - 0.25f) * 0.15f;

        if (y > 0.995f) {
            y = 0.995f;
        }
    }

    return (x < 0.0f) ? -y : y;
}

/*
 * First use, not boot.
 *
 * The device finishes booting with a few kilobytes of internal heap to spare, and
 * the Wi-Fi SoftAP starts asynchronously right after it. When the effects claimed
 * their memory at boot, the SoftAP failed to allocate its beacon buffers and the
 * Wi-Fi driver took a NULL it does not check: the board rebooted in a loop. So
 * nothing is claimed until an effect is actually asked for, which is the first
 * time a mix or a send stops being zero.
 *
 * The pointers are only published once all seven are set, and the gate is set last,
 * because the audio task is already running when this happens.
 */
void claim_scratch(void)
{
    /*
     * PSRAM, and now measured both ways for the summing loop itself.
     *
     * The question was whether these nine blocks are what the summing loop pays for: seven
     * of them are written every sample, and in PSRAM each store is a cache line. They were
     * moved into internal RAM and the loop was measured on the instrument on both sides of
     * the move, from the same code, with the same patch:
     *
     *     summing loop, pool in PSRAM:      812 us a block
     *     summing loop, pool in internal:   811 us a block
     *
     * — one microsecond, which is inside the run-to-run spread, so the placement is not what
     * the loop costs; the cache absorbs these writes. What the move DID buy was 33 us in the
     * returns sum, which reads all of them and writes two (282 -> 249 us a block), and it
     * cost 9 KB of internal RAM — the resource this instrument is shortest of, which is the
     * one the note above is about. It was therefore reverted: the loop under optimisation
     * gains nothing from it, and the 9 KB is worth more left where the engine can reach for
     * it. Claimed on first use rather than at boot for the reason above.
     */
    const size_t bytes = sizeof(float) * (size_t)SYNTH_BLOCK_SAMPLES * 9u;
    float *pool = (float *)heap_caps_malloc(bytes, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!pool) {
        ESP_LOGW(TAG, "no scratch for %u bytes — the effects stay bypassed",
                 (unsigned)bytes);
        return;
    }

    s_dry_r    = pool + SYNTH_BLOCK_SAMPLES;
    s_send_bus = pool + SYNTH_BLOCK_SAMPLES * 2;
    s_wet_l    = pool + SYNTH_BLOCK_SAMPLES * 3;
    s_wet_r    = pool + SYNTH_BLOCK_SAMPLES * 4;
    s_chr_l    = pool + SYNTH_BLOCK_SAMPLES * 5;
    s_chr_r    = pool + SYNTH_BLOCK_SAMPLES * 6;
    s_dly_l    = pool + SYNTH_BLOCK_SAMPLES * 7;
    s_dly_r    = pool + SYNTH_BLOCK_SAMPLES * 8;
    s_dry_l    = pool;
    s_scratch  = true;
}

#if STAGE_TIMING
/*
 * THE BLOCK'S OWN BOOKKEEPING, one entry per stage of synth_rack_process().
 *
 * Two kinds of measurement meet here. The block-level stages are added in microseconds as
 * they finish, straight from esp_timer_get_time(). The two per-sample ones — the compressor,
 * and the master gain with the soft clip — cannot be timed with that timer: two reads per
 * sample is 512 reads a block and would cost more than the stages themselves, so rack_out()
 * accumulates CYCLE COUNTS into the two counters below and they are converted once, here, at
 * the end of the block.
 *
 * The compressor is one of the two stages this exists for: the question that started the
 * measurement was what the compressor costs when the drive is also in the chain, and a
 * number that also contains the master gain cannot answer it.
 */
struct rack_stage_block {
    uint32_t sum;       /* the summing loop */
    uint32_t gate;      /* gate ramp, returns sum, master/clip */
    uint32_t perc;
    uint32_t chorus;
    uint32_t delay;
    uint32_t reverb;
};

rack_stage_block s_stage_blk;

/* One microsecond in cycles. The CPU runs at CONFIG_ESP_DEFAULT_CPU_FREQ_MHZ and DFS is off
 * (CONFIG_PM_ENABLE is not set), so this is a constant of the build and not a reading. */
constexpr uint32_t STAGE_CYCLES_PER_US = (uint32_t)CONFIG_ESP_DEFAULT_CPU_FREQ_MHZ;

uint32_t s_stage_cycles_comp;
uint32_t s_stage_cycles_master;

void stage_block_begin(void)
{
    s_stage_blk.sum = 0;
    s_stage_blk.gate = 0;
    s_stage_blk.perc = 0;
    s_stage_blk.chorus = 0;
    s_stage_blk.delay = 0;
    s_stage_blk.reverb = 0;
    s_stage_cycles_comp = 0;
    s_stage_cycles_master = 0;
}

void stage_block_end(void)
{
    if (STAGE_CYCLES_PER_US > 0u) {
        s_stage_blk.gate += s_stage_cycles_master / STAGE_CYCLES_PER_US;
    }

    synth_stage_add(SYNTH_STAGE_COMP,
                    (STAGE_CYCLES_PER_US > 0u)
                        ? (s_stage_cycles_comp / STAGE_CYCLES_PER_US) : 0u);
    synth_stage_add(SYNTH_STAGE_SUM,    s_stage_blk.sum);
    synth_stage_add(SYNTH_STAGE_GATE,   s_stage_blk.gate);
    synth_stage_add(SYNTH_STAGE_PERC,   s_stage_blk.perc);
    synth_stage_add(SYNTH_STAGE_CHORUS, s_stage_blk.chorus);
    synth_stage_add(SYNTH_STAGE_DELAY,  s_stage_blk.delay);
    synth_stage_add(SYNTH_STAGE_REVERB, s_stage_blk.reverb);
}

/* How long a block-level stage took, in microseconds, never negative. */
static inline uint32_t stage_elapsed(int64_t t0)
{
    const int64_t dt = esp_timer_get_time() - t0;
    return (dt > 0) ? (uint32_t)dt : 0u;
}
#endif /* STAGE_TIMING */

} // namespace

void synth_rack_init(void)
{
    /* Полоса дака: срез зависит от частоты сэмплов, а она на приборе одна. */
    synth_rack_set_band_rate((float)SYNTH_SAMPLE_RATE);

    /*
     * Send levels that are already balanced against each other, so that raising
     * the reverb mix alone gives a usable room rather than a drone soup: the low
     * drone sends least, the lead most. They are patch parameters and the
     * application will overwrite them at boot with its own defaults; these are
     * the values that hold if it never does.
     */
    static const float send_default[SYNTH_NUM_LAYERS] = {
        0.15f,   /* LOW  */
        0.20f,   /* MID  */
        0.35f,   /* HIGH */
        0.50f,   /* LEAD */
        0.12f,   /* BASS: the low end wants a short room, not a wash */
        0.20f,   /* AUX  */
    };

    /* The glides start on their targets: nothing to walk to at boot, and a fader that faded
     * up from zero would be a fade the instrument never asked for. */
    s_level_glide = 1.0f - expf(-1.0f / (0.012f * (float)SYNTH_SAMPLE_RATE));

    for (int i = 0; i < SYNTH_NUM_LAYERS; i++) {
        s_layer_level[i] = 1.0f;
        s_send_rev[i] = send_default[i];
        s_layer_level_cur[i] = s_layer_level[i];
        s_send_rev_cur[i] = s_send_rev[i];
        s_send_chr_cur[i] = 0.0f;
        s_send_dly_cur[i] = 0.0f;
        /* The two new buses start closed: an instrument that has never been touched sends
         * nothing to the chorus or the delay, and their returns come back to nothing. */
        s_send_chr[i] = 0.0f;
        s_send_dly[i] = 0.0f;
    }
    s_master = 1.0f;

    /* The boot fade starts closed and unarmed: the first block the audio task renders is
     * silent until main() explicitly releases it, and only then does the 150 + 700 ms
     * timeline begin. */
    s_boot_arm_request = 0u;
    s_boot_armed = false;
    s_boot_done = false;
    s_boot_samples = 0u;
    s_boot_block_base = 0u;

    /* The two per-sample poles of the output stage. Built here rather than per block
     * because neither depends on anything but the sample rate. Nothing on this path
     * has a sample clock of its own to run them against — rack_out() is called once
     * per sample and not once per block — so the coefficient is the per-sample one
     * and the time constants are the ones above. */
    const float fs = (float)SYNTH_SAMPLE_RATE;
    s_master_glide = 1.0f - expf(-1.0f / (MASTER_GLIDE_MS * 0.001f * fs));
    s_reverb_mix_glide = 1.0f - expf(-1.0f / (MIX_GLIDE_MS * 0.001f * fs));
    s_chorus_mix_glide = s_reverb_mix_glide;
    s_delay_mix_glide  = s_reverb_mix_glide;

    /*
     * The compressor's four, for the same reason and one more.
     *
     * None of them depends on anything but the sample rate and the constants in the header,
     * so they are constants — and they used to be built inside synth_rack_set_comp(). That
     * was harmless while the setter ran once per detent of a knob. It does not run once per
     * detent: a parameter travelling over a SLIDE is re-applied on every block, so a
     * three-second slide asked for these same four logarithms four and a half thousand
     * times. Moving the compressor was the one gesture the instrument could not afford, and
     * the status line's cost breakdown is the measurement that says so.
     */
    s_comp_att   = expf(-1.0f / (COMP_ATTACK_MS * 0.001f * fs));
    s_comp_rel   = expf(-1.0f / (COMP_RELEASE_MS * 0.001f * fs));
    s_comp_hp    = expf(-2.0f * 3.14159265f * COMP_SC_HP_HZ / fs);
    s_comp_glide = 1.0f - expf(-1.0f / (COMP_GAIN_GLIDE_MS * 0.001f * fs));
    s_duck_makeup_glide = 1.0f - expf(-1.0f / (DUCK_MAKEUP_GLIDE_MS * 0.001f * fs));

    /* Both ramps start on their targets: there is nothing to glide from at boot, and
     * a master that faded up from zero would be a fade the instrument never asked
     * for. */
    s_master_cur = s_master;
    s_reverb_mix_cur = s_reverb_mix;
    s_chorus_mix_cur = s_chorus_mix;
    s_delay_mix_cur  = s_delay_mix;

    /* Nothing has run yet, so every gate is shut and every line is the one its claim zeroed. */
    s_chorus_run = s_delay_run = false;
}

void synth_rack_set_layer_level(int layer, float level)
{
    /*
     * The 0..1 inputs are bounded by a NEGATED test, here and everywhere else on this
     * API. A comparison with NaN is always false, so the usual `x < 0 ? 0 : x` passes
     * a non-number straight through; `!(x >= 0)` sends it to the low bound instead.
     */
    if (!(level >= 0.0f)) {
        level = 0.0f;
    } else if (level > 1.0f) {
        level = 1.0f;
    }

    if (layer >= 0 && layer < SYNTH_NUM_LAYERS) {
        s_layer_level[layer] = level;
    }
}

void synth_rack_set_master(float level)
{
    if (!(level >= 0.0f)) {
        level = 0.0f;
    } else if (level > 1.0f) {
        level = 1.0f;
    }

    s_master = level;
}

/*
 * The application's one call into the boot gate. Written from app_main's task, read by
 * the audio task at the top of its next block; a single aligned word, so no lock is
 * needed and nothing else travels with it. Idempotent, and the first call is the one
 * that starts the clock.
 */
extern "C" void synth_rack_boot_arm(void)
{
    s_boot_arm_request = 1u;
}

/*
 * The gain that applies to the next output sample, for the desktop bench. Before the arm
 * this is exactly zero; through the 700 ms it is the ramp; once the ramp has arrived it
 * is exactly one, which is also the value the output stage multiplies by.
 */
extern "C" float synth_rack_boot_gain(void)
{
    if (!s_boot_armed) {
        return 0.0f;
    }
    return s_boot_done ? 1.0f : boot_gain_at(s_boot_samples);
}

float synth_rack_comp_ratio(float amount01)
{
    return 1.0f + (COMP_RATIO_MAX - 1.0f) * amount01;
}

void synth_rack_set_side(float amount01)
{
    if (!(amount01 >= 0.0f)) {
        amount01 = 0.0f;
    } else if (amount01 > 1.0f) {
        amount01 = 1.0f;
    }

    s_side = amount01;
}

void synth_rack_set_comp(float amount01)
{
    /* Negated lower test: a non-number must land on 0 (off), not pass through. */
    if (!(amount01 >= 0.0f)) {
        amount01 = 0.0f;
    } else if (amount01 > 1.0f) {
        amount01 = 1.0f;
    }

    const bool was_on = s_comp_on;
    s_comp_on = (amount01 > 0.0f);

    /*
     * NO STATE IS RESET HERE any more, and that is the whole of the fix for the
     * click on this knob.
     *
     * What used to stand here put the gain in force back to unity and the envelope
     * back to zero on every call — that is, on every detent of a knob that is being
     * turned, and on every block of a preset slide. The envelope was the worse half.
     * It is what the curve reads, and a detector that has just been zeroed says the
     * instrument is silent: the reduction for that block is none and the makeup is
     * all of it, so the gain the curve asked for was ABOVE unity — 2.59 at three
     * quarters of the travel, +8 dB — and the gain in force, freshly set to 1.0 by
     * the line below, walked up to it in sixteen samples. Measured on a held tone:
     * one detent of the knob took the applied gain from 0.83 to 1.10 on the first
     * sample, and the detector's 25 ms attack then dragged it back down. A step onto
     * a boost and a step back off it, on every detent, is the crackle that was
     * reported.
     *
     * The detector state and the gain in force are both history rather than
     * settings: the envelope is a measurement of the last 250 ms of the instrument,
     * which does not become untrue because a knob moved, and the gain is where the
     * signal actually is, which does not become untrue either. Both are carried
     * across the change, and the new threshold, ratio and makeup reach the signal
     * through the gain's own 12 ms pole — see rack_out().
     */
    s_comp_thresh_db = COMP_THRESH_DB * amount01;
    s_comp_slope = 1.0f - 1.0f / synth_rack_comp_ratio(amount01);
    s_comp_makeup_db = COMP_MAKEUP_FRAC * -s_comp_thresh_db * s_comp_slope;

    /*
     * The four one-pole coefficients are NOT built here, and that is the second half of the
     * same fix. None of them depends on amount01: they are constants of the sample rate, and
     * synth_rack_init() builds them once. They stood here, at four expf() a call — and a
     * call is not once per detent of the knob but once per BLOCK while the parameter is
     * sliding, which is what made this the one parameter the instrument could not afford to
     * move. See the note in synth_rack_init().
     */

    /*
     * The ONE reset that is still right, and only on the transition that needs it.
     *
     * With the knob at the bottom of its travel the stage is skipped, so its
     * detector is not being updated: the envelope sitting in it is whatever was
     * there when it was last switched off, and that is a measurement of a moment
     * that may have been minutes ago. Switching the stage on with a stale envelope
     * would open the first block on a gain reduction nobody asked for. Fresh state
     * for a fresh stage — and it is harmless here, because a detector that has just
     * been zeroed asks for no reduction at all, which is where the gain in force
     * already is: off means the pole has walked it to unity.
     */
    if (s_comp_on && !was_on) {
        s_comp_env = 0.0f;
        s_comp_hp_xl = s_comp_hp_yl = 0.0f;
        s_comp_hp_xr = s_comp_hp_yr = 0.0f;
        s_comp_tick = 0;   /* the first curve is due on the very next sample */
    }
}

void synth_rack_set_gate(int on)
{
    /* The target, not the gain: the ramp above walks to it, one sample at a time, so
     * that neither a note nor the transport can step the signal. Called once per block
     * by the audio task, which is the side that knows whether an external note is
     * sounding. */
    s_gate = (on != 0);
}

/* The watchdog's other input. A store, read on the block that follows; no lock, for the
 * same reason nothing else here has one — the audio task writes nothing the control side
 * reads back. */
void synth_rack_set_transport(int running)
{
    s_transport = (running != 0) ? 1u : 0u;
}

/*
 * The chorus and the delay are given a mix of 1 inside — pure wet.
 *
 * What reaches either of them is already only the part of the signal the player sent, and a
 * crossfade inside would mix that part back against itself: the dry coming out of the effect
 * would be the send, not the instrument. So the effect's own mix is pinned at full and the
 * knob is the return level, applied once, at the summing point where the reverb's is.
 */
/*
 * ЭФФЕКТ-МАШИНА НА МЕСТЕ ХОРУСА.
 *
 * Тип — номер эффекта, A, B, C — его три параметра, mix — уровень возврата. Возврат стойка
 * гасит на смене типа сама (см. chr_mix_glide ниже), поэтому щелчка нет.
 */
/* Темп для эффектов, которым нужна сетка: STUTTER берёт свой кусок раз в такт. */
void synth_rack_set_fx_tempo(float bpm, int running)
{
    synth_fx_machine_set_tempo(bpm, running);
}

void synth_rack_set_fx_machine(int type, float a, float b, float c, float mix01)
{
    synth_fx_machine_set_type(type);
    synth_fx_machine_set_params(a, b, c);

    s_chorus_mix = (mix01 >= 0.0f) ? mix01 : 0.0f;

    if (s_chorus_mix > 1.0f) {
        s_chorus_mix = 1.0f;
    }
}

void synth_rack_set_chorus(float rate_hz, float depth01, float mix01)
{
    if (!(mix01 >= 0.0f)) {
        mix01 = 0.0f;
    } else if (mix01 > 1.0f) {
        mix01 = 1.0f;
    }
    s_chorus_mix = mix01;

    if (mix01 > 0.0f) {
        s_want_fx = true;
    }
    synth_chorus_set(rate_hz, depth01, 1.0f);
}

/*
 * ПОСЫЛ ДИЛЕЯ В РЕВЕРБ.
 *
 * Повторы раньше шли только в сухую сумму, и обработать их ревербом было нельзя. Теперь
 * мокрый сигнал дилея добавляется в шину реверба — до того, как реверб посчитан, потому что
 * дилей в стойке стоит перед ним. Ноль — как было.
 */
static float s_delay_verb;

void synth_rack_set_fx_verb(float v01)
{
    if (!(v01 >= 0.0f)) {
        v01 = 0.0f;
    } else if (v01 > 1.0f) {
        v01 = 1.0f;
    }

    s_fx_verb = v01;
}

void synth_rack_set_delay_verb(float v01)
{
    if (!(v01 >= 0.0f)) {
        v01 = 0.0f;
    } else if (v01 > 1.0f) {
        v01 = 1.0f;
    }

    s_delay_verb = v01;
}

void synth_rack_set_delay_damp(float v01)
{
    /* Демпфирование повторов. Стоит отдельным сеттером, а не пятым аргументом
     * synth_rack_set_delay(): у того вызовы идут на каждое изменение времени и посыла, и
     * таскать в них ещё одно число значило бы трогать чужую ручку ради своей. */
    synth_delay_set_damp(v01);

    if (v01 > 0.0f) {
        s_want_fx = true;
    }
}

void synth_rack_set_delay(float time_samples, float feedback01, float mix01, bool crossfade)
{
    if (!(mix01 >= 0.0f)) {
        mix01 = 0.0f;
    } else if (mix01 > 1.0f) {
        mix01 = 1.0f;
    }
    s_delay_mix = mix01;

    if (mix01 > 0.0f) {
        s_want_fx = true;
    }
    synth_delay_set(time_samples, feedback01, 1.0f);
    /* The delay runs at full wet by design — this MIX is the return level the output loop
     * applies — so the module cannot read it from its own mix. Tell it whether the player
     * has asked for the effect; that is what permits a lazy claim before the boot prefetch
     * has taken the lines. */
    synth_delay_set_active(mix01 > 0.0f);
    synth_delay_set_mode(crossfade);
}

void synth_rack_set_reverb(float size01, float damp01, float mix01, int mode)
{
    if (!(mix01 >= 0.0f)) {
        mix01 = 0.0f;
    } else if (mix01 > 1.0f) {
        mix01 = 1.0f;
    }
    s_reverb_mix = mix01;
    s_reverb_ret_gain = reverb_gain_for(size01, mode);

    if (mix01 > 0.0f) {
        s_want_fx = true;
    }
    /*
     * PINNED AT ONE, like the chorus and the delay beside it: the rack owns the return and
     * applies it to the pair with its own pole. The knob used to be handed down as well, and
     * the module reads a mix of zero as "silence the wet buffers and return" — so the knob
     * reaching the bottom cut the answer in a single sample while the rack's pole was still
     * a tenth of the way down, which is a click. With the mix pinned the buffers stay whole
     * and only the pole moves; the module is not even called at zero return, so nothing is
     * paid for the pinning.
     */
    synth_reverb_set(size01, damp01, 1.0f, mode);
}

void synth_rack_set_reverb_send(int layer, float level01)
{
    if (!(level01 >= 0.0f)) {
        level01 = 0.0f;
    } else if (level01 > 1.0f) {
        level01 = 1.0f;
    }

    if (layer >= 0 && layer < SYNTH_NUM_LAYERS) {
        s_send_rev[layer] = level01;
        if (level01 > 0.0f) {
            s_want_fx = true;
        }
    }
}

/*
 * The chorus's and the delay's sends, per part. The reverb's own are
 * synth_rack_set_reverb_send() and have not moved; these are the two new buses, and each
 * part chooses how much of itself goes to each of the three effects.
 */
void synth_rack_set_chorus_send(int layer, float level01)
{
    if (!(level01 >= 0.0f)) {
        level01 = 0.0f;
    } else if (level01 > 1.0f) {
        level01 = 1.0f;
    }

    if (layer >= 0 && layer < SYNTH_NUM_LAYERS) {
        s_send_chr[layer] = level01;
        if (level01 > 0.0f) {
            s_want_fx = true;
        }
    }
}

void synth_rack_set_delay_send(int layer, float level01)
{
    if (!(level01 >= 0.0f)) {
        level01 = 0.0f;
    } else if (level01 > 1.0f) {
        level01 = 1.0f;
    }

    if (layer >= 0 && layer < SYNTH_NUM_LAYERS) {
        s_send_dly[layer] = level01;
        if (level01 > 0.0f) {
            s_want_fx = true;
        }
    }
}

void synth_rack_set_perc_send(float level01)
{
    if (!(level01 >= 0.0f)) {
        level01 = 0.0f;
    } else if (level01 > 1.0f) {
        level01 = 1.0f;
    }
    s_perc_send_rev = level01;

    /*
     * Always, not only above zero. The percussion is mixed inside the rack rather
     * than captured from a bus, so the rack needs its scratch for the drum part
     * itself and not just for the room it is asking for — a percussion voice with
     * the send at zero and every effect switched off still has to be audible, and
     * the dry path below has nowhere to put it.
     */
    s_want_fx = true;
}

void synth_rack_set_perc_chorus_send(float level01)
{
    if (!(level01 >= 0.0f)) {
        level01 = 0.0f;
    } else if (level01 > 1.0f) {
        level01 = 1.0f;
    }
    s_perc_send_chr = level01;
    if (s_perc_send_chr > 0.0f) {
        s_want_fx = true;
    }
}

void synth_rack_set_perc_delay_send(float level01)
{
    if (!(level01 >= 0.0f)) {
        level01 = 0.0f;
    } else if (level01 > 1.0f) {
        level01 = 1.0f;
    }
    s_perc_send_dly = level01;
    if (s_perc_send_dly > 0.0f) {
        s_want_fx = true;
    }
}

void synth_rack_set_duck_src(float mode01)
{
    synth_perc_set_duck_src(mode01);
}

void synth_rack_set_duck_rel(float rel01)
{
    if (!(rel01 >= 0.0f)) {
        rel01 = 0.0f;
    } else if (rel01 > 1.0f) {
        rel01 = 1.0f;
    }
    s_duck_rel = rel01;
}

void synth_rack_set_duck(float amount01)
{
    if (!(amount01 >= 0.0f)) {
        amount01 = 0.0f;
    } else if (amount01 > 1.0f) {
        amount01 = 1.0f;
    }
    s_duck = amount01 * DUCK_TRAVEL;
}

/*
 * The low end's gain for one block.
 *
 * The control is the drum's own envelope, the same number the level meters show, so the duck
 * opens on the hit and not on a clock of its own.
 *
 * The attack is short but NOT instant. It used to be, and that was a step in gain on the
 * first block of every hit — a click sitting exactly under the drum, the one place it cannot
 * hide. Twelve milliseconds is the compromise: fast enough that the hit still pushes the low
 * end away before its transient, slow enough that the gain is a slope and not a jump. The
 * release is a one-pole whose time is the knob's other half: 220 ms at the bottom of the
 * travel and 90 ms at the top. Depth and speed are one
 * gesture because that is how the effect is heard, and a second knob would only ever be set
 * to match the first.
 */
float synth_rack_duck_depth(void)
{
    return s_duck_smooth;
}

/*
 * How many times the output fuse has fired since boot. Read by the statistics task, which
 * is on the other core: the counter is volatile and a torn read is impossible on a 32-bit
 * aligned word, so one store and one load are the whole of the handover.
 */
uint32_t synth_rack_rescue_count(void)
{
    return s_rescue_count;
}

/* The serial of the last rescue, and a copy of the state it happened in. The audio task
 * reads the serial and, when it moves, copies the snapshot into the handover buffer; the
 * statistics task prints that copy and stores the RTC record. The audio task is the only
 * writer of both. */
IRAM_ATTR uint32_t synth_rack_rescue_serial(void)
{
    return s_rescue_serial;
}

IRAM_ATTR void synth_rack_rescue_snapshot(synth_rack_rescue_t *out)
{
    if (out != NULL) {
        *out = s_last_rescue;
    }
}

#if CONFIG_OBOD_STRESS
void synth_rack_stress_peak_reset(void)
{
    s_stress_peak_min = 32767;
    s_stress_peak_max = -32768;
    s_stress_blocks = 0u;

    /* The pass starts now, so a pass that never makes a sound reads as silent at its
     * own end rather than inheriting the previous pass's last block. */
    s_stress_last_sound_ms = (uint32_t)esp_log_timestamp();
}

void synth_rack_stress_peak(synth_rack_stress_out_t *out)
{
    if (out == NULL) {
        return;
    }

    out->peak_min = s_stress_peak_min;
    out->peak_max = s_stress_peak_max;
    out->blocks = s_stress_blocks;
    out->last_sound_ms = s_stress_last_sound_ms;
}

void synth_rack_stress_poison(int which)
{
    /* The two states rack_state_bad() checks by name that are not rewritten per sample by
     * an unrolled loop: the master gain and the compressor's. The gate's gain is also on
     * the fuse's list, but a poison there can be lost when the compiler keeps that ramp
     * in a register for the whole block, and a test that fails for a compiler's sake is
     * not a test of the fuse. */
    switch (which) {
    case 0:
        s_master_cur = NAN;
        break;
    case 1:
        s_comp_gain = NAN;
        break;
    default:
        break;
    }
}
#endif

/*
 * ПРИОРИТЕТ ЛИДА: ДРОН УСТУПАЕТ, КОГДА ЛИД ПОЁТ.
 *
 * На плотном миксе дрон и лид занимают одни и те же полосы, и дрон, будучи ровным и
 * непрерывным, перекрывает линию. Здесь стойка следит за уровнем слоя лида и опускает три
 * регистра дрона: в паузах дрон на месте, под линию — до трёх децибел вниз. Отпускание в
 * четверть секунды, чтобы возвращение не читалось как движение.
 *
 * Баса это не касается (у него свой дакинг с ударом), лида — тем более, ударной тоже.
 */
#define LEAD_DUCK_DEPTH  0.30f      /* до -3 дБ */
#define LEAD_DUCK_ATT_MS 18.0f
#define LEAD_DUCK_REL_MS 250.0f

float s_lead_gain = 1.0f;           /* множитель дрона от лида, обновляется раз в блок */
static float s_lead_gain_follow;    /* уровень лида, сглаженный */

static float lead_duck_gain(int samples)
{
    const float *ll = synth_layer_l(SYNTH_LAYER_LEAD);
    const float *lr = synth_layer_r(SYNTH_LAYER_LEAD);

    float sum = 0.0f;

    for (int i = 0; i < samples; i++) {
        sum += ll[i] * ll[i] + lr[i] * lr[i];
    }

    const float rms = sqrtf(sum / (float)((samples > 0) ? samples * 2 : 1));

    /* Четыре — это усиление до «единицы»: слой лида в работе доходит до четверти шкалы. */
    float target = rms * 4.0f;

    if (!(target >= 0.0f)) {
        target = 0.0f;
    } else if (target > 1.0f) {
        target = 1.0f;
    }

    const float block_ms = (float)samples * (1000.0f / 48000.0f);
    const float coef_att = block_ms / (LEAD_DUCK_ATT_MS + block_ms);
    const float coef_rel = block_ms / (LEAD_DUCK_REL_MS + block_ms);

    const float coef = (target > s_lead_gain_follow) ? coef_att : coef_rel;
    s_lead_gain_follow += (target - s_lead_gain_follow) * coef;

    if (!(s_lead_gain_follow >= 0.0f)) {
        s_lead_gain_follow = 0.0f;
    } else if (s_lead_gain_follow > 1.0f) {
        s_lead_gain_follow = 1.0f;
    }

    return 1.0f - LEAD_DUCK_DEPTH * s_lead_gain_follow;
}

static float duck_low_gain(int samples)
{
    if (s_duck <= 0.0f) {
        s_duck_smooth = 0.0f;
        return 1.0f;
    }

    const float env = synth_perc_duck_src_published();   /* полоса, выбранная SRC */
    const float block_ms = (float)samples * (1000.0f / 48000.0f);
    const float attack_ms = 12.0f;
    /* 60..400 мс своим числом: с фильтром источника сцепка с глубиной мешает. */
    const float release_ms = 60.0f + 340.0f * s_duck_rel;
    const float coef_att = block_ms / (attack_ms + block_ms);
    const float coef_rel = block_ms / (release_ms + block_ms);
    const float target = env * s_duck;

    const float coef = (target > s_duck_smooth) ? coef_att : coef_rel;
    s_duck_smooth += (target - s_duck_smooth) * coef;

    /* The same negated lower test as the setters: a non-finite envelope published by the
     * drum must not leave this state at NaN and hold the duck at an unknown depth. */
    if (!(s_duck_smooth >= 0.0f)) {
        s_duck_smooth = 0.0f;
    }

    return 1.0f - s_duck_smooth;
}

/*
 * The last thing the rack does to a sample: the master compressor, the master gain, the
 * soft clip, and the conversion to the output format.
 *
 * One function because there are two output paths — the full chain with its effects, and
 * the dry path taken when nothing has asked for one — and both end here for the same
 * reason. A compressor written into only one of them would be a control that stopped
 * working the moment the reverb was switched off, which is a bug that would be blamed on
 * the reverb.
 *
 * The detector runs on the signal as it arrives, BEFORE the master gain, so turning the
 * output down does not change what the compressor is doing.
 *
 * The master gain itself is a gain, and it is ramped rather than written: a LEVEL knob
 * that steps is the same click as a compressor that steps, and the knob is the one the
 * player reaches for while a drone is sounding. See MASTER_GLIDE_MS.
 */
IRAM_ATTR static inline void rack_out(float l, float r, float boot_gain, int16_t *out)
{
#if STAGE_TIMING
    /* Two stages in one function, and the compressor is the one the bench asked about: the
     * boundary is the end of its own branch, and the counter is a register read. */
    const uint32_t stage_c0 = esp_cpu_get_cycle_count();
#endif

    if (s_comp_on) {
        /*
         * The side-chain high-pass comes first, one pole per channel. The low drone is
         * the loudest thing in this instrument and the least informative about how loud
         * the mix is: left in, it would drive the detector and the gain would ride the
         * waveform, which is the pumping this would be judged by.
         */
        s_comp_hp_yl = (l - s_comp_hp_xl) + s_comp_hp * s_comp_hp_yl;
        s_comp_hp_xl = l;
        s_comp_hp_yr = (r - s_comp_hp_xr) + s_comp_hp * s_comp_hp_yr;
        s_comp_hp_xr = r;

        /* LINKED: one envelope from the louder side, so a hit on one side cannot move
         * the image. Rising uses the attack, falling the release. */
        /* Сравнение вместо fmaxf: в карте компоновки это вызов libm на каждый сэмпл. */
        const float comp_al = (s_comp_hp_yl < 0.0f) ? -s_comp_hp_yl : s_comp_hp_yl;
        const float comp_ar = (s_comp_hp_yr < 0.0f) ? -s_comp_hp_yr : s_comp_hp_yr;
        const float x = (comp_al > comp_ar) ? comp_al : comp_ar;
        const float k = (x > s_comp_env) ? s_comp_att : s_comp_rel;
        s_comp_env = x + k * (s_comp_env - x);

        /*
         * The static curve is evaluated once every COMP_GAIN_EVERY samples and the gain
         * walks to it in between. This is the one expensive part of the stage — a
         * logarithm and an exponential, and on this chip both are software routines —
         * and doing it per sample was MEASURED at 1.1 ms of a 2.67 ms block, which is
         * not a price a master compressor gets to charge. The envelope above still runs
         * on every sample, so a transient is never missed; only the curve is slower, and
         * the gain's own pole — 12 ms against the 0.33 ms the straight line across the
         * gap gave it — has walked across the treads since before this stage.
         *
         * The knee is the usual quadratic, joined to the two straight lines at -knee/2
         * and +knee/2, so both the value and its slope are continuous across it.
         */
        if (--s_comp_tick <= 0) {
            s_comp_tick = COMP_GAIN_EVERY;

            /*
             * THE SIDECHAIN'S OWN FUSE, and the reason it is here rather than in the
             * output check above: with the envelope not a number, log2f() is not a number,
             * BOTH ends of the knee compare false, and the curve answers a flat zero
             * decibels for ever — a compressor that has silently become an on switch, with
             * nothing in the output to show for it. One test per curve, sixteen samples
             * apart, on a stage that is asked for; the answer is unity gain and a clean
             * detector, and the next curve is due in sixteen samples.
             */
            if (!isfinite(s_comp_env)) {
                s_comp_env = 0.0f;
                s_comp_gain = 1.0f;
                s_comp_gain_to = 1.0f;
                s_comp_hp_xl = s_comp_hp_yl = 0.0f;
                s_comp_hp_xr = s_comp_hp_yr = 0.0f;
            } else {
                const float env_db = COMP_DB_PER_OCT * log2f(s_comp_env + 1.0e-9f);
                const float over = env_db - s_comp_thresh_db;
                float gain_db = 0.0f;

                if (over > COMP_KNEE_DB * 0.5f) {
                    gain_db = -s_comp_slope * over;
                } else if (over > -COMP_KNEE_DB * 0.5f) {
                    const float t = over + COMP_KNEE_DB * 0.5f;
                    gain_db = -s_comp_slope * t * t / (2.0f * COMP_KNEE_DB);
                }

                s_comp_gain_to = exp2f((gain_db + s_comp_makeup_db) / COMP_DB_PER_OCT);
            }
        }

        s_comp_gain += (s_comp_gain_to - s_comp_gain) * s_comp_glide;

        /* Компенсация дакинга идёт за сэмпл к своей цели: на границе блока она больше не
         * прыгает. Раньше она была постоянной блока — то есть очередь щелчков по 187 Гц,
         * ровно то, чего этот файл в другом месте велит не делать. */
        s_duck_makeup_cur += (s_duck_makeup - s_duck_makeup_cur) * s_duck_makeup_glide;
        l *= s_comp_gain * s_duck_makeup_cur;
        r *= s_comp_gain * s_duck_makeup_cur;
    } else if (s_comp_gain != 1.0f || s_duck_makeup_cur != 1.0f) {
        /*
         * The knob has been taken to the bottom of its travel while the stage was
         * holding the signal down, and the stage at the bottom of the travel is
         * SKIPPED — which is a step from the gain in force to unity, the same click at
         * the other end of the knob. So the pole is allowed to run its course to unity
         * first and the multiplies are dropped for good once it has arrived: with the
         * gain at exactly one, `l * 1.0f` is `l` to the last bit, and the branch below
         * then costs one comparison per sample and nothing else.
         */
        s_comp_gain += (1.0f - s_comp_gain) * s_comp_glide;
        if (s_comp_gain > 0.9999f) {
            s_comp_gain = 1.0f;
        }

        s_duck_makeup_cur += (s_duck_makeup - s_duck_makeup_cur) * s_duck_makeup_glide;
        if (fabsf(s_duck_makeup_cur - 1.0f) < 1e-4f) {
            s_duck_makeup_cur = 1.0f;
        }

        /* Компенсация дакинга живёт и здесь: компрессор может быть выключен, а дакинг — нет. */
        l *= s_comp_gain * s_duck_makeup_cur;
        r *= s_comp_gain * s_duck_makeup_cur;
    }

    /* The master gain, one step of its pole per sample, landing exactly on the knob's
     * own number when the addition stops changing anything — a master that parks a few
     * ulp off the value the player set is a master that is not the number on the
     * screen. */
#if STAGE_TIMING
    const uint32_t stage_c1 = esp_cpu_get_cycle_count();
    s_stage_cycles_comp += stage_c1 - stage_c0;
#endif

    const float next = s_master_cur + (s_master - s_master_cur) * s_master_glide;
    s_master_cur = (next == s_master_cur) ? s_master : next;

    /* The boot fade, beside the master and after the compressor: the detector above sees
     * the signal the instrument makes, not the one the fade is letting through, and the
     * two gains multiply every sample exactly once. With boot_gain 1.0 this is the same
     * `l * s_master_cur` as before. */
    const float master = s_master_cur * boot_gain;

    out[0] = (int16_t)(soft_clip(l * master) * 32767.0f);
    out[1] = (int16_t)(soft_clip(r * master) * 32767.0f);

#if STAGE_TIMING
    s_stage_cycles_master += esp_cpu_get_cycle_count() - stage_c1;
#endif
}

/*
 * THE FUSE ON THE OUTPUT, AND THE RESCUE BEHIND IT.
 *
 * Arithmetic on this instrument has no notion of a bad number, and a bad number has no
 * notion of leaving: NaN times zero is NaN, every comparison against NaN is false, and the
 * one-poles that make the master gain, the faders, the compressor and the filters are all
 * `x += (target - x) * k`. One non-finite sample in any of them is therefore permanent —
 * the pole never moves again, the comparison that lands a value exactly on its target never
 * fires, and nothing the player can do from the control surface reaches it. That is the
 * failure that is cured by a power cycle and by nothing else.
 *
 * So the rack watches its own output. ONCE PER BLOCK, on the last mixed sample of each
 * channel, not per sample: everything that can STAY bad lives in a recursive state, so a
 * sample that poisoned one is followed by a poisoned sample at the end of the same block.
 * The compressor's gain and the master's are checked by name because they multiply the
 * sample after the check and would otherwise turn a finite block into a garbage one without
 * the mix ever seeing it. That is four compares in 5.33 ms, and the sample loop is untouched.
 *
 * What the rescue does NOT do is go quiet. A block of silence would be a hole in the
 * instrument, and the next block would start from zero at whatever level the patch is at —
 * both edges audible. Instead every module's recursive state is put back on its TARGETS:
 * the poles land on the numbers the knobs ask for, the filters drop only the charge they
 * held, and the effects' memories are cleared off the audio core by the tasks that already
 * own them. The block in progress is filled with the last output pair, which is the one
 * value in the whole path that is known to be good.
 */
static void rack_reset_state(void)
{
    /*
     * The rack's own poles, every one of them on the value its knob or send already says.
     * Nothing here is a decision: these are the numbers the next block was walking towards
     * anyway, installed in one go instead of a millisecond later.
     */
    s_master_cur = s_master;

    for (int i = 0; i < SYNTH_NUM_LAYERS; i++) {
        s_layer_level_cur[i] = s_layer_level[i];
        s_send_rev_cur[i] = s_send_rev[i];
        s_send_chr_cur[i] = s_send_chr[i];
        s_send_dly_cur[i] = s_send_dly[i];
    }

    s_reverb_mix_cur = s_reverb_mix;
    s_chorus_mix_cur = s_chorus_mix;
    s_delay_mix_cur  = s_delay_mix;

    /* The gate's ramp on the state the transport asks for, not on zero: a rescue during a
     * sounding note must not mute the note. */
    s_gate_gain = s_gate ? 1.0f : 0.0f;

    /* The duck's pole, on the target its own block loop would compute: the drum's published
     * envelope times the knob. A non-finite envelope cannot be allowed to become the target. */
    const float duck_env = synth_perc_env_published();
    s_duck_smooth = (s_duck > 0.0f && isfinite(duck_env)) ? s_duck * duck_env : 0.0f;
    s_duck_prev = 1.0f - s_duck_smooth;

    /*
     * The compressor. The gain in force goes to unity, which is the one gain that cannot
     * make the output worse, and the detector is zeroed rather than left holding a number
     * that is not a number: its curve is evaluated within sixteen samples and walks the
     * gain to the answer from there.
     */
    s_comp_env = 0.0f;
    s_comp_gain = 1.0f;
    s_comp_gain_to = 1.0f;
    s_comp_hp_xl = s_comp_hp_yl = 0.0f;
    s_comp_hp_xr = s_comp_hp_yr = 0.0f;
    s_comp_tick = 0;

    /*
     * And the modules below the rack. Their state is the part that cannot be reached from
     * here by arithmetic — integrators, delay lines, the reverb's tank — which is why each
     * one owns its own reset and this is the one place that calls them all.
     */
    synth_chorus_reset_state();
    synth_delay_reset_state();
    synth_reverb_reset_state();
    synth_plate_reset_state();
    synth_lead_filter_reset_state();
    synth_drone_filter_reset_state();
    synth_perc_reset_state();
}

/*
 * THE RESCUE'S RECORD, NOT ITS LINE. A rescue pins a snapshot and returns; the line is
 * printed by the statistics task from that snapshot. The audio task cannot afford the wait
 * a line costs — a blocking UART write measured 12-16 ms on this instrument against a
 * 2.67 ms block — so printing here made the report of a rescued block the cause of the
 * next missed deadline. The snapshot is the whole of the handover; the rate limit and the
 * text live in synth_app.cpp, on the task whose own print cannot drop a block.
 *
 * THE SAME PROCEDURE FOR BOTH FAILURES. A bad number and a silent output need exactly the
 * same cure — every pole and smoother on the value its knob already asks for, the effects'
 * memories cleared by the tasks that own them — and differ only in what the snapshot says.
 * The caller says which one it saw; the counters, the pinned snapshot and the serial are
 * shared, which is also what keeps the record in RTC memory one small struct.
 */
enum rescue_cause {
    RESCUE_NONFINITE = 0,
    RESCUE_SILENCE   = 1,
};

static void rack_rescue(int cause, bool bad_l, bool bad_r, float last_l, float last_r,
                        float silence_s)
{
    const uint32_t n = s_rescue_count + 1u;
    s_rescue_count = n;

    /*
     * The drone is the part that guarantees the instrument is audible: it is held for as
     * long as the transport runs, so its level is the number the watchdog's own condition
     * is read through. Summing the three faders here is three loads on a path that runs
     * once per rescue.
     */
    const float drone = s_layer_level[SYNTH_LAYER_DRONE_LOW]
                      + s_layer_level[SYNTH_LAYER_DRONE_MID]
                      + s_layer_level[SYNTH_LAYER_DRONE_HIGH];

    if (cause == RESCUE_SILENCE) {
        s_silence_count++;
    } else {
        s_nonfinite_count++;
    }

    /*
     * Pinned before the rescue moves any of these numbers: this is the state the failure
     * was seen in. The serial is published last, so a reader that compares it never takes
     * a half-written struct for a new one.
     */
    s_last_rescue.silence_count = s_silence_count;
    s_last_rescue.nonfinite_count = s_nonfinite_count;
    s_last_rescue.cause = (uint32_t)cause;
    /* The log's own clock, so the `previous boot` line can be read against the rescue line
     * in the journal rather than against a second time base. */
    s_last_rescue.uptime_ms = esp_log_timestamp();
    s_last_rescue.lasted_ms = (cause == RESCUE_SILENCE)
                                  ? (uint32_t)(silence_s * 1000.0f + 0.5f) : 0u;
    s_last_rescue.bad_l = bad_l ? 1u : 0u;
    s_last_rescue.bad_r = bad_r ? 1u : 0u;
    s_last_rescue.master = s_master_cur;
    s_last_rescue.comp = s_comp_gain;
    s_last_rescue.gate = s_gate_gain;
    s_last_rescue.duck = s_duck_smooth;
    s_last_rescue.drone = drone;
    s_last_rescue.last_l = last_l;
    s_last_rescue.last_r = last_r;
    for (int i = 0; i < SYNTH_NUM_LAYERS; i++) {
        s_last_rescue.layers[i] = s_layer_level[i];
    }
    /* Point-in-time copies: the delay's settings belong to the line, and the statistics
     * task has no business reading the delay's live state to find them. */
    s_last_rescue.delay_samples = synth_delay_time_samples();
    s_last_rescue.delay_fb = synth_delay_feedback();

    s_rescue_serial = s_rescue_serial + 1u;
    s_last_rescue.serial = s_rescue_serial;

    rack_reset_state();
}

/*
 * THE SILENCE WATCHDOG.
 *
 * A drone is not a note: it is held for as long as the transport runs, and its level is
 * the player's statement that it should be heard. So an output that is EXACTLY silent for
 * a second while the drone's levels are up and the gate is open is a failure of the kind
 * the non-finite fuse cannot see — every number in the path is still a number. The gate
 * may be stuck at zero, a level may have been zeroed behind its knob, the output stage may
 * have stopped producing samples.
 *
 * WHY THE OUTPUT AND NOT THE MIX. A zero at the mix before the master can still be made
 * audible by the master, and a master stuck at zero is one of the failures worth catching:
 * the test is on the samples that leave the rack, after the compressor, the master and the
 * clip.
 *
 * WHY 41 POINTS AND NOT 128 SAMPLES. The scope decimation below already reads 41 points of
 * the block, and their bitwise OR is the whole test. A silent block is zero at every one of
 * them; a block that is sounding cannot be exactly zero at 41 points spread over 2.7 ms,
 * let alone at 375 blocks in a row. The sample loop is not touched, and the cost is two ORs
 * per scope point — under a hundred integer operations per block, against a budget of
 * 5.33 ms.
 *
 * WHY A SECOND OF EXACT ZEROS AND NOT A LEVEL THRESHOLD. A threshold needs a reference and
 * a reference is wrong at some knob position: the instrument can legitimately be quiet. An
 * exact zero sustained for a second cannot be produced by a running drone at any level the
 * controls allow, and it is what a stuck gate, a zeroed gain and a dead output all look
 * like from here. Any nonzero sample, however small, restarts the count — the count is of
 * samples, not of blocks, so a block that is shorter than 128 cannot shorten the second.
 *
 * WHAT DOES NOT ARM IT, and all of these are states the instrument is allowed to be in:
 * the drone's faders at zero, the transport stopped, the gate closed, the master level at
 * zero, the first four seconds after the audio task starts — the effects are claiming
 * their memory there and the drone's 2.5 s attack is rising from zero, so a silent block is
 * expected rather than wrong — and the boot fade itself. The fade is the one silence that
 * is ASKED FOR: the rack is silent until main() says the boot is over, and a watchdog
 * that counted those samples would report the deliberate silence as a fault on exactly
 * the boots whose fade ran slow. The test is on the TARGETS the knobs and the transport
 * ask for, not on the smoothed values, so a fader on its way to zero silences the
 * watchdog at the same moment it silences the instrument.
 */
static bool silence_watch(uint32_t any_out, int samples, float *lasted_s)
{
    const uint64_t arm_at = (uint64_t)SYNTH_SAMPLE_RATE * SILENCE_ARM_S;

    if (s_watch_samples < arm_at) {
        s_watch_samples += (uint64_t)(unsigned)samples;
    }

    if (s_watch_samples < arm_at || !s_boot_done) {
        s_zero_samples = 0;
        return false;
    }

    const float drone = s_layer_level[SYNTH_LAYER_DRONE_LOW]
                      + s_layer_level[SYNTH_LAYER_DRONE_MID]
                      + s_layer_level[SYNTH_LAYER_DRONE_HIGH];

    /* Negated lower tests, as everywhere on this API: a non-number in any of these must
     * silence the watchdog rather than arm it. */
    const bool expect_sound = (s_transport != 0u) && s_gate && (s_master > 0.0f)
                              && (drone > 0.0f);

    if (any_out != 0u || !expect_sound) {
        s_zero_samples = 0;
        return false;
    }

    s_zero_samples += (uint32_t)(unsigned)samples;
    if (s_zero_samples < (uint32_t)SYNTH_SAMPLE_RATE * SILENCE_LIMIT_S) {
        return false;
    }

    *lasted_s = (float)s_zero_samples / (float)SYNTH_SAMPLE_RATE;
    s_zero_samples = 0;
    return true;
}

/* The states that multiply, or are multiplied by, every output sample. See rack_rescue(). */
IRAM_ATTR static inline bool rack_state_bad(void)
{
    return !isfinite(s_master_cur) || !isfinite(s_comp_gain) || !isfinite(s_gate_gain);
}

/*
 * The block itself, and the measurement around it.
 *
 * The work is in rack_process_block(); synth_rack_process() below is the published entry
 * point, which is where the stage timing wraps the whole block — a wrapper rather than a
 * timer at the top and bottom of the body, because the body returns from six places (the
 * dry path, two rescues) and a stage that is published on five of them is worse than no
 * measurement at all.
 */
IRAM_ATTR /*
 * ВТОРАЯ ПОЛОВИНА БЛОКА, ОТДЕЛЬНОЙ ФУНКЦИЕЙ.
 *
 * Всё, что происходит после того, как сухая пара, посыл реверба и входы хоруса и дилея
 * собраны и закрыты заслонкой: три возврата, мастер, клип, компрессор, осциллограф и сторож.
 * Шов здесь не выдуман ради красоты: хвост и так читал и писал только эти буферы, и функция
 * просто называет то, что было правдой.
 *
 * Зачем называть: это единственная половина блока, которую можно отдать другому ядру, не
 * меняя ни одного числа. Она не читает ни одного состояния движка и не пишет ни в один буфер
 * слоёв — только в свой выход.
 */
static void rack_fx_section(int samples, int16_t *out_stereo,
                            bool chr_run, bool dly_run, bool rev_run,
                            FxBuffers *fx)
{
/*
 * The three returns, in PARALLEL, and the dry crossfade that lets each of them take the
 * dry's place rather than sit beside it. See THE DRY CROSSFADE near the top of the file
 * for the amounts and the curve; what is applied here is the second half of it.
 *
 * The two compensated returns carry a fixed gain: measured against a fully open send,
 * the room's answer lands 11 dB under the dry and the delay's 3 to 4 dB under it, and a
 * crossfade against an answer that quiet would fade into a hole. The gain is what makes
 * the crossfade a replacement. The chorus is untouched: it was not part of the report and
 * its answer already arrives at the dry's own level, so nothing needs compensating and
 * no crossfade was asked for.
 *
 * A module whose return is at zero is not called at all, and that is the point of the
 * gates at the top of this block: with nothing to add there is nothing to compute, and
 * an effect that is only ever asked to deliver silence costs no line of PSRAM.
 */
if (chr_run) {
#if STAGE_TIMING
    const int64_t t_s_chr = esp_timer_get_time();
#endif
    synth_fx_machine_process(samples, fx->chr_l, fx->chr_r);

    /* Хвост эффект-машины в реверб, как у дилея: хорус в комнате — это и есть даб. */
    if (rev_run && s_fx_verb > 0.0f) {
        for (int i = 0; i < samples; i++) {
            fx->send[i] += (fx->chr_l[i] + fx->chr_r[i]) * 0.5f * s_fx_verb;
        }
    }
#if STAGE_TIMING
    s_stage_blk.chorus += stage_elapsed(t_s_chr);
#endif
}
if (dly_run) {
#if STAGE_TIMING
    const int64_t t_s_dly = esp_timer_get_time();
#endif
    synth_delay_process(samples, fx->dly_l, fx->dly_r);

    /*
     * ХВОСТ ДИЛЕЯ В РЕВЕРБ. Дилей в стойке стоит перед ревербом, поэтому добавка в его шину
     * попадает в комнату в этом же блоке. Сумма моно, как и у посылов слоёв: комната сама
     * делает стерео, и широкий источник не должен становиться шире.
     */
    if (rev_run && s_delay_verb > 0.0f) {
        for (int i = 0; i < samples; i++) {
            fx->send[i] += (fx->dly_l[i] + fx->dly_r[i]) * 0.5f * s_delay_verb;
        }
    }
#if STAGE_TIMING
    s_stage_blk.delay += stage_elapsed(t_s_dly);
#endif
}
if (rev_run) {
#if STAGE_TIMING
    const int64_t t_s_rev = esp_timer_get_time();
#endif
    synth_reverb_process(samples, fx->send, fx->wet_l, fx->wet_r);
#if STAGE_TIMING
    s_stage_blk.reverb += stage_elapsed(t_s_rev);
#endif
}
#if STAGE_TIMING
const int64_t t_s_ret = esp_timer_get_time();
#endif
for (int i = 0; i < samples; i++) {
    /*
     * Each return on its own smoothed factor, which was stepped at the top of the summing
     * loop: the crossfade there already read it, and a second step here would put the dry
     * and the wet a block apart.
     *
     * The sum goes back into the dry pair rather than straight into the output: with the
     * drive after the effects this is what it has to treat, and the pair has done its job
     * by now — the three buses were taken from it before the effects ran.
     */
    float l = fx->dry_l[i];
    float r = fx->dry_r[i];

    if (chr_run) {
        l += fx->chr_l[i] * s_chorus_mix_cur;
        r += fx->chr_r[i] * s_chorus_mix_cur;
    }
    if (dly_run) {
        l += fx->dly_l[i] * s_delay_mix_cur * DELAY_RETURN_GAIN;
        r += fx->dly_r[i] * s_delay_mix_cur * DELAY_RETURN_GAIN;
    }
    if (rev_run) {
        l += fx->wet_l[i] * s_reverb_mix_cur * s_reverb_ret_gain;
        r += fx->wet_r[i] * s_reverb_mix_cur * s_reverb_ret_gain;
    }

    fx->dry_l[i] = l;
    fx->dry_r[i] = r;
}
#if STAGE_TIMING
s_stage_blk.gate += stage_elapsed(t_s_ret);
#endif

/*
 * THE FUSE. Four compares, once, at the point where the dry path and the three returns
 * have become one signal — and before that signal is either driven or clipped, because
 * both of those would only carry a bad number further.
 *
 * The last sample is the probe and not a scan of the block: every state that can keep a
 * bad number is recursive, so a block that was poisoned anywhere in the middle is still
 * poisoned at its end. A bad number that does NOT survive to the end has poisoned no
 * state and has cost one sample, which is the one case this is not here for.
 *
 * The compressor's gain and the master's are named separately because they multiply the
 * sample after this test: with either of them bad, the mix above is perfectly finite and
 * the output would still be garbage.
 */
{
    const float tail_l = fx->dry_l[samples - 1];
    const float tail_r = fx->dry_r[samples - 1];
    const bool bad_l = !isfinite(tail_l);
    const bool bad_r = !isfinite(tail_r);

    if (bad_l || bad_r || rack_state_bad()) {
        rack_rescue(RESCUE_NONFINITE, bad_l, bad_r, tail_l, tail_r, 0.0f);

        /* The block in progress is the one the bad number reached. Hold it at the last
         * pair that is known to be good rather than dropping to silence. */
        for (int i = 0; i < samples; i++) {
            out_stereo[i * 2] = s_hold_l;
            out_stereo[i * 2 + 1] = s_hold_r;
        }
#if CONFIG_OBOD_STRESS
        stress_observe(out_stereo, samples);
#endif
        return;
    }
}

for (int i = 0; i < samples; i++) {
    rack_out(fx->dry_l[i], fx->dry_r[i], boot_gain_sample(i), &out_stereo[i * 2]);
}

#if CONFIG_OBOD_STRESS
stress_observe(out_stereo, samples);
#endif

/* The last good pair, for the block a rescue has to fill. Two loads a block. */
s_hold_l = out_stereo[(samples - 1) * 2];
s_hold_r = out_stereo[(samples - 1) * 2 + 1];

/*
 * The block as a picture, for the page that shows the master's waveform.
 *
 * It is taken from out_stereo rather than from the dry mix on purpose: the level, the
 * compressor and the reverb balance are already in it, and the display has no business
 * showing a sound the instrument is not making. The back buffer is filled and then the
 * front is flipped, so a reader can never see half of one block and half of the next.
 */
{
    const int back = 1 - s_scope_front;
    uint32_t any_out = 0;

    for (int i = 0; i < SYNTH_SCOPE_POINTS; i++) {
        const int idx = (i * samples) / SYNTH_SCOPE_POINTS;
        const int16_t sl = out_stereo[idx * 2];
        const int16_t sr = out_stereo[idx * 2 + 1];

        /* The watchdog's whole reading of this block: see silence_watch(). */
        any_out |= (uint32_t)(uint16_t)sl | (uint32_t)(uint16_t)sr;

        const float l = (float)sl * (1.0f / 32768.0f);
        const float r = (float)sr * (1.0f / 32768.0f);
        s_scope[back][i] = 0.5f * (l + r);
    }

    s_scope_front = back;

    /* After the scope, so the picture of the block is the block that was played; the
     * rescue moves the state the NEXT block starts from. */
    float lasted_s = 0.0f;
    if (silence_watch(any_out, samples, &lasted_s)) {
        rack_rescue(RESCUE_SILENCE, false, false, 0.0f, 0.0f, lasted_s);
    }
}
}

#if RACK_FX_TASK

/*
 * ВТОРАЯ ПОЛОВИНА НА ВТОРОМ ЯДРЕ, БЕЗ ЕДИНОГО ОЖИДАНИЯ.
 *
 * Снимок и готовые блоки живут отдельно. `s_fx_todo` — снимок лежит, `s_fx_free` — снимок
 * свободен. Готовые блоки складываются в кольцо из четырёх: задача публикует блок только
 * целиком, звук берёт самый свежий и никогда не ждёт. Если задача опоздала, повторяется
 * предыдущий блок — это тише и короче провала в постоянную, который был здесь раньше.
 *
 * Кольцо из четырёх, а не из двух: задача производит не больше одного блока на снимок, то
 * есть отстаёт не больше чем на блок, и перезаписи читаемого буфера не бывает по построению.
 */
#define FX_RING 4

static TaskHandle_t      s_fx_task;
static SemaphoreHandle_t s_fx_todo;
static SemaphoreHandle_t s_fx_free;

static FxBuffers s_fx_work;                        /* снимок, с которым работает задача */
static int16_t   s_fx_out[FX_RING][SYNTH_BLOCK_SAMPLES * 2];
static volatile int  s_fx_write;                   /* сколько блоков задача уже посчитала */
static volatile int  s_fx_read;                     /* сколько из них забрал звук */
static volatile int  s_fx_samples;
static volatile bool s_fx_chr;
static volatile bool s_fx_dly;
static volatile bool s_fx_rev;
static volatile uint32_t s_fx_late;                 /* блоков, которых не дождались */
static volatile uint32_t s_fx_late_run;             /* из них подряд */
static volatile uint32_t s_fx_late_max;             /* самая длинная серия подряд */
static bool              s_fx_off;                  /* конвейер снят: считаем на месте */
static volatile int32_t  s_fx_hold;                 /* сколько блоков считать на месте после срыва */

static void rack_fx_task(void *arg)
{
    (void)arg;

    for (;;) {
        if (xSemaphoreTake(s_fx_todo, portMAX_DELAY) != pdTRUE) {
            continue;
        }

        const int n = s_fx_samples;
        const bool c = s_fx_chr;
        const bool d = s_fx_dly;
        const bool r = s_fx_rev;

        /* Снимок к себе, и сразу отпустить: дальше он нам не нужен. */
        memcpy(&s_fx_work, &s_fx, sizeof(FxBuffers));
        xSemaphoreGive(s_fx_free);

        const int b = s_fx_write % FX_RING;
        rack_fx_section(n, s_fx_out[b], c, d, r, &s_fx_work);

        /* Публикация — после того как блок целиком посчитан. */
        s_fx_write = s_fx_write + 1;
    }
}

static void rack_fx_start(void)
{
    s_fx_todo = xSemaphoreCreateBinary();
    s_fx_free = xSemaphoreCreateBinary();

    if (!s_fx_todo || !s_fx_free) {
        return;
    }

    /* Первый снимок класть можно сразу. */
    xSemaphoreGive(s_fx_free);

    /*
     * Приоритет выше интерфейса: хвост короткий (около 1.7 мс из 5.3), и если его вытеснит
     * отрисовка кадра, звук получит повтор блока. Ядро нулевое — там же, где интерфейс:
     * звук на первом ядре не трогается вовсе.
     */
    if (xTaskCreatePinnedToCore(rack_fx_task, "obod_fx", 4096, NULL, 20, &s_fx_task, 0) != pdPASS) {
        s_fx_task = NULL;
    }
}

#endif /* RACK_FX_TASK */
/*
 * Сколько блоков хвоста не дождались. Ноль означает, что конвейер не потерял ни одного блока
 * и треск, если он есть, приходит не отсюда.
 */
uint32_t synth_rack_fx_late(void)
{
#if RACK_FX_TASK
    return s_fx_late;
#else
    return 0u;
#endif
}

/* Самая длинная серия повторов подряд: сорок — это уже снятый конвейер. */
uint32_t synth_rack_fx_late_max(void)
{
#if RACK_FX_TASK
    return s_fx_late_max;
#else
    return 0u;
#endif
}


static void rack_process_block(int samples, int16_t *out_stereo)
{
    if (samples <= 0 || !out_stereo) {
        return;
    }
    if (samples > SYNTH_BLOCK_SAMPLES) {
        samples = SYNTH_BLOCK_SAMPLES;
    }

    /* The boot clock runs on every path, including the dry one and the two rescues: a
     * block rendered while the gate is shut still belongs to the instrument's timeline,
     * and the fade must not wait for a note to be played before it starts. */
    boot_gate_prepare(samples);

    if (!s_scratch && s_want_fx) {
        claim_scratch();
    }

    /*
     * The gate's ramp, stepped once per sample by every path below. The coefficient is
     * the exact one-pole step for the time constant, 1 - exp(-dt/tau), computed once per
     * block rather than once per sample — the same arithmetic the lead filter's own
     * smoother uses, and the same reason: the exponential is the only part that costs
     * anything, and it does not depend on the sample.
     *
     * The direction is settled for the whole block from the target, because that is the
     * only thing the ramp is walking towards: a block cannot be opening and closing.
     */
    const float gate_target = s_gate ? 1.0f : 0.0f;
    const float gate_tau = (gate_target > 0.0f) ? GATE_OPEN_TAU_S : GATE_CLOSE_TAU_S;
    const float gate_coef = 1.0f - expf(-1.0f / (gate_tau * (float)SYNTH_SAMPLE_RATE));

    if (!s_scratch) {
        /* Nothing asked for an effect, or there was no room for the scratch. The
         * instrument still plays: losing the reverb is a far better failure than
         * losing the output. There is no rack to ring on in this path, so a closed
         * gate is simply silence — and it is silence only once the ramp has arrived
         * there, which is what the second half of the test waits for. */
        if (!(gate_target > 0.0f) && !(s_gate_gain > 0.0f)) {
            for (int i = 0; i < samples; i++) {
                out_stereo[i * 2] = 0;
                out_stereo[i * 2 + 1] = 0;
            }
            /* Silence the instrument asked for, not a fault: the watchdog starts over. */
            s_zero_samples = 0;
#if CONFIG_OBOD_STRESS
            stress_observe(out_stereo, samples);
#endif
            return;
        }

        /*
         * The fuse, before the block rather than after it: this path has no buffers to scan
         * and only the two gains that multiply every sample, so there is nothing to detect
         * at the end that could not be seen at the start. A layer buffer that goes bad here
         * poisons nothing — this path has no recursive state but these gains — and the
         * engine's own state is not the rack's to clear.
         */
        if (rack_state_bad()) {
            rack_rescue(RESCUE_NONFINITE, false, false, 0.0f, 0.0f, 0.0f);

            for (int i = 0; i < samples; i++) {
                out_stereo[i * 2] = s_hold_l;
                out_stereo[i * 2 + 1] = s_hold_r;
            }
#if CONFIG_OBOD_STRESS
            stress_observe(out_stereo, samples);
#endif
            return;
        }

        uint32_t any_out = 0;

        /*
         * ЧТО НЕ ЗАВИСИТ ОТ СЭМПЛА — ИЗ ЦИКЛА.
         *
         * Здесь стояли synth_layer_l(layer)[i] и synth_layer_r(layer)[i]: функции из
         * synth_layers.cpp, а LTO в этой сборке нет, поэтому это двадцать настоящих
         * вызовов на каждый сэмпл — три тысячи на блок — за указателями на буферы,
         * которые внутри блока не двигаются. Рядом, в мокром пути, такая же правка была
         * сделана раньше, и там цикл давно читает готовые указатели.
         *
         * Уровни тоже не меняются внутри блока: все сеттеры вызываются из звуковой задачи
         * между блоками, поэтому снимок на входе и запись назад после цикла — это те же
         * числа, что читались бы каждый сэмпл. Порядок сложения прежний, поэтому сумма
         * выходит бит в бит та же.
         */
        float *lay_l[SYNTH_NUM_LAYERS];
        float *lay_r[SYNTH_NUM_LAYERS];
        float  lay_gain[SYNTH_NUM_LAYERS];

        for (int k = 0; k < SYNTH_NUM_LAYERS; k++) {
            lay_l[k] = synth_layer_l(k);
            lay_r[k] = synth_layer_r(k);
            lay_gain[k] = s_layer_level[k];
        }

#if STAGE_TIMING
        const int64_t t_s_dry = esp_timer_get_time();
#endif
        for (int i = 0; i < samples; i++) {
            s_gate_gain = gate_step(s_gate_gain, gate_coef, gate_target);

            float l = 0.0f;
            float r = 0.0f;

            for (int layer = 0; layer < SYNTH_NUM_LAYERS; layer++) {
                const float level = lay_gain[layer];
                l += lay_l[layer][i] * level;
                r += lay_r[layer][i] * level;
            }

            rack_out(l * s_gate_gain, r * s_gate_gain, boot_gain_sample(i),
                     &out_stereo[i * 2]);

            any_out |= (uint32_t)(uint16_t)out_stereo[i * 2]
                     | (uint32_t)(uint16_t)out_stereo[i * 2 + 1];
        }
#if STAGE_TIMING
        /* The dry path is summing, gate, master and clip with no effects in it; the
         * compressor's share arrived from rack_out()'s own counter. */
        s_stage_blk.sum += stage_elapsed(t_s_dry);
#endif

        s_hold_l = out_stereo[(samples - 1) * 2];
        s_hold_r = out_stereo[(samples - 1) * 2 + 1];

        /* This path is taken only when nothing has asked for an effect, but the silence it
         * can fall into is the same one: the same watchdog, the same rescue. It reads the
         * block it has already written rather than a second pass, which is why the OR above
         * is in the output loop. */
        float lasted_s = 0.0f;
        if (silence_watch(any_out, samples, &lasted_s)) {
            rack_rescue(RESCUE_SILENCE, false, false, 0.0f, 0.0f, lasted_s);
        }
#if CONFIG_OBOD_STRESS
        stress_observe(out_stereo, samples);
#endif
        return;
    }

    /*
     * THE RETURN GATES, settled once for the block.
     *
     * An effect whose return level is zero is not part of the chain this block: its bus is
     * not summed, it is not handed to its module, and its answer is not added. That is the
     * whole difference between a knob at zero and a knob at zero that still costs a delay
     * line of PSRAM read and rewritten every 2.7 ms — the price the prefetch made permanent.
     *
     * The level IN FORCE decides, not the target, so a return on its way down keeps being
     * heard for the 15 ms of its glide and only then stops. The rising edge is also where
     * the module's memory is put back to a clean line: the delay's and the chorus's lines
     * hold the last signal they were fed, and a return that came back would otherwise open
     * on a phrase from the moment it was switched off. The reverb and the plate are not
     * reset here: their tails already hold their own decay, which is what a room does when
     * the return is lowered — resuming it is not garbage, it is the room.
     */
    const bool chr_run = (s_chorus_mix > 0.0f) || (s_chorus_mix_cur > MIX_OFF_FLOOR);
    const bool dly_run = (s_delay_mix > 0.0f) || (s_delay_mix_cur > MIX_OFF_FLOOR);
    const bool rev_run = (s_reverb_mix > 0.0f) || (s_reverb_mix_cur > MIX_OFF_FLOOR);

    /*
     * A bus is summed only if its effect runs AND some part actually sends to it. Both halves
     * are decided once per block, on numbers the sample loop does not change, so the loop's
     * test is the same for every one of its samples: the parts that send nothing cost nothing
     * and the samples that do not need the sum do not pay for it either.
     *
     * The level test cannot be left to the multiply. A part at a level of zero contributes a
     * zero, which is free — but a bus nobody sends to would still be summed sample by sample
     * for an effect that hears nothing, and that is nine multiply-adds a sample of a chain
     * that is already at its budget. What it must NOT do is skip the WRITE below: a bus that
     * is not summed still has to be handed zeros, or the effect processes whatever the last
     * block left there.
     */
    const bool rev_send = rev_run && sends_live(s_send_rev, s_send_rev_cur);
    const bool chr_send = chr_run && sends_live(s_send_chr, s_send_chr_cur);
    const bool dly_send = dly_run && sends_live(s_send_dly, s_send_dly_cur);

    if (chr_run) {
        if (!s_chorus_run) {
            /* The return has come up from zero: the module stops reading its line until the
             * tap has been written over with what is being played now, instead of opening on
             * the forty milliseconds it was left holding. See synth_fx_chorus.cpp. */
            synth_chorus_restart();
        }
    }
    if (dly_run) {
        if (!s_delay_run) {
            /* The same, and this is the one that matters: a delay line holds seconds, and a
             * return that came back would otherwise replay a phrase from before it was
             * switched off. One store, where clearing the line is a megabyte and a half. */
            synth_delay_restart();
        }
    }

    s_chorus_run = chr_run;
    s_delay_run = dly_run;

    /*
     * The gate is applied here, at the rack's input, and not on the master gain
     * further down. That is what lets STOP silence the generators while the
     * effects keep ringing: what is already in the delay lines and the reverb
     * combs decays out on its own instead of being cut off with the source.
     *
     * The test is on the RAMP and not on the switch: a gate that has been asked to
     * close is still passing signal on its way down, and a block's worth of that signal
     * is 2.7 ms of the 34 the ramp takes.
     */
    if (gate_target > 0.0f || s_gate_gain > 0.0f) {
        /* До суммы, раз в блок: дакинг теперь на всех слоях — низ, середина, верх и лид.
         * Раньше он трогал только LOW и половину MID и оставлял верх и лид звучать поверх
         * удара; на плотном миксе это и было «не хватает удара». */
        /*
         * ФИЛЬТР ЛИДА — НА СУММЕ СЛОЯ, ДО ПОСЫЛОВ И ДО ДАКА.
         *
         * Панорама каждой ноты уже поставлена захватами на шинах аккорда, поэтому слой лида к
         * этому месту собран. Фильтр линейный, значит «отфильтровать сумму» — то же, что
         * «сложить отфильтрованное», только копий две (левый и правый канал) вместо трёх-четырёх
         * шин. Срез нулевой — фильтра нет, вызов стоит одно сравнение.
         */
        synth_lead_filter_layer(synth_layer_l(SYNTH_LAYER_LEAD), synth_layer_r(SYNTH_LAYER_LEAD),
                                samples);

        /*
         * Дрон отступает под линию. Множитель один на блок и применяется к трём буферам
         * дрона до суммы — ни одной ветви в горячем цикле, полторы тысячи умножений.
         */
        s_lead_gain = lead_duck_gain(samples);

        if (s_lead_gain < 0.999f) {
            static const int drone_layers[3] = {
                SYNTH_LAYER_DRONE_LOW, SYNTH_LAYER_DRONE_MID, SYNTH_LAYER_DRONE_HIGH,
            };

            for (int d = 0; d < 3; d++) {
                float *dl = synth_layer_l(drone_layers[d]);
                float *dr = synth_layer_r(drone_layers[d]);

                for (int i = 0; i < samples; i++) {
                    dl[i] *= s_lead_gain;
                    dr[i] *= s_lead_gain;
                }
            }
        }

        const float duck_low = duck_low_gain(samples);

        /* The block's gain is walked to, not stepped to: a gain that changes only at block
         * boundaries is a train of clicks at the block rate, and no amount of smoothing the
         * control itself removes them. */
        const float duck_from = s_duck_prev;
        const float duck_span = duck_low - duck_from;

#if STAGE_TIMING
        const int64_t t_s_sum = esp_timer_get_time();
#endif
        /*
         * WHAT DOES NOT DEPEND ON THE SAMPLE IS TAKEN OUT OF THE LOOP, and every one of these
         * is the same expression on the same numbers as before — only evaluated once for the
         * block instead of 256 times:
         *
         *   - the ten layer pointers. synth_layer_l()/r() live in another translation unit and
         *     nothing inlines them (there is no LTO in this build), so the loop was paying
         *     twenty calls a sample just to read two buffers that cannot move;
         *
         *   - the four faders' glide state and their targets, held in registers for the block
         *     and written back once. The step is still `cur += (target - cur) * glide` per
         *     sample on the same 32-bit floats, so the trajectory is bit for bit the one it
         *     was; a setter cannot land inside the block, because they are all called from
         *     the audio task, between blocks — the same reason nothing here takes a lock;
         *
         *   - the returns' three poles, for the same reason: they are read once more far below,
         *     in the returns sum, and the values written back are the ones that sum expects;
         *
         *   - the duck's span as a reciprocal. The division was per sample, and the duck
         *     touches two of the five layers, so it was paid once for each of them.
         *     Multiplying by 1/span differs from the division on 126 of the ramp's 256
         *     points, by one unit in the last place of a product that is then added to a
         *     number near one — and in the host render that place never reached the mix: the
         *     drum sounding at full duck depth, the whole patch moving, 614400 frames came
         *     out identical bit for bit, 0 samples different.
         *
         *   - the duck's two factors themselves, which are one number and its half-depth
         *     partner, computed once a sample instead of once a layer.
         */
        float *lay_l[SYNTH_NUM_LAYERS];
        float *lay_r[SYNTH_NUM_LAYERS];
        for (int k = 0; k < SYNTH_NUM_LAYERS; k++) {
            lay_l[k] = synth_layer_l(k);
            lay_r[k] = synth_layer_r(k);
        }

        const float glide = s_level_glide;
        const float inv_span = 1.0f / (float)((samples > 1) ? (samples - 1) : 1);

        float tgt_lvl[SYNTH_NUM_LAYERS], tgt_rev[SYNTH_NUM_LAYERS];
        float tgt_chr[SYNTH_NUM_LAYERS], tgt_dly[SYNTH_NUM_LAYERS];
        float lvl[SYNTH_NUM_LAYERS], rev[SYNTH_NUM_LAYERS];
        float chr[SYNTH_NUM_LAYERS], dly[SYNTH_NUM_LAYERS];

        for (int k = 0; k < SYNTH_NUM_LAYERS; k++) {
            tgt_lvl[k] = s_layer_level[k];
            tgt_rev[k] = s_send_rev[k];
            tgt_chr[k] = s_send_chr[k];
            tgt_dly[k] = s_send_dly[k];
            lvl[k] = s_layer_level_cur[k];
            /* Сайдчейн посылов: на пике удара хвосты уступают место. */
    const float side_gain = 1.0f - s_side * s_duck_smooth;

    rev[k] = s_send_rev_cur[k] * side_gain;
            chr[k] = s_send_chr_cur[k];
            dly[k] = s_send_dly_cur[k];
        }

        float pre_lvl[SYNTH_NUM_LAYERS], pre_dry[SYNTH_NUM_LAYERS];
        float pre_rev[SYNTH_NUM_LAYERS], pre_chr[SYNTH_NUM_LAYERS];
        float pre_dly[SYNTH_NUM_LAYERS];
        /*
         * СПИСОК ЗВУЧАЩИХ СЛОЁВ.
         *
         * Шесть слоёв умножаются и складываются в каждом сэмпле, но слой, у которого и
         * уровень, и все три посыла нулевые, добавляет ровно ноль — и всё равно стоит
         * умножения и сложения. На плотном патче (бас, лид, три регистра дрона) таких
         * слоёв два-три, и это около полутораста микросекунд блока, которых на пределе
         * не хватает. Список собирается раз в блок вместе с остальными величинами, так
         * что поведение не меняется: слой, поднявшийся с нуля, зазвучит со следующего
         * блока — как и раньше, потому что эти множители и были постоянными блока.
         */
        int plain[SYNTH_NUM_LAYERS];
        int plain_n = 0;
        bool bass_on = false;
        bool aux_on = false;

        for (int k = 0; k < SYNTH_NUM_LAYERS; k++) {
            if (pre_lvl[k] == 0.0f && pre_dry[k] == 0.0f && pre_rev[k] == 0.0f
                && pre_chr[k] == 0.0f && pre_dly[k] == 0.0f) {
                continue;
            }

            if (k == SYNTH_LAYER_BASS) {
                bass_on = true;
            } else if (k == SYNTH_LAYER_AUX) {
                aux_on = true;
            } else {
                plain[plain_n++] = k;
            }
        }

        float rev_mix_cur = s_reverb_mix_cur;
        float dly_gain = 1.0f;   /* вилка дилея: считается в сэмпле, читается свёрткой */
        float chr_mix_cur = s_chorus_mix_cur;
        float dly_mix_cur = s_delay_mix_cur;

        /*
         * КОЭФФИЦИЕНТЫ СЛОЯ — РАЗ В ВОСЕМЬ СЭМПЛОВ.
         *
         * Уровень слоя и его посылы ползут глайдом с постоянной времени в полторы
         * миллисекунды: за восемь сэмплов они меняются на сотую долю хода. Считать их в
         * каждом сэмпле — это шесть слоёв по шесть произведений на сэмпл, самая дорогая
         * работа во всей сумме. Здесь они свёрнуты в готовые числа, а в цикле остаётся
         * умножение сигнала на готовое.
         */
        auto precompute_layer_gains = [&](void) {
            for (int k = 0; k < SYNTH_NUM_LAYERS; k++) {
                const float rev_a = rev[k] * rev_mix_cur;
                const float rev_sq = rev_a * rev_a;

                pre_lvl[k] = lvl[k];
                pre_dry[k] = lvl[k] * (1.0f - rev_sq * rev_sq) * dly_gain;
                pre_rev[k] = lvl[k] * rev[k] * 0.5f;
                pre_chr[k] = lvl[k] * chr[k];
                pre_dly[k] = lvl[k] * dly[k];
            }
        };

        /*
         * СТОЯТ ЛИ ФЕЙДЕРЫ.
         *
         * Двадцать четыре шага глида на сэмпл — это шесть тысяч умножений-сложений на блок,
         * и в обычной игре они считают за ничем: ручку не крутят, все текущие значения уже
         * дошли до целей. Здесь это выясняется один раз на блок, и если двигать нечего, шаг
         * пропускается целиком. Остаток глида при таком пропуске — меньше миллионной доли
         * усиления (минус сто двадцать децибел), и стенд проверяет, что на выходе от этого
         * не меняется ни один сэмпл.
         */
        bool faders_moving = false;

        for (int k = 0; k < SYNTH_NUM_LAYERS; k++) {
            const float d = fabsf(tgt_lvl[k] - lvl[k]) + fabsf(tgt_rev[k] - rev[k])
                          + fabsf(tgt_chr[k] - chr[k]) + fabsf(tgt_dly[k] - dly[k]);

            if (d > 1e-6f) {
                faders_moving = true;
                break;
            }
        }

        /* Дилей берёт самый громкий посыл; пока фейдеры стоят, он тоже не меняется. */
        float dly_max_const = 0.0f;

        if (!faders_moving) {
            for (int k = 0; k < SYNTH_NUM_LAYERS; k++) {
                if (dly[k] > dly_max_const) {
                    dly_max_const = dly[k];
                }
            }
        }

        /*
         * САМЫЙ ГРОМКИЙ ПОСЫЛ В ДИЛЕЙ — НА ВЕСЬ БЛОК.
         *
         * Он читается ниже в каждом сэмпле и задаёт, насколько широка вилка дилея. Пока глайд
         * шёл в каждый сэмпл, величина обновлялась там же. Когда глайд стал шагать раз в восемь
         * сэмплов, она осталась посепмпльной — и на семи сэмплах из восьми обнулялась: посыл в
         * дилей и сухой путь гейтились на шести килогерцах. Владелец услышал это как цифровой
         * шум и резонанс при посыле баса в дилей. Теперь величина живёт весь блок.
         */
        float dly_max = dly_max_const;

        for (int i = 0; i < samples; i++) {
            float l = 0.0f;
            float r = 0.0f;
            float raw_l = 0.0f;     /* the same sum before the crossfade, for the delay's input */
            float raw_r = 0.0f;
            float send = 0.0f;      /* the reverb's bus, mono */

            /*
             * ШАГ ГЛАЙДА — ВОСЕМЬ СЭМПЛОВ, А НЕ ОДИН.
             *
             * Двадцать четыре однополюсника в каждый сэмпл при постоянной времени в полторы
             * миллисекунды: шаг в восемь сэмплов опаздывает на сто шестьдесят шесть
             * микросекунд, то есть на сотую долю хода фейдера. На слух не читается, а работы
             * в восемь раз меньше. Между шагами величины держатся.
             */
            if (faders_moving && (i & 7) == 0) {
                dly_max = 0.0f;
                for (int k = 0; k < SYNTH_NUM_LAYERS; k++) {
                    lvl[k] += (tgt_lvl[k] - lvl[k]) * glide;
                    rev[k] += (tgt_rev[k] - rev[k]) * glide;
                    chr[k] += (tgt_chr[k] - chr[k]) * glide;
                    dly[k] += (tgt_dly[k] - dly[k]) * glide;
                    if (dly[k] > dly_max) {
                        dly_max = dly[k];
                    }
                }
            }

            /*
             * The returns' own poles, stepped HERE rather than at the summing point below.
             * The crossfade reads the same number the wet will be scaled by, so a return on
             * the move cannot duck the dry to a level the wet has not reached yet — the
             * amount is one value, read once, used twice. The poles still run when the gate
             * is closed; see the block below.
             */
            rev_mix_cur = mix_step(rev_mix_cur, s_reverb_mix, s_reverb_mix_glide);
            chr_mix_cur = mix_step(chr_mix_cur, s_chorus_mix, s_chorus_mix_glide);
            dly_mix_cur = mix_step(dly_mix_cur, s_delay_mix, s_delay_mix_glide);

            /* The delay's crossfade: one amount for the bus, because the delay is one place
             * on the bus rather than a send per layer. */
            const float dly_a = dly_max * dly_mix_cur;
            const bool need_raw = (dly_a > 0.0f);
            const float dly_sq = dly_a * dly_a;
            dly_gain = 1.0f - dly_sq * dly_sq;

            /* Коэффициенты слоёв пересобираются там же, где идут глайды: раз в восемь сэмплов. */
            if ((i & 7) == 0) {
                precompute_layer_gains();
            }



            /*
             * ДАКИНГ НА ВСЁ, кроме самого удара.
             *
             * Раньше он трогал LOW целиком и MID на 70 %, а верх и лид не трогал вовсе. На
             * плотном миксе этого мало: кик уступает место только в теле, а верх дрона и
             * лид продолжают звучать поверх удара, и удар читается хуже, чем есть. Владелец
             * попросил распространить на все регистры и на лиды — здесь это один множитель
             * на все слои.
             *
             * Барабан сюда не попадает: он прибавляется к сухой сумме ниже, после этого
             * множителя, поэтому дакинг двигает всё, КРОМЕ того, что его открыло. Это не
             * тонкость реализации, а условие, без которого эффект не имеет смысла.
             *
             * Рампа — одна на сэмпл, как и была: duck_from + duck_span * i/span.
             */
            const float duck = duck_from + duck_span * ((float)i * inv_span);

            /*
             * БАС УСТУПАЕТ УДАРУ ГЛУБЖЕ ОСТАЛЬНЫХ.
             *
             * Дакинг умножал все шесть слоёв и раньше, но с одной глубиной, а она ограничена
             * тридцатью процентами хода — на басовой линии это слышно как «дакинг её не
             * трогает». Здесь у баса и микрофонного входа вдвое большая глубина и пол в
             * двадцать процентов: сцепка бочки с басом, из-за которой удар и читается.
             */
            float duck_bass = 1.0f - (1.0f - duck) * 2.0f;

            if (duck_bass < 0.2f) {
                duck_bass = 0.2f;
            }

            float cl = 0.0f;        /* the chorus's, stereo */
            float cr = 0.0f;
            float dl = 0.0f;        /* the delay's, stereo */
            float dr = 0.0f;

            /*
             * ОБЫЧНЫЕ СЛОИ — ОДНИМ ЦИКЛОМ, БЕЗ ВЕТВЕЙ ПО СЛОЮ.
             *
             * Раньше на каждом слое на каждом сэмпле проверялось «это бас?», «это
             * микрофон?», и множитель дака выбирался ветвью. Бас и микровход — единственные
             * два слоя со своим дако́м (и бас ещё и со своим сайдчейном), поэтому они
             * вынесены из цикла целиком: общий цикл стал прямым, а два особых случая
             * добавляются ниже, в том же сэмпле.
             */
            for (int pi = 0; pi < plain_n; pi++) {
                const int layer = plain[pi];
                const float ll = lay_l[layer][i];
                const float rr = lay_r[layer][i];
                const float ll_d = ll * duck;
                const float rr_d = rr * duck;

                /* Сырая сумма нужна только открытому кроссфейду дилея. */
                if (need_raw) {
                    raw_l += ll_d * pre_lvl[layer];
                    raw_r += rr_d * pre_lvl[layer];
                }

                l += ll_d * pre_dry[layer];
                r += rr_d * pre_dry[layer];

                /*
                 * ПОСЫЛ БЕРЁТСЯ ПОСЛЕ ФЕЙДЕРА: усиление то же, что у сухого пути, — иначе
                 * слой с нулевым уровнем продолжал бы звучать через эффект.
                 */
                if (rev_send) {
                    send += (ll_d + rr_d) * pre_rev[layer];
                }
                if (chr_send) {
                    cl += ll_d * pre_chr[layer];
                    cr += rr_d * pre_chr[layer];
                }
                if (dly_send) {
                    dl += ll_d * pre_dly[layer];
                    dr += rr_d * pre_dly[layer];
                }
            }

            /*
             * БАС: НИЗ ПОД ДАКОМ, ВЕРХ ЦЕЛЫЙ.
             *
             * Бочка качает низ, а середина и верх баса стоят: линия читается, а низ не
             * спорит с бочкой. Глубина у баса вдвое больше обычной и с полом в двадцать
             * процентов — на этом и держится сцепка бочки с линией.
             */
            if (bass_on) {
                const int layer = SYNTH_LAYER_BASS;
                const float ll = lay_l[layer][i];
                const float rr = lay_r[layer][i];

                s_sc_l[0] += s_sc_k * (ll - s_sc_l[0]);
                s_sc_l[1] += s_sc_k * (s_sc_l[0] - s_sc_l[1]);
                s_sc_r[0] += s_sc_k * (rr - s_sc_r[0]);
                s_sc_r[1] += s_sc_k * (s_sc_r[0] - s_sc_r[1]);

                const float ll_d = s_sc_l[1] * duck_bass + (ll - s_sc_l[1]);
                const float rr_d = s_sc_r[1] * duck_bass + (rr - s_sc_r[1]);

                if (need_raw) {
                    raw_l += ll_d * pre_lvl[layer];
                    raw_r += rr_d * pre_lvl[layer];
                }

                l += ll_d * pre_dry[layer];
                r += rr_d * pre_dry[layer];

                if (rev_send) {
                    send += (ll_d + rr_d) * pre_rev[layer];
                }
                if (chr_send) {
                    cl += ll_d * pre_chr[layer];
                    cr += rr_d * pre_chr[layer];
                }
                if (dly_send) {
                    dl += ll_d * pre_dly[layer];
                    dr += rr_d * pre_dly[layer];
                }
            }

            /* Микрофонный вход: свой дак, без сайдчейна. */
            if (aux_on) {
                const int layer = SYNTH_LAYER_AUX;
                const float ll_d = lay_l[layer][i] * duck_bass;
                const float rr_d = lay_r[layer][i] * duck_bass;

                if (need_raw) {
                    raw_l += ll_d * pre_lvl[layer];
                    raw_r += rr_d * pre_lvl[layer];
                }

                l += ll_d * pre_dry[layer];
                r += rr_d * pre_dry[layer];

                if (rev_send) {
                    send += (ll_d + rr_d) * pre_rev[layer];
                }
                if (chr_send) {
                    cl += ll_d * pre_chr[layer];
                    cr += rr_d * pre_chr[layer];
                }
                if (dly_send) {
                    dl += ll_d * pre_dly[layer];
                    dr += rr_d * pre_dly[layer];
                }
            }

            s_dry_l[i] = l;
            s_dry_r[i] = r;
            if (rev_run) {
                s_send_bus[i] = send;
            }
            if (chr_run) {
                s_chr_l[i] = cl;
                s_chr_r[i] = cr;
            }
            if (dly_run) {
                /* The delay's input walks from its sends to the dry pair as its crossfade
                 * opens: a bus insert must hear what it replaces, or the layers whose send
                 * is closed would be taken out of the mix without being put into the delay. */
                s_dly_l[i] = dl + dly_a * (raw_l - dl);
                s_dly_r[i] = dr + dly_a * (raw_r - dr);
            }
        }

        /* The block's glide state back where the next block and the rescue trail expect it. */
        for (int k = 0; k < SYNTH_NUM_LAYERS; k++) {
            s_layer_level_cur[k] = lvl[k];
            s_send_rev_cur[k] = rev[k];
            s_send_chr_cur[k] = chr[k];
            s_send_dly_cur[k] = dly[k];
        }
        s_reverb_mix_cur = rev_mix_cur;
        s_chorus_mix_cur = chr_mix_cur;
        s_delay_mix_cur  = dly_mix_cur;
#if STAGE_TIMING
        s_stage_blk.sum += stage_elapsed(t_s_sum);
#endif

        /*
         * Компенсация дакинга: часть вычтенного возвращается всему миксу, включая удар.
         *
         * Считается здесь, где дакинг уже посчитан, но НЕ присваивается напрямую: цель
         * медленная (120 мс) и с потолком, а к цели ведёт отдельный однополюсник на сэмпл —
         * см. rack_out(). Так усиление не шагает на границах блока и не поднимает микс в
         * клиппер.
         */
        {
            const float block_ms = (float)samples * (1000.0f / 48000.0f);
            float goal = 1.0f / (1.0f - DUCK_MAKEUP_FRAC * s_duck_smooth);

            if (goal > DUCK_MAKEUP_MAX) {
                goal = DUCK_MAKEUP_MAX;
            }
            if (!(goal >= 1.0f)) {
                goal = 1.0f;
            }

            s_duck_makeup += (goal - s_duck_makeup) * (block_ms / (DUCK_MAKEUP_MS + block_ms));
        }

        s_duck_prev = duck_low;

        /*
         * The percussion, added to the dry sum and to the send bus it has already
         * been given. Inside the gate, so STOP stops the drum part as well — the
         * generator side of the rack is what the gate closes, and a drum machine
         * that kept playing after STOP would not be part of the instrument.
         *
         * A bus that is not running is handed over as NULL, which is the module's own
         * "no such send": that is the economy the drum already had, and it now covers the
         * case where the effect behind the send has been turned off.
         */
#if STAGE_TIMING
        const int64_t t_s_perc = esp_timer_get_time();
#endif
        synth_perc_process(samples, s_dry_l, s_dry_r,
                           rev_run ? s_send_bus : nullptr, s_perc_send_rev,
                           chr_run ? s_chr_l : nullptr, chr_run ? s_chr_r : nullptr,
                           s_perc_send_chr,
                           dly_run ? s_dly_l : nullptr, dly_run ? s_dly_r : nullptr,
                           s_perc_send_dly);
#if STAGE_TIMING
        s_stage_blk.perc += stage_elapsed(t_s_perc);
#endif

        /*
         * The ramp, on the whole generator side at once: the layers AND the drum, which
         * is inside the gate with them. Last, because the three buffers are only complete
         * once the drum has been summed into them, and one step per sample because a
         * per-block gain is the step this exists to remove. At the open end s_gate_gain
         * is exactly 1.0 and the multiplies return the samples unchanged, so the sound
         * of a gate that is open is bit for bit the sound it was before this ramp.
         */
#if STAGE_TIMING
        const int64_t t_s_gate = esp_timer_get_time();
#endif
        for (int i = 0; i < samples; i++) {
            s_gate_gain = gate_step(s_gate_gain, gate_coef, gate_target);

            s_dry_l[i] *= s_gate_gain;
            s_dry_r[i] *= s_gate_gain;
            if (rev_run) {
                s_send_bus[i] *= s_gate_gain;
            }
            if (chr_run) {
                s_chr_l[i] *= s_gate_gain;
                s_chr_r[i] *= s_gate_gain;
            }
            if (dly_run) {
                s_dly_l[i] *= s_gate_gain;
                s_dly_r[i] *= s_gate_gain;
            }
        }
#if STAGE_TIMING
        s_stage_blk.gate += stage_elapsed(t_s_gate);
#endif
    } else {
#if STAGE_TIMING
        const int64_t t_s_zero = esp_timer_get_time();
#endif
        for (int i = 0; i < samples; i++) {
            /* Nothing is summed, but the returns' poles still run: a return lowered while
             * the gate is shut has to arrive at zero for the gates above to close, and one
             * raised has to start from where it is when the gate opens again. */
            s_reverb_mix_cur = mix_step(s_reverb_mix_cur, s_reverb_mix, s_reverb_mix_glide);
            s_chorus_mix_cur = mix_step(s_chorus_mix_cur, s_chorus_mix, s_chorus_mix_glide);
            s_delay_mix_cur  = mix_step(s_delay_mix_cur, s_delay_mix, s_delay_mix_glide);

            s_dry_l[i] = 0.0f;
            s_dry_r[i] = 0.0f;
            if (rev_run) {
                s_send_bus[i] = 0.0f;
            }
            if (chr_run) {
                s_chr_l[i] = 0.0f;
                s_chr_r[i] = 0.0f;
            }
            if (dly_run) {
                s_dly_l[i] = 0.0f;
                s_dly_r[i] = 0.0f;
            }
        }
#if STAGE_TIMING
        s_stage_blk.gate += stage_elapsed(t_s_zero);
#endif
    }

    /* Хвост блока — отдельной функцией: см. rack_fx_section(). Строки те же, порядок тот же. */
    {
        const size_t bytes = (size_t)samples * sizeof(float);
        memcpy(s_fx.dry_l, s_dry_l, bytes);
        memcpy(s_fx.dry_r, s_dry_r, bytes);
        if (rev_run) {
            memcpy(s_fx.send, s_send_bus, bytes);
        }
        if (chr_run) {
            memcpy(s_fx.chr_l, s_chr_l, bytes);
            memcpy(s_fx.chr_r, s_chr_r, bytes);
        }
        if (dly_run) {
            memcpy(s_fx.dly_l, s_dly_l, bytes);
            memcpy(s_fx.dly_r, s_dly_r, bytes);
        }
    }

#if RACK_FX_TASK
    /*
     * Конвейер. Снимок уже лежит в s_fx; здесь он отдаётся задаче, если она забрала прошлый,
     * а на выход идёт самый свежий готовый блок. Звуковая задача не ждёт ни одного такта:
     * ожидание здесь — это блок, отданный не вовремя, то есть тот же треск.
     */
    if (!s_fx_task && !s_fx_off) {
        rack_fx_start();
    }

    if (!s_fx_task) {
        rack_fx_section(samples, out_stereo, chr_run, dly_run, rev_run, &s_fx);
    } else {
        if (s_fx_hold > 0) {
            /* Конвейер отдыхает: после срыва считаем на месте подряд, потом включим снова. */
            s_fx_hold = s_fx_hold - 1;
            rack_fx_section(samples, out_stereo, chr_run, dly_run, rev_run, &s_fx);
            s_fx_late_run = 0u;
            s_fx_read = s_fx_write;   /* опубликованное до срыва уже не в очередь */
        } else if (xSemaphoreTake(s_fx_free, 0) == pdTRUE) {
            s_fx_samples = samples;
            s_fx_chr = chr_run;
            s_fx_dly = dly_run;
            s_fx_rev = rev_run;
            xSemaphoreGive(s_fx_todo);
        }

        const int done = s_fx_write;

        if (done != s_fx_read) {
            /* Готовый блок есть: играем самый свежий. */
            const int idx = s_fx_read % FX_RING;
            memcpy(out_stereo, s_fx_out[idx], (size_t)samples * 2u * sizeof(int16_t));
            s_fx_read = done;
            s_fx_late_run = 0u;
        } else if (s_fx_late_run > 0u && xSemaphoreTake(s_fx_todo, 0) == pdTRUE) {
            /*
             * Задача к снимку не приступала: считаем хвост на месте. Снимок мы у неё забрали,
             * поэтому она его не возьмёт и состояние эффектов не сдвинется дважды.
             */
            rack_fx_section(samples, out_stereo, chr_run, dly_run, rev_run, &s_fx);
            s_fx_late_run = 0u;
            s_fx_hold = 200;          /* секунда на месте, чтобы не повторять через блок */
            s_fx_read = s_fx_write;
        } else if (s_fx_read > 0) {
            /*
             * Задача считает прямо сейчас: повторяем прошлый блок. Это максимум один блок —
             * дальше либо придёт результат, либо счётчик снимет задачу.
             */
            const int idx = (s_fx_read - 1) % FX_RING;
            memcpy(out_stereo, s_fx_out[idx], (size_t)samples * 2u * sizeof(int16_t));
            s_fx_late = s_fx_late + 1u;
            s_fx_late_run = s_fx_late_run + 1u;

            if (s_fx_late_run > s_fx_late_max) {
                s_fx_late_max = s_fx_late_run;
            }

            if (s_fx_late_run >= 40u) {
                /* Пятая часть секунды одних повторов: задача не живёт, дальше считаем сами. */
                vTaskDelete(s_fx_task);
                s_fx_task = NULL;
                s_fx_off = true;
                s_fx_late_run = 0u;
            }
        } else {
            /* Первый блок после старта: выхода ещё нет, считаем на месте. */
            rack_fx_section(samples, out_stereo, chr_run, dly_run, rev_run, &s_fx);
        }
    }
#else
    rack_fx_section(samples, out_stereo, chr_run, dly_run, rev_run, &s_fx);
#endif
}

/*
 * THE ENTRY POINT, with the block's stages measured around it when the diagnostic flag is
 * on. Off, this is one call and an inline of nothing; on, it is the same call with the
 * block's bookkeeping on either side, and it covers every return the body makes — the dry
 * path's, the two rescues' — because a stage that is published on most paths is a number
 * nobody can use.
 */
IRAM_ATTR void synth_rack_process(int samples, int16_t *out_stereo)
{
#if STAGE_TIMING
    stage_block_begin();
    rack_process_block(samples, out_stereo);
    stage_block_end();
#else
    rack_process_block(samples, out_stereo);
#endif
}

int synth_rack_scope(float *dst, int max)
{
    if (dst == NULL || max <= 0) {
        return 0;
    }

    const int n = (max < SYNTH_SCOPE_POINTS) ? max : SYNTH_SCOPE_POINTS;
    const int front = s_scope_front;

    for (int i = 0; i < n; i++) {
        dst[i] = s_scope[front][i];
    }

    return n;
}







