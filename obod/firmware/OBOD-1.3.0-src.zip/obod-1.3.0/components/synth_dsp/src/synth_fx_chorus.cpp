#include "esp_attr.h"
#include "synth_dsp.h"
#include "synth_dsp_private.h"

#include <math.h>
#include <string.h>

#include "esp_heap_caps.h"
#include "esp_log.h"

/*
 * Stereo chorus.
 *
 * One modulated delay line per channel, read with linear interpolation, with the
 * two LFOs in quadrature. Quadrature is the whole trick: a single LFO shared by
 * both channels is vibrato, not chorus, because the two sides move together and
 * the ear hears pitch rather than width. Ninety degrees apart, the sides move
 * against each other and the ear hears width — which matters here more than
 * usual, because the engine underneath this is mono, so every bit of stereo the
 * instrument has is made after the fact.
 *
 * Nothing is allocated until the chorus is actually mixed in. See the note in
 * ensure() for why that is not an optimisation.
 */

namespace {

constexpr const char *TAG = "chorus";

constexpr float PI_F = 3.14159265358979f;

constexpr int   CHORUS_MAX_MS   = 40;
constexpr float CHORUS_BASE_MS  = 12.0f;   /* where the LFO swings around */
constexpr float CHORUS_SWING_MS = 8.0f;    /* how far it swings, at full depth */
constexpr int   SINE_SIZE       = 1024;    /* power of two, plus guard entries */

/*
 * How long the depth takes to arrive, in milliseconds.
 *
 * DEPTH is not an amount, it is a TIME: it is the width of the swing the two read
 * pointers make around their base tap, and the LFO is at its extreme when the knob
 * moves. Writing it straight in moves the pointer between two samples, and a
 * pointer that jumps is a splice — the same tick a hard time change makes in the
 * delay, and the more of them the faster the knob is turned. So the swing is a
 * one-pole of its own, per sample, 30 ms: longer than the delay's feedback pole
 * because what it moves is smooth already and it has to stay under the LFO's own
 * corner at the slowest rate the knob offers — 0.05 Hz, where a 30 ms pole is
 * three orders of magnitude away from eating the sweep it exists to carry.
 *
 * The MIX is not smoothed here and cannot be: the rack multiplies the dry by
 * (1 - mix) when it works out what this effect added to the reverb's send, and it
 * reads the mix out of its own copy. A mix that glided inside this file would be a
 * number the send derivation disagrees with for the length of the glide.
 */
constexpr float CHORUS_DEPTH_GLIDE_MS = 30.0f;

/* The fade the wet gets when a restarted effect's first material reaches its tap; see the
 * gain in synth_chorus_process(). */
constexpr float CHORUS_WARM_MS = 10.0f;

float *s_sine    = nullptr;
float *s_line[2] = { nullptr, nullptr };
int    s_len     = 0;
int    s_write   = 0;
float  s_rate    = 48000.0f;
float  s_base    = 0.0f;      /* base delay, in samples */
float  s_swing   = 0.0f;      /* swing, in samples, at the current depth */
float  s_swing_cur = 0.0f;    /* that, through the pole: the number the reads use */
float  s_swing_glide = 0.0f;
float  s_inc     = 0.0f;      /* LFO phase per sample */
float  s_phase   = 0.0f;      /* left channel phase, 0..1; right is a quarter on */
float  s_mix     = 0.0f;
bool   s_ready   = false;

/*
 * HOW MUCH OF THE LINE HAS BEEN WRITTEN SINCE THE RACK'S RETURN CAME BACK UP FROM ZERO.
 *
 * Same idea as the delay's s_fill, and for the same reason: a line that a return reports
 * from must not report the forty milliseconds it was left holding, and clearing it is work
 * this effect's line is small enough to do but pointless work all the same. The read is
 * twelve milliseconds behind the write, so after that much has been written the tap only
 * ever sees material written since the restart; until then the wet is silence.
 */
int    s_fill    = 0;
/* One over the ramp that fade-in takes: ten milliseconds, the same as the delay's. */
float  s_warm_inv = 1.0f / 480.0f;

/*
 * sin(2*pi*x), with a guard entry so that interpolation never has to wrap.
 *
 * The index is bounded INDEPENDENTLY of the caller, because a phase is not always the
 * number process() keeps: `(int)phase` of a non-number, an infinity or anything past
 * 2^31 is an undefined conversion, and on this chip it lands outside s_sine — a load
 * past the end of the table, which is the access violation the host bench found and a
 * panic on the instrument. So a phase outside [0, 1) is wrapped with floorf(), and the
 * table coordinate is held to [0, SINE_SIZE] afterwards; i + 1 is then at most the
 * guard entry, which exists.
 *
 * WHAT THIS COSTS THE NORMAL CASE: nothing. A finite phase in [0, 1) — every value the
 * LFO produces — fails the wrap test, both comparisons on f are a no-op, and the
 * interpolation is the same expression it always was, so those samples are bit for bit
 * what they were. Only the values the LFO cannot produce take the extra arithmetic.
 */
inline float sine_at(float phase)
{
    if (!(phase >= 0.0f) || phase >= 1.0f) {
        phase -= floorf(phase);
        if (!(phase >= 0.0f) || phase >= 1.0f) {
            /* floorf() of a non-finite phase is still non-finite: 1 - 1 is NaN. */
            phase = 0.0f;
        }
    }

    float f = phase * (float)SINE_SIZE;
    if (!(f >= 0.0f)) {
        f = 0.0f;
    } else if (f > (float)SINE_SIZE) {
        f = (float)SINE_SIZE;
    }

    const int i = (int)f;
    return s_sine[i] + (s_sine[i + 1] - s_sine[i]) * (f - (float)i);
}

/*
 * First use, not boot.
 *
 * This is not a lazy-initialisation optimisation. The device finishes booting
 * with a few kilobytes of internal heap to spare, and the Wi-Fi SoftAP starts
 * asynchronously right after: when this memory was taken at boot, the SoftAP
 * failed to allocate its beacon buffers and the Wi-Fi driver took a NULL it does
 * not check, which rebooted the board in a loop. Every effect therefore claims
 * its memory the first time somebody actually asks for it, which is the first
 * time a mix or a send stops being zero — long after Wi-Fi has what it needs.
 *
 * Everything lives in PSRAM for the same reason: internal DRAM is the scarce
 * resource, and it is not ours.
 */
bool ensure(void)
{
    if (s_ready) {
        return true;
    }

    /*
     * INTERNAL RAM FIRST, and this one is measured rather than reasoned about: both lines and
     * the LFO table are read on every single sample, and in PSRAM every one of those reads is a
     * cache miss behind a bus the display also uses. Nineteen kilobytes of internal RAM buy a
     * third of the chorus's own cost. PSRAM stays as the fallback, so a build that cannot spare
     * the internal memory still has a chorus.
     */
    if (!s_sine) {
        const size_t sine_bytes = sizeof(float) * (size_t)(SINE_SIZE + 2);
        s_sine = (float *)heap_caps_malloc_prefer(sine_bytes, 2,
                                                  MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT,
                                                  MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
        if (!s_sine) {
            ESP_LOGE(TAG, "no room for the LFO table — the chorus stays bypassed");
            return false;
        }
        for (int i = 0; i <= SINE_SIZE + 1; i++) {
            s_sine[i] = sinf(2.0f * PI_F * (float)i / (float)SINE_SIZE);
        }
    }

    const size_t bytes = sizeof(float) * (size_t)s_len;
    for (int c = 0; c < 2; c++) {
        if (s_line[c]) {
            continue;
        }
        s_line[c] = (float *)heap_caps_malloc_prefer(bytes, 2,
                                                     MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT,
                                                     MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
        if (!s_line[c]) {
            ESP_LOGE(TAG, "no room for %u bytes of delay line — bypassed", (unsigned)bytes);
            return false;
        }
        memset(s_line[c], 0, bytes);
    }

    s_fill = s_len;             /* the line is empty, so there is nothing to protect against */
    s_ready = true;
    ESP_LOGI(TAG, "stereo, quadrature LFO, %d samples a side in internal RAM, %.0f ms base",
             s_len, (double)CHORUS_BASE_MS);
    return true;
}

} // namespace

void synth_chorus_init(uint32_t sample_rate)
{
    /*
     * ХОРУС ТОЖЕ ЧЕРЕЗ ОТСЧЁТ.
     *
     * Здесь цена не в PSRAM, а в том, что на каждый отсчёт приходится два дробных чтения из
     * линии с интерполяцией и два синуса модуляции. Шаг в два отсчёта снимает половину, а
     * модуляция у хоруса медленная (десятые доли герца), и за два отсчёта фаза не уходит
     * никуда; на выходе пара получает одну и ту же величину, а на вход линии идёт среднее
     * пары — тот же двухточечный фильтр, что у реверба, и та же защита от складывания.
     *
     * Все времена (базовая задержка, размах, разгон, длина линии) считаются от половинной
     * частоты, то есть в шагах, поэтому в миллисекундах ничего не сдвинулось.
     */
#define CHORUS_HALF_RATE 1
#define CHORUS_STEP_DIV  2

    s_rate = (float)sample_rate / (float)CHORUS_STEP_DIV;
    s_len = (int)(s_rate * (float)CHORUS_MAX_MS / 1000.0f);
    if (s_len < 64) {
        s_len = 64;
    }

    s_base = CHORUS_BASE_MS * s_rate / 1000.0f;
    s_swing_glide = 1.0f - expf(-1.0f / (CHORUS_DEPTH_GLIDE_MS * s_rate / 1000.0f));

    synth_chorus_set(0.6f, 0.35f, 0.0f);
    s_fill = 0;                 /* nothing is written until the line has been claimed */
    s_warm_inv = 1.0f / (CHORUS_WARM_MS * s_rate / 1000.0f);

    /* Nothing to glide FROM at boot: the lines are empty and there is no pointer to
     * splice, so the first block runs at the depth that was just asked for. */
    s_swing_cur = s_swing;
}

void synth_chorus_set(float rate_hz, float depth01, float mix01)
{
    /*
     * The lower test is the NEGATION of the one the value has to pass, here and in
     * every setter on this API: NaN compares false against everything, so `x < min`
     * passes it and it reaches the phase increment, where it stays — and `(int)` of it
     * is what used to walk off the sine table. `!(x >= min)` sends it to the bound.
     * An infinity is pulled to the bound it names by the test above or below.
     */
    if (!(rate_hz >= 0.01f)) {
        rate_hz = 0.01f;
    } else if (rate_hz > 20.0f) {
        rate_hz = 20.0f;
    }
    if (!(depth01 >= 0.0f)) {
        depth01 = 0.0f;
    } else if (depth01 > 1.0f) {
        depth01 = 1.0f;
    }
    if (!(mix01 >= 0.0f)) {
        mix01 = 0.0f;
    } else if (mix01 > 1.0f) {
        mix01 = 1.0f;
    }

    s_inc = rate_hz / s_rate;
    s_swing = depth01 * CHORUS_SWING_MS * s_rate / 1000.0f;
    s_mix = mix01;
}

/*
 * The rescue, from synth_rack.cpp's fuse. The depth pole is put on the knob's target, because
 * a pointer that walks up from zero after a rescue is a thirty-millisecond pitch sweep nobody
 * asked for, and the phase is put back in range: sinf() of a non-finite phase is NaN, which
 * is one of the ways this module could keep poisoning the bus by itself.
 *
 * Both lines are cleared HERE rather than in a task of their own, and that is a size
 * decision, not an oversight: a chorus line is forty milliseconds, 7.7 KB a side, against the
 * delay's megabyte and a half. At the internal-RAM speed ensure() asks for first that is tens
 * of microseconds in a 5333 microsecond block; the delay's clearing is the one that has to
 * leave the core.
 */
void synth_chorus_reset_state(void)
{
    s_swing_cur = s_swing;

    if (!isfinite(s_phase) || s_phase < 0.0f || s_phase >= 1.0f) {
        s_phase = 0.0f;
    }

    if (s_line[0] && s_line[1] && s_len > 0) {
        const size_t bytes = sizeof(float) * (size_t)s_len;
        memset(s_line[0], 0, bytes);
        memset(s_line[1], 0, bytes);
        s_write = 0;
        s_fill = s_len;         /* cleared, so nothing stale is left to read */
    }
}

/*
 * The rack's chorus return has come back up from zero. Not a clear: a count, exactly as the
 * delay's restart — see s_fill. This is one store, so a return that is raised and lowered
 * costs the audio task nothing at either end.
 */
void synth_chorus_restart(void)
{
    s_fill = 0;
}

IRAM_ATTR void synth_chorus_process(int samples, float *l, float *r)
{
    /* An effect that is mixed out costs nothing and claims nothing. */
    if (s_mix <= 0.0f || !l || !r || samples <= 0) {
        return;
    }
    if (!ensure()) {
        return;
    }

    const float dry = 1.0f - s_mix;
    /* Read once and written back after the loop: see the delay's. */
    int fill = s_fill;

    for (int i = 0; i < samples; i += CHORUS_STEP_DIV) {
        /* The depth, one step of its pole per step, before the reads that use it:
         * a depth that has just been moved must not splice the pointer on the very
         * sample the knob landed on. */
        s_swing_cur += (s_swing - s_swing_cur) * s_swing_glide;

        /* The tap in force, and how much of what was written since the restart reaches it:
         * see s_fill. The LFO moves the tap, so the test is per sample — at the swing's far
         * end the tap is at its longest and the wet stays silent until the line has been
         * written that far. The gain ramps over ten milliseconds from the moment the fresh
         * material arrives, because the read does not start on a zero: it starts on the
         * first sample written after the restart, and turning a read on inside a waveform
         * is a step whatever the line holds. */
        const float tap_l = s_base + s_swing_cur * sine_at(s_phase);
        const float tap_r = s_base + s_swing_cur * sine_at(s_phase + 0.25f);
        const float tap   = (tap_l > tap_r) ? tap_l : tap_r;

        const float fresh = ((float)fill - tap) * s_warm_inv;
        const float gain  = (fresh >= 1.0f) ? 1.0f : ((fresh > 0.0f) ? fresh : 0.0f);

        float rl = 0.0f;
        float rr = 0.0f;
        if (gain > 0.0f) {
            rl = synth_fx_read(s_line[0], s_len, s_write, tap_l) * gain;
            rr = synth_fx_read(s_line[1], s_len, s_write, tap_r) * gain;
        }

        /* В линию — среднее пары (вход до смешения), на выход — одна величина на пару. */
        {
            const int j = (i + 1 < samples) ? (i + 1) : i;
            s_line[0][s_write] = 0.5f * (l[i] + l[j]);
            s_line[1][s_write] = 0.5f * (r[i] + r[j]);

            l[i] = l[i] * dry + rl * s_mix;
            r[i] = r[i] * dry + rr * s_mix;
            if (j != i) {
                l[j] = l[j] * dry + rl * s_mix;
                r[j] = r[j] * dry + rr * s_mix;
            }
        }

        if (++s_write >= s_len) {
            s_write = 0;
        }
        if (fill < s_len) {
            fill++;
        }
        s_phase += s_inc;
        if (s_phase >= 1.0f) {
            s_phase -= 1.0f;
        }
    }
    s_fill = fill;
}
