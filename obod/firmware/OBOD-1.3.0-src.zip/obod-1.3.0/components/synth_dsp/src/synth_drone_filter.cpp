#include "synth_dsp.h"
#include "synth_dsp_private.h"
#include "synth_stage_timing.h"

#if STAGE_TIMING
#include "esp_timer.h"
#endif

#include <math.h>

/*
 * Drone register filter: TPT/ZDF state-variable filter with its own LFO.
 *
 * WHY NOT THE ENGINE'S FILTER
 *   ESP32Synth ships two bus filters (FX_BiquadFilter, FX_BiquadFilterFast) and
 *   they are fine filters, but they recompute their coefficients once per
 *   render block from parameters pushed in by user code, and their frequency
 *   tables hardcode 48 kHz. More importantly there is no modulation path in the
 *   engine at all: no LFO routes to a filter, so a sweep has to be driven from
 *   outside at whatever rate the caller manages. A drone is a slow filter sweep
 *   held for minutes; it deserves its own LFO inside the same loop, where the
 *   sweep cannot be quantised by anything.
 *
 * WHY TPT
 *   The topology-preserving transform SVF (Zavalishin) stays stable at high
 *   resonance, needs one tanf per block plus five multiply-adds per sample, and
 *   gives low/band/high outputs from the same state. A direct-form biquad would
 *   need coefficient interpolation to sweep smoothly; this one just works.
 *
 * CUTOFF IS MODULATED IN OCTAVES, so a 1-octave sweep sounds like a 1-octave
 * sweep instead of crawling at the bottom and racing at the top.
 */

namespace {

struct SvfState {
    float ic1eq;         /* integrator states */
    float ic2eq;
    float lfo_phase;     /* 0..1 */
    float cutoff;        /* smoothed, Hz */
    float cutoff_target; /* Hz */
    float lfo_last;      /* the sweep of the previous block, -1..1 */
    float rate_phase;    /* the rate modulator's own phase, 0..1 */
    float depth;         /* smoothed LFO depth, centioctaves */
    bool  depth_set;     /* false until the first block has given it a value */
    float q;             /* smoothed resonance, same pole as the cutoff */
};

SvfState s_svf[SYNTH_NUM_LAYERS];
float    s_inv_sample_rate = 1.0f / (float)SYNTH_SAMPLE_RATE;

} // namespace

/* The sweep of the last block, for the display. See synth_drone_lfo(). */
float s_lfo_pub;

/*
 * ФАЗА ПЕРВОГО РЕГИСТРА, ДЛЯ ИНДИКАЦИИ.
 *
 * Значение s_lfo_pub — это свип ПОСЛЕДНЕГО обработанного регистра, а у трёх регистров фазы
 * разведены (0, 0.23, 0.46). Индикатор брал это значение и потому прыгал между регистрами:
 * «дёргается и не слушается RATE». Фаза отдаётся одна, первого регистра, и индикатор сам
 * считает по ней синус — тогда он идёт ровно и следует за ручкой скорости.
 */
float s_lfo_phase_pub;

/*
 * НАСКОЛЬКО САМА СКОРОСТЬ ЛФО СЛЕДУЕТ ЗА ЭТИМ ЖЕ ЛФО.
 *
 * Ручка RATE задаёт среднюю скорость, и пока она одна, фильтр идёт ровно: владелец слышал
 * именно это — «статично, не следует за модуляцией». Настоящая модуляция скорости — это
 * когда фаза бежит быстрее на подъёме и медленнее на спаде, то есть скорость умножается на
 * 2^(depth * lfo). Тогда один проход — это ускорение и замедление, и на слух это слышно как
 * дыхание фильтра, а не как постоянная величина.
 *
 * Глубина приходит из того же выбора адресата: RATE в списке MOD, WIDTH — в глубину.
 * Ноль здесь означает «скорость ровно такая, как на ручке», и на нуле код не делает ничего.
 * Модулятор — не этот же ЛФО, а отдельная медленная синусоида со своей фазой: см. тело ниже.
 */
static float s_rate_mod = 0.0f;

/* Set from the control side, read by the block. */
static volatile int s_trig_mode;
static volatile uint32_t s_trig_epoch;
static uint32_t s_trig_seen;       /* the epoch this filter has already acted on */

void synth_drone_lfo_set_rate_mod(float depth01)
{
    if (!(depth01 >= 0.0f)) {
        depth01 = 0.0f;
    } else if (depth01 > 1.0f) {
        depth01 = 1.0f;
    }
    s_rate_mod = depth01;
}

void synth_drone_lfo_trig(int mode)
{
    s_trig_mode = mode;
}

void synth_drone_lfo_retrigger(void)
{
    s_trig_epoch = s_trig_epoch + 1;
}

int synth_drone_lfo_mode(void)
{
    return s_trig_mode;
}

uint32_t synth_drone_lfo_epoch(void)
{
    return s_trig_epoch;
}

void synth_drone_filter_init(uint32_t sample_rate)
{
    s_inv_sample_rate = 1.0f / (float)sample_rate;

    for (int i = 0; i < SYNTH_NUM_LAYERS; i++) {
        s_svf[i].ic1eq = 0.0f;
        s_svf[i].ic2eq = 0.0f;
        s_svf[i].cutoff = 0.0f;
        s_svf[i].cutoff_target = 0.0f;
        s_svf[i].depth = 0.0f;
        s_svf[i].depth_set = false;
        s_svf[i].q = 0.0f;
        /* Staggered start phases, so the three registers never sweep together. */
        s_svf[i].lfo_phase = (float)i * 0.23f;
    }
}

/*
 * The rescue, from synth_rack.cpp's fuse. The integrators are the filter's memory and are
 * cleared unconditionally — units of numbers, microseconds. The cutoff, the resonance and the
 * depth are poles that were being walked towards knobs, so they are only replaced where the
 * poison actually reached them, and a cutoff of zero is this module's own "no ramp, take the
 * knob on the next block" value rather than silence. The phase is clamped into its range for
 * the same reason the chorus's is: sinf() of a non-finite phase is NaN, and the filter would
 * poison itself again on the next block without ever reading a sample.
 */
void synth_drone_filter_reset_state(void)
{
    for (int i = 0; i < SYNTH_NUM_LAYERS; i++) {
        SvfState &st = s_svf[i];

        st.ic1eq = 0.0f;
        st.ic2eq = 0.0f;

        if (!isfinite(st.cutoff) || st.cutoff < 0.0f) {
            st.cutoff = 0.0f;
        }
        if (!isfinite(st.cutoff_target) || st.cutoff_target < 0.0f) {
            st.cutoff_target = 0.0f;
        }
        if (!isfinite(st.q) || st.q < 0.0f) {
            st.q = 0.0f;
        }
        if (!isfinite(st.depth)) {
            st.depth = 0.0f;
            st.depth_set = false;   /* the next block seeds it from the knob */
        }
        if (!isfinite(st.lfo_phase) || st.lfo_phase < 0.0f || st.lfo_phase >= 1.0f) {
            st.lfo_phase = 0.0f;
        }
    }
}

static void synth_fx_drone_filter_body(int32_t *bus_buffer, int samples, int16_t *ep, int32_t *es)
{
    /* A note's restart is taken here, at the top of a block: the phases below are all that
     * the LFO is, and a reset halfway through a sweep would be a click. One epoch for all
     * registers, because they are one instrument's three bands. */
    const uint32_t epoch = s_trig_epoch;

    if (epoch != s_trig_seen) {
        s_trig_seen = epoch;

        for (int i = 0; i < SYNTH_NUM_LAYERS; i++) {
            s_svf[i].lfo_phase = 0.0f;
        }
    }

    (void)es;   /* state lives in s_svf[]; see the note in synth_dsp.h */

    if (!ep[6]) {
        return;
    }
    const int idx = ep[7];
    if (idx < 0 || idx >= SYNTH_NUM_LAYERS) {
        return;
    }
    if (samples <= 0) {
        return;
    }
    if (samples > SYNTH_BLOCK_SAMPLES) {
        samples = SYNTH_BLOCK_SAMPLES;
    }

    SvfState &st = s_svf[idx];
    const float dt = (float)samples * s_inv_sample_rate;

    /* --- cutoff modulation ------------------------------------------------ */
    /*
     * СКОРОСТЬ, КОТОРУЮ ВЕДЁТ ОТДЕЛЬНАЯ МЕДЛЕННАЯ МОДУЛЯЦИЯ.
     *
     * Первая попытка модулировать скорость собственным значением ЛФО была круглой: фаза
     * ускорялась на подъёме и замедлялась на спаде, но в среднем проходила цикл за то же
     * время, и на слух ничего не менялось. Владелец ждёт другого: «будто я кручу ручку
     * RATE» — то есть чтобы скорость ходила вверх-вниз независимо от самого колебания.
     *
     * Поэтому у модулятора своя фаза и своя постоянная скорость: 0.10 Гц, десять секунд на
     * цикл. Глубина 1 — это три октавы вверх и вниз, при 0.5 — полторы. Фильтр при этом
     * продолжает качаться со своей частоты, а его скорость дышит поверх неё, и это ровно
     * медленная частотная модуляция, а не размывание.
     */
    float rate_hz = (float)ep[2] * 0.001f;          /* ep is milliHertz */
    if (s_rate_mod > 0.0f) {
        st.rate_phase += 0.10f * dt;
        if (st.rate_phase >= 1.0f) {
            st.rate_phase -= 1.0f;
        }
        rate_hz *= exp2f(s_rate_mod * 3.0f * sinf(st.rate_phase * 6.28318531f));
    }
    st.lfo_phase += rate_hz * dt;
    if (s_trig_mode == 3 && st.lfo_phase >= 1.0f) {
        /* One shot: the shape runs to its end and stays there. An exponential shape read at
         * its end is a settled envelope, which is what the mode is for. */
        st.lfo_phase = 1.0f;
    } else if (st.lfo_phase >= 1.0f) {
        st.lfo_phase -= 1.0f;
    }

    /*
     * ONE SHAPE, A SINE, AND IT IS THIS FILTER'S OWN.
     *
     * This LFO used to take its waveform from the LFO page's SHAPE knob: a triangle, a square,
     * a ramp or a random ramp whenever that page said so. Two LFOs with one shape — and the
     * picture on the filter page was honest about it, which is what made it visible. They are
     * separate controls now. This one is a sine, driven by the filter page's own RATE and DEPTH,
     * and it moves this corner and nothing else.
     *
     * The other page's LFO keeps its shapes and its destination list, which may include this
     * filter as well: the two depths add in filter_depth_sum() and the sum is the exponent
     * below. That addition is the whole of the meeting between the two pages.
     *
     * The microphone does not stand in for this sine any more either. MIC is a source on the LFO
     * page and it moves what that page is pointed at; a filter that stopped sweeping because
     * another page chose a source was the same coupling in another form. The phase keeps
     * running throughout, so a knob move never restarts the sweep.
     */
    const float lfo = sinf(st.lfo_phase * 6.28318531f);

    s_lfo_pub = lfo;
    st.lfo_last = lfo;

    /* первый регистр задаёт фазу для индикации */
    if (&st == &s_svf[0]) {
        s_lfo_phase_pub = st.lfo_phase;
    }

    /*
     * The depth is a knob, and a knob is a staircase: each detent asks for a new sweep width,
     * and because the target is base * 2^(depth * lfo), a step in depth is a step in the
     * corner of up to the whole sweep — the click that is heard while WIDTH is turned. It is
     * therefore smoothed on its own, slower than the corner it multiplies: 60 ms turns a
     * detent into a widening rather than a jump, and it cannot slow the sweep itself, which
     * is the LFO's business and stays at 8 ms in the corner below.
     */
    if (!st.depth_set) {
        st.depth = (float)ep[3];
        st.depth_set = true;
    } else {
        float ad = dt * (1.0f / 0.060f);

        if (ad > 1.0f) {
            ad = 1.0f;
        }

        st.depth += ((float)ep[3] - st.depth) * ad;
    }

    const float depth_oct = st.depth * 0.01f;       /* centioctaves -> octaves */
    const float base_hz = (float)ep[0];

    float target = base_hz * exp2f(depth_oct * lfo);

    /* Keep it below Nyquist with margin, and above DC. The lower test is negated:
     * a base of zero times a depth that has overflowed the exponential is a NaN, and
     * a NaN fails both of the comparisons a plain `x < 20` / `x > max` pair makes. */
    const float fc_max = 0.45f / s_inv_sample_rate;
    if (!(target >= 20.0f)) {
        target = 20.0f;
    } else if (target > fc_max) {
        target = fc_max;
    }
    st.cutoff_target = target;

    /* One-pole smoothing over ~8 ms, so a jump in the base cutoff cannot step
     * the filter hard enough to click.
     *
     * 8, not the 15 it was: this is a low-pass on the sweep itself, and the top of the
     * RATE travel puts the LOW register's LFO at 6 Hz (MID 8.4, HIGH 4.8). At 15 ms the
     * smoother's corner sits at 10.6 Hz against a block rate of 187.5 Hz, so a 6 Hz sweep
     * came out at 89 % of the depth asked for and 24 degrees late, and MID, the fastest
     * of the three, lost 19 % and 32 degrees. At 8 ms the corner is 19.9 Hz: 6 Hz comes
     * out at 97 % and 11 degrees late, MID at 95 % and 15. The phase still advances once
     * per block, and the smoother's corner stays ten times below the block rate, so this
     * is a filter on the sweep rather than a source of stepping: the largest per-block
     * change the smoothed cutoff makes stays under the one the target itself makes in
     * the same block. */
    /* One coefficient for both settings below: they are both knobs read once per
     * block, and neither is a modulator. */
    float a = dt / 0.008f;
    if (a > 1.0f) {
        a = 1.0f;
    }

    if (st.cutoff <= 0.0f) {
        st.cutoff = target;                         /* first block: no ramp from zero */
    } else {
        st.cutoff += (target - st.cutoff) * a;
    }

    /* --- TPT coefficients ------------------------------------------------- */
    float q = (float)ep[1] * 0.01f;                 /* Q x 100 -> Q */
    if (!(q >= 0.5f)) {
        q = 0.5f;
    } else if (q > 20.0f) {
        q = 20.0f;
    }

    /*
     * RESONANCE IS SMOOTHED, on the same per-block pole the cutoff uses, and it is
     * the ONE coefficient here that reaches the output without being offered a
     * glide anywhere else.
     *
     * The lead filter's does not need this: its Q goes into a1/a2/a3, and those are
     * ramped across 32 samples between one coefficient update and the next, which is
     * what makes a resonance move there a sweep rather than a splice. This filter
     * has no such ramp — it is the cheap one, and the whole of its design is that
     * one tanf per block plus five multiply-adds per sample — so a Q that has just
     * been moved lands on the very next block. Q sets where the peak sits and how
     * tall it is, and on a resonant sweep that is a step in the output; a per-block
     * pole will not remove the step, but it turns one step of the whole change into
     * a series of steps a few per cent of it, which is the difference between a
     * click and a knob.
     */
    if (st.q <= 0.0f) {
        st.q = q;                                   /* first block: no ramp from zero */
    } else {
        st.q += (q - st.q) * a;
    }

    const float g = tanf(3.14159265f * st.cutoff * s_inv_sample_rate);
    const float k = 1.0f / st.q;
    const float a1 = 1.0f / (1.0f + g * (g + k));
    const float a2 = g * a1;
    const float a3 = g * a2;

    const int mode = ep[4];

    for (int i = 0; i < samples; i++) {
        const float x = (float)bus_buffer[i] * (1.0f / 32768.0f);

        const float v3 = x - st.ic2eq;
        const float v1 = a1 * st.ic1eq + a2 * v3;
        const float v2 = st.ic2eq + a2 * st.ic1eq + a3 * v3;
        st.ic1eq = 2.0f * v1 - st.ic1eq;
        st.ic2eq = 2.0f * v2 - st.ic2eq;

        float y;
        if (mode <= 0) {
            y = v2;                                 /* low pass, bit for bit */
        } else if (mode >= 100) {
            y = x - k * v1 - v2;                    /* high pass */
        } else if (mode < 50) {
            /* Low to band: the two outputs cross-faded by the knob's first half.
             * A cross-fade of one state is what makes the sweep continuous; a
             * switch would step the output on a held drone and click. */
            const float t = (float)mode * 0.02f;
            y = v2 * (1.0f - t) + v1 * t;
        } else {
            const float t = (float)(mode - 50) * 0.02f;
            y = v1 * (1.0f - t) + (x - k * v1 - v2) * t;
        }

        /* Resonance can push the output past full scale; the rack limits the
         * sum, but this keeps a single bus from overflowing int32 first. */
        float out = y * 32768.0f;
        if (out > 2147483000.0f) {
            out = 2147483000.0f;
        } else if (out < -2147483000.0f) {
            out = -2147483000.0f;
        }
        bus_buffer[i] = (int32_t)out;
    }
}

float synth_drone_lfo(void)
{
    return s_lfo_pub;
}

/* Фаза свипа первого регистра, 0..1: по ней индикатор рисует свою синусоиду. */
float synth_drone_lfo_phase(void)
{
    return s_lfo_phase_pub;
}

/*
 * The published callback, with the stage measured around it.
 *
 * This runs inside the engine's render — generateSamples() calls it once per block per
 * register — so it cannot be timed from the outside, and the three registers are three
 * separate calls. The measurement is a wrapper rather than a timer inside the body because
 * the body returns from six places (an unconfigured register, a bad index, a block of zero
 * samples), and a stage that is only counted on some of them is a wrong number.
 */
void synth_fx_drone_filter(int32_t *bus_buffer, int samples, int16_t *ep, int32_t *es)
{
#if STAGE_TIMING
    const int64_t t0 = esp_timer_get_time();
    synth_fx_drone_filter_body(bus_buffer, samples, ep, es);
    synth_stage_add(SYNTH_STAGE_DRONE, (uint32_t)(esp_timer_get_time() - t0));
#else
    synth_fx_drone_filter_body(bus_buffer, samples, ep, es);
#endif
}

