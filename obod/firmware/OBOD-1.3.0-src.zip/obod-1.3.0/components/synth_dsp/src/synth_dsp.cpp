#include "synth_dsp.h"
#include "synth_dsp_private.h"
#include "synth_stage_timing.h"

#include "esp_log.h"
#include "esp_timer.h"

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include <string.h>

namespace {

constexpr const char *TAG = "fx";

/*
 * The size of one piece of a line clear. Four kilobytes is a few microseconds of PSRAM
 * traffic at the bus this board runs — far inside the 5.33 ms block — and it is coarse
 * enough that the per-piece overhead does not turn a clear into a thousand wake-ups.
 */
constexpr size_t ZERO_CHUNK = 4096;

/*
 * THE BOOT PREFETCH.
 *
 * Three seconds after app_main has finished — the screen is up, the radio (when the build
 * has one) has been started, and the first settings restoration has landed — the effects
 * take their memory. That is late enough that the boot path and the Wi-Fi beacon
 * allocation are done with PSRAM, and early enough that a player who turns a mix knob on
 * the first phrase finds the line ready. The order is the one the effects are listed in on
 * the pages: delay, reverb, plate. Each is complete before the next is asked for, because
 * three large claims at once are one long burst on the bus the audio task fetches from,
 * which is the fault this whole design exists to avoid.
 *
 * The wait below is a poll on the module's own readiness. The module's claim task does the
 * allocation and the zeroing; this task never touches a line. An effect that cannot take
 * its memory stays bypassed, exactly as it would have been after a failed lazy claim, and
 * the timeout keeps the prefetch from sitting on a module for the rest of the session.
 */
constexpr uint32_t PREFETCH_DELAY_MS   = 3000;
constexpr uint32_t PREFETCH_STEP_MS    = 10;
constexpr uint32_t PREFETCH_TIMEOUT_MS = 8000;
constexpr uint32_t PREFETCH_GAP_MS     = 250;

struct PrefetchStep {
    const char *name;
    bool (*ready)(void);
};

void prefetch_task(void *)
{
    vTaskDelay(pdMS_TO_TICKS(PREFETCH_DELAY_MS));

    const PrefetchStep steps[] = {
        { "delay",  synth_delay_prefetch  },
        { "reverb", synth_reverb_prefetch },
        { "plate",  synth_plate_prefetch  },
    };

    for (const PrefetchStep &step : steps) {
        const int64_t deadline =
            esp_timer_get_time() + (int64_t)PREFETCH_TIMEOUT_MS * 1000;

        while (!step.ready()) {
            if (esp_timer_get_time() >= deadline) {
                ESP_LOGW(TAG, "%s: memory not ready after %u ms — left bypassed",
                         step.name, (unsigned)PREFETCH_TIMEOUT_MS);
                break;
            }
            vTaskDelay(pdMS_TO_TICKS(PREFETCH_STEP_MS));
        }

        if (step.ready()) {
            ESP_LOGI(TAG, "%s: memory ready", step.name);
        }

        /* The radio and the display share this bus too. A pause between the three claims
         * keeps the prefetch a sequence of short bursts rather than one long one. */
        vTaskDelay(pdMS_TO_TICKS(PREFETCH_GAP_MS));
    }

    vTaskDelete(nullptr);
}

} // namespace

void synth_fx_zero(void *dst, size_t bytes)
{
    uint8_t *p = (uint8_t *)dst;

    while (bytes > 0) {
        const size_t n = (bytes < ZERO_CHUNK) ? bytes : ZERO_CHUNK;
        memset(p, 0, n);
        p += n;
        bytes -= n;

        /* One tick is a millisecond here, and the point is the gap: the next piece starts
         * only after the audio core has had a block to fetch and run. The last piece owes
         * no pause — nothing follows it. */
        if (bytes > 0) {
            vTaskDelay(pdMS_TO_TICKS(1));
        }
    }
}

void synth_dsp_prefetch_start(void)
{
    static bool started = false;

    if (started) {
        return;
    }
    started = true;

    /* Core 0, beside the three claim tasks and below the audio task on core 1. The task
     * only waits and polls; the work is in the module that owns each line. */
    if (xTaskCreatePinnedToCore(prefetch_task, "fx_prefetch", 3072, nullptr, 1, nullptr, 0)
        != pdPASS) {
        ESP_LOGW(TAG, "no task for the prefetch — effects stay lazy");
    }
}

void synth_dsp_init(uint32_t sample_rate)
{
    synth_pan_capture_init(sample_rate);
    synth_drone_filter_init(sample_rate);
    synth_lead_filter_init(sample_rate);
    synth_mic_mod_init();
    synth_chorus_init(sample_rate);
    /* Эффект-машина: STUTTER берёт из PSRAM 64 КБ под кусок, поэтому её запуск здесь, а
     * не при первом включении типа — иначе первое включение платило бы за malloc. */
    synth_fx_machine_init(sample_rate);
    synth_delay_init(sample_rate);
    synth_reverb_init(sample_rate);
    synth_perc_init(sample_rate);
    /* The bass is the one voice the engine does not render: it fills its own layer beside
     * the engine's block, so it is initialised here with the rest and called by name. */
    synth_bass_init(sample_rate);
    synth_rack_init();
}

#if STAGE_TIMING
/* -------------------------------------------------------------------------- */
/* Stage timing — see synth_stage_timing.h                                    */
/* -------------------------------------------------------------------------- */

namespace {

/*
 * Three arrays and a counter, all 32-bit and aligned, written by the audio task and read by
 * the statistics task on the other core. Every handover is one load or one store of a whole
 * word, so no lock is needed and none is taken: the audio task cannot afford to wait for a
 * task that is printing, and a window that is a block short is not a wrong answer about
 * where the time goes.
 *
 * The accumulator is the BLOCK's: a stage that is measured more than once inside a block
 * (the drone filter runs once per register) adds every call, and the average, the maximum
 * and the remainder are all worked out on the block's total. A maximum taken per call would
 * read lower than the average of the same stage whenever the stage is called more than once,
 * which is a number that cannot be true.
 *
 * The sums are monotonic within a window and are zeroed by the reader; the maxima are reset
 * to the last block's own value rather than to zero, exactly as the block's own `dsp max`
 * does, so the peak the next window reports can never read lower than the block that is
 * running.
 */
volatile uint32_t s_stage_acc_us[SYNTH_STAGE_COUNT];
volatile uint32_t s_stage_sum_us[SYNTH_STAGE_COUNT];
volatile uint32_t s_stage_max_us[SYNTH_STAGE_COUNT];
volatile uint32_t s_stage_last_us[SYNTH_STAGE_COUNT];
volatile uint32_t s_stage_blocks;

const char *const STAGE_NAME[SYNTH_STAGE_COUNT] = {
    "layers",
    "drone-filter",
    "lead-filter",
    "chorus",
    "delay",
    "reverb",
    "percussion",
    "compressor",
    "sum/glide",
    "gate/returns/master/clip",
    "control/seq",
    "remainder",
};

} // namespace

void synth_stage_add(synth_stage_t stage, uint32_t us)
{
    if ((int)stage < 0 || (int)stage >= (int)SYNTH_STAGE_COUNT) {
        return;
    }

    s_stage_acc_us[stage] = s_stage_acc_us[stage] + us;
}

uint32_t synth_stage_block_us(synth_stage_t stage)
{
    if ((int)stage < 0 || (int)stage >= (int)SYNTH_STAGE_COUNT) {
        return 0;
    }
    return s_stage_acc_us[stage];
}

void synth_stage_block(void)
{
    for (int i = 0; i < (int)SYNTH_STAGE_COUNT; i++) {
        const uint32_t us = s_stage_acc_us[i];

        s_stage_acc_us[i] = 0;
        s_stage_last_us[i] = us;
        s_stage_sum_us[i] = s_stage_sum_us[i] + us;

        if (us > s_stage_max_us[i]) {
            s_stage_max_us[i] = us;
        }
    }

    s_stage_blocks = s_stage_blocks + 1u;
}

void synth_stage_window(uint32_t *sum_us, uint32_t *max_us, uint32_t *blocks)
{
    for (int i = 0; i < (int)SYNTH_STAGE_COUNT; i++) {
        if (sum_us) {
            sum_us[i] = s_stage_sum_us[i];
        }
        if (max_us) {
            max_us[i] = s_stage_max_us[i];
        }

        s_stage_sum_us[i] = 0;
        s_stage_max_us[i] = s_stage_last_us[i];
    }

    if (blocks) {
        *blocks = s_stage_blocks;
    }
    s_stage_blocks = 0;
}

const char *synth_stage_name(synth_stage_t stage)
{
    if ((int)stage < 0 || (int)stage >= (int)SYNTH_STAGE_COUNT) {
        return "?";
    }
    return STAGE_NAME[stage];
}

uint32_t synth_stage_budget_us(void)
{
    return (uint32_t)((uint64_t)SYNTH_BLOCK_SAMPLES * 1000000ULL / (uint64_t)SYNTH_SAMPLE_RATE);
}
#endif /* STAGE_TIMING */
