/*
 * ЭФФЕКТ-МАШИНА.
 *
 * Одна позиция в стойке, в которой стоит один из нескольких недорогих эффектов. Эффектов
 * много, а место одно: в приборе с одной ручкой на страницу это единственный способ дать их
 * пачке, не отнимая у звука полифонию или память.
 *
 * ЧТО ЗДЕСЬ ЕСТЬ И ПОЧЕМУ ИМЕННО ЭТО.
 *
 *   CHORUS   — тот самый, что был: он не переписан, а позван (см. synth_chorus.cpp). Ноль в
 *              типе значит именно его, поэтому ни один старый патч не меняет звук.
 *   TREMOLO  — амплитудное качание, две строки на сэмпл.
 *   AUTOPAN  — то же качание, но между каналами.
 *   DRIVE    — мягкое ограничение с полкой по верхам: грязь, а не педаль.
 *   BITCRUSH — уменьшение разрядности и частоты выборки: цифровая текстура.
 *
 * ОБЩИЙ КОРПУС. Вход и выход — стерео, обработка на месте: стойка сама решает, сколько
 * мокрого вернуть (MIX) и сколько послать в реверб (VERB). У каждого эффекта три параметра
 * (A, B, C) — ровно столько, сколько остаётся на странице после типа, микса и посыла.
 *
 * ПЕРЕКЛЮЧЕНИЕ ТИПА НЕ ЩЁЛКАЕТ: стойка гасит возврат на два блока, меняет тип на нуле и
 * поднимает обратно — так же, как это делает реверб при смене алгоритма. Состояние при этом
 * чистится: эффекты не обязаны понимать состояние друг друга, а тишина в этот момент уже есть.
 */
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include "esp_heap_caps.h"
#include <string.h>

#include "synth_dsp.h"
#include "synth_dsp_private.h"
#include "ESP32Synth_Config.hpp"

namespace {

constexpr float FXM_PI = 3.14159265f;

/* Состояние. Одно на все эффекты: они не работают одновременно. */
struct MachineState {
    float phase;                        /* общий LFO: тремоло, автопан, фазер */
    float lp_l;                         /* полка драйва */
    float lp_r;
    int   hold;                         /* биткраш: счётчик удержания */
    float hold_l;
    float hold_r;
    float ap[6][2];                     /* фазер: шесть аллпасов на канал */
    float fb_l;                         /* фазер: обратная связь */
    float fb_r;
    float srr_l;                        /* SRR: сглаживание после удержания */
    uint32_t rng;                       /* жребий STUTTER */
    int      fade;                      /* сэмплов до полного возврата после смены типа */
    int      fade_pending;
    float srr_r;
};

/*
 * ЛИНИЯ ФЛАНГЕРА. Восемь килобайт во внутренней памяти: двадцать одна миллисекунда на канал —
 * весь диапазон флангера, от гребёнки до почти хоруса. Держим её здесь, а не в PSRAM: читается
 * она на каждом сэмпле и подкачки не терпит.
 */
#define FXM_LINE 1024
static float s_line[2][FXM_LINE];

/*
 * STUTTER: кусок и сетка.
 *
 * Запуск от транспорта, а не от руки: прибор самоиграющий, и повтор, который надо нажимать,
 * на нём бесполезен. Раз в четыре доли (такт в четырёх четвертях) машина записывает кусок
 * сигнала и проигрывает его B раз, после чего снова пропускает сигнал насквозь.
 */
/*
 * КУСОК ЖИВЁТ ВО ВНУТРЕННЕЙ ПАМЯТИ.
 *
 * В PSRAM он стоил до тридцати семи миллисекунд на блок: каждая запись и каждое чтение
 * отсчёта шли через кэш, а кэш был занят ревербом и дилеем. Восемь тысяч отсчётов на канал —
 * это тридцать два килобайта, зато каждый отсчёт берётся из внутренней памяти.
 *
 * Цена: самый длинный кусок — сто семьдесят миллисекунд, поэтому на медленном темпе 1/16 и
 * 1/8 обрезаются по буферу. На слух это значит, что заход короче, чем деление, но сам заход
 * остаётся.
 */
#define FXM_SLICE_MAX 16384
/* Окно на стыках куска: две миллисекунды при 48 кГц. */
#define ST_XF     96
#define ST_XF_INV (1.0f / (float)ST_XF)
static int16_t *s_slice[2];

enum { ST_IDLE = 0, ST_RECORD, ST_LOOP };

static float s_bpm = 120.0f;
static int   s_running;

static int   s_st_state;
static int   s_st_pos;              /* позиция внутри куска */
static int   s_st_len;              /* длина куска в отсчётах */
static int   s_st_reps;             /* сколько повторов осталось */
static float s_st_gain;             /* затухание на повторах */
static int   s_st_beat;             /* отсчётов до начала следующего такта */

MachineState s_m;

int   s_type;
float s_a;
float s_b;
float s_c;

/* Быстрый мягкий клип: тот же характер, что у tanh, но без вызова на сэмпл. */
inline float soft_clip(float x)
{
    const float ax = (x < 0.0f) ? -x : x;

    if (ax >= 1.0f) {
        return (x < 0.0f) ? -1.0f : 1.0f;
    }

    /* x(27 + x^2) / (27 + 9x^2) — приближение tanh на [-1, 1], ошибка под процентом. */
    const float x2 = x * x;

    return x * (27.0f + x2) / (27.0f + 9.0f * x2);
}

inline float clamp01f(float v)
{
    if (!(v >= 0.0f)) {
        return 0.0f;
    }
    return (v > 1.0f) ? 1.0f : v;
}

/* Треугольник из фазы 0..1: без sinf на сэмпл. */
inline float tri(float ph)
{
    const float t = (ph < 0.5f) ? ph : (1.0f - ph);

    return 4.0f * t - 1.0f;
}

/* --- эффекты ------------------------------------------------------------- */

void run_tremolo(int samples, float *l, float *r)
{
    const float rate = 0.05f + s_a * 19.95f;          /* 0.05 .. 20 Гц */

    /* Глубина по корню: середина хода уже даёт слышимую качку, а не четверть. */
    const float depth = sqrtf(s_b);
    const float shape = s_c;
    const float inc = rate / (float)SYNTH_SAMPLE_RATE;

    for (int i = 0; i < samples; i++) {
        s_m.phase += inc;
        if (s_m.phase >= 1.0f) {
            s_m.phase -= 1.0f;
        }

        /* SHAPE: 0 — треугольник, 1 — квадрат через мягкий клип. */
        float mod = tri(s_m.phase);

        if (shape > 0.0f) {
            const float sq = soft_clip(mod * (2.0f + 18.0f * shape)) * (1.0f / (1.0f + 0.35f * shape));

            mod = mod * (1.0f - shape) + sq * shape;
        }

        const float g = 1.0f - depth * (0.5f - 0.5f * mod);

        l[i] *= g;
        r[i] *= g;
    }
}

void run_autopan(int samples, float *l, float *r)
{
    const float rate = 0.02f + s_a * 9.98f;
    const float depth = sqrtf(s_b);
    const float width = s_c;
    const float inc = rate / (float)SYNTH_SAMPLE_RATE;

    for (int i = 0; i < samples; i++) {
        s_m.phase += inc;
        if (s_m.phase >= 1.0f) {
            s_m.phase -= 1.0f;
        }

        const float p = tri(s_m.phase);
        const float pan = p * depth;                     /* -1 .. 1 */

        float gl = 1.0f - 0.5f * (1.0f - pan) * width;
        float gr = 1.0f - 0.5f * (1.0f + pan) * width;

        l[i] *= gl;
        r[i] *= gr;
    }
}

void run_drive(int samples, float *l, float *r)
{
    const float drive = 1.0f + s_a * 15.0f;
    const float tone = s_b;
    const float bias = (s_c - 0.5f) * 0.4f;

    /* Полка: чем выше TONE, тем больше верха остаётся. */
    const float k = 0.02f + 0.6f * tone;

    for (int i = 0; i < samples; i++) {
        s_m.lp_l += k * (l[i] - s_m.lp_l);
        s_m.lp_r += k * (r[i] - s_m.lp_r);

        const float yl = soft_clip(l[i] * drive + bias) - soft_clip(bias);
        const float yr = soft_clip(r[i] * drive + bias) - soft_clip(bias);

        /* SHAPE через TONE: 0 — только грязь, 1 — грязь плюс остаток верха. */
        l[i] = yl * (1.0f - tone) + (l[i] - s_m.lp_l) * 0.5f * tone + s_m.lp_l;
        r[i] = yr * (1.0f - tone) + (r[i] - s_m.lp_r) * 0.5f * tone + s_m.lp_r;
    }
}

void run_bitcrush(int samples, float *l, float *r)
{
    /*
     * ТОЛЬКО РАЗРЯДНОСТЬ. Частота выборки здесь не трогается: это работа SRR, и раньше
     * биткраш делал её же, поэтому два эффекта и звучали одинаково.
     *
     * BITS: от 16 (чисто) до 1 (в грязь). TONE: сколько сухого подмешать после квантования —
     * на нуле остаётся только квантованный сигнал, на единице он проходит почти целиком.
     */
    /*
     * ШКАЛА 1..8 БИТ, А НЕ 1..16. Проверка на столе показала: на середине хода шестнадцать
     * бит давали шаг квантования в три десятитысячных, то есть эффекта не было слышно вовсе.
     * Восемь бит на нижнем краю — это грязь, которую слышно, а на верхнем краю восемь бит
     * ещё чистые.
     */
    /*
     * 1..6 БИТ, А НЕ 1..8. Восемь бит — это почти чисто, и полезная часть хода сжималась к
     * самому краю. Шесть бит уже слышно как лёгкую шершавость, поэтому вся шкала работает.
     */
    const float bits = 1.0f + (1.0f - s_a) * 5.0f;
    const float steps = powf(2.0f, bits) - 1.0f;
    const float inv_steps = 1.0f / steps;
    const float tone = s_b;

    for (int i = 0; i < samples; i++) {
        const float ql = floorf(l[i] * steps + 0.5f) * inv_steps;
        const float qr = floorf(r[i] * steps + 0.5f) * inv_steps;

        l[i] = ql * (1.0f - tone) + l[i] * tone;
        r[i] = qr * (1.0f - tone) + r[i] * tone;
    }
}

void run_flanger(int samples, float *l, float *r)
{
    const float rate = 0.02f + s_a * 4.98f;
    const float depth = s_b;
    const float fb = s_c * 0.9f;
    const float inc = rate / (float)SYNTH_SAMPLE_RATE;

    /* Базовая задержка — середина линии, качание вокруг неё. */
    const float base = 200.0f;
    const float swing = 180.0f * depth;

    for (int i = 0; i < samples; i++) {
        s_m.phase += inc;
        if (s_m.phase >= 1.0f) {
            s_m.phase -= 1.0f;
        }

        const float d = base + swing * tri(s_m.phase);
        const int   di = (int)d;
        const float fr = d - (float)di;

        for (int ch = 0; ch < 2; ch++) {
            float *buf = (ch == 0) ? l : r;
            const int w = s_m.hold;       /* общий указатель записи на оба канала */

            int i0 = w - di;
            while (i0 < 0) {
                i0 += FXM_LINE;
            }
            int i1 = i0 - 1;
            if (i1 < 0) {
                i1 += FXM_LINE;
            }

            const float out = s_line[ch][i0] + (s_line[ch][i1] - s_line[ch][i0]) * fr;

            s_line[ch][w] = buf[i] + out * fb;
            buf[i] = buf[i] * 0.5f + out * 0.5f;
        }

        s_m.hold++;
        if (s_m.hold >= FXM_LINE) {
            s_m.hold = 0;
        }
    }
}

/* --- фазер ---------------------------------------------------------------- */

void run_phaser(int samples, float *l, float *r)
{
    const float rate = 0.02f + s_a * 4.98f;
    const float depth = s_b;
    const float fb = s_c * 0.8f;
    const float inc = rate / (float)SYNTH_SAMPLE_RATE;
    const float nyq = 0.45f * (float)SYNTH_SAMPLE_RATE;

    for (int i = 0; i < samples; i++) {
        s_m.phase += inc;
        if (s_m.phase >= 1.0f) {
            s_m.phase -= 1.0f;
        }

        /*
         * КОЭФФИЦИЕНТ — РАЗ В ШЕСТНАДЦАТЬ СЭМПЛОВ.
         *
         * Здесь стоял exp2f на КАЖДЫЙ сэмпл, и это стоило около миллисекунды на блок: на этом
         * камне показательная функция считается программно. Полоса качается медленно, и
         * ступенька в шестнадцать сэмплов (треть миллисекунды) на слух не читается.
         */
        static float g_hold;
        static float last_phase = -1.0f;

        if ((i & 15) == 0 || s_m.phase < last_phase) {
            last_phase = s_m.phase;

            const float m = 0.5f + 0.5f * tri(s_m.phase);
            float fc = 200.0f * exp2f(m * 1.7f * depth + 0.4f);

            if (fc > nyq) {
                fc = nyq;
            } else if (fc < 60.0f) {
                fc = 60.0f;
            }

            const float w = 3.14159265f * fc / (float)SYNTH_SAMPLE_RATE;
            g_hold = w / (1.0f + w * w * 0.3f);      /* tan, приближённо и дёшево */
        }

        const float g = g_hold;

        float xl = l[i] + s_m.fb_l * fb;
        float xr = r[i] + s_m.fb_r * fb;

        for (int a = 0; a < 6; a++) {
            const float yl = -g * xl + s_m.ap[a][0];
            s_m.ap[a][0] = xl + g * yl;
            xl = yl;

            const float yr = -g * xr + s_m.ap[a][1];
            s_m.ap[a][1] = xr + g * yr;
            xr = yr;
        }

        s_m.fb_l = xl;
        s_m.fb_r = xr;

        /* Полосовой выход: разность входа и выхода цепочки даёт гребёнку фазера. */
        l[i] = (l[i] + xl) * 0.5f;
        r[i] = (r[i] + xr) * 0.5f;
    }
}

/* --- SRR: уменьшение частоты выборки -------------------------------------- */

void run_srr(int samples, float *l, float *r)
{
    /* RATE: во сколько раз реже берётся отсчёт. SMOOTH: сглаживание после удержания, чтобы
     * зеркала не резали ухо — у нулевого порядка спектр очень яркий. */
    /*
     * ШАГ ПО ГЕОМЕТРИЧЕСКОЙ ШКАЛЕ.
     *
     * Линейная шкала давала музыкальные значения только у самого края: на середине хода шаг
     * был шестьдесят четыре, то есть сигнал уже разобран по кускам. Деление частоты вдвое,
     * вчетверо, в восемь раз — это шаги 2, 4, 8, и по геометрической шкале они приходятся на
     * разные места хода, а не на последний процент.
     */
    int step = (int)(exp2f(s_a * 7.0f) + 0.5f);

    if (step < 1) {
        step = 1;
    } else if (step > 128) {
        step = 128;
    }

    /* SMOOTH в ноль — без сглаживания, слышны все зеркала; в единицу — почти без них. */
    const float k = 1.0f - 0.98f * s_b;

    for (int i = 0; i < samples; i++) {
        if (s_m.hold <= 0) {
            s_m.hold = step;
            s_m.srr_l = l[i];
            s_m.srr_r = r[i];
        }
        s_m.hold--;

        /* Сглаженное значение ведёт за удержанным: fb_l/fb_r у SRR свободны. */
        s_m.fb_l += k * (s_m.srr_l - s_m.fb_l);
        s_m.fb_r += k * (s_m.srr_r - s_m.fb_r);

        l[i] = s_m.fb_l;
        r[i] = s_m.fb_r;
    }
}

/* --- STUTTER --------------------------------------------------------------- */

void run_stutter(int samples, float *l, float *r)
{
    /*
     * ОСНОВА ДЛИНЫ КУСКА, А НЕ ТОЧНОЕ ДЕЛЕНИЕ.
     *
     * A задаёт положение 0..3 (1/32, 1/16, 1/8, 1/4), но на каждом заходе жребий сдвигает его
     * на ступень вверх или вниз: заходы не повторяются один в один, оставаясь в ритме.
     */
    const int base_idx = (int)(s_a * 3.0f + 0.5f);
    const float beat = 60.0f / s_bpm * (float)SYNTH_SAMPLE_RATE;

    /*
     * B — ВЕРОЯТНОСТЬ, C — ЧИСЛО ПОВТОРОВ.
     *
     * Затухание было ручкой, и с быстрым затуханием заход читался как щелчок. Теперь оно
     * фиксированное и музыкальное: каждый повтор тише предыдущего на четырнадцать процентов.
     * Вместо него — вероятность: раз в две доли машина решает, делать заход или пропустить.
     */
    const float chance = s_b;
    int reps = 2 + (int)(s_c * 6.0f + 0.5f);

    if (reps < 2) {
        reps = 2;
    } else if (reps > 8) {
        reps = 8;
    }

    const float decay = 0.86f;

    /*
     * ПОДЪЁМ. Машина работает с шиной посыла, а в ней сигнал уже умножен на посыл — повторяя
     * его как есть, глитч выходил тише сухого ровно на величину посыла. 2.6 возвращает куску
     * уровень материала; больше не нужно, дальше уже слышно ограничитель.
     */
    const float makeup = 2.6f;
    const int beat_len = (int)(beat * 2.0f);

    for (int i = 0; i < samples; i++) {
        /* Сетка: раз в такт начинается новый заход. */
        if (s_running) {
            if (s_st_beat <= 0) {
                s_st_beat = beat_len;

                /* Жребий: chance 1 — каждый раз, chance 0 — никогда. */
                s_m.rng = s_m.rng * 1664525u + 1013904223u;

                if ((float)((s_m.rng >> 8) & 0xFFFFu) < chance * 65535.0f) {
                    /* Случайная ступень длины: −1, 0 или +1 от основы, с зажимом в 0..3. */
                    int idx = base_idx + (int)((s_m.rng >> 24) % 3u) - 1;

                    if (idx < 0) {
                        idx = 0;
                    } else if (idx > 3) {
                        idx = 3;
                    }

                    int len = (int)(beat / (float)(8 >> idx));

                    if (len < 64) {
                        len = 64;
                    } else if (len > FXM_SLICE_MAX) {
                        len = FXM_SLICE_MAX;
                    }

                    s_st_state = ST_RECORD;
                    s_st_pos = 0;
                    s_st_len = len;
                    s_st_reps = reps;
                    s_st_gain = 1.0f;
                }
            }
            s_st_beat--;
        }

        float sl = l[i];
        float sr = r[i];

        if (s_st_state == ST_RECORD) {
            s_slice[0][s_st_pos] = (int16_t)(sl * 32767.0f);
            s_slice[1][s_st_pos] = (int16_t)(sr * 32767.0f);

            /* Запись идёт сквозь сигнал: игрок слышит то, что запомнится. */
            if (++s_st_pos >= s_st_len) {
                s_st_pos = 0;
                s_st_state = (s_st_reps > 0) ? ST_LOOP : ST_IDLE;
            }
        } else if (s_st_state == ST_LOOP) {
            /*
             * ОКНО НА СТЫКАХ. Щелчок давали три прыжка: с живого входа на начало буфера, с
             * конца буфера обратно на начало (на каждом повторе) и обратно на вход. Окно в две
             * миллисекунды убирает щелчок, но оставляет слышимую нарезку.
             */
            /*
             * КРОССФЕЙД, А НЕ ГАШЕНИЕ В ТИШИНУ.
             *
             * Здесь окно умножалось на кусок, и на выходе из повтора сигнал прыгал с почти нуля
             * на живой вход — это и слышалось щелчком. Теперь окно задаёт ДОЛЮ куска: недостача
             * берётся из живого сигнала, поэтому вход в повтор и выход из него идут без
             * ступеньки, а между повторами остаётся слышимая нарезка.
             */
            float t_slice = 1.0f;

            if (s_st_pos < ST_XF) {
                t_slice = (float)s_st_pos * ST_XF_INV;
            }

            const int left = s_st_len - s_st_pos;
            const bool last = (s_st_reps <= 1);

            if (last && left < ST_XF) {
                const float out_t = (float)left * ST_XF_INV;

                if (out_t < t_slice) {
                    t_slice = out_t;
                }
            }

            float kl = (float)s_slice[0][s_st_pos] * (1.0f / 32768.0f) * s_st_gain * makeup;
            float kr = (float)s_slice[1][s_st_pos] * (1.0f / 32768.0f) * s_st_gain * makeup;

            if (kl > 1.2f) {
                kl = 1.2f;
            } else if (kl < -1.2f) {
                kl = -1.2f;
            }
            if (kr > 1.2f) {
                kr = 1.2f;
            } else if (kr < -1.2f) {
                kr = -1.2f;
            }

            sl = kl * t_slice + l[i] * (1.0f - t_slice);
            sr = kr * t_slice + r[i] * (1.0f - t_slice);

            if (++s_st_pos >= s_st_len) {
                s_st_pos = 0;
                s_st_gain *= decay;
                if (--s_st_reps <= 0 || s_st_gain < 0.02f) {
                    s_st_state = ST_IDLE;
                }
            }
        }

        l[i] = sl;
        r[i] = sr;
    }
}

/* --- кольцевой модулятор -------------------------------------------------- */

void run_ring(int samples, float *l, float *r)
{
    const float freq = 20.0f + s_a * 3980.0f;
    const float depth = s_b;
    const float shape = s_c;
    const float inc = freq / (float)SYNTH_SAMPLE_RATE;

    for (int i = 0; i < samples; i++) {
        s_m.phase += inc;
        if (s_m.phase >= 1.0f) {
            s_m.phase -= 1.0f;
        }

        /* Носитель — синус; SHAPE подмешивает его же, прогнанного через мягкий клип,
         * то есть квадрат. */
        const float car = tri(s_m.phase);
        float mod = car;

        if (shape > 0.0f) {
            const float sq = soft_clip(car * 8.0f);

            mod = car * (1.0f - shape) + sq * shape;
        }

        const float g = 1.0f - depth * (1.0f - mod) * 0.5f;

        l[i] *= g;
        r[i] *= g;
    }
}

/* --- гребёнка ------------------------------------------------------------- */

void run_comb(int samples, float *l, float *r)
{
    /* TUNE — непрерывный, от 60 Гц до 1200: резонатор можно ставить и между нотами, а подпись
     * просто говорит, попал ли он в ноту. FDBK и DAMP — как у любого резонатора. */
    const float tune = synth_fx_comb_hz(s_a);
    float delay = (float)SYNTH_SAMPLE_RATE / tune;

    if (delay > (float)(FXM_LINE - 2)) {
        delay = (float)(FXM_LINE - 2);
    } else if (delay < 4.0f) {
        delay = 4.0f;
    }

    const float fb = s_c * 0.95f;
    const float damp = 0.05f + s_b * 0.9f;

    for (int i = 0; i < samples; i++) {
        const int di = (int)delay;

        for (int ch = 0; ch < 2; ch++) {
            float *buf = (ch == 0) ? l : r;
            const int w = s_m.hold;

            int i0 = w - di;
            while (i0 < 0) {
                i0 += FXM_LINE;
            }

            float out = s_line[ch][i0];

            s_m.ap[0][ch] += damp * (out - s_m.ap[0][ch]);
            out = s_m.ap[0][ch];

            s_line[ch][w] = buf[i] + out * fb;
            buf[i] = buf[i] * 0.5f + out * 0.5f;
        }

        s_m.hold++;
        if (s_m.hold >= FXM_LINE) {
            s_m.hold = 0;
        }
    }
}

/* --- вибрато -------------------------------------------------------------- */

void run_vibrato(int samples, float *l, float *r)
{
    const float rate = 0.05f + s_a * 11.95f;
    const float depth = sqrtf(s_b);
    const float width = s_c;
    const float inc = rate / (float)SYNTH_SAMPLE_RATE;

    /* Глубина в сэмплах: 0.5 % периода при полном ходе. Вибрато — это задержка в несколько
     * миллисекунд, которая ходит туда-обратно. */
    const float base = 80.0f;

    /* Качание в сэмплах: при полном ходе задержка ходит на полторы миллисекунды, этого
     * хватает, чтобы вибрато читалось как вибрато, а не как лёгкое дрожание. */
    const float swing = 72.0f * depth;

    for (int i = 0; i < samples; i++) {
        s_m.phase += inc;
        if (s_m.phase >= 1.0f) {
            s_m.phase -= 1.0f;
        }

        float ph_r = s_m.phase + width * 0.5f;
        if (ph_r >= 1.0f) {
            ph_r -= 1.0f;
        }

        const float dl = base + swing * tri(s_m.phase);
        const float dr = base + swing * tri(ph_r);

        for (int ch = 0; ch < 2; ch++) {
            float *buf = (ch == 0) ? l : r;
            const float d = (ch == 0) ? dl : dr;
            const int   di = (int)d;
            const float fr = d - (float)di;
            const int   w = s_m.hold;

            int i0 = w - di;
            while (i0 < 0) {
                i0 += FXM_LINE;
            }
            int i1 = i0 - 1;
            if (i1 < 0) {
                i1 += FXM_LINE;
            }

            const float out = s_line[ch][i0] + (s_line[ch][i1] - s_line[ch][i0]) * fr;

            s_line[ch][w] = buf[i];
            buf[i] = out;
        }

        s_m.hold++;
        if (s_m.hold >= FXM_LINE) {
            s_m.hold = 0;
        }
    }
}

/* --- наклон --------------------------------------------------------------- */

void run_tilt(int samples, float *l, float *r)
{
    /* TILT: 0.5 — ровно, меньше — темнее, больше — ярче. MID: сколько середины поднять. */
    const float tilt = (s_a - 0.5f) * 2.0f;         /* -1 .. 1 */
    const float mid = s_b;

    const float lp_k = 0.02f + 0.35f * (0.5f + 0.5f * tilt);   /* темнее — ниже срез */
    const float hp_k = 0.02f + 0.35f * (0.5f - 0.5f * tilt);

    for (int i = 0; i < samples; i++) {
        s_m.lp_l += lp_k * (l[i] - s_m.lp_l);
        s_m.lp_r += lp_k * (r[i] - s_m.lp_r);

        s_m.ap[0][0] += hp_k * (l[i] - s_m.ap[0][0]);
        s_m.ap[0][1] += hp_k * (r[i] - s_m.ap[0][1]);

        /* Низ и верх в противофазе — это и есть наклон; MID поднимает середину. */
        const float ll = s_m.lp_l - (l[i] - s_m.ap[0][0]);
        const float rr = s_m.lp_r - (r[i] - s_m.ap[0][1]);

        l[i] = ll * (1.0f + mid * 0.5f) - ll * mid * 0.25f;
        r[i] = rr * (1.0f + mid * 0.5f) - rr * mid * 0.25f;
    }
}

} // namespace

float synth_fx_comb_hz(float v01)
{
    if (!(v01 >= 0.0f)) {
        v01 = 0.0f;
    } else if (v01 > 1.0f) {
        v01 = 1.0f;
    }

    /* Четыре с половиной октавы от 60 Гц: хватает и на бас, и на тело. */
    return 60.0f * exp2f(v01 * 4.3219f);
}

void synth_fx_comb_text(float v01, char *buf, int len)
{
    if (buf == NULL || len <= 0) {
        return;
    }

    const float hz = synth_fx_comb_hz(v01);
    const float midi = 69.0f + 12.0f * log2f(hz / 440.0f);
    const float near = floorf(midi + 0.5f);
    const float cents = (midi - near) * 100.0f;

    if (cents > -25.0f && cents < 25.0f) {
        static const char *const NAMES[12] = {
            "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B",
        };
        const int m = (int)near;
        const int oct = m / 12 - 1;
        const int deg = ((m % 12) + 12) % 12;

        snprintf(buf, (size_t)len, "%s%d", NAMES[deg], oct);
        return;
    }

    snprintf(buf, (size_t)len, "%d Hz", (int)(hz + 0.5f));
}

/* --- входы --------------------------------------------------------------- */

void synth_fx_machine_init(uint32_t sample_rate)
{
    (void)sample_rate;
    memset(&s_m, 0, sizeof(s_m));
    s_type = 0;

    for (int ch = 0; ch < 2; ch++) {
        if (s_slice[ch] == nullptr) {
            s_slice[ch] = (int16_t *)heap_caps_malloc(FXM_SLICE_MAX * sizeof(int16_t),
                                                      MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
        }
        if (s_slice[ch] != nullptr) {
            memset(s_slice[ch], 0, FXM_SLICE_MAX * sizeof(int16_t));
        }
    }
}

void synth_fx_machine_reset_state(void)
{
    memset(&s_m, 0, sizeof(s_m));
    memset(s_line, 0, sizeof(s_line));

    s_st_state = ST_IDLE;
    s_st_pos = 0;
    s_st_reps = 0;
}

void synth_fx_machine_set_type(int type)
{
    if (type < 0) {
        type = 0;
    } else if (type >= SYNTH_FXM_COUNT) {
        type = SYNTH_FXM_COUNT - 1;
    }

    if (type != s_type) {
        /*
         * СМЕНА ТИПА БЕЗ ЩЕЛЧКА: сначала тишина, потом новый эффект с нуля.
         *
         * Раньше здесь только чистилось состояние — и на выходе получался прыжок с хвоста
         * прошлого эффекта в новый звук. Теперь блок отдаётся в тишину, тип меняется, и
         * возврат поднимается за ST_FADE сэмплов.
         */
        s_m.fade = 0;                 /* этот блок — тишина */
        synth_fx_machine_reset_state();
        s_m.fade_pending = 1;
    }

    s_type = type;
}

void synth_fx_machine_set_tempo(float bpm, int running)
{
    if (!(bpm > 20.0f)) {
        bpm = 20.0f;
    } else if (bpm > 300.0f) {
        bpm = 300.0f;
    }

    s_bpm = bpm;
    s_running = running;
}

void synth_fx_machine_set_params(float a, float b, float c)
{
    s_a = clamp01f(a);
    s_b = clamp01f(b);
    s_c = clamp01f(c);
}

int synth_fx_machine_type(void)
{
    return s_type;
}

void synth_fx_machine_process(int samples, float *l, float *r)
{
    if (l == nullptr || r == nullptr || samples <= 0) {
        return;
    }
    if (samples > SYNTH_BLOCK_SAMPLES) {
        samples = SYNTH_BLOCK_SAMPLES;
    }

    /*
     * ПОСЛЕ СМЕНЫ ТИПА ВОЗВРАТ ПОДНИМАЕТСЯ ПЛАВНО. Первый блок отдаётся тишиной (её ставит
     * set_type), дальше окно в две миллисекунды.
     */
    if (s_m.fade_pending) {
        s_m.fade_pending = 0;
        s_m.fade = 96;
        for (int i = 0; i < samples; i++) {
            l[i] = 0.0f;
            r[i] = 0.0f;
        }
        return;
    }

    const int fade_in = s_m.fade;

    if (s_m.fade > 0) {
        s_m.fade -= samples;

        if (s_m.fade < 0) {
            s_m.fade = 0;
        }
    }

    switch (s_type) {
    case SYNTH_FXM_CHORUS:
        /* Хорус не переписан: он позван. Мокрый сигнал его собственный, возврат даёт стойка. */
        synth_chorus_set(0.1f + s_a * 7.9f, s_b, 1.0f);
        synth_chorus_process(samples, l, r);
        break;

    case SYNTH_FXM_TREMOLO:
        run_tremolo(samples, l, r);
        break;

    case SYNTH_FXM_AUTOPAN:
        run_autopan(samples, l, r);
        break;

    case SYNTH_FXM_DRIVE:
        run_drive(samples, l, r);
        break;

    case SYNTH_FXM_BITCRUSH:
        run_bitcrush(samples, l, r);
        break;

    case SYNTH_FXM_FLANGER:
        run_flanger(samples, l, r);
        break;

    case SYNTH_FXM_PHASER:
        run_phaser(samples, l, r);
        break;

    case SYNTH_FXM_SRR:
        run_srr(samples, l, r);
        break;

    case SYNTH_FXM_RING:
        run_ring(samples, l, r);
        break;

    case SYNTH_FXM_STUTTER:
        run_stutter(samples, l, r);
        break;

    case SYNTH_FXM_COMB:
        run_comb(samples, l, r);
        break;

    case SYNTH_FXM_VIBRATO:
        run_vibrato(samples, l, r);
        break;

    case SYNTH_FXM_TILT:
        run_tilt(samples, l, r);
        break;

    default:
        break;
    }

    if (fade_in > 0) {
        const float inv = 1.0f / 96.0f;

        for (int i = 0; i < samples; i++) {
            const int at = 96 - fade_in + i;
            const float g = (at >= 96) ? 1.0f : ((float)at * inv);

            l[i] *= g;
            r[i] *= g;
        }
    }
}
