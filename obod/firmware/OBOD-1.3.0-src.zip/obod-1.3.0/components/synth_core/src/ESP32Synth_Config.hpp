// Core Synth Limits
// Any values ​​changed here can positively or negatively impact performance.
// Changing them is not dangerous; choose your ideal values.
#pragma once
#include <stdint.h>
#ifndef ESP32_SYNTH_CONFIG_HPP
#define ESP32_SYNTH_CONFIG_HPP

/*
    To test and confirm the maximum polyphony on your ESP32,
    increase MAX_VOICES and set everything else to 0 so it
    doesn't consume the RAM needed for the voices.
    This issue was only found on the ESP32-DOWD-Q6, not on the S3,
    but it's good to leave a note here.
*/

/* Maximum Tested MAX_VOICES Values (ESP32 & ESP32-S3):

    ESP32:
     RAM-safe max: 140
     Default:       80
     Absolute max: 340
     FreeRTOS task starvation / jitter at: 346

    ESP32-S3:
     RAM-safe max: 150
     Default:       80
     Absolute max: 500
     FreeRTOS task starvation / jitter at: 515

    Note: These limits are based on testing with the default settings and may vary
    depending on the complexity of the patches, use of wavetables, samples, and SD
    streaming. Always test with your specific use case to find the optimal balance
    between polyphony and performance. And with each voice, more memory is allocated.
*/

/*
  ====================================================================================
   THE AUDIO BLOCK
   The one number the whole audio path is sized by: how many samples one pass of the
   audio task renders, and therefore how many samples the engine renders in one call.
   The DSP declares it out of this header (synth_dsp.h) rather than keeping a second
   copy, and every buffer, coefficient and threshold in the path is either this value,
   derived from it, or expressed in samples or seconds so that it does not depend on it.

   It lives here because the engine's render chunk must equal it: a chunk smaller than
   the block would split one block into two passes of the bus FX, and the pan capture
   adds into the layer accumulators, so the first half would land twice and the second
   half not at all.

   256 rather than 128: the block deadline doubles while the per-block costs (fuse,
   watchdog, parameter apply, the I2S write, the engine's own chunk setup) do not.
  ====================================================================================
*/
#ifndef SYNTH_BLOCK_SAMPLES
#define SYNTH_BLOCK_SAMPLES 256
#endif

/*
  ====================================================================================
   LOCAL CONFIGURATION - Guition JC3636K718C drone synth (vendored patch)
  ====================================================================================
   Upstream these six were unconditional #defines, so overriding them with -D was a
   redefinition error rather than an override. They are #ifndef-guarded here and the
   values below are this project's defaults.

   Sized for the pull-mode drone synth: the engine is driven by our own audio task,
   SD streaming and MP3 are unused, and internal RAM is shared with LVGL and Wi-Fi.

   Upstream defaults were VOICES 80, WAVETABLES 20, SAMPLES 20, ARP 16, STREAMS 4,
   STREAM_BUF_SAMPLES 4096 (~66 KB of static RAM). These values cost ~9.5 KB.
  ====================================================================================
*/
#ifndef MAX_VOICES
/*
 * 30, А НЕ 24: девять голосов дрона, восемнадцать лида (шесть групп по три) и три
 * арпеджиатора ровно занимают потолок. Раньше лида было четыре группы, и шесть секунд
 * отпускания физически некуда было звучать — хвост отбирала следующая нота.
 */
#define MAX_VOICES         21   // 6 drone (3 x 2) + 12 lead (4 x 3) + 3 arp
#endif
#ifndef MAX_WAVETABLES
#define MAX_WAVETABLES      8   // one band-limited table per drone register
#endif
#ifndef MAX_SAMPLES
#define MAX_SAMPLES         4   // unused (no WAV/SD playback); must stay non-zero, arrays are sized by it
#endif
#ifndef MAX_ARP_NOTES
#define MAX_ARP_NOTES       4   // we run our own sequencer; the engine arpeggiator is unused
#endif
#ifndef MAX_STREAMS
#define MAX_STREAMS         1   // cannot be 0: the class holds StreamTrack streams[MAX_STREAMS]
#endif
#ifndef STREAM_BUF_SAMPLES
#define STREAM_BUF_SAMPLES 512  // power of two; 512 x 2 B = 1 KB per track
#endif

/*
  ====================================================================================
   WAVE MORPH SCRATCH
   The largest block a voice's crossfade can be rendered into. A morphing voice is
   rendered TWICE, once per shape, into two scratch buffers of this size, which is
   why the number is here rather than in the header that uses it: it is a RAM
   decision, and it is the only cost this feature has when nothing is morphing.

   256 samples x 4 B x 2 buffers = 2 KB of .bss at the 128-sample block this was
   written for. It is the block size, not a number of its own: a caller with a larger
   block is handled rather than trusted — see ESP32Synth::renderVoiceMorph(), which
   falls back to the instant switch, silently and in one comparison, instead of
   writing past these arrays.
  ====================================================================================
*/
#ifndef SYNTH_MORPH_BLOCK_MAX
#define SYNTH_MORPH_BLOCK_MAX SYNTH_BLOCK_SAMPLES
#endif

/*
  ====================================================================================
   CUSTOM SYNTHESIS PARAMETERS
   Increasing these values allows for more complex custom waves/DSPs, 
   but increases the RAM footprint per voice. Default values are highly optimized.
  ====================================================================================
*/ 
#ifndef SYNTH_CUSTOM_WAVE_STATES
#define SYNTH_CUSTOM_WAVE_STATES      6 // cw array size (uint32_t). 6 keeps the Union at exactly 24 bytes.
#endif

#ifndef SYNTH_CUSTOM_PARAMS_PER_VOICE
#define SYNTH_CUSTOM_PARAMS_PER_VOICE 8 // cp array size (int16_t).
#endif

#ifndef SYNTH_CUSTOM_PARAMS_GLOBAL
#define SYNTH_CUSTOM_PARAMS_GLOBAL    4 // dp array size (int16_t).
#endif

/*
  ====================================================================================
   MODULAR FX ROUTING & BUSES
  ====================================================================================
*/
/*
 * 6, not the upstream 4.
 *
 * Bus 0 is the engine's master and never runs FX — the mixdown loop starts at
 * bus 1 — so the five instrument layers need buses 1..5. With the upstream
 * value, setVoiceBus() and setBusFX() silently ignore ids >= 4: the layer's
 * voices would render into bus 0 instead, and bus 0 is exactly the output this
 * firmware discards. The layer would be inaudible with no error anywhere.
 *
 * Costs two extra AudioBus objects, about 304 B.
 */
#ifndef MAX_BUSES
#define MAX_BUSES         10 // 0 = мастер, 1..6 = шесть слоёв, 7..9 = три ноты аккорда лида
#endif

#ifndef MAX_FX_PER_BUS
#define MAX_FX_PER_BUS    3  // Max effect slots chained per bus
#endif

#ifndef SYNTH_FX_PARAMS
#define SYNTH_FX_PARAMS   8  // Effect Parameters array size (ep)
#endif

#ifndef SYNTH_FX_STATES
#define SYNTH_FX_STATES   6  // Effect States array size (es)
#endif

// --- SD Recording Buffer ---
// 16384 samples = ~32KB of RAM (Only allocated while recording!)
// MUST be a power of 2 for extremely fast bitwise mask wrap-around.
#ifndef RECORD_BUF_SAMPLES
#define RECORD_BUF_SAMPLES 16384 
#define RECORD_BUF_MASK    (RECORD_BUF_SAMPLES - 1)
#endif

/*
  ====================================================================================
   HELIX MP3 STREAMING ENGINE (Fixed-Point, Zero-Floats)
   Enables on-the-fly MP3 streaming directly from PROGMEM or SD Card on Stream core.
   Preserves 100% of polyphony on DSP core.
  ====================================================================================
*/
#ifndef ENABLE_MP3
#define ENABLE_MP3 0   // local: no MP3 streaming, so the Helix decoder is not compiled
#endif
#ifndef SYNTH_MP3_IN_BUF_SIZE
#define SYNTH_MP3_IN_BUF_SIZE 2048
#endif

/*
    DMA buffers to control latency vs polyphony:
    - Smaller buffers reduce latency but increase CPU load and risk of audio dropouts
      if processing can't keep up.
    - Larger buffers allow for more stable audio at high polyphony or complex processing,
      but increase latency.

    Latency formula (ms) = (buf_len * buf_count) / sample_rate * 1000

    [Default] LEN: 512 | COUNT: 6  (high polyphony, slight delay)
    [Balance] LEN: 256 | COUNT: 4  (good for most MIDI keyboards)
    [LIVE]    LEN: 128 | COUNT: 2  (imperceptible latency, slightly less polyphony)

    [You have an audio analyzer in mind] LEN: 64 | COUNT: 2 (Impressive!)

    It's a joke, please don't take it seriously (works but possible low polyphony, not recommended):
    [You have something against the ESP32's CPU] LEN: 32 | COUNT: 2 (ESP32: "INCREASE THE BUFFER, THIS IS TORTURE!!!")
    [You want to see the limits of the ESP32]    LEN: 16 | COUNT: 2 ("Results are in and your ESP32 is in a coma.")
*/

#ifndef SYNTH_DMA_BUF_LEN
#define SYNTH_DMA_BUF_LEN 512
#endif

#ifndef SYNTH_DMA_BUF_COUNT
#define SYNTH_DMA_BUF_COUNT 6
#endif

// Core Task Pinning
// Stream / Decoding core
#define SYNTH_STREAM_TASK_CORE 0
#define SYNTH_SD_TASK_CORE     SYNTH_STREAM_TASK_CORE // Backward compatibility
// DSP core
#define SYNTH_AUDIO_TASK_CORE  1

/* 
  ====================================================================================
      SINE WAVE LOOK-UP TABLE
  ====================================================================================
*/ 
#define SINE_LUT_SIZE 4096
#define SINE_LUT_MASK (SINE_LUT_SIZE - 1)
#define SINE_SHIFT    20

// 0 = Maximum Polyphony (300+ voices, truncated phase LUT)
// 1 = Studio Quality (Interpolated LUT, >130 dBc SFDR, pristine FM / Overdrive)
#ifndef SYNTH_INTERPOLATE_SINE
#define SYNTH_INTERPOLATE_SINE 1
#endif

// Shared sine LUT (+1 guard sample for zero-branch, single-cycle interpolation wrap)
extern int16_t sineLUT[SINE_LUT_SIZE + 1];

#define STREAM_BUF_MASK (STREAM_BUF_SAMPLES - 1)
#define ENV_MAX 268435456

#endif // ESP32_SYNTH_CONFIG_HPP