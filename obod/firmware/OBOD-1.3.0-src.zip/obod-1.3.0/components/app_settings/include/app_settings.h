/*
 * Settings that belong to the device rather than to the sound.
 *
 * WHY THIS IS NOT PART OF synth_app
 *   Everything in synth_app is a parameter of the instrument: it is chosen by ear
 *   and thrown away when the tuning changes. Everything here is a property of the
 *   board — how bright it is, how it answers the fingers, whether the ring is
 *   allowed to glow, and whether the sound is worth keeping. They are stored
 *   under different keys, and only the last of them is ever restored
 *   automatically.
 *
 * WRITES ARE DEFERRED
 *   An NVS write is a flash write. A knob that is turned fifty times while it
 *   travels would be fifty writes if they were made inline, which is how a flash
 *   sector gets tired; so a value reaches the hardware at once and the flash
 *   after the movement stops. Nothing here blocks: the caller is the UI task,
 *   which is also the task that has to keep drawing the screen.
 *
 * APPLYING IS NOT THE CALLER'S JOB
 *   The two settings the board can enact on its own are enacted here, because
 *   there is exactly one right answer for each and no reason for two callers to
 *   be able to disagree about it.
 */
#pragma once

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    APP_SET_SCREEN = 0,   /* backlight, 0..100 percent */
    APP_SET_RING,         /* LED ring, 0..100 percent */
    APP_SET_RING_MODE,    /* app_ring_mode_t */
    /*
     * RESET USED TO HAVE THIS SLOT, and the slot is gone rather than reused.
     *
     * The realignment periods moved to the PATCH — one for the lead and, later, one for the
     * drum — so a preset carries its own and changing the preset changes them: see
     * SYNTH_PARAM_SEQ_RESET and SYNTH_PARAM_PERC_RESET in synth_app.h and app_seq_reset_t
     * below. That leaves a hole here on purpose — the rim sector it occupied on SYSTEM is
     * empty, and the vibration motor that sector held before RESET is not coming back.
     *
     * A hole in this enum is harmless because nothing is stored by number: SETTINGS[] is
     * read and written under its own string key, and the stored settings keep their keys
     * and their meanings. The entries after it renumber, which is why the note over
     * APP_SET_MIC says a new setting is appended rather than inserted.
     */
    APP_SET_PATCH,        /* app_patch_mode_t */
    APP_SET_SLIDE,        /* index into the parameter-slide durations */
    APP_SET_RND_DELAY,    /* may the randomiser draw a new delay time */
    /*
     * Microphone sensitivity, 0..100 percent, zero meaning off. A device setting and
     * not a patch parameter: it is a fact about the room the instrument is standing in
     * rather than about the sound, so it is stored under its own key and survives a
     * change of patch, a preset load and a random draw. Appended at the end for the
     * same reason a patch parameter is: SETTINGS[] is indexed by this enum, and an
     * entry inserted in the middle would renumber the ones after it.
     */
    APP_SET_MIC,          /* microphone sensitivity, 0 = off */
    /*
     * The velocity a NON-accented hit is struck at, in the engine's own units: whole
     * numbers 0..127, factory 80.
     *
     * A setting and not a patch parameter, because this is a fact about how the instrument
     * is played rather than about the sound in a slot. So it is stored under its own key,
     * survives a preset load and a random draw, and never appears in a saved sound or in a
     * preset.
     *
     * The three values worth knowing by heart:
     *   127  no difference — a weak hit is struck at full velocity, which is the
     *        instrument exactly as it was before the accent existed;
     *    80  the factory value, 20*log10(127/80) = 4.01 dB below an accented hit;
     *     0  there are no weak hits at all. The engine reads a velocity that is not
     *        greater than zero as "no hit" — see synth_perc_trigger() in synth_perc.cpp
     *        — so only the accented onsets sound. That is the intended behaviour and
     *        not a defect: the knob's bottom is silence for every unmarked step.
     *
     * Appended after the microphone for the reason the microphone is appended:
     * SETTINGS[] in app_settings.c is indexed by this enum, so an entry inserted in the
     * middle would renumber the ones after it. The range and the fallback are written
     * out twice on purpose — this component cannot include synth_app.h, which requires
     * it — and accent_velocity_weak() in synth_app.cpp divides by its own copy of 127 and
     * clamps, so a disagreement between the two would be harmless rather than audible.
     */
    APP_SET_WEAK_VEL,     /* velocity of a weak hit, 0..127; 127 = no accent at all */
    /*
     * Is the instrument a USB MIDI DEVICE — 0 off, 1 on — and the factory answer is OFF.
     *
     * A setting and not a patch parameter, for the reason the two before it give: this is a
     * fact about the socket rather than about the sound in a slot. So it has its own key, it
     * survives a preset load, and no saved sound carries it.
     *
     * WHY OFF IS THE DEFAULT, AND WHY IT IS A SETTING AT ALL
     *   USB-Serial-JTAG and USB-OTG are two controllers behind ONE PHY on this chip, so while
     *   the device stack is up the USB-C socket is a MIDI port and NOT the debug console: the
     *   log and the port esptool talks to are gone from the computer until the board is put
     *   into the ROM loader by hand. That is a large price to pay for an input nobody has
     *   asked for yet, so the factory state is the one that keeps the port, and ON is a
     *   decision the player makes on the screen — see APP_SET_MIDI_IN's sector on OPTIONS.
     *
     *   Which is also why it is not a compile-time switch: the setting can be turned while
     *   the instrument plays, and turning it off takes the driver down and releases the USB
     *   controller. It does NOT hand the port back live, and that is the measured part rather
     *   than the hoped-for one: the debug console is on the cable again only after a reboot
     *   with this OFF, because the console's controller is a second one that the uninstall
     *   does not touch. The mechanism is in components/midi (midi_in_set_enabled()), and what
     *   it can and cannot promise about the port is written out beside that call and in
     *   midi_in.h.
     *
     * Appended after the weak hit for the reason that one was appended after the microphone:
     * SETTINGS[] in app_settings.c is indexed by this enum, so an entry inserted in the middle
     * would renumber the ones after it.
     */
    APP_SET_MIDI_IN,      /* USB MIDI note input, 0 = off (and the console keeps the port) */
    /*
     * How long a change of WAVE takes to become audible, as the INDEX of a list of durations:
     * 0, 5, 10, 15, 20, 25, 30, 40, 60, 80 and 100 ms, so 0..10, and 25 ms — index 5 — out of
     * the factory. The durations themselves are in synth_app.cpp (WAVE_MORPH_MS), which is the
     * only thing that can act on them, exactly as the slide's durations are.
     *
     * A setting and not a patch parameter, for the reason the three before it give: this is a
     * fact about how the instrument is played rather than about the sound in a slot — a patch
     * saved with a different fade would be a patch that only sounded right on one instrument.
     * So it has its own key, it survives a preset load, and no saved sound carries it.
     *
     * WHY IT EXISTS. WAVE is a list, and every list on this instrument arrives in one step by
     * design (see synth_app.cpp). That is right for the shape of a silent voice and audible as
     * a click on a sounding one, which is what turning the drone's WAVE knob while the drone
     * plays does. The step cannot be smoothed on the parameter — it is a list, it is stored in
     * a preset and drawn by the randomiser — so the smoothing is inside the VOICE instead: the
     * engine renders the old shape and the new one for the same span and crossfades them, and
     * this setting is how long that takes. See setWaveSmooth() in
     * components/synth_core/src/ESP32Synth.h and wave_apply() in synth_app.cpp.
     *
     * 0 IS THE OLD BEHAVIOUR, exactly: the shape changes on the next block and the voice is
     * rendered once, as it always was. The factory value is deliberately not 0 — a click is not
     * a good first impression — but 0 is a real position on the knob, and the one to use if a
     * future phase wants the step back.
     *
     * Appended after the MIDI input for the reason the weak hit was appended after the
     * microphone: SETTINGS[] in app_settings.c is indexed by this enum, so an entry inserted in
     * the middle would renumber the ones after it.
     */
    APP_SET_WAVE_MORPH,
    /*
     * THE DRIVE'S PLACE IN THE RACK: a dead entry, kept for the same reason the dead patch
     * parameters are kept.
     *
     * It held 0 for before the effects and 1 for after them, and it went out with the drive
     * itself. It stays here because SETTINGS[] below is indexed by this enum: an entry removed
     * from the middle would hand every stored setting after it to a different key, so a device
     * would read its brightness as its ring mode. Nothing consults it and OPTIONS no longer
     * offers it; the stored key "drv_fx" is simply never written again.
     */
    APP_SET_DRIVE_POS,   /* dead: was the drive's place in the rack */
    /*
     * АВТОЗАПУСК И ПОСЛЕДНЕЕ СОСТОЯНИЕ ТРАНСПОРТА.
     *
     * AUTOPLAY: 0 — играть сразу (как было), 1 — включаться молча, 2 — помнить, играл ли
     * транспорт при выключении. TRANSPORT — сам флаг для третьего положения; пишется при
     * каждом изменении транспорта, потому что выключение бывает и аварийным.
     */
    APP_SET_AUTOPLAY,
    APP_SET_FASTRAND,   /* 0 — выкл, 1 — ручка, 2 — страница */
    APP_SET_TRANSPORT,
    APP_SET_COUNT
} app_setting_t;

typedef enum {
    APP_RING_PAGE = 0,    /* whatever the current page is about */
    APP_RING_STEREO,      /* always the stereo field */
    APP_RING_OFF,         /* never lit */
    /*
     * Appended rather than inserted: what is stored is the value, so a mode that moved
     * would turn every saved ring setting into a different one.
     */
    APP_RING_REACTIVE,    /* the sound's own picture: what plays, and where it sits */
    /*
     * Два режима, которых просил владелец.
     *
     * ALWAYS — кольцо горит целиком и всегда, цветом текущего раздела: это лампа прибора, а не
     * индикатор. TEMPO — тоже всегда, но тускло, и вспыхивает на каждую долю: метроном без
     * щелчка.
     */
    APP_RING_ALWAYS,
    APP_RING_MODE_COUNT
} app_ring_mode_t;

/*
 * The list of positions both RESET parameters share.
 *
 * INF is the gesture switched off, and the instrument as it has always been: the
 * lead, the drums and the arpeggiator each derive their step from the one transport
 * position, so they cannot drift apart and there is nothing to correct. A number is
 * a musical gesture — that part deliberately begins its phrase again after that many
 * steps of ITS OWN grid — and the same list serves two parameters that never act on
 * each other: SYNTH_PARAM_SEQ_RESET counts lead steps and moves the lead's (and the
 * arpeggiator's) origin, SYNTH_PARAM_PERC_RESET counts drum steps and moves the
 * drum's. See those two in synth_app.h.
 *
 * The value lives in the PATCH and in a PRESET, not in the settings: it is part of
 * what makes one sound different from another, so a preset brings its own periods
 * and moving the preset moves both RESET knobs with it. It is stored as the
 * parameter's normalised position in the patch (and therefore as one byte of a
 * preset record).
 *
 * The stored value is the POSITION, not the step count, so the list can gain a
 * longer setting later without renumbering the ones a device already holds.
 *
 * A RECORD WITHOUT THE LEAD'S FIELD MEANS SIXTEEN, NOT "OFF"; a record without the
 * drum's means INF. The first is the default the field had when it was written; the
 * drum never started resetting before its field existed, so its missing byte must
 * leave the drum exactly as it sounded. Both are applied by
 * synth_app_preset_load(), because a record is a prefix of the parameter list and
 * this component cannot know what the tail was meant to be.
 */
typedef enum {
    APP_SEQ_RESET_INF = 0,
    APP_SEQ_RESET_16,
    APP_SEQ_RESET_32,
    APP_SEQ_RESET_64,
    APP_SEQ_RESET_128,
    APP_SEQ_RESET_256,
    APP_SEQ_RESET_COUNT
} app_seq_reset_t;

/* The number of grid steps a position stands for — the lead's or the drum's, this one
 * list serves both RESET parameters; 0 is INF, meaning never. */
int app_seq_reset_steps(int index);

/*
 * What the instrument should sound like when it is switched on.
 *
 * FORGET boots the designed sound; STORE brings back the sound it was last played
 * with; and RANDOM throws a new one: the same structural draw a long press on RND
 * makes, rhythm, key and all, so that switching it on is never twice the same.
 * The two original meanings keep their stored numbers, so a device that has
 * already been configured does not change what it does.
 */
typedef enum {
    APP_PATCH_FORGET = 0,
    APP_PATCH_STORE,
    APP_PATCH_RANDOM,
    APP_PATCH_COUNT
} app_patch_mode_t;

/* How many floats the remembered sound is allowed to hold. The patch is 131 of these, and
 * synth_app.cpp asserts that against this ceiling rather than letting the two agree by
 * themselves. It moved with the patch when the drone's three shapes and its FOLLOW joined
 * the list, and again for the two key trackers appended after FOLLOW; a blob written by the
 * older firmware is a prefix of this one and loads through synth_app_patch_apply(), which
 * repairs what the shorter record cannot carry. It moved once more for the lead filter
 * envelope's SHAPE, which is the newest append of all and the one a record written before
 * it reads as the equal split, once more for SPAN, the octaves the melody walks, once
 * more for DRIFT, the cents the drone's registers lean by, and once more for the bass
 * section's sixteen, appended at the end of the patch as one block. */
#define APP_SETTINGS_PATCH_MAX 148

/* true — патч ждёт остановки транспорта: запись памяти стоит звуку нескольких миллисекунд. */
void app_settings_patch_hold(bool hold);

/*
 * THE TEMPO IS KEPT APART FROM EVERYTHING ELSE.
 *
 * SYNTH_PARAM_SEQ_TEMPO is a patch parameter, and rightly: a preset is a copy of the sound and
 * a sound played at 96 BPM should come back at 96. But the patch has three modes and two of them
 * do not bring the sound back — FORGET boots the designed one and RANDOM draws a fresh one,
 * rhythm included — so the tempo of the last session went with it, and the instrument came on at
 * a different tempo every time. Where the clock stands is not a decision about the sound: it is
 * where the player left it. Hence its own key, restored at boot after the patch and after any
 * draw, whatever the PATCH setting says.
 *
 * A float and not a BPM: the value is the knob's position, which is what the sequencer and the
 * delay read. Rounding it to whole beats would put the wheel back on a different detent after
 * every switch-on, and a knob that moves by itself is worse than one that is not remembered.
 */
void app_settings_tempo_note(float v01);

/* False when nothing has ever been stored — the boot then keeps whatever it has. */
bool app_settings_tempo_load(float *out);

/*
 * Reads NVS and applies the two settings the board can act on.
 *
 * Safe to call before app_net_init(): NVS is initialised here if it is not up
 * already, and a corrupt or repartitioned NVS partition is erased rather than
 * left to fail every read for the rest of the boot.
 *
 * Returns a bitmask of the settings that were actually found, for the log. A
 * setting that was never stored reads back as its fallback, which is the value
 * the hardware is already at — so the display never disagrees with the device.
 */
uint32_t app_settings_init(void);

/* Always returns a usable value, never a "missing" marker. */
int app_settings_get(app_setting_t id);

/* Clamps, applies to the hardware, and queues a flash write. */
void app_settings_set(app_setting_t id, int value);

/* Writes anything pending now instead of waiting for the timer. */
void app_settings_commit(void);

/* --- The remembered sound ------------------------------------------------- */

/*
 * How a stored patch value is repaired. Called from app_settings_patch_load() for every
 * value that is not finite or is outside 0..1 — the control surface's whole range — and
 * must return the factory value for that parameter. The table of factory values lives in
 * synth_app, which this component cannot include: the dependency runs the other way.
 *
 * Installed once by synth_app_start(). Until then a bad value falls back to 0.
 */
typedef float (*app_settings_patch_repair_t)(int index, float value);

void app_settings_patch_set_repair(app_settings_patch_repair_t repair);

/* Returns how many floats were read; 0 when nothing is stored. Every value is checked for
 * finiteness and range on the way out; a bad one is replaced by its factory value and
 * reported in one log line naming the parameter and the number that was there. */
int app_settings_patch_load(float *out, int count);

/* Queues `count` floats to be written once the knobs stop moving. */
void app_settings_patch_note(const float *in, int count);

/* Erases the stored sound. Called when the device is told to forget it. */
void app_settings_patch_forget(void);

/* --- Presets -------------------------------------------------------------- */
/*
 * WHY THESE ARE NOT PART OF THE PATCH
 *   The patch is the sound as it is now, and there is exactly one of it: it is
 *   restored by itself at boot, because coming up on the last sound you were
 *   making is right. A preset is a sound you decided to keep, and there are up
 *   to 128; coming up on an arbitrary one of them would not be.
 *
 * WHY A BYTE PER PARAMETER
 *   Everything the control surface holds is a normalised 0..1 float, and all of
 *   it is displayed as whole percent. 255 steps cover 0..100 exactly, so a
 *   preset shows the same numbers on the screen after a load as it showed when
 *   it was saved. Four bytes a parameter would spend 248 bytes on a record of
 *   which 190 were precision this instrument cannot express.
 *
 *   A record is 134 bytes: three of header and one per parameter, no count field,
 *   because NVS already stores a blob's length. 128 of them is 17.2 KB, which
 *   fits the 24 KB NVS partition beside the settings — so presets need no
 *   partition table change, survive every reflash, and put no card in the boot
 *   path.
 *
 *   The layout is frozen at format version 1, and the store carries that version
 *   in an entry of its own, so an upgrade rewrites nothing. An image that meets a
 *   store it cannot read refuses the slots and leaves them in the flash rather
 *   than erasing them — app_presets.c prints one line about it at every boot.
 */
/*
 * 96, а не 128: запись патча стала 134 байта, а в NVS такая запись занимает 192 — заголовок
 * 32-байтового поля плюс сами данные, округлённые до пяти полей. 128 записей — это 24 576
 * байт, ровно весь раздел 0x6000, и на имена и счётчик в нём не остаётся ничего. 96 — это
 * 18 432 байта, и запас есть.
 */
#define APP_PRESET_MAX       96
/* One byte per parameter, and a record is a PREFIX of the parameter list rather than a
 * fixed size: app_settings_preset_load() hands back as many values as the record carried,
 * so a sound saved by an older firmware loads with the parameters it did not have yet at
 * their defaults. That is what lets a parameter be appended without a format change.
 * RESET is what this was last used for, twice: the lead's parameter and then the drum's
 * were appended to the end of the list. A record without the lead's field reads as the
 * factory sixteen and one without the drum's as INF — the gesture off — and
 * synth_app_preset_load() applies both, because app_settings.c cannot know what a short
 * record was meant to carry. It grew again for the drone's three shapes and FOLLOW; those
 * are answered from the record's own old DRONE_WAVE byte, in synth_app_patch_apply(). The two
 * key trackers are the latest append, and a record without them reads their factory zero.
 * The lead filter envelope's SHAPE is the newest of all: a record without it reads the
 * equal split, which is the factory position. THE BASS SECTION'S sixteen are the last
 * append: one block at the end of the patch, and a record without them keeps the defaults
 * its own boot filled in. */
#define APP_PRESET_PARAM_MAX 148
#define APP_PRESET_NAME_MAX  16   /* "AMBER CROW" and a terminator */

/*
 * Opens the preset namespace and reads the name table. Called by
 * app_settings_init() once NVS is up — not something a caller needs.
 */
void app_presets_init(void);

/* How many presets exist. Dense: 0..count-1, and a save at the end appends. */
int app_settings_preset_count(void);

/* The name of a preset, upper case. False when the slot holds nothing. */
bool app_settings_preset_name(int slot, char *out, size_t len);

/*
 * Saves the given values into `slot`, overwriting whatever is there; a slot at
 * or past the end of the list appends, which is what the first save on an empty
 * device does.
 *
 * Every save draws a NEW name, an overwrite included. The name describes what is
 * in the slot rather than marking the slot itself, so a row in the list can
 * never say one thing while holding another.
 *
 * Returns the slot written, or -1 on failure.
 */
int app_settings_preset_save(int slot, const float *values, int count);

/* Reads a preset back. Returns how many values were read; 0 when it is empty. */
int app_settings_preset_load(int slot, float *out, int count);

/*
 * Удаление слота: магазин закрывает дыру, сдвигая хвост на одну запись вниз.
 *
 * Дырки в середине магазин не знает и знать не хочет — номер слота здесь и есть его
 * индекс, а `app_settings_preset_name()` отвечает без таблицы занятости. Поэтому
 * удаление СДВИГАЕТ записи после удаляемой, а не помечает её пустой, и число слотов
 * уменьшается на один. Имена едут вместе со звуками: имя описывает звук, а не место,
 * и имя удалённого звука возвращается в пул свободных.
 *
 * Возвращает новое число слотов (0 — магазин опустел) или -1, если слот не удалён.
 * Слот, который не читается, останавливает сдвиг: магазин с хвостом лучше магазина,
 * в котором запись потерялась молча.
 */
int app_settings_preset_delete(int slot);

#ifdef __cplusplus
}
#endif
