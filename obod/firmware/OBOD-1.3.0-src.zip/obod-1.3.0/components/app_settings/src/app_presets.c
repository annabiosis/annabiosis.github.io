/*
 * Presets: the sounds the player decided to keep.
 *
 * app_settings.h says why a parameter is stored as one byte and why the name
 * belongs to the slot. What belongs here is the shape of the storage.
 *
 * THREE KEYS, NOT 129
 *   The parameters of each preset live in their own NVS entry, `p0`..`p127`, so
 *   a save writes 134 bytes and cannot disturb the others. The name indices of
 *   all of them live in one small blob, because the interface wants every name
 *   the moment the list opens, and one read of 256 bytes beats 128 reads of two.
 *   A save therefore writes two entries and commits once.
 *
 *   If the power goes between them the worst case is a name in the table with no
 *   record behind it. The load then returns nothing, the interface draws an
 *   empty row, and the next save fills both. Nothing becomes unreadable, and
 *   nothing is lost that was not already in the middle of being written.
 *
 *   The third key is the format stamp, one byte that answers for the whole
 *   store. See the next section.
 *
 * WHY THE NAME IS DRAWN, NOT NUMBERED
 *   A numbered slot says where a sound is, not what it is: scrolling 128 rows of
 *   P001..P128 is reading a phone book. Two words say something, and 576 of them
 *   cover 128 slots with room to spare. The draw is repeated when it collides
 *   rather than nudged by one, so the names do not march in step with the order
 *   they were saved in.
 *
 * WHERE THE FORMAT VERSION LIVES, AND WHY IT IS NOT IN THE PARAMETERS
 *   A record is a three-byte header — version, adjective, noun — and then one
 *   byte per parameter. The version byte has been there since the first firmware
 *   that could write a record, and it stays: it is what lets a store describe
 *   itself to a later image, and moving it would shift every parameter by one
 *   byte and turn every saved sound into noise.
 *
 *   The same number is kept once more for the store as a whole, in the `fmt`
 *   entry. A version per slot would be the tidier place for it, but NVS spends a
 *   32-byte entry header on every key, so 128 of them would cost more than the
 *   presets they describe and 128 reads to check. One entry answers for the whole
 *   store in one read at boot, which is what the line in app_presets_init()
 *   reports.
 *
 *   A store stamped with any other version is REFUSED, never erased: nothing is
 *   listed, read or written, and the image that speaks that version finds its
 *   presets exactly where it left them. That is the whole difference between
 *   "this build cannot read it" and "this build threw it away" — and the second
 *   one throws away sounds that cannot be got back.
 *
 * WHY THE VERSION WENT UP WITHOUT THE LAYOUT MOVING
 *   Version 1 is the only layout that has ever shipped and version 2 has the same
 *   shape — three bytes of header and one byte per parameter — so nothing in the
 *   record moved and no offset is rewritten by the bump. What moved is the MEANING
 *   of one of those bytes: the reverb lost a mode, HOLD, so the position of every
 *   mode after it came down by one, and a record written before that names a mode
 *   on a list this image no longer has. Read as it stands, a stored HOLD — index 3
 *   of five — would come back as the cathedral, index 2 of four, and the player
 *   would be handed a different algorithm than the one recorded in the preset, with
 *   no sign that anything happened.
 *
 *   So a version-1 record is walked: its mode byte is read through the OLD
 *   five-entry list and written back through the new four-entry one, which keeps
 *   ROOM, HALL and CATHEDRAL where they were, moves PLATE down to 3, and gives the
 *   stored HOLD the hall, the mode the device comes up in. See migrate_mode_byte()
 *   and migrate_store_modes(). The version byte in the record is what makes that
 *   safe to do at any time: the walk knows from the record itself which list its
 *   mode was written against, so a slot the boot-time pass did not reach — a power
 *   cut in the middle of it, a stamp that could not be written — still loads as the
 *   mode the player chose.
 */
#include "app_settings.h"

#include <stdio.h>
#include <string.h>

#include "esp_log.h"
#include "esp_random.h"
#include "nvs.h"

static const char *TAG = "presets";

#define PRESET_NAMESPACE    "preset"
#define PRESET_COUNT_KEY    "count"
#define PRESET_NAMES_KEY    "names"
/* The format of the whole store, one byte for all of it. See check_store_format(). */
#define PRESET_FORMAT_KEY   "fmt"

/* The record layout: three bytes of header and one byte per parameter, and
 * nothing else. The number also stands for WHAT THE BYTES MEAN, which is why it
 * moved to 2 and then to 3 while the shape stayed put — nothing in the record has
 * moved, and what moved each time is the meaning of one byte. A record carrying
 * any other version is refused rather than misread as parameters, and its slot
 * stays in the flash for the image that can read it. */
#define PRESET_VERSION      3
/* Version 2 is the reverb-era record: the mode byte is already on the short list, but its
 * SCALE byte names a position in the scale list BEFORE it was sorted by consonance. Readable
 * here, and the scale is walked on the way in. */
#define PRESET_VERSION_OLD  2
/* And version 1 is the oldest: the reverb still had HOLD, and the scale is on the old order.
 * Both bytes move. */
#define PRESET_VERSION_OLDEST 1

/*
 * The record: three bytes of header and one byte per parameter, and only as many
 * parameter bytes as were actually saved. 134 for the control surface's 131.
 *
 * There is deliberately no count field. NVS stores the length of a blob and
 * returns it on the way out, so a count byte would be a second copy of a number
 * that is already known — and the kind of second copy that disagrees after a
 * format change.
 */
#define PRESET_HEADER 3                     /* version, adjective, noun */

typedef struct {
    uint8_t version;
    uint8_t adj;                            /* name: adjective index */
    uint8_t noun;                           /* name: noun index */
    uint8_t param[APP_PRESET_PARAM_MAX];    /* the blob ends after the real ones */
} preset_blob_t;

/*
 * The two word lists: twenty-four each, so 576 names for 128 slots. Every word
 * is short enough to draw on a 360 px screen in the list's face, and they are
 * chosen to belong to the instrument rather than to a synthesiser catalogue.
 */
static const char *const ADJECTIVES[] = {
    "AMBER", "ASH", "BLEAK", "BURNT", "COLD", "DEEP", "DIM", "DUSK",
    "DUST", "GLASS", "GREY", "HOLLOW", "IRON", "LOW", "MOSS", "PALE",
    "RUST", "SALT", "SLOW", "SOFT", "STILL", "THIN", "VAST", "WIRE",
};

static const char *const NOUNS[] = {
    "BELL", "BIRD", "BLOOM", "CLOUD", "COAST", "CROW", "DRIFT", "DUNE",
    "EMBER", "FERN", "FIELD", "FOG", "GLADE", "HILL", "LAKE", "MOON",
    "PIER", "RAIN", "REED", "RIDGE", "SHORE", "SNOW", "STONE", "TIDE",
};

#define ADJ_COUNT   ((int)(sizeof(ADJECTIVES) / sizeof(ADJECTIVES[0])))
#define NOUN_COUNT  ((int)(sizeof(NOUNS) / sizeof(NOUNS[0])))

static nvs_handle_t s_nvs;
static bool         s_ready;

/* The name indices, cached so the list opens without touching the flash. */
static int          s_count;
static uint8_t      s_adj[APP_PRESET_MAX];
static uint8_t      s_noun[APP_PRESET_MAX];

/* -------------------------------------------------------------------------- */
/* Names                                                                      */
/* -------------------------------------------------------------------------- */

/* Single case on purpose: the interface's font is a small bitmap face and two
 * cases would be a second font for no information. */
static void name_of(int adj, int noun, char *out, size_t len)
{
    if (len == 0) {
        return;
    }
    if (adj < 0 || adj >= ADJ_COUNT || noun < 0 || noun >= NOUN_COUNT) {
        out[0] = '\0';
        return;
    }
    /*
     * Copied by hand rather than formatted. Both words are short and the caller's
     * buffer is APP_PRESET_NAME_MAX, but a compiler cannot know either of those
     * things about a pair of string pointers, and this project treats
     * format-truncation as an error: an snprintf here would be a permanent
     * warning that is always unjustified and could never be silenced by being
     * right.
     */
    const char *const a = ADJECTIVES[adj];
    const char *const n = NOUNS[noun];
    const size_t alen = strlen(a);
    const size_t nlen = strlen(n);
    if (alen + 1u + nlen >= len) {
        out[0] = '\0';              /* the caller's buffer cannot hold the name */
        return;
    }
    memcpy(out, a, alen);
    out[alen] = ' ';
    memcpy(out + alen + 1u, n, nlen);
    out[alen + 1u + nlen] = '\0';
}

static bool name_in_use(int adj, int noun)
{
    for (int i = 0; i < s_count; i++) {
        if (s_adj[i] == (uint8_t)adj && s_noun[i] == (uint8_t)noun) {
            return true;
        }
    }
    return false;
}

static void add_name(int adj, int noun)
{
    if (s_count >= APP_PRESET_MAX) {
        return;
    }
    s_adj[s_count]  = (uint8_t)adj;
    s_noun[s_count] = (uint8_t)noun;
    s_count++;
}

/*
 * A name nobody is using.
 *
 * Drawn rather than counted, so two presets saved a minute apart do not read as
 * neighbours in a sequence. With 576 names for 128 slots the first draw almost
 * always lands, and the retry loop is bounded so that a nearly full table cannot
 * spin; the scan after it guarantees a unique name even then.
 */
static void draw_name(int *adj, int *noun)
{
    for (int attempt = 0; attempt < 64; attempt++) {
        const int a = (int)(esp_random() % (uint32_t)ADJ_COUNT);
        const int n = (int)(esp_random() % (uint32_t)NOUN_COUNT);
        if (!name_in_use(a, n)) {
            *adj = a;
            *noun = n;
            return;
        }
    }

    for (int a = 0; a < ADJ_COUNT; a++) {
        for (int n = 0; n < NOUN_COUNT; n++) {
            if (!name_in_use(a, n)) {
                *adj = a;
                *noun = n;
                return;
            }
        }
    }

    *adj = 0;
    *noun = 0;
}

/* -------------------------------------------------------------------------- */
/* Storage                                                                    */
/* -------------------------------------------------------------------------- */

/* 16 is the largest key NVS accepts, which is the only bound that cannot be
 * exceeded here: the compiler cannot see that slot is already inside
 * APP_PRESET_MAX, so the buffer has to be able to hold the worst case. */
static void key_for(int slot, char *out, size_t len)
{
    snprintf(out, len, "p%d", slot);
}

/* -------------------------------------------------------------------------- */
/* The mode byte that moved                                                   */
/* -------------------------------------------------------------------------- */
/*
 * The reverb's mode list, as it is stored: five entries in a version-1 record and
 * four in a version-2 one, and the walk between them.
 *
 * The position is written out here rather than included: this component cannot see
 * synth_app.h — synth_app requires app_settings, so the include would be a cycle —
 * and the number is checked against the enum by a static_assert in synth_app.cpp,
 * next to the list it belongs to. The same walk lives in app_settings.c for the
 * remembered sound, and the two copies cannot disagree: both are the map below, and
 * a disagreement would be one line of arithmetic, not a number that drifts.
 *
 * The map is the whole decision. HOLD sat fourth of five; it is gone, so the hole
 * itself has nowhere to point and goes to the hall — the mode the device comes up
 * in and the nearest thing to HOLD that still exists — while PLATE, which stood
 * after it, comes down from 4 to 3. ROOM, HALL and CATHEDRAL never moved.
 */
#define MIG_MODE_PARAM   43     /* SYNTH_PARAM_VERB_MODE */
#define MIG_SCALE_PARAM  10     /* SYNTH_PARAM_SCALE */
#define MIG_MODE_OLD      5
#define MIG_MODE_NEW      4
static const uint8_t MIG_MODE_MAP[MIG_MODE_OLD] = { 0, 1, 2, 1, 3 };

/*
 * One record's mode byte, read through the old list and written back through the new
 * one. A byte is a position and not a number: round(v * (count - 1)) on the way in,
 * the new position over the new length on the way out, which is the same conversion
 * the knob and the readout use on the value this byte becomes.
 *
 * There is no clamp on the way in: a stored byte is 0..255, so the value it becomes is
 * already 0..1 and the position it names is already inside both lists. Applied to a byte
 * that has been moved once the walk would NOT be the identity — CATHEDRAL is 2 of 4 now,
 * and 0.6667 read through five entries is HOLD — which is why the record's own version
 * byte, and not this function, decides whether it runs.
 */
/*
 * Лады отсортированы по благозвучности, и позиция лада — это сохранённый байт. Карта ниже
 * та же, что MIG_SCALE_ORDER в app_settings.c (старая позиция -> новая), и повторена здесь
 * по той же причине, по какой повторён режим реверба: два компонента, один порядок, и
 * включать app_settings в app_presets незачем. Сторож — static_assert о двадцати одном в
 * synth_app.cpp, рядом с самой таблицей.
 *
 * Список при этом вырос с шестнадцати до двадцати одного — пять восточных ладов встали в
 * середину, — поэтому карта ведёт позиции старой шкалы в новую, более длинную. Считается так
 * же, как режим: байт — это позиция, поэтому round(v * 15) на входе, новая позиция через
 * двадцать на выходе.
 */
#define MIG_SCALE_OLD     16
#define MIG_SCALE_NEW     21
static const uint8_t MIG_SCALE_ORDER[MIG_SCALE_OLD] =
    { 0, 1, 10, 8, 7, 9, 3, 2, 6, 12, 13, 11, 4, 18, 19, 20 };

static uint8_t migrate_scale_byte(uint8_t stored)
{
    const float v = (float)stored / 255.0f;
    int old = (int)(v * (float)(MIG_SCALE_OLD - 1) + 0.5f);
    if (old < 0) {
        old = 0;
    } else if (old > MIG_SCALE_OLD - 1) {
        old = MIG_SCALE_OLD - 1;
    }

    const float moved = (float)MIG_SCALE_ORDER[old] / (float)(MIG_SCALE_NEW - 1);
    return (uint8_t)(moved * 255.0f + 0.5f);
}

static uint8_t migrate_mode_byte(uint8_t stored)
{
    const float v = (float)stored / 255.0f;
    int old = (int)(v * (float)(MIG_MODE_OLD - 1) + 0.5f);
    if (old < 0) {
        old = 0;
    } else if (old > MIG_MODE_OLD - 1) {
        old = MIG_MODE_OLD - 1;
    }

    const float moved = (float)MIG_MODE_MAP[old] / (float)(MIG_MODE_NEW - 1);
    return (uint8_t)(moved * 255.0f + 0.5f);
}

/*
 * The whole store, walked once: every version-1 record this image can read has its mode
 * byte moved to the shorter list and is stamped with the new version.
 *
 * The records are written before the store's own stamp and one at a time, and a failure
 * on any of them leaves that record on version 1 with its old meaning intact — which is
 * exactly what the load path can still read. Nothing is deleted and nothing is refused
 * for being old: a slot that is damaged, or one whose layout is shorter than the mode
 * byte, is left alone and is refused by name if it is ever loaded, the same treatment it
 * gets today.
 *
 * Returns how many records were rewritten, which is what the boot line reports.
 */
static int migrate_store_modes(int count)
{
    int migrated = 0;

    for (int i = 0; i < count; i++) {
        char key[16];
        key_for(i, key, sizeof(key));

        preset_blob_t blob;
        size_t len = sizeof(blob);
        if (nvs_get_blob(s_nvs, key, &blob, &len) != ESP_OK) {
            continue;
        }
        if (len < PRESET_HEADER + (size_t)MIG_SCALE_PARAM + 1u) {
            continue;               /* no scale byte in a record this short */
        }
        if (blob.version != PRESET_VERSION_OLD && blob.version != PRESET_VERSION_OLDEST) {
            continue;               /* already this list, or not this slot's business */
        }

        /* The scale moves for both old formats; the reverb's mode only for the oldest. */
        blob.param[MIG_SCALE_PARAM] = migrate_scale_byte(blob.param[MIG_SCALE_PARAM]);
        if (blob.version == PRESET_VERSION_OLDEST
            && len >= PRESET_HEADER + (size_t)MIG_MODE_PARAM + 1u) {
            blob.param[MIG_MODE_PARAM] = migrate_mode_byte(blob.param[MIG_MODE_PARAM]);
        }
        blob.version = PRESET_VERSION;

        if (nvs_set_blob(s_nvs, key, &blob, len) != ESP_OK) {
            ESP_LOGW(TAG, "could not move preset %d's reverb mode", i);
            continue;
        }
        migrated++;
    }

    return migrated;
}

static void write_names(void)
{
    uint8_t pair[APP_PRESET_MAX * 2];
    for (int i = 0; i < s_count; i++) {
        pair[i * 2]     = s_adj[i];
        pair[i * 2 + 1] = s_noun[i];
    }
    const esp_err_t err =
        nvs_set_blob(s_nvs, PRESET_NAMES_KEY, pair, (size_t)s_count * 2u);
    if (err != ESP_OK) {
        ESP_LOGW(TAG, "could not store the name table: %s", esp_err_to_name(err));
    }
}

/*
 * WHAT THE STORE SAYS ABOUT ITSELF, AND WHAT THIS IMAGE DOES WITH IT.
 *
 * The store used to be stamped with the identity of the image that wrote it, and
 * a reflash cleared it — which meant that every reflash of the instrument threw
 * away every sound that had been kept. That was a development convenience and it
 * is gone; a preset is saved work, not the build's.
 *
 * What replaced it is the format version, and the difference matters: the build
 * stamp asked "did this image write it?", to which the honest answer for a
 * reflash is usually no, while the version asks "can this image read it?", to
 * which the answer for a reflash is yes.
 *
 * Four outcomes, and the log line in app_presets_init() names them:
 *
 *   a matching stamp  — the slots are read as they are.
 *   the old version   — version 1: the layout every record in it carries, read
 *                       through the reverb's longer mode list. The slots are this
 *                       image's to read, and each record is moved to the new
 *                       version — its mode byte walked to the shorter list — and
 *                       then the store is stamped. What was rewritten is what the
 *                       line reports as migrated.
 *   no stamp at all   — a store from before the stamp existed. Every record in
 *                       it is layout version 1, so this is the same case: the
 *                       records are walked and the stamp is written. A record
 *                       whose mode never named the removed entry still means the
 *                       algorithm it meant — the byte moves, the mode does not —
 *                       and a store that reads today reads after it too. An
 *                       empty store is stamped as well, so that it can never
 *                       later be mistaken for one from before the stamp.
 *   another version   — not this image's to read. Nothing is listed, nothing is
 *                       read and nothing is written, and the slots stay in the
 *                       flash for the image that speaks that version. The
 *                       refused store is left alone precisely so that a
 *                       downgrade — or an upgrade — does not take away the
 *                       sounds the other image can still play.
 *
 * The settings namespace is not involved in any of this and never was: screen
 * brightness, the ring mode and the Wi-Fi provisioning data live through a
 * reflash.
 *
 * A store written by the last image that used the old stamp still carries an
 * `fw` entry holding that image's ELF hash. It is left exactly where it is and
 * never read again: erasing it would be a flash write at boot for one entry of
 * bookkeeping that costs nothing.
 */

/*
 * The store as the boot log reports it.
 */
typedef struct {
    uint8_t stamp;          /* the version the store carries; 0 when it carried none */
    int     accepted;       /* slots this image can read */
    int     rejected;       /* slots it cannot, left where they are */
    int     migrated;       /* slots whose mode byte was walked to the new list */
    bool    usable;         /* false when the store belongs to another format */
    bool    walk;           /* the stamp is the old one (or absent): records need moving */
} preset_store_t;

/*
 * Whether the store can be read, and whether the records in it still name the reverb's
 * modes on the longer list. Nothing is written here: the walk and the stamp belong
 * together and both happen in app_presets_init(), the stamp last, so that a power cut
 * between them cannot leave a store claiming a version its records do not speak — see
 * migrate_store_modes().
 */
static preset_store_t check_store_format(int count)
{
    preset_store_t st = { 0, 0, 0, 0, true, false };

    uint8_t stamp = 0;
    const esp_err_t err = nvs_get_u8(s_nvs, PRESET_FORMAT_KEY, &stamp);
    if (err == ESP_OK) {
        st.stamp = stamp;
        if (stamp == PRESET_VERSION) {
            st.accepted = count;
            return st;
        }
        if (stamp == PRESET_VERSION_OLD || stamp == PRESET_VERSION_OLDEST) {
            /* Readable: version 2 records name their scale on the older order, version 1
             * records name both their scale and their reverb mode on lists this image no
             * longer has. The walk is what makes either readable as itself. */
            st.accepted = count;
            st.walk = true;
            return st;
        }
        st.rejected = count;
        st.usable = false;
        return st;
    }

    if (err != ESP_ERR_NVS_NOT_FOUND) {
        /* Not "absent" but unreadable: said out loud, then treated as absent,
         * because an unstamped store is version 1 by construction and reading it
         * as anything else would refuse sounds that are perfectly good. */
        ESP_LOGW(TAG, "could not read the store format: %s", esp_err_to_name(err));
    }

    /* No stamp at all: a store from before the stamp existed, so every record in it is
     * layout version 1 — which is PRESET_VERSION_OLD — and the same walk applies. The
     * stamp is written by the caller once the records speak the version it claims. */
    st.stamp = PRESET_VERSION_OLD;
    st.accepted = count;
    st.walk = true;
    return st;
}

void app_presets_init(void)
{
    if (nvs_open(PRESET_NAMESPACE, NVS_READWRITE, &s_nvs) != ESP_OK) {
        ESP_LOGW(TAG, "nvs_open(%s) failed — presets unavailable", PRESET_NAMESPACE);
        return;
    }
    s_ready = true;

    /*
     * Said out loud once at boot, because "there is room for 128 presets" is
     * otherwise an arithmetic claim about a partition that can simply be
     * measured. The figure that matters is entries, not payload: NVS spends a
     * 32-byte entry header on every blob, so a 67-byte preset costs four of
     * them, and the partition has to hold the settings and its own bookkeeping
     * as well.
     */
    nvs_stats_t stats;
    if (nvs_get_stats(NULL, &stats) == ESP_OK) {
        ESP_LOGI(TAG, "nvs: %u of %u entries used, %u free",
                 (unsigned)stats.used_entries, (unsigned)stats.total_entries,
                 (unsigned)stats.free_entries);
    }

    /* Read before the format check: how many slots there are is half of what the
     * check reports, and all of what a migration claims. */
    uint8_t count = 0;
    if (nvs_get_u8(s_nvs, PRESET_COUNT_KEY, &count) != ESP_OK) {
        count = 0;                  /* nothing has ever been saved */
    }
    if (count > APP_PRESET_MAX) {
        ESP_LOGW(TAG, "stored count %u is out of range — trimming", (unsigned)count);
        count = APP_PRESET_MAX;
    }

    preset_store_t store = check_store_format((int)count);

    /*
     * THE WALK, BEFORE ANYTHING CAN READ A SLOT.
     *
     * A store stamped with the old version, or with no stamp at all, names its reverb
     * mode on the five-entry list this image no longer has, so the records are moved to
     * the current version here and only then is the store stamped with it. That order is
     * the point: a stamp written first would claim records a power cut had left behind,
     * and a stored HOLD would then be read as the cathedral — the one outcome this
     * migration exists to prevent.
     *
     * An empty store is stamped as well, so that it can never later be mistaken for one
     * from before the stamp existed. A stamp that could not be written costs a boot's
     * worth of the same work next time and not a preset: the records have already moved,
     * and the walk skips a record that is on the new version already.
     */
    if (store.usable && store.walk) {
        store.migrated = (count > 0) ? migrate_store_modes((int)count) : 0;

        if (nvs_set_u8(s_nvs, PRESET_FORMAT_KEY, (uint8_t)PRESET_VERSION) != ESP_OK
            || nvs_commit(s_nvs) != ESP_OK) {
            ESP_LOGW(TAG, "could not stamp the store as format v%d", PRESET_VERSION);
        } else {
            store.stamp = PRESET_VERSION;
        }
    }

    /*
     * ONE line, at every boot, and it is the line that is read off the
     * instrument rather than out of a debugger: the format this image speaks and
     * what became of the slots it found. "migrated" can only be non-zero once in
     * the life of a store, and this firmware has two first boots it can happen on:
     * the one after the image that carried no stamp, and the one after the image
     * whose reverb still had a mode this one does not.
     *
     * The determination is the store's rather than each slot's, because the stamp is
     * what decides whether the records can be read at all. The walk above is the
     * one time the records themselves are read at boot, and it reads them because
     * the stamp said their mode byte still has to move; doing it at every boot to
     * confirm a stamp that already answered would put 128 flash reads on the boot
     * path for nothing. A single record that still disagrees with its store — which
     * takes a power cut in the middle of the walk — is walked again when it is
     * loaded, by its own version byte, and warned about by name if the two
     * disagree about the layout.
     */
    ESP_LOGI(TAG, "preset format v%d: %d accepted, %d rejected, %d migrated",
             PRESET_VERSION, store.accepted, store.rejected, store.migrated);

    if (!store.usable) {
        /*
         * Another format, so this image stands off it entirely: listing the slots
         * would offer sounds that cannot load, and a save would start at slot 0
         * and take the name table with it. Left in the flash, and left alone.
         */
        ESP_LOGW(TAG, "store is format v%u, not v%d — presets unavailable, slots untouched",
                 (unsigned)store.stamp, PRESET_VERSION);
        s_ready = false;
        return;
    }

    if (count == 0) {
        return;                     /* nothing has ever been saved */
    }

    uint8_t pair[APP_PRESET_MAX * 2];
    size_t len = sizeof(pair);
    const bool have_names = (nvs_get_blob(s_nvs, PRESET_NAMES_KEY, pair, &len) == ESP_OK)
                            && (len >= (size_t)count * 2u);

    for (int i = 0; i < count; i++) {
        if (have_names) {
            /* add_name() rather than a direct store, so the uniqueness scan sees
             * the names already placed. */
            add_name(pair[i * 2], pair[i * 2 + 1]);
        } else {
            int a = 0;
            int n = 0;
            draw_name(&a, &n);
            add_name(a, n);
        }
    }

    if (!have_names) {
        /* The slots are real and the names are not: give them names rather than
         * showing a list of blanks, and make that permanent so the list does not
         * change its mind on the next boot. */
        write_names();
        nvs_set_u8(s_nvs, PRESET_COUNT_KEY, (uint8_t)s_count);
        nvs_commit(s_nvs);
    }

    ESP_LOGI(TAG, "%d preset(s) remembered", s_count);
}

/* -------------------------------------------------------------------------- */
/* Public API                                                                 */
/* -------------------------------------------------------------------------- */

int app_settings_preset_count(void)
{
    return s_ready ? s_count : 0;
}

bool app_settings_preset_name(int slot, char *out, size_t len)
{
    if (slot < 0 || slot >= app_settings_preset_count()) {
        return false;
    }
    name_of(s_adj[slot], s_noun[slot], out, len);
    return true;
}

int app_settings_preset_save(int slot, const float *values, int count)
{
    if (!s_ready || !values || count <= 0) {
        return -1;
    }
    if (count > APP_PRESET_PARAM_MAX) {
        count = APP_PRESET_PARAM_MAX;
    }

    /*
     * A slot that does not exist yet is an append. That is what the first save
     * on an empty device is, and what a caller that has run past the end of the
     * list gets, so there is no separate "create" call to forget to use.
     */
    const bool append = (slot < 0) || (slot >= s_count);
    if (append) {
        if (s_count >= APP_PRESET_MAX) {
            ESP_LOGW(TAG, "no room for another preset");
            return -1;
        }
        slot = s_count;
    }

    preset_blob_t blob;
    memset(&blob, 0, sizeof(blob));
    blob.version = PRESET_VERSION;
    for (int i = 0; i < count; i++) {
        float v = values[i];
        if (v < 0.0f) {
            v = 0.0f;
        } else if (v > 1.0f) {
            v = 1.0f;
        }
        blob.param[i] = (uint8_t)(v * 255.0f + 0.5f);
    }

    /*
     * A new name on every save, an overwrite included. The name describes what
     * is in the slot rather than marking the slot itself, so a row in the list
     * can never say one thing while holding another — which is exactly what an
     * overwrite that kept the old name would do.
     *
     * Drawn before the cached name is changed, so the name being replaced is
     * still in the table and cannot be handed straight back as the new one.
     */
    int a = 0;
    int n = 0;
    draw_name(&a, &n);
    blob.adj  = (uint8_t)a;
    blob.noun = (uint8_t)n;

    char key[16];
    key_for(slot, key, sizeof(key));
    const size_t bytes = (size_t)PRESET_HEADER + (size_t)count;
    const esp_err_t err = nvs_set_blob(s_nvs, key, &blob, bytes);
    if (err != ESP_OK) {
        ESP_LOGW(TAG, "could not store %s: %s", key, esp_err_to_name(err));
        return -1;
    }

    if (append) {
        add_name(blob.adj, blob.noun);
        nvs_set_u8(s_nvs, PRESET_COUNT_KEY, (uint8_t)s_count);
    } else {
        s_adj[slot]  = blob.adj;
        s_noun[slot] = blob.noun;
    }
    write_names();

    if (nvs_commit(s_nvs) != ESP_OK) {
        ESP_LOGW(TAG, "nvs_commit failed — preset %d may not survive a power cut", slot);
        return -1;
    }

    ESP_LOGI(TAG, "preset %d %s (%d values)", slot, append ? "created" : "updated", count);
    return slot;
}

/*
 * УДАЛЕНИЕ СЛОТА: закрыть дыру, сдвинув хвост вниз.
 *
 * Магазин плотный, и это обещание виднее снаружи, чем кажется: номер слота — его
 * индекс, и имя слота читается без таблицы занятости. Дырка в середине потребовала бы
 * битмапа, которого здесь сознательно нет (см. preset_refresh() в synth_ui.c), поэтому
 * удаление не помечает запись пустой, а переносит все записи после неё на одну вниз и
 * стирает последнюю.
 *
 * Сдвиг идёт от удаляемого слота к концу, то есть каждая запись читается раньше, чем
 * её место будет перезаписано, и читается с проверкой: запись, которую не удалось
 * прочитать, останавливает сдвиг — лучше магазин с хвостом, чем магазин, в котором
 * запись потерялась молча.
 *
 * Имена едут вместе со звуками и не перерисовываются: имя описывает звук, а не место.
 * Имя удалённого звука уходит из кэша вместе со сдвигом, и name_in_use() больше его не
 * видит, так что следующий SAVE может его получить.
 */
int app_settings_preset_delete(int slot)
{
    if (!s_ready || slot < 0 || slot >= s_count) {
        return -1;
    }

    for (int i = slot; i + 1 < s_count; i++) {
        char from[16];
        char to[16];
        key_for(i + 1, from, sizeof(from));
        key_for(i, to, sizeof(to));

        preset_blob_t blob;
        size_t len = sizeof(blob);
        const esp_err_t err = nvs_get_blob(s_nvs, from, &blob, &len);
        if (err != ESP_OK) {
            ESP_LOGW(TAG, "could not read %s to close the gap at %s: %s",
                     from, to, esp_err_to_name(err));
            return -1;
        }
        if (nvs_set_blob(s_nvs, to, &blob, len) != ESP_OK) {
            ESP_LOGW(TAG, "could not move %s into %s", from, to);
            return -1;
        }
        nvs_erase_key(s_nvs, from);

        s_adj[i]  = s_adj[i + 1];
        s_noun[i] = s_noun[i + 1];
    }

    char last[16];
    key_for(s_count - 1, last, sizeof(last));
    nvs_erase_key(s_nvs, last);

    s_count--;
    nvs_set_u8(s_nvs, PRESET_COUNT_KEY, (uint8_t)s_count);
    if (s_count > 0) {
        write_names();
    } else {
        /* An empty store has no name table: a zero-length blob is a record too, and the
         * walk at boot would have to know that it is the same as nothing. */
        nvs_erase_key(s_nvs, PRESET_NAMES_KEY);
    }

    if (nvs_commit(s_nvs) != ESP_OK) {
        ESP_LOGW(TAG, "nvs_commit failed — the delete of preset %d may not survive a power cut",
                 slot);
        return -1;
    }

    ESP_LOGI(TAG, "preset %d deleted, %d left", slot, s_count);
    return s_count;
}

int app_settings_preset_load(int slot, float *out, int count)
{
    if (!s_ready || !out || count <= 0 || slot < 0 || slot >= s_count) {
        return 0;
    }

    char key[16];
    key_for(slot, key, sizeof(key));

    preset_blob_t blob;
    size_t len = sizeof(blob);
    const esp_err_t err = nvs_get_blob(s_nvs, key, &blob, &len);
    if (err == ESP_ERR_NVS_INVALID_LENGTH) {
        /* Longer than this image's record. NVS hands back the size it found, so
         * the log can say what it was, and the slot is left for whatever wrote
         * it. */
        ESP_LOGW(TAG, "preset %d is %u bytes, longer than a format v%d record — not read",
                 slot, (unsigned)len, PRESET_VERSION);
        return 0;
    }
    if (err != ESP_OK) {
        return 0;
    }
    /* The length is the count: three bytes of header, then one per parameter. */
    if (len < PRESET_HEADER || (len - PRESET_HEADER) > APP_PRESET_PARAM_MAX) {
        ESP_LOGW(TAG, "preset %d is %u bytes, which is no format v%d record — not read",
                 slot, (unsigned)len, PRESET_VERSION);
        return 0;
    }
    /*
     * A record from another format is refused here as well as at boot, because
     * the stamp and the record are two entries and a store can be half written
     * by a power cut. The slot keeps what it holds; the next save over it
     * replaces the record and the name together.
     *
     * ONE old version is not refused, and that is the whole of the migration from
     * the record's side: a version-1 record names its reverb mode on the longer
     * list, so it is read here and its mode byte walked to the shorter one — see
     * migrate_mode_byte(). It is done here as well as in migrate_store_modes()
     * because a slot the boot-time walk did not reach must still load as the mode
     * the player chose, and reading is exactly where the old byte would otherwise
     * turn into a different algorithm.
     */
    if (blob.version != PRESET_VERSION
        && blob.version != PRESET_VERSION_OLD
        && blob.version != PRESET_VERSION_OLDEST) {
        ESP_LOGW(TAG, "preset %d is format v%u, not v%d — not read, slot left as it is",
                 slot, (unsigned)blob.version, PRESET_VERSION);
        return 0;
    }

    const bool old_list = (blob.version == PRESET_VERSION_OLDEST);
    const bool old_scale = (blob.version != PRESET_VERSION);

    int n = (int)(len - PRESET_HEADER);
    if (n > count) {
        n = count;
    }
    for (int i = 0; i < n; i++) {
        uint8_t byte = blob.param[i];
        if (old_list && i == MIG_MODE_PARAM) {
            byte = migrate_mode_byte(byte);
        }
        if (old_scale && i == MIG_SCALE_PARAM) {
            byte = migrate_scale_byte(byte);
        }
        out[i] = (float)byte / 255.0f;
    }
    /* Logged because a load is a deliberate act and a rare one, and because it
     * is the only evidence that the stored bytes came back out again. */
    ESP_LOGI(TAG, "preset %d read (%d values)", slot, n);
    return n;
}
