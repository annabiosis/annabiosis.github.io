/*
 * КАРТА РАЗДЕЛОВ КОЛЬЦАМИ.
 *
 * Три кольца секторов вокруг круглой кнопки в середине. Углы в 1/1024 оборота от
 * верхней точки по часовой стрелке, радиусы в пикселях от центра экрана 360x360.
 *
 * Таблица выписана владельцем: пять секторов в узком кольце, семь в среднем и десять
 * во внешнем, плюс MASTER в середине. Порядок страниц — его.
 */

#define NAV_RINGS_HUB_R      40
#define NAV_RINGS_TURN       1024
#define NAV_RINGS_BANDS      2

/* Границы колец: R[i]..R[i+1] — i-е кольцо. */
static const uint8_t NAV_RING_R[NAV_RINGS_BANDS + 1] = { 40, 109, 178 };

typedef struct {
    uint8_t  ring;      /* 0 — внутреннее, 1 — среднее, 2 — внешнее */
    uint8_t  page;      /* код страницы из synth_app.h */
    uint16_t a0;        /* начало сектора, 1/1024 оборота от верхней точки */
    uint16_t span;      /* длина сектора в тех же единицах */
} nav_ring_sector_t;

static const nav_ring_sector_t NAV_RING_SECTORS[] = {
    /* кольцо, страница, начало, длина */
    { 0, PAGE_DRONE,  963, 128 },
    { 0, PAGE_FILTER,   67, 128 },
    { 0, PAGE_MIX,  195, 128 },
    { 0, PAGE_BASS,  323, 128 },
    { 0, PAGE_RHYTHM,  451, 128 },
    { 0, PAGE_ENV,  579, 128 },
    { 0, PAGE_TONE,  707, 128 },
    { 0, PAGE_LEAD,  835, 128 },
    { 1, PAGE_PERC_MIX,   37,  73 },
    { 1, PAGE_PERC_SEQ,  110,  73 },
    { 1, PAGE_SEND_REV,  183,  73 },
    { 1, PAGE_SEND_DLY,  256,  73 },
    { 1, PAGE_SEND_CHR,  329,  73 },
    { 1, PAGE_MOD2,  402,  73 },
    { 1, PAGE_MOD,  475,  74 },
    { 1, PAGE_ARP,  549,  73 },
    { 1, PAGE_EUCLID,  622,  73 },
    { 1, PAGE_SCALE,  695,  73 },
    { 1, PAGE_CHORUS,  768,  73 },
    { 1, PAGE_DELAY,  841,  73 },
    { 1, PAGE_VERB,  914,  73 },
    { 1, PAGE_PERC,  987,  74 },
};

#define NAV_RING_SECTOR_COUNT ((int)(sizeof(NAV_RING_SECTORS) / sizeof(NAV_RING_SECTORS[0])))

/* Кнопка в середине: одна страница, круг радиуса NAV_RINGS_HUB_R. */
#define NAV_RING_HUB_PAGE    PAGE_MASTER
