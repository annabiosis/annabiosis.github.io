/*
 * synth_app — the instrument itself.
 *
 * Brings the engine up in pull mode, assigns voices to layers, installs the bus
 * FX, and starts the audio task that owns the I2S output.
 */
#pragma once

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* -------------------------------------------------------------------------- */
/* Control surface: the parameter set                                         */
/* -------------------------------------------------------------------------- */
/*
 * Declared before the stats struct that carries their values, so the array in
 * there cannot fall out of step with this list.
 *
 * WHY THERE ARE RATE PARAMETERS
 *   The drone filter's LFO and the stereo drift were both designed to be
 *   geological: at the factory setting the filter cycles in 14 to 25 seconds
 *   (40/50/70 mHz; LOW is the 0.050 Hz the display prints) and the drift in 27 to
 *   35 seconds (its first LFO per register, LOW/MID/HIGH 31/37/29 mHz — the one
 *   the readout prints; the second runs 47/53/61 mHz), so between them they cover
 *   cycles of 14 to 35 seconds. That is right for a drone held for minutes and
 *   hopeless for judging the instrument in a ten-second listen — a
 *   20-second cycle is not something the ear hears as movement, so the filter
 *   reads as "duller or brighter" and the drift as nothing at all.
 *   The RATE parameters put that legibility on demand, and both knobs end at a
 *   sixth of a second a cycle on LOW. The filter's LFO is 6.000 Hz there (MID
 *   8.400, HIGH 4.800 — one knob, three designed rates), and SPEED's own readout,
 *   the drift's first LFO, is 6.000 Hz too (MID 7.161, HIGH 5.613 — the same
 *   193.5484x factor over the designed 31 mHz instead of 50, one knob and three
 *   designed rates again; the drift's second LFO reaches 9.097/10.258/11.806 Hz).
 *   The same modulation then reads immediately as a filter sweep or a stereo sway;
 *   at the bottom it is the designed weather.
 */
typedef enum {
    SYNTH_PARAM_LEVEL = 0,      /* overall output; 0 is silence */
    SYNTH_PARAM_CUTOFF,         /* drone filter base cutoff, all three registers */
    SYNTH_PARAM_RESONANCE,      /* drone filter Q */
    SYNTH_PARAM_FILTER_RATE,    /* filter LFO speed: 0.040-8.400 Hz, LOW 0.050-6.000 Hz */
    SYNTH_PARAM_FILTER_DEPTH,   /* filter LFO depth: 2.40-4.00 oct, 6.00 with WIDTH at max */
    SYNTH_PARAM_MOTION_DEPTH,   /* pan drift depth */
    SYNTH_PARAM_MOTION_RATE,    /* pan drift speed: 0.029-7.161 Hz, LOW 0.031-6.000 Hz */

    /*
     * Phase 2: the lead voice and its sequencer.
     *
     * These are deliberately separate from the drone's LEVEL and CUTOFF. The
     * lead is a different instrument sharing one box: a melody that ducked the
     * drone every time it moved would make the two unusable together, which is
     * the opposite of what a lead is for.
     */
    SYNTH_PARAM_LEAD_LEVEL,     /* the lead layer's own level */
    SYNTH_PARAM_SEQ_TEMPO,      /* one step per beat */
    SYNTH_PARAM_SEQ_GATE,       /* how much of the step a note is held for */

    /*
     * The generation itself: what the line does rather than how loud or how
     * fast. These are the controls that make the difference between one
     * sequencer and another, so they are the ones worth having on the screen.
     */
    SYNTH_PARAM_SCALE,          /* the mode the notes are drawn from */
    SYNTH_PARAM_ROOT,           /* the tonic's NOTE, C..B; the octave is ROOT_OCT, at the end */
    SYNTH_PARAM_DENSITY,        /* how often a step sounds at all */
    SYNTH_PARAM_OCTAVE,         /* how freely the register moves */
    SYNTH_PARAM_LFO_SHAPE,      /* the drone filter's modulation waveform */

    /*
     * The rhythm. TEMPO and GATE above set the tempo and the note length; these
     * four shape where the notes fall.
     */
    SYNTH_PARAM_SEQ_STEPS,      /* how many grid steps to a bar */
    SYNTH_PARAM_SEQ_PULSES,     /* how many of them sound (the Euclidean k) */
    SYNTH_PARAM_SEQ_ROTATE,     /* where the pattern sits against the beat */
    SYNTH_PARAM_SEQ_SCATTER,    /* how far an onset wanders from its grid line */

    /* The drone's own mixer: one fader per register. */
    SYNTH_PARAM_DRONE_LOW,
    SYNTH_PARAM_DRONE_MID,
    SYNTH_PARAM_DRONE_HIGH,

    /*
     * THE SHAPE OF THE OSCILLATORS, one list per part.
     *
     * Six entries: sine, triangle, saw, square, a supersaw and noise. Four of them are
     * waveforms; the other two are not, and that is deliberate. A supersaw is the same saw
     * through several detuned oscillators, and this instrument has exactly three per
     * part — the drone's three voices are already detuned a few cents apart, so the
     * choice only widens that spread. Seven oscillators would be six more voices against
     * a fifteen percent idle CPU budget, which is not a trade this instrument can make.
     * Noise is neither a shape nor a pitch, but the filter and the envelope can place it,
     * which is what makes it worth a slot rather than a hiss over the top.
     *
     * The fourth entry is a SQUARE and is called one on the screen: its pulse width is
     * fixed at half the period, so the "PULSE" it was named after is not a control this
     * instrument has. The internal name PW_PLS is left alone — only the word the panel
     * prints changed.
     *
     * DRONE_WAVE IS THE DRONE'S ONE-SHAPE PAST, and it is deliberately still here. Each of
     * the three registers has a shape of its own now — SYNTH_PARAM_DRONE_OSC_LOW/MID/HIGH,
     * appended at the end of the patch — so this byte no longer reaches a voice. It stays in
     * the list at its old position for two reasons, and both are about records already in
     * the flash: the index must not move (everything after it is addressed by position), and
     * the old value is the answer a record written before the split has for the three new
     * parameters. synth_app_patch_apply() reads it for exactly that; the readout still
     * prints it, because a parameter the patch still stores must still be able to say what
     * it is. See the note over SYNTH_PARAM_DRONE_OSC_LOW.
     */
    SYNTH_PARAM_DRONE_WAVE,     /* the drone's old single shape: read by the migration only */
    SYNTH_PARAM_LEAD_WAVE,

    /*
     * The lead's own filter and the envelope that opens it.
     *
     * ENV is how far the envelope moves the cutoff, in octaves, and it is signed:
     * a negative amount closes the filter on each note instead of opening it.
     */
    SYNTH_PARAM_LEAD_CUTOFF,
    SYNTH_PARAM_LEAD_RESO,
    SYNTH_PARAM_LEAD_ENV,
    SYNTH_PARAM_LEAD_ATTACK,
    SYNTH_PARAM_LEAD_DECAY,
    SYNTH_PARAM_LEAD_SUSTAIN,
    SYNTH_PARAM_LEAD_RELEASE,

    /*
     * How long the lead takes to reach a new note, off at the bottom.
     *
     * It glides between the notes the generators actually play rather than between
     * arbitrary frequencies: the previous note is remembered, so a slide always
     * starts where the line was. The envelope is still retriggered — this moves the
     * pitch of a note that has just been articulated, which is what a player with a
     * slide control sounds like, and not a smear from one note into the next.
     */
    SYNTH_PARAM_LEAD_PORTA,

    /*
     * The arpeggiator: a second generator, and a different idea from the Euclidean
     * sequencer beside it. The sequencer decides WHEN notes fall and lets a Markov
     * walk decide which; the arp decides both, and what it plays is a staircase —
     * LEN notes to climb RANGE octaves from the tonic, in the direction asked for.
     *
     * LEN and RANGE are separate controls because they are separate questions:
     * RANGE is how far the figure reaches, LEN is how many notes it takes to get
     * there, and three notes across two octaves is not the same music as eight
     * notes across the same two.
     *
     * SPEED is a division of the beat and nothing else. An arpeggiator that could
     * be set out of time would be a novelty on an instrument whose whole timing
     * story is that a step is a whole number of blocks — and DIR=off is how the
     * arp is switched off, which hands the lead back to the Euclidean sequencer
     * rather than adding a second switch to keep in step with this one. SPEED has
     * no off position of its own: it is thirteen real divisions, the slowest first.
     */
    SYNTH_PARAM_ARP_DIR,        /* up / down / up-down / random */
    SYNTH_PARAM_ARP_SPEED,      /* 4-1 / 2-1 / 1-1 / 1-2. / 1-2 / 1-4. / 1-4 /
                                 * 1-8. / 1-8 / 1-16. / 1-8T / 1-16 / 1-32 */
    SYNTH_PARAM_ARP_LEN,        /* how many notes to climb the range in */
    SYNTH_PARAM_ARP_RANGE,      /* how many octaves that climb spans */

    /*
     * The effect chain: delay, chorus, reverb, in the order the rack runs them.
     *
     * All fifteen default to silence — every MIX starts at zero — so a device
     * that has never been touched sounds exactly as it did before the effects
     * existed. The values behind those zeroes are chosen so that the first thing a
     * raised MIX does is musical rather than a surprise.
     */
    SYNTH_PARAM_DELAY_SYNC,     /* free / 1-1 / 1-2. / 1-2 / 1-4. / 1-4 / 1-8. /
                                 * 1-8 / 1-16. / 1-8T / 1-16 / 1-32 */
    SYNTH_PARAM_DELAY_TIME,     /* used when sync is free */
    SYNTH_PARAM_DELAY_FEEDBACK,
    SYNTH_PARAM_DELAY_MIX,
    SYNTH_PARAM_CHORUS_RATE,
    SYNTH_PARAM_CHORUS_DEPTH,
    SYNTH_PARAM_CHORUS_MIX,
    SYNTH_PARAM_VERB_MODE,      /* room / hall / cathedral / plate */
    SYNTH_PARAM_VERB_SIZE,
    SYNTH_PARAM_VERB_DAMP,
    SYNTH_PARAM_VERB_MIX,
    SYNTH_PARAM_SEND_LOW,       /* how much of each layer goes to the reverb */
    SYNTH_PARAM_SEND_MID,
    SYNTH_PARAM_SEND_HIGH,
    SYNTH_PARAM_SEND_LEAD,

    /*
     * The percussion voice, and its own Euclidean figure.
     *
     * A noise source through a band-pass is the whole of it: the centre of the
     * filter is the note of the hit, resonance is how much it rings, and the gate is
     * how long it lasts. ENV is the one control that turns the result from a hiss
     * into a drum — it drops the filter over the hit, so the same noise burst reads
     * as a tom rather than as a hi-hat, and at zero the voice is a hat and nothing
     * else.
     *
     * The figure runs on the sequencer's clock rather than a second one: on an
     * instrument where a step is a whole number of audio blocks, two tempos are two
     * grids that never quite agree. It keeps its own STEPS and PULSES, so what it
     * plays is a polyrhythm against the lead rather than a copy of it.
     *
     * LEVEL also appears on LEVELS, and SEND_PERC only on SENDS, because a part's level
     * and its send are the two things a mixer sets together.
     */
    SYNTH_PARAM_PERC_PITCH,     /* the band-pass centre, in Hz */
    SYNTH_PARAM_PERC_RESO,      /* resonance: how much the filter rings */
    SYNTH_PARAM_PERC_DECAY,     /* the gate */
    SYNTH_PARAM_PERC_ENV,       /* how far the filter falls over the hit */
    SYNTH_PARAM_PERC_LEVEL,
    SYNTH_PARAM_PERC_STEPS,     /* the n of the Euclidean figure */
    SYNTH_PARAM_PERC_PULSES,    /* the k */
    SYNTH_PARAM_PERC_ROTATE,
    SYNTH_PARAM_SEND_PERC,      /* how much percussion goes to the reverb */

    /*
     * The master compressor, and deliberately at the end of the patch parameters.
     *
     * At the end because the parameter list is what a saved sound is, and a control
     * appended at the end leaves every index before it exactly where it was: a patch
     * remembered by an older firmware still restores from its shorter blob, with this
     * one at its default. Anywhere else in the block and every value after it would
     * come back attached to the wrong control.
     *
     * One knob for threshold and ratio together — see synth_rack_set_comp() for the
     * numbers and why they are those numbers. 0 is off, and off is bit-transparent.
     */
    SYNTH_PARAM_MASTER_COMP,

    /*
     * How hard the drum pushes the drone's low end out of its way, 0..1.
     *
     * One knob for depth and curve together, because they are one gesture: at the bottom it
     * leans on LOW and lets go slowly, at the top it drops LOW and half of MID and lets go
     * quickly. See synth_rack_set_duck() for the numbers.
     */
    SYNTH_PARAM_MASTER_DUCK,

    /*
     * The percussion's BODY: the balance between the noise a hit is made of and a
     * sine at the filter's centre. See synth_perc.cpp for the crossfade itself; what
     * matters here is only where it sits.
     *
     * Appended after MASTER_COMP and immediately before the microphone's send,
     * which leaves every parameter that was already part of the sound exactly where
     * it was. A patch or a preset saved by an older firmware is a prefix of this
     * list: BODY is simply not in it and arrives at its default, which is 0 — the
     * hit as it has always been, with nothing added to it.
     *
     * RES, above, is no longer on a page and stays in the list: the application hands
     * the engine the factory value whatever the stored patch says, because the peak
     * and the level were both calibrated at that value.
     */
    SYNTH_PARAM_PERC_BODY,

    /*
     * The microphone's send.
     *
     * It is here, after everything that was already the sound, for the reason BODY is:
     * a sound remembered by an older firmware is a prefix of this list, so a parameter
     * appended at the end arrives at its default — which for the microphone is silence —
     * while one inserted anywhere else renumbers every control after it.
     *
     * The microphone is not a layer of its own. It is summed into the AUX bus, whose
     * LAYER LEVEL IS ZERO, and the rack takes a layer's reverb send from the signal
     * captured BEFORE that level is applied; so this knob is the whole of the
     * microphone's path, it reaches the effects only, and it can never put the
     * microphone into the dry output however far it is turned. See synth_rack.cpp's
     * synth_rack_process(), the send loop in particular, and apply_reverb_send() in
     * synth_app.cpp.
     */
    SYNTH_PARAM_SEND_MIC,

    /*
     * WHICH FIGURE the accent plays, and the LAST patch parameter.
     *
     * A LIST of eight figures, OFF first. An accent is a VELOCITY here and nothing
     * else: the percussion engine has taken one since it was written, and the lead's
     * voices are handed one at note-on — both are scaled by it and by nothing else, so
     * a strong beat costs no second voice, no second envelope and no second code path.
     * What the list chooses is WHICH STEPS of the bar are struck strong — 1, 5, 9 and
     * 13 for QUARTER, which is a hit on every beat of the bar with the downbeat as the
     * first of them, 5 and 13 for 2&4, the backbeat, and six of them for a sixteenth
     * funk — and HOW HARD the rest are struck is not part of this parameter at all: it is
     * the WEAK VEL setting on OPTIONS, whole numbers 0..127, whose factory value of 80
     * leaves an unmarked step at 80/127 = 0.629921, about 4 dB down. Choosing a figure
     * and choosing how weak the weak half of it lands are two decisions, and they live on
     * two pages because one belongs to the patch and the other to the instrument.
     *
     * ONE FIGURE FOR BOTH PARTS, and one parameter for both pages. The accent has to be
     * visible and playable on the lead's sequencer page as well, and a second parameter
     * would be the same decision twice: an accent pattern is one decision about the
     * rhythm. So the same value is drawn on LEAD EUCLID and on PERC SEQ,
     * and it drives both figures — each one by the rule below, against its OWN STEPS,
     * because the two grids are independent. The name keeps its PERC_ because the
     * parameter's NUMBER is what a saved patch and a preset address, and renaming an
     * enumerator is churn that buys nothing: the label on both pages is ACCENT.
     *
     * It used to be a knob that set how MUCH of an accent there was, fading the weak
     * hits down as it turned. The list replaced it because a rhythm is
     * chosen rather than dialled: "which beats" is the question a drummer is asked,
     * and a level between two of them was never a groove. What it gave up did not
     * disappear: how hard the unmarked steps land is a setting of its own — WEAK VEL, on
     * OPTIONS — reachable without choosing a rhythm. The consequence is that this
     * parameter stopped being continuous, so synth_app_param_steps() now answers with
     * a count — the number of figures there are — and synth_app_param_text()
     * prints the figure's NAME rather than a velocity.
     *
     * The positions are numbers in the bar counted from the downbeat, so they do NOT
     * travel with ROTATE and are NOT rescaled for STEPS: QUARTER is on the beat
     * whatever the Euclidean figure is doing, and on seven steps it marks 1 and 5
     * because 9 and 13 have left the bar. The reasoning is spelled out over
     * ACCENT_MASK in synth_app.cpp, which is the only place the masks are
     * written.
     *
     * OFF is zero, and zero is the velocity every hit has always been struck at and the
     * one every lead note has always been opened at, so a device that has never been
     * touched, a sound remembered by an older firmware and a preset that predates this
     * parameter all play the drum and the line exactly as they were. The figure is made
     * by subtraction rather than by addition on purpose: the median hit is already
     * normalised to PERC_PEAK_TARGET and sits under the limiter's knee by 0.7 dB — see
     * perc_soft_limit() — so a "strong" hit raised above it would be the limiter's
     * answer rather than the player's. The lead has no such ceiling to respect: what it
     * gets is the same multiplier applied to the levels its note's three voices are opened
     * at — on that note's own group, and on no other — so a weak note is a quieter note
     * and nothing else about it moves.
     *
     * Appended at the very end of the patch for the reason BODY and SEND_MIC are: a
     * sound remembered by an older firmware is a prefix of this list and simply does
     * not carry this value, so it arrives at its default — OFF, the part as it always
     * was — and no index before it moves.
     *
     * NOT part of either random draw in synth_ui.c. This is the RHYTHM and not the
     * timbre: a draw that rewrote it would be inventing a groove, and the groove is what
     * the player set up.
     */
    SYNTH_PARAM_PERC_ACCENT,

    /*
     * HOW A CHANGE OF DELAY TIME ARRIVES: as tape, or across a fade.
     *
     * The delay reads its line at a fractional position, and that position WALKS to the
     * new time rather than jumping to it. What the walk sounds like is the whole of this
     * control. TAPE is the behaviour the instrument has always had: the pointer slews at
     * a bounded rate — half a sample per sample at the limit, an octave down — so a
     * change of time bends the repeats, exactly as slowing a tape machine does, and the
     * line is crossed at the speed tape would cross it. See DELAY_SLEW_MAX in
     * components/synth_dsp/src/synth_fx_delay.cpp for why the ceiling is a half.
     *
     * CROSSFADE puts the read position at the new time in one sample and crosses the two
     * taps over a fade instead, so the repeats do not bend at all: the old time is
     * replaced by the new one rather than travelled to. It is what a change of DIVISION
     * wants, which is a scene change rather than a performance. Neither setting is more
     * correct than the other; they are two answers to the same question.
     *
     * TAPE IS THE DEFAULT, deliberately: every sound this instrument has made so far —
     * every preset on every device and every remembered patch — was made with it, so the
     * default is what they already are. A record written before this parameter existed is
     * a prefix of this list and arrives at TAPE, the same way PERC_ACCENT's note
     * describes, so an older sound comes back exactly as it was saved.
     *
     * NOT part of either random draw in synth_ui.c: this is how the effect behaves rather
     * than how much of it there is.
     */
    SYNTH_PARAM_DELAY_TIMEMODE, /* tape / crossfade */

    /*
     * The drive: DEAD SLOTS, and they keep their places.
     *
     * They were the amount before the shaper and the shaper itself, and the drive is out of the
     * instrument — stage, page, knobs and all. The two enumerate entries stay because a
     * parameter's number is what a stored patch and a preset address: delete them here and every
     * value after them belongs to a different control, so a sound saved yesterday comes back as
     * a different instrument. Their appliers do nothing, their factory values are zero, and no
     * page offers them. This is the arrangement the drum's PITCH, QUANT, ENV, BODY, DECAY,
     * STEPS, PULSES and ROTATE already have.
     */
    SYNTH_PARAM_LEAD_PW,        /* ширина импульса лида: 0 = меандр, 1 = узкий импульс; был DRIVE_AMOUNT */
    SYNTH_PARAM_LEAD_SPREAD,    /* разброс стерео у лида 0..1; был DRIVE_ALGO, мёртвый с ухода привода */

    /*
     * The lead's own accent figure.
     *
     * The accent used to be ONE figure on both parts: an accent pattern was taken to be a
     * statement about the rhythm, and the lead and the drum share a bar. That reading does not
     * survive use — the drum wants its own emphasis and the lead wants its own, and turning the
     * accent on the lead's page moved the drum's hits. So the lead gets its own figure here,
     * and PERC_ACCENT keeps the drum's. Each is asked against its own bar, and OFF on either
     * part leaves that part exactly as it was built.
     */
    SYNTH_PARAM_SEQ_ACCENT,     /* the lead's accent figure */

    /*
     * The chorus's and the delay's sends, six parts each, in the same order as the reverb's
     * above: the three drone layers, the lead, the drum and the microphone. One per effect
     * rather than one shared bus, so a part can go deep into the delay and barely into the
     * chorus — that is what the three SENDS pages are for.
     */
    SYNTH_PARAM_CHR_SEND_LOW,
    SYNTH_PARAM_CHR_SEND_MID,
    SYNTH_PARAM_CHR_SEND_HIGH,
    SYNTH_PARAM_CHR_SEND_LEAD,
    SYNTH_PARAM_CHR_SEND_PERC,
    SYNTH_PARAM_CHR_SEND_MIC,

    SYNTH_PARAM_DLY_SEND_LOW,
    SYNTH_PARAM_DLY_SEND_MID,
    SYNTH_PARAM_DLY_SEND_HIGH,
    SYNTH_PARAM_DLY_SEND_LEAD,
    SYNTH_PARAM_DLY_SEND_PERC,
    SYNTH_PARAM_DLY_SEND_MIC,

    /*
     * PERC PITCH, PULLED ONTO THE SCALE.
     *
     * A drum's centre is a frequency and the instrument already has a scale in force, so the
     * two can be made to agree: with this on, the pitch knob lands on the nearest note of the
     * chosen scale instead of anywhere between them. It is a sound parameter and not a
     * setting — a kick tuned to the scale is a decision about the patch, and the patch that
     * carries it should bring the snap with it.
     *
     * Appended here, at the end of the patch and before the settings, so that every stored
     * patch and preset stays a prefix of the list. See the note at the top of this enum.
     */
    SYNTH_PARAM_PERC_QUANT,

    /*
     * How often the LEAD'S phrase is deliberately put back to its first step: INF, then
     * every 16, 32, 64, 128 or 256 steps of the lead's grid.
     *
     * A MUSICAL GESTURE, NOT A CORRECTION. The transport keeps one bar position and every
     * figure derives its step from it (see tp_advance() and tp_index() in synth_app.cpp),
     * so the lead, the drums and the arpeggiator cannot drift apart and there is nothing
     * to correct. What this parameter does is what a reset button does on purpose: once
     * the lead's phrase has stood on N steps of the grid the player sees, it begins
     * again. N is counted in grid steps of that phrase and read off the position, so it
     * cannot lag behind the transport while the arp holds the lead.
     *
     * IT IS THE LEAD'S GESTURE. The drum is not touched — not its position, not its
     * step, not a gate — because two figures disagreeing on purpose is the polyrhythm,
     * and a gesture that stopped the drum in the middle of its own phrase would be a
     * correction neither player asked for. The drum has its own gesture with its own
     * period, SYNTH_PARAM_PERC_RESET below, and the two never write each other's origin.
     * The arpeggiator goes with the lead: it is the figure the lead plays instead of its
     * grid, so it begins on its first note in the same block (that note is a note-on, not
     * a release; see arp_tick()).
     *
     * IT CUTS NOTHING. No gate is cleared and no voice is closed, and the drum's hits are
     * not ours to close at all: the lead's phrase begins on the first step at which the
     * note it opened has finished its gate. A sparse figure holds its notes longer than
     * one step — the gate is a fraction of the distance to the next onset — so its restart
     * can land a step later than the bare count; a dense figure is free at every boundary,
     * and its period is exact.
     *
     * A PATCH PARAMETER, NOT A SETTING, and that is the whole of what moved. It began life
     * as a device setting in the slot the vibration motor left on SYSTEM; the owner's
     * decision is that the gesture belongs to the SOUND, so a preset carries its own and
     * changing the preset changes it. It is therefore here, at the very END of the patch
     * and just before the settings, for the reason every appended parameter is: a record
     * written by an older firmware is a prefix of this list and simply does not carry it.
     * See the note over SYNTH_PARAM_PERC_QUANT.
     *
     * A PRESET WITHOUT THE FIELD MEANS SIXTEEN, not "off": zero is a real position — INF,
     * the gesture switched off — and a missing byte must not land on it.
     * synth_app_preset_load() applies the default for exactly this parameter; see the note
     * there.
     *
     * THE PERIOD IS READ FROM THE PHRASE'S OWN STEP NUMBER, so there is no counter that a
     * tempo change could leave behind and no re-trigger when the knob moves: a new N
     * applies to the phrase that is already running. An N that is a whole number of bars
     * for the grid in force lands on the bar line and is inaudible; one that is not
     * rewinds the phrase early, which is the gesture.
     *
     * NOT part of either random draw in synth_ui.c: this is the rhythm rather than the
     * timbre, and a draw that moved it would be inventing a groove. That is also how it
     * behaved while it was a setting, so the two draws are unchanged.
     */
    SYNTH_PARAM_SEQ_RESET,      /* INF / 16 / 32 / 64 / 128 / 256 lead steps */

    /*
     * How often the DRUM'S phrase is put back to its first step: the same six positions
     * as the lead's gesture above — INF, then every 16, 32, 64, 128 or 256 steps — but
     * counted on the drum's own grid and moving the drum's origin alone.
     *
     * THE TWO GESTURES ARE SEPARATE BY CONSTRUCTION, and that is the whole point of the
     * pair. One transport position feeds every figure (tp_advance(), tp_index()), and each
     * figure owns one origin subtracted from it: the lead's (s_seq_origin, with the arp's
     * s_arp_origin hanging off it) is written only by the lead's gesture, the drum's
     * (s_perc_origin) only by this one. Neither writes the position, the other's origin, a
     * gate or a voice, so neither can move the other by a step: a lead RESET leaves every
     * drum hit where it was, and a drum RESET leaves the lead's notes and the arp's where
     * they were. The two periods are independent numbers on independent grids (the parts
     * have their own STEPS), so sixteen on the lead with sixty-four on the drum is a valid
     * pair and either one may be INF.
     *
     * IT CUTS NOTHING, and that costs it a wait the lead does not have. A drum hit has no
     * gate that could be released: its envelope IS its gate, and the voice reports itself
     * finished when DECAY has run (synth_perc_active_voices(), read from the render path).
     * The restart lands on step zero of the phrase and it may only strike into silence:
     * while any voice is still ringing the gesture waits for the next boundary of its own
     * grid. At ROTATE zero step zero is an onset in every Euclidean figure, so the restart
     * always strikes and a tail under it would double a hit; with a rotation step zero can
     * be a rest, and the wait then costs one boundary and gives back silence. A decay
     * shorter than a step is over by the next boundary and the period is exact; a longer
     * one waits for the first boundary at which the tail has ended, which can be several
     * steps. A figure that sounds on every step with a decay longer than that step has no
     * silence between its hits, and there the gesture keeps waiting rather than doubling a
     * hit — the stated price of "the previous hit has sounded out".
     *
     * A PATCH PARAMETER like the lead's, at the very END of the patch, so a record written
     * by a firmware that carried only the lead's gesture is a prefix of this list. A
     * PRESET WITHOUT THE FIELD MEANS INF, the gesture off: the drum never started resetting
     * before this parameter existed, so an older sound must not begin to. That is the
     * opposite of the lead's missing-field default (sixteen) and deliberate — there the
     * field existed and meant sixteen, here it did not exist at all. See
     * synth_app_preset_load().
     *
     * NOT in either list the patch-wide random draw walks in synth_ui.c (PRESET_TIMBRE,
     * PRESET_STRUCTURE): it is the rhythm rather than the timbre, exactly like the lead's.
     */
    SYNTH_PARAM_PERC_RESET,     /* INF / 16 / 32 / 64 / 128 / 256 drum steps */

    /*
     * THE DRONE'S THREE SHAPES, ONE PER REGISTER.
     *
     * A shape used to be one choice for the whole part — DRONE_WAVE above — on the argument
     * that a drone whose registers had different shapes would be three instruments sharing
     * a filter. The owner's decision is the other way round, and it is about what the three
     * registers ARE: three octaves of one note, which is the one thing that distinguishes
     * them without moving the note. A shape each is therefore a difference in colour where
     * there was already a difference in register, and the filter stays one filter.
     *
     * THREE PARAMETERS AND NOT ONE WITH THREE VALUES, because a preset is a flat array of
     * normalised values addressed by position and the control surface draws one knob per
     * parameter: three shapes are three knobs on the drone's page — H.OSC, M.OSC and L.OSC
     * — and three positions in every record.
     *
     * APPENDED AT THE END OF THE PATCH, after the drum's RESET and before the settings, for
     * the reason every appended parameter is: everything before them keeps its index, and a
     * record written by a firmware that had one shape is a prefix of this list. That record
     * carries the old DRONE_WAVE byte, and synth_app_patch_apply() gives all three of these
     * the value it carried — which is exactly the sound the record was saved with. A record
     * that is older still and has no DRONE_WAVE byte gets the factory SAW, which is what the
     * old firmware would have used too.
     *
     * A change lands on the next block and re-triggers nothing, like every shape before it.
     * The morph is still ONE VOICE AT A TIME: the nine drone voices are staggered by
     * WAVE_MORPH_STAGGER_MS in the voice's own start delay (see apply_drone_wave()), so
     * changing all three shapes at once — a preset load does — starts nine fades 20 ms apart
     * instead of nine at once. Only the registers whose shape actually changed are written,
     * so a preset that changes one of them leaves the other six voices alone.
     */
    SYNTH_PARAM_DRONE_OSC_LOW,
    SYNTH_PARAM_DRONE_OSC_MID,
    SYNTH_PARAM_DRONE_OSC_HIGH,

    /*
     * HOW THE DRONE FOLLOWS THE LEAD: SCALE, FULL, CONS.
     *
     * The drone's base is its own and it is fixed: 55/110/220 Hz, one base for every mode,
     * so switching modes never retunes it by the difference between two references. The ROOT
     * knob does not transpose it — the knob names the key (the scale and its tonic), and the
     * drone is brought into that key through the scale. This parameter chooses what the
     * lead's notes do to it:
     *
     *   SCALE  the note's pitch class in the nearest direction: the interval from the base
     *          folded into ±6, so the drone lands on a degree of the scale and stays in its
     *          own register — a fifth above the base arrives as a fourth below. The factory
     *          setting, and what a record without this field gets.
     *   FULL   the whole signed interval from the base, octaves included: the LOW register
     *          lands on the played note. The only mode in which the drone leaves its register.
     *   CONS   responds only to a consonance above the base — a unison/octave, a third, a
     *          fourth or a fifth. On any other note it stands where it stood, which is the
     *          last shift it joined, or the base if it has not joined one yet.
     *
     * STAY IS GONE, and it is gone from the list rather than kept at position zero: it was
     * the pedal, the one position where the melody could not move the drone, and the owner's
     * decision is that the drone is a follower. The position is reused by SCALE, which is the
     * mode STAY already produced at rest; the migration in synth_app_patch_apply() maps a
     * stored four-position byte onto these three positions, so old records still come back
     * as the mode they named.
     *
     * The note is quantised by the scale before any mode sees it (seq_scale_note()), and it is
     * the newest note the lead is sounding; with no note all three return to the base. See
     * drone_tune_tick() for the table and for the edges.
     *
     * The transition between modes and every change of shift are smoothed by the same
     * 8 ms one-pole the shift has always had (DRONE_TUNE_TAU_S), so a mode change is a
     * glide and never a step: a list parameter arrives in one block by design, and this is
     * where that would otherwise be audible.
     *
     * APPENDED AT THE END OF THE PATCH like the three shapes above. A record without the
     * field gets SCALE — the factory default — and not the live value, because the old
     * firmware's following is not what a stored sound was. See synth_app_patch_apply().
     */
    SYNTH_PARAM_DRONE_FOLLOW,

    /*
     * KEY TRACKING OF THE TWO FILTERS: how far the cutoff follows the pitch.
     *
     * A filter's character is the ratio between its corner and the note, not the corner
     * itself: the same sound played an octave up needs its cutoff an octave up, or the ear
     * hears the same patch go dull as the line climbs and brittle as it falls. These two
     * knobs decide how much of that ratio the instrument keeps, 0..100 percent, and zero is
     * exactly the behaviour the instrument has always had — the cutoff is the knob's own
     * frequency and the pitch does not touch it.
     *
     * TWO PARAMETERS AND NOT ONE, because the two filters are pointed at different things.
     * DRONE_KTRCK is one number for all three registers: they are octaves of one fundamental
     * and the drone's shift moves all of them together, so one multiplier covers them.
     * Its reference is the drone's OWN base, A1 (MIDI 33, 55 Hz): the multiplier is
     * 2^(ktrck · (note − 33)/12), which is the same exponent the FOLLOW shift has already
     * computed, so a FULL mode octave up moves LOW to 110 Hz and the cutoff by exactly one
     * octave at 100 percent. LEAD_KTRCK is the lead's and its reference is A3 (MIDI 57,
     * 220 Hz) — the pitch the lead's own voice table is voiced at
     * (s_lead[].base_hz), so at that note the patch sounds as designed and the multiplier
     * is 1.
     *
     * AT 100 PERCENT THE CUTOFF TRAVELS WITH THE PITCH, octave for octave, and the timbre
     * is preserved exactly: 2^(shift/12) on the pitch and the same factor on the corner.
     * At 50 it travels half as far in octaves, which is a brighter high register and a
     * darker low one — a colour, not a correction. Both are read once per note change and
     * never per sample: the corner itself is already smoothed inside each filter, and the
     * cost is one exp2f and one setBusFXParam per register when the note moves, not per
     * block.
     *
     * THE RESULT IS CLAMPED AT DRONE_CUTOFF_MAX_HZ / LEAD_CUTOFF_MAX_TRACK_HZ, because a
     * cutoff above Nyquist is not a sound and an int16_t slot would overflow into a negative
     * frequency. At the top of the cutoff travel the tracker therefore saturates instead of
     * doubling past 16 kHz; the corner is already at the top of the band there.
     *
     * APPENDED AT THE VERY END OF THE PATCH, after FOLLOW and before the settings, for the
     * reason every appended parameter is here: a record written before them is a prefix of
     * this list and reads its two values as their factory zero — no tracking, the sound it
     * was saved with.
     */
    SYNTH_PARAM_DRONE_KTRCK,    /* drone filter key tracking, 0..100 percent */
    SYNTH_PARAM_LEAD_KTRCK,     /* lead filter key tracking, 0..100 percent */

    /*
     * FILTER MODE: the shape of the corner, low to high through band.
     *
     * Both filters are built on the same state-variable core, which produces low,
     * band and high outputs from one state, so the mode is a crossfade between
     * them and not a different filter: 0 is the low pass exactly (a branch, no
     * arithmetic, so the sound of a stored patch is bit for bit the sound it had
     * before the knob existed), 50 is the band pass, 100 the high pass, and the
     * travel between them is continuous, because a switch would click on a
     * sustained drone.
     *
     * Appended for the same reason as the trackers: a record written before them
     * reads its two values as the factory zero, which is the low pass.
     */
    SYNTH_PARAM_DRONE_FILTER_MODE,  /* 0 low .. 50 band .. 100 high */
    SYNTH_PARAM_LEAD_FILTER_MODE,   /* 0 low .. 50 band .. 100 high */

    /*
     * THE DRUM SECTION, AS A KIT AND A GROOVE RATHER THAN A VOICE: eleven parameters, all
     * normalised, split across two pages — six that shape the timbres and five that shape
     * the part. THE DIVISION IS THE ONE A DRUM MACHINE HAS ALWAYS HAD: the kit is the sound
     * and the groove is what is played with it.
     *
     * WHY THE VOICE'S OWN KNOBS ARE NO LONGER ENOUGH. One drum with one centre can be a kick
     * or a hi-hat and never both at once, and a drum part is made of different drums. The
     * section is therefore four lanes — KICK, SNARE, HAT, TOM — each with a recipe out of
     * the chosen kit, and the parameters below are the ones a player moves: the kit, its
     * pitch and its material, how alive its timbres are, and the figure that plays them.
     *
     * PERC_KIT picks the recipes and the character: sixteen kits, from a dry tight kit to a
     * long low one, and from a machine to a brush; the difference between two of them is
     * bigger than the difference between two positions of any one knob below. It is a list,
     * so its travel is the sixteen positions and a stored value lands on the nearest.
     *
     * PERC_TONE transposes the whole kit by up to an octave either way and PERC_TUNE
     * transposes only the two pitched lanes, the kick and the tom, so that the drum can sit
     * in the key while the hat stays where a hat belongs. PERC_LENGTH scales every gate,
     * PERC_BODY_TRIM is the attack of every hit (the page calls it PUNCH), and PERC_TIMBRE is the life in
     * the sound: how much a harder hit brightens and lengthens it, the per-hit jitter, the
     * slow per-bar walk of centre and gate, and how often a lane takes its alternate voice —
     * the open hat for the hat, the rim for the snare. At zero the section is a machine that
     * repeats exactly; at one it is a player who cannot quite repeat himself.
     *
     * PERC_GROOVE, PERC_VARIATION, PERC_FILL, PERC_SWING and PERC_SPEED are the part.
     *
     * GROOVE IS A LIST OF SIXTEEN WRITTEN PATTERNS and not a density: a minipops beat, a
     * disco, a boogie, a rock, a funk, a break, a house, a trap, a half-time, a two-step, an
     * afro, a latin, a march, a bossa, a garage and a club pattern, each a bar of sixteens
     * across the four lanes with its own ghost notes and its own cycle of bars. That is the
     * lesson of the Minipops and the only reason its rhythms sound like parts: the player
     * chooses a part that was written, and the generator varies it rather than inventing it.
     *
     * VARIATION is how often the part is varied at the bar line — the snare and the hats
     * shift by a sixteenth, an extra kick appears on a rest; FILL is how often the last bar
     * of the groove's cycle is a fill; SWING is how late the second sixteenth sits; SPEED is
     * the drum's clock against the transport and moves only in the ratios that agree with the
     * bar: ×0.25, ×0.5, ×1 and ×2. A speed that is not a ratio of two would drift against
     * the transport and the drum would argue with the rest of the instrument, so a change of
     * speed waits for the next bar line and re-anchors the drum there once.
     *
     * At VARIATION 0 and FILL 0 what plays is the written groove and nothing else.
     *
     * APPENDED AT THE END OF THE PATCH, like every parameter above them: a record written
     * before the kit existed is a prefix of this list and reads each of these at its factory
     * value, which is the MINI kit at the design settings — a drum section that plays, and
     * that a hand can then move. The old PERC_PITCH, PERC_DECAY, PERC_ENV, PERC_BODY,
     * PERC_QUANT, PERC_STEPS, PERC_PULSES and PERC_ROTATE keep their numbers and their
     * places in old records; they are simply no longer on a page, and the kit's recipes are
     * what the voice is set from now.
     */
    SYNTH_PARAM_PERC_KIT,           /* which kit: sixteen sets of four recipes */
    SYNTH_PARAM_PERC_TONE,          /* the whole kit's pitch, 0.5 = none */
    SYNTH_PARAM_PERC_LENGTH,        /* every gate's multiplier, 0.5 = the kit's own */
    SYNTH_PARAM_PERC_BODY_TRIM,     /* the attack of every hit, 0.5 = the hit as it was */
    SYNTH_PARAM_PERC_TIMBRE,        /* life in the timbres: velocity, jitter, walk, alternates */
    SYNTH_PARAM_PERC_TUNE,          /* the pitched lanes only, 0.5 = none */
    SYNTH_PARAM_PERC_GROOVE,        /* which written pattern plays: a list of sixteen */
    SYNTH_PARAM_PERC_VARIATION,     /* how often a figure is re-drawn at the bar line */
    SYNTH_PARAM_PERC_FILL,          /* how often the last bar of the cycle is a fill */
    SYNTH_PARAM_PERC_SWING,         /* how late the second sixteenth sits */
    SYNTH_PARAM_PERC_SPEED,         /* the drum's clock: ×0.25, ×0.5, ×1, ×2 */

    /*
     * THE TONIC'S OCTAVE — and why it stands here, a hundred numbers from the note it belongs to.
     *
     * ROOT used to be one knob across eighty-five semitones, MIDI 24..108: the tonic as a
     * single position, found by sweeping and read off the display. The owner asked for the note
     * and the octave to be two sectors, because the pair is what a player can aim at: twelve
     * notes the hand knows and seven octaves it knows. This is the second of them, and the note
     * stayed where it was.
     *
     * ROOT is now the NOTE (twelve positions, C..B) and this is the OCTAVE (seven, 1..7); the
     * two together name the same pitches the single knob did, less the top C of the old range.
     * Both are lists, so both step one detent per position and neither accelerates.
     *
     * IT IS APPENDED AT THE END OF THE PATCH AND NOT BESIDE ROOT. A patch and a preset are the
     * parameter list in ORDER, addressed by number, so a parameter inserted in the middle would
     * be read as its neighbour by every record ever written — the rule the whole enum is built
     * on. ROOT keeps number 11, this takes the last of the patch, and the out-of-order list is
     * the price of every old sound coming back in its own key.
     *
     * A RECORD WRITTEN BEFORE THIS EXISTED has no byte for it and would arrive at the factory
     * octave — but its ROOT byte is a position on the eighty-five-note list, not a note. That is
     * synth_app_patch_apply()'s business: the record's own length says which list it was
     * written against, and the note and the octave are both recomputed from the pitch it held.
     */
    SYNTH_PARAM_ROOT_OCT,           /* the tonic's octave, 1..7; the note is ROOT */

    /*
     * THE ARPEGGIATOR'S OWN ACCENT FIGURE — the third of the three, and the one that was
     * missing until the owner heard it.
     *
     * There are two figures already, LEAD EUCLID's for the lead's line and PERC SEQ's for
     * the drum, and they are independent on purpose: one shared figure moved both parts. The
     * arpeggiator borrows the LEAD's, because while it plays it IS the lead, and that reads
     * correctly on paper — one part, one figure. It does not read correctly from the page: the
     * arp's notes come from a held chord and from the arp's own step, its accents land on its
     * own rhythm of the bar, and a figure chosen on a page two tiles away decided them.
     *
     * So the arp gets a figure of its own, on its own page, with the same eight panel forms
     * and the same rule behind them: accented steps are struck at the key's velocity, the rest
     * at WEAK VEL of it. OFF — no accent at all, every step at the key's own level — is the
     * factory position, which is what the instrument did before the parameter existed.
     *
     * APPENDED AT THE END OF THE PATCH, for the usual reason: a record is addressed by number.
     * An older record has no byte for this and arrives at OFF, so its arp comes back unaccented
     * rather than re-accented by a figure nobody chose.
     */
    SYNTH_PARAM_ARP_ACCENT,         /* the arp's accent figure: the same eight, its own choice */

    /*
     * THE SHAPE OF THE LEAD FILTER'S ENVELOPE — the sixth sector of the TONE page, and
     * the knob that turned the filter's ADSR into an AR.
     *
     * The envelope now has two segments and no sustain, because the owner asked for the
     * two he plays with and the two he does not were in the way. Its LENGTH is not a
     * parameter at all: it is the note's — the sixteenth of the transport times GATE —
     * and this knob splits that length between the attack and the release. At -100 % the
     * attack is a millisecond and the rest is a long release, at 0 % the two are equal,
     * at +100 % the attack owns the gate and the release is instant. The filter closes
     * by the end of every note, which is the point of it: the corner is part of the
     * articulation and not a pad that stays open until the key comes up.
     *
     * WHY THE LEAD ENV PAGE'S FOUR KNOBS ARE NOW THE AMPLITUDE. They never were: they
     * wrote the filter's ADSR, and the amplitude was a fixed 40/250/0.86/500 ms that no
     * page could change — the owner believed otherwise, and the belief was the better
     * instrument. So the four moved to the amplitude envelope, where a long attack and a
     * long release are what a player wants to shape, and their factory values are those
     * four old constants, so a patch that never touches them sounds as it did.
     *
     * APPENDED AT THE END OF THE PATCH, where every parameter of this file ends up: a
     * record written before the knob existed is a prefix of this list and reads this one
     * at its factory 0 %, which is the equal split — a filter envelope an AR can be, and
     * nothing a hand has to undo.
     */
    SYNTH_PARAM_LEAD_FENV_SHAPE,    /* the filter envelope's split, -100..+100 percent */

    /*
     * Whether the lead is four voices or one, as POLY and MONO.
     *
     * MONO IS THE INSTRUMENT AS IT WAS BEFORE THE OVERLAP: every note takes the same
     * group, so a release is cut by the note after it, and a chord on the keys is heard
     * as its newest note. POLY is the four groups — a step that arrives while the
     * previous note is still ringing takes another group, and four keys can be held.
     *
     * APPENDED AT THE END OF THE PATCH, like the split before it, and a record written
     * before the knob existed reads this one at 0 %, which is MONO: the sound that record
     * was made with is the monophonic one.
     */
    SYNTH_PARAM_LEAD_VOICE,         /* POLY or MONO */

    /*
     * ЧЕМ ДАКИНГ СЛЫШИТ УДАР, и как долго он отпускает.
     *
     * До этих двух ручек источником был конверт удара целиком: кик, малый, хэт и том
     * открывали дакинг одинаково, и на плотной фигуре низ дрона качался от хэта так же,
     * как от бочки. SRC — мультимодальный фильтр на этом источнике: одна ручка ведёт от
     * низа (LP, только тело бочки) через середину (BP, корпус малого) к верху (HP, щелчок
     * и хэт). Резонанса у фильтра нет и не будет: он выбирает полосу, а не звенит, поэтому
     * Q здесь ровно 0.707 и остаётся таким на всём ходу ручки.
     *
     * REL — время отпускания отдельным числом, 60..400 мс. Раньше оно было сцеплено с
     * глубиной (220 мс внизу, 90 мс наверху), и это работало, пока дакинг был одним
     * жестом. С выбором полосы сцепка мешает: медленный дакинг по низу и быстрый по верху
     * — это два разных музыкальных приёма, а не две точки одной кривой.
     *
     * ОБЕ ПРИПИСАНЫ В КОНЕЦ ПАТЧА, как и всё до них: запись, сделанная раньше, читает
     * SRC = 0 (LP, то есть весь удар, как было) и REL в положение, которое даёт прежние
     * ~180 мс.
     */
    SYNTH_PARAM_MASTER_DUCK_SRC,    /* LP / BP / HP: чем дакинг слышит удар */
    SYNTH_PARAM_MASTER_DUCK_REL,    /* 60..400 мс: как долго отпускает */

    /*
     * УРОВНИ ДОРОЖЕК ПЕРКУССИИ: страница PERC MIX.
     *
     * Микшер части, а не второй кит: четыре ручки ставят каждую дорожку на своё место, не
     * трогая рецепт. 100 — дорожка звучит так, как её записал кит; ниже — тише; на нуле
     * дорожка не бьёт вовсе, и голос на неё не тратится (то же правило, что у фейдера части,
     * см. perc_strike()).
     *
     * ПРИПИСАНЫ В КОНЕЦ ПАТЧА: запись, сделанная раньше, читает их на 100 и звучит как
     * звучала. В пресет они входят — это часть звука, а не настройка прибора.
     */
    SYNTH_PARAM_PERC_MIX_KICK,      /* уровень бочки */
    SYNTH_PARAM_PERC_MIX_SNARE,     /* уровень снейра */
    SYNTH_PARAM_PERC_MIX_HAT,       /* уровень хэта */
    SYNTH_PARAM_PERC_MIX_TOM,       /* уровень тома */

    /*
     * SPAN: СКОЛЬКО ОКТАВ ОБХОДИТ МЕЛОДИЯ.
     *
     * До этой ручки обход был ровно две октавы — не решение, а число, вписанное в
     * генератор: `span = len * 2`. На пятиступенном ладу это десять позиций, и линия
     * гуляла по ним; на хроматике — двадцать четыре, и это уже не линия, а россыпь.
     * Владелец попросил диапазон, который можно выбрать: одна октава (лад, а не полёт),
     * две (как было) и три (широко, для редких длинных фраз).
     *
     * ТРИ ПОЛОЖЕНИЯ, ОДИН ДЕТЕНТ КАЖДОЕ: 0 — одна октава, 50 — две, 100 — три. Заводская
     * середина, потому что она и есть прежнее поведение: патч, записанный раньше, читает
     * её и звучит как звучал.
     *
     * Стоит в конце патча, как и PUNCH/MIX до неё: длина записи выросла на байт, а прежние
     * записи читаются до конца и недостающее берут заводским значением.
     */
    SYNTH_PARAM_GEN_SPAN,           /* октав в обходе мелодии: одна, две, три */

    /*
     * DRIFT: НАСКОЛЬКО РАСХОДЯТСЯ РЕГИСТРЫ ДРОНА.
     *
     * Дрон — три точные октавы, и точные до цента: это степени двойки от одной базы. От
     * этого он и стоит как генератор, а не как инструмент. Биение появляется только тогда,
     * когда два почти совпадающих тона чуть-чуть не совпадают, и вот этого «чуть-чуть»
     * здесь не было вовсе.
     *
     * Ручка задаёт ОДНО: насколько далеко. Каждый регистр качается в своей фазе и с одной
     * медленной скоростью (около одной десятой герца, то есть дыхание раз в десять секунд),
     * поэтому три голоса никогда не идут вместе: они то сходятся, то расходятся, и биения
     * получаются неровными, как у живого ансамбля. Скорость не ручка: у дрейфа, который
     * можно ускорить, есть только один интересный диапазон, и он уже выбран.
     *
     * Ноль — сегодняшний звук до цента, поэтому ни один сохранённый патч не меняется.
     * Сто центов на самом верху — полутон: это уже не биение, а расстроенность, и в музыке
     * верхом ручки пользуются редко. Но предел должен быть слышен целиком, а не угадываться
     * за краем: рабочая зона лежит в первых двадцати центах, и туда рука попадает легко
     * именно потому, что до края далеко.
     */
    SYNTH_PARAM_DRONE_DRIFT,        /* центы расстройки регистров, 0..30 */

    /*
     * THE BASS SECTION: one voice, its own layer, twelve macros and four mixer values.
     *
     * The bass is an instrument of its own, not a fourth register of the drone: a sequencer
     * that places a note on an exact sample rather than on a block, one voice under it, and
     * a layer of its own in the rack so that it can have a fader and sends like every other
     * part. The DSP side is complete and lives in synth_bass.cpp; what is here is the
     * sound's memory of it.
     *
     * The twelve macros are the voice and the figure. KIT and PAT are LISTS of thirty with
     * one detent each — a kit is a place and not a dial, and so is a written bar — while OCT
     * and LEN are arcs that name a whole number (-2..+2 octaves about A1, and 4..16 steps).
     * LVL, REV, CHR and DLY are the layer's fader and its three sends: what the rack needs to
     * place the part in the mix, beside the same four for every other layer.
     *
     * APPENDED AT THE END OF THE PATCH, immediately before the settings, so that every
     * parameter already part of the sound keeps the index it had: the patch and the presets
     * are a flat array of these values in this order, and a record written before the bass
     * existed is a PREFIX of the list, which loads with these sixteen at their defaults.
     */
    SYNTH_PARAM_BASS_KIT,       /* kit over thirty, one detent each: round, picked, driven */
    SYNTH_PARAM_BASS_OCT,       /* the line's octave about A1, -2..+2 */
    SYNTH_PARAM_BASS_TONE,      /* СЛОТ 2 = ОКТАВА ЛИНИИ, -2..+2: срез ушёл в киты */
    SYNTH_PARAM_BASS_DECAY,     /* the length of the note */
    SYNTH_PARAM_BASS_SNAP,      /* the depth of the pitch dive at the attack */
    SYNTH_PARAM_BASS_DRIVE,     /* СЛОТ 5 МЁРТВ: резонанс живёт в ките, патч его не двигает */
    SYNTH_PARAM_BASS_PAT,       /* figure over thirty written bars, one detent each */
    SYNTH_PARAM_BASS_VAR,       /* character: bar jumps, ties and accents */
    SYNTH_PARAM_BASS_LEN,       /* steps of the bar the figure plays, 4..16 */
    SYNTH_PARAM_BASS_GATE,      /* the share of a step the note holds */
    SYNTH_PARAM_BASS_SLIDE,     /* the chance a note ties into the next */
    SYNTH_PARAM_BASS_ACCENT,    /* the chance a note is struck hard */
    SYNTH_PARAM_BASS_LVL,       /* the layer's fader in the rack */
    SYNTH_PARAM_BASS_REV,       /* how much bass goes to the reverb */
    SYNTH_PARAM_BASS_CHR,       /* ...to the chorus */
    SYNTH_PARAM_BASS_DLY,       /* ...to the delay */

    /*
     * ДЕМПФИРОВАНИЕ ПОВТОРОВ ДИЛЕЯ.
     *
     * В дабе повтор обязан темнеть с каждым проходом — это половина характера эффекта, и
     * до этой ручки его не было вовсе: повторы возвращались такими же яркими, как источник.
     * Стоит в САМОМ КОНЦЕ патча, а не в середине: тогда все прежние индексы остаются на
     * своих местах, а патч и пресет, записанные раньше, читаются как префикс списка и
     * получают заводское значение. */
    SYNTH_PARAM_DELAY_DAMP,     /* 0 — открыто (18 кГц), 1 — глухо (700 Гц) */

    /* ПОСЫЛ ДИЛЕЯ В РЕВЕРБ: сколько мокрого сигнала дилея уходит в реверб. Ноль — как было
     * раньше, повторы сухие; сто процентов — реверб обрабатывает и повторы тоже. */
    SYNTH_PARAM_DELAY_VERB,

    /* ЭФФЕКТ-МАШИНА: тип (хорус, тремоло, автопан, драйв, биткраш) и её третий параметр.
     * Первые два — SYNTH_PARAM_CHORUS_RATE и SYNTH_PARAM_CHORUS_DEPTH: их id остались, чтобы
     * старые патчи читались как хорус с прежними настройками. */
    SYNTH_PARAM_FX_TYPE,
    SYNTH_PARAM_FX_C,

    /* Посыл мокрого сигнала эффект-машины в реверб. */
    SYNTH_PARAM_FX_VERB,


    /*
     * ТИП ДИЛЕЯ — ЧАСТЬ ЗВУКА, последним в патче.
     *
     * Последним, а не рядом с остальными параметрами дилея: вставка в середину сдвинула бы
     * номера всех следующих, и сохранённые звуки прочитались бы как другие. Так старые
     * записи читаются как прежде, а новый параметр берёт заводское значение.
     */
    SYNTH_PARAM_DELAY_TYPE,
    SYNTH_PARAM_MASTER_SIDE,   /* сайдчейн посылов в эффекты */

    /*
     * Settings, not sound.
     *
     * They live in the same table because the display machinery reads every
     * control the same way — one number, one name, one optional list to fall
     * into — and a second parallel pipeline for a handful of items would be a
     * handful of items that behave subtly differently. What makes them settings is
     * where a write GOES: the UI routes these to app_settings, which owns the hardware
     * and the flash, and the audio task is handed none of them — with ONE exception,
     * stated where it belongs: WEAK VEL, which the engine reads for itself because the
     * knob that would have carried it could not be a patch parameter. See below.
     *
     * They are therefore deliberately last: everything before them is the patch,
     * and SYNTH_PARAM_PATCH_COUNT is what gets remembered.
     */
    /*
     * НАСТРОЙКИ МОДУЛЯЦИИ — ЧАСТЬ ЗВУКА.
     *
     * Оба LFO переехали сюда из сессионной группы: адресат, две его глубины, форма и
     * скорость — это то, чем звук сделан, и в пресете они должны ехать вместе с ним.
     * Порядок ровно такой, как на страницах: DEST, DEPTH, SHAPE, SPEED у каждого канала.
     */
    SYNTH_PARAM_MOD_DEST,       /* первый приёмник первого LFO */
    SYNTH_PARAM_MOD_DEPTH,      /* его глубина, двусторонняя */
    SYNTH_PARAM_MOD_DEST2,      /* второй приёмник */
    SYNTH_PARAM_MOD_DEPTH2,     /* его глубина */
    SYNTH_PARAM_MOD2_SHAPE,     /* форма второго LFO */
    SYNTH_PARAM_MOD2_DEST,
    SYNTH_PARAM_MOD2_DEST2,
    SYNTH_PARAM_MOD2_DEPTH,
    SYNTH_PARAM_MOD2_DEPTH2,
    SYNTH_PARAM_MOD2_RATE,      /* скорость второго LFO */

    SYNTH_PARAM_SET_SCREEN,     /* backlight, 0..100 percent */
    SYNTH_PARAM_SET_RING,       /* LED ring, 0..100 percent */
    SYNTH_PARAM_SET_RINGMODE,   /* page / stereo / off */
    SYNTH_PARAM_SET_PATCH,      /* forget the sound, or remember it */
    SYNTH_PARAM_SET_AUTOPLAY,   /* играть ли при включении: ON, OFF, STORE */
    SYNTH_PARAM_SET_FASTRAND,   /* быстрый рандомизатор: OFF, PARAM, PAGE */
    SYNTH_PARAM_SET_SLIDE,      /* how long a batch of new values takes to arrive */
    SYNTH_PARAM_SET_RNDDELAY,   /* may a random draw choose the delay's time section */

    /*
     * The microphone's sensitivity, 0..100 percent, zero meaning off.
     *
     * Deliberately among the LAST of the settings rather than before the first of
     * them: PATCH_COUNT is SET_SCREEN, so a setting inserted before it would move every
     * patch parameter that is already stored in the flash and in 128 presets by one, and
     * a saved sound would come back attached to the wrong controls. A setting is stored
     * under its own string key (SETTINGS[] in app_settings.c) rather than by its number,
     * so where it sits among the settings matters only to that table — which is why
     * WEAK VEL was appended after this one rather than inserted anywhere more logical.
     *
     * One knob and not two: it drives the driver's own gain, and the envelope that
     * modulation reads is normalised after it, so turning it up is the whole of
     * "make the microphone more sensitive" — and at zero the input is not read at
     * all. See apply_mic() and mic_process_block() in synth_app.cpp.
     */
    SYNTH_PARAM_SET_MIC,        /* microphone sensitivity, 0 = off */

    /*
     * The velocity a NON-accented hit is struck at, 0..127 in the engine's own units,
     * factory 80. APP_SET_WEAK_VEL in app_settings.h is the same thing seen from the
     * storage side, and that is where the three values worth knowing are written out.
     *
     * It sits in this table because the control surface reads every control the same way
     * — one number, one name, one optional list to fall into — and because the knob, the
     * arc, the readout and the knobs' own restore all address a control by its
     * parameter. What makes it a SETTING is where a write goes: the UI routes it to
     * app_settings, so it is not part of the patch, not part of a saved sound and not
     * drawn by either randomiser. It is also the one setting the AUDIO task reads for
     * itself — accent_velocity_weak() in synth_app.cpp asks app_settings for it rather
     * than trusting the copy kept here, which exists for the display.
     *
     * A LIST of a hundred and twenty-eight entries, and deliberately so: the value is
     * whole numbers of engine velocity and every one of them is a real difference in how
     * hard the hit is struck, so the knob is given one arc step per number — one detent,
     * one velocity — exactly as the other lists do. The wheel accelerates it like every
     * other control (proxy_changed_cb() in synth_ui.c), so a fast turn crosses the range
     * in a flick and a slow one still moves by one. The alternative, a continuous
     * thousand-step arc, was rejected: it would need a second percentage-style mapping
     * beside the two brightnesses, and at a steady turning speed one detent is a seventh
     * of a velocity unit — eight clicks before the number moves at all. For this control
     * the fine end is what matters, and one click per number is the honest resolution.
     *
     * Appended among the settings for the reason the microphone's entry gives: what is
     * indexed by number is the patch, and everything before SET_SCREEN is the patch. The
     * modulation page's own values that follow keep their behaviour, since they are stored
     * nowhere by number.
     */
    SYNTH_PARAM_SET_WEAKVEL,    /* velocity of a weak hit, 0..127; 127 = no accent */

    /*
     * Is the instrument a USB MIDI device — OFF or ON — and OFF is the factory answer.
     *
     * In this table for the reason the weak hit is: the control surface reads every control
     * the same way — one number, one name, one optional list to fall into — and a control
     * that behaved differently would be a second pipeline to keep in step. What makes it a
     * SETTING is where a write goes: the UI routes it to app_settings under its own key, so
     * it is not part of the patch, not in a saved sound and not drawn by either randomiser.
     *
     * It is also the one setting whose effect is another COMPONENT rather than the board:
     * the write ends in midi_in_set_enabled(), which is what installs or uninstalls the USB
     * device stack. app_settings cannot make that call (components/midi requires this
     * component, so the edge back would be a cycle), so the settings page owns it, exactly
     * as it owns the ring mode — see apply_setting() in synth_ui.c. main() asks the same
     * question once at boot, through app_settings_get(APP_SET_MIDI_IN).
     *
     * WHY OFF, and it is not a matter of taste: USB-Serial-JTAG and USB-OTG are two
     * controllers behind one PHY, so ON means the USB-C socket is a MIDI port and the debug
     * console is gone from the computer for as long as the instrument runs. OFF is the state
     * that keeps the port, and the one thing a fresh device should do. Anything else about
     * the input — transpose, a velocity curve, channel assignment — would be a mapping and
     * is deliberately not here; the switch is the whole of the configuration.
     *
     * Appended among the settings for the reason the microphone's entry gives: what is
     * indexed by number is the patch, everything before SET_SCREEN is the patch, and the
     * three modulation values below move by one — which nothing can notice, because they are
     * addressed by this enum inside one build and stored nowhere by number.
     */
    SYNTH_PARAM_SET_MIDIIN,     /* USB MIDI note input, 0 = off, 1 = on */

    /*
     * How long a change of WAVE takes to become audible, as a LIST of eleven durations — 0, 5,
     * 10, 15, 20, 25, 30, 40, 60, 80 and 100 ms — one detent each, the value the rest of the
     * instrument reads out of app_settings and the index of WAVE_MORPH_MS in synth_app.cpp.
     * 25 ms out of the factory, which is index 5 of 10.
     *
     * WHY IT EXISTS. WAVE is a list, and every list on this instrument arrives in one step by
     * design: a detent is an entry, and an entry that slid would be two things at once. That is
     * right for the shape of a voice nobody is listening to yet, and it is a click on a voice
     * that is already sounding — which is what turning the drone's WAVE knob while the drone
     * plays does, deliberately, because that is how the shapes are auditioned. The step
     * cannot be smoothed on the parameter: the parameter is a list, it is stored in a preset
     * and it is drawn by the randomiser, so a slide on it would be a different feature. The
     * smoothing is therefore inside the VOICE: the engine renders the old shape and the new one
     * for the same span of time, from the same phase, and crossfades them, and this setting is
     * how long that takes. See setWaveSmooth() in components/synth_core/src/ESP32Synth.h.
     *
     * 0 IS EXACTLY THE OLD BEHAVIOUR — one render, one step on the next block — so the bottom
     * of the knob is also the escape hatch. The factory value is not 0 because a click is not a
     * good first impression, and not more than 25 ms because the knob would stop feeling
     * immediate; the positions above it are there so that the line can be heard.
     *
     * WHAT IT DOES NOT COVER, stated rather than implied: the shapes that carry a position of
     * their own — a wavetable, a sample, a stream — cannot be rendered twice and change
     * instantly at any setting, and so does the SUPERSAW, which is not a shape at all but the
     * same anti-aliased saw on three detuned voices (see wave_apply() in synth_app.cpp). A
     * change into or out of it is instant by construction, and the ≤ 14 cents of detune on the
     * outer voices of the group steps with it.
     *
     * Appended among the settings for the reason the microphone's entry gives: what is indexed
     * by number is the patch, everything before SET_SCREEN is the patch, and the three
     * modulation values below move by one — which nothing can notice, because they are addressed
     * by this enum inside one build and stored nowhere by number.
     */
    SYNTH_PARAM_SET_WAVEMORPH,  /* wave-morph time, index into WAVE_MORPH_MS; 0 = instant */

    /*
     * DRIVE POSITION: a dead setting.
     *
     * It chose between the drive before the effects and after them, and it went with the drive
     * itself. The entry stays for the same reason the two patch slots do — dropping it would
     * move every setting below it — and because app_settings' own table is indexed by ITS enum,
     * where the same argument applies twice. Nothing reads it, and OPTIONS no longer offers it.
     */
    SYNTH_PARAM_SET_DRIVE_POS,  /* dead: was 0 = drive before the effects, 1 = after */


    /*
     * The modulation page's own values, kept past SYNTH_PARAM_PATCH_COUNT deliberately: the
     * patch and the presets are the first PATCH_COUNT entries of this list, so nothing here is
     * part of a saved sound and each one keeps its factory default.
     *
     * The settings just above are NOT the reason these sit here. They are stored in NVS under
     * their own string keys — SETTINGS[i].key in app_settings.c, not by their number — so
     * inserting among them would not make a stored setting be read as its neighbour; what it
     * would disturb is the SETTINGS[] table, which is indexed by APP_SET_* and would need a
     * matching row.
     */
    SYNTH_PARAM_MOD_TRIG,       /* how the modulation restarts: free, per note, held */


    /*
     * ВТОРОЙ ПРИЁМНИК. DEST выбирает один приёмник или пару, DEST2 — ещё один: два списка
     * складываются по битам, и модуляция приходит сразу в оба места. Раньше сочетания были
     * вписаны в один список готовыми строками, и выбрать своё можно было только из того, что
     * кто-то придумал заранее.
     *
     * Стоит здесь же, за SYNTH_PARAM_PATCH_COUNT: как и остальные значения этой страницы, в
     * патч и пресеты он не входит и держит заводское значение.
     */

    /*
     * ВТОРАЯ ГЛУБИНА ПЕРВОГО LFO. У первого LFO два приёмника, и глубина у каждого своя:
     * DEPTH двигает DEST, DEPTH2 — DEST2. Если приёмник выбран в обоих, глубины складываются.
     */

    /*
     * ВТОРОЙ LFO: своя форма, свои два приёмника, свои две глубины и своя скорость. Всё это,
     * как и первый LFO, живёт вне патча: это настройка модуляции, а не часть сохранённого
     * звука. Глубины по умолчанию нулевые, поэтому второй LFO молчит, пока его не тронули.
     */

    SYNTH_PARAM_COUNT
} synth_param_t;

/* How many parameters make up the sound. Everything before the settings. */
#define SYNTH_PARAM_PATCH_COUNT ((int)SYNTH_PARAM_SET_SCREEN)

/*
 * The bass section's two lists: thirty kits and thirty written bars, one detent each.
 *
 * The count is here rather than in the engine for the reason the drum's is: a list
 * parameter's travel IS its count, so the arc, the readout and the table in synth_app.cpp
 * all take the number from one place. Thirty is also what synth_bass.cpp's KITS[] and
 * PATTERNS[] hold, and the two lists are read as positions over count-1 by both sides.
 */
#define BASS_KIT_COUNT 30
#define BASS_PAT_COUNT 42

/*
 * The drum section's kits, and the names the two drum pages read.
 *
 * Twenty-four of them, and the count is written here rather than in the engine because the
 * display needs it too: a list parameter's travel is its count, so PERC_KIT's twenty-four
 * positions come from this number and not from a second one kept beside the tables.
 *
 * The kits are ordered from dry to strange, which is the order the knob travels in: TIGHT is
 * the shortest and most controlled, MINI is the drum machine the instrument was tuned
 * against and the factory kit, BROKEN is the long metallic one, and the rest are characters
 * rather than variations — DUST is a dark room, TAPE is a worn machine, DEEP is a slow heavy
 * kit, BRUSH is soft attacks and long noise, MACHINE is the hardest and most regular.
 *
 * THE LAST EIGHT WERE ADDED ON TOP, and they are the ones with no relative among the first
 * sixteen: GLASS and BOX have no bottom, NEON is the eighties, SUB is one kick, WOOD is wood,
 * GRIME is the middle, TIN is a toy, INDUS is the heaviest. A kit is a place rather than a
 * setting, and sixteen places had begun to repeat each other.
 *
 * THE COUNT CHANGED THE ARITHMETIC OF EVERY STORED KIT. A list parameter is stored as a
 * position, not as an index, so a preset saved at 8 of 16 comes back as 12 of 24 — a different
 * kit. That is the price of a longer list, and it is the price the groove list paid when it
 * went from sixteen to seventeen. A preset is a blob of parameters, not a database.
 *
 * THE LAST FOUR ARE THE DEEP END, and they were asked for by name: "strange kits with deeper
 * and longer kicks". ABYSS is the floor of the voice — 35 Hz, the lowest centre it has — with a
 * gate that outlasts a bar; SLUDGE is the same idea slower and thicker; MONK is a ritual built
 * on metal instead of skin; VOID is a kick and the air around it, with the other three lanes
 * nearly switched off. They are placed after INDUS because the knob's travel is the list and
 * the list runs from dry to strange; the four are the strangest, so they are the end of it.
 */
#define PERC_KIT_COUNT 32
#define PERC_KIT_TIGHT 0
#define PERC_KIT_MINI 1
#define PERC_KIT_BROKEN 2
#define PERC_KIT_DUST 3
#define PERC_KIT_TAPE 4
#define PERC_KIT_DEEP 5
#define PERC_KIT_BRUSH 6
#define PERC_KIT_MACHINE 7
#define PERC_KIT_EIGHT 8
#define PERC_KIT_NINE 9
#define PERC_KIT_ROOM 10
#define PERC_KIT_LOFI 11
#define PERC_KIT_TRAP 12
#define PERC_KIT_CLUB 13
#define PERC_KIT_JAZZ 14
#define PERC_KIT_STEEL 15
#define PERC_KIT_GLASS 16
#define PERC_KIT_BOX 17
#define PERC_KIT_NEON 18
#define PERC_KIT_SUB 19
#define PERC_KIT_WOOD 20
#define PERC_KIT_GRIME 21
#define PERC_KIT_TIN 22
#define PERC_KIT_INDUS 23
#define PERC_KIT_ABYSS 24
#define PERC_KIT_SLUDGE 25
#define PERC_KIT_MONK 26
#define PERC_KIT_VOID 27

/* THE GROOVE LIST, in the order the knob moves through it. Every entry is one bar of
 * sixteens; see the table in synth_app.cpp for what each one plays. The dance floor comes
 * before the rest on purpose — HOUSE, TECHNO and CLUB are the three the instrument is
 * asked for first — and every name is the short one the readout prints, so the list on the
 * screen and the list here are the same words.
 *
 * THE LAST SEVEN ARE THE IDM END, asked for as "strange grooves, like for IDM": the kick
 * stutters across the bar, the snare doubles itself, the hats sit off the grid, the time
 * splits and the machine sounds like it is being repaired while it plays. They are appended
 * after CLUB so the seventeen the instrument had keep their places, and they are the last
 * seven for the same reason the deep kits are the last four: the travel is the list. */
#define PERC_GROOVE_COUNT 32
#define PERC_GROOVE_MINIPOP 0
#define PERC_GROOVE_DISCO 1
#define PERC_GROOVE_BOOGIE 2
#define PERC_GROOVE_ROCK 3
#define PERC_GROOVE_FUNK 4
#define PERC_GROOVE_BREAK 5
#define PERC_GROOVE_HOUSE 6
#define PERC_GROOVE_TECHNO 7
#define PERC_GROOVE_TRAP 8
#define PERC_GROOVE_HALF 9
#define PERC_GROOVE_TWOSTEP 10
#define PERC_GROOVE_AFRO 11
#define PERC_GROOVE_LATIN 12
#define PERC_GROOVE_MARCH 13
#define PERC_GROOVE_BOSSA 14
#define PERC_GROOVE_GARAGE 15
#define PERC_GROOVE_CLUB 16
#define PERC_GROOVE_SKIP 17
#define PERC_GROOVE_STUT 18
#define PERC_GROOVE_GRIT 19
#define PERC_GROOVE_WOBBLE 20
#define PERC_GROOVE_SPLIT 21
#define PERC_GROOVE_RUST 22
#define PERC_GROOVE_DRILL 23

/* The speeds the drum's clock may take, in the order of the knob's positions. Only ratios of
 * two: the drum has to stay on the bar, and any other ratio drifts against it. */
#define PERC_SPEED_COUNT 7

/*
 * WHAT PLAYS ON ONE STEP OF THE DRUM'S BAR, for the ring of dots on PERC SEQ.
 *
 * The mask is asked of the app rather than recomputed by the display, for the reason the
 * accent is: what plays is a decision the engine makes — the variation moves parts of it,
 * the fill replaces the second half, the open hat closes the cycle — and a ring that worked
 * it out again could draw a bar the drum is not playing. One bit per lane, in the lane order
 * the engine uses, plus the two things a lane cannot say: a ghost note, which is a quiet hat
 * between the written ones, and the fill, which is the snare running down the bar.
 */
#define SYNTH_APP_PERC_STEP_KICK  0x01
#define SYNTH_APP_PERC_STEP_SNARE 0x02
#define SYNTH_APP_PERC_STEP_HAT   0x04
#define SYNTH_APP_PERC_STEP_TOM   0x08
#define SYNTH_APP_PERC_STEP_GHOST 0x10
#define SYNTH_APP_PERC_STEP_FILL  0x20

typedef struct {
    float    cpu_load;          /* engine DSP load, 0..100 %, as the engine measures it */
    uint32_t blocks;            /* audio blocks rendered since boot */
    uint32_t deadline_misses;   /* blocks whose DSP work took longer than one block */
    uint32_t write_errors;      /* failed bsp_audio_out_write() calls */
    uint32_t dsp_us_last;       /* engine + FX + rack, last block, microseconds */
    uint32_t dsp_us_max;        /* worst block of the last stats interval */
    uint32_t block_budget_us;   /* wall time one block represents at 48 kHz */
    uint32_t heap_internal_free;

    /* The control surface's values as the audio task sees them, 0..1, indexed by
     * synth_param_t. Reported so a UI can show what is actually in force rather
     * than what it last wrote. */
    float    param[SYNTH_PARAM_COUNT];
} synth_app_stats_t;

/*
 * Starts the instrument. Requires bsp_init() to have brought the audio output
 * up. Everything that touches the engine happens before the audio task is
 * created, because the engine has no locking of any kind.
 */
void synth_app_start(void);
void synth_app_autoplay_apply(void);   /* ON / OFF / STORE из настроек */

void synth_app_get_stats(synth_app_stats_t *out);

/* -------------------------------------------------------------------------- */
/* Control surface: the accessors                                             */
/* -------------------------------------------------------------------------- */
/*
 * These are plain data, not engine calls.
 *
 * The engine has no locking of any kind — no critical sections, no atomics, not
 * even volatile on the voice array — so nothing outside the audio task may touch
 * it. A UI handler runs on the LVGL task and would be racing the renderer on
 * every write. The setters here therefore only store a value; the audio task,
 * which owns the engine, picks changes up between blocks.
 *
 * Safe to call from any task. Values are clamped to 0..1, and every parameter is
 * defined so that its DEFAULT reproduces the tuned voicing exactly — turning a
 * knob moves the sound away from what was designed rather than being part of
 * reaching it.
 */
void  synth_app_set_param(synth_param_t param, float v01);
float synth_app_get_param(synth_param_t param);

/*
 * The parameter slide.
 *
 * A preset load and a draw are BATCHES of new values, and a batch that lands at once is a
 * discontinuity in every one of them: the sound is not changed, it is replaced. So the
 * control surface marks the batch with synth_app_slide_begin() and the values that follow
 * are travelled to over the configured time instead — the audio task snapshots where it is
 * and ramps every parameter that is not a list entry or a setting.
 *
 * Safe to call from any task, at any moment, including with no slide configured: then the
 * batch arrives at once, exactly as it always did.
 */
void synth_app_slide_begin(void);
float synth_app_slide_ms(void);        /* what the SLIDE setting resolved to; 0 = at once */


/* The duration, as an index into the table the readout prints: off, 0.2, 0.5, 1.5, 3 s. */
void synth_app_slide_set_index(int index);

/*
 * The whole sound at once, for saving it.
 *
 * Reads `count` parameters starting at LEVEL into `out`; reads no further than
 * SYNTH_PARAM_PATCH_COUNT, because a setting is not part of the sound.
 */
void  synth_app_get_params(float *out, int count);
float synth_app_param_default(synth_param_t param);

/* Эффект-машина: имя того, что стоит сейчас (для ручки TYPE), и подписи её параметров. */
const char *synth_app_fx_name(void);
const char *synth_app_fx_slot_label(int slot);
int synth_app_fx_slot_used(int slot);

/*
 * The parameter's current value rendered for display: "300 Hz", "Q 0.70",
 * "0.050 Hz", "1.00 oct", "70%".
 *
 * This lives here rather than in the UI because the mapping from a 0..1 knob to
 * an engine value is defined here, and a display that recomputed it would drift
 * out of step with the sound the first time a range changed.
 *
 * The figures are the LOW register's. It is the register the ear judges the
 * drone by, and the other two follow at their own designed values — one knob
 * cannot show three numbers honestly, so it shows the one that matters and the
 * UI says which.
 */
void synth_app_param_text(synth_param_t param, char *buf, size_t len);

/*
 * The tempo the instrument is ACTUALLY playing at, 0..1, for the display.
 *
 * The transport's readout is the one caller. It exists because the tempo can come from the
 * MIDI clock rather than from the parameter, and the state behind that is the audio task's:
 * the UI may not read it, so the audio task publishes a snapshot instead — the answer the
 * readout needs, in the parameter's own 0..1, plus whether a clock produced it.
 * When no clock is driving the instrument this is the parameter's value.
 *
 * THE SNAPSHOT IS READ ONLY. A caller must never write it back into
 * SYNTH_PARAM_SEQ_TEMPO: the parameter is what the wheel points at and what a preset
 * stores, and a wire's tempo left in it would go into every preset saved afterwards.
 *
 * `from_clock` may be NULL.
 */
float synth_app_tempo_now(int *from_clock);

/* That same tempo as its display line ("120 BPM"), in the format the parameter's own
 * readout uses, so the transport cannot word the tempo differently from the knob's page. */
void synth_app_tempo_text(char *buf, size_t len);

/*
 * How many discrete positions a parameter has, or 0 if it is continuous.
 *
 * This lives here, beside the mapping, for the same reason param_text() does:
 * the number of positions IS part of the mapping from a knob to an engine value.
 * A UI that kept its own count would drift the moment a range changed, and the
 * symptom would be a control that needs a hundred clicks to move one entry.
 */
/* THE ACCENT FIGURE, asked the way the picture needs it: does figure `accent` mark step
 * `step` (0-based) of a figure of `n` steps? The preview draws sixteen cells and asks this
 * per cell, so the picture cannot disagree with what the engine marks — the modulo rule,
 * the bit order and the masks all live in accent_marks_step() and nowhere else. */
bool synth_app_accent_marks(int accent, uint32_t step, int n);

/* Whether the steps the figure does not mark will sound at all. WEAK VEL at zero means
 * they do not, and the preview draws them as rings: a step that will not sound is not the
 * same thing as a quiet one, and the picture is the only place that difference is visible. */
bool synth_app_weak_hits_are_off(void);

int synth_app_param_steps(synth_param_t param);

/* The number of steps in that part's bar, as opposed to the count of values the knob has:
 * the drum is always sixteen, the sequencer is four to sixteen. The accent picture needs this
 * one. See synth_app_bar_steps(). */
int synth_app_bar_steps(synth_param_t steps_param);

/*
 * THE WRITTEN PATTERN BEHIND A GROOVE, for the picture on its sector. Bit i of out[lane] is
 * position i of the bar; the lanes are in the order KICK, SNARE, HAT, TOM, and *ghost is the
 * quiet hat that fills the places the hat itself leaves empty. An index outside the list
 * writes zeros: an empty bar is an honest thing to draw, the nearest pattern is not.
 */
void synth_app_groove_pattern(int index, uint16_t out[4], uint16_t *ghost);

/*
 * What the sequencer is doing right now, for the display.
 *
 * Filled in one place so the caller gets a consistent set rather than five
 * separate reads that could straddle a step boundary. The sequencer runs in the
 * audio task and the caller in the UI task, so a straddle is possible; the worst
 * it can do is show the previous step for one frame, which is invisible.
 */
typedef struct {
    int steps;      /* n: grid steps to the bar */
    int pulses;     /* k in force, after the saturation */
    int rotate;     /* rotation in force */
    int position;   /* the grid step playing now, 0..steps-1 */
    int sounding;   /* a note is gated at this moment: 0 or 1 */
    /*
     * A signature of the FIGURE itself, for the part whose figure is a written pattern
     * rather than a euclidean pair: the bass's pattern number, accent mask and cycle
     * length in one number. Zero for the parts whose figure is already described by
     * steps/pulses/rotate above.
     *
     * Without it the ring and the LED ring had nothing to notice a new pattern by: PAT
     * moves the notes and leaves steps, position and accent alone, so the dots stayed on
     * the old figure until the transport happened to move.
     */
    int figure;
} synth_app_seq_view_t;

/*
 * Whether the arpeggiator has taken the lead's grid. This is a MODE and not a momentary
 * state — "off" is one of the arp's own speeds — so a caller may show it steadily, and a
 * page whose controls the arp has displaced can say so instead of looking broken.
 */
int synth_app_arp_active(void);

void synth_app_seq_view(synth_app_seq_view_t *out);

/*
 * Whether a given grid position is an onset.
 *
 * Asked rather than recomputed. The formula IS the sequencer's definition of the
 * rhythm, and a display that worked it out again could draw a pattern that is not
 * the one playing — which is worse than drawing nothing, because it would look
 * authoritative.
 */
int synth_app_seq_is_onset(int position);

/*
 * The same view of the drum part's own figure.
 *
 * Two calls rather than an argument to the ones above, because the two grids are
 * independent: the lead's can be taken over by the arpeggiator, and the percussion
 * plays its own whether or not anything else is running. A caller that asked for
 * "the sequencer" would have to know which one it meant anyway.
 */
void synth_app_perc_view(synth_app_seq_view_t *out);
/* Показание дорожки перкуссии для индикатора на экране, 0..1: что от неё слышно. */
float synth_app_perc_lane_level(int lane);int synth_app_perc_is_onset(int position);
int synth_app_perc_step_mask(int position);

/*
 * Whether a given grid step of a figure is one ACCENT strikes strong.
 *
 * A predicate rather than "the accented step", because the accent is a figure of its
 * own and a figure may hold several beats: the caller asks each step it draws, and a
 * rule that changes from one beat to a mask changes nothing at the call site. That
 * prediction was collected when the parameter became a list of eight figures — the
 * display did not move — and it held again when the same figure was drawn on the
 * lead's page as well: the two calls below are the same rule asked of two grids.
 *
 * False when the figure is OFF, and false when the position is outside the figure.
 *
 * TWO CALLS, one per figure, for the reason synth_app_perc_view() gives above. The
 * rules are the same and the n is not: the lead's is the latched one its figure is
 * playing — the arpeggiator can take that grid over mid-bar — and the drum's is its own
 * live STEPS. n is therefore not an argument: a caller with a position in hand already
 * knows which ring it is drawing, and it must not be able to pass the other part's n by
 * mistake.
 */
int synth_app_seq_is_accent(int position);
int synth_app_perc_is_accent(int position);

/*
 * The bass's figure, for the ring on RHYTHM. The same four questions the lead's and the drum's
 * figures answer, because the ring is the same ring: the engine answers, the page draws.
 */
void synth_app_bass_view(synth_app_seq_view_t *out);
int synth_app_bass_is_onset(int position);
int synth_app_bass_is_accent(int position);

/*
 * Presets: the sound, not a property of the board.
 *
 * The store itself lives in app_settings beside the patch, because that is where
 * NVS is handled. These two are the seam where the live parameters meet it — the
 * interface drives the list and asks the app to save or load, so the parameter
 * array never has to be copied into the UI, and the UI cannot disagree with what
 * is sounding.
 */
int synth_app_preset_save(int slot);   /* the slot written, or -1 */
int synth_app_preset_load(int slot);   /* how many parameters were set */
int synth_app_preset_delete(int slot); /* slots left in the store, or -1 */

/*
 * The fader law: travel 0..1 in, gain 0..1 out, square in between (see level_gain()).
 *
 * Exported because the screen has to answer one question with the same arithmetic the
 * engine uses — "is this part audible at all" for the ring's figure — and a second copy
 * of the law on the other side of the component boundary is exactly the kind of drift
 * this project keeps paying to remove.
 */
float synth_app_level_gain(float v01);

/* Значение LFO 0 или 1 с учётом его глубины: для индикации на ободе. */
float synth_app_lfo_viz(int ch, int which);

/* true, если у ручки шкала двусторонняя: заливка от середины дуги. */
bool synth_app_param_bipolar(synth_param_t p);   /* which: 0 — DEST, 1 — DEST2 */

/* Сколько глубины приходится на приёмник: 0 — обход фильтра, 1 — панорама. */
float synth_app_mod_depth_for(int what);

/*
 * The two random draws: a new colour of the same music, and a new piece of music.
 *
 * The draw lives here rather than in the interface because it needs the scales, the
 * drum's pitch range and the rule that maps a knob to a frequency — all of which the
 * app owns. `structural` is the long press: it also draws the key, the figures and
 * the arpeggio. `draw_delay_time` is RND DEL: with it off, neither half of the delay's
 * time section moves, because both of them are heard as rhythm rather than colour.
 *
 * Returns how many parameters were written. Every write goes through
 * synth_app_set_param(), so a draw arrives exactly as a preset does — including the
 * slide, if one is configured, and the drum's snap to the key.
 */
int synth_app_random_draw(int structural, int draw_delay_time);

/*
 * Applies a stored sound: the same loop a preset load does, and the place the record's own
 * age is read.
 *
 * `count` is how many values the record carried, and it is what says WHICH list it was
 * written against. A full record needs nothing: every position means what it means today.
 * A record that ends at or before the drum's RESET was written before two things moved
 * under it, and both are repaired here rather than in either loader, because a sound
 * arrives through two doors — a preset from the list, and the remembered patch at boot,
 * which components/synth_ui/src/synth_ui.c restores itself:
 *
 *   ROOT   the knob's range widened from A2..A4 to C1..C8, so the same normalised value
 *          names a different note. The old note is recovered through the OLD range and
 *          written back through the new one, which is what keeps an old sound in its key
 *          instead of transposing it by as much as a tritone.
 *   the three shapes and FOLLOW   the record has no bytes for them. The shapes take the
 *          old DRONE_WAVE byte's value, so the timbre is the one that was saved; FOLLOW
 *          takes its factory SCALE rather than the live value.
 *   the two key trackers   appended after FOLLOW, so a record written before them simply
 *          does not carry them and they keep their factory zero — no tracking, the sound
 *          the record was saved with.
 *
 * A record that DOES carry FOLLOW may have written it against the old four-position list
 * (STAY, SCALE, FULL, CONS). Its byte is remapped here — 0 and 1 to SCALE, 2 to FULL, 3 to
 * CONS, anything else to SCALE — because the position it holds now means a different mode:
 * the list is SCALE, CONS, FULL, so a raw position would put an old FULL on CONS.
 * The record's length is what tells the two apart: this firmware's patch is 90 parameters,
 * and a record at or below the old 88 is the one that needs the map.
 *
 * A record written by this firmware carries all of it and takes the plain path. Nothing here
 * rewrites the flash: the repair happens on the way in, so it is idempotent and costs a
 * fresh record nothing.
 */
void synth_app_patch_apply(const float *values, int count);

/*
 * Put every patch parameter back to its factory value — the sound the instrument ships with,
 * not a stored one — and return how many values were applied.
 *
 * This is what the preset page's INIT row loads. It goes through patch_apply(), so it slides
 * rather than jumps and it carries the tempo with the rest of the patch; the settings
 * (brightness, ring mode, microphone, the options) are not patch parameters and are left
 * exactly where the player put them.
 */
int synth_app_patch_factory(void);

/*
 * Play and stop.
 *
 * This is the rack's INPUT GATED, not a separate mute: the stored level is left
 * alone, so starting again returns the exact volume that was set rather than a
 * default. The generators deliberately keep their clocks underneath it — a drone
 * instrument that fell silent should come back into the phrase, not restart it —
 * but they open no notes while it is stopped, which is what "stop" means here: the
 * sequencer plays nothing and the drum strikes nothing until it is started again.
 *
 * NOTES FROM THE MIDI INPUT ARE NOT STOPPED BY IT. A note the player is holding, and
 * the tail of one that has just been released or struck, keeps the output open
 * whatever the transport says: the instrument is the player's, and this is the
 * transport. See the MIDI section below.
 *
 * IT IS NOT ONLY THE BUTTON'S ANY MORE. A host's START, CONTINUE and STOP arrive through
 * the MIDI ring and reach this same call on the audio task, so the wire's transport and
 * the panel's are one piece of state and one pair of rules — and the arpeggiator over keys
 * the player is holding keeps sounding at STOP, from either of them, because that is what
 * the rule above says.
 */
void synth_app_set_running(int on);
int synth_app_is_running(void);

/* Сколько долей клока прошло с начала транспорта. Для режима кольца TEMPO. */
uint32_t synth_app_beat_count(void);

/*
 * ПУСК С ПЕРВОГО ШАГА — то, что делает кнопка стоп-плей на панели.
 *
 * START с провода всегда начинал фразу с начала, а кнопка на панели только снимала флаг
 * остановки: прибор продолжал играть с того места, где его остановили, то есть с середины
 * такта — и лид, и ударка, и бас вступали не вместе, потому что останавливались они тоже в
 * разных местах. Владелец: «кнопка транспорта стоп-плей должна перезапускать все секвенции
 * в приборе с начала».
 *
 * Требование только ставится здесь и снимается на задаче звука в начале блока, перед
 * seq_tick(): позиция транспорта и все три счётчика шагов — её, и трогать их имеет право
 * только тот, кто владеет движком. Сброс тот же, что у START: midi_transport_reset().
 */
void synth_app_transport_restart(void);

/* -------------------------------------------------------------------------- */
/* Notes from outside: USB MIDI                                               */
/* -------------------------------------------------------------------------- */
/*
 * A note played on a computer has to reach the instrument, and the instrument belongs
 * to the audio task: the engine has no locking of any kind, so that task is the only
 * thing that may call the engine's note functions. A MIDI read task calling them
 * itself would be a plain data race on every voice it touched, which is exactly
 * the failure the whole design of this file exists to avoid.
 *
 * These two functions therefore do ONE thing: they place an event in a ring and
 * return. They do not touch the engine, a voice or a parameter; they never
 * block and they never allocate; and a caller may be a task, a callback or an
 * interrupt without any of them having to know which.
 *
 * WHICH PART A NOTE BELONGS TO is an argument and not a setting: the MIDI input
 * splits its traffic by channel — channel 1 (the status byte's low nibble 0) is the
 * lead, channel 2 (nibble 1) is the percussion — and it has already decided by the
 * time it gets here. A part is part of the MESSAGE and not part of the patch: the
 * same note on two channels is two different players.
 *
 * The ring is single-producer/single-consumer, and that is the whole of its
 * synchronisation:
 *
 *   - the producer is the MIDI read task in components/midi, and it must remain
 *     the ONLY caller of these two functions: two producers would need a real
 *     lock, which is the one thing this path may not have;
 *   - the consumer is the audio task, which drains the ring between blocks and
 *     before the sequencer's own step of that block, so a note that arrives in
 *     time to be heard this block also takes the lead before anything else can;
 *   - head and tail are 32-bit atomics with release/acquire ordering, which is
 *     what makes a note written on one core visible to the other. Nothing else
 *     in this path synchronises anything at all.
 *
 * A FULL RING DROPS THE NEW EVENT rather than waiting. The audio task drains
 * sixty-four events in the time of one block, so a full ring does not mean "a
 * fast player", it means the consumer has stopped — and blocking a MIDI task on
 * that would still not make the note sound. Drops are counted, and the first
 * one is logged by the producer.
 *
 * WHILE AN EXTERNAL LEAD NOTE IS HELD, THE LEAD BELONGS TO IT. The sequencer and the
 * arpeggiator keep their own clocks — their place in the bar does not slip
 * while someone plays, and they are not restarted when the player stops — but
 * they do not OPEN a note on the lead. Let go and the next onset is theirs
 * again. Up to three notes sound at once, each with the lead's whole timbre; a
 * fourth key steals the group of the note that has been held longest, and a
 * note-off releases its own group and no other.
 *
 * AND THE DRONE MOVES WITH IT. While a lead note is held the drone's registers are
 * transposed onto the newest of them — the last key pressed that is still sounding —
 * by an interval measured from the ROOT knob, so the drone is always consonant with
 * what is being played; when no lead note is held it returns to the knob. The shift
 * is smoothed, never switched.
 *
 * WHILE ANY EXTERNAL NOTE IS SOUNDING, THE OUTPUT IS OPEN, transport or no transport:
 * the note and its release, and the drum and its decay, are the instrument's and not the
 * sequencer's — which is what STOP mutes, by never opening a note rather than by
 * closing the gate on one.
 */
typedef enum {
    SYNTH_MIDI_LEAD = 0,    /* channel 1: the lead, three notes at once */
    SYNTH_MIDI_PERC,        /* channel 2: the drum, one note is one hit */
} synth_midi_part_t;

void synth_app_midi_note_on(int note, float velocity, synth_midi_part_t part);
void synth_app_midi_note_off(int note, synth_midi_part_t part);

/*
 * The transport and the clock, on exactly the same terms and through the SAME ring: the
 * two calls below place an event and return, and the audio task is the only side that acts
 * on it. 0xFA and 0xFB are two messages and not one, because one of them means "from the
 * top" and the other does not, and a single "go" would have thrown that difference away.
 * A clock tick carries nothing at all: twenty-four of them make a beat, and what they mean
 * is measured on the other side of the ring — see the clock section in synth_app.cpp for
 * the window and for what happens when the wire stops.
 *
 * THE TEMPO IS DELIBERATELY NOT WRITTEN TO A PARAMETER, and that is why the measurement
 * lives in the engine rather than here: SYNTH_PARAM_SEQ_TEMPO is part of the patch, so a
 * tempo that arrived on a cable would go into every preset saved afterwards and leave the
 * knob pointing at a number the instrument is not playing. The knob keeps its value and
 * the screen keeps showing it; the generators read the clock's tempo while a clock is live
 * and are back on the knob about a second after it stops.
 */
typedef enum {
    SYNTH_MIDI_TRANSPORT_START = 0,   /* 0xFA: play, from the top of the phrase */
    SYNTH_MIDI_TRANSPORT_CONTINUE,    /* 0xFB: play, from where the phrase stands */
    SYNTH_MIDI_TRANSPORT_STOP,        /* 0xFC: stop; the generators open nothing */
} synth_midi_transport_t;

void synth_app_midi_clock(void);
void synth_app_midi_transport(synth_midi_transport_t what);

/*
 * Convenience wrappers over the three parameters the first cut of the UI used.
 * Kept because they read better than an enum at a call site that only ever
 * touches one parameter.
 */
void synth_app_set_level(float v01);
void synth_app_set_cutoff(float v01);
void synth_app_set_motion(float v01);

/*
 * SERVICE MODE: the unattended stress program.
 *
 * Started from app_main() only when CONFIG_OBOD_STRESS is set, and defined in
 * src/stress.c, which the component's CMakeLists does not put in the build
 * otherwise. The task runs below the audio and statistics tasks, changes
 * parameters through the same calls the control surface uses, and prints one
 * verdict line every ten seconds and at the end of each full pass. See
 * «Стресс на приборе» in docs/FRAMEWORK.md for what a pass does and what makes
 * it fail.
 */
#if CONFIG_OBOD_STRESS
void synth_app_stress_start(void);
#endif

#ifdef __cplusplus
}
#endif
