#include "synth_app.h"

#include "app_settings.h"
#include "synth_dsp.h"
#include "synth_stage_timing.h"

#include "ESP32Synth.h"

/*
 * ESP32Synth_Patches.hpp contains DSP_BiquadOsc, whose oscillator state lives in
 * cw[] and is read and written by type-punning that array through int64_t*. That
 * is undefined behaviour under strict aliasing, and GCC says so.
 *
 * We include the header only for AA_Saw/AA_Pulse and never call that patch, but
 * the diagnostic is raised while compiling its body regardless, so it has to be
 * silenced here. If a later phase wants DSP_BiquadOsc, fix the type-punning
 * (memcpy in and out of the int64_t) rather than trusting this pragma.
 */
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wstrict-aliasing"
#include "ESP32Synth_Patches.hpp"
#pragma GCC diagnostic pop

#include "bsp/bsp.h"

#include <inttypes.h>
#include <math.h>
#include <stdio.h>
#include <type_traits>

/* The MIDI ring below is the one thing in this file whose two ends run on
 * different cores, and an index that crosses a core boundary is what atomics
 * exist for: see the note over synth_app_midi_note_on(). Nothing else in the
 * engine is atomic, and that is not an oversight — everything else is one task's
 * own state. */
#include <atomic>
#include <esp_random.h>

#include "esp_attr.h"
#include "esp_heap_caps.h"
#include "esp_log.h"
#include "esp_rom_sys.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

static const char *TAG = "synth";

/* -------------------------------------------------------------------------- */
/* Layout                                                                     */
/* -------------------------------------------------------------------------- */
/*
 * Voice allocation. The engine's noteOn() takes an explicit voice index and it
 * has no allocator of its own, so the map is entirely ours. Voices are grouped
 * by layer, and every layer owns one engine bus.
 *
 *   voices 0..8   drone LOW/MID/HIGH    buses 1..3
 *   voices 9..20  lead, four groups     bus 4
 *   voices 21..23 the arp's own group   bus 4
 *
 * The layout used to leave 21..23 unassigned, and the lead held three notes. The fourth
 * group is what the owner asked for — a long attack or a long release has to be able to
 * sound while the next note is already starting — and those three spare voices are
 * exactly one group, so the fourth note costs no engine change and no parameter: the
 * allocator simply walks four groups instead of three. The reserve the old comment kept
 * for the drone is gone with them, deliberately: the drone's nine are still moved by
 * nothing but the drone's own table, and a fifth lead group would be the point at which
 * MAX_VOICES has to grow.
 *
 * Bus 0 is the engine's master and never runs FX — its mixdown loop starts at
 * bus 1 — so no layer can live there. Bus 5 is the AUX layer, wired and panned
 * but with no voices yet.
 *
 * THE LEAD'S NOTE IS THREE VOICES, and the lead holds four notes. One note is a
 * group — the two detuned oscillators and the sub the line was always voiced with
 * — and there are LEAD_GROUPS of them, so a four-note chord keeps the whole timbre
 * on every note instead of thinning it out. Twelve voices for the lead, plus the
 * arpeggiator's group, is fifteen: with the drone's nine that is exactly the engine's
 * twenty-four, and the three that used to be spare are the fourth note. The reason
 * for the fourth is the envelope: the filter's AR closes inside the note, so what
 * overlaps is the AMPLITUDE's attack and release, and a long one of either has to be
 * able to ring while the next note is already arriving. Nothing is allocated per
 * voice anywhere — a group is what a note takes and what a note-off gives back; see
 * lead_group_alloc().
 *
 * THE ARPEGGIATOR HAS A GROUP OF ITS OWN, and it is the twenty-second voice of the
 * twenty-one the count above accounts for. It exists for one sentence: while the
 * player HOLDS KEYS and the arp is on, the keys are the arp's figure and the arp takes
 * the lead — so its step has to sound where the player's key allocator can neither find
 * it nor steal from it, and where letting the arp go cannot take a key with it. One
 * source at a time on one lead, and this group is how the arp's step is that source:
 * see arp_tick() and arp_lead_tick().
 */
#define DRONE_REGISTERS           3
/*
 * ДВА, А НЕ ТРИ.
 *
 * Расстройка регистра была { -7, 0, +7 } центов: центральный голос не добавлял ширины, он
 * добавлял громкости в центр. Два крайних дают те же медленные биения и минус три голоса
 * движка — это 220 мкс блока, которых с барабаном не хватало.
 */
/*
 * ДВА ГОЛОСА НА РЕГИСТР: ЖЕРТВА ПОЛИФОНИЕЙ ДРОНА РАДИ БЛОКА.
 *
 * Расстройка была { -7, 0, +7 } центов: крайние дают медленные биения и ширину, а средний
 * добавлял громкости в центр, не добавляя движения. Владелец выбрал жертвовать дроном, а не
 * лидом, поэтому средний голос ушёл: та же ширина биений, минус три голоса движка.
 */
#define DRONE_VOICES_PER_REGISTER 2
#define DRONE_VOICE_BASE          0

#define LEAD_VOICE_BASE           6
/* Шины аккорда: 7, 8 и 9. Ноль — мастер, 1..6 — слои, дальше свободные. */
#define LEAD_CHORD_BUS0           7

#define LEAD_GROUP_VOICES         3      /* one note: two oscillators and the sub */
/*
 * ШЕСТЬ, А НЕ ЧЕТЫРЕ.
 *
 * Владелец: «проверь релиз у лида, кажется он короче чем 6 сек». Конверт честный — ручка
 * доходит до шести секунд, и движок считает спад от этого числа. Коротким его делали группы:
 * с четырьмя хвост пятой ноты отбирался следующей нотой, и шесть секунд оставались слышны
 * только у последней ноты фразы. Шесть групп дают хвосту место, а аккорду — не отбирать
 * группу у предыдущего аккорда сразу.
 */
/*
 * ПЯТЬ, А НЕ ШЕСТЬ.
 *
 * Шесть групп дали хвосту место, но и цену: восемнадцать голосов в блоке — это 1936 мкс
 * против 1140 при двенадцати, и вместе с ударными блок уходил за дедлайн (владелец слышал
 * это как постоянный треск). Пять групп оставляют хвост длинным и возвращают три голоса.
 */
/*
 * ЧЕТЫРЕ. Блок обязан влезать: с пятью группами средний блок был 4.8 мс при бюджете 5.33, и
 * удары барабана его переваливали (5.7-6.0 мс, серии опозданий). Четыре группы — это три
 * голоса назад; хвост отпускания при этом всё равно слышен на паузах и медленных линиях.
 */
#define LEAD_GROUPS               4      /* notes the lead can sound at once */
#define LEAD_VOICES               (LEAD_GROUP_VOICES * LEAD_GROUPS)

/* The arpeggiator's own group, one past the player's four.
 *
 * It is CONFIGURED exactly like a lead group — same wave, same envelope, same bus —
 * and it is ALLOCATED by nobody: the player's key allocator walks the four groups
 * above, so it can neither find this one nor steal from it. That one index is the
 * whole of how an arpeggio over held keys and the keys themselves sound at once, and
 * why neither can ever open a voice the other owns.
 *
 * It is now the LAST group the engine has: voices 21..23, the three that used to be
 * spare and are the fourth player group's, and no voice beyond them. A fifth group
 * would have to grow MAX_VOICES; see the layout comment at the top. */
#define LEAD_ARP_GROUP            LEAD_GROUPS
#define LEAD_GROUP_COUNT          (LEAD_GROUPS + 1)
#define LEAD_CONFIGURED_VOICES    (LEAD_GROUP_VOICES * LEAD_GROUP_COUNT)

/* Drone envelope: a long swell, held forever, released slowly. Sustain is full
 * because a drone is by definition always sustaining. */
#define DRONE_ATTACK_MS           2500
#define DRONE_DECAY_MS            1500
#define DRONE_SUSTAIN             255
#define DRONE_RELEASE_MS          5000

#define AUDIO_TASK_CORE           1
#define AUDIO_TASK_PRIO           18
#define AUDIO_TASK_STACK          8192

#define STATS_TASK_CORE           0
#define STATS_TASK_PRIO           3
#define STATS_TASK_STACK          3072
#define STATS_PERIOD_MS           1000

/* 500 Hz, not the engine's 100 Hz default: the engine's own vibrato, tremolo
 * and glide are zero-order-held on this grid, and 10 ms steps are audible on a
 * slow pitch drift. Our own LFOs do not depend on it (they run per block in the
 * bus FX), but the engine's do. */
#define CONTROL_RATE_HZ           500

/* -------------------------------------------------------------------------- */
/* State                                                                      */
/* -------------------------------------------------------------------------- */

/* One instance, static: the object is ~9.5 KB with our config, and putting it
 * in .bss avoids both the heap and any fragmentation. */
static ESP32Synth s_synth;

/* The engine's mono output. We capture the layers through bus FX instead, so
 * this buffer exists only because generateSamples() insists on writing
 * somewhere. */
static int16_t s_engine_mono[SYNTH_BLOCK_SAMPLES];
static int16_t s_stereo_out[SYNTH_BLOCK_SAMPLES * 2];

static volatile float    s_cpu_load;
static volatile uint32_t s_blocks;
static volatile uint32_t s_deadline_misses;

/*
 * Самая длинная серия опоздавших блоков подряд. Одиночное опоздание очередь звука (двенадцать
 * дескрипторов по 5 мс) поглощает без следа; слышно становится только тогда, когда серия
 * длиннее очереди. Печатается рядом с `miss`, чтобы это различие было видно из лога.
 */
/*
 * СКАЧОК ВЫХОДА: ОТДЕЛЬНО ОТ ПРОПУСКОВ.
 *
 * Треск — это либо опоздавший блок (счётчик miss у нас есть), либо РАЗРЫВ в самом сигнале,
 * которого до сих пор никто не видел. Здесь считается самый большой перепад между соседними
 * сэмплами одного канала за блок, и отдельно — те скачки, что случились вскоре после
 * применения патча: если треск приходит от загрузки пресета, это будет видно числом.
 */
#define JUMP_WINDOW_BLOCKS 32
#define JUMP_THRESHOLD     4915      /* 0,15 полной шкалы: для непрерывного сигнала невозможно */

static volatile uint32_t s_jump_events;      /* скачков вне окна патча */
static volatile uint32_t s_jump_in_patch;    /* скачков внутри окна */
static volatile uint32_t s_jump_max_q;       /* самый большой перепад, в тысячных */
static volatile uint32_t s_patch_gen;        /* сколько раз применяли патч */
static uint32_t s_patch_gen_seen;
static uint32_t s_patch_window;

static volatile uint32_t s_miss_run;
static volatile uint32_t s_miss_run_max;
static volatile uint32_t s_gap_us_max;
static volatile uint32_t s_gap_bad;
static volatile uint32_t s_gap_last;
static volatile uint32_t s_write_errors;
static volatile int      s_write_last_err;      /* esp_err_t of the last failed write */
static volatile int      s_write_last_bytes;    /* bytes queued by that write */
static volatile uint32_t s_dsp_us_last;
/* The worst block of the interval the statistics task last looked at, not of the boot: it is
 * put back to the last block's own time wherever the stats line is printed, so the number it
 * shows describes the ten seconds that line covers instead of a peak the instrument may have
 * left behind hours ago. */
static volatile uint32_t s_dsp_us_max;

/* ОТЛАДКА: средняя длительность блока за окно статистики. */
static volatile uint64_t s_dsp_us_sum;
static volatile uint32_t s_dsp_us_n;

/*
 * THE OVERLOAD RECORD.
 *
 * A block that runs past its budget is the one fault that cannot be found by listening,
 * because the sound says only that something happened and never what. Eight records, written
 * by the audio task and read by the statistics task a second later, so the report costs the
 * audio task a store and never a UART write. Each record says how long the block took, how
 * many drum voices were ringing inside it and which block it was: if the drum is the reason,
 * the voice count is high, and if the reason is elsewhere it is zero.
 */
typedef struct {
    uint32_t block;
    uint32_t us;
    int16_t  voices;
    int16_t  spare;
} overload_rec_t;

#define OVERLOAD_SLOTS 8

static overload_rec_t s_overload[OVERLOAD_SLOTS];
static volatile uint32_t s_overload_w;      /* where the audio task writes next */
static uint32_t s_overload_seen;            /* how far the statistics task has read */

/*
 * THE JUMP RECORD, for the crackle that is heard but never caught.
 *
 * A click is a step in the waveform, and the loudest one of a block shows up as the block's
 * peak jumping against the previous block's by more than four times. A drum onset does that
 * every time, so a record is only kept when no new drum voice started in the same block:
 * what is left is the sound doing something the drum did not ask for.
 */
typedef struct {
    uint32_t block;
    int32_t  peak;
    int32_t  from;
    int16_t  voices;
    int16_t  spare;
} jump_rec_t;

#define JUMP_SLOTS 8

static jump_rec_t s_jump[JUMP_SLOTS];
static volatile uint32_t s_jump_w;
static uint32_t s_jump_seen;
static int32_t s_peak_prev;
static int16_t s_voices_prev;

/* -------------------------------------------------------------------------- */
/* MIC PROBE — RETIRED                                                        */
/* -------------------------------------------------------------------------- */
/*
 * The liveness check for the PDM microphone: one engine block per audio block,
 * keeping the peak, the RMS and the DC of what came back, printed once a second.
 * It measured what the microphone actually delivers on this board — 48000 samples
 * a second with no errors, a DC offset of about 1081 counts against a room signal of
 * about 46 RMS, and a peak of about 4840 on a hand clap — and that measurement is why
 * the sensitivity range, the DC blocker and the envelope's full-scale reference are
 * the numbers they are in mic_process_block() below.
 *
 * MIC_TEST_ENABLE IS 0. The microphone is a feature now, it is read by
 * mic_process_block() in the audio task and published to the AUX bus, and this probe
 * must not read the driver alongside it: two readers of one I2S channel split the
 * stream between them. The code below is kept compiled out as the record of the test
 * that was run; delete every block marked MIC PROBE if that record is not wanted.
 */
#define MIC_TEST_ENABLE 0

#if MIC_TEST_ENABLE
/* One engine block of 16-bit samples: the read size is exactly that. */
static int16_t s_mic_buf[SYNTH_BLOCK_SAMPLES];

/* One window is one second of audio: 187.5 blocks of 256 samples at 48 kHz. It is
 * counted in read attempts, not in samples, so a dead channel still closes a
 * window and still prints n=0 once a second instead of going quiet. */
#define MIC_TEST_WINDOW_BLOCKS ((int)(SYNTH_SAMPLE_RATE / SYNTH_BLOCK_SAMPLES))

/* The window, touched by the audio task only. */
static uint32_t s_mic_peak;    /* largest |sample| seen this window */
static uint64_t s_mic_sumsq;   /* sum of squares, for the RMS */
static int64_t  s_mic_sum;     /* signed sum, for the DC */
static uint32_t s_mic_n;       /* samples actually read this window */
static uint32_t s_mic_blocks;  /* read attempts this window */
static uint32_t s_mic_errs;    /* attempts that returned nothing at all */
static int      s_mic_last_err;

/* The finished window, as 32-bit fields the stats task can read: the audio task
 * publishes them and bumps the serial last, so a line is never half updated. */
static volatile uint32_t s_mic_out_serial;
static volatile uint32_t s_mic_out_peak;
static volatile uint32_t s_mic_out_rms;
static volatile int32_t  s_mic_out_dc;
static volatile uint32_t s_mic_out_n;
static volatile uint32_t s_mic_out_errs;
static volatile int      s_mic_out_last_err;
static uint32_t          s_mic_seen_serial;

/* Floor of the square root, integer only: the probe stays off the FPU. */
static uint32_t mic_isqrt(uint64_t v)
{
    uint64_t rem  = 0;
    uint64_t root = 0;
    for (int i = 31; i >= 0; i--) {
        root <<= 1;
        rem = (rem << 2) | ((v >> (2 * i)) & 3u);
        if (root < rem) {
            rem -= root + 1u;
            root += 2u;
        }
    }
    return (uint32_t)(root >> 1);
}
#endif /* MIC_TEST_ENABLE */

/*
 * SEQ TRACE — a service switch, not a feature. 0 is the normal build: the lines
 * below compile to nothing. Set it to 1, build and flash once, and every hit and
 * every RESET gesture lands in the log with the audio block it happened in:
 *
 *   seq: P block=12345 n=16 step=7
 *   seq: L block=12346 step=8
 *   seq: R block=12500 bar=3 n=16
 *   seq: P RESET block=12600 bar=3 n=16
 *
 * P/L are the percussion and lead onsets, R is the lead's RESET gesture with the bar the
 * transport had reached before its phrase went back to the first step, and P RESET is the
 * drum's — the same line with the drum's own length and bar. step is the figure's index
 * (take it modulo the figure's length for the position in the bar; the drum's cursor may be
 * on another step of its phrase after its gesture, see synth_app_perc_view()). The block
 * counter starts at zero on boot and is one audio block (5.33 ms at 48 kHz/256) per tick, so
 * two hits eight blocks apart are the flam the ear hears.
 */
#define SEQ_TRACE_ENABLE 0
#if SEQ_TRACE_ENABLE
static uint32_t s_trace_block;
#define SEQ_TRACE(...) ESP_LOGI(TAG, __VA_ARGS__)
#else
#define SEQ_TRACE(...) do { } while (0)
#endif

/* -------------------------------------------------------------------------- */
/* Control surface — the stored values                                        */
/* -------------------------------------------------------------------------- */
/*
 * Written by whatever task owns the UI and read by the audio task, which is the
 * only task allowed to touch the engine. Every value is an aligned 32-bit float,
 * so a reader can never observe a half-written one; nothing here needs a lock,
 * and the engine must not acquire one.
 *
 * s_applied[] is the audio task's own record of what the engine currently has.
 * Comparing against it means a knob move costs one pass over three registers
 * instead of that work on every block. It is filled in by synth_app_start(),
 * which runs before the audio task exists, and -1 there forces the first block
 * to apply every parameter.
 */
static volatile float s_param[SYNTH_PARAM_COUNT];

/* Тип эффект-машины: по нему зависят и подписи, и число положений ручек. */
static int fx_type(void);
static float          s_applied[SYNTH_PARAM_COUNT];

/*
 * THE SLIDE, and the state it needs.
 *
 * s_cur[] is what the engine actually has. Outside a slide it is a copy of s_param[]; during
 * one it is the travelling value. It lives in the audio task because the starting point of a
 * slide is whatever is sounding RIGHT NOW, and only this task knows that — which is also why
 * the request is a flag and not a filled-in table: a control task that wrote a from-array
 * would be writing this task's state while this task read it.
 *
 * A list entry and a setting are never slid. A mode is not a place between two modes, and a
 * setting is not part of the sound: those arrive at once, as they always did.
 */
static float s_cur[SYNTH_PARAM_COUNT];
static float s_from[SYNTH_PARAM_COUNT];

static volatile bool  s_slide_req;           /* a batch of new values has just been written */
static volatile bool  s_slide_taken = true;  /* the snapshot of that batch has been made */
static volatile float s_slide_ms = 500.0f;   /* how long it should take; 0 = arrive at once */
static float          s_slide_pos = 1.0f;    /* 0..1, 1 = nothing travelling */
static float          s_slide_step = 1.0f;   /* per block, from s_slide_ms */

/* Counts blocks, so a slide can write one block in SLIDE_APPLY_EVERY. Never reset: only the
 * remainder matters, and an unsigned wrap keeps it exact. */
static uint32_t       s_slide_tick;

/* The durations the SLIDE setting chooses between, and the index it stores. The first is
 * off, which is what the instrument did before there was a choice to make. */
static const uint16_t SLIDE_MS[] = { 0, 200, 500, 1500, 3000 };
#define SLIDE_COUNT ((int)(sizeof(SLIDE_MS) / sizeof(SLIDE_MS[0])))

/*
 * How often a parameter that is travelling over a slide is actually written to the engine:
 * one block in four, which is 94 times a second.
 *
 * A slide used to write on EVERY block, because the interpolated value differs on every
 * block and the guard below could not tell a change worth making from a change worth
 * skipping. At 375 blocks a second a three-second slide therefore applied each of its
 * parameters 1125 times, and the setters are not free: measured on this instrument, one
 * call of MOTION RATE costs about 44 us, CUTOFF 17, PERC PITCH 14 — a single preset
 * transition spent 90 to 150 milliseconds of the audio task on them, spread thin enough not
 * to be one stall but thick enough to hold every block of those three seconds closer to the
 * deadline. That is the crackle heard while the drawer is being used, and it is why switching
 * between two similar patches is silent: they differ in almost nothing, so almost nothing
 * travels.
 *
 * Four blocks is 10.7 ms, and the step it leaves in the parameter is far below what any of
 * these controls resolve: the knob itself arrives in detents coarser than that, and the
 * engine's own setters quantise several of these values to 12 bits or fewer. The position
 * still advances on every block — only the write is thinned — and the last block of a slide
 * always writes, so a parameter lands exactly on its target and never a step short of it.
 */
#define SLIDE_APPLY_EVERY 4u

/*
 * The microphone's control state, here rather than in the Microphone section below
 * because two of the appliers above that section — apply_lfo_shape() and
 * apply_reverb_send() — are what write it.
 *
 * s_mic_sens01 is SET_MIC as the audio task last applied it, which is what decides
 * whether the input is read at all: at zero, mic_process_block() returns before it
 * touches the driver. s_mic_env01 is the envelope that came out of the last block, and
 * s_mic_replace is whether the SHAPE knob is standing on MIC. Both are written and read
 * by the audio task only.
 */
static float s_mic_sens01;
static float s_mic_env01;
static bool  s_mic_replace;

/*
 * The driver's own multiplier as this application last set it, 1..15, and the mapping
 * from the knob's dB to it: 1 + dB/3, held at 15.
 *
 * The BSP's bsp_audio_in_set_gain() does exactly this arithmetic and this is a second
 * copy of it, which is normally how two things come apart — the reason it is here is that
 * a call to that function CANNOT BE MADE PER DETENT: it stops the PDM channel to write the
 * slot configuration. Comparing the multiplier first is what keeps a hundred detents
 * fourteen interruptions, and it needs the number rather than the dB.
 */
#define MIC_AMPLIFY_MIN     1
#define MIC_AMPLIFY_MAX     15
#define MIC_AMPLIFY_DB_STEP 3

/* 42 dB is the top of both mappings: 1 + 42/3 = 15. Asserted below. */
static int s_mic_gain_step = MIC_AMPLIFY_MIN;

/*
 * The software stage's factor, from MIC_SW_GAIN_MAX and the same 0..1 the knob holds,
 * written by apply_mic() and read once per block by mic_process_block(). It is a plain
 * float in the audio task's own state: no driver call, no channel restart, nothing to
 * synchronise. On this board it is the ONLY gain the input has — see the note on the
 * driver's own stage in the constants below — so every detent moves it, including the ones
 * that would have fallen inside one amplifier step.
 */
static float s_mic_sw_gain = 1.0f;

/*
 * Whether this chip has told us it cannot set the driver's gain at all.
 *
 * ESP_ERR_NOT_SUPPORTED is a fact about the target and not a fault — the PDM RX
 * high-pass/amplify stage exists on the P4 and the S31 and not on the S3 this board runs —
 * so the answer cannot change while the firmware is running, and asking again costs a
 * blocking warning line inside the audio task. Caching it turns fourteen calls across the
 * knob's travel into one. Every OTHER error is left un-cached on purpose: a channel that
 * is merely not ready yet, or a reconfiguration that failed once, is still retried at the
 * next detent.
 */
static bool s_mic_drv_gain_absent = false;

static int mic_amplify_for(uint8_t gain_db)
{
    int amp = MIC_AMPLIFY_MIN + (int)(gain_db / MIC_AMPLIFY_DB_STEP);
    if (amp > MIC_AMPLIFY_MAX) {
        amp = MIC_AMPLIFY_MAX;
    }
    return amp;
}

/* Hand the envelope and the replace flag to the DSP, where the drone filter and the pan
 * capture read them in this same block. Once per block, and once more whenever SHAPE or
 * the microphone's own setting moves. */
static void publish_mic_mod(void);

/*
 * The microphone's numbers, all in one place. They come from what the probe measured on
 * this board (see the retired probe at the top of the file):
 *
 *   MIC_GAIN_MAX_DB   the top of the sensitivity knob as the BSP wants it, 0..42 dB. It is
 *                     the BSP's number and not the hardware's: its mapping is
 *                     amplify_num = 1 + dB/3 held at 15, so 42 is what reaches the top of
 *                     the driver's 1..15 range, while the gain there is 15x = +23.5 dB,
 *                     because amplify_num is a straight multiplier of the PCM result and
 *                     not a decibel scale (IDF's own setter says so: "pcm_result =
 *                     pdm_input * amplify_num"). Three dB a step is true of the first step
 *                     only — 1->2 is +6.0 dB, 14->15 is +0.6 dB, +1.68 dB on average.
 *
 *                     ON THIS BOARD IT DOES NOTHING AT ALL, and that is checked rather
 *                     than assumed. `amplify_num` sits in the PDM RX high-pass/amplify
 *                     stage that only the P4 and the S31 have, so
 *                     SOC_I2S_SUPPORTS_PDM_RX_HP_FILTER is undefined for the S3, its
 *                     i2s_pdm_rx_slot_config_t has no such field, and the BSP compiles its
 *                     "this chip has no PDM RX amplify stage" branch, returning
 *                     ESP_ERR_NOT_SUPPORTED without touching the channel. Verified by
 *                     preprocessing bsp_audio.c with its own compile command for esp32s3:
 *                     the amplify path is not in the output at all. Which is why the knob
 *                     never changed the level, and why the software stage below is the
 *                     whole of the sensitivity rather than a stage on top of the driver's.
 *
 *   MIC_SW_GAIN_MAX   the software stage's gain at the top of the knob: 6x (+15.6 dB), and
 *                     with the driver stage dead it is the WHOLE of the sensitivity. The
 *                     numbers it is picked from are the probe's, at unity gain: the room
 *                     peaks at 1300 counts against a DC of 1081, so its useful peak after
 *                     the DC blocker is 220 counts and its useful RMS is 46; a hand clap
 *                     reaches 4840 against the same DC, so 3760 counts, 0.115 of full scale
 *                     — the loudest thing measured on this board.
 *
 *                       at the top of the knob, 6x        room      clap
 *                         peak, of full scale             0.040     0.688
 *                         RMS, of full scale             -41.5 dBFS   -
 *
 *                     6x leaves the loudest measured transient 3.2 dB under the ceiling and
 *                     lifts the room's RMS from -57 dBFS, where no send can be heard at
 *                     all, to -41.5 dBFS. It is the largest round value that keeps that
 *                     margin: 8.7x is where the clap itself touches full scale. There is no
 *                     analogue gain on this microphone to spend instead, and more than
 *                     about 8x would therefore trade the transient for the room, which is
 *                     not a trade this path can make — it has no limiter. It is applied
 *                     after the DC blocker, one multiply a sample, and it never touches the
 *                     PDM channel: no restart, no driver call, nothing to reconfigure.
 *
 *   MIC_HP_CORNER_HZ  the DC the PDM part sits on measured at about 1081 counts against
 *                     a room signal of about 46 RMS, so the offset is twenty times the
 *                     signal and has to go before anything else looks at it. One pole at
 *                     175 Hz: the voice is above it, the offset is at 0 Hz, and one
 *                     multiply-add a sample is the whole cost.
 *
 *   MIC_ENV_PEAK_REF  the peak, at the top of the sensitivity knob, that reads as a full
 *                     envelope: 0.15 of full scale. The envelope is normalised AFTER the
 *                     software gain, which is the same domain the old 0.35 was written for,
 *                     where the driver's gain came before the division. With the driver
 *                     stage dead the numbers are: a full envelope at 0.15 of full scale
 *                     after 6x, which is 819 counts at the input — 3.7x the room's own peak,
 *                     so a clap or a voice near the port rather than a room. The measured
 *                     room, 220 counts, reads 0.27 at the top of the knob: moving, and not
 *                     pinned by the room alone, which is the property the reference has to
 *                     keep. The old 0.35 asked for four times the peak the board can put out
 *                     at maximum sensitivity, so the envelope never left the bottom of its
 *                     range. If the room alone should swing it harder, 0.10 reads the room
 *                     at 0.40 and 0.08 at 0.50, at the price of a room that pins the
 *                     envelope whenever it is merely loud.
 *
 *   MIC_ENV_RELEASE_MS  instant attack, 150 ms release: the rate a room moves at, and
 *                     long enough that a single block of silence does not drop it.
 */
#define MIC_GAIN_MAX_DB     42.0f
#define MIC_SW_GAIN_MAX     6.0f
#define MIC_HP_CORNER_HZ    175.0f
#define MIC_ENV_PEAK_REF    0.15f
#define MIC_ENV_RELEASE_MS  150.0f

/*
 * The percussion's ring envelope: instant attack, 140 ms release.
 *
 * The drum's own gate can be 20 ms long — its DECAY knob goes there — and the ring is
 * drawn every third 40 ms frame, so one frame every 120 ms. A bare gate would therefore be
 * missed more often than seen, and the knob that sets it would decide whether the part has
 * a colour instead of how it sounds. The release is what makes a hit a flash.
 *
 * 140 ms is the layer telemetry's own figure (synth_pan_capture.cpp), taken rather than
 * invented so a drum hit glows on the ring for as long as a lead note does and the four
 * parts stay comparable. It is longer than the 120 ms between two ring frames, so the frame
 * drawn after a hit still finds the envelope at about 0.42 of its peak — thirty times the
 * 0.02 the ring needs to light at all — and no hit can fall between two of them; the same
 * figure is what keeps the flashes separate at a fast figure instead of merging into a
 * steady light. It shapes the DISPLAY only: the voice is freed by the module's own
 * PERC_TAIL and nothing here is in the sample path.
 */
#define PERC_ENV_RELEASE_MS 140.0f

/* The top of the sensitivity travel must reach the whole of the driver's range, and this
 * macro must be the number that gets there: if either mapping moves, this stops the build
 * instead of quietly leaving the knob unable to reach full gain. The multiplier's own
 * constants are beside the state above. */
static_assert((int)MIC_GAIN_MAX_DB / MIC_AMPLIFY_DB_STEP + MIC_AMPLIFY_MIN == MIC_AMPLIFY_MAX,
              "MIC_GAIN_MAX_DB must map onto the driver's top multiplier");

/*
 * The software stage as a function of the knob, and the shape of the travel it gives.
 *
 * MIC_SW_GAIN_MAX ^ sens: 1.0 at the bottom, 6.0 at the top, so the stage is a gain in
 * decibels — 15.6 * sens dB — and it is continuous at zero: one detent up is 0.3 dB whether
 * it happens at the bottom of the travel or the top. A linear 1 + 5 * sens would spend the
 * first half of the knob in 3 dB steps and the last tenth in 0.9 dB ones, which is the
 * opposite of what a sensitivity control is for. On this board it is the whole control, so
 * the travel has to be even across its length and not bunched at either end.
 *
 * At zero it returns unity rather than zero: nothing is read at all there (see
 * mic_process_block()), and unity is the value that says "this stage is not doing
 * anything", which is what the invariant tests want to see.
 *
 * THE CURVE IS A TABLE. powf() is a libm call, and this runs on the audio task
 * whenever the sensitivity moves — including every applied step of a preset slide,
 * where the previous build was caught inside it. The curve is smooth and monotonic,
 * so 257 samples of it with linear interpolation are enough: the second derivative
 * of 6^x is (ln 6)^2 * 6^x, so the relative error is at most (ln 6)^2 h^2 / 8,
 * which at h = 1/256 is 6.1e-6 — -104 dB, measured against powf over the whole
 * travel, and it is a gain error of 0.0002 dB: not a level the ear can hear.
 * mic_init() fills the table once, before the first block.
 */
#define MIC_SW_GAIN_LUT_STEPS 256

static float s_mic_sw_lut[MIC_SW_GAIN_LUT_STEPS + 1];

static void mic_sw_lut_build(void)
{
    for (int i = 0; i <= MIC_SW_GAIN_LUT_STEPS; i++) {
        s_mic_sw_lut[i] = powf(MIC_SW_GAIN_MAX, (float)i / (float)MIC_SW_GAIN_LUT_STEPS);
    }
}

static float mic_sw_gain_for(float sens01)
{
    if (sens01 <= 0.0f) {
        return 1.0f;
    }
    if (sens01 >= 1.0f) {
        return s_mic_sw_lut[MIC_SW_GAIN_LUT_STEPS];
    }

    const float x = sens01 * (float)MIC_SW_GAIN_LUT_STEPS;
    const int i = (int)x;
    const float f = x - (float)i;

    return s_mic_sw_lut[i] + (s_mic_sw_lut[i + 1] - s_mic_sw_lut[i]) * f;
}

/*
 * The SHAPE list: seven waveforms and, eighth, the microphone.
 *
 * MIC is the shape that is not a waveform. Choosing it says "the source is the
 * microphone's envelope, not the generator": mod_value() returns the envelope instead of
 * a point on the phase, and the DSP is told to replace its own LFOs with it. Nothing else
 * about the page changes — the DEPTH and SPEED knobs stay where they are and simply have
 * no say while the envelope is the source, because a room has no phase to speed up.
 *
 * Declared here rather than beside the generator below because apply_lfo_shape() is what
 * hands the code to the DSP, and that is written earlier in the file.
 */
#define LFO_SHAPE_COUNT 8
/*
 * СЛОТОВ ПЯТНАДЦАТЬ: ВОСЕМЬ СВОБОДНЫХ И СЕМЬ С ТРИГГЕРОМ.
 *
 * Слот — это положение ручки SHAPE. Свободные формы стоят первыми, с триггером — следом, и
 * отдельной ручки TRIG поэтому больше нет: режим читается из слота.
 */
#define LFO_SHAPE_SLOTS  (LFO_SHAPE_COUNT + (LFO_SHAPE_COUNT - 1))
#define LFO_SHAPE_MIC   7

/* The DSP has its own name for the same code, because it is what the filter's switch is
 * compared against. They are the same shape and must stay the same number. */
static_assert(LFO_SHAPE_MIC == SYNTH_LFO_SHAPE_MIC, "the MIC shape code must match the DSP's");

/* Output level when the control surface asks for full scale. The rack's own
 * headroom, not 1.0: the four layer levels already sum to about 1.0, so the
 * soft clipper should only ever catch a coincident peak. */
#define MASTER_AT_FULL_SCALE 0.9f

/* The cutoff knobs are bipolar around the designed value and span three octaves
 * either way. Three, not two: two was polite and the whole point of exposing the
 * filter is that its effect should be unmistakable. Above 16 kHz there is nothing
 * left to open.
 *
 * The floor is LOW's own bottom of travel — 300 x 2^-3 = 37.5 Hz — and not the 80 it
 * used to be. At 80 the last 18 percent of the travel was one number: LOW asked for less
 * than the clamp and was handed the clamp instead, so the bottom of the knob stopped
 * moving. MID (700 x 2^-3 = 87.5) and HIGH (1800 x 2^-3 = 225) never reached the old
 * floor and do not reach this one, so for both of them the floor is the backstop it was
 * always meant to be. 37.5 is also above the 20 Hz floor the filter itself holds
 * (synth_drone_filter.cpp, synth_fx_drone_filter), so nothing is clamped twice. */
#define DRONE_CUTOFF_MIN_HZ  37.5f
#define DRONE_CUTOFF_MAX_HZ  16000.0f
#define CUTOFF_MACRO_OCTAVES 3.0f

/* How far a rate knob reaches past the designed rate. Both are exponential so
 * that a knob step is an equal musical step, and both are chosen so the top of
 * the range leaves the geological and becomes plainly audible:
 *
 *   filter LFO   50 mHz (20 s) -> 6.000 Hz   120x
 *   pan drift    31 mHz (32 s) -> 6.000 Hz 193.5x, with the random walk 8x faster
 *
 * The two spans are not the same number even though both knobs end at 6.000 Hz on LOW:
 * the filter starts from 50 mHz, the drift from 31. So one multiplies by 120 and the
 * other by 6000/31 = 193.5484, and the constants below are log2 of those two: 6.9068906
 * for the filter, 7.5965505 for the drift — neither is a round power of two, because the
 * number that has to be exact is the one at the TOP of the travel, the 6.000 Hz on LOW
 * that the display prints. One knob drives all three registers, so the same factor puts
 * the filter's MID at 8.400 Hz and HIGH at 4.800 Hz, and the drift's first LFO — the one
 * the SPEED readout prints — at MID 7.161 Hz and HIGH 5.613 Hz: the three designed rates
 * stay in their designed ratio, and it is still one knob and one number on the screen.
 *
 * At v01 = 0 the factor is exactly one, so the factory rates are untouched: 50/70/40 mHz
 * for the filter, 31/47, 37/53 and 29/61 mHz for the drift's two LFOs. Each literal is the
 * float nearest its log2 and is written to that precision deliberately: 6.9069f happens to
 * print 6.000 Hz too, but a coarser 7.0f lands on 6.400 Hz; and 7.59455f — the drift's
 * span with one digit wrong — lands on 5992 mHz, which prints 5.992 Hz. That is the
 * failure these digits are here to prevent.
 *
 * The drift's SECOND LFO reaches 9.097/10.258/11.806 Hz (LOW/MID/HIGH) the same way, and the
 * lead's 23/17 mHz drift reaches 4.452/3.290 Hz. All of them stay under the 20 Hz ceiling
 * motion_rate_for() holds, so no register is clamped before its travel ends.
 */
#define FILTER_RATE_RANGE_EXP 6.9068906f
#define MOTION_RATE_RANGE_EXP 7.5965505f
#define MOTION_WALK_RANGE_EXP 3.0f

/* Resonance reaches 8x the designed Q, which turns the filter from a tone
 * control into a voice of its own: a peak you can hear the LFO sweep. The FX
 * clamps Q at 20 anyway; this stays under it. */
#define RESONANCE_RANGE_EXP   3.0f

/* THE PAN DRIFT'S depth multiplier, and only the pan drift's.
 *
 * At the top of its travel WIDTH asks for three times the designed drift — generous
 * deliberately, because half of the designed depth was too little to hear, which is why
 * the parameter's own default is 1.0.
 *
 * The pan stage clamps at a full swing (0..1000), so the designed depth has to be the
 * ceiling divided by this multiplier or the top of the travel is dead. That is what
 * DRONE_PAN_DEPTH is: 334, which is 1000/3 rounded UP, because 333 stops one unit short
 * (333 x 3 = 999) and 334 x 3 = 1002 asks for the ceiling at 99.8 percent of the travel
 * and holds it over the last two units. The three registers therefore share one width.
 * A width per register cannot survive that ceiling: the wider one reaches it first and
 * everything above that point on its travel does nothing — which is exactly what the old
 * 700/600/800 did, HIGH clamping from 41.7 percent of the travel up, LOW from 47.6 and
 * MID from 55.6, so the whole upper half of the knob was dead on all three. What the
 * registers keep is the character a shared width does not touch: their rates and walks.
 *
 * The lead is deliberately NOT on this number: LEAD_PAN_DEPTH stays 250, so its travel
 * is never clamped and ends at 750 — a quarter short of the ceiling, which is what keeps
 * the line findable in the image.
 *
 * The filter's depth is bounded elsewhere, by FILTER_DEPTH_MAX_CENTIOCT and the
 * DEPTH+WIDTH sum, which is why the filter gets a multiplier of its own instead of a
 * share of this one. */
#define DEPTH_AT_FULL 3.0f

/* THE FILTER LFO'S depth multiplier.
 *
 * The number the knobs actually reach is the product of three things: the register's
 * designed depth (lfo_depth_centioct, 100/80/60 = 1/0.8/0.6 octaves per unit), this
 * multiplier, and the DEPTH+WIDTH sum that publish_filter_depth() holds at 1.5. DEPTH alone
 * reaches four octaves and the two knobs together six:
 *
 *   LOW   DEPTH 1.0, WIDTH 0    100 centioct x 4.0 x 1.0 = 400 centioct = 4.00 oct
 *   LOW   DEPTH 1.0, WIDTH 1.0  100 centioct x 4.0 x 1.5 = 600 centioct = 6.00 oct
 *   MID   DEPTH 1.0, WIDTH 1.0   80 centioct x 4.0 x 1.5 = 480 centioct = 4.80 oct
 *   HIGH  DEPTH 1.0, WIDTH 1.0   60 centioct x 4.0 x 1.5 = 360 centioct = 3.60 oct
 *
 * WIDTH's share of that sum is FILTER_WIDTH_SHARE below — a half, not a whole — so DEPTH
 * uses its entire travel at every WIDTH instead of saturating half way up.
 *
 * The register bases stay at 100/80/60: they ARE the designed voicing, and lowering
 * them to buy a bigger multiplier would change the factory sound for every register.
 * The cost of raising 3.0 to 4.0 is that the whole travel deepens by a third: LOW at
 * DEPTH 0.5 with WIDTH at 0 goes from 1.50 to 2.00 octaves. */
#define FILTER_DEPTH_AT_FULL 4.0f

/* Доля WIDTH в глубине фильтра, когда фильтр выбран приёмником: половина единицы на верху
 * хода WIDTH. */
#define FILTER_WIDTH_SHARE 0.5f

/* Где останавливается сумма DEPTH и доли WIDTH: 1.5 — это верх обеих ручек вместе. */
#define FILTER_DEPTH_SUM_MAX 1.5f

/* The hard ceiling the filter LFO's depth is held under: eight octaves, two octaves of
 * headroom over anything the knobs can ask for.
 *
 * The real ceiling is the product above, and it is six octaves (600 centioct) on LOW
 * with WIDTH at maximum. This clamp is a backstop rather than a range: it is meant to
 * stay unreachable, and it is what stops a future change to either multiplier from
 * turning a sweep into a stutter without anyone noticing. It was documented as "not
 * past four octaves" while being set to eight, and neither number was the one in force
 * — that is the contradiction this comment removes. */
#define FILTER_DEPTH_MAX_CENTIOCT 800.0f

static bool param_valid(synth_param_t p)
{
    return (int)p >= 0 && (int)p < (int)SYNTH_PARAM_COUNT;
}

/*
 * The 0..1 clamp used by the control surface. The lower test is NEGATED so that a
 * non-number lands on 0 rather than passing straight through: every comparison with NaN
 * is false, which is exactly what `v < 0.0f` relies on and exactly why it fails here.
 */
static float clamp01(float v)
{
    if (!(v >= 0.0f)) {
        return 0.0f;
    }
    if (v > 1.0f) {
        return 1.0f;
    }
    return v;
}

/* -------------------------------------------------------------------------- */
/* The instrument's voicing                                                   */
/* -------------------------------------------------------------------------- */

typedef struct {
    synth_layer_t layer;                              /* also picks the bus: layer + 1 */
    float         base_hz;
    float         detune_cents[DRONE_VOICES_PER_REGISTER];
    uint16_t      first_voice;
    uint16_t      volume;                             /* 0..255 */

    /* drone filter */
    int16_t       fc_hz;
    int16_t       q_x100;
    int16_t       lfo_mhz;
    int16_t       lfo_depth_centioct;
    int16_t       lfo_shape;

    /* pan capture */
    int16_t       pan_base;                           /* -1000..1000 */
    int16_t       pan_depth;                          /* 0..1000 */
    int16_t       pan_rate1_mhz;
    int16_t       pan_rate2_mhz;
    int16_t       walk_ms;
    int16_t       walk_depth;

    float         rack_level;
} drone_register_cfg_t;

/* The drones' designed pan depth: ONE number for all three registers, and the reason is
 * in DEPTH_AT_FULL. 334 is 1000/3 rounded up, so 334 x 3 = 1002 asks the pan stage for
 * its full swing at 99.8 percent of WIDTH's travel and holds it over the last two units,
 * which puts the factory WIDTH of 1.0 on exactly 1000 on every register — where it landed
 * before, when all three were clamped. The old 700/600/800 put each register's clamp at a
 * different point of the travel, which is the dead upper half this removes; what the
 * registers keep is their own rates and walks, the character a shared width does not
 * touch. */
#define DRONE_PAN_DEPTH 334

/*
 * The three drone registers, an octave apart.
 *
 * Volumes are deliberately low: the engine gives one voice at full volume
 * essentially the whole scale, and three voices per register sum inside one
 * bus. Detune is a few cents — enough to make the beating slow and wide, which
 * is most of what makes a drone sound alive.
 *
 * The drift rates are mutually unrelated on purpose (31/47, 37/53, 29/61 mHz):
 * if they were related, the registers would periodically line up and the stereo
 * image would visibly snap.
 *
 * LEVEL BUDGET. The engine gives a single voice at volume 255 essentially the
 * whole scale — about +/-32766 on the bus — so a voice's volume is a fraction of
 * full scale: 84/255, 78/255, 66/255 above. Three voices of one register
 * therefore sum to roughly full scale on their own, which means rack_level is
 * what actually places a register in the mix. The four levels are chosen to sum
 * to about 1.0: that is the point where the rack's soft clipper only ever
 * catches a coincident peak, instead of running as a permanent limiter. Nothing
 * clips inside the engine — the buses are int32 and are only clamped when they
 * reach bus 0, which we discard.
 */
static const drone_register_cfg_t s_drones[DRONE_REGISTERS] = {
    /* LOW — A1, the foundation. The loudest of the three, and the only sine LFO. */
    {
        SYNTH_LAYER_DRONE_LOW, 55.0f, { -7.0f, 7.0f }, DRONE_VOICE_BASE + 0, 66,
        300, 70, 50, 100, 0,
        0, DRONE_PAN_DEPTH, 31, 47, 6000, 1000,
        0.40f,
    },
    /* MID — A2. */
    {
        SYNTH_LAYER_DRONE_MID, 110.0f, { -6.0f, 6.0f }, DRONE_VOICE_BASE + 2, 58,
        700, 90, 70, 80, 1,
        0, DRONE_PAN_DEPTH, 37, 53, 7000, 1000,
        0.28f,
    },
    /* HIGH — A3, triangle LFO so it does not sweep in step with the others. */
    {
        SYNTH_LAYER_DRONE_HIGH, 220.0f, { -9.0f, 9.0f }, DRONE_VOICE_BASE + 4, 48,
        1800, 120, 40, 60, 1,
        0, DRONE_PAN_DEPTH, 29, 61, 5000, 1000,
        0.22f,
    },
};

typedef struct {
    float    base_hz;
    float    detune_cents;
    uint16_t volume;
} lead_voice_cfg_t;

/* Two detuned oscillators plus a sub an octave down, ONE GROUP'S worth: every group
 * of the lead is these same three voices and these same three levels, so a chord is
 * the same timbre three times over. The lead gets a much smaller pan depth than the
 * drones: it should stay findable in the image. */
static const lead_voice_cfg_t s_lead[LEAD_GROUP_VOICES] = {
    { 220.0f, -4.0f, 70 },
    { 220.0f,  4.0f, 70 },
    { 110.0f,  0.0f, 55 },
};

/*
 * THE WAVE LIST, and what each entry actually is.
 *
 * SIN and TRI are the engine's own generators, and they are enough: a sine has no harmonics
 * to alias, and a triangle's fall off as 1/n², so a wavetable for either would be work for
 * nothing. SAW and PLS are ESP32Patches' PolyBLEP wavetables, because the engine's built-in
 * saw is a naive ramp and aliases badly — a drone held for minutes is exactly where that is
 * unforgivable, which is why the instrument has always used AA_Saw.
 *
 * SPR is not a waveform at all, and calling it one in the list is a deliberate convenience:
 * it is SAW with the part's three voices spread further apart. The instrument has three
 * oscillators per part and no more; seven would be six more voices against a fifteen percent
 * idle CPU budget, so the width does the work instead of the count.
 *
 * NOISE is the odd one out in the other direction: it is not a shape and not a pitch, just
 * the engine's noise, one independent stream per voice. Nine drone voices make a wash rather
 * than one hiss, and it still passes through the part's filter and envelope, so it is a
 * texture this instrument can place rather than a hiss laid over the top.
 */
/* PW_, not WAVE_: the engine's WaveType already owns WAVE_SINE, WAVE_TRIANGLE, WAVE_SAW and
 * WAVE_PULSE, and this is a different thing — a list of choices for a part, two of which are
 * not waveforms at all. */
typedef enum {
    PW_SIN = 0,
    PW_TRI,
    PW_SAW,
    PW_PLS,
    PW_SPR,
    PW_NOISE,
    /* Скошенная пила: симметрию цикла задаёт та же ручка PW. Дописана в конец, чтобы
     * сохранённые значения OSC у прежних патчей указывали туда же, куда и раньше. */
    PW_SKEW,
    PW_COUNT
} part_wave_t;

#define PW_DEFAULT  PW_SAW          /* the sound the instrument was designed around */
#define SUPER_SPREAD  3.0f          /* how much wider SPR spreads the detune */

/*
 * How long a change of WAVE is faded over, in milliseconds, one entry per detent of the
 * setting; the index is what app_settings stores under its own key. 0 is the behaviour the
 * instrument had before any of this existed: the shape changes on the next block, the voice
 * is rendered once, and nothing is crossfaded. See SYNTH_PARAM_SET_WAVEMORPH in synth_app.h
 * for why the smoothing is in the voice and not on the parameter, and setWaveSmooth() in
 * components/synth_core/src/ESP32Synth.h for the mechanism.
 */
static const uint16_t WAVE_MORPH_MS[] = { 0, 5, 10, 15, 20, 25, 30, 40, 60, 80, 100 };
#define WAVE_MORPH_COUNT ((int)(sizeof(WAVE_MORPH_MS) / sizeof(WAVE_MORPH_MS[0])))
#define WAVE_MORPH_FACTORY 5        /* 25 ms; app_settings.c's row for this key says 5 too */

/*
 * The stagger. A voice that is morphing is rendered TWICE for as long as its fade lasts, and
 * the drone has nine voices on one knob, so they do not start together: each waits another
 * 20 ms after the one before it. Nine voices at 20 ms apart is 160 ms from the first to the
 * last — under the fifth of a second a shape change is worth waiting for — and it keeps the
 * extra render to one voice at a time, about 2.5 % of the block budget, instead of nine at
 * once, which would be a quarter of it in a single block. The lead uses the same figure for
 * the same reason: its group is three voices, not one.
 */
#define WAVE_MORPH_STAGGER_MS 20

/* The stored setting, clamped and turned into milliseconds. The table is the only copy of the
 * durations, the way SLIDE_MS is for the slide; app_settings stores the index. */
static uint16_t wave_morph_ms(void)
{
    int i = app_settings_get(APP_SET_WAVE_MORPH);
    if (i < 0) {
        i = 0;
    } else if (i > WAVE_MORPH_COUNT - 1) {
        i = WAVE_MORPH_COUNT - 1;
    }
    return WAVE_MORPH_MS[i];
}

/*
 * The engine's own generators for three of the six, the anti-aliased patches for the rest.
 *
 * morph_ms is how long the change takes to be heard and start_ms is how long this voice waits
 * first. Both come from the caller rather than from the setting, and both for the same
 * reason: the stagger is a property of the PART — the engine has no idea which voices belong
 * together — and the supersaw boundary has to be instant, which only the caller knows.
 *
 * With morph_ms 0 this is exactly the setWave()/setCustomWave() pair it replaced, which is
 * what a factory setting of 0 or a boot-time configuration gets.
 */
/*
 * ШИРИНА ИМПУЛЬСА.
 *
 * _pwShift в движке 24, то есть ширина — это восемь бит: 128 это меандр. Ручка PW ведёт от
 * меандра вниз, к узкому импульсу (10 из 255, около четырёх процентов): шире пятидесяти
 * процентов импульс — зеркало того же узкого, отдельного звука там нет. Заводское значение
 * ноль, и оно даёт ровно 128, то есть прежнее звучание всех старых патчей.
 */
/*
 * ВЕСЬ ХОД РУЧКИ — ВЕСЬ ДИАПАЗОН СКВАЖНОСТИ.
 *
 * Сначала ручка шла от меандра вниз, 50 % -> 4 %, и владелец справедливо сказал, что вторая
 * половина хода читается странно: «сделай, чтобы ручка крутила весь диапазон от 0 до 100 %,
 * визуально хотя бы». Теперь так: 5 % на левом краю, 50 % (меандр) в центре, 95 % на правом.
 *
 * Пять процентов, а не ноль: импульс нулевой ширины — это постоянное напряжение, то есть
 * тишина со смещением. Края 5 % и 95 % — зеркала друг друга, и на слух это одна и та же
 * форма; зато весь ход ручки что-то делает, а центр — привычный меандр.
 */
static uint32_t lead_pw_value(void)
{
    /* Зажим свой: clamp01f() объявлен ниже по файлу, а эта функция нужна выше —
     * wave_apply() и applier стоят раньше. */
    float v = s_param[SYNTH_PARAM_LEAD_PW];

    if (!(v > 0.0f)) {
        v = 0.0f;
    } else if (v > 1.0f) {
        v = 1.0f;
    }

    /* 0..1 -> 5..95 % периода, в восьмибитной ширине движка: 255 * доля. */
    return (uint32_t)((0.05f + v * 0.90f) * 255.0f + 0.5f);
}

static void apply_lead_pw(float v01)
{
    if (!(v01 > 0.0f)) {
        v01 = 0.0f;
    } else if (v01 > 1.0f) {
        v01 = 1.0f;
    }

    const uint32_t pw = (uint32_t)((0.05f + v01 * 0.90f) * 255.0f + 0.5f);

    /* Всем голосам лида, а не только тем, что играют сейчас: голос, который прозвучит
     * следующей нотой, должен получить ширину до неё, а не после. */
    for (int v = 0; v < LEAD_VOICES; v++) {
        s_synth.setPulseWidth((uint16_t)(LEAD_VOICE_BASE + v), pw);
    }
}

static void wave_apply(uint16_t voice, int wave, uint16_t morph_ms, uint16_t start_ms)
{
    switch (wave) {
    case PW_SIN:
        s_synth.setWaveSmooth(voice, WAVE_SINE, nullptr, morph_ms, start_ms);
        break;
    case PW_TRI:
        s_synth.setWaveSmooth(voice, WAVE_TRIANGLE, nullptr, morph_ms, start_ms);
        break;
    case PW_PLS:
        s_synth.setWaveSmooth(voice, WAVE_CUSTOM, ESP32Patches::AA_Pulse, morph_ms, start_ms);
        /* _pwShift is 24, so the width is an 8-bit number and half of it is 128. A pulse
         * whose width is left at zero is a constant — silence with a DC offset. Set after the
         * shape and instantly: the width is not part of the crossfade, which is why the
         * generator is called with the width the voice already has.
         *
         * Ширина теперь приходит от ручки PW: 128 это меандр, меньше — узкий импульс. */
        s_synth.setPulseWidth(voice, lead_pw_value());
        break;
    case PW_NOISE:
        s_synth.setWaveSmooth(voice, WAVE_NOISE, nullptr, morph_ms, start_ms);
        break;
    case PW_SKEW:
        /* Пила с изломом: PW задаёт, где излом стоит. 50 % — треугольник. */
        s_synth.setWaveSmooth(voice, WAVE_CUSTOM, ESP32Patches::AA_Skew, morph_ms, start_ms);
        s_synth.setPulseWidth(voice, lead_pw_value());
        break;
    case PW_SAW:
    case PW_SPR:
    default:
        s_synth.setWaveSmooth(voice, WAVE_CUSTOM, ESP32Patches::AA_Saw, morph_ms, start_ms);
        break;
    }
}

/* The detune a voice actually gets. Only SPR changes it, and it is the whole of what SPR
 * is: the same three saws, pushed apart far enough to beat audibly. */
static float wave_detune(float base_cents, bool super)
{
    return super ? base_cents * SUPER_SPREAD : base_cents;
}

/* A list parameter arrives as 0..1 and means an index. */
static int param_wave(synth_param_t p)
{
    /*
     * ШЕСТЬ СТАРЫХ ФОРМ НЕ СДВИГАЮТСЯ.
     *
     * В патче лежит ДОЛЯ хода, а не номер формы, поэтому при семи формах прежние доли
     * указали бы на другие: PULS (0.6) стал бы SPR. Первые шесть делят ход как раньше, а
     * SKEW стоит на самом верху, за последним делением: старый патч звучит той же формой,
     * что и до неё.
     */
    const float v = (s_param[p] > 0.0f) ? ((s_param[p] > 1.0f) ? 1.0f : s_param[p]) : 0.0f;

    if (v > 0.999f) {
        return PW_SKEW;
    }

    const int n = PW_COUNT - 2;      /* шесть форм: 0..5 */
    const int i = (int)(v * (float)n + 0.5f);
    return i < 0 ? 0 : (i > n ? n : i);
}

/*
 * ДРОН БЕЗ SKEW.
 *
 * SKEW — скошенная пила, и её излом задаётся шириной импульса, которой у дрона нет: ручки PW
 * там не существует. Форма попала в список потому, что список общий с лидом, а управлять в
 * дроне нечем. Здесь шесть прежних форм, и SKEW не выдаётся ни при каком ходе ручки.
 */
static int param_wave_drone(synth_param_t p)
{
    const float v = (s_param[p] > 0.0f) ? ((s_param[p] > 1.0f) ? 1.0f : s_param[p]) : 0.0f;
    const int n = PW_COUNT - 2;      /* шесть форм: 0..5 */
    const int i = (int)(v * (float)n + 0.5f);

    return i < 0 ? 0 : (i > n ? n : i);
}

/* The shapes in force, one per register.
 *
 * `wave` is the list index already written to that register's three voices, or -1 before
 * the first write: it is what keeps apply_drone_wave() from re-writing the registers that
 * did not change, which matters beyond the saved work — a setWaveSmooth() call for the
 * shape a voice already has DROPS any fade that was waiting behind the running one, so
 * re-writing a neighbouring register would swallow a request made a block earlier.
 *
 * `super` is whether that shape is the supersaw, which is a detune rather than a wave, and
 * is why it is carried beside the list index: drone_set_pitch() needs it per register, not
 * for the part. */
static int  s_drone_wave[DRONE_REGISTERS] = { -1, -1, -1 };
static bool s_drone_super[DRONE_REGISTERS];
static bool s_lead_super;

/* The lead's designed pan settings, shared with buses_init() so the motion
 * parameters scale the same numbers the voicing was built around. */
#define LEAD_PAN_DEPTH     250
#define LEAD_PAN_RATE1_MHZ 23
#define LEAD_PAN_RATE2_MHZ 17
#define LEAD_WALK_MS       9000

/* -------------------------------------------------------------------------- */
/* The lead sequencer                                                         */
/* -------------------------------------------------------------------------- */
/*
 * The sequencer is a monophonic line — one note at a time — played on all three
 * voices of ONE lead group at once. Monophonic does not mean one voice: the detune
 * spread that already gives the drone registers their width gives the melody the
 * same, and it costs nothing, because those voices exist and were voiced for it.
 * The other two groups are the player's, and they belong to the keyboard alone:
 * see lead_group_alloc().
 *
 * WHY THE SEQUENCER RUNS INSIDE THE AUDIO TASK
 *   Two reasons, and the second is the one that decides it:
 *
 *   the engine has no locking of any kind, so a timer task calling noteOn()
 *   would be racing the renderer on every note;
 *
 *   and a clock taken from the block counter cannot drift against the audio. A
 *   millisecond timer wanders by a block here and there, which at a slow tempo
 *   is an audible flam between the note and the beat it was meant to land on.
 *   Here a step is a whole number of blocks, so the line is as steady as the
 *   sample clock.
 */
#define LEAD_LEVEL_MAX       0.5f   /* the designed 0.25 sits at the travel below */

/*
 * ЗАКОН ФЕЙДЕРА: КВАДРАТ, А НЕ ЛИНЕЙНЫЙ МНОЖИТЕЛЬ.
 *
 * Ручка уровня — это фейдер микшера, а не регулятор громкости на усилителе. Линейный
 * множитель звучит неправильно по одной причине: громкость слышится логарифмически, а
 * значит половина хода линейного фейдера — это всего −6 дБ, то есть «почти так же громко».
 * Весь полезный ход собирается в первой трети, и рукой его не поймать: движение на пару
 * градусов у верха уже орёт, а ниже половины ничего не меняется на слух.
 *
 * Квадрат даёт −12 дБ на середине и −24 дБ на четверти, и ход становится ровным на слух:
 * каждые десять процентов убавляют примерно поровну. Это же и есть закон, по которому
 * устроены фейдеры пультов, — только там он нарисован на шкале дБ, а здесь шкала одна, и
 * закон зашит в число.
 *
 * КОНЦЫ ТОЧНЫЕ: ноль остаётся тишиной (на нём стоит жест глушения и правило «дорожка на
 * нуле не бьёт»), единица — полной шкалой. Всё, что между ними, считается этой функцией,
 * и другого места, где уровень превращается в усиление, в приборе нет.
 */
static float level_gain(float v01)
{
    float v = v01;
    if (!(v > 0.0f)) {
        return 0.0f;
    }
    if (v > 1.0f) {
        v = 1.0f;
    }
    return v * v;
}

extern "C" float synth_app_level_gain(float v01)
{
    return level_gain(v01);
}

/*
 * The drone mixer defaults are EXACTLY the levels the registers were voiced at,
 * so all three at rest is that voicing and the knobs can only move away from it.
 */
/*
 * The same three gains the registers were voiced at, written as the TRAVEL that produces
 * them under the fader law: 0.632^2 = 0.40, 0.529^2 = 0.28, 0.469^2 = 0.22. The factory
 * sound is therefore the same balance it was, and the readout still prints 40, 28 and 22 —
 * it prints the gain, which is what level_gain() makes of these numbers.
 */
/* Заводские положения пересчитаны под дБ-шкалу и поправку: усиление на них прежнее —
 * 0.40, 0.28 и 0.22, и на экране печатается именно оно. */
#define DRONE_LOW_DEFAULT    0.824f
#define DRONE_MID_DEFAULT    0.799f
#define DRONE_HIGH_DEFAULT   0.781f

/*
 * The lead's filter and its envelope.
 *
 * Ranges are stated in the units the music is in, and the knob's 0..1 is mapped
 * onto them at the edges. Where the ear is logarithmic — cutoff, resonance and
 * all three times — the mapping is geometric, so a turn of the knob is the same
 * interval at the bottom of its travel as at the top. Where it is not — octaves
 * of envelope, sustain — the mapping is linear, because octaves already are the
 * logarithmic unit.
 *
 * The defaults make the filter audibly a filter without taking the lead away from
 * the sound that was approved: the cutoff sits above the fundamental but below
 * the top of the saw, so notes get a soft edge, and the envelope opens each onset
 * again. CUTOFF at maximum with ENV at zero is the unfiltered lead exactly.
 */
#define LEAD_FC_MIN_HZ        80.0f
#define LEAD_FC_MAX_HZ      9000.0f
#define LEAD_FC_DEFAULT_HZ  2600.0f

/*
 * THE LEAD FILTER'S KEY TRACKER, AND ITS REFERENCE NOTE.
 *
 * The reference is A3 — MIDI 57, 220 Hz — because that is the pitch the lead's own voice table
 * is voiced at: all three entries of s_lead[] carry base_hz 220, the two saws and the sub an
 * octave below (110). A3 is therefore the note on which the patch sounds as it was designed,
 * the one the factory CUTOFF of 2600 Hz is a corner above, and the one where the tracker's
 * multiplier is exactly 1. Taking the bottom of the keyboard instead would make every note
 * above it read as "tracking up" and shift the whole designed sound; taking the top would do
 * the same downwards. The middle of the lead's range is where a reference belongs, and the
 * voice table already names it.
 *
 * A3 is also MIDI 57 = DRONE_BASE_MIDI + 24, so the two trackers' exponents differ only by the
 * two octaves between the parts' bases: one formula, 2^(k·(note − ref)/12), with the same shape
 * on both pages.
 *
 * The clamp is the filter's own top of travel: LEAD_FC_MAX_HZ is 9 kHz and the tracker can
 * multiply it by up to 2^(75/12) at the top of the keyboard, so an unclamped product would
 * leave the audio band and overflow the int16 slot. 16 kHz keeps the corner where a low-pass is
 * still doing something at 48 kHz.
 */
#define LEAD_KTRCK_REF_MIDI       57
#define LEAD_CUTOFF_TRACK_MAX_HZ  16000.0f

/* The newest note the lead is sounding, as a MIDI number; the tracker's whole input. Freed
 * notes do not clear it: the filter holds the corner of the last note played, which is what a
 * released but still ringing voice wants, and the next note moves it. */
static int s_lead_track_note = LEAD_KTRCK_REF_MIDI;

#define LEAD_Q_MIN            0.5f
#define LEAD_Q_MAX            8.0f
#define LEAD_Q_DEFAULT        1.0f

/*
 * THE ENVELOPE'S DEPTH IS A PERCENTAGE OF THE TRAVEL THAT IS LEFT, not a number of
 * octaves on a fixed scale.
 *
 * It was -3..+5 octaves, and both ends were wrong at the ends of CUTOFF: from a corner at
 * 9 kHz, three octaves down is 1.1 kHz and the filter is wide open, and from 80 Hz five
 * octaves up is 2.5 kHz and it is still shut. A player asking for "closed" at the bottom
 * of the knob and "open" at the top means the STOPS of the filter, not a number of
 * octaves that happens to be right at one corner.
 *
 * So the knob is -100..+100 % of the distance from the corner in force to the stop it is
 * heading for: down to LEAD_FC_FLOOR_HZ, up to LEAD_FC_CEIL_HZ, which are the same 20 Hz
 * and 0.45 of the sample rate that the filter itself clamps to. The slot still carries
 * centioctaves — 8.8 of them at the low end from a 9 kHz corner, which is why the number
 * is computed here and not there — so nothing inside the filter changes; what changes is
 * where the number comes from: lead_env_oct_for() and the corner the tracker has left it
 * at.
 */
#define LEAD_FC_FLOOR_HZ      20.0f
#define LEAD_FC_CEIL_HZ      (0.45f * (float)SYNTH_SAMPLE_RATE)
#define LEAD_ENV_DEFAULT_OCT  2.0f   /* the factory travel, measured at the factory corner */

#define LEAD_TIME_MIN_MS      1.0f
#define LEAD_TIME_MAX_MS   6000.0f

/*
 * THE AMPLITUDE ENVELOPE'S FACTORY, and these four numbers are the ones the lead's voices
 * were hard-wired to before the four knobs moved here: 40 ms of attack, a quarter second
 * of decay, 0.86 of sustain and half a second of release. A patch that never touches the
 * page therefore sounds exactly as it did — which is the whole reason the defaults are
 * these constants and not round ones.
 */
#define LEAD_AMP_ATTACK_DEFAULT_MS    40.0f
#define LEAD_AMP_DECAY_DEFAULT_MS    250.0f
#define LEAD_AMP_SUSTAIN_DEFAULT     (220.0f / 255.0f)
#define LEAD_AMP_RELEASE_DEFAULT_MS  500.0f

/* The filter envelope's split, in the knob's 0..1: 0.5 is the equal one, and the factory
 * position is the one whose two segments are the same — nothing a hand has to undo. */
#define LEAD_FENV_SHAPE_DEFAULT        0.5f

/* POLY at the factory, and it is the ZERO of the list (see apply_lead_voice): the knob's
 * bottom position, the byte an old patch carries, and the sound the lead was given when the
 * sequencer learned to overlap its steps are all the same number. */
#define LEAD_VOICE_DEFAULT             0.0f

/* Whether the lead is four voices or one. Written by apply_lead_voice(), read by the two
 * allocators — lead_note_on() for the generator and lead_group_alloc() for the keys — and
 * by nothing else. */
static bool s_lead_poly = true;

/*
 * АККОРД, третье положение VOICE.
 *
 * Включённый, он не меняет ни одного голоса: он меняет то, сколько нот приходит на одно
 * событие. Одна нота, взятая линией или арпеджиатором, звучит тремя — основная, через
 * ступень и через две, — а раскладывает их тот же аллокатор, что и раньше: аккорд просто
 * занимает три группы из четырёх.
 *
 * ПОЧЕМУ ОТ ЛАДА, А НЕ СЛУЧАЙНО. Дрон держит тонику, и аккорд вне лада слышен как ошибка.
 * Ступени берутся из выбранного SCALE, поэтому качество аккорда получается само: на 1, 4 и
 * 5 — мажор, на 2, 3 и 6 — минор, на 7 — уменьшённый. Ни одна настройка для этого не нужна,
 * и ни одна не может рассинхронизироваться с ладом.
 *
 * УРОВНИ: основная нота громче остальных, иначе аккорд читается как «три ноты», а не как
 * «нота с окраской». Сумма трёх весов ниже двух, так что аккорд громче одной ноты, но не
 * вдвое.
 */
static bool s_lead_chord = false;

#define LEAD_CHORD_NOTES 3
static const float LEAD_CHORD_LEVEL[LEAD_CHORD_NOTES] = { 0.70f, 0.55f, 0.55f };

/*
 * The effect chain.
 *
 * DELAY_TIME's range only bounds the free-running case: when the delay is synced
 * its time comes from the tempo, and the knob becomes a readout of what the
 * tempo has decided.
 */

/*
 * The delay's divisions, BY NAME.
 *
 * The index of a name here is the position of that entry on the knob, because a
 * list parameter is round(v * (DELAY_DIV_COUNT - 1)) of its stored value. That is
 * the whole reason for the enumeration: the factory default below has to name the
 * division it means. Written as a number it went stale twice as this list grew, and
 * a stale default is a device that switches on with a different echo than the one
 * its patch was voiced with — silently, because nothing about the sound says which
 * position the knob thinks it is on.
 *
 * FREE is first and is not a division at all: it is the switch that hands the delay
 * back to the TIME knob, which is why it stays at zero. The list starts at 1/1 rather
 * than at 2/1: nothing longer than one whole note fits the line, and one whole note is
 * exactly what the line holds (see DELAY_LINE_MAX_MS).
 */
enum {
    DELAY_DIV_FREE = 0,
    DELAY_DIV_1_1,          /* a whole note: four beats */
    DELAY_DIV_1_2_DOT,      /* dotted half: three beats */
    DELAY_DIV_1_2,          /* half: two beats */
    DELAY_DIV_1_4_DOT,
    DELAY_DIV_1_4,
    DELAY_DIV_1_8_DOT,
    DELAY_DIV_1_8,
    DELAY_DIV_1_16_DOT,
    DELAY_DIV_1_8_T,        /* eighth triplet: a third of a beat */
    DELAY_DIV_1_16,
    DELAY_DIV_1_32,
    DELAY_DIV_NAME_COUNT
};
#define DELAY_DIV_COUNT   DELAY_DIV_NAME_COUNT
#define DELAY_MIN_MS       20.0f
#define DELAY_MAX_MS     1500.0f
/* How long the effect's line actually is, in milliseconds: one whole note at 60 bpm,
 * which is DELAY_MAX_MS in components/synth_dsp/src/synth_fx_delay.cpp. That constant
 * lives in an anonymous namespace inside the effect and cannot be read from here, so it
 * is written again — and only the readout below uses it, because the readout has to say
 * what the effect can play rather than what the tempo asked for. Below 60 bpm a synced
 * 1/1 asks for more than the line holds; the effect clamps and this is where the knob
 * agrees with it. Keep the two numbers together. */
#define DELAY_LINE_MAX_MS 4000.0f
#define DELAY_SYNC_DEFAULT DELAY_DIV_1_8   /* half a beat, the echo it was voiced with */

/*
 * СЛИТАЯ РУЧКА ВРЕМЕНИ.
 *
 * Первые одиннадцать положений — доли такта (FREE из списка убран: он и был переключателем
 * на миллисекунды, теперь миллисекунды просто идут следом), остальные шестнадцать —
 * миллисекунды от DELAY_MIN_MS до DELAY_MAX_MS по геометрической шкале. Шестнадцать
 * положений на всю шкалу — шаг около полутора процентов, на слух непрерывная ручка.
 */
#define DELAY_MS_STEPS    16
#define DELAY_TIME_STEPS  ((DELAY_DIV_COUNT - 1) + DELAY_MS_STEPS)
#define DELAY_TIME_DEFAULT (DELAY_SYNC_DEFAULT - 1)

/*
 * The time mode's two entries: TAPE first, which is the behaviour the delay has always
 * had, and CROSSFADE second. Two, so the knob is one detent from either — see
 * delay_crossfade().
 */
#define DELAY_TIME_MODE_COUNT 2

/*
 * The parameters whose MEANING moved, as numbers, for the migration.
 *
 * A remembered sound is a flat array of floats with no names in it: the position is the
 * parameter and the value is normalised. Four of those positions have been given a new
 * meaning — the two division lists above, the percussion's pitch and its depth — so the
 * one-time migration in components/app_settings/src/app_settings.c rewrites what is in the
 * flash by index, by name (divisions) or by formula (the percussion pair). Two more moved
 * with a list of their own and carry a one-time flag of their own there: SCALE, whose list
 * grew from eleven entries to sixteen, and VERB MODE, whose engine lost a mode — HOLD — so
 * the positions after it moved down. A stored position is walked through the OLD list in
 * both cases, which is what keeps the sound the player chose instead of whatever the same
 * number happens to mean in the shorter list.
 *
 * app_settings cannot include this header to ask for those numbers: this component
 * already requires that one, so the include would be a cycle. They are therefore written
 * out there, and checked here, where the list is — an insertion above one of them is a
 * compile error in this file instead of a migration that quietly rewrites the wrong knob.
 */
static_assert((int)SYNTH_PARAM_ARP_SPEED  == 33, "app_settings.c migrates ARP SPEED at 33");
static_assert((int)SYNTH_PARAM_DELAY_SYNC == 36, "app_settings.c migrates DELAY SYNC at 36");
static_assert((int)SYNTH_PARAM_PERC_PITCH == 51, "app_settings.c migrates PERC PITCH at 51");
static_assert((int)SYNTH_PARAM_PERC_ENV   == 54, "app_settings.c migrates PERC ENV at 54");
static_assert((int)SYNTH_PARAM_SCALE      == 10, "app_settings.c migrates SCALE at 10");
static_assert((int)SYNTH_PARAM_VERB_MODE  == 43, "app_settings.c migrates VERB MODE at 43");

/*
 * The patch and its ceiling.
 *
 * 131 is what the sound is: everything from LEVEL to the drum's clock, the two RESET
 * gesture periods, the drone's three shapes, the way it follows the lead, the two key
 * trackers, the delay's time mode and the bass section's sixteen — and a patch or a preset
 * is exactly those values with no names in them. The ceiling is a separate number that
 * belongs to the store — APP_SETTINGS_PATCH_MAX (the patch blob) and APP_PRESET_PARAM_MAX
 * (a preset record), both 131, both in app_settings.h, which this file already includes —
 * and the equality is asserted so that a parameter added past the ceiling stops the build
 * here rather than being silently cut in half by app_settings_patch_note() at run time.
 *
 * The ceiling moved with the count each time a RESET parameter took the new slot: the
 * lead's when the gesture moved from a device setting on SYSTEM to the sound, the drum's
 * when the two gestures were split. It moved again for the drone's three shapes, and again
 * when the tonic's octave became a control of its own, once more for SPAN, the octaves the
 * melody walks, and once more for the bass section, whose sixteen are appended as one block
 * at the end of the patch. A record
 * written before any of those existed is a PREFIX of the list rather than an invalid one —
 * app_settings_preset_load() returns as many values as the record carried and
 * synth_app_patch_apply() gives the missing tail the answer that record's own contents imply
 * — so the store's format version did not have to move with it. See the note on
 * SYNTH_PARAM_SEQ_RESET and SYNTH_PARAM_PERC_RESET, and synth_app_patch_apply().
 */
static_assert(SYNTH_PARAM_PATCH_COUNT == 148, "the patch is 148 parameters");
static_assert(SYNTH_PARAM_PATCH_COUNT <= APP_SETTINGS_PATCH_MAX,
              "the patch must fit the blob app_settings stores");
static_assert(SYNTH_PARAM_PATCH_COUNT <= APP_PRESET_PARAM_MAX,
              "the patch must fit a preset record");

#define CHORUS_RATE_MIN_HZ  0.05f
#define CHORUS_RATE_MAX_HZ  8.0f
#define VERB_SIZE_DEFAULT   0.50f
#define VERB_DAMP_DEFAULT   0.40f
#define SEND_LOW_DEFAULT    0.15f    /* balanced against each other, so that */
#define SEND_MID_DEFAULT    0.20f    /* raising the reverb mix alone gives a  */
#define SEND_HIGH_DEFAULT   0.35f    /* usable room instead of a drone soup   */
#define SEND_LEAD_DEFAULT   0.50f

#define SEQ_TEMPO_MIN_BPM    30.0f
#define SEQ_TEMPO_MAX_BPM    300.0f
/*
 * Exponential rather than linear, because tempo is heard as a ratio: the step
 * from 30 to 60 is the same musical distance as 150 to 300, and a linear knob
 * would spend most of its travel in the fast end where every step sounds alike.
 *
 * The span is log2(300 / 30), and the default is the knob position that lands on
 * exactly 60 BPM — one note per second, the tempo the line was voiced at and
 * judged by, so widening the range does not change what the instrument does when
 * it is switched on.
 */
#define SEQ_TEMPO_SPAN       3.32192809f
#define SEQ_TEMPO_DEFAULT    0.30103000f
/*
 * THE TONIC, AS TWO LISTS: the note and the octave.
 *
 * MIDI 24 (C1) to 107 (B7) — seven octaves, and the range the lead plays in, because the
 * sequencer draws its notes around this tonic. The old single knob covered the same register
 * as eighty-five detents, one per semitone, and it used to be MIDI 45 (A2) to 69 (A4) before
 * that: twenty-five detents around the register the line was voiced in.
 *
 * ONE KNOB WAS A SWEEP. Finding D minor on it meant eight detents of guessing between the
 * note you wanted and the note you landed on, with the readout as the only witness; the owner
 * asked for the two things a player actually aims at, and they are two controls now — twelve
 * notes (ROOT, a list of C..B) and seven octaves (ROOT_OCT, a list of 1..7). Nothing moves
 * faster than one position per detent, so the tonic is four or five clicks from anywhere.
 *
 * THE TOP C IS GONE. The old range ended on C8, which a twelve-by-seven grid cannot name
 * without an eighth octave that would exist for one note; B7 is the ceiling and a record that
 * sat on C8 comes back on B7. Said here rather than discovered by ear.
 *
 * A STORED ROOT IS REMAPPED TWICE OVER, because a preset is a normalised value and both the
 * range and the shape of the control changed: 0.5 is A3 in the twenty-five note range, F#4
 * across the eighty-five semitones, and a pair now. synth_app_patch_apply() walks each older
 * record through the range it was written against and splits the result into the two lists,
 * so an old sound comes back in its key.
 */
#define SEQ_ROOT_MIN_MIDI    24
#define SEQ_ROOT_MAX_MIDI    107
/* A3 (MIDI 57) is note 9 of 12 and octave 3 of 7 — the same note 0.5 used to name, so the
 * instrument still comes up on the register it was voiced in. Written as divisions rather
 * than as decimals so the two knobs round to exactly A and 3: 9/11 is 0.818182 and 2/6 is
 * 0.333333, and it is the knob's own rounding that decides the last digit. */
#define SEQ_NOTE_DEFAULT     (9.0f / 11.0f)
#define SEQ_OCT_DEFAULT      (2.0f / 6.0f)
/* The octave list's length: MIDI 1..7, so that note 12 plus octave 1 is C1 = MIDI 24 and the
 * top of the list is B7. */
#define SEQ_OCT_COUNT        7

#define SEQ_SCALE_DEFAULT    0.0f   /* MIN PENT, the factory scale */
#define SEQ_DENSITY_DEFAULT  1.0f   /* every step sounds, as designed */
#define SEQ_OCTAVE_DEFAULT   0.0f   /* the register follows the melody */
#define SEQ_SHAPE_DEFAULT    0.0f   /* sine */

/*
 * The rhythm grid. STEPS is the n of E(k,n) and PULSES is the k; a bar is four
 * beats, so the pattern spans a bar and E(3,8) comes out as the tresillo rather
 * than as an arbitrary figure.
 *
 * The defaults reproduce what the instrument did before there was a grid at all:
 * four steps to a bar is a quarter note, four pulses out of four is an onset on
 * every one of them, and no scatter and no rotation leave them exactly on the
 * beat. A Euclidean sequencer that changed the sound the moment it was added
 * would have been the wrong way to add it.
 *
 * PULSES IS A COUNT INSIDE THE GRID, not a range of its own: k of E(k,n) cannot
 * exceed n, so the knob has exactly as many positions as the grid has steps —
 * see seq_pulses_for(). Turn STEPS down and the pulses knob shortens with it.
 *
 * ROTATE is a phase on the same grid and therefore has n positions too: the
 * sixteenth position of a four-step pattern is the same rhythm as the first, so
 * the old fixed range left twelve detents that changed nothing but the number.
 */
#define SEQ_STEPS_MIN        4
#define SEQ_STEPS_MAX        16

#define SEQ_STEPS_DEFAULT    0.0f   /* 4 steps to the bar */
#define SEQ_PULSES_DEFAULT   1.0f   /* every step of whatever grid is chosen */
#define SEQ_ROTATE_DEFAULT   0.0f   /* the pattern starts on the downbeat */
#define SEQ_SCATTER_DEFAULT  0.0f   /* nothing wanders; it is written exactly */

/*
 * The floor under a step, expressed in TIME rather than in blocks: 21 ms is the
 * shortest that still reads as a note instead of a buzz, and 10 ms the shortest gate
 * that is not a click. The blocks are derived, so a larger audio block does not
 * stretch the floor with it — at 256 samples they come out at 4 and 2.
 */
#define SEQ_MIN_STEP_MS      21u
#define SEQ_MIN_GATE_MS      10u
#define SEQ_MIN_STEP_BLOCKS  ((SEQ_MIN_STEP_MS * SYNTH_SAMPLE_RATE / 1000 + SYNTH_BLOCK_SAMPLES - 1) / SYNTH_BLOCK_SAMPLES)
#define SEQ_MIN_GATE_BLOCKS  ((SEQ_MIN_GATE_MS * SYNTH_SAMPLE_RATE / 1000 + SYNTH_BLOCK_SAMPLES - 1) / SYNTH_BLOCK_SAMPLES)

/*
 * The scales, as semitone offsets from the root.
 *
 * The pentatonics come first because that is what the line was voiced on: no
 * avoid notes, so a wandering melody cannot land on a wrong-sounding interval.
 * The modes follow, because a mode changes the intervals — and the intervals are
 * the largest single difference one setting can make.
 */
static const int8_t SEQ_PENT_MINOR[] = { 0, 3, 5, 7, 10 };
static const int8_t SEQ_PENT_MAJOR[] = { 0, 2, 4, 7, 9 };
static const int8_t SEQ_HIRAJOSHI[]  = { 0, 2, 3, 7, 8 };

static const int8_t SEQ_IONIAN[]     = { 0, 2, 4, 5, 7, 9, 11 };
static const int8_t SEQ_DORIAN[]     = { 0, 2, 3, 5, 7, 9, 10 };
static const int8_t SEQ_PHRYGIAN[]   = { 0, 1, 3, 5, 7, 8, 10 };
static const int8_t SEQ_LYDIAN[]     = { 0, 2, 4, 6, 7, 9, 11 };
static const int8_t SEQ_MIXOLYDIAN[] = { 0, 2, 4, 5, 7, 9, 10 };
static const int8_t SEQ_AEOLIAN[]    = { 0, 2, 3, 5, 7, 8, 10 };
static const int8_t SEQ_LOCRIAN[]    = { 0, 1, 3, 5, 6, 8, 10 };
static const int8_t SEQ_HARM_MINOR[] = { 0, 2, 3, 5, 7, 8, 11 };

/*
 * The five that were added after the list was already in the field. They are a tail and
 * not a group: what they have in common is only that they came later, and the order
 * inside the tail is the order a player would look for them in — the plain one first,
 * the octatonic and the whole-tone after it, and CHROMATIC, which is not a scale at all
 * but the absence of one, last.
 *
 * Chromatic is twelve steps because it is every semitone there is: a note that is
 * already a step cannot be moved to a nearer one, which is what makes it the setting
 * that quantises nothing.
 */
static const int8_t SEQ_BLUES[]      = { 0, 3, 5, 6, 7, 10 };
static const int8_t SEQ_MEL_MINOR[]  = { 0, 2, 3, 5, 7, 9, 11 };
static const int8_t SEQ_WHOLE_TONE[] = { 0, 2, 4, 6, 8, 10 };
static const int8_t SEQ_DIMINISHED[] = { 0, 2, 3, 5, 6, 8, 9, 11 };
static const int8_t SEQ_CHROMATIC[]  = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 };

/*
 * ВОСТОЧНЫЕ ЛАДЫ, КОТОРЫЕ ПРОСИЛИ. Всё это приближения двенадцатиступенным строем:
 * настоящий макам живёт четвертями тона, и здесь их нет — есть только то, что остаётся,
 * когда четверть округлена до полутона. Остаётся, однако, самое узнаваемое: увеличенная
 * секунда и её окрестности.
 *
 *   HIJAZ     1-b2-3-4-5-b6-b7  мажорный тонический аккорд с малой секундой над ним;
 *                               первое, что называют «восточным», и на слух самое
 *                               употребимое из пяти
 *   NIKRIZ    1-2-3-4-5-b6-7    тот же мажор, но с малой секстой и обычной секундой:
 *                               мягче хиджаза, годится под фразу, а не под выкрик
 *   SABA      1-b2-b3-4-5-b6-b7 мажорная терция при малой секунде и увеличенной кварте —
 *                               характерный плачущий оборот, самый шершавый из четырёх
 *                               семиступенных здесь
 *   PERSIAN   1-b2-3-4-5-b6-7   дважды гармонический: малая секунда, малая секста и
 *                               терция без опоры — блестит и не успокаивается
 *   IN-SEN    1-b2-4-5-b7       японская пятиступенчатая, без терции вовсе: лад не
 *                               называет ни мажора, ни минора, отсюда его холод
 */
static const int8_t SEQ_HIJAZ[]     = { 0, 1, 4, 5, 7, 8, 10 };
static const int8_t SEQ_NIKRIZ[]    = { 0, 2, 4, 5, 7, 8, 11 };
static const int8_t SEQ_SABA[]      = { 0, 1, 3, 4, 7, 8, 10 };
static const int8_t SEQ_PERSIAN[]   = { 0, 1, 4, 5, 7, 8, 11 };
static const int8_t SEQ_IN_SEN[]    = { 0, 1, 5, 7, 10 };

/*
 * The Markov chain: how likely the line is to move from one pentatonic degree to
 * another, ignoring octaves. Row = where it is, column = where it goes.
 *
 * The numbers are musical judgements, not arithmetic, which is why they are
 * written out rather than derived from a rule — a rule can only ever produce
 * what the rule already says, and this is the one place in the sequencer where
 * taste is supposed to live.
 *
 *   Tonic and fifth are the two columns that are never low. That pull is what
 *   makes a line sound like it is going somewhere rather than drifting: 0 and 3
 *   are the resting places of A minor pentatonic.
 *
 *   The neighbouring degree usually outweighs a leap, so the melody moves in
 *   steps most of the time and the leaps stay noticeable.
 *
 *   NO ZEROS ANYWHERE. Every move stays possible however unlikely, because a
 *   table with a zero in it can trap the line in a closed cycle it can never
 *   leave — and a generative sequencer that gets stuck is worse than one that
 *   occasionally plays something odd.
 *
 * Read the rows against A minor pentatonic: 0 = A, 1 = C, 2 = D, 3 = E, 4 = G.
 */
static const uint8_t SEQ_MARKOV5[5][5] = {
    /* from A */ {  8, 12,  3,  6, 10 },
    /* from C */ { 16,  6,  9,  7,  3 },
    /* from D */ {  7, 14,  5, 10,  4 },
    /* from E */ { 11,  5, 12,  6,  9 },
    /* from G */ { 15,  4,  3,  8,  5 },
};

/*
 * The seven-degree table, for the modes.
 *
 * One table serves all of them, and that is a considered compromise rather than
 * laziness: the tendencies that matter here — the pull to the tonic, the
 * preference for a step over a leap, the seventh leaning upward — are properties
 * of tonal gravity, not of one particular mode. What a mode actually changes is
 * the intervals, and that is already the largest difference one setting can
 * make. Per-mode tables would be a real refinement later, if the modes turn out
 * to sound too much alike.
 *
 * Degrees are 1..7 of the mode. Same rules as above: the tonic and fifth columns
 * are the strong ones, and there are no zeros anywhere.
 */
static const uint8_t SEQ_MARKOV7[7][7] = {
    /* from 1 */ {  7, 11,  5,  4,  9,  6,  3 },
    /* from 2 */ {  9,  5, 12,  5,  6,  4,  3 },
    /* from 3 */ { 10,  8,  5,  9,  7,  4,  3 },
    /* from 4 */ {  5,  4, 12,  5, 10,  6,  3 },
    /* from 5 */ {  9,  5,  6, 10,  6,  9,  4 },
    /* from 6 */ {  8,  4,  4,  6, 11,  5,  7 },
    /* from 7 */ { 15,  3,  3,  4,  5,  8,  4 },
};

/*
 * The three shapes the appended scales needed, and nothing else about them is new: the
 * same rules as above hold in all three — the tonic and fifth columns are the strong ones,
 * a neighbouring degree outweighs a leap, and there is no zero anywhere, so no line can
 * be trapped in a cycle it cannot leave.
 *
 * They exist because a scale IS its table here: a row is indexed by the degree and read
 * sc->len wide, so a scale of six, eight or twelve degrees cannot borrow a table of five
 * or seven without reading past it. The six-degree table is shared by BLUES and WHOLE
 * TONE for the reason the pentatonics share theirs — the shape fits both, and what
 * differs between them is the intervals, which is the whole point of choosing.
 */
static const uint8_t SEQ_MARKOV6[6][6] = {
    /* from 1 */ {  7, 12,  4,  7,  9,  5 },
    /* from 2 */ { 13,  6, 11,  5,  6,  4 },
    /* from 3 */ {  8, 12,  5,  9,  7,  4 },
    /* from 4 */ {  6,  5, 12,  5, 10,  6 },
    /* from 5 */ { 10,  5,  6, 11,  6,  8 },
    /* from 6 */ { 14,  4,  4,  6,  9,  5 },
};

static const uint8_t SEQ_MARKOV8[8][8] = {
    /* from 1 */ {  7, 11,  5,  4,  9,  6,  3,  5 },
    /* from 2 */ { 10,  5, 12,  5,  6,  4,  3,  4 },
    /* from 3 */ {  9,  8,  5,  9,  7,  4,  3,  4 },
    /* from 4 */ {  5,  4, 12,  5, 10,  6,  4,  3 },
    /* from 5 */ {  9,  5,  6, 10,  6,  9,  4,  5 },
    /* from 6 */ {  8,  4,  4,  6, 11,  5,  7,  6 },
    /* from 7 */ { 12,  3,  3,  4,  7,  8,  5, 10 },
    /* from 8 */ { 15,  3,  3,  4,  5,  8,  6,  6 },
};

/*
 * Twelve wide, so every semitone is a degree and the row is the whole octave: the step
 * either side is the strong move, the tonic and fifth columns carry the same pull they
 * carry everywhere else, and the far degrees are reachable but rare.
 */
static const uint8_t SEQ_MARKOV12[12][12] = {
    /* from  1 */ {  9, 12,  5,  4,  3,  3,  4,  9,  4,  3,  3,  5 },
    /* from  2 */ { 13,  7, 12,  6,  4,  3,  3,  5,  4,  3,  3,  4 },
    /* from  3 */ {  7, 12,  6, 12,  6,  4,  3,  4,  4,  3,  3,  4 },
    /* from  4 */ {  6,  7, 12,  6, 12,  6,  4,  4,  4,  4,  3,  3 },
    /* from  5 */ {  5,  5,  7, 12,  6, 12,  6,  4,  4,  4,  4,  3 },
    /* from  6 */ {  4,  4,  5,  7, 12,  6, 12,  6,  4,  4,  4,  4 },
    /* from  7 */ {  5,  4,  4,  5,  7, 12,  6, 12,  6,  4,  4,  4 },
    /* from  8 */ { 12,  5,  4,  4,  5,  7, 12,  6, 12,  6,  4,  4 },
    /* from  9 */ {  5, 12,  5,  4,  5,  6,  7, 12,  6, 12,  6,  4 },
    /* from 10 */ {  5,  5, 12,  5,  4,  5,  6,  7, 12,  6, 12,  6 },
    /* from 11 */ {  5,  5,  5, 12,  5,  4,  5,  6,  7, 12,  6, 12 },
    /* from 12 */ { 14,  5,  5,  5,  8,  6,  5,  8,  6,  7,  9,  6 },
};

typedef struct {
    const char    *name;
    const int8_t  *steps;    /* semitone offsets from the root */
    int            len;      /* degrees per octave */
    const uint8_t *markov;   /* len x len, row-major */
} seq_scale_cfg_t;

/*
 * ЛАДЫ В ПОРЯДКЕ БЛАГОЗВУЧНОСТИ.
 *
 * Порядок ручки — это порядок таблицы, и владелец попросил, чтобы он шёл от самого
 * гладкого к самому шершавому: тогда первое положение нащупывается вслепую, а последние
 * два — то, что выбирают сознательно.
 *
 * Критерий — не вкус, а счёт: сколько в ладу полутоновых ходов, и устроен ли тонический
 * аккорд (есть ли над тоникой терция и квинта). Полутоновый ход — самый сильный раздражитель
 * на слух, поэтому он идёт первым числом: ноль полутонов (обе пентатоники) в начале, потом
 * один, потом два, потом три и больше. При равенстве первым стоит лад, у которого тоника
 * держит мажорный или минорный аккорд, а последним — тот, где квинта подменена тритоном
 * (LOCR, DIM): такой лад не шершавый, он без опоры.
 *
 * Отдельно стоят двое. BLUES имеет всего два полутоновых хода, но оба — в самой середине
 * (b5 и blue note), и на слух это не «гладко», а «живо», поэтому он после HIRA, а не после
 * LYD. WHOLE TONE полутонов не имеет вовсе, но и квинты: без дна — это другая беда, чем
 * шершавость, и место ей перед DIM. CHRM последний и не потому, что хуже всех звучит, а
 * потому что это не лад, а квантование без него.
 *
 * ЦЕНА ПОРЯДКА: позиция в этой таблице — сохранённое значение параметра. Перестановка
 * строк значит, что байт SCALE в каждом сохранённом звуке начинает называть другой лад.
 * Поэтому рядом лежит MIG_SCALE_ORDER — старая позиция на новую — и сохранённый звук
 * проходит её один раз: app_settings.c для помнимого патча, app_presets.c для каждой
 * записи в магазине. Без этой пары правка была бы молчаливой подменой, а не сортировкой.
 *
 * Пять восточных ладов (IN-SEN, NIKRIZ, HIJAZ, SABA, PERSIAN) стоят там, куда их положил
 * тот же счёт, а не хвостом и не отдельной группой: NIKRIZ и HIJAZ — мажор с малой секундой
 * или малой секстой, у них три полутоновых хода, и по шкале они рядом с гармоническим
 * минором; SABA и PERSIAN шершавее всех семиступенных здесь и стоят перед WHOLE.
 */
static const seq_scale_cfg_t SEQ_SCALES[] = {
    /* 0 */  { "MN PNT",   SEQ_PENT_MINOR, 5, (const uint8_t *)SEQ_MARKOV5 },
    /* 1 */  { "MJ PNT",   SEQ_PENT_MAJOR, 5, (const uint8_t *)SEQ_MARKOV5 },
    /* 2 */  { "MIX",      SEQ_MIXOLYDIAN, 7, (const uint8_t *)SEQ_MARKOV7 },
    /* 3 */  { "LYD",      SEQ_LYDIAN, 7, (const uint8_t *)SEQ_MARKOV7 },
    /* 4 */  { "M. MIN",   SEQ_MEL_MINOR, 7, (const uint8_t *)SEQ_MARKOV7 },
    /* 5 */  { "IN-SEN",   SEQ_IN_SEN, 5, (const uint8_t *)SEQ_MARKOV5 },
    /* 6 */  { "ION",      SEQ_IONIAN, 7, (const uint8_t *)SEQ_MARKOV7 },
    /* 7 */  { "DOR",      SEQ_DORIAN, 7, (const uint8_t *)SEQ_MARKOV7 },
    /* 8 */  { "AEOL",     SEQ_AEOLIAN, 7, (const uint8_t *)SEQ_MARKOV7 },
    /* 9 */  { "PHRY",     SEQ_PHRYGIAN, 7, (const uint8_t *)SEQ_MARKOV7 },
    /* 10 */ { "HIRA",     SEQ_HIRAJOSHI, 5, (const uint8_t *)SEQ_MARKOV5 },
    /* 11 */ { "BLUES",    SEQ_BLUES, 6, (const uint8_t *)SEQ_MARKOV6 },
    /* 12 */ { "LOCR",     SEQ_LOCRIAN, 7, (const uint8_t *)SEQ_MARKOV7 },
    /* 13 */ { "H. MIN",   SEQ_HARM_MINOR, 7, (const uint8_t *)SEQ_MARKOV7 },
    /* 14 */ { "NIKRIZ",   SEQ_NIKRIZ, 7, (const uint8_t *)SEQ_MARKOV7 },
    /* 15 */ { "HIJAZ",    SEQ_HIJAZ, 7, (const uint8_t *)SEQ_MARKOV7 },
    /* 16 */ { "SABA",     SEQ_SABA, 7, (const uint8_t *)SEQ_MARKOV7 },
    /* 17 */ { "PERSIAN",  SEQ_PERSIAN, 7, (const uint8_t *)SEQ_MARKOV7 },
    /* 18 */ { "WHOLE",    SEQ_WHOLE_TONE, 6, (const uint8_t *)SEQ_MARKOV6 },
    /* 19 */ { "DIM",      SEQ_DIMINISHED, 8, (const uint8_t *)SEQ_MARKOV8 },
    /* 20 */ { "CHRM",     SEQ_CHROMATIC, 12, (const uint8_t *)SEQ_MARKOV12 },
};
#define SEQ_SCALE_COUNT ((int)(sizeof(SEQ_SCALES) / sizeof(SEQ_SCALES[0])))

/* The length is written into app_settings.c as the list the remembered sound is walked
 * through, and into app_presets.c as the list a stored record is walked through, so this is
 * where that number is pinned. See migrate_patch_scale() and migrate_patch_scale_order(). */
static_assert(SEQ_SCALE_COUNT == 21, "app_settings.c and app_presets.c migrate SCALE on 21 scales");

/* -------------------------------------------------------------------------- */
/* Helpers                                                                    */
/* -------------------------------------------------------------------------- */

static uint32_t cents_to_centihz(float hz, float cents)
{
    /* The engine works in centiHertz (Hz x 100) and has no cents helper. */
    const float f = hz * exp2f(cents / 1200.0f);
    return (uint32_t)(f * 100.0f + 0.5f);
}

/* -------------------------------------------------------------------------- */
/* Engine setup — all of this runs before the audio task exists                */
/* -------------------------------------------------------------------------- */

static bool engine_init(void)
{
    s_synth.setControlRateHz(CONTROL_RATE_HZ);

    /* Pull mode: passing a null output callback means the engine creates no
     * task of its own and allocates nothing. Our audio task drives it. */
    if (!s_synth.beginCustom(SYNTH_SAMPLE_RATE, nullptr)) {
        ESP_LOGE(TAG, "beginCustom() failed");
        return false;
    }

    return true;
}

/*
 * Knob position to physical value, and back.
 *
 * The inverse matters as much as the forward mapping: it is what lets the
 * designed defaults be written as 2600 Hz and 380 ms instead of as fractions of a
 * knob that nobody could check by reading them.
 */
static float geom_for(float v01, float lo, float hi)
{
    return lo * exp2f(v01 * log2f(hi / lo));
}

static float geom_v01(float value, float lo, float hi)
{
    if (value <= lo) {
        return 0.0f;
    }
    if (value >= hi) {
        return 1.0f;
    }
    return log2f(value / lo) / log2f(hi / lo);
}

static float lead_fc_for(float v01)  { return geom_for(v01, LEAD_FC_MIN_HZ, LEAD_FC_MAX_HZ); }
static float lead_fc_v01(float hz)   { return geom_v01(hz, LEAD_FC_MIN_HZ, LEAD_FC_MAX_HZ); }
static float lead_q_for(float v01)   { return geom_for(v01, LEAD_Q_MIN, LEAD_Q_MAX); }
static float lead_q_v01(float q)     { return geom_v01(q, LEAD_Q_MIN, LEAD_Q_MAX); }
static float lead_time_for(float v01){ return geom_for(v01, LEAD_TIME_MIN_MS, LEAD_TIME_MAX_MS); }
static float lead_time_v01(float ms) { return geom_v01(ms, LEAD_TIME_MIN_MS, LEAD_TIME_MAX_MS); }

/*
 * The filter envelope's depth, in octaves, for a knob at v01 and a corner at fc: the
 * distance to the stop that side of the knob is heading for, scaled by how far the knob
 * has been turned. A signed number, because the same slot closes the filter when the
 * knob is under the middle — the filter multiplies its corner by 2^(oct * env).
 */
static float lead_env_oct_for(float v01, float fc)
{
    const float p = v01 * 2.0f - 1.0f;               /* -1 .. +1 */
    const float up = log2f(LEAD_FC_CEIL_HZ / fc);
    const float dn = log2f(LEAD_FC_FLOOR_HZ / fc);   /* negative: the stop is below */

    return ((p >= 0.0f) ? up : dn) * fabsf(p);
}

/*
 * The position that keeps a patch saved before the knob meant a percentage exactly as it
 * sounded: LEAD_ENV_DEFAULT_OCT octaves at the factory corner. It is the one place the
 * old scale still has a meaning, and it is the default.
 */
static float lead_env_v01_for(float octaves, float fc)
{
    const float up = log2f(LEAD_FC_CEIL_HZ / fc);

    return 0.5f + 0.5f * (octaves / up);
}

static float chorus_rate_for(float v01) { return geom_for(v01, CHORUS_RATE_MIN_HZ, CHORUS_RATE_MAX_HZ); }
static float chorus_rate_v01(float hz)  { return geom_v01(hz, CHORUS_RATE_MIN_HZ, CHORUS_RATE_MAX_HZ); }
/* Миллисекунды положения слитой ручки: step 0 — DELAY_MIN_MS, step 15 — DELAY_MAX_MS. */
static float delay_ms_step(int step)
{
    if (step < 0) {
        step = 0;
    } else if (step > DELAY_MS_STEPS - 1) {
        step = DELAY_MS_STEPS - 1;
    }

    return geom_for((float)step / (float)(DELAY_MS_STEPS - 1), DELAY_MIN_MS, DELAY_MAX_MS);
}

static float delay_ms_for(float v01)    { return geom_for(v01, DELAY_MIN_MS, DELAY_MAX_MS); }
static float delay_ms_v01(float ms)     { return geom_v01(ms, DELAY_MIN_MS, DELAY_MAX_MS); }

/*
 * How much of a beat each of those lasts. A dotted entry is one and a half of its
 * neighbour — 1/2. is a dotted half, three beats — and 1/8T is the eighth triplet, so
 * it sits between the dotted sixteenth and the sixteenth rather than in size order.
 * Index 0 is FREE and lasts no beats at all: delay_ms_now() never reads it.
 */
static const float DELAY_DIV_BEATS[DELAY_DIV_COUNT] = {
    [DELAY_DIV_FREE]     = 0.0f,
    [DELAY_DIV_1_1]      = 4.0f,
    [DELAY_DIV_1_2_DOT]  = 3.0f,
    [DELAY_DIV_1_2]      = 2.0f,
    [DELAY_DIV_1_4_DOT]  = 1.5f,
    [DELAY_DIV_1_4]      = 1.0f,
    [DELAY_DIV_1_8_DOT]  = 0.75f,
    [DELAY_DIV_1_8]      = 0.5f,
    [DELAY_DIV_1_16_DOT] = 0.375f,
    [DELAY_DIV_1_8_T]    = 1.0f / 3.0f,
    [DELAY_DIV_1_16]     = 0.25f,
    [DELAY_DIV_1_32]     = 0.125f,
};

static void buses_init(void)
{
    /* Every layer gets a pan capture in slot 1. Slot 0 takes the drone filter on the
     * three drone buses, the lead's filter on the lead bus and the microphone's input
     * on the AUX bus, below; slot 2 is unused for now. The order matters within a bus:
     * slot 0 runs first, so what slot 1 captures is a bus that already has that
     * contribution in it. */
    for (int layer = 0; layer < SYNTH_NUM_LAYERS; layer++) {
        const uint8_t bus = (uint8_t)(layer + 1);

        s_synth.setBusFX(bus, 1, FX_CUSTOM, synth_fx_pan_capture);
        s_synth.setBusFXParam(bus, 1, 7, (int16_t)layer);
        s_synth.setBusFXParam(bus, 1, 6, 1);          /* enable */

        /* ШИНЫ АККОРДА: три ноты — три места в стерео.
         *
         * Ноты аккорда звучат одним событием, поэтому в одной моно-шине их не развести.
         * Движок умеет отдать каждую группу голосов в свою шину (setVoiceBus), и шины 7, 8,
         * 9 отданы трём нотам: каждая проходит свой захват панорамы и пишет в ТОТ ЖЕ слой
         * лида, потому что слой — это фейдер и посылы, а не место в стерео. Канал состояния
         * у каждой свой: 6, 7, 8 (см. PAN_CHANNELS в synth_pan_capture.cpp). */
        if (layer == SYNTH_LAYER_LEAD) {
            for (int c = 0; c < LEAD_CHORD_NOTES; c++) {
                const uint8_t cb = (uint8_t)(LEAD_CHORD_BUS0 + c);

                /* Фильтр лида — на каждой шине аккорда: без него в аккорде не работали ни
                 * CUTOFF, ни RES, ни ENV, ни SHAPE, ни K.TRCK, ни MODE. */
                /* Фильтра на шинах больше нет: он один, на сумме слоя. Здесь остаётся
                 * только захват панорамы — он и разводит ноты аккорда по стерео. */
                s_synth.setBusFX(cb, 1, FX_CUSTOM, synth_fx_pan_capture);
                s_synth.setBusFXParam(cb, 1, 7, (int16_t)(SYNTH_NUM_LAYERS + c));
                s_synth.setBusFXParam(cb, 1, 6, 1);
                s_synth.setBusMix(cb, 255);
                s_synth.setBusFXParam(cb, 1, 0, 0);   /* панорама: центр, пока ручка не двинута */
            }
        }

        /* mixLevel 255 is x0.99609, not unity — the engine's bus sum is
         * dst += (src * mixLevel) >> 8. Irrelevant here because we discard the
         * engine's master output, but the level has to be non-zero: a bus with
         * mixLevel 0 is skipped entirely, FX chain included. */
        s_synth.setBusMix(bus, 255);
    }

    for (int r = 0; r < DRONE_REGISTERS; r++) {
        const drone_register_cfg_t *cfg = &s_drones[r];
        const uint8_t bus = (uint8_t)(cfg->layer + 1);

        /* setBusFX() memsets ep[] and es[], so parameters must come after it. */
        s_synth.setBusFX(bus, 0, FX_CUSTOM, synth_fx_drone_filter);
        s_synth.setBusFXParam(bus, 0, 0, cfg->fc_hz);
        s_synth.setBusFXParam(bus, 0, 1, cfg->q_x100);
        s_synth.setBusFXParam(bus, 0, 2, cfg->lfo_mhz);
        s_synth.setBusFXParam(bus, 0, 3, cfg->lfo_depth_centioct);
        s_synth.setBusFXParam(bus, 0, 4, 0);          /* low pass */
        s_synth.setBusFXParam(bus, 0, 5, cfg->lfo_shape);
        s_synth.setBusFXParam(bus, 0, 6, 1);          /* enable */
        s_synth.setBusFXParam(bus, 0, 7, (int16_t)cfg->layer);

        s_synth.setBusFXParam(bus, 1, 0, cfg->pan_base);
        s_synth.setBusFXParam(bus, 1, 1, cfg->pan_depth);
        s_synth.setBusFXParam(bus, 1, 2, cfg->pan_rate1_mhz);
        s_synth.setBusFXParam(bus, 1, 3, cfg->pan_rate2_mhz);
        s_synth.setBusFXParam(bus, 1, 4, cfg->walk_ms);
        s_synth.setBusFXParam(bus, 1, 5, cfg->walk_depth);

        synth_rack_set_layer_level(cfg->layer, cfg->rack_level);
    }

    /* Lead: pan only, and gently. */
    const uint8_t lead_bus = (uint8_t)(SYNTH_LAYER_LEAD + 1);
    /*
     * Lead: its own filter in slot 0, and pan in slot 1 — which has to stay last,
     * because the pan capture in it is what the stereo image is read from.
     *
     * The gate starts released. apply_pending_params() overwrites every one of
     * these on the first block anyway (s_applied[] starts at -1), so this is the
     * state the engine is in for the few microseconds before that, and it is the
     * designed voicing rather than zero — a lead with a cutoff of zero would be
     * silent if anything ever did start the audio task ahead of that pass.
     */
    /*
     * ФИЛЬТР ЛИДА ЖИВЁТ В СТОЙКЕ, НА СУММЕ СЛОЯ (synth_lead_filter_layer): панорама каждой
     * ноты ставится до него, а фильтруется уже собранный слой. На шине слоя остаётся только
     * захват панорамы.
     *
     * Заводские значения заданы здесь же, прямым сеттером, чтобы первый блок после запуска
     * звучал как задумано.
     */
    synth_lead_filter_param(0, (int16_t)LEAD_FC_DEFAULT_HZ);
    synth_lead_filter_param(1, (int16_t)(LEAD_Q_DEFAULT * 100.0f));
    synth_lead_filter_param(2, (int16_t)(LEAD_ENV_DEFAULT_OCT * 100.0f));
    synth_lead_filter_param(3, (int16_t)LEAD_AMP_ATTACK_DEFAULT_MS);
    synth_lead_filter_param(4, 0);   /* счётчик нот, до первой ноты ноль */
    synth_lead_filter_param(5, 0);   /* низкопропускной, заводская форма */
    synth_lead_filter_param(6, (int16_t)LEAD_AMP_RELEASE_DEFAULT_MS);
    synth_lead_filter_param(7, 0);   /* заслонка закрыта */

    s_synth.setBusFXParam(lead_bus, 1, 0, 0);
    s_synth.setBusFXParam(lead_bus, 1, 1, LEAD_PAN_DEPTH);
    s_synth.setBusFXParam(lead_bus, 1, 2, LEAD_PAN_RATE1_MHZ);
    s_synth.setBusFXParam(lead_bus, 1, 3, LEAD_PAN_RATE2_MHZ);
    s_synth.setBusFXParam(lead_bus, 1, 4, LEAD_WALK_MS);
    s_synth.setBusFXParam(lead_bus, 1, 5, 800);
    synth_rack_set_layer_level(SYNTH_LAYER_LEAD, 0.25f);

    /*
     * THE AUX LAYER CARRIES NOTHING NOW, and the microphone's input FX is no longer
     * registered on it.
     *
     * The microphone used to arrive here as slot 0 of this bus and leave again through its
     * three sends; the owner took it out of the sends, so the input has no path to the rack
     * at all and the slot is not wired. The layer keeps its LEVEL at zero and keeps its three
     * sends at zero below, so the bus is silent by construction rather than by a knob being
     * down — a stored patch with a microphone send in it cannot make it audible again.
     *
     * What the microphone still does is modulate: mic_process_block() computes its envelope
     * and publish_mic_mod() hands it to the DSP, which is where the MIC shape of the LFO
     * lives. That is the whole of its remaining job, and it costs no bus.
     */
    synth_rack_set_layer_level(SYNTH_LAYER_AUX, 0.0f);
}

static void voices_init(void)
{
    for (int r = 0; r < DRONE_REGISTERS; r++) {
        const drone_register_cfg_t *cfg = &s_drones[r];
        const uint8_t bus = (uint8_t)(cfg->layer + 1);

        for (int v = 0; v < DRONE_VOICES_PER_REGISTER; v++) {
            const uint16_t voice = (uint16_t)(cfg->first_voice + v);

            /* AA_Saw, not the engine's built-in WAVE_SAW: the built-in saw is a
             * naive ramp and aliases badly. PolyBLEP lives only in the patches,
             * and a drone held for minutes is exactly where aliasing is
             * unforgivable. */
            s_synth.setCustomWave(voice, ESP32Patches::AA_Saw);
            s_synth.setEnv(voice, DRONE_ATTACK_MS, DRONE_DECAY_MS,
                           DRONE_SUSTAIN, DRONE_RELEASE_MS);
            s_synth.setSmoothEnv(voice, true);
            s_synth.setVoiceBus(voice, bus);
            s_synth.noteOn(voice, cents_to_centihz(cfg->base_hz,
                                                   wave_detune(cfg->detune_cents[v],
                                                               s_drone_super[r])),
                           cfg->volume);
        }
    }

    /* LEAD_CONFIGURED_VOICES and not LEAD_VOICES: the arp's own group is a lead
     * group in everything but ownership, so it is given the lead's wave, envelope
     * and bus here. It is never opened from this function, and a voice that is
     * never opened renders nothing at all, so the extra three cost the instrument
     * no sound — see the layout comment at the top of the file. */
    for (int v = 0; v < LEAD_CONFIGURED_VOICES; v++) {
        const uint16_t voice = (uint16_t)(LEAD_VOICE_BASE + v);

        s_synth.setCustomWave(voice, ESP32Patches::AA_Saw);
        /* Fast, because these voices are now played rather than held. The
         * drone's two-and-a-half second attack belongs to a sound you sit
         * inside; a melody needs the note to arrive when it is asked for. */
        /* The four numbers the amplitude envelope was hard-wired to before its page
         * existed. From the first block the four knobs own them; this is the state the
         * engine is in before that pass, and it is the designed voicing rather than
         * zero. */
        s_synth.setEnv(voice, (uint16_t)LEAD_AMP_ATTACK_DEFAULT_MS,
                       (uint16_t)LEAD_AMP_DECAY_DEFAULT_MS,
                       (uint8_t)(LEAD_AMP_SUSTAIN_DEFAULT * 255.0f + 0.5f),
                       (uint16_t)LEAD_AMP_RELEASE_DEFAULT_MS);
        s_synth.setSmoothEnv(voice, true);
        s_synth.setVoiceBus(voice, (uint8_t)(SYNTH_LAYER_LEAD + 1));

        /* Deliberately NOT noteOn(). These voices used to be held on forever as
         * a static chord. They are gated by the sequencer now, and starting one
         * here would leave a note sounding that nothing could ever release. */
    }
}

/* -------------------------------------------------------------------------- */
/* Control surface — the mapping from a knob to an engine value               */
/* -------------------------------------------------------------------------- */
/*
 * Each function below is the single definition of what one parameter means, and
 * both the audio task and synth_app_param_text() go through it. That is what
 * keeps the number on the screen equal to the number in the filter.
 *
 * All of them are written so that the parameter's DEFAULT returns the designed
 * value exactly, which is why the defaults are 0.5 for a scaled quantity and 0.0
 * for one that is by definition a deviation from the design.
 */

/* Exponential rather than linear: the ear hears frequency logarithmically, so a
 * linear knob would crawl through the useful range and then race through the
 * rest. */
static int32_t cutoff_for(const drone_register_cfg_t *cfg, float v01)
{
    const float mult = exp2f((v01 - 0.5f) * 2.0f * CUTOFF_MACRO_OCTAVES);

    /* In float and clamped BEFORE the rounding, so the floor is the frequency it names:
     * LOW's bottom of travel is exactly 37.5, which is not below it, and what comes out is
     * the 38 the readout prints. Rounding first and clamping after — which is what this did
     * — turns a fractional floor into one whole hertz below itself. The top is unchanged:
     * 16000 is whole, so both orders land on it. */
    float fc = (float)cfg->fc_hz * mult;
    if (fc < DRONE_CUTOFF_MIN_HZ) {
        fc = DRONE_CUTOFF_MIN_HZ;
    } else if (fc > DRONE_CUTOFF_MAX_HZ) {
        fc = DRONE_CUTOFF_MAX_HZ;
    }
    return (int32_t)(fc + 0.5f);
}

static int32_t resonance_for(const drone_register_cfg_t *cfg, float v01)
{
    float q = (float)cfg->q_x100 * 0.01f * exp2f(v01 * RESONANCE_RANGE_EXP);
    if (q > 20.0f) {
        q = 20.0f;
    }
    return (int32_t)(q * 100.0f + 0.5f);
}

static int32_t filter_rate_for(const drone_register_cfg_t *cfg, float v01)
{
    float mhz = (float)cfg->lfo_mhz * exp2f(v01 * FILTER_RATE_RANGE_EXP);
    if (mhz > 20000.0f) {
        mhz = 20000.0f;
    }
    return (int32_t)(mhz + 0.5f);
}

/* FILTER_DEPTH_AT_FULL, not DEPTH_AT_FULL: the two depths share a shape and nothing
 * else. The pan's multiplier is bounded by the pan stage's own ceiling and the filter's
 * is not, so deepening the filter must not drag the pan along — see the two constants. */
static int32_t filter_depth_for(const drone_register_cfg_t *cfg, float v01)
{
    float d = (float)cfg->lfo_depth_centioct * v01 * FILTER_DEPTH_AT_FULL;
    if (d > (float)FILTER_DEPTH_MAX_CENTIOCT) {
        d = (float)FILTER_DEPTH_MAX_CENTIOCT;
    }
    return (int32_t)(d + 0.5f);
}

/* The motion parameters take their designed value as an argument rather than a
 * register config, because the lead shares them and has no config struct. */
static int32_t motion_depth_for(int base, float v01)
{
    float d = (float)base * v01 * DEPTH_AT_FULL;
    if (d > 1000.0f) {
        d = 1000.0f;
    }
    return (int32_t)(d + 0.5f);
}

static int32_t motion_rate_for(int base_mhz, float v01)
{
    float mhz = (float)base_mhz * exp2f(v01 * MOTION_RATE_RANGE_EXP);
    if (mhz > 20000.0f) {
        mhz = 20000.0f;
    }
    return (int32_t)(mhz + 0.5f);
}

/* The random walk gets faster with the LFOs but not as fast: it is what keeps
 * the drift from repeating, and a walk that retargets as quickly as the LFOs
 * cycle stops being a walk and becomes noise. */
static int32_t motion_walk_for(int base_ms, float v01)
{
    float ms = (float)base_ms / exp2f(v01 * MOTION_WALK_RANGE_EXP);
    if (ms < 200.0f) {
        ms = 200.0f;
    }
    return (int32_t)(ms + 0.5f);
}

/* -------------------------------------------------------------------------- */
/* Control surface — applied on the audio task                                */
/* -------------------------------------------------------------------------- */

/*
 * LEVEL is the rack's master gain, and play and stop is the rack's INPUT gate —
 * two separate controls on purpose.
 *
 * Writing the gate rather than the gain means there is no second piece of state
 * to fall out of step with the knob: stop, change the level, start, and the
 * volume is wherever the knob now points. And because the gate is at the input
 * and not on the gain, stopping the generators leaves the delay repeats and the
 * reverb tail to decay instead of cutting them off mid-air.
 *
 * WHAT THE GATE ANSWERS TO IS NO LONGER THE TRANSPORT ALONE. A note arriving over USB
 * MIDI has to be audible with the transport stopped — that is most of what an input is
 * for — so the gate is opened by the audio task while an external note is held or its
 * tail is still alive, transport or no transport. STOP is then enforced where it
 * belongs: the sequencer and the arpeggiator open no notes and the drum strikes nothing
 * while it is stopped, each of them explicitly (see seq_trigger(), arp_tick() and
 * perc_tick()), and the transport position is frozen rather than reset, so CONTINUE
 * resumes the phrase where STOP left it instead of starting it again.
 * ONE THING IS NOT THE TRANSPORT'S and so is not silenced with it: the arp's figure over
 * keys the player is holding, which is the player's hand rather than the machine's clock
 * — see arp_tick(), and tp_advance() for the one case that moves the position while the
 * transport is stopped. The gate is open for it either way, because a key is down.
 * The gate itself is written once per block by midi_gate_tick(), which is where the
 * whole rule is written down.
 */
static void apply_fx_tempo(void);

/* Доли клока для режима кольца TEMPO: счётчик и его аккумулятор. */
static volatile uint32_t s_beat_count;
static float s_beat_acc;

static bool s_running = true;

/*
 * Пуск с первого шага, поставленный панелью и снятый здесь. Атомарный, потому что пишет его
 * задача интерфейса на нулевом ядре, а читает задача звука на первом — как и кольцо MIDI,
 * только без самого кольца: требование одно и его достаточно, двух подряд пусков с первого
 * шага не бывает.
 */
static std::atomic<bool> s_restart_req{false};

static void apply_level(float v01)
{
    synth_rack_set_master(MASTER_AT_FULL_SCALE * v01);
}

static void apply_comp(float v01)
{
    synth_rack_set_comp(v01);
}

/*
 * ЧТО ДЕЛАТЬ ПРИ ВКЛЮЧЕНИИ.
 *
 * ON — играем сразу, как прибор и вёл себя до этой настройки; OFF — включаемся молча;
 * STORE — возвращаем то состояние транспорта, в котором прибор выключили.
 */
extern "C" void synth_app_autoplay_apply(void)
{
    const int mode = app_settings_get(APP_SET_AUTOPLAY);

    ESP_LOGI(TAG, "autoplay: mode %d, stored transport %d", mode,
             app_settings_get(APP_SET_TRANSPORT));

    if (mode == 1) {
        s_running = false;
    } else if (mode == 2) {
        s_running = (app_settings_get(APP_SET_TRANSPORT) != 0);
    } else {
        s_running = true;
    }

    apply_level(s_param[SYNTH_PARAM_LEVEL]);
    apply_fx_tempo();
}

extern "C" void synth_app_set_running(int on)
{
    /* The gate is NOT written here any more: it is the audio task's own, because it
     * depends on what the MIDI input is holding as well as on the transport, and the
     * audio task is the only side that owns that state. This flag is read there on the
     * next block, 2.7 ms later — less than the time it takes a finger to leave a button.
     *
     * LEVEL is still applied here, straight through the applier rather than through the
     * change queue, so a stop and a start always return the volume the knob points at
     * rather than waiting for the parameter to differ from its cached value, which it
     * does not. */
    s_running = (on != 0);

    /* Пока играем — патч в памяти не трогаем: запись стоит звуку нескольких миллисекунд. */
    app_settings_patch_hold(s_running);

    /*
     * STORE ПОМНИТ СОСТОЯНИЕ ТРАНСПОРТА. Пишется при каждом изменении, а не только при
     * выключении: выключение бывает и аварийным, и тогда записать было бы некому.
     */
    if (app_settings_get(APP_SET_AUTOPLAY) == 2) {
        app_settings_set(APP_SET_TRANSPORT, s_running ? 1 : 0);
    }

    apply_level(s_param[SYNTH_PARAM_LEVEL]);
    apply_fx_tempo();
}

extern "C" int synth_app_is_running(void)
{
    return s_running ? 1 : 0;
}

extern "C" void synth_app_transport_restart(void)
{
    /* Флаг транспорта ставится сразу: кнопка обязана отозваться на нажатие в том же кадре.
     * Сброс позиции — на следующем блоке, 2.7 мс, на задаче, которая владеет движком; здесь
     * двигать счётчики шагов нельзя. */
    s_running = true;
    app_settings_patch_hold(true);

    /* STORE помнит и этот путь: PLAY/STOP идёт через рестарт, а не через set_running. */
    if (app_settings_get(APP_SET_AUTOPLAY) == 2) {
        app_settings_set(APP_SET_TRANSPORT, 1);
    }

    s_restart_req.store(true, std::memory_order_release);
    apply_level(s_param[SYNTH_PARAM_LEVEL]);
    apply_fx_tempo();

    /* Начало такта: кольцо снова бьёт по доле с начала. */
    s_beat_acc = 0.0f;
    s_beat_count = 0u;
}

/* Both key trackers are computed where the pitch they follow is known — the drone's shift and
 * the lead's newest note — and consumed here, by the two cutoff appliers. The forward
 * declarations are because those places are further down the file than the appliers, the same
 * shape mod_value() and lfo_shape_index() are declared in above. */
static float drone_filter_track_mult(void);
static float lead_filter_track_mult(void);

/* Все шины лида: фильтр лида обязан стоять на каждой — в режиме CHORD ноты уходят на три
 * шины аккорда. Определена ниже, зовётся из applier'ов выше. */
static void lead_filter_slot(uint8_t slot, uint8_t id, int16_t value);
static void apply_lead_cutoff(float v01);
static void apply_lead_reso(float v01);
static void apply_lead_env(float v01);
static void apply_lead_filter_mode(float v01);
static void lead_fenv_times_apply(void);

/*
 * The cutoff a drone register's filter actually gets: the knob's frequency times the key
 * tracker, clamped to the top of the band the filter itself uses.
 *
 * The multiplication is done in float BEFORE the rounding, so at k=0 the number is exactly
 * cutoff_for()'s — the tracker is bit-transparent at its factory zero. At k>0 the clamp is the
 * same DRONE_CUTOFF_MAX_HZ the knob's own travel stops at: a corner above 16 kHz is outside the
 * band this filter was designed for, and letting the product through would overflow the int16
 * slot the engine takes it in.
 */
static int32_t drone_cutoff_tracked(const drone_register_cfg_t *cfg, float v01)
{
    float fc = (float)cutoff_for(cfg, v01) * drone_filter_track_mult();

    if (fc > DRONE_CUTOFF_MAX_HZ) {
        fc = DRONE_CUTOFF_MAX_HZ;
    }
    return (int32_t)(fc + 0.5f);
}

static void apply_cutoff(float v01)
{
    for (int r = 0; r < DRONE_REGISTERS; r++) {
        const drone_register_cfg_t *cfg = &s_drones[r];

        /* Sub-slot 0 is the drone filter, parameter 0 is the cutoff. Writing it
         * from the audio task is safe: the render path this feeds runs on this
         * same task. */
        s_synth.setBusFXParam((uint8_t)(cfg->layer + 1), 0, 0,
                              (int16_t)drone_cutoff_tracked(cfg, v01));
    }
}

static void apply_resonance(float v01)
{
    for (int r = 0; r < DRONE_REGISTERS; r++) {
        const drone_register_cfg_t *cfg = &s_drones[r];
        s_synth.setBusFXParam((uint8_t)(cfg->layer + 1), 0, 1,
                              (int16_t)resonance_for(cfg, v01));
    }
}
/*
 * FILTER MODE. The slot takes percent, and the filter reads it as a cross-fade
 * between the low, band and high outputs of its own state: 0, 50 and 100 are the
 * three shapes, and everything between is a mix of the neighbours. Zero is passed
 * through untouched — no blend, no rounding — so a patch saved before the knob
 * existed renders bit for bit as it did.
 */
static void apply_filter_mode(float v01)
{
    const int mode = (int)(v01 * 100.0f + 0.5f);
    for (int r = 0; r < DRONE_REGISTERS; r++) {
        const drone_register_cfg_t *cfg = &s_drones[r];
        s_synth.setBusFXParam((uint8_t)(cfg->layer + 1), 0, 4, (int16_t)mode);
    }
}

static void apply_lead_filter_mode(float v01)
{
    const int mode = (int)(v01 * 100.0f + 0.5f);
    lead_filter_slot(0, 5, (int16_t)mode);
}

static void apply_motion_depth(float v01);
static void apply_perc(void);
static void apply_bass(void);
static void apply_bass_root(void);
static uint16_t accent_mask_of(synth_param_t param);   /* defined with the figures below */
static void apply_bass_tempo(void);
static float seq_tempo_now(void);   /* defined with the clock below; the bass follows it */
static void perc_show_written(void);   /* defined with the drum section, called from apply_perc */
static float mod_value_ch(int ch);
static uint32_t mod_dest_bits_of(synth_param_t p);
static float mod_sum01(uint32_t bit);
static float mod_depth_sum(uint32_t bit);
static float depth_pm(synth_param_t param);
static float mod_sum_pm(uint32_t bit);   /* defined below: the destination republishes it */
static float mod_value(void);
static int lfo_shape_index(void);   /* defined with the generator below; SHAPE is read here too */
static int lfo_shape_slot(int ch);
static float clamp01f(float v);     /* defined with the generator below; apply_mic() is above it */


/* The order of the DEST list, nothing else: three that move the drone, four for the
 * percussion, and two for the pitch of the lead step. */
/*
 * WHERE THE MODULATION GOES: ONE TABLE. The routing, the readout and the destination knob all
 * read it, so a combination is one entry with two or three bits and never a special case in
 * the audio path.
 *
 * It used to be index arithmetic — `== 0 || == 2` for the filter, `>= 9 && <= 11` for the drum's
 * material knob — and it drifted out of step with the names: when that knob arrived, its three
 * entries were written into the list ahead of LEAD's while the routing kept the old order, so
 * two of the twelve destinations made one sound while the readout said another. A table of names beside
 * their bits cannot drift that way, and the extra combinations this page now has are rows in
 * the same table.
 */
enum {
    MD_FILTER = 1u << 0,    /* the drone registers' corner, through FILTER_DEPTH_SHARE */
    MD_PAN    = 1u << 1,    /* the drone's pan and the lead's */
    MD_LEAD   = 1u << 2,    /* the lead's step */
    MD_PITCH  = 1u << 3,    /* the drum's pitch */
    MD_ENV    = 1u << 4,    /* the drum's fall */
    MD_DEC    = 1u << 5,    /* the drum's decay */
    MD_PUNCH  = 1u << 6,    /* the drum's attack, the knob the page calls PUNCH */
    MD_RATE   = 1u << 7,    /* the drone filter's LFO rate — RATE from the FILTER page */
    /*
     * УРОВЕНЬ ДРОНА как приёмник. У дрона двигалось всё, кроме собственно громкости:
     * панорама, обрезной, скорость, — то есть пространство и тембр, но не дыхание.
     * С этим битом LFO раздела MOD качает уровень всех трёх регистров сразу: они громче и
     * тише вместе, потому что дышит фундамент, а не отдельный голос.
     */
    MD_LEVEL  = 1u << 8,
    /* СИММЕТРИЯ ИМПУЛЬСА как приёмник: ручка PW у лида — единственное место, где ширина
     * импульса что-то значит, поэтому и приёмник один. */
    MD_PW     = 1u << 9,
    /*
     * ПЯТЬ НОВЫХ ПРИЁМНИКОВ. Все — непрерывные величины, поэтому модулируются так же, как
     * остальные: базовая величина ручки плюс вклад LFO с учётом глубины, и пересчёт раз в
     * блок, пока приёмник выбран.
     */
    MD_RESO     = 1u << 10,   /* резонанс обхода фильтра дрона */
    MD_LEAD_FC  = 1u << 11,   /* обрезной лида */
    MD_RV_MIX   = 1u << 12,   /* доля реверба */
    MD_DL_MIX   = 1u << 13,   /* доля задержки */
    MD_FX_MIX   = 1u << 14    /* доля эффект-машины */
};

typedef struct {
    const char *name;
    uint16_t    bits;
} mod_dest_t;

static const mod_dest_t MOD_DESTS[] = {
    /*
     * ОДНА ПОЗИЦИЯ — ОДИН ПРИЁМНИК, И ПОРЯДОК — ПО СЕМЕЙСТВАМ.
     *
     * Составных строк («фильтр и пан вместе») здесь нет: складывать модуляции можно двумя
     * приёмниками одного LFO или двумя LFO на одном приёмнике.
     *
     * Имена сокращены до семи знаков, чтобы влезать в сектор, но с префиксом семейства:
     * ручка идёт подряд по дрону, лиду, ударке и эффектам, и по первым двум буквам сразу
     * видно, куда модуляция пойдёт. Порядок таблицы — порядок ручки, поэтому семейства не
     * должны перемешиваться.
     */
    { "OFF",      0u },

    /* ДРОН: обход фильтра, его резонанс и скорость свипа, панорама, громкость. */
    { "DR.CUT",   MD_FILTER },
    { "DR.RES",   MD_RESO },
    { "DR.PAN",   MD_PAN },
    { "DR.LVL",   MD_LEVEL },
    { "DR.F.RT",  MD_RATE },

    /* ЛИД: высота шага, ширина импульса, обрезной фильтра. */
    { "LD.PTCH",  MD_LEAD },
    { "LD.PW",    MD_PW },
    { "LD.CUT",   MD_LEAD_FC },

    /* УДАРКА: высота, огибающая, затухание, атака. */
    { "PC.PTCH",  MD_PITCH },
    { "PC.ENV",   MD_ENV },
    { "PC.DEC",   MD_DEC },
    { "PC.PNCH",  MD_PUNCH },

    /* ЭФФЕКТЫ: доля машины, реверба и задержки. */
    { "FX.MIX",   MD_FX_MIX },
    { "RV.MIX",   MD_RV_MIX },
    { "DLY.MIX",  MD_DL_MIX }
};

#define MOD_DEST_COUNT ((int)(sizeof(MOD_DESTS) / sizeof(MOD_DESTS[0])))

/* Два выбора. FILTER и PAN по умолчанию — это прежнее FILT+PAN, тот же звук на загрузке. */
static int s_mod_dest = 1;
static int s_mod_dest2 = 2;


static uint16_t mod_dest_pick(int d)
{
    if (d < 0) {
        d = 0;
    } else if (d >= MOD_DEST_COUNT) {
        d = MOD_DEST_COUNT - 1;
    }
    return MOD_DESTS[d].bits;
}

/*
 * ЧТО ПОКАЗЫВАТЬ НА ОБОДЕ СТРАНИЦЫ LFO.
 *
 * Значение канала, умноженное на его глубину в том приёмнике, который выбран: при нуле
 * глубины — ноль (ровная линия), при полной — полный размах формы. Глубина берётся из СВОЕЙ
 * страницы этого LFO (DEPTH и DEPTH2), а не из ручек фильтра и панорамы: иначе индикация
 * жила бы своей жизнью.
 */

/*
 * БИПОЛЯРНАЯ ШКАЛА: значение ходит вокруг нуля.
 *
 * Сейчас это обе глубины каждого LFO: они двусторонние, середина хода — ноль. Индикатор
 * такой ручки заливает насечки от СЕРЕДИНЫ дуги: в плюс по часовой, в минус против.
 */
extern "C" bool synth_app_param_bipolar(synth_param_t p)
{
    return p == SYNTH_PARAM_MOD_DEPTH || p == SYNTH_PARAM_MOD_DEPTH2 ||
           p == SYNTH_PARAM_MOD2_DEPTH || p == SYNTH_PARAM_MOD2_DEPTH2 ||
           /* LEAD TONE: глубина огибающей и её форма ходят вокруг середины. */
           p == SYNTH_PARAM_LEAD_ENV || p == SYNTH_PARAM_LEAD_FENV_SHAPE;
}

extern "C" float synth_app_lfo_viz(int ch, int which)
{
    if (ch < 0 || ch > 1) {
        return 0.0f;
    }

    const bool first = (ch == 0);

    /*
     * ГЛУБИНА ПО ПРИЁМНИКУ, А НЕ НА КАНАЛ.
     *
     * Сектор DEST показывает вклад первого приёмника (DEPTH), сектор DEST2 — второго
     * (DEPTH2). Раньше здесь стояла сумма, и увеличение DEPTH2 двигало оба индикатора
     * сразу — это и было ошибкой.
     */
    const synth_param_t param = first
        ? (which ? SYNTH_PARAM_MOD_DEPTH2 : SYNTH_PARAM_MOD_DEPTH)
        : (which ? SYNTH_PARAM_MOD2_DEPTH2 : SYNTH_PARAM_MOD2_DEPTH);

    /* Глубина со знаком: при отрицательной полоса идёт в противофазе. */
    return mod_value_ch(ch) * depth_pm(param);
}

/*
 * Сколько глубины вообще приходится на приёмник: сумма обоих LFO плюс собственная ручка
 * подсистемы. Нужно индикации: при нуле она обязана стоять, даже если её генератор идёт.
 */
extern "C" float synth_app_mod_depth_for(int what)
{
    if (what == 0) {
        return mod_depth_sum(MD_FILTER) + clamp01f(s_param[SYNTH_PARAM_FILTER_DEPTH]);
    }
    return mod_depth_sum(MD_PAN) + clamp01f(s_param[SYNTH_PARAM_MOTION_DEPTH]);
}

/* Биты адресата из самого параметра — так их читают оба LFO: у второго нет своих индексов. */
static uint32_t mod_dest_bits_of(synth_param_t p)
{
    const float raw = s_param[p];
    const float v = (raw >= 0.0f) ? ((raw > 1.0f) ? 1.0f : raw) : 0.0f;
    const int d = (int)(v * (float)(MOD_DEST_COUNT - 1) + 0.5f);

    return mod_dest_pick(d);
}

/*
 * СУММА ДВУХ ВЫБОРОВ, И НЕ БОЛЬШЕ ЧЕТЫРЁХ.
 *
 * Биты просто складываются: одна и та же пара в обоих списках не удваивает зондирование, а
 * один приёмник, выбранный дважды, остаётся одним. Потолок в четыре — по числу мест, которые
 * вообще слышны вместе, — держит крайний случай (обе ручки на четырёхбитной паре).
 */
static uint16_t mod_dest_bits(void)
{
    uint16_t bits = (uint16_t)(mod_dest_pick(s_mod_dest) | mod_dest_pick(s_mod_dest2));

    int count = 0;
    for (int b = 0; b < 16; b++) {
        if ((bits >> b) & 1u) {
            count++;
        }
    }

    /* Overflow: the lowest four survive, the rest are dropped — arbitrary but stable, and it
     * can only be reached by asking for more than the instrument has places. */
    if (count > 4) {
        uint16_t kept = 0u;
        int n = 0;
        for (int b = 0; b < 8 && n < 4; b++) {
            if ((bits >> b) & 1u) {
                kept = (uint16_t)(kept | (1u << b));
                n++;
            }
        }
        bits = kept;
    }
    return bits;
}

/*
 * ФИЛЬТР — ПРИЁМНИК, А НЕ ВЛАДЕНИЕ.
 *
 * У дрона два независимых модулятора: собственный, со страницы DRONE FLTR (его RATE,
 * DEPTH и форма — только его), и раздел LFO. Когда адресатом выбран FILTER, второй
 * добавляет к глубине первого половину своей DEPTH — то есть их влияние СКЛАДЫВАЕТСЯ, и
 * патч может открыть развёртку с любой из двух страниц или с обеих.
 *
 * Половина, а не целое: так ход DEPTH раздела LFO что-то значит при любой глубине
 * фильтра, и ни одна страница не показывает число, которого нет в двигателе. Сумма
 * держится на FILTER_DEPTH_SUM_MAX — ровно DEPTH 1.0 + половина DEPTH, то есть потолок
 * достижим только обеими ручками наверху.
 *
 * И РЕШАЮЩЕЕ: множитель — DEPTH раздела LFO, а не WIDTH со страницы DRONE. Именно здесь
 * была утечка: при DEPTH = 0 выбор FILTER всё равно подмешивал половину WIDTH, и фильтр
 * начинал разворачиваться от ручки, которую в этом разделе никто не трогал.
 */
static bool mod_dest_filter(void)
{
    return (mod_dest_bits() & MD_FILTER) != 0u;
}

/* RATE — тоже приёмник: скорость собственного ЛФО фильтра множится на 2^(depth*lfo),
 * поэтому он бежит быстрее на подъёме и медленнее на спаде. Глубина — DEPTH раздела LFO. */
static bool mod_dest_rate(void)
{
    return (mod_dest_bits() & MD_RATE) != 0u;
}

static bool mod_dest_level(void)
{
    return (mod_dest_bits() & MD_LEVEL) != 0u;
}

static bool mod_dest_pw(void);
static bool mod_dest_pan(void)
{
    return (mod_dest_bits() & MD_PAN) != 0u;
}

static bool mod_dest_pw(void)
{
    return (mod_dest_bits() & MD_PW) != 0u;
}

/*
 * ШИРИНА ИМПУЛЬСА ПОД ЛФО.
 *
 * Колеблется вокруг положения ручки в её же шкале: DEPTH задаёт размах, SHAPE — форму, а
 * RATE — скорость. Пишется всем голосам лида раз в блок; голосов теперь восемнадцать, и это
 * восемнадцать записей — на фоне блока не видно.
 */
static void mod_pw_tick(void)
{
    /*
     * Оба LFO складываются: сумма двусторонних вкладов, и только потом закон
     * приёмника — половина размаха на полный ход. Раньше здесь стоял один LFO и
     * общий MOD_DEPTH.
     */
    const float m = mod_sum_pm(MD_PW);
    float v = s_param[SYNTH_PARAM_LEAD_PW] + m * 0.5f;

    if (!(v > 0.0f)) {
        v = 0.0f;
    } else if (v > 1.0f) {
        v = 1.0f;
    }

    const uint32_t pw = (uint32_t)((0.05f + v * 0.90f) * 255.0f + 0.5f);

    for (int i = 0; i < LEAD_VOICES; i++) {
        s_synth.setPulseWidth((uint16_t)(LEAD_VOICE_BASE + i), pw);
    }
}

/* The lead's step, on its own or together with the percussion's pitch. */
static bool mod_dest_lead(void)
{
    return (mod_dest_bits() & MD_LEAD) != 0u;
}

/*
 * The filter's LFO depth as the engine gets it: own is the FILTER page's DEPTH, and when the filter
 * is a destination the modulation page's WIDTH adds FILTER_WIDTH_SHARE of itself — a half and not a
 * whole, so DEPTH's entire travel does something at every WIDTH. The sum is held at
 * FILTER_DEPTH_SUM_MAX, which is exactly DEPTH 1.0 + WIDTH 0.5: only both knobs at the top reach it.
 *
 * Both the publisher and the DEPTH readout call this, so the number on the screen is the number in
 * the filter rather than the knob's own value.
 */
static float filter_depth_sum(float own)
{
    /* Своя глубина плюс доля DEPTH раздела LFO, когда фильтр выбран адресатом. Обе
     * ручки на нуле дают ноль — сумма, а не подмена. См. mod_dest_filter(). */
    float depth = own;

    if (mod_dest_filter()) {
        depth += FILTER_WIDTH_SHARE * clamp01f(s_param[SYNTH_PARAM_MOD_DEPTH]);
        if (depth > FILTER_DEPTH_SUM_MAX) {
            depth = FILTER_DEPTH_SUM_MAX;
        }
    }
    return depth;
}

static void publish_filter_depth(float own)
{
    const float depth = filter_depth_sum(own);

    for (int r = 0; r < DRONE_REGISTERS; r++) {
        const drone_register_cfg_t *cfg = &s_drones[r];
        s_synth.setBusFXParam((uint8_t)(cfg->layer + 1), 0, 3,
                              (int16_t)filter_depth_for(cfg, depth));
    }
}

static void apply_filter_rate(float v01);

/*
 * ДВА СПИСКА НЕ МОГУТ УКАЗАТЬ НА ОДНО И ТО ЖЕ.
 *
 * Одна и та же строка в обоих списках — это не сочетание, а повтор: modulation идёт в одно
 * место, и вторая ручка не делает ничего. Поэтому одинаковый выбор пропускается: ручка
 * встаёт на следующую позицию (на конце списка — на предыдущую). OFF исключение: два OFF
 * это честное «модуляции нет», и запрещать его нечего.
 */
static int mod_dest_legal(int d, int other)
{
    if (d <= 0 || d != other) {
        return d;                     /* OFF или уже различны */
    }
    if (d + 1 < MOD_DEST_COUNT) {
        return d + 1;
    }
    return (d > 1) ? d - 1 : 0;
}

static void apply_mod_dest2(float v01)
{
    int d = (int)(v01 * (float)(MOD_DEST_COUNT - 1) + 0.5f);

    if (d < 0) {
        d = 0;
    } else if (d >= MOD_DEST_COUNT) {
        d = MOD_DEST_COUNT - 1;
    }
    d = mod_dest_legal(d, s_mod_dest);
    s_mod_dest2 = d;

    /* Скорректированное значение возвращается в параметр: иначе сектор показывал бы
     * строку, которой на деле не выбрано. */
    s_param[SYNTH_PARAM_MOD_DEST2] = (float)d / (float)(MOD_DEST_COUNT - 1);

    /* Both chains are republished, because the one that was just switched off has to fall
     * silent and the one switched on has to take effect without waiting for its knob to move. */
    apply_motion_depth(s_param[SYNTH_PARAM_MOTION_DEPTH]);
    publish_filter_depth(s_param[SYNTH_PARAM_FILTER_DEPTH]);
    apply_filter_rate(s_param[SYNTH_PARAM_FILTER_RATE]);
}

static void apply_mod_dest(float v01)
{
    int d = (int)(v01 * (float)(MOD_DEST_COUNT - 1) + 0.5f);

    if (d < 0) {
        d = 0;
    } else if (d >= MOD_DEST_COUNT) {
        d = MOD_DEST_COUNT - 1;
    }
    d = mod_dest_legal(d, s_mod_dest2);
    s_mod_dest = d;
    s_param[SYNTH_PARAM_MOD_DEST] = (float)d / (float)(MOD_DEST_COUNT - 1);

    /* Both chains are republished, because the one that was just switched off has to fall silent
     * and the one switched on has to take effect without waiting for its knob to move. */
    apply_motion_depth(s_param[SYNTH_PARAM_MOTION_DEPTH]);
    publish_filter_depth(s_param[SYNTH_PARAM_FILTER_DEPTH]);
    apply_filter_rate(s_param[SYNTH_PARAM_FILTER_RATE]);
}

static void apply_filter_rate(float v01)
{
    /*
     * RATE как адресат — это не прибавка к скорости, а СЛЕДОВАНИЕ: сама скорость умножается
     * на 2^(depth * lfo), поэтому ЛФО бежит быстрее на подъёме и медленнее на спаде. Ручка
     * задаёт среднюю скорость, WIDTH — глубину этого дыхания. Пока это была статическая
     * прибавка, владелец справедливо слышал, что фильтр не следует за модуляцией.
     */
    /* Слежение за LFO включается адресатом RATE и меряется DEPTH раздела LFO, а не
     * WIDTH: при нулевой глубине скорость остаётся ровно той, что стоит на ручке. */
    synth_drone_lfo_set_rate_mod(mod_dest_rate() ? clamp01f(s_param[SYNTH_PARAM_MOD_DEPTH])
                                                 : 0.0f);

    for (int r = 0; r < DRONE_REGISTERS; r++) {
        const drone_register_cfg_t *cfg = &s_drones[r];
        s_synth.setBusFXParam((uint8_t)(cfg->layer + 1), 0, 2,
                              (int16_t)filter_rate_for(cfg, v01));
    }
}

static void apply_filter_depth(float v01)
{
    publish_filter_depth(v01);
}

static void apply_motion_depth(float v01)
{
    /*
     * ШИРИНА УМНОЖАЕТСЯ НА ГЛУБИНУ, и это то же правило, что у остальных приёмников:
     * при DEPTH = 0 раздел LFO не посылает ничего, каким бы ни был адресат. Раньше здесь
     * стоял WIDTH один — ручка со страницы DRONE, — и выбор PAN при нулевой глубине всё
     * равно уводил дрон в панораму.
     *
     * WIDTH остаётся шириной дрейфа: он говорит, куда дрону можно уходить, а DEPTH —
     * насколько сильно его туда тянет.
     */
    /*
     * ШИРИНА — ЭТО СТАТИКА, А НЕ ГЛУБИНА ДРЕЙФА.
     *
     * Владелец: «не вижу по приборам какого-то эффекта от её вращения». Проверено по коду:
     * ручка читалась в одном месте и уходила в панораму как WIDTH x MOD_DEPTH, заводское
     * значение DEPTH — ноль, а сама панорама открывалась только при адресате PAN. На свежем
     * патче она не делала ничего.
     *
     * Теперь она делает то, что написано на ней: разводит три регистра по стерео. LOW уходит
     * влево, MID стоит в центре, HIGH — вправо; на полном ходе 900 из 1000, то есть почти
     * край, но не край, где голос пропадает из канала. Дрейф остаётся движением и включается
     * своим DEPTH: две ручки больше не перемножаются, и каждая отвечает за своё.
     */
    /* НИЗ В ЦЕНТРЕ. Фундамент не двигают: LOW остаётся в центре всегда, а расходятся
     * верхние регистры — MID влево, HIGH вправо. Это и есть «ширина» дрона: одна точка
     * опоры и две, разъехавшиеся вокруг неё. */
    static const float spread[DRONE_REGISTERS] = { 0.0f, -1.0f, 1.0f };
    const float width = clamp01f(v01) * 900.0f;

    const float drift = mod_dest_pan()
                      ? clamp01f(s_param[SYNTH_PARAM_MOD_DEPTH])
                      : 0.0f;

    for (int r = 0; r < DRONE_REGISTERS; r++) {
        const drone_register_cfg_t *cfg = &s_drones[r];
        const uint8_t bus = (uint8_t)(cfg->layer + 1);

        /* Куда регистр стоит: его собственное место, от нуля до края по ходу ручки. */
        s_synth.setBusFXParam(bus, 1, 0, (int16_t)(spread[r] * width));

        /* И насколько он гуляет вокруг этого места — от DEPTH раздела LFO. */
        s_synth.setBusFXParam(bus, 1, 1,
                              (int16_t)motion_depth_for(cfg->pan_depth, drift));
        s_synth.setBusFXParam(bus, 1, 5,
                              (int16_t)motion_depth_for(cfg->walk_depth, drift));
    }

    /* The lead drifts with the drones but stays gentler, so it remains findable
     * in the image. Свою ширину лид получил ручкой SPREAD. */
    s_synth.setBusFXParam((uint8_t)(SYNTH_LAYER_LEAD + 1), 1, 1,
                          (int16_t)motion_depth_for(LEAD_PAN_DEPTH, drift));
}

/*
 * DEPTH РАЗДЕЛА LFO ДВИГАЕТ ТРИ ВЕЩИ, и это единственное место, где они сходятся:
 * глубину панорамы (она же — WIDTH, умноженный на эту ручку), глубину развёртки фильтра,
 * когда FILTER выбран адресатом, и скорость его ЛФО, когда выбран RATE. Пока DEPTH был
 * нулём и ничего не публиковал, два последних приёмника жили на прежних числах, и выбор
 * адресата слышался как изменение звука — то, на что владелец и жаловался.
 */
static void apply_mod_depth(float v01)
{
    (void)v01;      /* читается там, где складывается: см. filter_depth_sum() */

    apply_motion_depth(s_param[SYNTH_PARAM_MOTION_DEPTH]);
    publish_filter_depth(s_param[SYNTH_PARAM_FILTER_DEPTH]);
    apply_filter_rate(s_param[SYNTH_PARAM_FILTER_RATE]);
}

static void apply_motion_rate(float v01)
{
    for (int r = 0; r < DRONE_REGISTERS; r++) {
        const drone_register_cfg_t *cfg = &s_drones[r];
        const uint8_t bus = (uint8_t)(cfg->layer + 1);

        /* Both LFOs scale by the same factor, so the ratio between them — which
         * is what makes the drift non-repeating — survives the knob. */
        s_synth.setBusFXParam(bus, 1, 2, (int16_t)motion_rate_for(cfg->pan_rate1_mhz, v01));
        s_synth.setBusFXParam(bus, 1, 3, (int16_t)motion_rate_for(cfg->pan_rate2_mhz, v01));
        s_synth.setBusFXParam(bus, 1, 4, (int16_t)motion_walk_for(cfg->walk_ms, v01));
    }

    const uint8_t lead_bus = (uint8_t)(SYNTH_LAYER_LEAD + 1);
    s_synth.setBusFXParam(lead_bus, 1, 2, (int16_t)motion_rate_for(LEAD_PAN_RATE1_MHZ, v01));
    s_synth.setBusFXParam(lead_bus, 1, 3, (int16_t)motion_rate_for(LEAD_PAN_RATE2_MHZ, v01));
    s_synth.setBusFXParam(lead_bus, 1, 4, (int16_t)motion_walk_for(LEAD_WALK_MS, v01));
}

static void apply_lfo_shape(float v01)
{
    (void)v01;   /* the index is read from the table, which this applier runs after */

    const int shape = lfo_shape_index();

    /*
     * THE FILTER'S LFO IS A SINE, and this page no longer has a say in it.
     *
     * It used to be handed this page's SHAPE, translated to the DSP's five codes, so the filter
     * page's RATE traced whatever figure was chosen here and the filter swept it too: two LFOs
     * with one waveform. The filter now sweeps a sine of its own rate and depth — the shape is
     * not a control it has — and the shapes on this page belong to this page's LFO and to the
     * destinations it is pointed at.
     *
     * MIC still travels. It is this page's source, and the flag below is what the pan capture
     * reads; it no longer stands in for the filter's sweep, which is the sine above.
     */
    s_mic_replace = (shape == LFO_SHAPE_MIC);

    for (int i = 0; i < 3; i++) {
        s_synth.setBusFXParam((uint8_t)(SYNTH_LAYER_DRONE_LOW + i + 1), 0, 5, 0);
    }

    /* The flag is published now as well as every block: choosing MIC is a change that
     * has to be in force on the next block, and the envelope that comes with it is the
     * one from the last block read. */
    publish_mic_mod();
}

static void apply_lead_level(float v01)
{
    /* A multiplier on the designed level rather than an absolute one, so the
     * default lands exactly on the designed voicing and the knob
     * can only ever move away from it. Through the fader law: see level_gain(). */
    synth_rack_set_layer_level(SYNTH_LAYER_LEAD, level_gain(v01) * LEAD_LEVEL_MAX);
}

/*
 * The drone's registers: where each one is tuned right now, and what the LEVELS page asks for.
 *
 * The fader and the audibility rule are kept apart because the level that reaches the rack is
 * their PRODUCT: the player sets one, physics sets the other. See drone_level_apply().
 */
static float s_drone_hz[DRONE_REGISTERS] = { 55.0f, 110.0f, 220.0f };

/*
 * ДРЕЙФ СТРОЯ: расстройка каждого регистра в центах, своя у каждого.
 *
 * Одна скорость на всех — DRONE_DRIFT_HZ, дыхание примерно раз в десять секунд — и три
 * РАЗНЫЕ фазы, разнесённые так, чтобы никогда не сходиться: 0, 1/3 и 2/3 круга. Тогда
 * регистры расходятся и сходятся вразнобой, и биение выходит неровным.
 *
 * Числа квантованы до половины цента и обновляются только когда квант изменился: питч
 * девяти голосов переписывается setFrequency, и делать это каждый блок на постоянной
 * величине значило бы платить за то, чего не слышно.
 */
#define DRONE_DRIFT_HZ        0.095f    /* одно дыхание за 10.5 с */
#define DRONE_DRIFT_MAX_CT    100.0f    /* предел ручки, центы: полутон на самом верху */
#define DRONE_DRIFT_STEP_CT   0.5f      /* квант: ниже этого питч не переписывается */

static float s_drone_drift_ct[DRONE_REGISTERS];      /* что звучит сейчас, центы */
static float s_drone_drift_ph[DRONE_REGISTERS] = { 0.0f, 1.0f / 3.0f, 2.0f / 3.0f };
static float s_drone_mix[DRONE_REGISTERS] = { 1.0f, 1.0f, 1.0f };

/*
 * BELOW THIS A REGISTER IS NOT A NOTE, AND IT IS TURNED DOWN RATHER THAN TUNED UP.
 *
 * The drone's base is fixed at 55/110/220 Hz, and only FULL can drive a register under the
 * audio band: a note far below A1 moves the whole drone down with the keyboard, and at the
 * bottom of the MIDI range the registers land at 8.18, 16.35 and 32.70 Hz. The first two are
 * under the band: they carry full-scale energy, eat headroom and make a woofer breathe, and
 * nothing else. Fading them out is the honest answer, and it is the LEVEL that moves — never
 * the pitch.
 *
 * WHY NOT TRANSPOSE. The obvious alternative, lifting the whole drone by octaves until its LOW
 * register is audible, was in the first cut of this and it was wrong: the lift is a step
 * function of the TUNED pitch, so it also fires when a FOLLOW shift crosses the floor. Measured
 * at the old ROOT = C1 it turned a folded shift of -4 semitones into +8 semitones of actual
 * movement, and made folded(-4) and unfolded(+8) produce the identical 207.65 Hz — the drone
 * hopped by octaves as notes were played, which is exactly "FOLLOW does not work, it
 * transposes". A gain cannot do that: the pitch stays the arithmetic of the base and the shift,
 * whatever the mode says.
 *
 * THE BAND IS SET SO THAT NOTHING THE INSTRUMENT COULD DO BEFORE MOVES. At the designed base
 * the LOW register is 55 Hz and every mode but FULL keeps it above 49 Hz; the old ROOT range
 * bottomed out at A2, whose LOW register is 27.5 Hz — above the top of the fade, so every sound
 * saved before this rework keeps its level exactly. Inside the band a register fades linearly,
 * and 16 Hz is under what the speaker can produce anyway.
 */
#define DRONE_AUDIBLE_SILENT_HZ  16.0f
#define DRONE_AUDIBLE_FULL_HZ    22.0f


/*
 * ФЕЙДЕР РЕГИСТРА ДРОНА: ДЕЦИБЕЛЫ, А НЕ КВАДРАТ.
 *
 * Квадрат хода отдавал сорок децибел в первые десять процентов: ручку только тронули, а
 * регистр уже звучит. Здесь шестьдесят децибел на весь ход, по три на процент — низ шкалы
 * тихий, верх ровный. Ноль остаётся точной тишиной, единица — полной шкалой.
 */
static float drone_level_gain(float v01)
{
    if (!(v01 > 0.0f)) {
        return 0.0f;
    }

    const float v = (v01 > 1.0f) ? 1.0f : v01;

    return powf(10.0f, (v - 1.0f) * 3.0f);
}

/*
 * ПОПРАВКА НА СЛЫШИМОСТЬ РЕГИСТРА: ухо на пятидесяти пяти герцах слышит хуже, чем на
 * двухстах двадцати, поэтому при равном ходе ручек низ звучал тише верха.
 */
static float drone_loudness(float hz)
{
    if (hz <= 70.0f) {
        return 1.35f;
    }
    if (hz <= 140.0f) {
        return 1.12f;
    }
    return 1.0f;
}

static float drone_audible(float hz)
{
    if (hz >= DRONE_AUDIBLE_FULL_HZ) {
        return 1.0f;
    }
    if (hz <= DRONE_AUDIBLE_SILENT_HZ) {
        return 0.0f;
    }
    return (hz - DRONE_AUDIBLE_SILENT_HZ)
         / (DRONE_AUDIBLE_FULL_HZ - DRONE_AUDIBLE_SILENT_HZ);
}

/* The one writer of a register's LEVEL: the player's fader times the audibility of where the
 * register is tuned. Called when either of those moves. */
static void drone_level_apply(int register_index)
{
    if (register_index < 0 || register_index >= DRONE_REGISTERS) {
        return;
    }
    /*
     * Модуляция уровня, если она выбрана адресатом. Ноль глубины — множитель ровно
     * единица, поэтому DEST без DRONE LVL и WIDTH на заводском положении дают то же
     * число, что и до этой строки, бит в бит.
     */
    /*
     * УРОВЕНЬ ДРОНА: ЗАКОН 1 − d·(1 − w), РАСКРЫТЫЙ НА ДВА LFO.
     *
     * 1 − d·(1 − w) = 1 − d + d·w. Сумма по двум каналам даёт 1 − Σdᵢ + Σdᵢwᵢ, поэтому
     * постоянная часть складывается из ГЛУБИН, а не из единицы: иначе два LFO с половиной
     * глубины каждый дали бы вдвое меньший провал, чем один на полной.
     */
    float mod = 1.0f;

    /* Глубина со знаком: отрицательная поднимает уровень вместо провала — это и есть
     * противофаза, которую просил владелец. */
    const float level_depth = mod_depth_sum(MD_LEVEL);

    if (level_depth > 0.0f) {
        mod = 1.0f - level_depth + mod_sum01(MD_LEVEL);
    }

    const float level = drone_level_gain(s_drone_mix[register_index])
                      * drone_loudness(s_drone_hz[register_index])
                      * drone_audible(s_drone_hz[register_index]) * mod;
    synth_rack_set_layer_level(s_drones[register_index].layer, level);
}

/*
 * One fader per drone register.
 *
 * This is the RACK level, which is where a register's place in the mix is really
 * decided. The per-voice volumes in the table are a fraction of full scale on a
 * single voice, not a mixer setting, and three voices of one register sum to
 * roughly full scale on their own — so the rack level is the control that moves
 * a register against the others.
 */
static void apply_drone_mix(int register_index, float v01)
{
    if (register_index < 0 || register_index >= DRONE_REGISTERS) {
        return;
    }
    s_drone_mix[register_index] = v01;
    drone_level_apply(register_index);
}

/* Both live in the sequencer section further down the file; the drone needs the
 * melody's tonic, and the tonic is defined there. */
static float midi_to_hz(int note);
static int seq_root_midi(void);
static void seq_root_split(float v01, float *note01, float *oct01);
static float seq_tempo_bpm(float v01);

/* The tempo the generators are ACTUALLY running at: the wire's while a clock is being
 * received, the knob's otherwise. Defined in the clock section below, where the two
 * reasons it is a layer of its own are written down — and used by everything that
 * counts in beats: the two sequencers, the arpeggiator and the modulation clock. */
static float seq_tempo_now(void);

/* The bar the transport divides, in blocks, at a given tempo. Defined with the
 * transport below; the synced delay reads it so that its echo is a whole number of
 * blocks of the SAME bar the sequencer counts. */
static uint32_t bar_blocks_for_bpm(float bpm);

/*
 * THE DRONE'S HEIGHT IS ITS OWN, AND THE ROOT KNOB NO LONGER SETS IT.
 *
 * The base is the pitch the instrument was voiced at: 55 / 110 / 220 Hz for LOW, MID and
 * HIGH, i.e. A1, A2 and A3, one octave apart. It is a PROPERTY OF THE DRONE and not of the
 * ROOT knob. Moving ROOT does not transpose it, in any mode, at any position: the knob names
 * the key the lead is in, and the drone is brought into that key through the SCALE instead
 * (see drone_follow_shift()). This is what the previous rule got wrong. There the base WAS the
 * knob, so turning it walked the whole drone by up to seven octaves and the drone could not
 * hold a register of its own while the player changed key.
 *
 * WHY ONE BASE FOR ALL THREE MODES. A mode is a decision about whether the drone follows the
 * lead, not a different drone. If each mode carried its own reference, switching modes would
 * retune the instrument by the difference between the two references — an audible move that
 * means nothing musical. One base also makes the modes comparable, which is what the table in
 * tools/follow_check.py measures: every row starts from the same 55/110/220.
 *
 * WHERE A REGISTER SITS IS THE BASE TIMES THE SHIFT: LOW is the base, MID twice it and HIGH
 * four times it, all times 2^(shift/12), and then each register is halved until it is at or
 * below DRONE_REGISTER_MAX_HZ — see the note over that constant for why the top register is
 * dropped an octave rather than filtered. Nothing else touches the pitch, and in particular
 * there is NO OCTAVE LIFT: an earlier cut lifted the whole drone whenever LOW fell under 26 Hz
 * and that lift fired from the FOLLOW shift itself, so at the old ROOT = C1 the requests
 * folded(-4) and unfolded(+8) produced the same 207.65 Hz. Audibility is a LEVEL question — see
 * drone_audible(), which turns a sub-audio register down instead of tuning it up.
 */
#define DRONE_BASE_HZ    55.0f   /* LOW; MID is 110 and HIGH 220 */
#define DRONE_BASE_MIDI  33      /* A1, the note 55 Hz is tuned to */

/*
 * THE UPPER REGISTER'S CEILING, AND WHY IT IS AN OCTAVE DROP RATHER THAN A FILTER.
 *
 * In FULL the whole drone travels with the keyboard, and the three registers stay octaves of
 * the played note: at C8 the tuned fundamental is 4186 Hz, so HIGH would sit at 16744 Hz —
 * above what the speaker and the ear do with a drone, and it carries almost no mass: the
 * register that is supposed to be the body becomes a piercing line. The fix is to put the
 * register back into the band, and it is PITCH that moves, not gain and not a low-pass: an
 * octave filter would change the timbre of one register against the other two, while an octave
 * drop keeps all three the same shape.
 *
 * The rule is applied per register and independently: while a register's frequency is above
 * DRONE_REGISTER_MAX_HZ it is halved. At C8 that takes HIGH from 16744 to 8372 Hz, which is
 * exactly MID — the two registers then sound in unison, and that is expected rather than a
 * fault: the alternative is a register nobody wants to hear. LOW and MID are untouched at any
 * note the keyboard can send (MID's own ceiling would need a fundamental above 5000 Hz, i.e. a
 * note above the top of MIDI), so nothing below 10 kHz changes at all.
 *
 * The ceiling is 10 kHz rather than the 20 kHz of the audio band on purpose: a drone register
 * that is audible as a pitch has no business in the top octave, and 10 kHz is where the third
 * harmonic of the highest useful fundamental still leaves the fundamental itself as the note.
 */
#define DRONE_REGISTER_MAX_HZ 10000.0f

static float s_drone_tune_st;    /* the FOLLOW shift in force, semitones, smoothed */

/*
 * БАЗИС ДРОНА, ПРИВЕДЁННЫЙ К СКЕЙЛУ.
 *
 * Сдвиг базиса НЕ применяется отдельным setFrequency, а складывается со сдвигом FOLLOW и идёт
 * через тот же восьмимиллисекундный однополюсник: смена тональности — это переезд, а не ступенька,
 * и два правила (куда встать по скейлу и куда по ноте) не могут разъехаться во времени.
 *
 * Дрон стоит на A1 — это его строй, и ROOT его не двигает. Но скейл двигает: если тональность
 * ноты A не содержит (C# major — там A#), то в паузах, когда FOLLOW возвращает сдвиг в ноль,
 * дрон звучит вне тональности. Базис поэтому пропускается через ту же seq_scale_note(), что и
 * ноты лида: хроматика оставляет его как есть (33 -> 33), а скейл без A уводит на ближайшую
 * свою ступень. Сдвиг FOLLOW считается уже от этого базиса, поэтому оба правила не спорят.
 */
static int   s_drone_base_midi = DRONE_BASE_MIDI;
static float s_drone_base_st   = 0.0f;   /* и тот же сдвиг в полутонах, для сглаживания */

/* The key-tracking multiplier the drone filter's cutoff is multiplied by: 2^(k·shift/12),
 * where shift is the FOLLOW shift in force — the tuned base IS A1 transposed by it, so the
 * exponent is exactly the distance of the note from the drone's own base (MIDI 33). At k=0
 * this is 1 and the cutoff is the knob's own number, unchanged bit for bit. */
static float drone_filter_track_mult(void)
{
    const float k = s_param[SYNTH_PARAM_DRONE_KTRCK];

    if (k <= 0.0f) {
        return 1.0f;
    }
    return exp2f(k * s_drone_tune_st / 12.0f);
}

static void drone_set_pitch(float base_hz, float semis)
{
    const float tuned = base_hz * exp2f(semis / 12.0f);

    for (int r = 0; r < DRONE_REGISTERS; r++) {
        const drone_register_cfg_t *cfg = &s_drones[r];
        float hz = tuned * (float)(1 << r);

        /* The ceiling: halve the register until it is back in the band. Widened to a loop
         * rather than one test so that the rule is "while above", which is what was asked
         * for and is also true if the constant ever moves. */
        while (hz > DRONE_REGISTER_MAX_HZ) {
            hz *= 0.5f;
        }

        /* Where the register is tuned, for the audibility rule; then the level that follows
         * from it, because a register can move under the floor while its fader does not. */
        s_drone_hz[r] = hz;
        drone_level_apply(r);
        for (int v = 0; v < DRONE_VOICES_PER_REGISTER; v++) {
            /* setFrequency, not a fresh noteOn: the drone is already sounding and
             * retuning it must not restart the envelope. Phase is continuous
             * across a frequency change in this engine, so a jump in pitch is a
             * jump in pitch and not a click. */
            /* The drift rides on the same detune the register's voices already carry, so
             * one register can lean while the others stay: it is one more number in cents,
             * and the supersaw spread does not have to know it exists. */
            s_synth.setFrequency((uint16_t)(cfg->first_voice + v),
                                 cents_to_centihz(hz, wave_detune(cfg->detune_cents[v]
                                                                  + s_drone_drift_ct[r],
                                                                  s_drone_super[r])));
        }
    }
}

/* Write the pitch that is in force now. Used where a register's tuning has to be refreshed
 * without waiting for the next block — the supersaw boundary changes the detune, and the
 * drone has no next note to pick the spread up on. The ROOT knob is NOT a caller: it moves no
 * base, and the one place a key change reaches the drone is drone_tune_tick(). */
static void drone_retune(void)
{
    drone_set_pitch(DRONE_BASE_HZ, s_drone_tune_st);
}

/*
 * The lead filter's gate.
 *
 * The filter's envelope has to know when a note starts and stops, and the FX runs
 * on the bus where it cannot see voices — so the sequencer tells it, at the same
 * moment it tells the voices. Both run on the audio task in the same block, so
 * the gate is exact rather than sampled: no note can start or end between two
 * blocks and go unnoticed.
 */
static void lead_fenv_times_apply(void);

/*
 * Все параметры фильтра заново — на все его шины. Нужно после регистрации: setBusFX стирает
 * ep и es, и без этого новая копия фильтра осталась бы с нулями (нулевой срез — тишина).
 */
static void lead_filter_repush(void)
{
    apply_lead_cutoff(s_cur[SYNTH_PARAM_LEAD_CUTOFF]);
    apply_lead_reso(s_cur[SYNTH_PARAM_LEAD_RESO]);
    apply_lead_env(s_cur[SYNTH_PARAM_LEAD_ENV]);
    apply_lead_filter_mode(s_cur[SYNTH_PARAM_LEAD_FILTER_MODE]);
    lead_fenv_times_apply();
}

static void lead_filter_gate(int on)
{
    if (on) {
        /* The envelope's two segments are the note's length, and the note about to
         * start is the only place they can be sized: the gate is what the filter sees,
         * so its two numbers travel with it. */
        lead_fenv_times_apply();
    }
    lead_filter_slot(0, 7,
                          (int16_t)(on ? 1 : 0));
}

/* The corner as it is written to the filter, before the rounding to whole hertz: the
 * knob's frequency and the key tracker's multiplier, clamped where the slot can hold it.
 * The depth knob is a percentage of the distance from THIS number to a stop, so it is
 * asked for here rather than recomputed. */
static float lead_fc_base_for(float v01)
{
    float fc = lead_fc_for(v01) * lead_filter_track_mult();

    /* In float and clamped before the rounding, like the drone's: at k=0 the product is
     * exactly 1.0 and the number is the one this applier always wrote. */
    if (fc > LEAD_CUTOFF_TRACK_MAX_HZ) {
        fc = LEAD_CUTOFF_TRACK_MAX_HZ;
    }
    return fc;
}

static void apply_lead_env(float v01);
static void apply_lead_voice(float v01);
static void lead_chord_pan(float v01);   /* определена с лидом, зовётся из applier'а */
static void lead_chord_hz(float hz, float *out, int *count);

static void apply_lead_cutoff(float v01)
{
    const float fc = lead_fc_base_for(v01);

    lead_filter_slot(0, 0,
                          (int16_t)(fc + 0.5f));

    /* THE DEPTH FOLLOWS THE CORNER, because it is a distance to a stop and the stop does
     * not move: three octaves down from 9 kHz is not the same number of octaves as three
     * from 300 Hz, and a knob left where it was would change what it means as CUTOFF and
     * the key tracker move. One extra slot write, on a knob that is turned by hand. */
    apply_lead_env(s_cur[SYNTH_PARAM_LEAD_ENV]);
}

static void apply_lead_reso(float v01)
{
    lead_filter_slot(0, 1,
                          (int16_t)(lead_q_for(v01) * 100.0f));
}

static void apply_lead_env(float v01)
{
    /* Centioctaves, signed: the FX multiplies the cutoff by 2^(env * amount), so this is
     * a number of octaves. Where those octaves COME from is the percentage above: the
     * distance from the corner in force to the stop, which makes both ends of the knob
     * land on a stop whatever CUTOFF says. */
    const float fc = lead_fc_base_for(s_cur[SYNTH_PARAM_LEAD_CUTOFF]);
    const float oct = lead_env_oct_for(v01, fc);

    lead_filter_slot(0, 2,
                          (int16_t)(oct * 100.0f + (oct >= 0.0f ? 0.5f : -0.5f)));
}

/*
 * THE FILTER ENVELOPE'S LENGTH, and the two segments the SHAPE knob cuts it into.
 *
 * THE LENGTH IS THE BEAT, not the note: a quarter at the transport's tempo, multiplied by
 * GATE. The note's own length — a sixteenth of the same tempo times GATE — was the whole of
 * it while the envelope was being designed, and at 120 BPM that is 62 ms, which is a click:
 * an attack or a release long enough to hear cannot fit inside a sixteenth. The beat does
 * fit, and it keeps the one thing worth keeping — the envelope moves with the tempo — while
 * making the slow end genuinely slow: at 30 BPM with GATE at its top the two segments share
 * 1.9 s.
 *
 * THE CEILING IS THREE SECONDS. It is not the knob's own limit (the slowest tempo the
 * transport can be given, 30 BPM, cannot reach it): it is what a clock on the wire can do,
 * and 3 s is the longest a filter sweep is worth listening to. Without it a host at 12 BPM
 * would leave the corner moving for twenty seconds after the note was gone.
 *
 * The knob splits the length: at its bottom the attack is a millisecond and the release owns
 * the rest, at its middle they are equal, at its top the attack owns it and the release is a
 * millisecond. Both ends are floored at a millisecond rather than at zero: seg_rate() in the
 * filter clamps under half a millisecond anyway, and a segment that is exactly zero would
 * leave the envelope with no segment at all.
 */
#define LEAD_FENV_TIME_MAX_MS  3000.0f

static float lead_fenv_ms(void)
{
    float gate = s_cur[SYNTH_PARAM_SEQ_GATE];
    float bpm = seq_tempo_now();
    float ms;

    if (!(gate >= 0.05f)) {
        gate = 0.05f;
    } else if (gate > 0.95f) {
        gate = 0.95f;
    }
    if (!(bpm >= 20.0f)) {
        bpm = 20.0f;
    }

    ms = (60000.0f / bpm) * gate;
    if (ms > LEAD_FENV_TIME_MAX_MS) {
        ms = LEAD_FENV_TIME_MAX_MS;
    }
    if (ms < 2.0f) {
        ms = 2.0f;
    }

    return ms;
}

static void lead_fenv_times_apply(void)
{
    const float total = lead_fenv_ms();
    float share = s_cur[SYNTH_PARAM_LEAD_FENV_SHAPE];   /* 0..1, the attack's half */

    if (!(share >= 0.0f)) {
        share = 0.0f;
    } else if (share > 1.0f) {
        share = 1.0f;
    }

    float a = total * share;
    float r = total - a;

    if (a < 1.0f) {
        a = 1.0f;
    }
    if (r < 1.0f) {
        r = 1.0f;
    }

    lead_filter_slot(0, 3, (int16_t)(a + 0.5f));
    lead_filter_slot(0, 6, (int16_t)(r + 0.5f));
}

static void apply_lead_fenv_shape(float v01)
{
    (void)v01;
    lead_fenv_times_apply();
}

/*
 * THE AMPLITUDE ENVELOPE, which is what the four knobs on the ENV page now write.
 *
 * One call, four slots of one voice's own envelope: the engine's setEnv() takes
 * milliseconds for the three times and 0..255 for the level, and it recomputes the
 * voice's rates, so a knob turned while a note is held changes the rest of that note
 * rather than waiting for the next one — the same behaviour the filter had.
 *
 * It is written to EVERY lead voice, the arpeggiator's group included: they are one
 * instrument, and a note that arrived from the wire must decay like one that came from
 * the sequencer.
 */
static void apply_lead_amp_env(void)
{
    const uint16_t a = (uint16_t)(lead_time_for(s_cur[SYNTH_PARAM_LEAD_ATTACK]) + 0.5f);
    const uint16_t d = (uint16_t)(lead_time_for(s_cur[SYNTH_PARAM_LEAD_DECAY]) + 0.5f);
    const uint16_t r = (uint16_t)(lead_time_for(s_cur[SYNTH_PARAM_LEAD_RELEASE]) + 0.5f);
    const uint8_t  sl = (uint8_t)(s_cur[SYNTH_PARAM_LEAD_SUSTAIN] * 255.0f + 0.5f);

    for (int v = 0; v < LEAD_CONFIGURED_VOICES; v++) {
        s_synth.setEnv((uint16_t)(LEAD_VOICE_BASE + v), a, d, sl, r);
    }
}

static void apply_lead_attack(float v01)  { (void)v01; apply_lead_amp_env(); }
static void apply_lead_decay(float v01)   { (void)v01; apply_lead_amp_env(); }
static void apply_lead_sustain(float v01) { (void)v01; apply_lead_amp_env(); }
static void apply_lead_release(float v01) { (void)v01; apply_lead_amp_env(); }

/*
 * The delay's division, bounded as a float and only then cast. `(int)` of a non-number
 * is undefined and can produce any value, including one the table read below does not
 * survive; the negated lower test sends that value to FREE (index 0).
 */
/* Положение слитой ручки: 0..10 доли такта, 11..26 миллисекунды. */
static int delay_time_index(void)
{
    float v = s_param[SYNTH_PARAM_DELAY_TIME];

    if (!(v >= 0.0f)) {
        v = 0.0f;
    } else if (v > 1.0f) {
        v = 1.0f;
    }

    const int idx = (int)(v * (float)(DELAY_TIME_STEPS - 1) + 0.5f);
    return (idx < 0) ? 0 : ((idx >= DELAY_TIME_STEPS) ? (DELAY_TIME_STEPS - 1) : idx);
}

/* Доля такта этого положения, или 0 — положение в миллисекундах. */
static int delay_division(void)
{
    const int idx = delay_time_index();

    if (idx >= DELAY_DIV_COUNT - 1) {
        return 0;                       /* миллисекунды: доли нет */
    }
    return idx + 1;                     /* 0 -> 1/1, 10 -> 1/32 */
}

/*
 * The synced delay's time, in whole blocks of the bar the transport is counting.
 *
 * ONE SOURCE OF TEMPO. The division is in beats, a bar is four of them, so the echo is
 * `bar_blocks * beats / 4` blocks — the same bar the sequencer divides, rounded to the
 * block the effect can actually place. It is no longer a millisecond figure computed
 * from a second reading of the tempo: with a live MIDI clock the old one followed the
 * knob while the sequencer followed the wire, and the two ran seventeen percent apart.
 *
 * TWO CALLERS, ONE ANSWER. The audio task passes the live tempo (seq_tempo_now); the UI
 * readout passes the published one (synth_app_tempo_now) because it may not touch the
 * clock's state. Both go through bar_blocks_for_bpm() here.
 */
static uint32_t delay_blocks_for_bpm(float bpm, int div)
{
    const uint32_t bar = bar_blocks_for_bpm(bpm);
    uint32_t blocks = (uint32_t)((float)bar * DELAY_DIV_BEATS[div] * 0.25f + 0.5f);

    return (blocks < 1u) ? 1u : blocks;
}

static float delay_ms_for_bpm(float bpm, int div)
{
    return (float)delay_blocks_for_bpm(bpm, div) * (float)SYNTH_BLOCK_SAMPLES * 1000.0f
           / (float)SYNTH_SAMPLE_RATE;
}

/* What the UI shows, and the only delay-time question the UI task may ask. */
static float delay_ms_now(void)
{
    const int div = delay_division();
    if (div <= 0) {
        return delay_ms_step(delay_time_index() - (DELAY_DIV_COUNT - 1));
    }

    const float bpm = seq_tempo_bpm(synth_app_tempo_now(nullptr));
    return delay_ms_for_bpm(bpm, div);
}

/*
 * The delay's time mode, as the two-entry list it is: TAPE at the bottom, CROSSFADE at the
 * top. Read the way every list on this instrument is read — the stored value names an
 * entry — and with two entries the midpoint of the knob's travel is where one becomes the
 * other.
 */
static bool delay_crossfade(void)
{
    return s_param[SYNTH_PARAM_DELAY_TIMEMODE] >= 0.5f;
}

/*
 * The effects are set as groups, not one parameter at a time: the rack takes a
 * whole effect at once, and a delay whose time has been updated while its
 * feedback has not is a delay that briefly has the wrong character. Each of these
 * reads the other members of its group out of the table, which apply_pending_params
 * has already updated by the time any applier runs.
 *
 * It runs on the audio task only (the parameter appliers and the clock's own update
 * both call it there), so it may ask seq_tempo_now() for the live tempo directly.
 */
static void apply_delay(void)
{
    const int div = delay_division();
    const float ms = (div <= 0)
                         ? delay_ms_for(s_param[SYNTH_PARAM_DELAY_TIME])
                         : delay_ms_for_bpm(seq_tempo_now(), div);

    synth_rack_set_delay(ms * SYNTH_SAMPLE_RATE / 1000.0f,
                         s_param[SYNTH_PARAM_DELAY_FEEDBACK],
                         clamp01f(s_param[SYNTH_PARAM_DELAY_MIX] +
                                  mod_sum_pm(MD_DL_MIX) * 0.25f),
                         delay_crossfade());
}

/*
 * ЭФФЕКТ-МАШИНА.
 *
 * Тип — список, поэтому в таблице лежит положение на нём. Первые два параметра — прежние
 * RATE и DEPTH: их id не тронуты, чтобы старый патч читался как хорус с прежними
 * настройками. Третий параметр общий (FX_C), MIX — уровень возврата.
 */
static int fx_type(void)
{
    int t = (int)(s_param[SYNTH_PARAM_FX_TYPE] * (float)(SYNTH_FXM_COUNT - 1) + 0.5f);

    if (t < 0) {
        t = 0;
    } else if (t >= SYNTH_FXM_COUNT) {
        t = SYNTH_FXM_COUNT - 1;
    }
    return t;
}

/*
 * ЧТО СТОИТ В МАШИНЕ: имя для ручки TYPE и подписи трёх её параметров.
 *
 * Третьего параметра может не быть (у BITCRUSH его нет), и тогда ручка C на странице
 * потухает, а в машину уходит ноль — определённое значение вместо случайного, оставшегося от
 * прошлого эффекта.
 */
typedef struct {
    const char *name;
    const char *label[3];
    int         used;
} fx_desc_t;

/*
 * ПОРЯДОК ПО РАЗРУШИТЕЛЬНОСТИ: чистое сверху, перегруз внизу.
 *
 * Место в этой таблице — оно же положение на ручке TYPE и номер типа в движке, поэтому
 * три списка (enum, эта таблица и dispatcher) держатся в одном порядке. Ноль — хорус:
 * старые записи читаются как раньше.
 */
/*
 * СКОЛЬКО ПОЛОЖЕНИЙ У КАЖДОГО ИЗ ТРЁХ ПАРАМЕТРОВ, ПО ТИПУ ЭФФЕКТА.
 *
 * Ноль — непрерывная ручка. Ступенчатые параметры получают список, и тогда сектор ведёт себя
 * как любой список в приборе: одно деление — одно положение, курсор на ободе, никакого
 * ускорения. Ответ зависит от типа, поэтому таблица и читается через fx_type().
 */
static const uint8_t FX_STEPS[SYNTH_FXM_COUNT][3] = {
    /* CHORUS   */ { 0, 0, 0 },
    /* TREMOLO  */ { 0, 0, 0 },
    /* AUTOPAN  */ { 0, 0, 0 },
    /* VIBRATO  */ { 0, 0, 0 },
    /* TILT     */ { 0, 0, 0 },
    /* PHASER   */ { 0, 0, 0 },
    /* FLANGER  */ { 0, 0, 0 },
    /* STUTTER  */ { 4, 0, 7 },
    /* COMB     */ { 0, 0, 0 },
    /* RING     */ { 0, 0, 0 },
    /* SRR      */ { 0, 0, 0 },
    /* BITCRUSH */ { 0, 0, 0 },
    /* DRIVE    */ { 0, 0, 0 },
};

static const fx_desc_t FX_DESC[SYNTH_FXM_COUNT] = {
    { "CHORUS",    { "RATE",  "DEPTH", "TONE", }, 3 },
    { "TREMOLO",   { "RATE",  "DEPTH", "SHAPE", }, 3 },
    { "AUTOPAN",   { "RATE",  "DEPTH", "WIDTH", }, 3 },
    { "VIBRATO",   { "RATE",  "DEPTH", "WIDTH", }, 3 },
    { "TILT",      { "TILT",  "MID",   NULL,   }, 2 },
    { "PHASER",    { "RATE",  "DEPTH", "FDBK", }, 3 },
    { "FLANGER",   { "RATE",  "DEPTH", "FDBK", }, 3 },
    { "STUTTER",   { "RATE",  "CHANCE", "REPEAT", }, 3 },
    { "COMB",      { "TUNE",  "DAMP",  "FDBK", }, 3 },
    { "RING",      { "FREQ",  "DEPTH", "SHAPE", }, 3 },
    { "SRR",       { "RATE",  "SMOOTH", NULL,   }, 2 },
    { "BITCRUSH",  { "BITS",  "TONE",  NULL,   }, 2 },
    { "DRIVE",     { "DRIVE", "TONE",  "BIAS", }, 3 },
};

extern "C" const char *synth_app_fx_name(void)
{
    return FX_DESC[fx_type()].name;
}

/* Подпись сектора страницы FX: 0 TYPE, 1 MIX, 2..4 параметры, 5 VERB. NULL — своя подпись. */
extern "C" const char *synth_app_fx_slot_label(int slot)
{
    if (slot < 2 || slot > 4) {
        return nullptr;
    }

    const fx_desc_t *d = &FX_DESC[fx_type()];
    const int s = slot - 2;

    return (s < d->used) ? d->label[s] : nullptr;
}

/* Есть ли у выбранного эффекта этот параметр. */
extern "C" int synth_app_fx_slot_used(int slot)
{
    if (slot < 2 || slot > 4) {
        return 1;
    }

    return ((slot - 2) < FX_DESC[fx_type()].used) ? 1 : 0;
}

/* Темп машине: STUTTER берёт свой кусок раз в такт, и сетку ему даёт транспорт. */
static void apply_fx_tempo(void)
{
    synth_rack_set_fx_tempo(seq_tempo_bpm(synth_app_tempo_now(NULL)), synth_app_is_running());
}

static void apply_chorus(void)
{
    const fx_desc_t *d = &FX_DESC[fx_type()];

    synth_rack_set_fx_machine(fx_type(),
                              s_param[SYNTH_PARAM_CHORUS_RATE],
                              s_param[SYNTH_PARAM_CHORUS_DEPTH],
                              (d->used >= 3) ? s_param[SYNTH_PARAM_FX_C] : 0.0f,
                              clamp01f(s_param[SYNTH_PARAM_CHORUS_MIX] + mod_sum_pm(MD_FX_MIX) * 0.25f));
}

/*
 * The reverb's mode is a list, so what sits in the table is a position on it rather than
 * a number: the same conversion the arp's DIR uses, and rounded the same way.
 */
static int verb_mode(void)
{
    int m = (int)(s_param[SYNTH_PARAM_VERB_MODE] * (float)(SYNTH_REVERB_MODE_COUNT - 1) + 0.5f);
    if (m < 0) {
        m = 0;
    } else if (m >= SYNTH_REVERB_MODE_COUNT) {
        m = SYNTH_REVERB_MODE_COUNT - 1;
    }
    return m;
}

static void apply_reverb(void)
{
    synth_rack_set_reverb(s_param[SYNTH_PARAM_VERB_SIZE],
                          s_param[SYNTH_PARAM_VERB_DAMP],
                          clamp01f(s_param[SYNTH_PARAM_VERB_MIX] +
                                   mod_sum_pm(MD_RV_MIX) * 0.25f),
                          verb_mode());
}

static void apply_reverb_send(void)
{
    synth_rack_set_reverb_send(SYNTH_LAYER_DRONE_LOW,  s_param[SYNTH_PARAM_SEND_LOW]);
    synth_rack_set_reverb_send(SYNTH_LAYER_DRONE_MID,  s_param[SYNTH_PARAM_SEND_MID]);
    synth_rack_set_reverb_send(SYNTH_LAYER_DRONE_HIGH, s_param[SYNTH_PARAM_SEND_HIGH]);
    synth_rack_set_reverb_send(SYNTH_LAYER_LEAD,       s_param[SYNTH_PARAM_SEND_LEAD]);

    /*
     * THE MICROPHONE'S THREE SENDS ARE ZERO, ALWAYS, and this is where that is decided.
     *
     * They were the microphone's only path into the mix; the owner took that path out, so
     * the three parameters are dead slots now — kept in the enum, still stored in a patch,
     * and read by nothing. The sends are written as a literal zero rather than from
     * s_param[] so that a patch saved before the decision, with a send turned up, cannot
     * put the input back into the room. The AUX bus carries nothing at all; see buses_init().
     */
    synth_rack_set_reverb_send(SYNTH_LAYER_AUX,        0.0f);
}

/*
 * The chorus's and the delay's sends: the same five layers and the same drum, one set per
 * effect. Written beside the reverb's rather than folded into it, because the parameters are
 * separate and a page moves one effect's six knobs at a time.
 */
static void apply_chorus_send(void)
{
    synth_rack_set_chorus_send(SYNTH_LAYER_DRONE_LOW,  s_param[SYNTH_PARAM_CHR_SEND_LOW]);
    synth_rack_set_chorus_send(SYNTH_LAYER_DRONE_MID,  s_param[SYNTH_PARAM_CHR_SEND_MID]);
    synth_rack_set_chorus_send(SYNTH_LAYER_DRONE_HIGH, s_param[SYNTH_PARAM_CHR_SEND_HIGH]);
    synth_rack_set_chorus_send(SYNTH_LAYER_LEAD,       s_param[SYNTH_PARAM_CHR_SEND_LEAD]);
    synth_rack_set_chorus_send(SYNTH_LAYER_AUX,        0.0f);   /* dead slot: see above */
    /* У перкуссии реверберация уже считалась после фейдера; хорус и дилей — теперь тоже. */
    synth_rack_set_perc_chorus_send(s_param[SYNTH_PARAM_CHR_SEND_PERC]
                                    * level_gain(clamp01f(s_param[SYNTH_PARAM_PERC_LEVEL])));
}

static void apply_delay_send(void)
{
    synth_rack_set_delay_send(SYNTH_LAYER_DRONE_LOW,  s_param[SYNTH_PARAM_DLY_SEND_LOW]);
    synth_rack_set_delay_send(SYNTH_LAYER_DRONE_MID,  s_param[SYNTH_PARAM_DLY_SEND_MID]);
    synth_rack_set_delay_send(SYNTH_LAYER_DRONE_HIGH, s_param[SYNTH_PARAM_DLY_SEND_HIGH]);
    synth_rack_set_delay_send(SYNTH_LAYER_LEAD,       s_param[SYNTH_PARAM_DLY_SEND_LEAD]);
    synth_rack_set_delay_send(SYNTH_LAYER_AUX,        0.0f);    /* dead slot: see above */
    synth_rack_set_perc_delay_send(s_param[SYNTH_PARAM_DLY_SEND_PERC]
                                   * level_gain(clamp01f(s_param[SYNTH_PARAM_PERC_LEVEL])));
}

/*
 * The microphone's sensitivity, 0..100 percent.
 *
 * ONE knob for the whole of the input, and it is an input gain rather than a modulation
 * depth. It has TWO stages behind it and only one of them exists on this board:
 *
 *   the driver's   `amplify_num`, the digital multiplier of 1..15 that the BSP's
 *                  set_gain() would write into the PDM RX slot — unity at the bottom of
 *                  the travel, 15x (+23.5 dB) at the top, reached at 42 because the BSP
 *                  maps dB as 1 + dB/3. THIS BOARD CANNOT DO IT: the field belongs to the
 *                  PDM RX high-pass/amplify stage that only the P4 and the S31 have, so
 *                  the BSP returns ESP_ERR_NOT_SUPPORTED without touching the channel.
 *                  The call is kept — it is the honest thing to ask for on hardware that
 *                  has it, and the mapping and its static assert stay valid there — but
 *                  after the first refusal it is not made again (s_mic_drv_gain_absent).
 *
 *   the software   s_mic_sw_gain, 1..6x (+15.6 dB) across the same travel, applied per
 *                  sample in mic_process_block() after the DC blocker. This is the stage
 *                  the knob actually works through here, and it is where the numbers in
 *                  the constants above were chosen.
 *
 * IT IS CALLED ONLY WHEN SOMETHING MOVES. The driver's multiplier is written only when it
 * changes, and that is not an optimisation: a slot configuration can only be changed with
 * the PDM channel disabled, so a hundred detents are fourteen interruptions instead of a
 * hundred. The software stage is set on EVERY call, before either early return below: it
 * moves on every detent, so a detent that leaves the multiplier where it was must still
 * change the level. A sensitivity of zero is not a multiplier at all — it is the input
 * switched off, and it leaves the driver exactly where it was.
 *
 * The envelope that modulation reads is normalised AFTER the software gain, so the same
 * sound that reads as a fifth of full scale near the bottom of the travel reads as full
 * scale near the top. One knob, then, for "how much of the room is the instrument allowed
 * to hear", and the DSP's own sources are told nothing about it.
 *
 * ZERO IS OFF, and it is off for the whole path: mic_process_block() returns before it
 * reads a byte, so a disabled microphone costs nothing at all. It is deliberately not
 * deinitialised — the PDM channel is brought up once at boot, when the internal DMA pool
 * still has room for it, and tearing it down to build it again later is how a board ends
 * up with a microphone it cannot re-open.
 */
static void apply_mic(float v01)
{
    s_mic_sens01 = clamp01f(v01);
    s_mic_sw_gain = mic_sw_gain_for(s_mic_sens01);

    if (s_mic_sens01 <= 0.0f) {
        s_mic_env01 = 0.0f;
        publish_mic_mod();
        return;
    }

    /*
     * THE DRIVER IS NOT TOUCHED FROM HERE, and this is the whole of why the boot overload
     * went away. bsp_audio_in_set_gain() reconfigures the PDM RX channel on its first call and
     * measured about 4.8 ms on the instrument — most of a block — and this applier runs in the
     * audio task. The call now belongs to the control task, through
     * synth_app_set_param() and mic_driver_sync() below; what the audio task does is what it
     * should: keep the software gain and follow the setting.
     */
}

/*
 * The microphone's DRIVER gain, written from wherever this is called and never from the audio
 * task. Called by synth_app_set_param() when the setting is SET_MIC — the control surface's own
 * task — and by the boot path before the audio task exists. Everything expensive is behind the
 * step comparison, so a turn that does not change the driver's step costs one compare.
 *
 * It reads the parameter rather than s_mic_sens01: the control task writes the parameter and
 * calls this at once, while s_mic_sens01 is the audio task's copy of it and is a block or more
 * behind — and a driver step computed from a stale setting would be the wrong step.
 */
static void mic_driver_apply(float sens01)
{
    if (sens01 <= 0.0f || s_mic_drv_gain_absent) {
        return;
    }

    const uint8_t gain_db = (uint8_t)(sens01 * MIC_GAIN_MAX_DB + 0.5f);
    const int step = mic_amplify_for(gain_db);

    if (step == s_mic_gain_step) {
        return;
    }

    const esp_err_t err = bsp_audio_in_set_gain(gain_db);
    if (err == ESP_ERR_NOT_SUPPORTED) {
        /* A property of the target, not a fault: this chip has no PDM RX amplify stage
         * (see the constants above), and it will not grow one while the firmware runs.
         * Asked once, remembered, and never asked again. */
        s_mic_drv_gain_absent = true;
        return;
    }
    if (err != ESP_OK) {
        /* Not logged here: the BSP logs the failure itself. The multiplier is left un-cached,
         * so the next detent tries again. */
        return;
    }
    s_mic_gain_step = step;
}

static void mic_driver_sync(void)
{
    mic_driver_apply(clamp01f(s_param[SYNTH_PARAM_SET_MIC]));
}

/*
 * The percussion voice, handed over whole.
 *
 * One applier for the five numbers, like the effects: they are not independent
 * settings, they are one drum. The voice reads them when a hit is STRUCK rather
 * than per sample, so a knob touched during a tail changes the next hit and not
 * the one in the air.
 *
 * DECAY goes in exactly as the knob has it. A ceiling stood here for a while, holding the
 * decay down on dense figures so that no more than three tails overlapped; it was removed
 * once the crackle it was meant to cure turned out to be the filter's
 * coefficients being rebuilt every sample. Three tails are the module's own design and it
 * steals for the fourth, so there was nothing left for a ceiling to protect.
 */
/*
 * The modulation generator.
 *
 * It lives here rather than in the DSP because the DSP's own LFOs run per block and nothing
 * outside can read their phase; a generator in the application can also be restarted by a note
 * or held for one, which is what the trigger modes need. The shape is the same SHAPE knob the
 * drone filter's LFO uses, so there is one answer to what the modulation looks like.
 *
 * The percussion's own clock advances the phase: one step of the figure is one beat, and the
 * phase moves by however much a beat lasts at the current tempo. The modulation is therefore
 * locked to the rhythm rather than to a stopwatch.
 *
 * That lock is also this generator's ceiling, and the SPEED knob reaches past it. The phase
 * moves once per step, so a hit reads the LFO sampled at the step rate — bpm/60, which the
 * tempo knob spans as 0.5 to 5 Hz over its 30..300 BPM. The rate SPEED asks for is 0.031 to
 * 6.000 Hz on LOW (motion_rate_for() with the LOW drift rate: the number the display prints),
 * so the top of the travel is above the step rate at EVERY tempo, and what a hit hears there
 * is the alias: at 200 BPM the phase advances 1.800 turns per step, which reads as 0.667 Hz
 * and not as 6 Hz. At 30/36/40/45/60/72/90/120/180 BPM, where 360/bpm is a whole number, it
 * advances by whole turns, so every hit lands on the same point of the shape and the
 * modulation stands still. That is sampling and not a fault: the phase itself is right at
 * every step (6.000 Hz at 30 BPM is 11.984 turns, so the wrap below costs at most twelve
 * subtractions), nothing slips, and the drift has no such ceiling because the engine's copy
 * of the same LFO is evaluated per block, at 187.5 Hz.
 */
/*
 * ДВА ГЕНЕРАТОРА МОДУЛЯЦИИ.
 *
 * У каждого своя фаза, своё удержание и свой триггер: это два независимых LFO, а не два
 * приёмника одного. Второй заведён и молчит: у него пока нет ни адресата, ни своих ручек,
 * поэтому звук от появления второго канала не меняется ни на бит.
 */
typedef struct {
    float phase;      /* 0..1, положение на форме */
    float hold;       /* значение, взятое удержанием на последней ноте */
    int   trig;       /* 0 свободно, 1 на ноту, 2 держать, 3 один проход */
    bool  held;       /* удержание стоит */
} mod_lfo_t;

#define MOD_LFO_COUNT 2

static mod_lfo_t s_lfo[MOD_LFO_COUNT];

/* Шаг фазы на блок и частота для подписи: считаются при смене ручки или темпа. */
static float s_lfo_phase_step[MOD_LFO_COUNT];
static float s_lfo_rate_hz[MOD_LFO_COUNT];

static void mod_rate_refresh(void)
{
    for (int ch = 0; ch < MOD_LFO_COUNT; ch++) {
        const synth_param_t rate_param = (ch == 0) ? SYNTH_PARAM_MOTION_RATE
                                                   : SYNTH_PARAM_MOD2_RATE;
        const int32_t mhz = motion_rate_for(s_drones[0].pan_rate1_mhz, s_param[rate_param]);
        const float hz = (float)mhz * 0.001f;

        s_lfo_rate_hz[ch] = hz;
        s_lfo_phase_step[ch] = hz * ((float)SYNTH_BLOCK_SAMPLES / (float)SYNTH_SAMPLE_RATE);
    }
}

static float clamp01f(float v)
{
    /* Same negated lower test as clamp01(): NaN goes to the low bound, not through. */
    if (!(v >= 0.0f)) {
        return 0.0f;
    }
    return (v > 1.0f) ? 1.0f : v;
}

/*
 * What the SHAPE knob is standing on, 0..LFO_SHAPE_COUNT-1, and the count itself is
 * defined with the microphone's constants above. One conversion for the generator, the
 * DSP and the readout, so the three cannot disagree about which shape a position means.
 */
/*
 * Положение ручки SHAPE у канала: 0..LFO_SHAPE_SLOTS-1. Первые восемь — свободные формы,
 * дальше семь с триггером; у MIC триггера нет, потому что перезапускать в конверте нечего.
 */
static int lfo_shape_slot(int ch)
{
    const synth_param_t param = (ch == 0) ? SYNTH_PARAM_LFO_SHAPE : SYNTH_PARAM_MOD2_SHAPE;
    const float raw = s_param[param];
    const float v = (raw >= 0.0f) ? ((raw > 1.0f) ? 1.0f : raw) : 0.0f;
    int slot = (int)(v * (float)(LFO_SHAPE_SLOTS - 1) + 0.5f);

    if (slot < 0) {
        slot = 0;
    } else if (slot > LFO_SHAPE_SLOTS - 1) {
        slot = LFO_SHAPE_SLOTS - 1;
    }
    return slot;
}

/* Из слота в форму: слот 8..14 — та же форма (слот − 8), но с триггером. */
static int lfo_shape_index_ch(int ch)
{
    const int slot = lfo_shape_slot(ch);

    return (slot < LFO_SHAPE_COUNT) ? slot : (slot - LFO_SHAPE_COUNT);
}

static int lfo_shape_index(void)
{
    return lfo_shape_index_ch(0);
}

/* Триггер ли выбранный слот: вторая половина списка. */
static bool lfo_triggered_ch(int ch)
{
    return lfo_shape_slot(ch) >= LFO_SHAPE_COUNT;
}

static float mod_wave(int shape, float phase)
{
    switch (shape) {
    case 0:
        return sinf(phase * 6.2831853f);
    case 1:
        return 1.0f - 4.0f * fabsf(phase - 0.5f);
    case 2:
        return phase < 0.5f ? 1.0f : -1.0f;
    case 3:
        return 1.0f - 2.0f * phase;
    case 4: {
        /*
         * СЛУЧАЙНАЯ — СТУПЕНЯМИ, А НЕ РЯБЬЮ.
         *
         * Здесь стояло phase * 43758.5: значение менялось на каждом шаге фазы, то есть на
         * каждом блоке и каждом кадре, независимо от SPEED — индикатор дёргался, а ручка
         * скорости ни на что не влияла. Теперь фаза делится на восемь ступеней, и значение
         * берётся хешем от номера ступени: смена — раз в восьмую оборота, поэтому быстрота
         * случайной формы задаётся скоростью, как и у остальных.
         */
        const int steps = 8;
        int k = (int)(phase * (float)steps);

        if (k < 0) {
            k = 0;
        } else if (k >= steps) {
            k = steps - 1;
        }

        uint32_t h = (uint32_t)k * 2654435761u;

        h ^= h >> 15;
        h *= 2246822519u;
        h ^= h >> 13;

        return ((float)(h & 0xFFFFu) / 32767.5f) - 1.0f;
    }
    default:
        break;
    }
    /* Five and six are the exponential pair: a rise and a fall shaped like an envelope, which
     * is what a drum wants — a fast move and a long settle rather than an even sweep. */
    if (shape == 5) {
        return -expf(-6.0f * (1.0f - phase));   /* EXP+: from zero down to minus one */
    }
    return -expf(-6.0f * phase);              /* EXP-: from minus one up to zero */
}

static void mod_advance_ch(int ch)
{
    /* Through seq_tempo_now(), not the mapping written out again: the modulation clock has
     * to run at the tempo the sequencer and the readout are on, and a second copy of the
     * formula is how the two come apart — the more so now that the tempo can come from a
     * cable rather than from the knob. */
    /*
     * ФАЗА ДВИГАЕТСЯ НА КАЖДЫЙ БЛОК, КАК В DSP.
     *
     * Раньше она двигалась раз за шаг секвенсора: удар читал LFO с частотой шага, а наверху
     * SPEED получался алиас — 6 Гц читались как 0.7. Теперь шаг — это блок (5.33 мс), и
     * модуляция идёт с той частотой, что стоит на ручке. Глубины не меняются: они
     * по-прежнему множители на приёмник, а не часть фазы.
     */
    /*
     * СВОЯ СКОРОСТЬ У КАЖДОГО КАНАЛА. Здесь стоял параметр первого LFO для обоих, поэтому
     * второй шёл со скоростью первого, и его индикация не отвечала его же ручке SPEED.
     */
    /*
     * ШАГ ФАЗЫ КЭШИРОВАН. motion_rate_for() зовётся при смене ручки SPEED (и темпа), а не
     * каждый блок: у блока бюджет 5.33 мс, и лишняя кривая на каждые 5 мс — это уже
     * недостача, из-за которой звук начинает пропускать блоки.
     */
    (void)s_lfo_rate_hz[ch];
    const float step_s = (float)SYNTH_BLOCK_SAMPLES / (float)SYNTH_SAMPLE_RATE;

    /* A held value stands until the next note, so the phase stops moving. */
    if (s_lfo[ch].trig == 2 && s_lfo[ch].held) {
        return;
    }

    s_lfo[ch].phase += s_lfo_phase_step[ch];

    if (s_lfo[ch].trig == 3) {
        /* One pass and stop: the end of the shape is where an envelope settles. */
        if (s_lfo[ch].phase >= 1.0f) {
            s_lfo[ch].phase = 1.0f;
            s_lfo[ch].held = true;
        }
        return;
    }

    while (s_lfo[ch].phase >= 1.0f) {
        s_lfo[ch].phase -= 1.0f;
    }
}

/* The modulation as the rest of the file asks for it: the running shape, the value a HOLD
 * took and is still keeping, or — when MIC is chosen — the microphone's envelope. */
static float mod_value_ch(int ch)
{
    /*
     * MIC first, and before the trigger modes on purpose: a trigger is about a phase that
     * is restarted or frozen, and the envelope has no phase. HOLD therefore means nothing
     * while MIC is the source rather than holding a stale point on a waveform.
     *
     * The envelope arrives as 0..1 where a waveform is -1..1, so everything it drives moves
     * one way from its base: the percussion's pitch and the lead's step go up, never down.
     * That is what an envelope is, and it is the same law the filter uses.
     */
    /*
     * ФОРМА — СВОЕГО КАНАЛА. Здесь стоял lfo_shape_index(), то есть форма ПЕРВОГО LFO:
     * второй канал играл и показывал не то, что выбрано на его странице, хотя скорость
     * брал свою. Отсюда и «скорость правильная, а форма чужая».
     */
    const int slot = lfo_shape_slot(ch);
    const int shape = (slot < LFO_SHAPE_COUNT) ? slot : (slot - LFO_SHAPE_COUNT);

    if (shape == LFO_SHAPE_MIC) {
        return s_mic_env01;
    }
    if (s_lfo[ch].trig == 2 && s_lfo[ch].held) {
        return s_lfo[ch].hold;
    }
    if (s_lfo[ch].trig == 3 && s_lfo[ch].held) {
        return mod_wave(shape, 1.0f);
    }
    return mod_wave(shape, s_lfo[ch].phase);
}

/* Оба канала — одна механика; наружу первый, как и было. */
static void mod_advance(void)
{
    mod_advance_ch(0);
    mod_advance_ch(1);   /* второй LFO: своя фаза, своя скорость */
}

static float mod_value(void)
{
    return mod_value_ch(0);
}

/*
 * ВКЛАД ОДНОГО LFO В ПРИЁМНИК.
 *
 * Возвращает две суммы сразу, потому что приёмники берут их по-разному: see mod_sum01() и
 * mod_sum_pm(). Глубина берётся та, что относится к тому приёмнику: DEST — первая, DEST2 —
 * вторая; приёмник, выбранный в обоих, получает сумму глубин.
 */
/*
 * ГЛУБИНА СО ЗНАКОМ.
 *
 * Ход ручки 0..1 означает −1..+1: середина — ноль, правый край — полная в фазе, левый —
 * полная в противофазе. Отрицательная глубина переворачивает вклад LFO, а не меняет его
 * величину: на слух это та же форма, качающая в другую сторону.
 */
static float depth_pm(synth_param_t param)
{
    float v = s_param[param];

    if (!(v > 0.0f)) {
        v = 0.0f;
    } else if (v > 1.0f) {
        v = 1.0f;
    }

    return v * 2.0f - 1.0f;
}

static float mod_contrib(int ch, uint32_t bit)
{
    const uint32_t d1 = mod_dest_bits_of(ch == 0 ? SYNTH_PARAM_MOD_DEST : SYNTH_PARAM_MOD2_DEST);
    const uint32_t d2 = mod_dest_bits_of(ch == 0 ? SYNTH_PARAM_MOD_DEST2 : SYNTH_PARAM_MOD2_DEST2);
    float g = 0.0f;

    if (d1 & bit) {
        g += depth_pm(ch == 0 ? SYNTH_PARAM_MOD_DEPTH : SYNTH_PARAM_MOD2_DEPTH);
    }
    if (d2 & bit) {
        g += depth_pm(ch == 0 ? SYNTH_PARAM_MOD_DEPTH2 : SYNTH_PARAM_MOD2_DEPTH2);
    }

    return mod_value_ch(ch) * g;
}

/* Сумма глубин, приходящихся на приёмник: Σ dᵢ. Нужна тем, у кого закон 1 − d·(1 − w). */
static float mod_depth_sum(uint32_t bit)
{
    float g = 0.0f;

    for (int ch = 0; ch < 2; ch++) {
        const uint32_t d1 = mod_dest_bits_of(ch == 0 ? SYNTH_PARAM_MOD_DEST : SYNTH_PARAM_MOD2_DEST);
        const uint32_t d2 = mod_dest_bits_of(ch == 0 ? SYNTH_PARAM_MOD_DEST2 : SYNTH_PARAM_MOD2_DEST2);

        if (d1 & bit) {
            g += depth_pm(ch == 0 ? SYNTH_PARAM_MOD_DEPTH : SYNTH_PARAM_MOD2_DEPTH);
        }
        if (d2 & bit) {
            g += depth_pm(ch == 0 ? SYNTH_PARAM_MOD_DEPTH2 : SYNTH_PARAM_MOD2_DEPTH2);
        }
    }

    return g;
}

/* Сумма по обоим LFO сырых значений: Σ dᵢ·wᵢ. */
static float mod_sum01(uint32_t bit)
{
    return mod_contrib(0, bit) + mod_contrib(1, bit);
}

/*
 * Сумма двусторонних значений: Σ dᵢ·(2wᵢ − 1).
 *
 * Считается как 2·Σdᵢwᵢ − Σdᵢ, чтобы не удваивать проход: обе величины уже есть в
 * mod_contrib(), а глубина приёмника — это сумма g первого и второго приёмника того же LFO.
 */
static float mod_sum_pm(uint32_t bit)
{
    const float s = mod_sum01(bit);
    float g = 0.0f;

    for (int ch = 0; ch < 2; ch++) {
        const uint32_t d1 = mod_dest_bits_of(ch == 0 ? SYNTH_PARAM_MOD_DEST : SYNTH_PARAM_MOD2_DEST);
        const uint32_t d2 = mod_dest_bits_of(ch == 0 ? SYNTH_PARAM_MOD_DEST2 : SYNTH_PARAM_MOD2_DEST2);

        if (d1 & bit) {
            g += clamp01f(s_param[ch == 0 ? SYNTH_PARAM_MOD_DEPTH : SYNTH_PARAM_MOD2_DEPTH]);
        }
        if (d2 & bit) {
            g += clamp01f(s_param[ch == 0 ? SYNTH_PARAM_MOD_DEPTH2 : SYNTH_PARAM_MOD2_DEPTH2]);
        }
    }

    return 2.0f * s - g;
}

/* A lead note is what NOTE and HOLD are measured against. FREE does nothing here. */
static void mod_note(void)
{
    if (s_lfo[0].trig == 1) {
        s_lfo[0].phase = 0.0f;
        s_lfo[0].held = false;
    } else if (s_lfo[0].trig == 2) {
        s_lfo[0].hold = mod_wave(lfo_shape_index(), s_lfo[0].phase);
        s_lfo[0].held = true;
    } else if (s_lfo[0].trig == 3) {
        /* ONE SHOT: the shape starts over at the note and runs one pass, then stands on
         * its own last value until the next note. That is what turns an exponential shape
         * into an envelope. */
        s_lfo[0].phase = 0.0f;
        s_lfo[0].held = false;
    }

    /* The drone's own LFOs are in the engine and cannot be read from here, so the note is
     * told to them: NOTE and ONES start their shape over, FREE and HOLD leave it running. */
    if (s_lfo[0].trig == 1 || s_lfo[0].trig == 3) {
        synth_drone_lfo_retrigger();
    }
}

static void apply_mod_trig(float v01)
{
    int t = (int)(v01 * 3.0f + 0.5f);

    if (t < 0) {
        t = 0;
    } else if (t > 3) {
        t = 3;
    }
    if (t != 2) {
        s_lfo[0].held = false;
    }
    s_lfo[0].trig = t;

    /* The filter and the pan are told the same mode: the DSP knows these four, in this order. */
    synth_drone_lfo_trig(t);
}

/*
 * The percussion's share of the modulation is no longer worked out here.
 *
 * It used to be a detour through the knobs: the offset was added to PERC_PITCH, PERC_ENV,
 * PERC_DECAY and PERC_BODY, apply_perc() was called, and the knobs were put back, so that the
 * hit the engine triggered a line later would carry the modulated values. That was the only
 * way with one voice whose knobs were the sound.
 *
 * The drum section sets the voice from a RECIPE for every hit — the kit's numbers, moved by
 * the trims, the velocity and the walk — so the modulation has somewhere to land: see
 * perc_apply_mod(), which moves the hit that is about to be struck and leaves the knobs and
 * the preset alone by construction, because the recipe is a local copy.
 */
static int seq_scale_note(int note);   /* below, where the scales are */

/*
 * The percussion's centre, pulled onto the scale. Called from the control surface, in
 * synth_app_set_param(), and NOT from the audio path — see the note at the end of this comment.
 *
 * The knob is a frequency and the instrument already knows which notes are in play, so with
 * PERC QUANT on the pitch lands on the nearest of them rather than anywhere between. The
 * NEAREST step and the same tie rule as every other quantised note in this file — the
 * distance is measured in semitones, folded into one octave, and the winner is added back —
 * because seq_scale_note() is the one place that decision is made and a second copy of it
 * would drift from the first.
 *
 * The answer is written BACK into s_param[], and that is the whole trick: the readout, the
 * knob's arc and the DSP all read the same number, so the display cannot claim a frequency
 * the voice is not playing. The conversion goes through synth_perc_pitch_01() rather than
 * repeating the voice's range here.
 *
 * Called for every write of PITCH, and for SCALE, ROOT and PERC QUANT, because each of those
 * changes the answer — a scale moved under a tuned kick retunes the kick.
 */
static void perc_pitch_snap(void)
{
    if (!(s_param[SYNTH_PARAM_PERC_QUANT] > 0.5f)) {
        return;
    }

    const float hz = synth_perc_pitch_hz(s_param[SYNTH_PARAM_PERC_PITCH]);

    /* MIDI 69 is 440 Hz, and the note the voice is nearest to is the one to round to. */
    const float midi = 69.0f + 12.0f * log2f(hz / 440.0f);

    /* The notes the voice can reach, as MIDI numbers. 26..117, and taken from the voice's own
     * range rather than written down here. */
    /*
     * Five cents of slack at each end, and the number matters.
     *
     * The ends of the travel are not notes: the voice's range is 35 Hz to 7030.9 Hz against a
     * scale built on 440, so the top of the knob sits two cents under A9 and the bottom just
     * over C#1. Without the slack the topmost note in the scale was discarded as unreachable
     * and the knob stopped a fourth short of its own end; with too much the bottom would take
     * C#1 and clamp it to 35 Hz, which is seventeen cents off and a readout that lies.
     */
    const int note_min = (int)ceilf(69.0f + 12.0f * log2f(synth_perc_pitch_hz(0.0f) / 440.0f) - 0.05f);
    const int note_max = (int)floorf(69.0f + 12.0f * log2f(synth_perc_pitch_hz(1.0f) / 440.0f) + 0.05f);

    const int want = (int)lroundf(midi);
    int note = want;

    /*
     * Outward from where the hand is, and the first note the scale accepts that the voice can
     * also play wins. The nearest step to the bottom of the travel can lie under the range —
     * the scale's answer there would be a note the voice cannot reach, and clamping the
     * frequency afterwards would put a note back that the scale never chose.
     */
    for (int d = 0; d <= 12; d++) {
        const int up = seq_scale_note(want + d);
        if (up >= note_min && up <= note_max) {
            note = up;
            break;
        }

        const int down = seq_scale_note(want - d);
        if (down >= note_min && down <= note_max) {
            note = down;
            break;
        }
    }

    s_param[SYNTH_PARAM_PERC_PITCH] = synth_perc_pitch_01(440.0f * exp2f(((float)note - 69.0f) / 12.0f));


}

static void apply_perc(void)
{
    /*
     * THE VOICE IS NO LONGER SET FROM THE KNOBS, and that is the drum section's whole
     * difference: perc_strike() sets it from a recipe a moment before every trigger, so what
     * a hit sounds with is the kit, the trims and the velocity of THAT hit and not a value a
     * knob left standing. There is nothing here to write to the voice, and writing the old
     * knobs would retune the tail of the last hit for no reason.
     *
     * What is left is what belongs to the part rather than to the hit: the fader's send. The
     * send is scaled by the fader here and not in the rack, because a fader at zero has to
     * mean silence and not silence-plus-the-room: with the send left open the drum would
     * still be heard as a reverb tail after its level was pulled down, which is the one thing
     * a fader must never do.
     */
    synth_rack_set_perc_send(s_param[SYNTH_PARAM_SEND_PERC]
                             * level_gain(clamp01f(s_param[SYNTH_PARAM_PERC_LEVEL])));

    /*
     * And the ring goes back to the part as written — BUT ONLY WHILE THE DRUM IS STOPPED.
     *
     * It used to do it on every write, and that is what made the ring look wrong: a run of
     * knob moves is a run of writes, so while a player turned VARIATION or FILL the ring kept
     * snapping back to the written bar and stayed there until the next bar line. The drum was
     * playing the varied bar and the ring was showing the one it started from — the dots that
     * the move adds were missing for as long as the hand was moving, which reads as an
     * instrument that has lost the picture of itself. With the transport running the bar being
     * played owns the ring (perc_new_bar() writes it at every bar line), and a knob move changes
     * the NEXT bar's picture, which is exactly when it takes effect.
     *
     * Stopped, the reset is what it always was: the part as chosen, so a drum that has never
     * played still shows what it will play, and a groove chosen on the panel appears at once.
     */
    if (!s_running) {
        perc_show_written();
    }
}

/*
 * THE BASS SECTION, and the whole of how it reaches the engine.
 *
 * The twelve macros are handed over one at a time — synth_bass_set(id, value01) is the
 * module's whole control surface — so this applier reads the group out of s_param[] and
 * pushes all twelve on every call, the way apply_perc() hands the drum its part: the table
 * below is the translation from the patch's parameters to the module's own ids, and the
 * static_assert makes a macro added to one side and not the other a build failure rather
 * than a control that quietly does nothing.
 *
 * THE FADER AND THE SENDS ARE THE RACK'S, and the arithmetic is the PERC one. apply_perc()
 * ends on synth_rack_set_perc_send(SEND_PERC * level_gain(PERC_LEVEL)), and the reason is
 * written there: the rack takes a layer's send from the signal BEFORE that layer's level, so
 * an unscaled send would leave a reverb tail hanging after its fader was pulled down — and a
 * fader at zero has to mean silence, not silence plus the room. The bass's level is a real
 * rack fader, so the level itself is written once and the three sends are scaled by it here,
 * by the same fader law, for the same reason. That also keeps the readout honest: the level
 * prints the gain it lands on, not the travel.
 */
static void apply_bass(void)
{
    static const struct {
        synth_param_t      param;   /* the patch's */
        synth_bass_param_t id;      /* the module's */
    } BASS_MACROS[] = {
        { SYNTH_PARAM_BASS_KIT,    SYNTH_BASS_KIT },
        { SYNTH_PARAM_BASS_OCT,    SYNTH_BASS_OCT },
        { SYNTH_PARAM_BASS_TONE,   SYNTH_BASS_NOTE },     /* слот 2: смена ноты */
        { SYNTH_PARAM_BASS_DECAY,  SYNTH_BASS_DECAY },
        { SYNTH_PARAM_BASS_SNAP,   SYNTH_BASS_SNAP },
        { SYNTH_PARAM_BASS_DRIVE,  SYNTH_BASS_DRIVE },
        { SYNTH_PARAM_BASS_PAT,    SYNTH_BASS_PAT },
        { SYNTH_PARAM_BASS_VAR,    SYNTH_BASS_VAR },
        { SYNTH_PARAM_BASS_LEN,    SYNTH_BASS_LEN },
        { SYNTH_PARAM_BASS_GATE,   SYNTH_BASS_GATE },
        { SYNTH_PARAM_BASS_SLIDE,  SYNTH_BASS_SLIDE },
        { SYNTH_PARAM_BASS_ACCENT, SYNTH_BASS_ACCENT },
    };

    static_assert(sizeof(BASS_MACROS) / sizeof(BASS_MACROS[0]) == (size_t)SYNTH_BASS_PARAM_COUNT,
                  "every bass macro must have exactly one row");

    for (size_t i = 0; i < sizeof(BASS_MACROS) / sizeof(BASS_MACROS[0]); i++) {
        synth_bass_set((int)BASS_MACROS[i].id, clamp01f(s_param[BASS_MACROS[i].param]));
    }

    /* Акцент — фигура, как в остальных разделах: та же таблица ACCENT_MASK, своё число. */
    synth_bass_set_accent_mask(accent_mask_of(SYNTH_PARAM_BASS_ACCENT));

    /* Транспозиция — вторая вещь после клока, которую бас берёт у прибора. */
    apply_bass_root();

    const float level = level_gain(clamp01f(s_param[SYNTH_PARAM_BASS_LVL]));

    /*
     * ПОСЫЛ — ЧИСТАЯ РУЧКА. Уровень умножается в стойке, на пути в шину, и один раз для всех:
     * пока он множился ещё и здесь, бас получал свой уровень дважды.
     */
    synth_rack_set_layer_level(SYNTH_LAYER_BASS, level);
    synth_rack_set_reverb_send(SYNTH_LAYER_BASS, s_param[SYNTH_PARAM_BASS_REV]);
    synth_rack_set_chorus_send(SYNTH_LAYER_BASS, s_param[SYNTH_PARAM_BASS_CHR]);
    synth_rack_set_delay_send(SYNTH_LAYER_BASS, s_param[SYNTH_PARAM_BASS_DLY]);
}

/*
 * ТОНИКА БАСА: та же, что у прибора, но двумя октавами ниже и в басовом регистре.
 *
 * Бас обязан идти за транспозицией — это единственное, кроме клока, что он берёт у
 * инструмента. Но играть тонику как есть нельзя: на C2 бас звучал бы в регистре лида, а на
 * C6 ушёл бы в писк. Поэтому тоника прибора отводится на октаву вниз и складывается в окно
 * A1..A2 (MIDI 33..45, 55..110 Гц): смена тональности двигает линию, а регистр остаётся
 * басовым и при этом слышимым на любом динамике.
 */
static void apply_bass_root(void)
{
    /*
     * E1..E2: 41..82 Гц. Заготовки и рисунки идут вверх от корня до октавы, так что линия
     * живёт в 41..165 Гц — регистр, в котором бас и читается басом. Прошлое окно (A1..A2)
     * ставило основную ноту на 110 Гц, и с октавными рисунками она уходила в 220 — это уже
     * не бас, и владелец слышал «тихо и низко» именно как отсутствие баса.
     */
    int midi = seq_root_midi() - 24;

    while (midi < 28) {
        midi += 12;
    }
    while (midi > 40) {
        midi -= 12;
    }

    synth_bass_set_root_hz(440.0f * powf(2.0f, (float)(midi - 69) * (1.0f / 12.0f)));
}

/*
 * THE BASS FOLLOWS THE INSTRUMENT'S CLOCK, not a second one of its own.
 *
 * One tempo is the whole reason the bass is a layer of this instrument rather than a module
 * beside it: two clocks at the same number are still two grids that drift apart by a block
 * now and then, and a bass a block off the drum is the one error the ear never forgives.
 *
 * It is called from the same three doors the delay's tempo is, and for the same reason:
 * the parameter's own case, and the two places the MIDI clock moves the tempo underneath it
 * — the lock and each measured window (see midi_clock_tick() and midi_clock_block()). A
 * fourth door would be a fourth chance for one of the three to be updated and not the other.
 */
static void apply_bass_tempo(void)
{
    synth_bass_set_tempo(seq_tempo_now());
}

/*
 * The shape of the drone is a per-REGISTER control: each of the three registers has its own
 * list and its own three voices, so H.OSC, M.OSC and L.OSC can be three different things.
 * The lead still has one choice for the part, because its groups are the same
 * instrument playing the player's chords.
 *
 * A change lands on the next block like everything else and re-triggers nothing — the voices
 * are the same voices with a different shape, which is the whole point of being able to
 * choose one while it is sounding.
 */
static synth_param_t drone_osc_param(int register_index)
{
    static const synth_param_t p[DRONE_REGISTERS] = {
        SYNTH_PARAM_DRONE_OSC_LOW,
        SYNTH_PARAM_DRONE_OSC_MID,
        SYNTH_PARAM_DRONE_OSC_HIGH,
    };
    return p[register_index];
}

static void apply_drone_wave(void)
{
    bool retune = false;

    for (int r = 0; r < DRONE_REGISTERS; r++) {
        const int wave = param_wave_drone(drone_osc_param(r));

        /* Only the registers whose shape changed are written, and this is not only about
         * the work: a setWaveSmooth() call for the shape a voice already has drops a fade
         * that was waiting behind the running one, so re-writing a neighbour would swallow
         * a request made a block earlier. A preset load changes all three — see below. */
        if (wave == s_drone_wave[r]) {
            continue;
        }

        /*
         * A change of shape is crossfaded — see WAVE_MORPH_MS — EXCEPT at either end of the
         * supersaw, and the exception is the honest part of this. SPR is not a shape: it is the
         * same anti-aliased saw, on the same three voices, with the detune multiplied by
         * SUPER_SPREAD, so SAW and SPR are one generator and there is nothing to fade between. What
         * changes at that boundary is the TUNING, and drone_retune() below writes it with
         * setFrequency(), which has no glide: the outer voices of a group step by up to 14 cents
         * the moment the knob moves. Crossfading the shape there would hide that pitch step behind
         * a timbre fade, which is worse than the step itself — the ear would hear the pitch move
         * with the timbre and read it as a portamento this instrument does not have. So the boundary
         * is instant, by construction rather than by luck, and this is where it is decided.
         *
         * A PRESET LOAD COMES THROUGH THIS SAME CALL, and fades the same way — deliberately. A load
         * is a batch that travels over the slide (see synth_app_preset_load()), but a shape is a LIST,
         * and a list jumps even inside a batch: apply_pending_params() sends every parameter with
         * steps straight to its destination. So on a load the continuous knobs travel and the shape
         * is the one thing that would step — which is the other half of why this fade is here.
         */
        const bool was_super = s_drone_super[r];

        s_drone_super[r] = (wave == PW_SPR);
        s_drone_wave[r] = wave;
        retune = retune || was_super || s_drone_super[r];

        const uint16_t morph = (was_super || s_drone_super[r]) ? 0 : wave_morph_ms();

        for (int v = 0; v < DRONE_VOICES_PER_REGISTER; v++) {
            const uint16_t voice = (uint16_t)(s_drones[r].first_voice + v);
            /* One voice at a time: the position within the PART is the delay, so the ninth
             * voice starts its fade 160 ms after the first and only one of them is ever
             * rendered twice in the same block. That the stagger runs across register
             * boundaries is what makes three simultaneous shape changes — a preset load —
             * nine fades 20 ms apart instead of three at once. */
            wave_apply(voice, wave, morph,
                       (uint16_t)((voice - DRONE_VOICE_BASE) * WAVE_MORPH_STAGGER_MS));
        }
    }

    /* A supersaw IS a wider detune, so the drone has to be retuned: unlike the lead it has
     * no next note on which to pick the new spread up. setFrequency rather than noteOn, so
     * the drone does not restart its two-and-a-half second attack. A change that stays on
     * the same side of the boundary does not touch the tuning at all. */
    if (retune) {
        drone_retune();
    }
}

static void apply_lead_wave(void)
{
    const int wave = param_wave(SYNTH_PARAM_LEAD_WAVE);

    /* The same exception as the drone's, for the same reason — and the same crossfade
     * everywhere else, a preset load included (see apply_drone_wave()). The stagger is here
     * too: the three voices of a group are rendered together, and a fade is a second render
     * each. */
    const bool was_super = s_lead_super;
    s_lead_super = (wave == PW_SPR);
    const uint16_t morph = (was_super || s_lead_super) ? 0 : wave_morph_ms();

    /* The arp's group takes the lead's wave with the rest of the lead: it is the
     * same instrument playing the same held keys, one note at a time. */
    for (int v = 0; v < LEAD_CONFIGURED_VOICES; v++) {
        wave_apply((uint16_t)(LEAD_VOICE_BASE + v), wave, morph,
                   (uint16_t)(v * WAVE_MORPH_STAGGER_MS));
    }

    /* No retune here, and it is not an oversight: the lead's voices are gated, so the next
     * note takes the new spread. Retuning now would move a note that is already sounding. */
}

static void apply_pending_params(void)
{
    /*
     * The slide, first, because it decides what every value below IS this block.
     *
     * The request says only "a batch has arrived". The starting point is taken here, out of
     * s_cur[], which is this task's own record of what is sounding. Nothing is snapshotted by
     * the caller, and nothing crosses the task boundary except a flag and a duration.
     */
    /*
     * АВТОЗАПУСК ЗДЕСЬ НЕ РЕШАЕТСЯ. Порядок в main.c: synth_app_start() создаёт звуковую
     * задачу РАНЬШЕ, чем app_settings_init() читает настройки, поэтому и старт, и первый
     * блок видят заводские значения. Решение принимает main.c сразу после чтения настроек.
     */

    s_slide_tick++;

    if (s_slide_req) {
        s_slide_req = false;

        if (s_slide_ms > 0.0f) {
            /* One step per block, so the step is one over the number of blocks the duration
             * spans: block_hz blocks a second, for this many seconds. What stood here divided
             * blocks a second BY the seconds, which finished a three-second slide inside a
             * single block — 125 steps of 1125 — and is why nothing ever appeared to move. */
            const float block_hz = (float)SYNTH_SAMPLE_RATE / (float)SYNTH_BLOCK_SAMPLES;
            s_slide_step = 1.0f / (block_hz * (s_slide_ms * 0.001f));

            /* Откуда ехать: что звучит прямо сейчас, из своего же массива. */
            for (int p = 0; p < (int)SYNTH_PARAM_COUNT; p++) {
                s_from[p] = s_cur[p];
            }
            s_slide_pos = 0.0f;
        } else {
            s_slide_pos = 1.0f;
        }

        s_slide_taken = true;
    }

    if (s_slide_pos < 1.0f) {
        s_slide_pos += s_slide_step;
        if (s_slide_pos > 1.0f) {
            s_slide_pos = 1.0f;
        }
    }

    for (int p = 0; p < (int)SYNTH_PARAM_COUNT; p++) {
        const float target = s_param[p];

        /* A batch arriving at once is what this used to be for every parameter; a slide is the
         * same code with a position somewhere between the two. The settings are the last block
         * of the enum by construction, which is how they are told apart here. */
        const bool jump = (s_slide_pos >= 1.0f) ||
                          (p >= (int)SYNTH_PARAM_SET_SCREEN) ||
                          (synth_app_param_steps((synth_param_t)p) > 0);

        const float v = jump ? target : (s_from[p] + (target - s_from[p]) * s_slide_pos);
        s_cur[p] = v;

        if (v == s_applied[p]) {
            continue;
        }

        /*
         * The write is thinned to one block in SLIDE_APPLY_EVERY while a slide is travelling,
         * and only then: a parameter that JUMPS — a stepped one, a setting, anything on the
         * last block of a slide — is written the block it changes. s_applied[] is left alone
         * on a thinned block, so the next one that does write carries everything the three
         * before it accumulated, and the parameter lands on its target exactly.
         */
        if (!jump && (s_slide_tick % SLIDE_APPLY_EVERY) != 0u) {
            continue;
        }
        s_applied[p] = v;

        switch ((synth_param_t)p) {
        case SYNTH_PARAM_LEVEL:        apply_level(v);        break;
        case SYNTH_PARAM_MASTER_COMP:  apply_comp(v);         break;
    case SYNTH_PARAM_MASTER_DUCK:  synth_rack_set_duck(v); break;
    case SYNTH_PARAM_MASTER_DUCK_SRC: synth_rack_set_duck_src(v); break;
    case SYNTH_PARAM_MASTER_DUCK_REL: synth_rack_set_duck_rel(v); break;
        /*
         * THE DRIVE IS GONE, and these two are here only because removing an entry from the
         * middle of the enum would shift every parameter after it and turn every stored sound
         * into a different one. The slots keep their place, the appliers do nothing, and no
         * page offers them. See FEATURES.
         */
        case SYNTH_PARAM_LEAD_PW:      apply_lead_pw(v);      break;
        case SYNTH_PARAM_LEAD_SPREAD:  lead_chord_pan(v); break;
        case SYNTH_PARAM_CUTOFF:       apply_cutoff(v);       break;
        case SYNTH_PARAM_RESONANCE:    apply_resonance(v);    break;
        case SYNTH_PARAM_FILTER_RATE:  apply_filter_rate(v);  break;
        case SYNTH_PARAM_FILTER_DEPTH: apply_filter_depth(v); break;
        case SYNTH_PARAM_MOTION_DEPTH: apply_motion_depth(v); break;
        case SYNTH_PARAM_MOTION_RATE:  apply_motion_rate(v); mod_rate_refresh(); break;
        case SYNTH_PARAM_MOD2_RATE:    mod_rate_refresh();    break;
        case SYNTH_PARAM_LEAD_LEVEL:   apply_lead_level(v);   break;
        case SYNTH_PARAM_LFO_SHAPE:    apply_lfo_shape(v);    break;
    case SYNTH_PARAM_MOD_DEST:     apply_mod_dest(v); mod_pw_tick(); break;
    case SYNTH_PARAM_MOD_DEST2:    apply_mod_dest2(v); mod_pw_tick(); break;
    case SYNTH_PARAM_MOD_TRIG:     apply_mod_trig(v);     break;
    case SYNTH_PARAM_MOD_DEPTH:    apply_mod_depth(v);    break;   /* pan, filter sweep, filter rate */
        /* The generation parameters are not engine state either, so there is
         * nothing to write here. The sequencer reads them at the top of every
         * step, which is the only moment they can mean anything. */
        /* The tempo is engine state only through the delay, which follows it
         * whenever it is synced, and now through the bass, whose clock is this one. */
        case SYNTH_PARAM_SEQ_TEMPO:    apply_delay(); apply_bass_tempo(); apply_fx_tempo(); mod_rate_refresh(); break;
        case SYNTH_PARAM_SEQ_GATE:    lead_fenv_times_apply(); break;   /* the note got shorter */
        case SYNTH_PARAM_SCALE:                               break;
        case SYNTH_PARAM_ROOT:                                apply_bass_root(); break;
        case SYNTH_PARAM_ROOT_OCT:                            apply_bass_root(); break;
        /* Read where a step is struck, like the lead's: see arp_velocity(). */
        case SYNTH_PARAM_ARP_ACCENT:                          break;
        case SYNTH_PARAM_DENSITY:                             break;
        case SYNTH_PARAM_OCTAVE:                              break;
        case SYNTH_PARAM_SEQ_STEPS:                           break;
        case SYNTH_PARAM_SEQ_PULSES:                          break;
        case SYNTH_PARAM_SEQ_ROTATE:                          break;
        case SYNTH_PARAM_SEQ_SCATTER:                         break;
        case SYNTH_PARAM_DRONE_LOW:    apply_drone_mix(0, v); break;
        case SYNTH_PARAM_DRONE_MID:    apply_drone_mix(1, v); break;
        case SYNTH_PARAM_DRONE_HIGH:   apply_drone_mix(2, v); break;
        case SYNTH_PARAM_DRONE_WAVE:   break;   /* the old single shape: the migration's business */
        case SYNTH_PARAM_DRONE_OSC_LOW:
        case SYNTH_PARAM_DRONE_OSC_MID:
        case SYNTH_PARAM_DRONE_OSC_HIGH: apply_drone_wave();  break;
        /* FOLLOW is read where it is used, once a block, in drone_tune_tick(): the drone's
         * shift is a function of the mode, the root, the scale and the newest note, and the
         * tick is the one place all four are in hand. Writing anything here would only
         * duplicate it. */
    case SYNTH_PARAM_DRONE_FOLLOW:                        break;
        /* The two key trackers are multipliers on the two cutoffs, so a change of either is
         * a republish of that cutoff and nothing else: one exp2f and the slots it writes. The
         * drone's exponent comes from the shift in force, which is why its cutoff is also
         * republished from drone_tune_tick() when a note moves it — a knob turned while a
         * note is held would otherwise be the only way to hear the change. */
        case SYNTH_PARAM_DRONE_KTRCK:  apply_cutoff(s_param[SYNTH_PARAM_CUTOFF]); break;
        case SYNTH_PARAM_LEAD_KTRCK:   apply_lead_cutoff(s_param[SYNTH_PARAM_LEAD_CUTOFF]); break;
        case SYNTH_PARAM_DRONE_FILTER_MODE: apply_filter_mode(v); break;
        case SYNTH_PARAM_LEAD_FILTER_MODE:  apply_lead_filter_mode(v);  break;
        case SYNTH_PARAM_LEAD_WAVE:    apply_lead_wave();     break;
        case SYNTH_PARAM_LEAD_CUTOFF:  apply_lead_cutoff(v);  break;
        case SYNTH_PARAM_LEAD_RESO:    apply_lead_reso(v);    break;
        case SYNTH_PARAM_LEAD_ENV:     apply_lead_env(v);     break;
        case SYNTH_PARAM_LEAD_ATTACK:  apply_lead_attack(v);  break;
        case SYNTH_PARAM_LEAD_DECAY:   apply_lead_decay(v);   break;
        case SYNTH_PARAM_LEAD_SUSTAIN: apply_lead_sustain(v); break;
        case SYNTH_PARAM_LEAD_RELEASE: apply_lead_release(v); break;
        case SYNTH_PARAM_LEAD_FENV_SHAPE: apply_lead_fenv_shape(v); break;
    case SYNTH_PARAM_LEAD_VOICE:      apply_lead_voice(v);      break;
        /* The lead's glide and the arpeggiator read these where they are used: at
         * the moment a note is chosen. There is no engine state to write, and
         * writing one the instant the knob moved would change a note that is
         * already sounding. */
        case SYNTH_PARAM_LEAD_PORTA:                          break;
        case SYNTH_PARAM_ARP_DIR:                             break;
        case SYNTH_PARAM_ARP_SPEED:                           break;
        case SYNTH_PARAM_ARP_LEN:                             break;
        case SYNTH_PARAM_ARP_RANGE:                           break;

        /* One applier per effect, not per parameter: the rack is handed whole
         * effects, and each of these reads the rest of its group out of the table
         * that apply_pending_params has already updated. */
        case SYNTH_PARAM_DELAY_SYNC:     apply_delay();       break;
        case SYNTH_PARAM_DELAY_TIME:     apply_delay();       break;
    case SYNTH_PARAM_DELAY_DAMP:     synth_rack_set_delay_damp(v); break;
    case SYNTH_PARAM_DELAY_FEEDBACK: apply_delay();       break;
        case SYNTH_PARAM_DELAY_MIX:      apply_delay();       break;
        case SYNTH_PARAM_DELAY_TYPE:     synth_delay_set_type((int)(v * 5.0f + 0.5f)); break;
        case SYNTH_PARAM_DELAY_TIMEMODE: apply_delay();       break;
        case SYNTH_PARAM_DELAY_VERB:     synth_rack_set_delay_verb(v); break;
        case SYNTH_PARAM_CHORUS_MIX:     apply_chorus();      break;
        case SYNTH_PARAM_CHORUS_RATE:    apply_chorus();      break;
        case SYNTH_PARAM_CHORUS_DEPTH:   apply_chorus();      break;
        case SYNTH_PARAM_FX_TYPE:        apply_chorus();      break;
        case SYNTH_PARAM_FX_C:           apply_chorus();      break;
        case SYNTH_PARAM_FX_VERB:        synth_rack_set_fx_verb(v); break;
        case SYNTH_PARAM_VERB_MODE:      apply_reverb();      break;
        case SYNTH_PARAM_VERB_SIZE:      apply_reverb();      break;
        case SYNTH_PARAM_VERB_DAMP:      apply_reverb();      break;
        case SYNTH_PARAM_VERB_MIX:       apply_reverb();      break;
        case SYNTH_PARAM_SEND_LOW:       apply_reverb_send(); break;
        case SYNTH_PARAM_SEND_MID:       apply_reverb_send(); break;
        case SYNTH_PARAM_SEND_HIGH:      apply_reverb_send(); break;
        case SYNTH_PARAM_SEND_LEAD:      apply_reverb_send(); break;
        /* Dead slots: the microphone is a modulation source and nothing else. They keep
         * their appliers so a stored patch still loads and still writes zeros; see
         * apply_reverb_send(). */
        case SYNTH_PARAM_SEND_MIC:       apply_reverb_send(); break;
    case SYNTH_PARAM_CHR_SEND_LOW:   apply_chorus_send(); break;
    case SYNTH_PARAM_CHR_SEND_MID:   apply_chorus_send(); break;
    case SYNTH_PARAM_CHR_SEND_HIGH:  apply_chorus_send(); break;
    case SYNTH_PARAM_CHR_SEND_LEAD:  apply_chorus_send(); break;
    case SYNTH_PARAM_CHR_SEND_PERC:  apply_chorus_send(); break;
    case SYNTH_PARAM_CHR_SEND_MIC:   apply_chorus_send(); break;
    case SYNTH_PARAM_DLY_SEND_LOW:   apply_delay_send();  break;
    case SYNTH_PARAM_DLY_SEND_MID:   apply_delay_send();  break;
    case SYNTH_PARAM_DLY_SEND_HIGH:  apply_delay_send();  break;
    case SYNTH_PARAM_DLY_SEND_LEAD:  apply_delay_send();  break;
    case SYNTH_PARAM_DLY_SEND_PERC:  apply_delay_send();  break;
    case SYNTH_PARAM_DLY_SEND_MIC:   apply_delay_send();  break;

        /*
         * The microphone's sensitivity. This is the one setting that also has to reach
         * the audio path, and it does so through the same task boundary as everything
         * else: apply_mic() only records the setting and hands the driver its new gain,
         * and mic_process_block() below is what reads the microphone — or does not, when
         * the setting is at zero.
         */
        case SYNTH_PARAM_SET_MIC:        apply_mic(v);        break;

        /* DRIVE POSITION: a dead setting, kept in the enum so the stored settings after it
         * keep their slots. Nothing reads it any more. */
        case SYNTH_PARAM_SET_DRIVE_POS:  break;

        /* The drum part. Its figure is read at the top of every step, like the
         * lead's, so those three have no engine state to write; the voice itself is
         * one drum and is handed over in one piece. RES keeps its branch even though
         * its knob is gone: the parameter is still in the list, and a preset or a
         * random draw can still write it — apply_perc() is what ignores it. */
        case SYNTH_PARAM_PERC_PITCH:     apply_perc();        break;
        case SYNTH_PARAM_PERC_RESO:      apply_perc();        break;
        case SYNTH_PARAM_PERC_DECAY:     apply_perc();        break;
        case SYNTH_PARAM_PERC_ENV:       apply_perc();        break;
        case SYNTH_PARAM_PERC_LEVEL:     apply_perc();        break;
        case SYNTH_PARAM_PERC_BODY:      apply_perc();        break;
        case SYNTH_PARAM_PERC_QUANT:     apply_perc();        break;
        case SYNTH_PARAM_SEND_PERC:      apply_perc();        break;
        case SYNTH_PARAM_PERC_STEPS:                          break;
        case SYNTH_PARAM_PERC_PULSES:                         break;
        case SYNTH_PARAM_PERC_ROTATE:                         break;

        /* The bass section, one applier for the whole part, for the drum's reason: the voice
         * and the figure are handed over together and the layer's fader and sends are read
         * out of the same table, so a write that arrives for one macro cannot leave the
         * others a block behind. See apply_bass(). */
        case SYNTH_PARAM_BASS_KIT:       apply_bass();        break;
        case SYNTH_PARAM_BASS_OCT:       apply_bass();        break;
        case SYNTH_PARAM_BASS_TONE:      apply_bass();        break;
        case SYNTH_PARAM_BASS_DECAY:     apply_bass();        break;
        case SYNTH_PARAM_BASS_SNAP:      apply_bass();        break;
        case SYNTH_PARAM_BASS_DRIVE:     apply_bass();        break;
        case SYNTH_PARAM_BASS_PAT:       apply_bass();        break;
        case SYNTH_PARAM_BASS_VAR:       apply_bass();        break;
        case SYNTH_PARAM_BASS_LEN:       apply_bass();        break;
        case SYNTH_PARAM_BASS_GATE:      apply_bass();        break;
        case SYNTH_PARAM_BASS_SLIDE:     apply_bass();        break;
        case SYNTH_PARAM_BASS_ACCENT:    apply_bass();        break;
        case SYNTH_PARAM_BASS_LVL:       apply_bass();        break;
        case SYNTH_PARAM_BASS_REV:       apply_bass();        break;
        case SYNTH_PARAM_BASS_CHR:       apply_bass();        break;
        case SYNTH_PARAM_BASS_DLY:       apply_bass();        break;
        default:                                              break;
        }
    }
}

/* -------------------------------------------------------------------------- */
/* The slide's two doors                                                      */
/* -------------------------------------------------------------------------- */
/*
 * Marking a batch, and choosing how long a batch takes.
 *
 * The request is raised from the control surface, the snapshot is taken in the control task,
 * and the caller writes the new values as soon as this returns — so this waits for the
 * snapshot. It has to. "The worst a badly-timed call can do" was written when every batch was
 * forty writes long and a block boundary never fell inside such a burst; a single parameter is
 * written in a microsecond, the snapshot then found the new value already in place, and a ramp
 * with nowhere to travel from is no ramp. What arrives is a jump.
 *
 * Bounded, and a tick is 1 ms here (CONFIG_FREERTOS_HZ=1000): a stalled control task costs
 * this call its patience and not the UI a hang. Every caller is the control surface — nothing
 * on the audio side calls it — so the task that has to set the flag is never the one waiting.
 */
extern "C" void synth_app_slide_begin(void)
{
    s_slide_taken = false;
    s_slide_req = true;

    for (int i = 0; i < 20 && !s_slide_taken; i++) {
        vTaskDelay(1);
    }
}

/* What the SLIDE setting resolved to, for the log: 0 means a batch arrives at once. */
extern "C" float synth_app_slide_ms(void)
{
    return s_slide_ms;
}

extern "C" void synth_app_slide_set_index(int index)
{
    if (index < 0) {
        index = 0;
    } else if (index >= SLIDE_COUNT) {
        index = SLIDE_COUNT - 1;
    }
    s_slide_ms = (float)SLIDE_MS[index];
}

/* -------------------------------------------------------------------------- */
/* Lead sequencer                                                             */
/* -------------------------------------------------------------------------- */

static uint32_t s_seq_rng;
/* ~0 rather than 0, so the very first block after boot takes step zero instead of
 * waiting for the grid to come round to it. */
static uint32_t s_seq_prev = (uint32_t)~0u;  /* the step of the previous block */
static uint32_t s_seq_current;      /* the phrase step playing now, for the display */
static uint32_t s_seq_pending;      /* blocks until a scheduled onset; 0 = none */
static uint32_t s_seq_fire_index;   /* the phrase step that onset belongs to */
static uint32_t s_seq_fire_raw;     /* and the transport step it physically occupies */
static uint32_t s_seq_gate_left;
static int      s_seq_degree;
static int      s_seq_n;            /* the grid values in force, latched */
static int      s_seq_k;
static int      s_seq_rot;

/*
 * WHERE THE LEAD'S PHRASE STANDS, and the whole of what the LEAD'S RESET moves.
 *
 * s_seq_origin is the transport's grid step (bar * n + local, counted from START) on
 * which the phrase's first step fell. The phrase step is (g - s_seq_origin) % n, so
 * changing the origin rewinds the phrase and nothing else: the transport, the drum and
 * the gate arithmetic never look at it. Only START and the lead's RESET gesture write it;
 * the drum's phrase has an origin of its own beside the drum (s_perc_origin), and neither
 * gesture can reach the other's.
 *
 * s_lead_grid is the n the origin was taken in. STEPS is a knob, and the same bar
 * divided differently is a different step count, so a change of n re-anchors the phrase
 * on the bar (origin = bar * n) instead of inheriting a count from a grid that no longer
 * exists.
 *
 * s_lead_grid_prev is the transport's step as of the last block, updated every block
 * whether or not the lead is the figure playing, because the gesture may only fire on a
 * step boundary — firing inside a step would cut the gate of the note already sounding.
 */
static uint64_t s_seq_origin;
static uint32_t s_lead_grid;
static uint32_t s_lead_grid_prev = (uint32_t)~0u;

/* xorshift32. The sequencer needs unpredictability, not cryptography, and this
 * is four instructions in a task that has 5333 microseconds per block. */
static uint32_t seq_rand(void)
{
    s_seq_rng ^= s_seq_rng << 13;
    s_seq_rng ^= s_seq_rng >> 17;
    s_seq_rng ^= s_seq_rng << 5;
    return s_seq_rng;
}

/*
 * The tempo mapping, and the ONE place it is written down. Every consumer goes through
 * here — the delay's division of the beat, the sequencer's step, the modulation clock
 * and the readout — so none of them can disagree about the tempo the knob is asking for.
 *
 * Rounded to a WHOLE BPM. The parameter stays continuous (synth_app_param_steps()
 * returns 0 for it, so the encoder keeps its acceleration and a change still slides), but
 * the number a player reads and plays to is a whole BPM, and the transport's own grid is
 * now fine enough to land on every one of the 271 values between 30 and 300. Rounding
 * here rather than at the readout is what keeps the clock, the delay and the number on
 * the screen on the same tempo: a readout that rounded while the clock did not would
 * print 120 for a step the sequencer was playing at 119.43.
 */
static float seq_tempo_bpm(float v01)
{
    return (float)(int)(SEQ_TEMPO_MIN_BPM * exp2f(v01 * SEQ_TEMPO_SPAN) + 0.5f);
}

/* Equal temperament from A4 = 440 Hz, the tuning the registers were designed in. */
static float midi_to_hz(int note)
{
    return 440.0f * exp2f(((float)note - 69.0f) / 12.0f);
}

static uint32_t detuned_centihz(float hz, int cents)
{
    return (uint32_t)(hz * exp2f((float)cents / 1200.0f) * 100.0f + 0.5f);
}

/* -------------------------------------------------------------------------- */
/* The lead's groups: which note is on which three voices                     */
/* -------------------------------------------------------------------------- */
/*
 * A group is one note: the two detuned oscillators and the sub, on three
 * consecutive voices starting at LEAD_VOICE_BASE + group * LEAD_GROUP_VOICES.
 * These four arrays are the whole of the lead's allocation — the engine has no
 * allocator, so it is this table that turns "play this note" into "these three
 * voice indices", and nothing else in the file holds a voice number for the lead.
 *
 * The NOTE is stored rather than a flag, for the two questions a note-off and a
 * repeated note-on ask: which group is playing this key, and is this key already
 * sounding somewhere. LEAD_NOTE_FREE is a group with nothing in it;
 * LEAD_NOTE_GEN is the sequencer's or the arp's own note, which has no MIDI
 * number to be found by and is the one thing that is handed over rather than
 * shared when the player arrives — see lead_group_alloc().
 *
 * The stamp is the note-on order, and it is what "oldest" means when a group has
 * to be taken: one increment per note opened, never reset, so two notes cannot
 * tie however long the instrument runs. The pitch per group is where that group's
 * last note was ASKED to be, kept for the glide to start from — asked for rather
 * than read back from the engine, because the group's voices are detuned against
 * each other and asking one of them where it got to would give a different answer
 * depending on which voice was asked.
 */
#define LEAD_NOTE_FREE   (-1)
#define LEAD_NOTE_GEN    (-2)
#define LEAD_NOTE_ARP    (-3)   /* the arpeggiator's own note, while keys are held */
#define LEAD_GEN_GROUP   0      /* the sequencer's, and the arp figure's, own group */

/*
 * FOUR TABLES, ONE PER GROUP, and the fourth is the arp's.
 *
 * It is in the same arrays rather than beside them because everything that keeps
 * the lead coherent — the filter gate, the clearing on release, the glide's memory
 * of what this group last played — has to see it: a note the arp has open is a note
 * the lead is playing, and the filter gate that ignored it would close over it.
 *
 * The one thing that does NOT see it is the allocator, and that is on purpose:
 * lead_group_alloc() and lead_group_owning() walk the PLAYER'S groups, so a key
 * from the wire can neither take the arp's group nor be found in it. LEAD_NOTE_ARP
 * is a second lock on the same door: should either walk ever be widened to
 * LEAD_GROUP_COUNT, an arp entry is still not a LEAD_NOTE_GEN one, and only the
 * generator's own note is handed over.
 *
 * THE TABLE IS INITIALISED FREE, every group of it. Written out rather than left to
 * .bss, because zero is a note number: an untouched table would claim that all four
 * groups were holding MIDI note 0, and while the allocator happens to land on group
 * 0 either way, "group 3 is holding note 0" would make lead_arp_group_off() believe
 * the arp had a note open before it had ever played one.
 */
static int16_t  s_lead_note[LEAD_GROUP_COUNT] = {
    LEAD_NOTE_FREE, LEAD_NOTE_FREE, LEAD_NOTE_FREE, LEAD_NOTE_FREE, LEAD_NOTE_FREE
};
static_assert(LEAD_GROUP_COUNT == 5, "the initialiser above must name every group");
static uint32_t s_lead_stamp[LEAD_GROUP_COUNT];
static uint32_t s_lead_serial;
static float    s_lead_group_hz[LEAD_GROUP_COUNT];

/*
 * THE GENERATOR'S OWN TWO COUNTDOWNS, one pair per PLAYER group.
 *
 * The sequencer used to be one note in one group: it opened group 0 at a step, and
 * the gate's expiry closed that group a moment later. NOW A STEP TAKES A NEW GROUP
 * while the previous note is still ringing — that is what makes a long release
 * overlap the next step — so each generator note has to be followed to its own end,
 * and the two steps of that end are counted here per group:
 *
 *   s_gen_gate[g]  blocks until the note's gate is up and its voices are let go;
 *   s_gen_tail[g]  blocks until the group is FREE again, which is the amplitude
 *                  release: the group is not reusable while it is still sounding.
 *
 * The tail is what makes the overlap work and what bounds it. Four groups are
 * shared with the player's keys and the arp's is not among them: at a gate shorter
 * than the release, four notes can overlap and the fifth onset takes the oldest of
 * them — the voice stealing the player's own chords use, on the machine's line.
 */
static uint16_t s_gen_gate[LEAD_GROUPS];
static uint16_t s_gen_tail[LEAD_GROUPS];

/* The pitch the generator's PREVIOUS note was asked for, for PORTA to glide from.
 * Per line and not per group, because with the groups handed round it is the note
 * before this one in the melody, not the note this group played four steps ago. */
static float s_gen_last_hz;

/* The filter's note-on counter: see lead_fenv_retrigger(). */
static uint16_t s_lead_retrig;

/*
 * Tell the filter that a note has started.
 *
 * The filter used to read that off the gate's rising edge, and it cannot any more:
 * with a step able to overlap the one before it, the gate stays up across steps and
 * never falls between them. So the app counts notes and the filter watches the
 * count — one slot write per note, and ep[4] is the slot the AR left free when it
 * gave up its decay. See synth_lead_filter.cpp.
 */
static void lead_fenv_retrigger(void)
{
    /* Pre-increment: the filter starts at zero, so the first note of a session has to
     * write one rather than zero. The counter is free to wrap; only a difference
     * between two blocks means anything. */
    lead_filter_slot(0, 4,
                          (int16_t)(++s_lead_retrig));
}

/*
 * ВСЕ ШИНЫ ЛИДА.
 *
 * Слой, на котором лид живёт всегда, и три шины аккорда: в режиме CHORD ноты уходят на них,
 * и фильтр обязан стоять на каждой — иначе его ручки в аккорде не делают ничего. Владелец
 * поймал именно это: «не слышу работу фильтра лида».
 *
 * Панорама сюда НЕ входит: у шин аккорда свои панорамы.
 */
static const uint8_t LEAD_BUSES[] = {
    (uint8_t)(SYNTH_LAYER_LEAD + 1),
    (uint8_t)LEAD_CHORD_BUS0,
    (uint8_t)(LEAD_CHORD_BUS0 + 1),
    (uint8_t)(LEAD_CHORD_BUS0 + 2),
};

#define LEAD_BUS_COUNT ((int)(sizeof(LEAD_BUSES) / sizeof(LEAD_BUSES[0])))

/*
 * Какой набор шин сейчас живой: шина слоя или три шины аккорда.
 *
 * Флаг нужен, чтобы НЕ ТРОГАТЬ ненужные копии фильтра: у них срез пишется нулём, и фильтр
 * выходит из строя на первом же сравнении (так устроено его тело), то есть стоит почти
 * ничего. Раньше ненужные копии СНИМАЛИСЬ через setBusFX — а тот стирает ep и es, и смена
 * пресета, в котором другой режим VOICE, обнуляла состояние фильтра на ходу: владелец слышал
 * это как треск при переключении пресетов 03 -> 04.
 */
static bool s_lead_filter_chord_mode = false;

/*
 * ФИЛЬТР ЛИДА СТОИТ НА СУММЕ СЛОЯ, А НЕ НА ШИНАХ.
 *
 * Параметры идут прямым сеттером, один раз, а не на каждую шину: копий теперь две — левый и
 * правый канал собранного слоя.
 */
static void lead_filter_slot(uint8_t slot, uint8_t id, int16_t value)
{
    (void)slot;
    synth_lead_filter_param(id, value);
}

/*
 * ФИЛЬТР РАБОТАЕТ ТОЛЬКО ТАМ, ГДЕ ПОЮТ НОТЫ.
 *
 * В аккорде ноты уходят на три шины аккорда, в остальных режимах — на шину слоя. Четыре
 * копии фильтра, из которых три (или одна) считают тишину, стоили 490 мкс вместо 156:
 * владелец услышал это как треск на пределе. Поэтому ненужные копии СНИМАЮТСЯ, а при смене
 * режима нужные ставятся заново и получают все свои параметры.
 *
 * Регистрация стирает ep и es (так устроен setBusFX), поэтому после неё параметры пишутся
 * заново — этого требует сам движок, а не аккуратность.
 */
static void lead_filter_repush(void);

static void lead_buses_mode(bool chord)
{
    /*
     * РЕЖИМ БОЛЬШЕ НЕ ВЛИЯЕТ НА ФИЛЬТР: он один, на сумме слоя, и одинаков в любом режиме.
     * От режима зависит только маршрут голосов, и это решает lead_group_bus().
     */
    (void)chord;
    lead_filter_repush();
}

static uint16_t lead_voice_of(int group, int v)
{
    return (uint16_t)(LEAD_VOICE_BASE + group * LEAD_GROUP_VOICES + v);
}

/*
 * Куда эта группа поёт: обычный слой лида или одна из трёх шин аккорда.
 *
 * Ставится на каждом включении ноты, а не один раз при выборе режима: группа достаётся то
 * аккорду, то одиночной ноте, и забытая маршрутизация оставила бы ноту в чужой шине — то
 * есть с чужой панорамой.
 */
static void lead_group_bus(int group, int chord_note)
{
    const uint8_t bus = (chord_note >= 0 && chord_note < LEAD_CHORD_NOTES)
                            ? (uint8_t)(LEAD_CHORD_BUS0 + chord_note)
                            : (uint8_t)(SYNTH_LAYER_LEAD + 1);

    for (int v = 0; v < LEAD_GROUP_VOICES; v++) {
        s_synth.setVoiceBus(lead_voice_of(group, v), bus);
    }
}

/* The group playing this key, or -1. One audible note, one group: a note-off has
 * to close its own note and no other, which is the whole of what polyphony adds
 * to the release path. */
static int lead_group_owning(int note)
{
    for (int g = 0; g < LEAD_GROUPS; g++) {
        if (s_lead_note[g] == (int16_t)note) {
            return g;
        }
    }
    return -1;
}

/*
 * The lead filter's gate, from the group table rather than from the event.
 *
 * The filter is the BUS's and the FX runs where it cannot see voices, so it is
 * told when a note starts and stops — but with four groups, "the note" is not a
 * thing the release of one key can speak for: letting the last key of a chord
 * close the gate would cut the envelope of the notes still sounding under it.
 * So the gate follows whether ANY group is open, computed after the table has
 * been changed, and a single-note line writes exactly the ones and zeros it
 * always did.
 *
 * ALL FOUR GROUPS, the arp's included: while keys are held it is the arp's note
 * that is the lead's newest, and a filter gate that shut under it would cut the
 * third of a second of filter envelope the step was played with. With nothing held
 * the fourth entry is FREE and this loop answers exactly what it always did.
 */
static void lead_gate_update(void)
{
    bool any = false;

    for (int g = 0; g < LEAD_GROUP_COUNT; g++) {
        if (s_lead_note[g] != LEAD_NOTE_FREE) {
            any = true;
        }
    }

    lead_filter_gate(any ? 1 : 0);
}

/* Close one group: its three voices and its place in the table. The others are
 * untouched — they are other notes. */
static void lead_group_off(int group)
{
    for (int v = 0; v < LEAD_GROUP_VOICES; v++) {
        s_synth.noteOff(lead_voice_of(group, v));
    }

    s_lead_note[group] = LEAD_NOTE_FREE;
    if (group < LEAD_GROUPS) {
        s_gen_gate[group] = 0;
        s_gen_tail[group] = 0;
    }
    lead_gate_update();
}

/*
 * Close the arpeggiator's own group, if it has one open.
 *
 * The test is the point. With no key held the arp plays the figure in the
 * generator's group and this one is FREE, so this is one comparison and no engine
 * call at all — which is what lets the release paths below stay bit for bit the
 * lines they were while still being able to let an arp note go.
 */
static void lead_arp_group_off(void)
{
    if (s_lead_note[LEAD_ARP_GROUP] == LEAD_NOTE_FREE) {
        return;
    }
    lead_group_off(LEAD_ARP_GROUP);
}

/*
 * One block of the generator's notes: the gate that lets each of them go, and the
 * tail that keeps its group out of the allocator until the note has finished.
 *
 * It runs every block on the audio task and does nothing at all when the sequencer
 * is silent: a loop over four entries, two comparisons, and no engine call.
 *
 * THE GATE IS NOT THE TAIL. A note whose gate is up is still held; a note whose gate
 * has expired is still AUDIBLE, for as long as its amplitude release lasts, and the
 * group must not be given to the next step until that release is over — otherwise
 * every step would cut the tail of the one before it and the overlap would never be
 * heard. The tail is the LEAD RELEASE knob's own time, read here because it is what
 * the engine's envelope was configured with.
 */
static void lead_gen_tick(void)
{
    for (int g = 0; g < LEAD_GROUPS; g++) {
        if (s_lead_note[g] != LEAD_NOTE_GEN) {
            /* Not ours any more: a key or the arp owns the group, and lead_group_off()
             * or lead_group_claim() has already zeroed the two countdowns. */
            s_gen_gate[g] = 0;
            s_gen_tail[g] = 0;
            continue;
        }

        if (s_gen_gate[g] > 0) {
            s_gen_gate[g]--;
            if (s_gen_gate[g] == 0) {
                for (int v = 0; v < LEAD_GROUP_VOICES; v++) {
                    s_synth.noteOff(lead_voice_of(g, v));
                }

                const float ms = lead_time_for(s_cur[SYNTH_PARAM_LEAD_RELEASE]);
                uint32_t blocks = (uint32_t)(ms * ((float)SYNTH_SAMPLE_RATE
                                                   / (float)SYNTH_BLOCK_SAMPLES) * 0.001f
                                             + 0.5f);
                if (blocks < 1u) {
                    blocks = 1u;
                }
                if (blocks > 65000u) {
                    blocks = 65000u;
                }
                s_gen_tail[g] = (uint16_t)blocks;
            }
        } else if (s_gen_tail[g] > 0) {
            s_gen_tail[g]--;
            if (s_gen_tail[g] == 0) {
                s_lead_note[g] = LEAD_NOTE_FREE;
                lead_gate_update();
            }
        }
    }
}

/*
 * Which group a note plays in.
 *
 * THE GROUP ALREADY HOLDING THE KEY WINS, so a key pressed twice is one note
 * retriggered and not a second copy of itself — the same rule the held list
 * applies, and the reason a host repeating a note-on cannot fill the lead with
 * one key.
 *
 * THE GENERATOR'S GROUP IS HANDED OVER first, whenever the search needs a group
 * at all: while the sequencer or the arp is playing, the player's first key must
 * take that note over rather than leave it sounding underneath. No noteOff is sent
 * for it — the player's note opens the same three voices a block later at most,
 * and the engine's own retrigger is exactly what the lead has always done when a
 * keyboard took it over.
 *
 * THEN A FREE GROUP, lowest index, so the map fills in one direction and nothing
 * depends on where a hole happens to be. (The generator's group is 0, so a
 * handed-over note is also the one a first key lands on.)
 *
 * THEN THE OLDEST IS STOLEN. Four notes at once is the instrument, not a limit to
 * be worked around, and a fifth key has to sound: the note the player has been
 * holding longest is the one furthest from what they are playing now, which is
 * why it is the standard victim on an instrument with no spare voice. The
 * alternatives are worse in a way that is audible — dropping the newest would
 * break a chord exactly while it is being played as one, and dropping the lowest
 * would make the bottom of every chord the note that disappears. The stolen group
 * is retriggered, not faded: a note-on on voices that are already sounding is a
 * new note, and it is how the monophonic lead already replaced itself.
 *
 * THE ARP'S GROUP IS OUTSIDE ALL THREE LOOPS, and the loop bound is the whole of
 * how: LEAD_GROUPS and not LEAD_GROUP_COUNT. A key from the wire is allocated
 * among the player's four groups and can neither land on the arp's group nor take
 * it as the oldest — so a key that is opened can never be confused with the arp's
 * step, and the arp's step can never take a key's voices. (While the arp is on no
 * key is allocated here at all: the arp walks the keys in its own group, see
 * arp_lead_tick().)
 */
/*
 * Группа для одной ноты одного события.
 *
 * Отличие от lead_group_alloc() одно: там повторное нажатие той же ноты находит свою
 * группу и перезапускается в ней. Аккорду этого мало — его три ноты несут ОДИН номер
 * клавиши, и вторая с третьей получили бы группу первой. Поэтому may_reuse разрешает
 * такое совпадение только первой ноте события, а остальные берут свободную или старейшую.
 */
static int lead_group_take(int note, bool may_reuse)
{
    /*
     * MONO: ОДНА ГРУППА, ВСЕГДА ОДНА И ТА ЖЕ. Это правило переехало сюда из
     * lead_group_alloc(), когда клавиша перестала быть единственным его читателем:
     * в моно аккорда быть не может, сколько бы клавиш ни держали, и каждая новая
     * заменяет предыдущую в группе генератора.
     */
    if (!s_lead_poly) {
        return LEAD_GEN_GROUP;
    }

    if (may_reuse) {
        for (int g = 0; g < LEAD_GROUPS; g++) {
            if (s_lead_note[g] == (int16_t)note) {
                return g;
            }
        }
    }

    for (int g = 0; g < LEAD_GROUPS; g++) {
        if (s_lead_note[g] == LEAD_NOTE_FREE) {
            return g;
        }
    }

    int oldest = 0;
    for (int g = 0; g < LEAD_GROUPS; g++) {
        if (s_lead_stamp[g] < s_lead_stamp[oldest]) {
            oldest = g;
        }
    }
    return oldest;
}


/* The group now belongs to that note: the stamp is what makes "oldest" mean
 * something, and it is written on every note-on, retriggered or stolen or not. */
static void lead_group_claim(int group, int note)
{
    s_lead_note[group] = (int16_t)note;
    s_lead_stamp[group] = ++s_lead_serial;

    /* A group that changes hands stops being the generator's, and its countdowns
     * must stop with the entry: a countdown left running would let go of a note
     * that belongs to the player. The arp's group is one past these two arrays. */
    if (group < LEAD_GROUPS) {
        s_gen_gate[group] = 0;
        s_gen_tail[group] = 0;
    }
}

/* Nothing is held and nothing is sounding: the whole lead, table included, so
 * that no later lookup can find a note no voice is playing. The arp's entry goes
 * with the rest — its voices are closed by lead_arp_group_off() immediately before
 * this, so an entry left behind would be exactly the lie this function exists to
 * prevent. */
static void lead_groups_clear(void)
{
    for (int g = 0; g < LEAD_GROUP_COUNT; g++) {
        s_lead_note[g] = LEAD_NOTE_FREE;
    }
    for (int g = 0; g < LEAD_GROUPS; g++) {
        s_gen_gate[g] = 0;
        s_gen_tail[g] = 0;
    }
}

/*
 * MONO and POLY, one switch over the same four groups.
 *
 * MONO is the instrument before the overlap: every note takes one group and retriggers
 * its three voices, so a release is cut by the note that follows it, and the keys are
 * heard one at a time. POLY is the four groups the sequencer learned to hand round.
 *
 * TURNING THE KNOB TO MONO TAKES THE EXTRA GROUPS AWAY rather than waiting for their
 * notes to end. A lead that is monophonic and still sounding three tails is not
 * monophonic, and the tails are the whole of what the switch is about — so the groups
 * past the first are closed here, through lead_group_off(), which sends the note-offs
 * and lets the engine's release finish them.
 *
 * It does nothing at all in POLY beyond setting the flag: the groups are allocated on
 * demand by the two allocators, and there is nothing to switch on.
 */
static void apply_lead_voice(float v01)
{
    /*
     * ТРИ ПОЛОЖЕНИЯ, И НОЛЬ — ЭТО POLY.
     *
     * Порядок POLY, MONO, CHORD, то есть тот, в котором прибор жил до появления третьего
     * положения: VOICE хранится байтом шкалы, и ноль обязан значить то, что он значил.
     * Тогда ни один сохранённый звук не переписывается — пресет, записанный год назад,
     * читается как POLY, потому что POLY в нём и был, — и заводская настройка тоже POLY,
     * ведь она и есть ноль. Порядок «по возрастанию возможностей» (MONO первым) стоил бы
     * молчаливого переворота у всех старых записей, а это цена не за чтение ручки.
     *
     * CHORD третьим, как и был: он не степень полифонии, а другое поведение — аккорд из
     * одной клавиши, — и место у него за пределами выбора mono/poly.
     */
    const int pos = (int)(clamp01f(v01) * 2.0f + 0.5f);
    const bool chord = (pos == 2);
    const bool poly = (pos == 0) || chord;

    /*
     * CHORD СЧИТАЕТСЯ ПОЛИФОНИЧЕСКИМ ДЛЯ РАСПРЕДЕЛИТЕЛЯ ГРУПП, и это не оговорка.
     * Аккорд — три ноты одного события, и каждая обязана получить свою группу; правило
     * MONO («одна группа, всегда одна и та же») складывало все три в группу генератора,
     * где каждая следующая заменяла предыдущую, и из трёх нот слышалась одна — ровно то,
     * на что владелец и пожаловался. Поэтому s_lead_poly здесь истинно и для аккорда:
     * группы берутся свободные, а не одна. Сам аккорд при этом остаётся аккордом —
     * s_lead_chord решает, сколько нот играть, а этот флаг только где им жить.
     */
    s_lead_chord = chord;
    s_lead_poly = poly;

    /* Копии фильтра стоят только на тех шинах, где в этом режиме поют ноты: четыре копии,
     * из которых три считают тишину, стоили 490 мкс вместо 156. */
    lead_buses_mode(chord);

    if (!poly) {
        for (int g = LEAD_GEN_GROUP + 1; g < LEAD_GROUPS; g++) {
            if (s_lead_note[g] != LEAD_NOTE_FREE) {
                lead_group_off(g);
            }
        }
    }
}

static void seq_release(void)
{
    for (int v = 0; v < LEAD_VOICES; v++) {
        s_synth.noteOff((uint16_t)(LEAD_VOICE_BASE + v));
    }

    /* ...and the arp's group, which is not among those nine voices: while keys are
     * held the arp sounds there, and this is the path that takes the lead back —
     * the last key's release — so leaving its note open would leave the arp's last
     * step sounding under a lead that is supposed to be silent. Nothing is open in
     * the case that matters for bit-for-bit: with no key held the test returns
     * before an engine call is made. */
    lead_arp_group_off();

    lead_groups_clear();

    /* The line starts again from nothing: no pitch to glide from and no filter
     * envelope to continue out of. */
    s_gen_last_hz = 0.0f;

    /* The filter's envelope follows the note it belongs to, and the FX runs on
     * the bus where it cannot see voices — so it is told. */
    lead_filter_gate(0);
}

static const seq_scale_cfg_t *seq_scale(void)
{
    int i = (int)(s_param[SYNTH_PARAM_SCALE] * (float)(SEQ_SCALE_COUNT - 1) + 0.5f);
    if (i < 0) {
        i = 0;
    } else if (i >= SEQ_SCALE_COUNT) {
        i = SEQ_SCALE_COUNT - 1;
    }
    return &SEQ_SCALES[i];
}

static int seq_scale_index(void)
{
    return (int)(seq_scale() - SEQ_SCALES);
}

/*
 * The tonic, from its two lists: the note (0..11) and the octave (1..7).
 *
 * The octave list is MIDI octaves, so note 0 in octave 1 is C1 = MIDI 24 and note 11 in
 * octave 7 is B7 = MIDI 107. Both are clamped rather than trusted — a patch or a preset is a
 * stored number and this is where it becomes a pitch — and the product is clamped again so
 * that no future widening of either list can leave the range.
 */
static int seq_root_midi(void)
{
    const int note = (int)(clamp01f(s_param[SYNTH_PARAM_ROOT]) * 11.0f + 0.5f);
    const int oct = (int)(clamp01f(s_param[SYNTH_PARAM_ROOT_OCT]) * 6.0f + 0.5f);

    int midi = 12 * (oct + 2) + note;

    if (midi < SEQ_ROOT_MIN_MIDI) {
        midi = SEQ_ROOT_MIN_MIDI;
    } else if (midi > SEQ_ROOT_MAX_MIDI) {
        midi = SEQ_ROOT_MAX_MIDI;
    }
    return midi;
}

/*
 * A single stored root, counted out on the eighty-five semitone list, as the two positions
 * the patch keeps now.
 *
 * Only the migration calls this: a record written before the split carries one byte for the
 * tonic, and that byte is a position on the old list. The pitch it names is what matters, so
 * the pitch is what is read back and then written out as its note and its octave. The old top
 * C8 folds to B7, which is the one note the split cannot name.
 */
static void seq_root_split(float v01, float *note01, float *oct01)
{
    int midi = SEQ_ROOT_MIN_MIDI
             + (int)(clamp01f(v01) * (float)(SEQ_ROOT_MAX_MIDI - SEQ_ROOT_MIN_MIDI) + 0.5f);

    if (midi < SEQ_ROOT_MIN_MIDI) {
        midi = SEQ_ROOT_MIN_MIDI;
    } else if (midi > SEQ_ROOT_MAX_MIDI) {
        midi = SEQ_ROOT_MAX_MIDI;
    }

    int oct = midi / 12 - 1;            /* MIDI 60 is C4 */
    if (oct < 1) {
        oct = 1;
    } else if (oct > SEQ_OCT_COUNT) {
        oct = SEQ_OCT_COUNT;
    }

    *note01 = (float)(midi % 12) / 11.0f;
    *oct01 = (float)(oct - 1) / 6.0f;
}

/*
 * A note from the wire, pulled onto the chosen scale.
 *
 * CALLED WHERE THE NOTE BECOMES A PITCH, at the three places that is true of — the
 * player's own group, the arpeggiator's ladder and the drone's harmonisation — and not
 * where the note arrives. The held list, the group table and the note-off lookup keep the
 * key the wire sent, so the scale cannot be turned into a note nothing is able to release,
 * and the three sinks are the whole of what a scale is allowed to change. They are also
 * the reason it has to be all three: an arp or a drone left on the raw key would sit a
 * semitone away from the note coming out of the same press.
 *
 * THE NEAREST STEP, AND THE OCTAVE WITH IT. The distance is measured in semitones from the
 * root, folded into one octave, and the winner is added back to the note itself — so the
 * step is the nearest one however far up the keyboard the key was played, and the register
 * the player chose is kept. A tie goes DOWN: two steps exactly as far away is the one case
 * where nothing musical decides it, and a rule that can be written down (always fall rather
 * than always rise) is worth more than a coin toss that makes the same key move differently
 * on two presses.
 *
 * CHROMATIC IS EVERY SEMITONE, so the winning distance is zero and the note leaves as it
 * arrived — the setting that quantises nothing, bit for bit the line this replaced.
 */
static int seq_scale_note(int note)
{
    const seq_scale_cfg_t *sc = seq_scale();
    const int root = seq_root_midi();

    int pc = (note - root) % 12;
    if (pc < 0) {
        pc += 12;
    }

    /* The candidates are signed semitones in [-6, 6], so a tie is two of them the same
     * distance away on either side of the note, and the test takes the lower one. */
    int best = 0;
    int best_abs = 12;

    for (int i = 0; i < sc->len; i++) {
        int d = sc->steps[i] - pc;
        if (d > 6) {
            d -= 12;
        } else if (d < -6) {
            d += 12;
        }

        const int ad = (d < 0) ? -d : d;
        if (ad < best_abs || (ad == best_abs && d < best)) {
            best = d;
            best_abs = ad;
        }
    }

    return note + best;
}

/*
 * ПРИВЕСТИ БАЗИС ДРОНА К ТЕКУЩЕМУ СКЕЙЛУ.
 *
 * Зовётся там же, где щёлкает высота ударки: на смену скейла, тоники и октавы тоники. Работает
 * только когда квант действительно сдвинулся — на хроматике (умолчание) это одно сравнение и
 * ноль перестроек, поэтому звук старых патчей остаётся бит в бит прежним.
 *
 * Перестройка идёт через drone_set_pitch, то есть setFrequency без нового noteOn: дрон уже
 * звучит, и смена базиса — это смена высоты, а не удар. Сдвиг FOLLOW при этом пересчитывается
 * сам: drone_base_class() читает s_drone_base_midi.
 */
static void drone_base_update(void)
{
    const int midi = seq_scale_note(DRONE_BASE_MIDI);

    if (midi == s_drone_base_midi) {
        return;
    }

    s_drone_base_midi = midi;
    s_drone_base_st = (float)(midi - DRONE_BASE_MIDI);

    /* Перестраивать здесь нечего: сдвиг уедет в drone_tune_tick() тем же однополюсником, что и
     * сдвиг FOLLOW. Отдельный вызов нужен только фильтру — его привязка к высоте считается от
     * сдвига, и без него она отстала бы до следующей смены ноты. */
    if (s_param[SYNTH_PARAM_DRONE_KTRCK] > 0.0f) {
        apply_cutoff(s_param[SYNTH_PARAM_CUTOFF]);
    }
}

/* -------------------------------------------------------------------------- */
/* The lead's note-on                                                         */
/* -------------------------------------------------------------------------- */

#define LEAD_PORTA_MAX_MS 600

static uint32_t lead_porta_ms(void)
{
    const float v = s_param[SYNTH_PARAM_LEAD_PORTA];
    if (v <= 0.001f) {
        return 0;
    }
    if (v >= 1.0f) {
        return LEAD_PORTA_MAX_MS;
    }
    return (uint32_t)(v * (float)LEAD_PORTA_MAX_MS + 0.5f);
}

/*
 * Where the accent's velocity comes from. Declared here because the lead needs it and
 * the rule itself lives with the drum's figure, six hundred lines down: each part asks
 * about its OWN figure — SYNTH_PARAM_PERC_ACCENT for the drum, SYNTH_PARAM_SEQ_ACCENT for
 * the lead — and the rule is written once, next to the masks both of them read.
 */
static float figure_velocity_for(int accent, uint32_t grid_index, int n);
static int accent_index_perc(void);
static int accent_index_seq(void);
static int accent_index_arp(void);

/*
 * The lead's velocity: what the ACCENT figure and the WEAK VEL setting do to this part, and
 * the whole of it. The figure chooses WHICH notes are taken down — figure_velocity_for()
 * hands this function a 1.0 for a marked step — and WEAK VEL says by how much; see
 * accent_velocity_weak().
 *
 * THE ENGINE HAS NO VELOCITY OF ITS OWN, and it does not need one. noteOn() takes the
 * level the voice is opened at, stores it in the voice, and the render loop multiplies
 * the oscillator by it and by the envelope — see ESP32Synth_Core.hpp. A group's three
 * voices are three levels (70, 70 and 55, see s_lead) and every group is the same three,
 * so a velocity is one multiplication of those numbers, and it happens HERE: once per
 * note, in the audio task at the moment the note starts, on the group that note took.
 * Nothing is added to the sample path — no multiply, no branch, no memory — because the
 * field it writes is the field the engine was already reading.
 *
 * 1.0 IS THE IDENTITY, and it is taken as a BRANCH rather than as a multiplication:
 * with the figure OFF the table's own uint16_t goes to the engine untouched, so the
 * line is bit for bit the instrument it was before this parameter existed — and the same
 * branch is taken when WEAK VEL is at 127, which is the setting saying "no difference".
 * That is the
 * promise the whole feature is built around — the factory sound must not move by a bit
 * — and an equality is the only version of it that cannot drift: arithmetic that ought
 * to come out equal would be one compiler flag away from not doing so.
 *
 * The scale is rounded to the nearest level because the engine's copy of it is eight
 * bits wide (setVolDepthBase() is never called, so _volShift is its default 8): at the
 * factory setting, 70 * 80/127 = 44.09 comes out 44, and 55 * 80/127 = 34.65 comes out 35.
 * The rounding is
 * worth 0.5 of one of 256 levels — about a tenth of a dB on a weak note — and it is
 * spent deliberately rather than avoided by widening the engine, whose voice struct is
 * not this parameter's to grow.
 *
 * The SUB-OCTAVE VOICE IS SCALED WITH THE OTHER TWO, by the same factor, so the
 * balance between them does not move. Everything else about the note is the voice's
 * own and is untouched: the envelope, the timbre, the detune and the glide are set by
 * noteOn() from state this does not go near.
 */
static uint16_t lead_volume_for(int v, float velocity)
{
    if (velocity >= 1.0f) {
        return s_lead[v].volume;
    }
    return (uint16_t)((float)s_lead[v].volume * velocity + 0.5f);
}

/*
 * The lead's own pitch, moved once per step of its sequencer. The shift is in semitones so that
 * the interval between two steps stays a musical one, and it is the step that is moved rather
 * than the oscillator: the note that is playing holds its pitch until the next step.
 */
static float mod_lead_pitch(float hz)
{
    if (!mod_dest_lead()) {
        return hz;
    }
    const float semis = mod_sum01(MD_LEAD) * 24.0f;   /* сумма двух LFO в полутонах */
    return hz * exp2f(semis / 12.0f);
}

/*
 * The lead filter's key-tracking multiplier: 2^(k·(note − A3)/12), clamped to the tracker's
 * top of band. At k=0 it is exactly 1, which is the whole of "the cutoff does not move with the
 * pitch".
 */
static float lead_filter_track_mult(void)
{
    const float k = s_param[SYNTH_PARAM_LEAD_KTRCK];

    if (k <= 0.0f) {
        return 1.0f;
    }
    return exp2f(k * (float)(s_lead_track_note - LEAD_KTRCK_REF_MIDI) / 12.0f);
}

/* A frequency as a MIDI note, rounded, for the tracker. The lead's pitches are in hertz by the
 * time they reach lead_group_on() — the sequencer, the arp and the wire all speak hertz — so
 * this is where the number a keyboard would have sent is recovered. Clamped to the MIDI range
 * so a modulation or a modulation-made extreme cannot leave it. */
static int midi_from_hz(float hz)
{
    if (!(hz > 0.0f)) {
        return LEAD_KTRCK_REF_MIDI;
    }

    const int note = (int)(69.0f + 12.0f * log2f(hz * (1.0f / 440.0f)) + 0.5f);
    return note < 0 ? 0 : (note > 127 ? 127 : note);
}

/*
 * Open one note in one group: the three voices of THAT group, at the pitch and the
 * velocity of that one note.
 *
 * noteOn first and always: a new note is a new note, and retriggering the
 * envelope is what makes the line articulate instead of smearing from one pitch
 * into the next. Portamento does not contradict that — it moves the pitch of the
 * note that has just been articulated, which is exactly what a player with a
 * slide control sounds like.
 *
 * The glide starts from the note that group played last, so a group's first note
 * arrives without one: there is nothing to glide from, and a slide out of whatever
 * the last note happened to be would be a slide out of nowhere. Per group rather
 * than one pitch for the whole lead, because the groups are its notes: a
 * bass note in group 2 and a melody note in group 0 have no business gliding into
 * each other.
 *
 * The velocity arrives as an ARGUMENT and not as state, so the note that is opened and
 * the velocity it is opened at are decided in one call: two calls into this function
 * with a step between them could hand one note's velocity to another note's pitch.
 * It lands on this group's three voices and on no others, which is what makes an
 * accent on one note of a chord an accent rather than a swell of the whole chord.
 */
/*
 * THE LAST NOTE THE LEAD STARTED, from whichever hand or line started it, or -1 for none.
 *
 * The held-key list cannot answer this: the sequencer's and the arp's notes are opened by a
 * line rather than by a key and never enter that list, so a drone that read only the list
 * could not follow the music the instrument plays on its own — with nothing held it would
 * sit on its base for the whole session, which is heard as "the drone does not follow the
 * note". This is that missing memory; lead_group_on() writes it, because every lead note
 * passes through it.
 */
static int s_lead_last_note = -1;

static void lead_group_on(int group, float hz, float velocity)
{
    /* The tracker reads the note that was ASKED for, before the modulation's pitch offset:
     * the filter follows the line, not the LFO on it. Harmless when LEAD_KTRCK is zero — the
     * write below is skipped and the cutoff stays the knob's number. */
    const int track_note = midi_from_hz(hz);

    /* The drone's own reading of the same note: see drone_follow_note(). */
    s_lead_last_note = track_note;

    mod_note();
    hz = mod_lead_pitch(hz);
    const uint32_t porta = lead_porta_ms();
    const float prev_hz = s_lead_group_hz[group];
    const bool glide = (porta > 0) && (prev_hz > 0.0f);

    for (int v = 0; v < LEAD_GROUP_VOICES; v++) {
        const uint16_t voice = lead_voice_of(group, v);
        const uint32_t target = detuned_centihz(hz, wave_detune(s_lead[v].detune_cents,
                                                                s_lead_super));

        s_synth.noteOn(voice,
                       glide ? detuned_centihz(prev_hz,
                                               wave_detune(s_lead[v].detune_cents,
                                                           s_lead_super))
                             : target,
                       lead_volume_for(v, velocity));

        if (glide) {
            s_synth.slideFreqTo(voice, target, porta);
        }
    }

    s_lead_group_hz[group] = hz;

    /* The cutoff follows the newest note when tracking is on: one exp2f and one int16 write
     * per note started, and nothing when the knob is at zero. Done after the voices so the
     * filter corner moves with the note rather than a block ahead of it; the filter smooths
     * the corner itself over its own 15 ms, so this is a step of a parameter and not a click. */
    s_lead_track_note = track_note;
    if (s_param[SYNTH_PARAM_LEAD_KTRCK] > 0.0f) {
        apply_lead_cutoff(s_param[SYNTH_PARAM_LEAD_CUTOFF]);
    }

    lead_gate_update();
}

/*
 * The generator's note: the sequencer's or the arp's own line, in whichever group is
 * free.
 *
 * IT TAKES A NEW GROUP WHILE THE LAST NOTE STILL RINGS. That is the whole change:
 * the line used to be one voice — group 0, retriggered on every step — so a release
 * was cut by the next onset, and a slow one was never heard at all. Now each step
 * allocates, and a step that arrives while the previous tail is still audible gets a
 * group of its own. Four of them can overlap; the fifth onset takes the oldest of
 * the generator's own notes, which is the same victim rule the player's allocator
 * uses and for the same reason.
 *
 * THE GROUPS ARE THE PLAYER'S GROUPS, and that is safe rather than sloppy: the
 * generator opens no note at all while a key is down (see seq_trigger() and
 * arp_tick()), so the two never want a group at the same time. A key does not even
 * have to steal one — by the time it arrives, every group the generator was using is
 * FREE or still in its tail, and lead_group_alloc() takes the free ones first.
 *
 * GATE_BLOCKS comes from the step that is starting the note, because on this side of
 * the seam only the caller knows how long the gap to the next onset is.
 */
static void lead_note_one(float hz, float velocity, uint32_t gate_blocks, int chord_note)
{
    int group = -1;

    if (!s_lead_poly) {
        /*
         * MONO: the one group, and the note it replaces is not let go of first. That is
         * the switch's whole difference — the release of the previous step is cut by the
         * next note-on, which is what a monophonic line sounds like, and what this line
         * sounded like before it could overlap itself.
         *
         * A key may be holding the group when the sequencer starts: the line takes it,
         * as it always did, and the key's release finds its note gone.
         */
        group = LEAD_GEN_GROUP;
        if (s_lead_note[group] != LEAD_NOTE_FREE && s_lead_note[group] != LEAD_NOTE_GEN) {
            lead_group_off(group);
        }
    } else {
        for (int g = 0; g < LEAD_GROUPS; g++) {
            if (s_lead_note[g] == LEAD_NOTE_FREE) {
                group = g;
                break;
            }
        }

        if (group < 0) {
            /* Every group is in use. The generator's own oldest note goes first; a group
             * holding a key is not touched, because it cannot be holding one — see
             * above — and the fallback is the oldest of all, never the newest. */
            int oldest_gen = -1;
            int oldest_any = 0;

            for (int g = 0; g < LEAD_GROUPS; g++) {
                if (s_lead_note[g] == LEAD_NOTE_GEN
                    && (oldest_gen < 0 || s_lead_stamp[g] < s_lead_stamp[oldest_gen])) {
                    oldest_gen = g;
                }
                if (s_lead_stamp[g] < s_lead_stamp[oldest_any]) {
                    oldest_any = g;
                }
            }

            group = (oldest_gen >= 0) ? oldest_gen : oldest_any;
            lead_group_off(group);
        }
    }

    if (gate_blocks < 1u) {
        gate_blocks = 1u;
    } else if (gate_blocks > 60000u) {
        gate_blocks = 60000u;
    }

    /* The glide starts from the previous note of the LINE, not of the group: with the
     * groups handed round, this group's last note is three or four steps back, and a
     * slide out of it would be a slide out of the wrong note. In MONO the group IS the
     * line, so its own last note is already the right one and nothing is rewritten. */
    if (s_lead_poly) {
        s_lead_group_hz[group] = s_gen_last_hz;
    }

    lead_group_claim(group, LEAD_NOTE_GEN);
    s_gen_gate[group] = (uint16_t)gate_blocks;
    s_gen_tail[group] = 0;

    /* Шина — до включения ноты: голоса должны зазвучать уже в своей. */
    lead_group_bus(group, chord_note);

    lead_group_on(group, hz, velocity);
    s_gen_last_hz = s_lead_group_hz[group];

    lead_fenv_retrigger();
}

/*
 * ТРИ НОТЫ ОДНОГО СОБЫТИЯ: основная и две ступени вверх по выбранному ладу.
 *
 * Ступени считаются от основной в ладу, а не полутонами: интервал получается тот, который
 * лад содержит, поэтому в минорном ладу третья ступень минорная сама, без отдельной
 * настройки. Октава прибавляется, когда ступень переваливает за верх лада, — иначе аккорд
 * сломался бы на последних ступенях.
 *
 * Нота в герцах переводится в MIDI и обратно: остальные генераторы играют уже готовые
 * частоты, а лад живёт в полутонах, и это единственное место, где два мира встречаются.
 */
static void lead_chord_hz(float hz, float *out, int *count)
{
    *count = 0;
    if (!(hz > 0.0f)) {
        return;
    }

    const seq_scale_cfg_t *sc = seq_scale();
    const int root = seq_root_midi();
    const int len = (sc->len > 0) ? sc->len : 1;

    int midi = seq_scale_note((int)(69.0f + 12.0f * log2f(hz / 440.0f) + 0.5f));

    int pc = midi - root;
    int oct = 0;
    while (pc < 0) {
        pc += 12;
        oct--;
    }
    while (pc >= 12) {
        pc -= 12;
        oct++;
    }

    /* Ступень основной ноты. Лад всегда содержит сыгранную ноту — её только что привели к
     * нему, — но если совпадения нет (лад поменяли под звучащую ноту), берётся ближайшая
     * снизу, чтобы аккорд всё равно был. */
    int deg = 0;
    for (int i = 0; i < len; i++) {
        if (sc->steps[i] == pc) {
            deg = i;
            break;
        }
        if (sc->steps[i] < pc) {
            deg = i;
        }
    }

    out[0] = midi_to_hz(midi);
    *count = 1;

    for (int k = 1; k < LEAD_CHORD_NOTES; k++) {
        const int step = deg + 2 * k;
        const int up = step / len;
        const int idx = step % len;
        out[k] = midi_to_hz(root + 12 * (oct + up) + sc->steps[idx]);
        *count = k + 1;
    }
}

/*
 * ПАНОРАМЫ ТРЁХ ШИН АККОРА.
 *
 * Владелец: «просто рандомная панорама это вообще не то что нужно» — и он прав: нужен не
 * поочерёдный голос, а каждая нота аккорда на своём месте. Ноты аккорда идут тремя шинами
 * (7, 8, 9), и здесь задаются их панорамы: −SPREAD, 0, +SPREAD — основная чуть левее,
 * терция в центре, квинта чуть правее. 900 из 1000 — почти край, но не самый край: в самом
 * краю нота пропадает из одного канала.
 *
 * На нуле все три стоят в центре, и это ровно прежнее звучание.
 */
static void lead_chord_pan(float v01)
{
    static const float offset[LEAD_CHORD_NOTES] = { -1.0f, 0.0f, 1.0f };
    const float v = clamp01f(v01) * 900.0f;

    for (int c = 0; c < LEAD_CHORD_NOTES; c++) {
        s_synth.setBusFXParam((uint8_t)(LEAD_CHORD_BUS0 + c), 1, 0,
                              (int16_t)(offset[c] * v));
    }
}

static void lead_note_on(float hz, float velocity, uint32_t gate_blocks)
{
    if (!s_lead_chord) {
        lead_note_one(hz, velocity, gate_blocks, -1);
        return;
    }

    float notes[LEAD_CHORD_NOTES];
    int count = 0;

    /*
     * Скольжение считается от ПРЕДЫДУЩЕЙ ноты линии, а не от первой ноты этого аккорда:
     * lead_note_one() записывает в s_gen_last_hz каждую сыгранную ноту, и без сохранения
     * вторая и третья ступени поехали бы из первой — аккорд въехал бы в себя.
     */
    const float from = s_gen_last_hz;

    lead_chord_hz(hz, notes, &count);
    for (int i = 0; i < count; i++) {
        s_gen_last_hz = from;
        /* Каждая нота аккорда — в свою шину: третья и дальше ступени идут в последнюю. */
        lead_note_one(notes[i], velocity * LEAD_CHORD_LEVEL[i], gate_blocks,
                      (i < LEAD_CHORD_NOTES) ? i : (LEAD_CHORD_NOTES - 1));
    }
}

/* -------------------------------------------------------------------------- */
/* The clock from the wire                                                    */
/* -------------------------------------------------------------------------- */
/*
 * A host that is playing sends twenty-four clocks to the beat, and this is where they
 * become a TEMPO. It is not the knob's tempo and it must not become the knob's value: the
 * patch is what the instrument is and a preset is a copy of it, so a tempo written into
 * SYNTH_PARAM_SEQ_TEMPO when a cable asked for it would go into every preset saved
 * afterwards and would leave the knob pointing at a number the instrument is not playing.
 * The override is a layer of its own instead: `seq_tempo_now()` — the one function every
 * generator asks for its tempo — answers with the measured one while a clock is live and
 * with the knob's the rest of the time, and the parameter is never written.
 *
 * WHAT IT IS MEASURED FROM, AND WHY A WHOLE BEAT OF IT. Ticks are timed in audio blocks,
 * the only clock this task has: each tick records how many blocks have passed since the one
 * before it, and a window of twenty-four INTERVALS is one beat. Twenty-four intervals
 * rather than "twenty-four ticks seen" is the point — the sum of the intervals telescopes,
 * so the window measures the time between its first tick and its twenty-fifth however the
 * host delivered them. A host that hands over a beat's worth of clock in one USB frame and
 * then nothing for half a second is measured as the beat it is; the per-tick average of the
 * same stream — twenty-three zero intervals and one enormous one — only gets that right by
 * accident, and it swings around the mean while it does.
 *
 * One beat is also the shortest window worth having: a single interval is quantised to a
 * block (2.7 ms), which at 300 BPM is a third of a tick, and a beat averages twenty-four of
 * those roundings away.
 *
 * SMOOTHED ACROSS WINDOWS, because a window boundary can land on a jittery tick and a tempo
 * that steps by a few BPM every beat is heard as a stutter. The first measured window is
 * taken as it is — a clock that has just started should be adopted rather than faded in —
 * and every one after it moves the estimate half way there, so a real tempo change is
 * followed within about two beats and a single bad window is not.
 *
 * CLAMPED TO THE KNOB'S OWN RANGE, SEQ_TEMPO_MIN_BPM..SEQ_TEMPO_MAX_BPM (30..300): it is
 * what the instrument can play, it is the same pair of numbers the parameter's mapping is
 * built from, and a wire can therefore ask for exactly the range the panel can. The clamp
 * is applied to the measured period, which is the same thing as clamping the BPM and is
 * where the value is used.
 *
 * WHEN THE WIRE GOES QUIET the override is dropped: about a second without a tick — 187.5
 * blocks, 187 at this block size, and far above any tick the range allows — and the generators are back on the
 * knob. The return is a step rather than a glide and it happens after a second in which
 * nothing was playing to the wire's tempo anyway. The tick after it starts a FRESH LOCK,
 * whose estimate is seeded from the knob's own tempo: the takeover is then a measurement
 * and never a jump to whatever the first two ticks of a restarted clock happened to be,
 * and a clock that stops before its first whole beat leaves the tempo exactly where the
 * knob had it.
 *
 * THE SCREEN SHOWS WHAT IS PLAYING, and that costs the parameter nothing: the transport's
 * readout asks for the published snapshot below (synth_app_tempo_now()) instead of the
 * parameter, so the number beside the wheel follows the wire while a clock is live and
 * snaps back to the wheel when the wire stops. The knob, the preset and the parameter keep
 * the knob's number throughout — the screen is a readout of the instrument, not a second
 * writer of the patch.
 */
#define CLK_TICKS_PER_BEAT 24
#define CLK_WINDOW_TICKS   CLK_TICKS_PER_BEAT   /* the window IS one beat of intervals */
#define CLK_BLOCK_RATE     ((float)SYNTH_SAMPLE_RATE / (float)SYNTH_BLOCK_SAMPLES)

/* Blocks without a tick before the knob takes the tempo back: one second at the fixed block
 * rate, which is the number the section above explains. */
#define CLK_TIMEOUT_BLOCKS ((uint32_t)CLK_BLOCK_RATE)

/* Blocks per tick at the two ends of the parameter's range. */
#define CLK_PERIOD_BLOCKS(bpm) (60.0f * CLK_BLOCK_RATE / ((float)CLK_TICKS_PER_BEAT * (bpm)))

static float    s_clk_period_blocks;   /* smoothed blocks per tick; the estimate itself */
static uint32_t s_clk_window_blocks;   /* blocks the intervals of the open window span */
static uint32_t s_clk_window_ticks;    /* intervals counted into that window */
static uint32_t s_clk_idle_blocks;     /* blocks since the last tick: the timeout above */
static bool     s_clk_live;            /* a clock has been received and has not timed out */
static bool     s_clk_measured;        /* a whole window has been measured since the lock */

/*
 * THE PUBLICATION FOR THE SCREEN. The transport's readout used to be built from the
 * parameter, which is the wheel's position, while a clock made the instrument play at
 * another tempo; the screen has to mirror the tempo that is running. The UI
 * task may no more read the clock's state than it may read the engine's — both are the
 * audio task's — so the answer is published here in the shape the readout already draws
 * from: the parameter's own 0..1, plus whether a clock is what produced it. It is written
 * on the audio task at the three moments the answer changes (a fresh lock, a measured
 * window, the timeout) and read by whoever asks, so there is no lock, no allocation, and
 * nothing here can hold a block up.
 *
 * THE FLAG IS PUBLISHED AFTER THE VALUE, release then acquire, for the reason the MIDI ring
 * gives further down: the two ends are on different cores and the fence is the point. A
 * reader that sees "from the clock" cannot then see a value from before the measurement
 * that earned the flag, and a reader that sees "from the knob" takes the parameter and
 * never looks at the value at all, so the reverse window costs nothing.
 */
static std::atomic<float>    s_clk_out_tempo{SEQ_TEMPO_DEFAULT};
static std::atomic<uint32_t> s_clk_out_live{0};

/* The measured tempo as the parameter's 0..1 — the inverse of seq_tempo_bpm()'s mapping
 * (SEQ_TEMPO_MIN_BPM * 2^(v * SEQ_TEMPO_SPAN)), so the screen's "%d BPM" rounds back to the
 * tempo being played and not to its neighbour. Written together with the flag, never alone. */
static void clk_publish_live(void)
{
    const float bpm = 60.0f * CLK_BLOCK_RATE / ((float)CLK_TICKS_PER_BEAT * s_clk_period_blocks);

    s_clk_out_tempo.store(log2f(bpm / SEQ_TEMPO_MIN_BPM) / SEQ_TEMPO_SPAN,
                          std::memory_order_relaxed);
    s_clk_out_live.store(1u, std::memory_order_release);
}

/* The timeout's publication: the VALUE goes back to the parameter as well as the flag, so
 * the snapshot itself is the knob again and the screen follows it even if it only reads the
 * number. Taken from the control surface rather than from the seed the lock started with,
 * because the wheel may have been turned while the clock was live. */
static void clk_publish_knob(void)
{
    s_clk_out_tempo.store(s_param[SYNTH_PARAM_SEQ_TEMPO], std::memory_order_relaxed);
    s_clk_out_live.store(0u, std::memory_order_release);
}

/*
 * One block of the clock's own time, once per block from the drain below and before that
 * block's events are read. It does one thing: it ends the override when the wire has been
 * quiet for a second. The window goes with it, so a clock that comes back starts a fresh
 * measurement rather than finishing one with a second of silence inside it — which would be
 * read as a very slow beat and would move the sequencer there.
 */
static void midi_clock_block(void)
{
    s_clk_idle_blocks++;

    if (s_clk_live && s_clk_idle_blocks > CLK_TIMEOUT_BLOCKS) {
        s_clk_live = false;
        s_clk_window_ticks = 0;
        s_clk_window_blocks = 0;
        clk_publish_knob();

        /* The tempo the delay follows went back to the knob in this block, so the echo
         * is re-cut from the same tempo the sequencer is now on — and so does the bass,
         * which is on that clock and not a second one. */
        apply_delay();
        apply_bass_tempo();
    }
}

/*
 * One clock tick, on the audio task, out of the ring. Twenty-four of them make the beat.
 */
static void midi_clock_tick(void)
{
    const uint32_t elapsed = s_clk_idle_blocks;
    s_clk_idle_blocks = 0;

    if (!s_clk_live) {
        /* A fresh lock. The period is seeded from the knob so that the override starts
         * where the instrument already was — a stale estimate or a division by zero
         * would both be worse — and this tick is the reference the next twenty-four
         * intervals are measured from. */
        s_clk_period_blocks = CLK_PERIOD_BLOCKS(seq_tempo_bpm(s_param[SYNTH_PARAM_SEQ_TEMPO]));
        s_clk_measured = false;
        s_clk_window_ticks = 0;
        s_clk_window_blocks = 0;
        s_clk_live = true;
        /* Published at once rather than left to the first window: the override is already
         * in force from this tick, so the screen switches to the snapshot on the same beat
         * the instrument switches tempo — with the knob's own number in it, since that is
         * what the seed is. */
        clk_publish_live();
        return;
    }

    /* The tick before this one is the far end of an interval, and the interval is what
     * an average of twenty-four of them is made of. A tick that is late because a whole
     * beat's worth of clock was handed over at once contributes the interval it really
     * was; a tick that arrives in the same block as the last one contributes zero, which
     * is also what it really was. */
    s_clk_window_blocks += elapsed;
    s_clk_window_ticks++;

    if (s_clk_window_ticks < CLK_WINDOW_TICKS) {
        return;
    }

    float period = (float)s_clk_window_blocks / (float)CLK_WINDOW_TICKS;

    s_clk_window_ticks = 0;
    s_clk_window_blocks = 0;

    if (period < CLK_PERIOD_BLOCKS(SEQ_TEMPO_MAX_BPM)) {
        period = CLK_PERIOD_BLOCKS(SEQ_TEMPO_MAX_BPM);
    } else if (period > CLK_PERIOD_BLOCKS(SEQ_TEMPO_MIN_BPM)) {
        period = CLK_PERIOD_BLOCKS(SEQ_TEMPO_MIN_BPM);
    }

    if (s_clk_measured) {
        period = s_clk_period_blocks + (period - s_clk_period_blocks) * 0.5f;
    } else {
        s_clk_measured = true;
    }
    s_clk_period_blocks = period;

    /* The estimate moved, so the published one is one window behind it otherwise. One store
     * per beat, which is where the tempo itself changes. The delay follows the same
     * measurement: a synced echo that kept the knob's tempo while the sequencer followed
     * the wire was the seventeen percent the owner measured. The bass follows it too, for
     * the stronger reason: its whole line is placed against this number. */
    clk_publish_live();
    apply_delay();
    apply_bass_tempo();
}

/*
 * The tempo the generators run at, and the whole of the override. Called where the
 * parameter used to be read — see the four callers — so there is one answer to "what tempo
 * is this instrument playing at" rather than one per generator.
 *
 * NOT ROUNDED TO A WHOLE BPM, deliberately. seq_tempo_bpm() rounds because the knob's
 * number is one a player reads and plays to, and the step the sequencer takes has to be the
 * step the screen shows; this number is a measurement, nobody reads it, and rounding it
 * would only add up to half a BPM of error to a tempo the host is keeping exactly.
 */
static float seq_tempo_now(void)
{
    if (!s_clk_live) {
        return seq_tempo_bpm(s_param[SYNTH_PARAM_SEQ_TEMPO]);
    }
    return 60.0f * CLK_BLOCK_RATE / ((float)CLK_TICKS_PER_BEAT * s_clk_period_blocks);
}

/*
 * The same answer for the screen, and the read side of the publication above.
 *
 * A separate call from seq_tempo_now() for two reasons: it has to be callable from the UI
 * task, which may not read the clock's state, and it answers in the parameter's own 0..1
 * rather than in BPM, because that is the form the readout is drawn in — the tempo's arc
 * is on the same scale as every other arc on the instrument, which is the parameter's.
 * `from_clock` is optional and says which of the two answered, so a caller that has to draw
 * the difference can; the transport itself shows only the number.
 *
 * Nothing here writes: the snapshot is a readout, and the parameter stays the wheel's.
 */
/*
 * СЧЁТЧИК ДОЛЕЙ ДЛЯ КОЛЬЦА.
 *
 * Доля считается по клоку транспорта, а не по рисунку ударки: рисунок может молчать и меняет
 * длину, а такт — нет. Счётчик падает в ноль на рестарте транспорта, поэтому вспышки снова
 * совпадают с началом такта. Кольцу хватает счётчика: оно рисуется раз в кадр, десять
 * миллисекунд разницы на глаз не читаются.
 */
extern "C" uint32_t synth_app_beat_count(void)
{
    return s_beat_count;
}

float synth_app_tempo_now(int *from_clock)
{
    if (s_clk_out_live.load(std::memory_order_acquire) == 0) {
        if (from_clock) {
            *from_clock = 0;
        }
        return s_param[SYNTH_PARAM_SEQ_TEMPO];
    }

    if (from_clock) {
        *from_clock = 1;
    }
    return s_clk_out_tempo.load(std::memory_order_relaxed);
}

/* Where the transport's START puts the one position. Defined with the sequencers
 * further down the file, because that is where the position and its figures live. */
static void midi_transport_reset(void);

/* -------------------------------------------------------------------------- */
/* Notes from outside: USB MIDI                                               */
/* -------------------------------------------------------------------------- */
/*
 * A note played on a computer reaches the lead through the ring in this block,
 * and it reaches it the long way round on purpose: the MIDI read task may not
 * call into the engine. The engine has no locking at all — no critical sections,
 * no atomics over the voices, not even volatile — so the audio task is the only
 * thing allowed to open or close a note, and anything else doing it would be a
 * data race on every voice it happened to touch. Neither side of the seam knows
 * the other's timing: the producer writes four bytes and returns, the consumer
 * reads them between blocks.
 *
 * This is the same indirection the parameter setters use (synth_app_set_param()
 * stores, apply_pending_params() decides), with one difference that is worth
 * being explicit about: the two ends here run on DIFFERENT CORES. The audio task
 * is pinned to core 1 and the MIDI task to core 0, so the indices are not merely
 * a handshake between two times on one CPU — they are how a store made on one
 * core is made visible to the other. Hence std::atomic with release/acquire
 * ordering rather than plain volatile words: the fence is the point, and both
 * operations are lock-free on this target, so the audio task can never block on
 * the producer.
 *
 * WHY A RING AND NOT A FLAG
 *   A single "new note" flag would lose notes: a player can press and release a
 *   key inside one 2.7 ms block, and a chord is three presses in the same
 *   millisecond. The ring keeps the ORDER of the keys, which is what the lead
 *   needs to answer "which note is the newest" — see midi_note_pressed() — and it
 *   is bounded, so nothing in this path allocates.
 */
#define MIDI_RING_SIZE 64u  /* power of two: the mask below is the whole of the index arithmetic */

/* How many keys the held list can keep. This is NOT the lead's polyphony, which is
 * LEAD_GROUPS: it is the length of the memory of what is still down, which is what
 * the drone's harmonisation reads to find the newest note the player is holding —
 * see midi_newest_note() — and what a steal has to reach into to take a group away
 * from a key that is still down. Sixteen is more than the ten fingers the situation
 * needs and small enough to be a fixed array; the steal drops its victim from this
 * list, so in practice it holds exactly the notes that are sounding, and the bound
 * is the floor under the index whatever the future does to the steal.
 *
 * The arpeggiator reads the same list, and it reads the held keys as a CHORD: what
 * is down is what the figure is made of — see arp_held_step(). */
#define MIDI_HELD_MAX 16

typedef enum {
    MIDI_EVT_NOTE_ON = 0,
    MIDI_EVT_NOTE_OFF,
    /* The clock and the transport, in the same ring as the notes and for the same
     * reason: they arrive on the same task, they have the same consumer, and the
     * consumer is the only side that may touch the transport flag, the position or
     * the measured tempo. A second queue would be a second thing to keep in step
     * with the drain and a second place to look for why the instrument did or did
     * not start; the traffic does not need one — twenty-four clocks to the beat is
     * one event per eight milliseconds at the fastest tempo the range allows, and
     * the drain empties the ring every 2.7 ms. */
    MIDI_EVT_CLOCK,
    MIDI_EVT_START,
    MIDI_EVT_CONTINUE,
    MIDI_EVT_STOP,
} midi_evt_kind_t;

/* Four bytes, and deliberately not packed any tighter: a 32-bit aligned store is
 * what the producer can make without disabling interrupts, and this path runs
 * on the task that also has to keep up with USB.
 *
 * The part is carried in the event rather than inferred at the consumer from anything
 * else, because it is a property of the MESSAGE: the same note on channel 1 and on
 * channel 2 are two different players, and the consumer must not have to look at what
 * is held to find out which one sent it. It is one byte of the four that were already
 * here — the spare one — so the store is the same single 32-bit write it was.
 *
 * THE TRANSPORT AND THE CLOCK USE THE KIND ALONE and the other three bytes are written
 * zero, so a transport event can never be read as a note: the kind is the first thing
 * the consumer looks at, and there is one kind per message. See midi_ring_push(). */
typedef struct {
    uint8_t kind;   /* midi_evt_kind_t */
    uint8_t part;   /* synth_midi_part_t */
    uint8_t note;   /* 0..127 */
    uint8_t vel;    /* 0..127, note on only */
} midi_evt_t;

static midi_evt_t s_midi_ring[MIDI_RING_SIZE];

/* Written by the producer (the MIDI task), read by the consumer (the audio
 * task). Each side owns one of them, which is what makes this lock-free. */
static std::atomic<uint32_t> s_midi_head{0};
static std::atomic<uint32_t> s_midi_tail{0};

/* Events lost to a full ring, for the log line below. Written by the producer
 * only, so no atomic is needed for it. */
static uint32_t s_midi_dropped;

/* The keys currently held, in the order they were pressed. Audio task only, and kept in
 * step with the lead's groups only while the arp is off: a key the steal has taken a group
 * from is dropped here too, so "held" means "a voice is playing it". While the arp is ON
 * this list is the arp's CHORD and no key on it has a group of its own at all — a key is
 * still written here when it arrives and dropped when it is released, which is exactly what
 * the figure reads; see arp_held_step() and arp_lead_tick().
 *
 * THE VELOCITY IS KEPT WITH THE KEY, one byte beside it, and it is kept for the
 * ARPEGGIATOR. A note from the wire spends its velocity at its own note-on as it
 * always did — see lead_group_on() — but a key that stays down is also one of the
 * notes the arp's figure is made of while it is down, and each step of that figure
 * has to arrive at the level the player pressed it with. There is nowhere else to
 * read it from: the engine keeps a voice's level, not a key's, and a key the steal
 * has taken has no voice of its own left. Sixteen bytes of static array, in the
 * order of the list beside it, and it is read only while a key is held.
 */
static uint8_t s_midi_held_note[MIDI_HELD_MAX];
static uint8_t s_midi_held_vel[MIDI_HELD_MAX];   /* 0..127, the velocity the key arrived with */
static int     s_midi_held_n;

/*
 * Whether an external note is on the lead right now. This is the one question
 * the sequencer asks before opening a note, and the whole of the eviction rule:
 * while this is true the lead is the player's, and the SEQUENCER keeps its clock
 * but stays silent (see seq_trigger(), and the gate expiry in seq_tick()).
 *
 * THE ARPEGGIATOR IS NOT PART OF IT, and that is deliberate in both directions. It has its
 * own group and its own question — are there keys to arpeggiate — and while the arp is on
 * it walks the keys itself and opens no group for them; see arp_lead_tick(). What the rule
 * still means is what it always meant for the Euclidean figure: the generator does not play
 * over the player's hands.
 *
 * IT IS ALSO WHAT KEEPS THE OUTPUT OPEN FOR THE ARP WITHOUT THE TRANSPORT: while keys are
 * down this is true, so midi_gate_tick() has the gate open for the chord, and the arp's
 * steps in it are audible at STOP.
 *
 * It asks the held list, and the list is the KEYS THE PLAYER IS HOLDING, in press order: a
 * key is added when it arrives, dropped when it is released or when a steal takes the group
 * it was sounding in. While the arp has the lead no key has a group and the list still holds
 * every one of them — which is the whole of what the figure is made of, and why a key the
 * arp is playing can never be read as silence.
 */
static bool midi_note_active(void)
{
    return s_midi_held_n > 0;
}

/*
 * The note the lead is sounding, or -1. The newest key still down — the last key
 * the player pressed that nothing has taken — and the drone reads this to know what
 * to harmonise to. Nothing else does. See drone_tune_tick().
 */
static int midi_newest_note(void)
{
    return (s_midi_held_n > 0) ? (int)s_midi_held_note[s_midi_held_n - 1] : -1;
}

/* -------------------------------------------------------------------------- */
/* How long a tail keeps the output open                                      */
/* -------------------------------------------------------------------------- */
/*
 * THE OUTPUT GATE, and why it is no longer the transport alone.
 *
 * The gate is the rack's input, so closing it silences the generators AND the drone —
 * which is what STOP has always meant on this instrument. But a note played over USB
 * MIDI is not the sequencer's note, and an instrument that a computer is playing has to
 * be audible with the transport stopped: that is most of what a note input is for. So
 * STOP is enforced on the GENERATORS instead (the sequencer opens no notes, the drum
 * strikes none) and the gate is opened by whatever is sounding:
 *
 *   - a key that is still down on channel 1 — the note itself;
 *   - the release of the last such key, for as long as that release lasts. That is the
 *     lead VOICES' own amplitude release — the LEAD RELEASE knob, which is the one that
 *     number is set from, so a note is inaudible exactly when the hold ends and the gate's
 *     own ramp covers the last of the decay. Half a second at the factory position;
 *   - a hit on channel 2, for as long as that hit's decay lasts. Again the patch's own
 *     number: synth_perc_decay_ms() is the module's reading of the DECAY knob and the
 *     same number its envelope is built with, and it is the module's own definition of
 *     silence — the envelope reaches PERC_TAIL at exactly that moment — so the hit is
 *     over when the hold is;
 *
 * THE TAILS ARE COUNTED IN BLOCKS and armed by the events themselves, not read from the
 * audio it is gating. That matters on the first block of a hit: a reading of the drum's
 * envelope taken before the render would still be the PREVIOUS block's — zero — and the
 * hit that opened the gate would be gated away by its own arrival.
 *
 * NOTHING HERE KEEPS THE GATE OPEN FOR THE SEQUENCER. Its notes are the transport's and
 * STOP silences them at the source; the drum's figure is stopped the same way. So the
 * only way a tail can be running is a MIDI event, which is exactly the distinction
 * asked for.
 *
 * THE CLOCK KEEPS RUNNING behind all of it, which is the existing design and is why the
 * tails are counters rather than anything inside the generators.
 */
static uint32_t s_midi_lead_tail;   /* blocks left of an external lead note's release */
static uint32_t s_midi_perc_tail;   /* blocks left of a MIDI-struck hit's decay */

/* Milliseconds as whole audio blocks. The block rate is fixed at 187.5 Hz (48 kHz over
 * 256 samples), and the audio task's own resolution is one block, so this is as fine as
 * a countdown here can be — 5.3 ms. */
static uint32_t midi_ms_to_blocks(float ms)
{
    if (!(ms > 0.0f)) {
        return 0u;
    }
    return (uint32_t)(ms * ((float)SYNTH_SAMPLE_RATE / (float)SYNTH_BLOCK_SAMPLES) * 0.001f
                      + 0.5f);
}

/*
 * What was last written to the rack, so the setter is called on a change rather than
 * 187.5 times a second. It starts at the rack's own boot state, which is open.
 */
static bool s_midi_gate_open = true;

/* The watchdog's transport input, a second mirror of the same decision. It starts false
 * because the rack does, and the first block writes it before the first render. */
static bool s_midi_transport_open = false;

/*
 * The gate, decided once per block by the task that owns every input to the decision.
 *
 * Called after the ring has been drained and before the render, so a note that arrives
 * in time to be heard this block has already opened the gate for it — and so has a hit.
 * The rack smooths the change itself (see GATE_OPEN_TAU_S in synth_rack.cpp); nothing here
 * ramps anything.
 */
static void midi_gate_tick(void)
{
    if (s_midi_lead_tail > 0u) {
        s_midi_lead_tail--;
    }
    if (s_midi_perc_tail > 0u) {
        s_midi_perc_tail--;
    }

    /*
     * The transport reaches the rack as itself, not through the gate: the gate is open for
     * an external note while the transport is stopped, and a drone under a stopped
     * transport is silent by definition. The silence watchdog needs the difference; see
     * synth_rack_set_transport().
     */
    if (s_running != s_midi_transport_open) {
        s_midi_transport_open = s_running;
        synth_rack_set_transport(s_running ? 1 : 0);
    }

    const bool open = s_running
                   || midi_note_active()
                   || (s_midi_lead_tail > 0u)
                   || (s_midi_perc_tail > 0u);

    if (open != s_midi_gate_open) {
        s_midi_gate_open = open;
        synth_rack_set_gate(open ? 1 : 0);
    }
}

/*
 * The producer's end: called from the MIDI task, on the other core.
 *
 * A full ring DROPS the event and counts it. The consumer is the audio task,
 * which drains sixty-four events in the time of one block, so a ring that is
 * full does not mean a fast player — it means the consumer has stopped, and
 * waiting for it would not make the note sound any earlier. Dropping is
 * therefore the honest answer, and the first drop is logged once: it is a
 * symptom worth seeing, and a per-drop log would be the audio path's problem
 * rather than a report of it. Since the clock and the transport come through the
 * same ring the drop can be one of those as well, which is why the log line says
 * events and not notes.
 */
static void midi_ring_push(midi_evt_kind_t kind, uint8_t part, int note, int vel)
{
    const uint32_t head = s_midi_head.load(std::memory_order_relaxed);
    const uint32_t next = (head + 1u) & (MIDI_RING_SIZE - 1u);

    /* One slot is left empty so that head == tail means empty rather than
     * ambiguous, which is why the ring holds 63 events and not 64. */
    if (next == s_midi_tail.load(std::memory_order_acquire)) {
        s_midi_dropped = s_midi_dropped + 1u;
        if (s_midi_dropped == 1u) {
            ESP_LOGW(TAG, "MIDI ring full: events dropped from here on");
        }
        return;
    }

    s_midi_ring[head].kind   = (uint8_t)kind;
    s_midi_ring[head].part   = part;
    s_midi_ring[head].note   = (uint8_t)note;
    s_midi_ring[head].vel    = (uint8_t)vel;

    /* Release: the four bytes above are visible to the consumer before the index
     * that offers them, whatever the two cores' caches and store buffers were
     * doing. */
    s_midi_head.store(next, std::memory_order_release);
}

extern "C" void synth_app_midi_note_on(int note, float velocity, synth_midi_part_t part)
{
    /* Two parts exist and the input names one of them. Anything else is a caller's bug
     * and is dropped rather than guessed at: a note sent to the wrong part is a note
     * nobody asked for, and the wrong guess would be audible. */
    if (note < 0 || note > 127
        || (part != SYNTH_MIDI_LEAD && part != SYNTH_MIDI_PERC)) {
        return;
    }

    /* No velocity curve. The curve is a SETTING — how a player likes their
     * keyboard to respond — and there are no MIDI settings yet, so the honest
     * default is the one the instrument was designed with: full velocity is the
     * level the voices are opened at, and everything below it is proportional.
     * See lead_volume_for(). The drum reads the same number in the same unit, so
     * one curve would serve both the day there is one. */
    int vel = (int)(velocity * 127.0f + 0.5f);
    if (vel < 0) {
        vel = 0;
    } else if (vel > 127) {
        vel = 127;
    }

    /* NOTE ON at velocity zero IS NOTE OFF — the convention hosts and keyboards
     * both use to reuse the three-byte message for a release. It is enforced on
     * both sides of the seam: the MIDI component already routes it here, and a
     * caller of this function should not have to know that. */
    if (vel == 0) {
        midi_ring_push(MIDI_EVT_NOTE_OFF, (uint8_t)part, note, 0);
        return;
    }

    midi_ring_push(MIDI_EVT_NOTE_ON, (uint8_t)part, note, vel);
}

extern "C" void synth_app_midi_note_off(int note, synth_midi_part_t part)
{
    if (note < 0 || note > 127
        || (part != SYNTH_MIDI_LEAD && part != SYNTH_MIDI_PERC)) {
        return;
    }
    midi_ring_push(MIDI_EVT_NOTE_OFF, (uint8_t)part, note, 0);
}

/*
 * The transport and the clock, producers' end, on the MIDI task and on exactly the terms
 * the notes above are: an event in the ring and a return. Nothing is decided here — not
 * whether a START is early, not whether a clock is the right distance from the last one —
 * because the only side that can decide anything about the instrument is the audio task.
 */
extern "C" void synth_app_midi_clock(void)
{
    midi_ring_push(MIDI_EVT_CLOCK, 0u, 0, 0);
}

extern "C" void synth_app_midi_transport(synth_midi_transport_t what)
{
    switch (what) {
    case SYNTH_MIDI_TRANSPORT_START:
        midi_ring_push(MIDI_EVT_START, 0u, 0, 0);
        return;
    case SYNTH_MIDI_TRANSPORT_CONTINUE:
        midi_ring_push(MIDI_EVT_CONTINUE, 0u, 0, 0);
        return;
    case SYNTH_MIDI_TRANSPORT_STOP:
        midi_ring_push(MIDI_EVT_STOP, 0u, 0, 0);
        return;
    default:
        /* A value this header does not name: dropped rather than guessed at, the
         * same answer an unassigned channel gets in the MIDI component. */
        return;
    }
}

/*
 * Everything below runs on the audio task, on the values the ring delivered.
 */

/* Drop a key from the held list, closing the gap so that the list stays in the
 * order the keys were pressed — which is what "the newest note" means for the
 * drone's harmonisation, and what a note-off has to find to release its own group. */
static void midi_held_remove(int note)
{
    for (int i = 0; i < s_midi_held_n; i++) {
        if (s_midi_held_note[i] != (uint8_t)note) {
            continue;
        }

        for (int j = i + 1; j < s_midi_held_n; j++) {
            s_midi_held_note[j - 1] = s_midi_held_note[j];
            s_midi_held_vel[j - 1]  = s_midi_held_vel[j];
        }
        s_midi_held_n--;
        return;
    }
}

/*
 * One channel-2 note, one hit — the drum's whole MIDI path.
 *
 * THE PITCH IS THE NOTE. The drum has one voice: a noise burst through a band-pass whose
 * centre IS the note of the hit (see synth_perc.cpp), so the only thing a note can say to
 * it is a pitch. That is what it says: the note transposes the PITCH knob, exactly the
 * way the drone's harmonisation transposes the ROOT knob and for the same reason — the
 * knob is the patch and stays where the player put it, and the input is an interval on
 * top of it. 1.0 is the knob's own centre and the sequencer's hits are that.
 *
 * THE REFERENCE IS 38, the GM snare, because that is the drum this voice is closest to:
 * its band-pass through an envelope that drops is a tom or a snare far more than a kick,
 * and the whole kit is then played around it. The interval is the lead's own
 * equal-tempered mapping, applied as a RATIO to the centre, and it is CLAMPED to an
 * octave either way: a note at the top of a keyboard would otherwise ask for a centre
 * above what the module's own range can hold, and the clamp is what keeps a drum note a
 * drum rather than a click. The named notes of the GM kit therefore land two semitones
 * either side of the snare for the kick (36) and four up for the closed hat (42) — the
 * voice has one shape and one DECAY knob, so a "kit" here is a set of pitches and not a
 * set of sounds, and this is that set.
 *
 * VELOCITY IS THE ENGINE'S OWN UNIT, 0..1, which is the unit the sequencer's figure
 * hands over and the one the voice multiplies by. 0..127 from the wire is divided by 127
 * here; a zero velocity is a note-off by the convention and never reaches this function.
 * Nothing else is applied to it: WEAK VEL is a SETTING about the velocity of a step the
 * ACCENT figure does not mark, and this note is not a step — the player's own velocity is
 * the accent, and it arrives at the voice through the same multiply every other hit uses.
 */
#define MIDI_PERC_REF_NOTE   38
#define MIDI_PERC_MAX_SEMIS  12

static void midi_perc_struck(int note, int vel)
{
    /* A part whose fader is at zero has nothing to hold the gate open for: the module
     * refuses to spend a voice on a hit nobody can hear, and the same test here keeps the
     * drone from arriving for half a second because a drum pad was touched with the drum
     * turned down. The test is on the same parameter the module is given, so the two
     * cannot disagree. */
    if (!(s_param[SYNTH_PARAM_PERC_LEVEL] > 0.0f)) {
        return;
    }

    int semis = note - MIDI_PERC_REF_NOTE;
    if (semis > MIDI_PERC_MAX_SEMIS) {
        semis = MIDI_PERC_MAX_SEMIS;
    } else if (semis < -MIDI_PERC_MAX_SEMIS) {
        semis = -MIDI_PERC_MAX_SEMIS;
    }

    /* The keyboard's drum has no lane: it gets the voice the sequencer cannot reach. */
    synth_perc_trigger_voice(PERC_VOICE_MIDI, (float)vel / 127.0f, exp2f((float)semis / 12.0f));

    /* The gate's bookkeeping: this hit's tail, from the module's own reading of the
     * DECAY knob — the same number, from the same function, that the voice's own
     * envelope is built with when it is struck. See midi_gate_tick(). */
    s_midi_perc_tail = midi_ms_to_blocks(synth_perc_decay_ms(s_param[SYNTH_PARAM_PERC_DECAY]));
}

/*
 * The arp's switch, asked by the input's own path: "is the arp on" is the other half of
 * the eviction rule while keys are held — see midi_note_pressed() — and the function
 * itself lives with the arp six hundred lines down.
 */
static bool arp_active(void);

/*
 * One key onto the lead: the group it takes, the key a steal may take with it, and the
 * note itself. The held list is NOT this function's business — the press path adds the
 * key to it first and the arp's hand-back re-reads it — so its two callers disagree
 * about nothing but where the key came from.
 */
static void midi_key_play(int note, int vel)
{
    /*
     * WHICH GROUP, and the one thing the answer can cost. lead_group_alloc() picks
     * the group before the note is opened because it may have to STEAL one, and a
     * group taken from a note that is still down takes that key with it: the victim
     * leaves the held list here, in the same call that takes its voices, so what the
     * list says is held and what the lead is playing cannot come apart. A key the
     * steal has dropped is silent until it is pressed again — which is what voice
     * stealing is — and the drone's harmonisation follows the newest key that is
     * still listed, which is the newest note that is still audible.
     */
    /*
     * АККОРД ИЗ ОДНОЙ КЛАВИШИ, и снова три группы. Здесь тот же расчёт, что у
     * секвенсора (lead_note_on), но ноты клавиши распределяются сами: первая может
     * занять группу, которая уже держала эту ноту (повторное нажатие — это та же нота),
     * а вторая и третья обязаны получить ДРУГИЕ, иначе они заменят первую и слушатель
     * снова услышит одну ноту.
     */
    float notes[LEAD_CHORD_NOTES];
    int count = 0;

    if (s_lead_chord) {
        lead_chord_hz(midi_to_hz(seq_scale_note(note)), notes, &count);
    }
    if (count <= 0) {
        notes[0] = midi_to_hz(seq_scale_note(note));
        count = 1;
    }

    for (int i = 0; i < count; i++) {
        const int group = lead_group_take(note, i == 0);
        const int victim = s_lead_note[group];

        if (victim >= 0 && victim != note) {
            midi_held_remove(victim);
        }

    /* Always retriggered, even when that group is already sounding — a new key is a
     * new note, and the envelope is what makes the line articulate rather than
     * smear. That is lead_group_on()'s own rule, and it is the same one the
     * sequencer relies on.
     *
     * The group is claimed BEFORE its voices are opened, because the filter's gate
     * is read off the table and a note that is not in it yet would open its voices
     * behind a closed filter. The stamp is the press order either way: a chord is
     * drained in one block, and these two lines run in the ring's order. */
        lead_group_claim(group, note);
        lead_group_on(group, notes[i], (float)vel / 127.0f
                                    * (i == 0 ? 1.0f : LEAD_CHORD_LEVEL[i]));
    }
}

static void midi_note_pressed(int note, int vel)
{
    /* A key pressed again before it was released must not stack: the list is a
     * set with an order, not a log. A host that repeats a note-on — or a player
     * holding a key while a DAW retriggers it — would otherwise leave a phantom
     * note held after one release, and the lead would never fall silent. */
    midi_held_remove(note);

    if (s_midi_held_n >= MIDI_HELD_MAX) {
        /* Full: forget the OLDEST key rather than refuse the new one. The note
         * the player just pressed is the one they expect to hear; the oldest is
         * the one they played longest ago. */
        for (int i = 1; i < s_midi_held_n; i++) {
            s_midi_held_note[i - 1] = s_midi_held_note[i];
            s_midi_held_vel[i - 1]  = s_midi_held_vel[i];
        }
        s_midi_held_n = MIDI_HELD_MAX - 1;
    }

    s_midi_held_note[s_midi_held_n] = (uint8_t)note;
    s_midi_held_vel[s_midi_held_n]  = (uint8_t)vel;
    s_midi_held_n++;

    /*
     * THE ARP HAS THE LEAD while it is on, so a key that arrives under it is LISTED and
     * not played. The keys are the arp's figure and the arp walks them in a group of its
     * own (see arp_held_step() and arp_tick()); the group this function would otherwise
     * open is where the player's chord sounded, which is the second source the player did
     * not ask for. The key is written to the held list either way, because that list is
     * what the arp reads and what DIR turned to OFF hands back to the lead — see
     * arp_lead_tick().
     *
     * With the arp off the test is false and this is the press it always was.
     */
    if (!arp_active()) {
        midi_key_play(note, vel);
    }
}

static void midi_note_released(int note)
{
    const int before = s_midi_held_n;
    midi_held_remove(note);

    if (s_midi_held_n == before) {
        /* A release for a key that was never seen held: a cable pulled and
         * replugged, a host that lost track, a device that was flashed while a
         * key was down — or a key the steal took a group from. Ignored rather than
         * acted on, because a note-off for an unknown note cannot be allowed to cut
         * a note that IS sounding — that is how a stray byte would silence the
         * instrument mid-phrase. */
        return;
    }

    if (s_midi_held_n > 0) {
        /*
         * THIS KEY'S OWN GROUP, and only it.
         *
         * The notes still held are other notes in other groups: letting one go must
         * not cut the two that are still down, and it must not reopen them either.
         * The monophonic fall-back that played the newest key still down would do
         * exactly that here — retrigger a note that never stopped sounding, with the
         * envelope of a key that is no longer part of it — and the release is the
         * whole of what this event means.
         *
         * A key the held list no longer has cannot be sounding, but the lookup is
         * allowed to fail rather than assumed to succeed.
         */
        /*
         * ВСЕ ГРУППЫ ЭТОЙ КЛАВИШИ, а не первая. В аккорде одна клавиша — три ноты в
         * трёх группах, и отпустить одну значило бы оставить две звучать без того, кто
         * их закроет. В моно и поли совпадение одно, и цикл стоит тех же двух сравнений.
         */
        for (int g = 0; g < LEAD_GROUPS; g++) {
            if (s_lead_note[g] == (int16_t)note) {
                lead_group_off(g);
            }
        }
        return;
    }

    /* Nothing is held: the lead is handed back silent. seq_release() is the
     * lead's own release — it is what the sequencer's gate expiry calls — so an
     * external note ends exactly as an internal one does, envelope and filter
     * follower included. It is also what makes the last release of a chord the same
     * single voice-off the monophonic lead always wrote. */
    seq_release();

    /* ...and the output stays open for as long as that release is making a sound.
     *
     * WHICH RELEASE is worth being exact about, because there are two and only one of them
     * is audible. The FILTER's envelope is an AR now and closes by the end of the note
     * whatever happens next, so it is not a tail at all; the note's own amplitude is the
     * engine envelope the lead's voices are configured with, and its release is the LEAD
     * RELEASE knob. That is the number the voice is built with and therefore the number
     * this reads: a note is inaudible that long after noteOff, and the gate's own closing
     * ramp — 34 ms to -60 dB — covers what is left of the decay after that.
     * See midi_gate_tick(). */
    s_midi_lead_tail = midi_ms_to_blocks(lead_time_for(s_cur[SYNTH_PARAM_LEAD_RELEASE]));
}

/*
 * The consumer's end, called once per block from the audio task and BEFORE the
 * sequencer's step of that block.
 *
 * That order is the eviction rule stated as a line of code: a note that arrives in
 * time to be heard this block has already taken the lead by the time seq_tick()
 * runs, so the Euclidean sequencer sees midi_note_active() and does not open a note
 * of its own — and so the arpeggiator, which now plays the held keys instead of
 * stepping aside for them, finds the key already in the held list and in the lead's
 * group table on the block it arrives. A release is read here too, so the line gets
 * the lead back on the same block rather than one block later.
 *
 * The whole ring is drained every block rather than one event per block: a chord
 * is three messages in the same millisecond, and taking them one block apart
 * would sound them 5 ms apart and open the first of them with the wrong stack.
 *
 * THE TRANSPORT AND THE CLOCK ARE READ HERE TOO, and they are the reason this is
 * more than a note path now. Two of them are writes to state the audio task owns —
 * s_running, and the position a START puts back to zero — and one of them is the
 * tempo measurement, which is timed in blocks and therefore can only be made on the
 * task that has the block clock. None of that could happen on the MIDI task: it is a
 * different core and it does not own the engine. See midi_clock_tick() and
 * midi_transport_reset().
 */
static void drain_midi_events(void)
{
    /* The clock's own time first, and once per block: it is what the tempo is
     * measured in, and what ends the override when the wire stops. */
    midi_clock_block();

    for (;;) {
        const uint32_t tail = s_midi_tail.load(std::memory_order_relaxed);

        /* Acquire: the event's four bytes are read below only after the index
         * that published them. */
        if (tail == s_midi_head.load(std::memory_order_acquire)) {
            break;
        }

        const uint8_t kind = s_midi_ring[tail].kind;
        const uint8_t part = s_midi_ring[tail].part;
        const int     note = (int)s_midi_ring[tail].note;
        const int     vel  = (int)s_midi_ring[tail].vel;

        /* Release: the slot is free for the producer only after it has been
         * read. */
        s_midi_tail.store((tail + 1u) & (MIDI_RING_SIZE - 1u), std::memory_order_release);

        if (kind == MIDI_EVT_CLOCK) {
            midi_clock_tick();
        } else if (kind == MIDI_EVT_START) {
            /* From the top: the transport runs and the phrase starts again at its
             * first step. The note the sequencer may have open is deliberately left
             * to its own gate — see midi_transport_reset(). */
            synth_app_set_running(1);
            midi_transport_reset();
        } else if (kind == MIDI_EVT_CONTINUE) {
            /* Running, from where the phrase stands: the same call as START with the
             * reset it does not make. */
            synth_app_set_running(1);
        } else if (kind == MIDI_EVT_STOP) {
            /* The button's own call, on the wire's behalf. It closes the output and
             * silences the generators at their source, and it does NOT stop the arp
             * over keys the player is holding — that is the rule the button has always
             * had. See midi_gate_tick() and arp_tick(). */
            synth_app_set_running(0);
        } else if (part == (uint8_t)SYNTH_MIDI_PERC) {
            /*
             * A DRUM HIT IS NOT A HELD NOTE, so a note-off has nothing to release: the
             * voice's own DECAY is its gate and it is already running, and the module has
             * no per-voice gate to cut with anyway. Cutting a drum on the release would
             * make a hi-hat out of every tom a player holds down, which is not what a
             * drum machine does and not what a MIDI drum track expects.
             */
            if (kind == MIDI_EVT_NOTE_ON) {
                midi_perc_struck(note, vel);
            }
        } else if (kind == MIDI_EVT_NOTE_ON) {
            midi_note_pressed(note, vel);
        } else {
            midi_note_released(note);
        }
    }
}

/* -------------------------------------------------------------------------- */
/* The drone, harmonised to what the player is holding                        */
/* -------------------------------------------------------------------------- */
/*
 * WHAT THE DRONE DOES WHILE THE LEAD PLAYS: four answers to one question.
 *
 * THE BASE IS THE DRONE'S OWN, AND ROOT DOES NOT MOVE IT. The drone is voiced at 55 / 110 /
 * 220 Hz (A1, A2, A3, one octave apart) and that is where every mode starts. The ROOT knob
 * names the key — the scale and its tonic — and the drone is brought into that key THROUGH THE
 * SCALE, not by transposing it with the knob. The rule this replaces did the opposite: the base
 * WAS the knob, so turning ROOT walked the whole drone by up to seven octaves, in every mode
 * at once, and the drone could not keep a register of its own while the player changed
 * key. One base for all three modes is also what makes a change of mode a decision about
 * following rather than a retune by the difference between two references.
 *
 * WHAT IS READ, AND IN WHAT ORDER. One note, from drone_follow_note(): the newest key the
 * lead is SOUNDING — the last key the player pressed that no steal has taken — and, with no
 * key held and FULL selected, the last note the LEAD STARTED from the sequencer or the arp
 * (s_lead_last_note, written by lead_group_on()). The key always wins, because a held key is
 * what the player means; the generator's note is what FULL exists for, and without it the
 * drone would sit on its base for a whole session of sequenced music and be reported as not
 * following at all. SCALE and CONS read keys only: both are answers about a held note, and a
 * figure that changes every step would put the drone on a new degree at every note. It is one
 * note of a polyphonic lead on purpose: the drone is one fundamental and its octaves, so there
 * is one thing it can be tuned to, and the note that sounded last is the one that is heard.
 *
 * The note is quantised by the scale FIRST (seq_scale_note()), so every mode below sees the
 * note the player hears, not the key that was pressed. With no note to follow — nothing held,
 * the transport stopped — all three modes return to the base, and FULL drops the memory of the
 * generator's last note in the same block.
 *
 * THE THREE MODES, chosen by SYNTH_PARAM_DRONE_FOLLOW, in the order the list shows them:
 *
 *   SCALE  the drone joins the newest note's PITCH CLASS, in the nearest direction: the
 *          interval from the base folded into ±6 semitones. The note was quantised first, so
 *          the drone lands on a degree of the scale and stays in its own register — a fifth
 *          above the base arrives as a fourth below. This is the old FOLD, re-anchored on the
 *          base instead of the ROOT knob. The factory answer, and what a record written
 *          before this parameter gets.
 *   CONS   only a consonance moves it. The interval from the base is tested UPWARD against the
 *          four intervals a drone may double — the unison/octave (class 0), the third (3 and 4),
 *          the fourth (5) and the fifth (7) — and on one of those the drone joins the note's
 *          pitch class, folded like SCALE so that the fifth arrives as −5. On anything else —
 *          seconds, sixths, sevenths, the tritone — it STANDS WHERE IT STOOD: the last shift it
 *          joined, or the base if it has not joined one yet. Letting go of every note clears
 *          that memory and returns the drone to the base.
 *   FULL   the drone follows the note COMPLETELY: the shift is the whole signed interval from
 *          the base, octaves included, so the LOW register lands on the played note and MID and
 *          HIGH are one and two octaves above it. This is the only mode in which the drone
 *          leaves its register: the shift passes ±6 as soon as the note is more than a tritone
 *          from A1, and an octave of the keyboard is twelve semitones of drone.
 *
 * STAY IS GONE. It was the pedal: the drone sat on the nearest degree of the scale to the base
 * and the melody could not move it. The owner's decision is that the drone is a follower, so the
 * position was removed from the list rather than kept; the position it held is SCALE's, which is
 * where a record from the four-position list maps (see synth_app_patch_apply()).
 *
 * WHY SCALE AND CONS FOLD. The three registers are octaves of ONE fundamental, so a shift of a
 * pitch class in the nearest direction keeps the drone in the octave it lives in: moving by
 * three semitones is moving the drone, not the octave it lives in. Sounding an octave of the
 * played note is the most consonant thing a drone can do; a full-interval answer is a different
 * mode (FULL) and is offered as one rather than imposed on every mode. Six semitones is a
 * tritone either way and the fold takes +6 for it deterministically: the tritone is the one
 * interval with no nearer direction, and a coin toss would make the same chord move differently
 * on two presses.
 *
 * THE EDGES, decided here so that they are decisions rather than accidents:
 *
 *   - CONS's memory is a SHIFT in semitones, not a MIDI note. A note would have to be
 *     re-quantised and re-folded against whatever ROOT and SCALE say on the next block, so a
 *     key change under a held note could silently re-mean the interval the drone agreed to;
 *     storing the shift makes "stands where it stood" literal.
 *   - A note that is not in the scale at all cannot arise: the lead's note is quantised before
 *     any mode sees it, the same rule every pitch sink follows.
 *   - NO SOUNDING NOTE returns SCALE, FULL and CONS to the base, CONS's memory included — not
 *     "hold the last note". A drone left on a pitch class the player cannot see on any control
 *     is wrong at the start of the next phrase; returning is also the cheaper answer, with no
 *     staleness to clear, and it is what the smoothing below is for.
 *   - A SHIFT IS A SHIFT IN SEMITONES, whichever mode produced it, so a change of mode is
 *     smoothed by the one-pole below exactly like a change of note: selecting CONS while the
 *     drone is on a fifth glides it home instead of dropping it. The parameter itself is a list
 *     and arrives in one block (apply_pending_params() has nothing to write for it), which is
 *     precisely why the smoothing cannot live on the parameter.
 *
 * SMOOTH, AND WHY IT IS SMOOTHENED IN SEMITONES. The pitch is written with setFrequency, which
 * steps it in one sample: the engine's phase is continuous across a change, so the step is a
 * step in pitch and not a click, but a step of five semitones is heard as a lurch. A one-pole
 * on the offset, evaluated once per block beside the parameter appliers, turns it into a glide
 * of a few tens of milliseconds. It is the same one-pole the drone filter's cutoff and the
 * lead's own cutoff are smoothed with, and the same reasoning: a value that arrives from
 * outside must not step.
 *
 * THE TIME CONSTANT IS 8 ms, the drone filter's own. At the block rate of 187.5 Hz that is the
 * whole interval in about fifty milliseconds, in steps that get smaller as it goes: a
 * six-semitone shift moves two semitones in the first block (5.3 ms), three and a half of the
 * six within ten, and is within a cent of the note by forty-five. A FULL shift of an octave or
 * more therefore sweeps rather than jumps, which is the honest consequence of asking one mode
 * to travel with the keyboard. Fast enough to arrive with the player's fingers, and no single
 * block carries the whole interval.
 */
#define DRONE_TUNE_TAU_S     0.008f
#define DRONE_TUNE_SNAP_ST   0.002f   /* 0.2 cent: below what any tuning can resolve */

/* The three answers, in the order the list shows them. The default is the first: SCALE.
 * STAY was removed and its position is not kept: a stored value is mapped by
 * drone_follow_from_legacy(), and a record with no byte for this parameter gets the
 * default. */
enum {
    DRONE_FOLLOW_SCALE = 0,
    DRONE_FOLLOW_CONS,
    DRONE_FOLLOW_FULL,
    DRONE_FOLLOW_COUNT
};
static_assert(DRONE_FOLLOW_COUNT == 3, "FOLLOW is three answers: SCALE, CONS, FULL");

/* CONS's memory: the shift it last agreed to join, in semitones. See the edges above. */
static int s_drone_cons_st;

/* The mode the list parameter currently names, clamped: a value written by a load can be
 * anything in 0..1 and the list is three long. */
static int drone_follow_mode(void)
{
    const int n = DRONE_FOLLOW_COUNT - 1;
    const int i = (int)(s_param[SYNTH_PARAM_DRONE_FOLLOW] * (float)n + 0.5f);
    return i < 0 ? 0 : (i > n ? n : i);
}

/* A stored FOLLOW byte from the four-position list, as a value in this one.
 *
 * The old list was STAY, SCALE, FULL, CONS and the old knob wrote position/(4-1); the new
 * list is SCALE, CONS, FULL and the knob writes position/(3-1). Reading the old number as
 * if it were the new one would put a stored SCALE (1/3) and a stored FULL (2/3) both on
 * CONS, and a stored CONS (3/3) on FULL — wrong modes from a record that is otherwise
 * intact. The map is written as positions, not as thresholds on the float, so it is exact
 * for every value a four-position knob could have produced:
 *
 *   0 STAY  -> SCALE (0)
 *   1 SCALE -> SCALE (0)
 *   2 FULL  -> FULL  (2)
 *   3 CONS  -> CONS  (1)
 *   anything else -> SCALE, which is the factory and the safe reading. "Anything else" is a
 *   position outside the old list — a corrupted byte, or a value that never came from that
 *   knob — and it is deliberately not clamped to an end: a record that has lost its meaning
 *   should come back as the least surprising mode rather than as the loudest one.
 */
static float drone_follow_from_legacy(float v01)
{
    const int pos = (int)(v01 * 3.0f + 0.5f);

    if (pos < 0 || pos > 3) {
        return (float)DRONE_FOLLOW_SCALE / (float)(DRONE_FOLLOW_COUNT - 1);
    }

    const int now = (pos <= 1) ? DRONE_FOLLOW_SCALE : (pos == 2 ? DRONE_FOLLOW_FULL
                                                              : DRONE_FOLLOW_CONS);

    return (float)now / (float)(DRONE_FOLLOW_COUNT - 1);
}

/* A sounding note's class against the base, 0..11: what the drone would have to add to the
 * base to be on that note with the octave dropped. The note is quantised first, because the
 * note the player HEARS is the quantised one. */
static int drone_base_class(int note)
{
    int d = (seq_scale_note(note) - s_drone_base_midi) % 12;
    if (d < 0) {
        d += 12;
    }
    return d;
}

/* Class to a shift, nearest direction, the tritone taken upwards. */
static int drone_fold(int d)
{
    return d > 6 ? d - 12 : d;
}

/* The shift a mode asks for, in semitones, given the sounding note (-1 for none). */
static float drone_follow_shift(int mode, int note)
{
    if (note < 0) {
        s_drone_cons_st = 0;
        return 0.0f;
    }

    const int c = drone_base_class(note);

    switch (mode) {
    case DRONE_FOLLOW_SCALE:
        return (float)drone_fold(c);

    case DRONE_FOLLOW_CONS: {
        const bool consonant = (c == 0 || c == 3 || c == 4 || c == 5 || c == 7);
        if (consonant) {
            s_drone_cons_st = drone_fold(c);
        }
        return (float)s_drone_cons_st;
    }

    case DRONE_FOLLOW_FULL:
        /* The whole interval, octaves and all: the LOW register goes to the note. */
        return (float)(seq_scale_note(note) - s_drone_base_midi);

    default:
        return 0.0f;
    }
}

/*
 * WHICH NOTE THE DRONE IS ASKED TO FOLLOW.
 *
 * A key that is still down always wins, because it is the note the player is holding and the
 * one they mean. With nothing held, FULL keeps following: the last note the lead started —
 * the sequencer's step or the arp's — counts as the note to harmonise to for as long as the
 * transport runs, so the drone travels with the music instead of sitting on its base. That is
 * the whole difference between FULL and the other two answers, and it is why FULL is the mode
 * a player chooses when the drone should move with the figure rather than with the fingers.
 *
 * SCALE and CONS keep their key-only rule. Both are decisions about a HELD note — joining its
 * pitch class, or agreeing to double a consonance — and running them from a figure that
 * changes every step would put the drone on a new degree at every note.
 *
 * When the transport stops and nothing is held, the memory is dropped and the drone returns
 * to its base in the same block.
 */
static int drone_follow_note(void)
{
    if (!s_running && midi_newest_note() < 0) {
        s_lead_last_note = -1;
    }

    const int key = midi_newest_note();
    if (key >= 0) {
        return key;
    }

    if (drone_follow_mode() == DRONE_FOLLOW_FULL && s_running && s_lead_last_note >= 0) {
        return s_lead_last_note;
    }

    return -1;
}

/*
 * Дрейф строя, раз в блок. Стоимость при нуле — три сравнения: ручка на заводском
 * положении не двигает ничего, и это то, что позволяет держать дрейф в общем такте, а не
 * в отдельной задаче.
 */
static void drone_drift_tick(void)
{
    const float depth = clamp01f(s_param[SYNTH_PARAM_DRONE_DRIFT]) * DRONE_DRIFT_MAX_CT;

    /* Ноль — это состояние, а не число, которое почти ноль: выключенный дрейф не двигает
     * питч вовсе, и всё, что было записано раньше, звучит до цента как звучало. */
    if (depth <= 0.0f) {
        bool any = false;

        for (int r = 0; r < DRONE_REGISTERS; r++) {
            if (s_drone_drift_ct[r] != 0.0f) {
                s_drone_drift_ct[r] = 0.0f;
                any = true;
            }
        }
        if (any) {
            drone_retune();
        }
        return;
    }

    const float inc = DRONE_DRIFT_HZ
                    * ((float)SYNTH_BLOCK_SAMPLES / (float)SYNTH_SAMPLE_RATE);

    bool changed = false;

    for (int r = 0; r < DRONE_REGISTERS; r++) {
        s_drone_drift_ph[r] += inc;
        if (s_drone_drift_ph[r] >= 1.0f) {
            s_drone_drift_ph[r] -= 1.0f;
        }

        const float want = sinf(6.28318531f * s_drone_drift_ph[r]) * depth;
        const float quant = floorf(want / DRONE_DRIFT_STEP_CT + 0.5f) * DRONE_DRIFT_STEP_CT;

        if (quant != s_drone_drift_ct[r]) {
            s_drone_drift_ct[r] = quant;
            changed = true;
        }
    }

    /* Девять setFrequency — только когда квант действительно сдвинулся: на медленном
     * дрейфе это несколько раз в секунду, а не каждый блок. */
    if (changed) {
        drone_retune();
    }
}

/*
 * ДВА ПРИЁМНИКА, КОТОРЫЕ СЧИТАЮТСЯ РАЗ В БЛОК: резонанс дрона и обрезной лида.
 *
 * Оба — обычные непрерывные ручки, поэтому модуляция складывается с их базовым положением
 * и пишется тем же путём, что и от самой ручки. Пока приёмник не выбран, глубины нулевые и
 * функции не делают ничего.
 */
static void mod_receivers_tick(void)
{
    if (fabsf(mod_depth_sum(MD_RESO)) > 0.0f) {
        float v = clamp01f(s_param[SYNTH_PARAM_RESONANCE]) + mod_sum_pm(MD_RESO) * 0.25f;

        apply_resonance(clamp01f(v));
    }

    if (fabsf(mod_depth_sum(MD_LEAD_FC)) > 0.0f) {
        float v = clamp01f(s_param[SYNTH_PARAM_LEAD_CUTOFF]) + mod_sum_pm(MD_LEAD_FC) * 0.25f;

        apply_lead_cutoff(clamp01f(v));
    }

    /* Доли эффектов пересобираются тем же путём, что и от ручки: значения внутри уже
     * содержат модуляцию, поэтому пересборка просто повторяет то, что сделала бы ручка. */
    if (fabsf(mod_depth_sum(MD_DL_MIX)) > 0.0f) {
        apply_delay();
    }
    if (fabsf(mod_depth_sum(MD_RV_MIX)) > 0.0f) {
        apply_reverb();
    }
    if (fabsf(mod_depth_sum(MD_FX_MIX)) > 0.0f) {
        apply_chorus();
    }
}

static void drone_tune_tick(void)
{
    /* The offset the mode asks for. See the note above for what is read, in what order. */
    const int note = drone_follow_note();
    const float target = drone_follow_shift(drone_follow_mode(), note) + s_drone_base_st;

    const float before = s_drone_tune_st;

    if (target != s_drone_tune_st) {
        float a = ((float)SYNTH_BLOCK_SAMPLES / (float)SYNTH_SAMPLE_RATE) / DRONE_TUNE_TAU_S;
        if (a > 1.0f) {
            a = 1.0f;
        }

        s_drone_tune_st += (target - s_drone_tune_st) * a;

        /* A one-pole never arrives, and this one has to: the last stretch of it is below
         * what the engine's hundredths of a hertz can express, and snapping is what makes
         * "the shift is zero" a state the code can test for rather than a number that is
         * almost zero and keeps nine voices being written every block for the rest of the
         * session. */
        if (fabsf(target - s_drone_tune_st) < DRONE_TUNE_SNAP_ST) {
            s_drone_tune_st = target;
        }
    }

    /* Nine setFrequency calls a block is not free, so they happen only when the number
     * they would be given has changed: at rest this function costs one comparison. */
    if (s_drone_tune_st != before) {
        drone_set_pitch(DRONE_BASE_HZ, s_drone_tune_st);

        /* The filter's key tracking follows the same shift, so it is republished on the
         * same event and never on a timer: one exp2f and three int16 writes while the drone
         * is gliding, nothing at rest. At zero tracking apply_cutoff() computes the same
         * numbers it did before this parameter existed. */
        if (s_param[SYNTH_PARAM_DRONE_KTRCK] > 0.0f) {
            apply_cutoff(s_param[SYNTH_PARAM_CUTOFF]);
        }
    }
}

/* -------------------------------------------------------------------------- */
/* Arpeggiator                                                                */
/* -------------------------------------------------------------------------- */

/*
 * A second generator, and a different idea from the Euclidean sequencer beside it.
 * The sequencer decides WHEN notes fall and lets a Markov walk decide which; the
 * arp decides both, and what it plays is a staircase — LEN notes climbing RANGE
 * octaves from the tonic, in the direction asked for.
 *
 * That is why LEN and RANGE are separate controls rather than one. RANGE is how far
 * the figure reaches, LEN is how many notes it takes to get there; three notes
 * across two octaves and eight notes across two octaves are the same interval span
 * and completely different music.
 *
 * SPEED is a division of the beat and nothing else. An arpeggiator that could be
 * set out of time would be a novelty on an instrument whose whole timing story is
 * that a step is a whole number of blocks — and its phrase is measured against the
 * same bar, so it adds up to a whole number of bars instead of drifting away from
 * them.
 */

/*
 * The figure's direction. OFF lives HERE rather than in the speed: the speed is how fast
 * the figure runs and the direction is WHAT it is, so "no figure" is a kind of direction
 * rather than a tempo. It also leaves the arp with one value to read, which is why
 * arp_active() is a single comparison.
 *
 * The two "+" figures are the inclusive ones: they hold the top and the bottom of the
 * range for an extra step instead of turning around on them. A figure of one note has no
 * ends to hold and falls back to that one note — see arp_hz_for().
 */
enum {
    ARP_DIR_OFF = 0,
    ARP_DIR_UP,
    ARP_DIR_DOWN,
    ARP_DIR_UPDOWN,
    ARP_DIR_DOWNUP,
    ARP_DIR_UPDOWN_INC,
    ARP_DIR_DOWNUP_INC,
    ARP_DIR_RANDOM,
    ARP_DIR_COUNT
};

/*
 * The arp's speeds, BY NAME, for the reason the delay's divisions carry theirs: the
 * index of a name IS the position of the knob, so anything that has to point at one of
 * them — the factory default above all — names it. A raw number went stale as this list
 * grew and would have gone on meaning whatever happened to sit at that position.
 *
 * The order is by division length: the slowest first, one whole note at the top and four
 * of them above it, down to the thirty-second. The dotted entries are one and a half of
 * their neighbour, and 1/8T is the eighth triplet, so it sits beside the other
 * sixteenths rather than in size order — the same place the delay puts it.
 */
enum {
    ARP_DIV_4_1 = 0,        /* four whole notes: sixteen beats to a note */
    ARP_DIV_2_1,            /* two whole notes: eight beats */
    ARP_DIV_1_1,            /* a whole note: four beats */
    ARP_DIV_1_2_DOT,        /* dotted half: three beats */
    ARP_DIV_1_2,            /* half: two beats */
    ARP_DIV_1_4_DOT,        /* dotted quarter: one and a half */
    ARP_DIV_1_4,            /* quarter: one beat */
    ARP_DIV_1_8_DOT,        /* dotted eighth: three quarters */
    ARP_DIV_1_8,            /* eighth: half a beat */
    ARP_DIV_1_16_DOT,       /* dotted sixteenth: three eighths of a beat */
    ARP_DIV_1_8_T,          /* eighth triplet: a third of a beat */
    ARP_DIV_1_16,           /* sixteenth: a quarter of a beat */
    ARP_DIV_1_32,           /* thirty-second: an eighth of a beat */
    ARP_DIV_NAME_COUNT
};
#define ARP_SPEED_COUNT    ARP_DIV_NAME_COUNT   /* thirteen divisions, the slowest first */
#define ARP_SPEED_DEFAULT  ARP_DIV_1_4          /* the division the line was voiced at */
#define ARP_LEN_MIN      2
#define ARP_LEN_MAX      8
/*
 * The arp's range: HOW MANY OCTAVES, no sign, from zero.
 *
 * It used to be nine positions — -3..-1, +1..+3 and +/-1..+/-3 — and every one of them was a
 * direction as well as a distance. That was the wrong split: the arp already has a DIR, and a
 * range that also chose a direction meant the same span could be asked for two ways and two of
 * the three families were the same music played backwards. What is left is the distance: 0 to
 * 5 octaves, one detent per octave, and where the figure goes is DIR's business — UP climbs the
 * span, DN walks the same span down, UP-DN goes up and back.
 *
 * ZERO IS ONE NOTE, and it is a real setting rather than an accident: with no span the figure
 * has nowhere to climb, so every step of it sounds the tonic — a pedal, which is what an
 * arpeggiator does when it is asked to hold one note. The four chords of a held chord still
 * sound because LEN and DIR are what choose among them.
 */
#define ARP_RANGE_MAX    5                       /* octaves at the widest setting */
#define ARP_RANGE_COUNT  (ARP_RANGE_MAX + 1)     /* 0..5 */

/* How much of a beat one note lasts — the same arithmetic the delay's sync uses, so
 * 1/8T is a triplet in both places. There is no "off" here any more: the arp is switched
 * from its DIR, so every entry is a real division. */
static const float ARP_DIV_BEATS[ARP_SPEED_COUNT] = {
    [ARP_DIV_4_1]      = 16.0f,
    [ARP_DIV_2_1]      = 8.0f,
    [ARP_DIV_1_1]      = 4.0f,
    [ARP_DIV_1_2_DOT]  = 3.0f,
    [ARP_DIV_1_2]      = 2.0f,
    [ARP_DIV_1_4_DOT]  = 1.5f,
    [ARP_DIV_1_4]      = 1.0f,
    [ARP_DIV_1_8_DOT]  = 0.75f,
    [ARP_DIV_1_8]      = 0.5f,
    [ARP_DIV_1_16_DOT] = 0.375f,
    [ARP_DIV_1_8_T]    = 1.0f / 3.0f,
    [ARP_DIV_1_16]     = 0.25f,
    [ARP_DIV_1_32]     = 0.125f,
};

/*
 * The figure's position is the transport's, like every other figure's: the step is
 * derived from the phase (tp_phrase_index) and the only state here is the absolute step
 * the last block stood on: `phrase * steps + local`, which is what makes the same place
 * in the figure the same note every time round. It is a position, not a duration, and
 * no gate or boundary is measured from it.
 */
static uint64_t s_arp_prev = ~(uint64_t)0;  /* the step last block; ~0 = none since START */
static uint64_t s_arp_origin;               /* the step the phrase started on; the lead's RESET moves it */

/*
 * A CHANGE OF DIVISION WAITS FOR THE LINE, the way the drum's SPEED does.
 *
 * The four positions of the drum's clock and the thirteen of the arp's are the same kind of
 * number: a rate, not a shape. What the ear wants from a rate is that it changes ON the grid,
 * because a phrase whose length just changed but whose phase did not lands in the middle of
 * itself — the note under the cursor is a different degree of a different walk, and it sounds
 * like a stumble rather than like a new rate.
 *
 * So the division takes effect at once for the length of a step, and the FIGURE re-anchors at
 * the NEXT BAR LINE: s_arp_origin is set to the raw step of that moment, the figure is at its
 * first note, and it walks from there at the new rate. One bar at most, whatever the division
 * — a phrase line would be up to four bars away at the slowest ones, and an instrument that
 * goes quiet for four bars after a knob touch is worse than one that stumbles.
 *
 * DIR, RANGE and LEN are NOT in this. They are shapes, the figure keeps its position across
 * them, and the stumble they make was heard, reported and kept on purpose — see arp_tick().
 */
static int      s_arp_speed_seen = -1;
static bool     s_arp_realign;
static uint64_t s_arp_tp_bar_seen;   /* the bar the change happened in: the next one is the line */

static int arp_dir(void)
{
    int d = (int)(s_param[SYNTH_PARAM_ARP_DIR] * (float)(ARP_DIR_COUNT - 1) + 0.5f);
    if (d < 0) {
        d = 0;
    } else if (d > ARP_DIR_COUNT - 1) {
        d = ARP_DIR_COUNT - 1;
    }
    return d;
}

static int arp_speed_index(void)
{
    int s = (int)(s_param[SYNTH_PARAM_ARP_SPEED] * (float)(ARP_SPEED_COUNT - 1) + 0.5f);
    if (s < 0) {
        s = 0;
    } else if (s > ARP_SPEED_COUNT - 1) {
        s = ARP_SPEED_COUNT - 1;
    }
    return s;
}

static int arp_len(void)
{
    int n = ARP_LEN_MIN
          + (int)(s_param[SYNTH_PARAM_ARP_LEN] * (float)(ARP_LEN_MAX - ARP_LEN_MIN) + 0.5f);
    if (n < ARP_LEN_MIN) {
        n = ARP_LEN_MIN;
    } else if (n > ARP_LEN_MAX) {
        n = ARP_LEN_MAX;
    }
    return n;
}

static int arp_range_index(void)
{
    int i = (int)(s_param[SYNTH_PARAM_ARP_RANGE] * (float)(ARP_RANGE_COUNT - 1) + 0.5f);
    if (i < 0) {
        i = 0;
    } else if (i > ARP_RANGE_COUNT - 1) {
        i = ARP_RANGE_COUNT - 1;
    }
    return i;
}

/*
 * The two ends of the range in octaves, lo <= hi — and lo is always the tonic now.
 *
 * The pair is kept as a pair rather than collapsed to one number because the two callers build
 * a figure from a span, and a span is what the arithmetic reads; the bottom being zero is the
 * consequence of the range no longer carrying a sign. DIR decides which end the figure starts
 * from, and the same span therefore walks up, down or both.
 */
static void arp_range_ends(int *lo, int *hi)
{
    *lo = 0;
    *hi = arp_range_index();
}

/* The arp is on when its DIR says so: the direction carries OFF, so this is the only
 * switch the arp has. */
static bool arp_active(void)
{
    return arp_dir() != ARP_DIR_OFF;
}

/*
 * The bar every figure is measured against, in blocks. Rounded to a block: the tempo
 * is the one the sequencer, the arp and the delay read, and a bar is the unit the
 * phrase below has to add up to.
 */
static uint32_t bar_blocks_for_bpm(float bpm)
{
    /* The multiplication is inside the division on purpose: 60 * 48000 / 256 is 11250
     * blocks a minute, while (48000 / 256) first is 187 and loses the half block —
     * 11220, a bar of 374 blocks at 120 BPM and a tempo 0.27% slow. The bar is the
     * unit the phase advances in, so this number is the transport's whole scale. */
    const uint32_t blocks_per_minute =
        (uint32_t)((60u * (uint64_t)SYNTH_SAMPLE_RATE) / SYNTH_BLOCK_SAMPLES);

    if (!(bpm > 0.0f)) {
        bpm = (float)SEQ_TEMPO_MIN_BPM;
    }
    return (uint32_t)(4.0f * (float)blocks_per_minute / bpm + 0.5f);
}

static uint32_t bar_blocks_now(void)
{
    return bar_blocks_for_bpm(seq_tempo_now());
}

/*
 * ONE POSITION, AND THE WHOLE OF HOW THIS INSTRUMENT KEEPS TIME.
 *
 * It is a phase in the bar, in bars, advanced once per audio block by 1/bar_blocks of
 * the tempo in force. Nothing else here has a clock of its own: the lead's grid, the
 * drum's figure, the arp's phrase and the synced delay all read this one number, so
 * there is no second phase for any of them to drift against.
 *
 * WHY A PHASE AND NOT A STEP COUNTER. The old sequencer counted whole blocks down to
 * the end of its current step and measured the next step from the tempo at its start.
 * Each generator did that on its own index, so a generator whose step did not move —
 * the lead's grid while the arp played it — stopped advancing its phase, and anything
 * comparing phases (the RESET counter) compared against a frozen head. A position
 * that moves while the transport runs cannot freeze behind a generator, and an index
 * derived from it cannot disagree with another index derived from it.
 *
 * WHY double. The increment is 1/375 of a bar at 120 BPM and the position is added to
 * once per block, 187.5 times a second: a float would exhaust its 24-bit mantissa in
 * minutes of playing, a double keeps the error far below one block for years. The
 * desktop check runs a million blocks and compares the phase with the exact count.
 *
 * WRAPPING is a subtraction of one bar, not a reset: the transport keeps the fractional
 * part, so the first block of a bar is a block boundary and a phrase that spans several
 * bars (the dotted arp divisions) counts them from s_tp_bar. The residual after the
 * subtraction is one rounding step of the sum, far below a block.
 *
 * THE WRAP TEST HAS A GUARD, and it is not cosmetic. Adding 1/bar `bar` times in binary
 * lands a step or two BELOW 1.0 for half of the bar lengths (152, 153, 156, 180, 250,
 * ...): without the guard those bars would be one block long and the phase would start
 * the next bar at one increment instead of zero, so every such bar would add a block —
 * the instrument would run slow and a step would sit on the bar line it does not belong
 * to. The guard is a billionth of a bar; the smallest gap between the phase and 1.0 one
 * block before the wrap is 1/1500, a million times larger, so it can only turn a wrap
 * that is already due into a wrap.
 */
#define TP_INDEX_GUARD 1e-9   /* one billionth of a step; a block is at least 1/150 of a bar */
#define TP_WRAP_GUARD  1e-9   /* one billionth of a bar; the nearest real approach is 1/1500 */

static double   s_tp_phase;   /* position inside the bar, 0..1 */
static uint64_t s_tp_bar;     /* whole bars since START */

static void tp_restart(void)
{
    s_tp_phase = 0.0;
    s_tp_bar = 0;
}

/*
 * One block of musical time.
 *
 * The position moves while the transport runs. THE ONE THING THAT MOVES IT WHILE STOPPED
 * is the arp over the player's held keys: a key is the player's hand rather than the
 * machine's clock, so the chord keeps arpeggiating on STOP (see arp_tick), and a phase
 * that froze would freeze the figure with it. That is the same exception the instrument
 * has always had; it advances the one position, and nothing else reads it while the
 * transport is stopped — the lead and the drum are silent behind the closed gate.
 */
static void tp_advance(void)
{
    const bool hand = arp_active() && midi_note_active();

    if (!s_running && !hand) {
        return;
    }

    const uint32_t bar = bar_blocks_now();

    s_tp_phase += 1.0 / (double)bar;
    if (s_tp_phase >= 1.0 - TP_WRAP_GUARD) {
        s_tp_phase -= 1.0;
        if (s_tp_phase < 0.0) {
            s_tp_phase = 0.0;
        }
        s_tp_bar++;
    }
}

/*
 * The step of a one-bar figure that this block is in.
 *
 * floor(phase * steps): the step changes in the block where the product crosses a whole
 * number, which is exactly the block the old distribution called the start of the step.
 * The guard is for a boundary that is exact in the arithmetic and lands one rounding
 * step under it in binary — the phase product is at least one block (0.02 step at the
 * widest grid and the fastest tempo) away from a boundary in every other block, so the
 * guard can only move a step that is already due.
 */
static uint32_t tp_index(uint32_t steps)
{
    if (steps == 0u) {
        return 0u;
    }

    const uint32_t i = (uint32_t)(s_tp_phase * (double)steps + TP_INDEX_GUARD);
    return (i < steps) ? i : (steps - 1u);
}

/* The same, for a figure whose phrase spans `bars` bars: its phase is the position
 * inside that many bars, and its index is that phase times its own number of steps. */
static uint32_t tp_phrase_index(uint32_t steps, uint32_t bars)
{
    if (steps == 0u || bars == 0u) {
        return 0u;
    }

    const uint64_t bar = s_tp_bar % (uint64_t)bars;
    const double pos = ((double)bar + s_tp_phase) * (double)steps / (double)bars;

    const uint32_t i = (uint32_t)(pos + TP_INDEX_GUARD);
    return (i < steps) ? i : (steps - 1u);
}

/*
 * One step of a phrase of `steps` that spans `total` blocks: the distance between the
 * block boundaries ceil(total*i/steps) and ceil(total*(i+1)/steps). This is the same
 * remainder-spreading rule as before, written from the phase's side: the block b is in
 * step floor(b*steps/total), so step i begins at the first block whose phase has
 * reached i/steps — ceil(total*i/steps) — and the phrase still adds up to `total`
 * exactly rather than to steps * floor(total/steps).
 *
 * IT IS NO LONGER A SOURCE OF PHASE. The generators take their position from tp_phase()
 * and ask this only for the length of a step: the gate is a fraction of it, and the
 * display draws it. A tempo change therefore moves the boundaries through the phase
 * itself, and this function never decides when a step begins.
 *
 * The floor is a refusal to make a step shorter than SEQ_MIN_STEP_BLOCKS. At the
 * tempos the instrument is played at (up to 300 BPM, 16 steps) it never binds; where
 * it does the phrase is longer than the bar, and that is exactly what the desktop
 * check reports rather than hiding.
 */
static uint32_t phrase_step_blocks(uint32_t total, uint32_t steps, uint32_t index)
{
    if (steps == 0u) {
        return total;
    }

    const uint32_t i = index % steps;
    const uint32_t a = (uint32_t)(((uint64_t)total * (uint64_t)i + steps - 1u) / steps);
    const uint32_t b = (uint32_t)(((uint64_t)total * (uint64_t)(i + 1u) + steps - 1u) / steps);

    uint32_t len = b - a;
    if (len < SEQ_MIN_STEP_BLOCKS) {
        len = SEQ_MIN_STEP_BLOCKS;
    }
    return len;
}

/*
 * How many arp steps make a whole number of bars: the smallest m for which m times the
 * division is a whole number of bars. A sixteenth, an eighth, a quarter, a half, a whole
 * and the eighth triplet all tile one bar; the entries that do not (the dotted notes and
 * the three-beat division) need three bars — twelve beats — before the count is whole.
 * The loop is over small integers and the table is exact enough in float to stop on the
 * first one.
 */
static uint32_t arp_phrase_steps(int idx, uint32_t *bars)
{
    const float div = ARP_DIV_BEATS[idx];

    for (uint32_t m = 1u; m <= 64u; m++) {
        const float b = (float)m * div * 0.25f;
        const uint32_t whole = (uint32_t)(b + 0.5f);
        if (fabsf(b - (float)whole) < 0.0005f) {
            *bars = whole;
            return m;
        }
    }

    *bars = 1u;
    return 1u;
}

/* One arp step, in whole blocks: the phrase spans `bars` bars and holds `steps` steps,
 * and the step's own index places it in that span. The gate is a fraction of this. */
static uint32_t arp_step_blocks(uint32_t bars, uint32_t steps, uint32_t index)
{
    return phrase_step_blocks(bars * bar_blocks_now(), steps, index);
}

/*
 * Where a step stands in a figure of n notes, for the directions that have an order.
 *
 * ONE SWITCH FOR TWO FIGURES, because the directions are the same idea in both: the
 * arp walks its own staircase of LEN notes here, and while the player is holding
 * keys it walks the held chord the same way — see arp_held_step(). Every formula
 * below is in terms of n and of nothing else, which is exactly what lets a chord be
 * walked by it: the caller says how many notes the thing it is walking has.
 */
static int arp_pos_for(uint32_t step, int n)
{
    int pos;
    switch (arp_dir()) {
    case ARP_DIR_DOWN:
        pos = n - 1 - (int)(step % (uint32_t)n);
        break;
    case ARP_DIR_UPDOWN: {
        const uint32_t cycle = (n > 1) ? (uint32_t)(2 * n - 2) : 1u;
        const uint32_t k = step % cycle;
        pos = (k < (uint32_t)n) ? (int)k : (int)(cycle - k);
        break;
    }
    case ARP_DIR_DOWNUP: {
        /* The same staircase walked downwards first. It is the mirror of UPDOWN, and the
         * cycle is the same 2n - 2: the ends are visited once per turn. */
        const uint32_t cycle = (n > 1) ? (uint32_t)(2 * n - 2) : 1u;
        const uint32_t k = step % cycle;
        pos = (k < (uint32_t)n) ? (n - 1 - (int)k) : (int)(k - (uint32_t)(n - 1));
        break;
    }
    case ARP_DIR_UPDOWN_INC: {
        /* Inclusive: the top and the bottom are each held for two steps, so the cycle is
         * 2n rather than 2n - 2. The note after the top is the tail that mirrors it. */
        const uint32_t cycle = (uint32_t)(2 * n);
        const uint32_t k = step % cycle;
        pos = (k < (uint32_t)n) ? (int)k : (int)(cycle - 1u - k);
        break;
    }
    case ARP_DIR_DOWNUP_INC: {
        const uint32_t cycle = (uint32_t)(2 * n);
        const uint32_t k = step % cycle;
        pos = (k < (uint32_t)n) ? (n - 1 - (int)k) : (int)(k - (uint32_t)n);
        break;
    }
    case ARP_DIR_RANDOM:
        pos = (int)(seq_rand() % (uint32_t)n);
        break;
    case ARP_DIR_UP:
    default:
        pos = (int)(step % (uint32_t)n);
        break;
    }
    return pos;
}

/*
 * The note at a given place in the figure.
 *
 * Deterministic on purpose: the same place is the same note every time round, which
 * is what makes an arpeggio recognisable AS an arpeggio rather than as a
 * sequence. RANDOM is deterministic too — a hash of the step, not a running
 * stream — so a random figure repeats instead of wandering, and a knob left alone
 * gives a phrase rather than a different phrase every bar.
 */
static float arp_hz_for(uint32_t step)
{
    const seq_scale_cfg_t *sc = seq_scale();
    const int len = sc->len;
    const int n = arp_len();

    int lo, hi;
    arp_range_ends(&lo, &hi);

    const int pos = arp_pos_for(step, n);

    /*
     * LEN notes from the bottom of the range to the top of it. One note has nothing to
     * climb, so it stays where the range begins; otherwise the figure is spread across the
     * whole span, which is what makes RANGE audible as a distance the line travels rather
     * than as a licence to wander.
     *
     * The distance is counted in SCALE STEPS from the tonic up. The bottom end is zero now
     * that the range carries no sign, so the floor split below is kept for the arithmetic's own
     * sake rather than because a negative degree can arrive.
     */
    const int total = (hi - lo) * len;
    const int off = (n > 1) ? (pos * total) / (n - 1) : 0;
    const int degree = lo * len + off;

    int octave = degree / len;
    int d = degree % len;
    if (d < 0) {
        d += len;
        octave -= 1;
    }

    const int semis = sc->steps[d] + 12 * octave;
    return midi_to_hz(seq_root_midi() + semis);
}

/*
 * THE FIGURE WHEN THE PLAYER IS HOLDING KEYS, and the whole of what the arp does
 * differently then.
 *
 * The keys that are down ARE the figure. They are put into PITCH order first,
 * because that is what the directions mean: up is up the keyboard, not up the order
 * the keys happened to be pressed in. Then the SAME arp_pos_for() walks them — LEN
 * still says how many steps it takes to get across, and RANGE still adds its
 * octaves — so the only thing that changes is what the staircase is made of: the
 * held chord instead of the scale. That is the whole design of this function, and it
 * is why it is a sibling of arp_hz_for() rather than a mode inside it.
 *
 * THE LADDER IS (hi - lo + 1) COPIES OF THE CHORD, an octave apart, and the figure
 * starts at the bottom of the lowest copy and stands, after LEN steps, on the bottom
 * note of the top one. The scale figure has exactly the same shape — it too ends on
 * the tonic of its topmost octave and never on its last degree — so RANGE means one
 * thing in both figures rather than two.
 *
 * RANDOM IS THE ONE DIRECTION THAT DOES NOT WALK THE LADDER, and the reason is LEN:
 * it says how many notes a rise is made of, and a random pick has no rise to shape.
 * What it chooses among is what RANGE offers — every held key in every octave the
 * range spans — which is the only reading of "random from the held keys" that leaves
 * the RANGE knob meaning something.
 *
 * The velocity comes back with the note, from the byte the key was recorded with:
 * a step is that key's note and it arrives at the level the key was struck at. The
 * return value says which figure was played — false is "nothing is held", and in
 * that case not one line below has run, not even the sort.
 */
typedef struct {
    uint8_t note;
    uint8_t vel;
} arp_key_t;

/* The chord, sorted, and only while it exists: sixteen keys of two bytes each, static,
 * and read by nothing but the function below. */
static arp_key_t s_arp_key[MIDI_HELD_MAX];

static bool arp_held_step(uint32_t step, float *hz, float *vel)
{
    const int n = s_midi_held_n;
    if (n <= 0) {
        return false;
    }

    /* Insertion sort, and at this size it is the right one: sixteen keys is at most
     * 120 comparisons, once per arp STEP rather than once per block (the step can be a
     * thirty-second), and it needs no second buffer and no allocation. */
    for (int i = 0; i < n; i++) {
        const arp_key_t k = { s_midi_held_note[i], s_midi_held_vel[i] };
        int j = i;
        while (j > 0 && s_arp_key[j - 1].note > k.note) {
            s_arp_key[j] = s_arp_key[j - 1];
            j--;
        }
        s_arp_key[j] = k;
    }

    int lo, hi;
    arp_range_ends(&lo, &hi);

    const int fig = arp_len();
    const int span = (hi - lo) * n;       /* the bottom of the range to the top of it */
    const int ladder = n * (hi - lo + 1); /* every octave copy the range offers */

    int q;
    if (arp_dir() == ARP_DIR_RANDOM) {
        q = arp_pos_for(step, ladder);
    } else {
        const int pos = arp_pos_for(step, fig);
        q = (fig > 1) ? (pos * span) / (fig - 1) : 0;
    }

    /* The octave first and the key inside it second: RANGE is a transposition of the
     * whole chord, and a note is never mistaken for a neighbour in another octave. */
    const int octave = lo + q / n;
    const int key = q % n;

    *hz = midi_to_hz(seq_scale_note((int)s_arp_key[key].note) + 12 * octave);
    *vel = (float)s_arp_key[key].vel / 127.0f;
    return true;
}

/*
 * The arp's step as the transport alone puts it: the phrase number times that phrase's
 * length, plus the step inside the phrase. This is the number the gesture re-anchors,
 * so it is a function of the position and of nothing else.
 */
static uint64_t arp_raw_step(void)
{
    uint32_t bars = 1u;
    const uint32_t steps = arp_phrase_steps(arp_speed_index(), &bars);

    if (steps == 0u) {
        return 0u;
    }
    const uint32_t local = tp_phrase_index(steps, bars);
    return (s_tp_bar / (uint64_t)bars) * (uint64_t)steps + (uint64_t)local;
}

/*
 * One block of arp time.
 *
 * The gate is the sequencer's own, deliberately: the generator plays one note at a
 * time, and two independent gates would fight over it the moment the arp was
 * switched on mid-phrase. That stays true with keys held even though the arp then
 * plays in a group of its own — the gate is a counter and a release, and the note it
 * releases is named by whoever is playing it: see the expiry in seq_tick().
 */
/*
 * The level the arp's figure is struck at: the lead's accent figure, read at the position in
 * the bar this step stands on.
 *
 * tp_index() is the grid position of the moment, and the grid is the lead's own n — the same
 * number the ring of dots is drawn against, so what the player sees marked is what the figure
 * plays quietly. The guard for n <= 0 is for the block before the first latch: a grid of no
 * steps has no accented positions, and the answer there is the full level rather than a
 * division by zero.
 */
static float arp_velocity(void)
{
    if (s_seq_n <= 0) {
        return 1.0f;
    }
    return figure_velocity_for(accent_index_arp(), tp_index((uint32_t)s_seq_n), s_seq_n);
}

static void arp_tick(void)
{
    /*
     * WHERE THE FIGURE STANDS, from the transport and nothing else.
     *
     * The step is the phrase's index at this position. There is deliberately no restart
     * on a change of DIR or SPEED any more: a restart would be a second phase, and the
     * whole point of the transport is that a figure has one position. Turning the knob
     * therefore changes the shape the SAME position is read in — the figure continues
     * where the bar is, exactly like a hardware arpeggiator locked to the transport.
     *
     * RANGE and LEN keep the gesture they always had: the figure is deterministic on the
     * absolute step number, so turning either of them moves the note the figure is
     * standing on and the line stumbles and lands inside its new shape. That was heard,
     * reported, explained and kept on purpose.
     *
     * The phrase's length is the smallest whole number of bars its division tiles
     * (arp_phrase_steps), and tp_phrase_index() reads the position inside that many bars.
     * THE STEP NUMBER IS ABSOLUTE, counted from the phrase the transport is in: a
     * phrase of four bars whose division is a whole note has ONE step, so its local
     * index is 0 for four bars and only the phrase number can say that a new step has
     * begun. `phrase * steps + local` is that number; it changes by one at every step
     * including the one across a phrase boundary. s_arp_origin is subtracted from it:
     * START and the lead's RESET gesture move the origin, and only they, so the figure
     * begins on its first note exactly when the lead's phrase does.
     */
    const int speed_now = arp_speed_index();
    if (speed_now != s_arp_speed_seen) {
        /* The first observation is the state the instrument booted with and is not a change:
         * the figure is already walking, and re-anchoring it here would restart the line every
         * time the arp is switched on. */
        if (s_arp_speed_seen >= 0) {
            s_arp_realign = true;
            s_arp_tp_bar_seen = s_tp_bar;
        }
        s_arp_speed_seen = speed_now;
    }

    uint32_t bars = 1u;
    const uint32_t steps = arp_phrase_steps(speed_now, &bars);

    if (steps == 0u) {
        return;
    }

    const uint32_t local = tp_phrase_index(steps, bars);

    /*
     * The bar line after the knob moved, and the figure starts there. The bar is COMPARED and
     * not counted down: a block that arrives after the line still sees s_tp_bar moved, anchors
     * on it, and does not wait for the next bar.
     */
    if (s_arp_realign && s_tp_bar != s_arp_tp_bar_seen) {
        s_arp_origin = arp_raw_step();
        s_arp_prev = ~(uint64_t)0;
        s_arp_realign = false;
    }

    const uint64_t step = arp_raw_step() - s_arp_origin;

    if (step == s_arp_prev) {
        return;
    }
    s_arp_prev = step;

    const uint32_t step_blocks = arp_step_blocks(bars, steps, local);
    if (step_blocks == 0u) {
        return;
    }

    /*
     * WHICH NOTES, AND IN WHOSE GROUP.
     *
     * A key that is down is a note the arp may play, and while any key is down the
     * figure is made of them and of nothing else: see arp_held_step(), which also
     * brings back the velocity of the key each step lands on. With no key held the
     * line is the scale figure it has always been, at 1.0.
     *
     * THE ACCENT REACHES THE FIGURE, AND IT IS READ WHERE THE STEP LANDS.
     *
     * The accent is drawn as a set of marks on the lead's Euclidean grid, which is a set of
     * positions in a BAR; the arp is not a bar but a figure stepping at a division of the beat.
     * The two meet at exactly one place, and it is the only place they need to: the arp step
     * happens at a POSITION IN THE BAR, and the accent figure has an answer for every position
     * in the bar. So the note is struck at the velocity the grid's own marks give for the
     * position its step falls on — see arp_velocity() — and the ring of dots under the ARP IS
     * ACTIVE notice is the picture of exactly that: the marks the figure is reading.
     *
     * The rate does not matter to this. A step at 1/16 lands on a sixteenth position, a step at
     * 4/1 lands on the first position of its bar, and both are answered by the same figure; an
     * accented position and a weak one are the same difference in level whatever the division.
     *
     * A HELD KEY'S VELOCITY IS THE LEVEL, AND THE FIGURE IS THE EMPHASIS, and the two MULTIPLY.
     *
     * The key's velocity is the note's own level, the one the hand asked for when it pressed
     * the key, and it is kept. The figure then says which of the notes the figure lands on are
     * struck at that level and which at the weak one — the same figure_velocity_for() the
     * sequencer reads, at the same position in the bar.
     *
     * IT USED TO LET THE KEYS WIN OUTRIGHT, on the argument that a played chord carries its
     * own dynamics. That is true of a human playing chords and false of an arpeggiator, which
     * is what this is: the figure is the rhythm and the player holds one chord, so every note
     * came out at the same level and the accent sector did nothing once a key was down. The
     * owner heard exactly that — "не вижу акцентов в арпе". The key still sets the level, so
     * a soft chord stays soft and a hard one stays hard; the figure now moves inside that.
     *
     * The figure is the LEAD's, chosen on LEAD EUCLID with its ACCENT sector, and it is read
     * at the position in the bar the step falls on, so the same marks the ring of dots shows
     * are the marks the chord is struck with.
     *
     * THE STEP IS TAKEN WHETHER OR NOT THE NOTE IS SOUNDED. While the transport runs the
     * phase moves, so the step is taken and the gate below is scheduled exactly as it
     * always is; STOP freezes the position (tp_advance) and the figure simply stands
     * where it stood. Letting go of the transport therefore moves nothing.
     *
     * TWO GROUPS, AND NEVER THE SAME ONE. With keys held the step is played in
     * LEAD_ARP_GROUP, which the player's key allocator cannot reach and which no key from
     * the wire enters while the arp is on — the arp has the lead then, see
     * arp_lead_tick() — so the step can neither retrigger, steal nor release anything a
     * hand owns. With no key held the step is the generator's own note in the generator's
     * group, exactly as before. The two cases are one branch apart on purpose: they can
     * never both be taken.
     *
     * A HELD KEY STEPS WITH THE TRANSPORT OR WITHOUT IT, and that is the one thing the arp
     * does not take from STOP. The keys are the player's HAND, not the machine's clock:
     * the chord under the fingers keeps arpeggiating while the machine is stopped, and the
     * output gate is already open for it because a key is down — see midi_gate_tick(), and
     * midi_note_active() for why that test is the one the gate wants. tp_advance() moves
     * the one position while the transport is stopped for exactly this case, and nothing
     * else reads it then: the figure the arp plays ON ITS OWN — the scale staircase, which
     * has no hand behind it — opens no note while the transport is stopped, and the
     * sequencer and the drum strike nothing either.
     *
     * THAT TEST IS ALSO WHY THE BRANCH BELOW IS ONE COMPARISON. held is true exactly when a
     * key is down — arp_held_step() returns false for an empty list and nothing else — so
     * "the arp has a chord to walk" and "an external note is active" are the same question,
     * answered once, and the generator's figure still steps aside for the player's keys.
     */
    float hz = 0.0f;
    float vel = 1.0f;
    const bool held = arp_held_step((uint32_t)step, &hz, &vel);
    if (!held) {
        hz = arp_hz_for((uint32_t)step);
    }

    float gate = s_param[SYNTH_PARAM_SEQ_GATE];
    if (gate < 0.05f) {
        gate = 0.05f;
    } else if (gate > 0.95f) {
        gate = 0.95f;
    }

    uint32_t gate_blocks = (uint32_t)((float)step_blocks * gate + 0.5f);
    if (gate_blocks < 1u) {
        gate_blocks = 1u;
    }
    if (gate_blocks > step_blocks) {
        gate_blocks = step_blocks;
    }

    /* The gate is decided BEFORE the note is opened: the generator's note carries its
     * own gate now, and it cannot be told how long it is after the fact. */
    if (held) {
        lead_group_claim(LEAD_ARP_GROUP, LEAD_NOTE_ARP);
        lead_group_on(LEAD_ARP_GROUP, hz, vel * arp_velocity());
    } else if (s_running) {
        lead_note_on(hz, arp_velocity(), gate_blocks);
    }

    s_seq_gate_left = gate_blocks;
}

/*
 * THE ARP'S CLAIM ON THE LEAD, and what taking it and giving it back do to the voices.
 *
 * While the arp is on and a key is down the keys ARE the figure, so the wire's input
 * opens no group at all (see midi_note_pressed()) and the only note the lead has is the
 * arp's own. That much is a test at each key. What is left is the SWITCH: DIR can be
 * turned to OFF and back with a chord held, and neither side of that change may keep a
 * voice the other owns — an arp note left open has no gate to close it once the arp
 * stops stepping, and a chord left open has nothing to release it once the arp has the
 * lead.
 *
 * READ HERE, once per block on the audio task, rather than at the control: DIR is a
 * parameter like any other and the audio task is the only side that may touch a voice —
 * the same reason every parameter applier lives on this side of the seam.
 *
 * ON: the player's groups go, group 0 included, because group 0 is also where the arp
 * itself plays its scale figure — with no keys held the arp sounds there, and that note
 * is not the chord, so it is released here and the arp moves its next step to
 * LEAD_ARP_GROUP. The arp's own group is deliberately NOT touched: it is where the arp
 * is playing, and a step already open there is what the switch is meant to keep. No key
 * leaves the held list, which is the whole of what the arp reads to build its chord.
 *
 * OFF: the arp's own group goes through lead_group_off(), so its voices get the release
 * their envelope was configured with — and that release is audible because the last
 * key's release has armed the output gate's tail, see midi_note_released(). Then the keys
 * are the player's again: the NEWEST LEAD_GROUPS of them are opened in press order, which
 * is the chord the player's allocator would be holding, since it steals from the oldest.
 * Opening them here rather than waiting for the next key is what makes DIR a switch the
 * player can hear: the chord under the fingers comes back on the block it happens and no
 * key has to be pressed again.
 *
 * THE SLICE IS WHY THIS LOOP CANNOT STEAL. At most LEAD_GROUPS keys are handed back, and
 * only the ones that own no group already (the block the switch happens in may have
 * delivered a key before the switch was read, and that key is the player's already), so
 * every call gets a free group and the allocator's victim branch never runs: the held list
 * cannot change under the loop.
 */
static bool s_arp_over_input;

static void arp_lead_tick(void)
{
    const bool over = arp_active() && midi_note_active();

    if (over == s_arp_over_input) {
        return;
    }
    s_arp_over_input = over;

    if (over) {
        for (int g = 0; g < LEAD_GROUPS; g++) {
            if (s_lead_note[g] != LEAD_NOTE_FREE) {
                lead_group_off(g);
            }
        }
        return;
    }

    lead_arp_group_off();

    const int n = s_midi_held_n;
    const int first = (n > LEAD_GROUPS) ? (n - LEAD_GROUPS) : 0;

    for (int i = first; i < n; i++) {
        const int note = (int)s_midi_held_note[i];

        if (lead_group_owning(note) >= 0) {
            continue;
        }
        midi_key_play(note, (int)s_midi_held_vel[i]);
    }
}

/*
 * Pick the next note and play it.
 *
 * THIS IS WHERE THE GENERATIVE PART LIVES. The sequencer around it neither knows
 * nor cares how the degree was chosen.
 *
 * Two decisions, deliberately separated:
 *
 *   the TABLE decides WHICH note, and carries all the musical judgement;
 *   the octave rule decides which REGISTER, so the table never has to know that
 *   registers exist.
 *
 * That split is what keeps the table five or seven wide instead of twice that: a
 * listener hears pitch class and register as separate things, and a matrix that
 * had to encode both would have twice the numbers and half the clarity.
 */
static void seq_trigger(uint32_t gate_blocks)
{
    const seq_scale_cfg_t *sc = seq_scale();
    const int len = sc->len;

    /*
     * Сколько октав обходит линия — SPAN, и это единственное его чтение. Одна октава,
     * две или три, по детенту на каждую. Обход всё ещё СЧИТАЕТСЯ в степенях: позиция в
     * таблице идёт 0..len-1, а регистр — целая часть от деления на len, поэтому таблице
     * по-прежнему не нужно знать, что регистры существуют (см. шапку этой функции).
     */
    int octaves = (int)(clamp01f(s_param[SYNTH_PARAM_GEN_SPAN]) * 2.0f + 0.5f) + 1;
    if (octaves < 1) {
        octaves = 1;
    } else if (octaves > 3) {
        octaves = 3;
    }
    const int span = len * octaves;

    /* The scale is a control, so it can change under a line that is already
     * playing — and the position has to be brought back inside the new range
     * before it is used as an index. */
    if (s_seq_degree >= span) {
        s_seq_degree = span - 1;
    }
    if (s_seq_degree < 0) {
        s_seq_degree = 0;
    }

    const int from = s_seq_degree % len;
    const uint8_t *row = sc->markov + from * len;

    uint32_t total = 0;
    for (int i = 0; i < len; i++) {
        total += row[i];
    }

    /* Walk the row like a cumulative distribution. Weighted choice, not a
     * transformation of the random number: any other scheme would make the
     * weights mean something no one could predict from reading them. */
    uint32_t pick = seq_rand() % total;
    int to = 0;
    for (int i = 0; i < len; i++) {
        if (pick < row[i]) {
            to = i;
            break;
        }
        pick -= row[i];
    }

    /*
     * Two registers can hold the chosen degree, and to + len is always inside
     * the span because the span is exactly two octaves. The nearer register is
     * the default, which bounds the line automatically: it cannot wander off the
     * top of the instrument and never dives an octave for no reason.
     *
     * OCTAVE buys the far one a chance. At zero the register is a pure
     * consequence of the melody, which is how the line was voiced; at the top it
     * is a coin toss, which is what opens the line out of a single register.
     */
    int best = to;
    if (to + len < span) {
        const float near_dist = fabsf((float)(to - s_seq_degree));
        const float far_dist = fabsf((float)(to + len - s_seq_degree));
        const float chance = (float)(seq_rand() & 0xFFFFu) / 65536.0f;
        if (far_dist < near_dist || chance < s_param[SYNTH_PARAM_OCTAVE] * 0.5f) {
            best = to + len;
        }
    }

    s_seq_degree = best;

    const int degree = s_seq_degree % len;
    const int octave = s_seq_degree / len;
    const float hz = midi_to_hz(seq_root_midi()
                                + octave * 12 + sc->steps[degree]);

    /*
     * The note's velocity, from the same figure and the same rule the drum's hits are
     * given: the position the note is played FOR — s_seq_fire_index, which is one step
     * AHEAD of the current one when SCATTER has pulled the next onset forward into this
     * step — against the n latched with it in seq_tick(). The arpeggiator, which can have
     * this grid instead, does not come through here; see arp_tick().
     *
     * The note is opened only when the lead is not someone else's. The walk ABOVE has
     * already happened, and that is the point of putting the test here rather than at the
     * top of seq_fire(): the generator keeps its place in the melody while an external note
     * sounds, so the line resumes the phrase it would have played instead of starting
     * again or standing still. The gate seq_fire() is about to set is set either way, and
     * the expiry of that gate is guarded as well — see seq_tick().
     *
     * s_running IS THE OTHER HALF OF IT, and for the reason arp_tick() gives: STOP no
     * longer closes the output on its own, so a stopped sequencer has to decline to open a
     * note rather than let the stopped transport be heard through a gate that an external
     * note has opened.
     */
    if (s_running && !midi_note_active()) {
        lead_note_on(hz, figure_velocity_for(accent_index_seq(), s_seq_fire_index, s_seq_n),
                     gate_blocks);
    }
}

/*
 * One block of sequencer time.
 *
 * A step is a whole number of blocks, and the bar's remainder is spread over the
 * steps that follow it, so the phrase stays exact rather than accumulating: the
 * per-step error never grows past one block, and the phrase never drifts at all.
 * That is the whole reason the clock is here and not on a timer.
 */
/*
 * Is there an onset at this grid position?
 *
 * The Euclidean rhythm, in one line of arithmetic rather than in a table: an
 * onset falls wherever the running count of pulses advances. What comes out is
 * the maximally even placement of k onsets across n steps — .x..x..x is not a
 * random rhythm, it is the only way to put three beats in eight steps without
 * clustering them, and that unequal spacing is exactly what the ear hears as a
 * groove instead of as a metronome.
 *
 * Position 0 needs the special case, and it is not cosmetic. The running count
 * before the pattern starts is EMPTY, not the count at n-1; without the case,
 * k = 1 would compare the single pulse against itself and produce no onsets at
 * all.
 */
static bool seq_is_onset(uint32_t grid_index, int n, int k, int rotate)
{
    const uint32_t un = (uint32_t)n;
    const uint32_t p = (grid_index + (uint32_t)rotate) % un;

    if (p == 0u) {
        return true;
    }

    const uint32_t prev = p - 1u;
    return (p * (uint32_t)k) / un != (prev * (uint32_t)k) / un;
}

/* Distance in grid steps to the next onset, scanning at most one full bar. */
static uint32_t seq_gap_steps(uint32_t grid_index, int n, int k, int rotate)
{
    for (uint32_t d = 1; d <= (uint32_t)n; d++) {
        if (seq_is_onset(grid_index + d, n, k, rotate)) {
            return d;
        }
    }
    return (uint32_t)n;
}

/*
 * A displacement in -1..+1 for a given grid position, derived from the position
 * itself rather than from a running stream of random numbers.
 *
 * That is deliberate, and it is what lets the spread push a note EARLY as well
 * as late. A note displaced early belongs before its grid line, which is still
 * inside the step that came before it — so the sequencer has to know where the
 * next onset will land before that step arrives. A running stream cannot be
 * asked about the future; a hash can.
 *
 * The second effect matters as much: the same onset lands in the same place
 * every bar, so the spread is a FEEL rather than a different rhythm each time.
 * The Euclidean figure stays recognisable, which is the whole reason for using
 * one.
 */
static float seq_jitter(uint32_t grid_index, uint32_t salt)
{
    uint32_t h = (grid_index + 1u) * 2654435761u + salt;
    h ^= h >> 15;
    h *= 2246822519u;
    h ^= h >> 13;
    return (float)(int16_t)(h >> 16) * (1.0f / 32768.0f);
}

static int seq_steps_for(float v01)
{
    int n = SEQ_STEPS_MIN + (int)(v01 * (float)(SEQ_STEPS_MAX - SEQ_STEPS_MIN) + 0.5f);
    if (n < SEQ_STEPS_MIN) {
        n = SEQ_STEPS_MIN;
    } else if (n > SEQ_STEPS_MAX) {
        n = SEQ_STEPS_MAX;
    }
    return n;
}

/*
 * The k of E(k,n): a count WITHIN the grid, so it is asked for as a fraction of the
 * grid's own length and never of the widest grid there is.
 *
 * Bounded by n and not by sixteen. With the old mapping the knob kept travelling past
 * the grid's end: STEPS 10 showed "10/10" at two thirds of the travel and the rest of
 * the turn did nothing visible, so the wheel had a dead zone and coming back off it
 * took six detents before the number moved again. Here the last position of the knob
 * IS the last pulse the figure can hold.
 */
static int seq_pulses_for(float v01, int n)
{
    int k = 1 + (int)(v01 * (float)(n - 1) + 0.5f);
    if (k < 1) {
        k = 1;
    } else if (k > n) {
        k = n;
    }
    return k;
}

/* The phase of the figure, in steps of its own grid: n positions, one detent each. */
static int seq_rotate_for(float v01, int n)
{
    int r = (int)(v01 * (float)(n - 1) + 0.5f);
    if (r < 0) {
        r = 0;
    } else if (r > n - 1) {
        r = n - 1;
    }
    return r;
}

/*
 * The figure's own numbers, all three of them read against the grid they belong to: k cannot
 * be more than n, and the phase cannot be more than n-1 steps. Nothing is saturated here — the
 * mappings themselves end where the grid ends — so what the readout says is what the knob does.
 */
static int seq_pulses(void)
{
    return seq_pulses_for(s_param[SYNTH_PARAM_SEQ_PULSES], seq_steps_for(s_param[SYNTH_PARAM_SEQ_STEPS]));
}

static int seq_rotate(void)
{
    return seq_rotate_for(s_param[SYNTH_PARAM_SEQ_ROTATE],
                          seq_steps_for(s_param[SYNTH_PARAM_SEQ_STEPS]));
}

/* The note itself, fired when its scheduled block arrives. */
static void seq_fire(void)
{
    /*
     * DENSITY is a second layer of rests, and it is not the same control as
     * PULSES: PULSES moves the onsets, DENSITY only removes some of them. Either
     * way the pattern keeps its shape, which is what lets the same Euclidean
     * figure be heard sparse or full.
     */
    const float roll = (float)(seq_rand() & 0xFFFFu) / 65536.0f;
    if (roll >= s_param[SYNTH_PARAM_DENSITY]) {
        return;
    }

    /*
     * The gate is a fraction of the distance to the NEXT onset rather than of a
     * fixed grid step. That is what lets a sparse pattern hold long notes: in
     * .x..x..x the gaps are three, three and two steps, so a note can fill the
     * space it actually has instead of being capped at a step that is not there.
     * The space is summed step by step because the steps are no longer all the same
     * length: a phrase gives its remainder to some of them, and a gate that used one
     * step's length for the whole gap would end past the next onset by the blocks the
     * distribution added.
     */
    const uint32_t gap = seq_gap_steps(s_seq_fire_index, s_seq_n, s_seq_k, s_seq_rot);
    uint32_t space = 0;
    for (uint32_t i = 0; i < gap; i++) {
        space += phrase_step_blocks(bar_blocks_now(), (uint32_t)s_seq_n,
                                    s_seq_fire_raw + i);
    }

    float gate = s_param[SYNTH_PARAM_SEQ_GATE];
    /* The length wanders by the same scatter as the timing, which is what makes
     * a long note and a short one come out of one setting. */
    gate *= 1.0f + seq_jitter(s_seq_fire_index, 0x5171u)
                 * s_param[SYNTH_PARAM_SEQ_SCATTER];
    if (gate < 0.05f) {
        gate = 0.05f;
    } else if (gate > 0.95f) {
        gate = 0.95f;
    }

    uint32_t gate_blocks = (uint32_t)((float)space * gate + 0.5f);
    if (gate_blocks < SEQ_MIN_GATE_BLOCKS) {
        gate_blocks = SEQ_MIN_GATE_BLOCKS;
    }
    if (gate_blocks > space) {
        gate_blocks = space;
    }

    seq_trigger(gate_blocks);
#if SEQ_TRACE_ENABLE
    SEQ_TRACE("L block=%" PRIu32 " step=%" PRIu32, s_trace_block, s_seq_fire_index);
#endif
    s_seq_gate_left = gate_blocks;
}

/* -------------------------------------------------------------------------- */
/* Percussion                                                                 */
/* -------------------------------------------------------------------------- */

/*
 * The drum part's own figure, on the sequencer's clock rather than beside it.
 *
 * A step is a bar divided by THIS pattern's length, with the same remainder
 * distribution the lead uses. The two are therefore locked to one tempo and one bar
 * and free to disagree about how the bar is divided — which is what makes three
 * against four a polyrhythm instead of a mistake. Both phrases add up to the bar
 * exactly, so the disagreement is in where the onsets fall, not in a bar that slowly
 * gets shorter.
 *
 * It ticks whether or not the arpeggiator has taken the lead: the percussion is a
 * second player, not an alternative to the first.
 */
/*
 * The drum's position is the transport's, like the lead's: the step is derived from the
 * phase and the only state here is the step the last block stood on, for the onset test
 * and for the display.
 *
 * s_perc_origin is the DRUM'S phrase origin — the counterpart of the lead's s_seq_origin,
 * on the drum's own grid and written only by the drum's own gesture and by START. That
 * they are two variables rather than one is what makes the two RESET gestures independent:
 * see the RESET section below and SYNTH_PARAM_PERC_RESET.
 */
static uint32_t s_perc_index;   /* the phrase step this block is in, for the display */
static uint32_t s_perc_prev = (uint32_t)~0u;  /* the transport step last block; ~0 = none */
static uint64_t s_perc_origin;  /* the grid step the drum's phrase began on */
static uint32_t s_perc_grid;    /* the n that origin was placed on */

/*
 * БАР УДАРКИ — ВСЕГДА ШЕСТНАДЦАТЬ ШАГОВ.
 *
 * Все тридцать три грува написаны на шестнадцати позициях, и перенос на сетку ударки —
 * пропорциональный: позиция local * 16 / n. Любое n, кроме шестнадцати, выбрасывает часть
 * рисунка: при четырёх шагах играют только позиции 0, 4, 8 и 12, то есть из грува выживает
 * четверть, а хэт «на каждом шестнадцатом» становится четырьмя хэтами на бар. Владелец
 * слышал это как «хэты не звучат каждый шаг», и он прав: на сетке из четырёх шагов их и не
 * могло быть.
 *
 * Параметр остаётся в списке (номер в патче никуда не двигается) и читается только
 * отображением — сам бар от него больше не зависит. Шестнадцать не «по умолчанию», а
 * всегда, как у драм-машины: сетка шестнадцатых — это и есть её бар.
 */
static int perc_steps(void)
{
    return 16;
}

static int perc_pulses(void)
{
    return seq_pulses_for(s_param[SYNTH_PARAM_PERC_PULSES], perc_steps());
}

static int perc_rotate(void)
{
    return seq_rotate_for(s_param[SYNTH_PARAM_PERC_ROTATE], perc_steps());
}

/*
 * HOW STRONG A NOTE IS STRUCK, and the whole of the accent rule.
 *
 * The percussion engine has taken a velocity since it was written; until ACCENT existed
 * the application had nothing to say about it and handed over a constant 1.0. The lead's
 * voices are opened with a level of their own — 70, 70 and 55, see s_lead — and the same
 * figure is handed to them as a multiplier at note-on, so one control speaks to both
 * parts and to each in the units its own engine already uses.
 *
 * HOW HARD the onsets the figure does not mark are struck is the WEAK VEL setting,
 * whole numbers 0..127 with 80 out of the factory, and accent_velocity_weak() below is
 * the only place it is read. The marked onsets keep the velocity they have always had —
 * 1.0, the whole of the voice — so the accent is still made by leaving the marked
 * onsets alone and taking the others down, and never by raising one into the limiter.
 *
 * 80 of 127 is the FACTORY VALUE and no longer a constant: 127 is the hit as it has always
 * been and 80 is the weak hit, and the weak half of that is a setting of its own, so that
 * 127 can mean "there is no difference" and 0 can mean "there are no weak hits". See
 * APP_SET_WEAK_VEL in app_settings.h for the three values and for what zero does to each
 * part.
 *
 * For the drum, velocity multiplies the voice once, on both of its paths and nowhere
 * else — see `g` and `gt` in synth_perc.cpp's render loop — so the distance between the
 * two hits is arithmetic and not a measurement: 20*log10(127/80) = 4.01 dB at the
 * factory value. An isolated hit reaches neither the limiter nor the compressor
 * (PERC_PEAK_TARGET 0.7810 stops 0.7 dB under the knee at 0.85), so nothing takes a piece
 * of it back; on a busy pattern the two hits share the limiter's knee and the heard
 * distance is a little smaller than that arithmetic figure — which is why no heard figure
 * is quoted for the setting's own range. The 2.8 dB that used to be quoted here belonged
 * to the old fixed pair of 90, which no longer exists.
 *
 * The accent is made by LEAVING THE MARKED ONSETS ALONE AND TAKING THE OTHERS DOWN,
 * not by raising the accented hit. The median hit is normalised to PERC_PEAK_TARGET
 * and sits 0.7 dB under the limiter's knee — see perc_soft_limit() in synth_perc.cpp
 * — so a hit raised above full would be shaped by the limiter and the accent would
 * become the limiter's answer instead of the player's. The lead's level has no such
 * ceiling, but it is taken down by the same amount for the same reason: what the ear
 * hears is the RATIO between the marked beat and the rest, and one setting makes that
 * ratio the same for both parts.
 */

/*
 * The WEAK VEL setting's range, in the engine's own velocity units, plus the factory
 * value — the same three numbers as the SETTINGS[] row in app_settings.c, written twice
 * because that component cannot include this header: it would be a cycle. Nothing
 * terrible can come of a disagreement, and that is by construction rather than by
 * hope: the row clamps what is stored, and the division below clamps what is read, so a
 * pair of copies that drifted apart could only ever narrow the range — it could not put
 * a velocity outside 0..1 into the engine.
 *
 * 127 is the whole of the engine's velocity: a hit struck at it is a hit struck as loud
 * as its voice goes, which is what "no accent" means. MAX is also the divisor below,
 * because the setting is whole numbers and the engine wants a fraction. STEPS is the
 * count of those whole numbers and is what the knob's own resolution is built from — see
 * synth_app_param_steps().
 */
#define WEAK_VEL_MAX       127
#define WEAK_VEL_STEPS     (WEAK_VEL_MAX + 1)
#define WEAK_VEL_FACTORY   80

/*
 * THE ACCENT RULE ITSELF, and the only place it is written: a step is struck strong
 * when its number in the bar is one the chosen FIGURE marks.
 *
 * The figures are named after what a drummer would call them and each one is a set of
 * numbers in the bar counted from the downbeat, 1-based. Sixteen bits is the whole
 * range: SEQ_STEPS_MAX is 16, so position 16 is the highest number any figure can
 * name and no mask needs more.
 *
 * The numbers are POSITIONS IN THE BAR, not positions in the figure, and both halves
 * of that are deliberate:
 *
 *   they do NOT move with ROTATE. A figure is a rhythm, and a rhythm is anchored to
 *   the beat: QUARTER hits every beat of the bar — 1, 5, 9 and 13, the first of them
 *   the downbeat — whatever ROTATE has done to the Euclidean pattern, so rotating the
 *   figure underneath the accent is how the two are made to disagree on purpose. Carrying the mask around with the pattern would have made
 *   ROTATE move the accent too, which is a second thing to keep track of and the
 *   opposite of the point of naming the figures after their position.
 *
 *   they are NOT scaled to the pattern's length either. A mask on seven steps keeps
 *   whatever of it fits — QUARTER marks 1 and 5 there, because 9 and 13 have left
 *   the bar — rather than being stretched into "the same rhythm with fewer beats".
 *   What falls past n simply does not sound. The alternative, rescaling, would make
 *   the same named figure mean a different rhythm at every STEPS setting, which is
 *   exactly what a NAME cannot survive.
 *
 * So the position is reduced to 1..n first — the step index is the one the transport
 * derives for this bar, 0..n-1, and the mask is a pattern of the bar, so the same
 * positions are marked in every bar — and the reduced number is looked up in the mask.
 * A step past the mask's highest number is simply not marked, which is also what makes
 * an n of 4 or 5 work with a six- or five-number figure.
 */
static const uint16_t ACCENT_MASK[] = {
    /* OFF: a position of its own so that the knob has a bottom, and no bit in the
     * mask, so nothing is accented and every onset keeps the velocity it always had. */
    0x0000u,
    /* QUARTER — a hit on every beat of the bar, the first of them the downbeat:
     * 1, 5, 9, 13. The panel prints the note as "1/4"; see ACCENT_NAME below. */
    0x1111u,
    /* 2&4 — the backbeat, two and four: 5, 13. */
    0x1010u,
    /* OFFBEAT — the off eighths: 3, 7, 11, 15. "OFFB" on the panel. */
    0x4444u,
    /* 3-3-2 — tresillo: 1, 7, 13. */
    0x1041u,
    /* FUNK16 — sixteenth funk accent: 1, 4, 7, 10, 13, 16. "FUNK" on the panel. */
    0x9249u,
    /* RUMBA — rumba clave, first bar: 1, 4, 7. "RMB" on the panel. */
    0x0049u,
    /* BOSSA — bossa nova, first bar: 1, 4, 7, 10, 13. "BOS" on the panel. */
    0x1249u,
};

#define ACCENT_COUNT ((int)(sizeof(ACCENT_MASK) / sizeof(ACCENT_MASK[0])))

/*
 * THE PANEL FORMS OF THE EIGHT FIGURES, and the only place they are written. The list
 * is read by the value line of the ACCENT sector on LEAD EUCLID and PERC SEQ, so the
 * strings are what the instrument shows, not what the code calls the pattern: the mask
 * above keeps the names a drummer uses (QUARTER, OFFBEAT, FUNK16, RUMBA, BOSSA) and this
 * table prints the form a panel prints — "1/4" for the quarter-note accent, "OFFB",
 * "FUNK", "RMB", "BOS".
 *
 * SHORT IS A LAYOUT CONSTRAINT, not a taste. ACCENT is the fourth sector on both figure
 * pages — 126 degrees on the drum's five-sector star and 90 on the lead's six — and the
 * drum's seat is where the dot ring comes closest to a long readout. 46 px of text is what
 * still clears a 16 px dot there by 9.8 px (tools/ring_clearance.py sweeps the cells). "QUARTER", at 84 px in the 20 px face,
 * would overlap the ring by 3.5 px in that seat; "OFFBEAT" was 80 px and would do the same.
 * The short forms — five characters at most — are what lets PERC SEQ stay a five, with the
 * voice's ENV back on PERC and no turned rim to make room for a word.
 *
 * The table is read by tools/ring_clearance.py, which measures every string here and
 * sweeps the widest one in the ACCENT seat: adding a longer form later fails that check
 * instead of quietly putting a dot on top of a letter. Keep the order — it is the mask
 * order, and the value is an index into both tables.
 */
static const char *const ACCENT_NAME[ACCENT_COUNT] = {
    "OFF", "1/4", "2&4", "OFFB", "3-3-2", "FUNK", "RMB", "BOS",
};

/*
 * The chosen figure, as an index into those two tables.
 *
 * Read the way every other list in this file is read: the knob's 0..1 times one less
 * than the count of entries, rounded. Clamped rather than trusted, because a patch or
 * a preset is a stored number and this is the one place it becomes an array index.
 * Zero — a device that has never been touched, and every preset saved before this
 * parameter existed — lands on OFF, which strikes every onset at 1.0.
 *
 * The parameter is the caller's: the drum asks with SYNTH_PARAM_PERC_ACCENT and the lead
 * with SYNTH_PARAM_SEQ_ACCENT, two stored numbers that share this arithmetic and the table
 * of names and nothing else. That is what lets the same sector read alike on both figure
 * pages while turning one never moves the other.
 */
static int accent_index_of(synth_param_t param)
{
    const int i = (int)(clamp01f(s_param[param]) * (float)(ACCENT_COUNT - 1) + 0.5f);
    return (i < 0) ? 0 : ((i >= ACCENT_COUNT) ? ACCENT_COUNT - 1 : i);
}

/* Маска фигуры, чьё число стоит в параметре: собрана из таблицы выше, один раз на вызов. */
static uint16_t accent_mask_of(synth_param_t param)
{
    return ACCENT_MASK[accent_index_of(param)];
}

/* The drum's figure and the lead's, read separately: one page each, no shared choice. */
static int accent_index_perc(void)
{
    return accent_index_of(SYNTH_PARAM_PERC_ACCENT);
}

static int accent_index_seq(void)
{
    return accent_index_of(SYNTH_PARAM_SEQ_ACCENT);
}

/* The arpeggiator's own figure: chosen on LEAD ARP, independent of both other parts. See
 * SYNTH_PARAM_ARP_ACCENT. */
static int accent_index_arp(void)
{
    return accent_index_of(SYNTH_PARAM_ARP_ACCENT);
}

/*
 * Does this figure mark this grid position?
 *
 * Asked of the mask by the step's NUMBER IN THE BAR, which is ((grid_index % n) + 1)
 * and therefore 1..n. n is 4 at the smallest, so the 1-based count never produces the
 * 0 that would index the wrong bit, and the reduction is done here, once, rather than
 * asked of the caller.
 *
 * n is the FIGURE'S OWN, and that is the whole of how one accent serves two parts: the
 * lead's grid and the drum's are independent — different STEPS, different PULSES,
 * different ROTATE — and each one asks this with its own length. A figure that marks
 * 1, 5, 9 and 13 marks those positions in a bar of sixteen steps on both parts and
 * marks what fits of them on a bar of seven.
 */
static bool accent_marks_step(int accent, uint32_t grid_index, int n)
{
    const uint16_t mask = ACCENT_MASK[accent];
    if (mask == 0u) {
        return false;
    }

    const uint32_t step = (grid_index % (uint32_t)n) + 1u;
    return (mask & (uint16_t)(1u << (step - 1u))) != 0u;
}

/*
 * The velocity an onset that is NOT the accent is struck at: the WEAK VEL setting, whole
 * numbers 0..127, over 127. 1.0 exactly while the figure is OFF, whatever the setting
 * says.
 *
 * A SETTING and not a fade, and that is the point of it: the ACCENT knob stopped being a
 * level when it became a list of figures, so "how much" left the figure and became a knob
 * of its own on OPTIONS — reachable without choosing a rhythm, stored per device like the
 * backlight, and not part of any preset. The figure decides WHICH onsets are weak; this
 * decides HOW weak they are. APP_SET_WEAK_VEL in app_settings.h is where the three values
 * are set out.
 *
 * 1.0 exactly at OFF, and not "one after a formula that happens to come to one", so a
 * device that has never been touched, an older patch and a preset that predates the
 * parameter all strike the hit — and open the lead note — at the velocity they always
 * did. That exact 1.0 is also what figure_velocity_for() below branches on, so the
 * promise is kept by an equality rather than by arithmetic that ought to cancel.
 *
 * 127 OF 127 COMES OUT AS EXACTLY 1.0 TOO, and that is what the top of the setting means
 * to the engine: a figure can be chosen and it changes nothing, through the same short
 * exit as OFF, so the sample path is the untouched one and not merely an equivalent one.
 * The arithmetic is exact because it is a whole number of 127ths divided by 127.0f — one
 * correctly rounded float division, the same one the old `80.0f / 127.0f` constant was,
 * so at the factory value the sound is bit for bit what this instrument played before
 * the setting existed rather than close to it.
 *
 * THE SETTING IS READ HERE, not the copy the control surface keeps in s_param[]: what the
 * sound follows is the stored setting, so one number covers a knob move, the restore a
 * boot performs and the value in the flash. app_settings_get() cannot fail — 80 is its
 * fallback when nothing has ever been stored — never touches the flash and takes no lock,
 * so this is an int read in the audio task and nothing more. The clamp is the belt for a
 * stored number this build no longer recognises.
 */
bool synth_app_accent_marks(int accent, uint32_t step, int n)
{
    if (accent < 0) {
        accent = 0;
    } else if (accent >= ACCENT_COUNT) {
        accent = ACCENT_COUNT - 1;
    }
    if (n < 1) {
        n = 1;
    }
    return accent_marks_step(accent, step, n);
}

bool synth_app_weak_hits_are_off(void)
{
    /* The stored setting, not the control surface's copy: the picture has to say what the
     * sound will do, and the engine reads the setting. */
    return app_settings_get(APP_SET_WEAK_VEL) == 0;
}

static float accent_velocity_weak(int accent)
{
    if (ACCENT_MASK[accent] == 0u) {
        return 1.0f;
    }

    const float v = (float)app_settings_get(APP_SET_WEAK_VEL) / (float)WEAK_VEL_MAX;
    return clamp01f(v);
}

/* The velocity one onset of a figure is given: 1.0 for a step the chosen figure marks
 * and for every step while it is OFF, the WEAK VEL setting for the rest. Shared by the
 * drum's hits and the lead's notes, each against its own n.
 *
 * The short exit is what makes the setting's top value — 127, "there is no difference" —
 * free: the comparison is against the same 1.0 that accent_velocity_weak() returns for a
 * figure that is OFF, so the mask is not even read and the engine sees the sample path it
 * always had.
 *
 * At 0 the weak onsets are handed a velocity of exactly 0.0, and the two parts do two
 * different things with it — both of them intended, and the setting's description is the
 * reason neither is special-cased:
 *
 *   the drum does not strike AT ALL. synth_perc_trigger() returns before it looks at a
 *   voice when the velocity is not greater than zero, on the engine's own reading of a
 *   zero velocity as "there was no hit", so nothing sounds, no voice is spent and even the
 *   pending steal is not re-aimed.
 *
 *   the lead opens its group's three voices at level 0. That is silent, but it is a note:
 *   it retriggers the envelope of the step before it and its glide still steps, so the
 *   line becomes the accented notes alone, each lasting until the next unmarked step.
 *   Nothing is starved by it — the generator's group is its own, not a pool it shares
 *   with the player — and no code path is added for it. */
static float figure_velocity_for(int accent, uint32_t grid_index, int n)
{
    const float base = accent_velocity_weak(accent);
    if (base >= 1.0f) {
        return 1.0f;
    }
    return accent_marks_step(accent, grid_index, n) ? 1.0f : base;
}

/*
 * The step count a RESET position stands for, for either RESET parameter.
 *
 * One function for both, because the list is one list: the caller passes its own parameter,
 * so the number the lead's page shows is the lead's period and the one the drum's page shows
 * is the drum's. Zero is INF — the gesture off — and is returned as zero.
 */
static int reset_step_count_for(synth_param_t param)
{
    const int index = (int)(s_param[param] * (float)(APP_SEQ_RESET_COUNT - 1) + 0.5f);

    /* Bounded before the table read: the value comes from a patch and a patch can be a
     * byte from anywhere. */
    if (!(index >= 0)) {
        return app_seq_reset_steps(0);
    }
    if (index >= APP_SEQ_RESET_COUNT) {
        return app_seq_reset_steps(APP_SEQ_RESET_COUNT - 1);
    }
    return app_seq_reset_steps(index);
}

/* The drum's gesture is due when ITS phrase has stood on N of its own steps. Integers only:
 * p and the origin are step numbers of the same grid, so there is no rounding here. */
static bool perc_reset_due(uint64_t p)
{
    const int steps = reset_step_count_for(SYNTH_PARAM_PERC_RESET);
    if (steps <= 0) {
        return false;
    }
    if (p < s_perc_origin) {
        return false;
    }
    return (p - s_perc_origin) >= (uint64_t)steps;
}

/* Whether the drum has finished the hit it last struck: DECAY is its gate, and the render
 * path keeps the count of voices that are still sounding. Zero means silence — a voice is
 * freed once its gate has fallen below PERC_TAIL — so this is the module's own definition of
 * "sounded out" and not a second one invented here. */
static bool perc_restart_free(void)
{
    return synth_perc_active_voices() <= 0;
}

/* ------------------------------------------------------------------------- */
/* THE DRUM SECTION: A KIT, FOUR LANES, AND A GROOVE                          */
/*                                                                           */
/* One drum voice cannot be a kick and a hat at once, and a drum part is made  */
/* of different drums. What the section is, then, is four LANES — kick,       */
/* snare, hat, tom — each with a recipe out of the chosen KIT, playing a      */
/* GROOVE chosen from a list. THE KIT IS THE SOUND AND THE GROOVE IS THE PART: */
/* nothing in the kit says when to play, and nothing in the groove says how   */
/* it sounds. That division is what a drum machine has had since the Minipops, */
/* and it is the only arrangement in which a written rhythm, a chosen kit and */
/* a generator that varies the two can coexist without arguing.               */
/* ------------------------------------------------------------------------- */

#define PERC_LANE_COUNT 4
#define PERC_LANE_KICK 0
#define PERC_LANE_SNARE 1
#define PERC_LANE_HAT 2
#define PERC_LANE_TOM 3

/*
 * КАЖДЫЙ ИНСТРУМЕНТ — СВОЙ ГОЛОС, И ГОЛОСА РАЗНЫЕ.
 *
 * Дорожек в ките четыре, инструментов пять: открытый хэт — не второй удар по дорожке хэта,
 * а свой инструмент, и раньше он шёл в тот же голос, отчего закрытый и открытый не могли
 * звучать вместе: второй удар гасил хвост первого. Владелец слышал это как «открытых хэтов
 * нигде нет» — их и не было, был закрытый, оборванный на полпути.
 *
 * Отображение дорожки в голос объявлено таблицей ниже, а не совпадением номеров: дорожка и
 * голос — разные вещи, и совпадать они могут только случайно. Внутри дорожки голос
 * монофонический, как у настоящей установки: удар обрывает свой же хвост.
 */
#define PERC_VOICE_OPEN 5

/* Every groove in the list is one bar of sixteen positions, whatever PERC_STEPS says: the
 * grid stretches the sixteen onto its own count, so a groove is written once and plays on
 * any grid. Sixteen is the length every one of these patterns was written in. */
#define PERC_GROOVE_STEPS 16

/* The voice's own ranges, repeated here because the section sets the voice from hertz and
 * octaves while the voice speaks in knob positions: these are the two maps on the way back.
 * The numbers are the module's and were printed by its own init line. */
#define PERC_DECAY_MIN_MS 20.0f
#define PERC_DECAY_SPAN 6.2288f
#define PERC_ENV_MAX_OCT 5.0f

static float perc_decay_v01(float ms)
{
    const float v = log2f(ms / PERC_DECAY_MIN_MS) / PERC_DECAY_SPAN;
    return v < 0.0f ? 0.0f : (v > 1.0f ? 1.0f : v);
}

static float perc_env_v01(float octaves)
{
    const float v = octaves / PERC_ENV_MAX_OCT;
    return v < 0.0f ? 0.0f : (v > 1.0f ? 1.0f : v);
}

static float perc_clampf(float v, float lo, float hi)
{
    return v < lo ? lo : (v > hi ? hi : v);
}

typedef struct {
    float pitch_hz;     /* the band-pass centre: the note of the hit */
    float decay_ms;     /* the gate */
    float env_oct;      /* how far the centre falls over the hit */
    float body;         /* the tone under the noise */
    float level;
    /*
     * ФОРМА ТОНА: 0 — синус, 0.5 — треугольник, 1 — квадрат.
     *
     * Добавлена последней, поэтому все двадцать восемь старых китов, у которых этого
     * поля нет в инициализаторе, получают ноль — ровно тот удар, который у них и был.
     * Новые киты задают её явно, и это первое, чем они отличаются на слух.
     */
    float shape = 0.0f;
} perc_recipe_t;

typedef struct {
    perc_recipe_t voice[PERC_LANE_COUNT];
    perc_recipe_t alt[PERC_LANE_COUNT];     /* the open hat, the rim, the tight kick */
} perc_kit_t;

/*
 * THE TWENTY-EIGHT KITS, DRY TO STRANGE, AND EACH ONE A PLACE RATHER THAN A SETTING.
 *
 * A kit is four recipes and their alternates, and it is the biggest single control on the
 * page: two kits differ more than two positions of any trim below. The numbers come from the
 * host bench, where each one was played as a part before it was written here. The kick's
 * centre is the one chosen by ear: 41 Hz with a long fall and a body of 0.95 for MINI, lower
 * and longer for DEEP and TRAP, higher and shorter for TIGHT and NINE.
 *
 * THE ALTERNATES are the same lane changing voice: the open hat for the hat, the rim for the
 * snare, a tight second kick for the kick, a higher tom for the tom. They are what PERC_TIMBRE
 * reaches for when a part has been playing long enough to want a different colour.
 *
 * THE SECOND EIGHT ARE THE STYLES rather than the materials: EIGHT is the long sub and the
 * snapping snare of the machine that named it, NINE is the punch and the metal above it, TRAP
 * is a kick that outlasts the bar, JAZZ is a brush and a low ride, STEEL is a kit with the
 * noise left raw.
 */
static const perc_kit_t s_perc_kits[PERC_KIT_COUNT] = {
    /* TIGHT: dry, short, no metal in the hats. */
    {
        { { 46.0f, 340.0f, 3.2f, 0.92f, 1.00f }, { 340.0f, 100.0f, 0.8f, 0.04f, 0.90f },
          { 6400.0f, 38.0f, 0.2f, 0.00f, 0.65f }, { 160.0f, 140.0f, 1.4f, 0.50f, 0.85f } },
        { { 60.0f, 160.0f, 1.6f, 0.50f, 0.95f }, { 720.0f, 58.0f, 0.6f, 0.30f, 0.80f },
          { 5000.0f, 150.0f, 0.2f, 0.00f, 0.55f }, { 240.0f, 110.0f, 1.2f, 0.40f, 0.80f } },
    },
    /* MINI: the drum machine the instrument was tuned against, and the factory kit. */
    {
        { { 41.0f, 480.0f, 3.6f, 0.95f, 1.00f }, { 330.0f, 120.0f, 0.9f, 0.05f, 0.90f },
          { 6200.0f, 45.0f, 0.2f, 0.00f, 0.70f }, { 165.0f, 190.0f, 1.6f, 0.55f, 0.90f } },
        { { 55.0f, 200.0f, 1.8f, 0.55f, 0.95f }, { 700.0f, 60.0f, 0.6f, 0.32f, 0.80f },
          { 4800.0f, 240.0f, 0.2f, 0.00f, 0.60f }, { 250.0f, 140.0f, 1.4f, 0.45f, 0.82f } },
    },
    /* BROKEN: long, low and metallic, with a part that wanders. */
    {
        { { 37.0f, 620.0f, 3.9f, 0.98f, 1.00f }, { 300.0f, 160.0f, 1.2f, 0.08f, 0.92f },
          { 5600.0f, 60.0f, 0.25f, 0.00f, 0.66f }, { 150.0f, 260.0f, 2.0f, 0.45f, 0.90f } },
        { { 50.0f, 240.0f, 1.8f, 0.45f, 0.95f }, { 640.0f, 70.0f, 0.8f, 0.25f, 0.82f },
          { 4200.0f, 300.0f, 0.2f, 0.00f, 0.58f }, { 220.0f, 170.0f, 1.6f, 0.38f, 0.82f } },
    },
    /* DUST: a dark room, soft attacks and a longer tail than the beat. */
    {
        { { 44.0f, 520.0f, 3.4f, 0.85f, 1.00f }, { 380.0f, 180.0f, 1.0f, 0.02f, 0.88f },
          { 5200.0f, 70.0f, 0.3f, 0.00f, 0.60f }, { 175.0f, 220.0f, 1.6f, 0.40f, 0.85f } },
        { { 58.0f, 200.0f, 1.6f, 0.40f, 0.95f }, { 760.0f, 80.0f, 0.7f, 0.20f, 0.78f },
          { 3800.0f, 260.0f, 0.25f, 0.00f, 0.55f }, { 260.0f, 150.0f, 1.4f, 0.35f, 0.80f } },
    },
    /* TAPE: a worn machine — a little longer than MINI everywhere. */
    {
        { { 42.0f, 440.0f, 3.4f, 0.90f, 1.00f }, { 350.0f, 130.0f, 0.9f, 0.06f, 0.90f },
          { 5800.0f, 55.0f, 0.25f, 0.00f, 0.62f }, { 170.0f, 200.0f, 1.6f, 0.50f, 0.88f } },
        { { 56.0f, 200.0f, 1.6f, 0.50f, 0.95f }, { 690.0f, 65.0f, 0.6f, 0.28f, 0.80f },
          { 4500.0f, 220.0f, 0.2f, 0.00f, 0.58f }, { 245.0f, 150.0f, 1.4f, 0.42f, 0.82f } },
    },
    /* DEEP: slow and heavy, for a part that carries the low end. */
    {
        { { 35.0f, 760.0f, 4.2f, 1.00f, 1.05f }, { 260.0f, 220.0f, 1.4f, 0.10f, 0.88f },
          { 4800.0f, 90.0f, 0.3f, 0.00f, 0.58f }, { 130.0f, 320.0f, 2.2f, 0.50f, 0.88f } },
        { { 46.0f, 320.0f, 2.2f, 0.50f, 0.95f }, { 560.0f, 90.0f, 0.9f, 0.20f, 0.80f },
          { 3600.0f, 320.0f, 0.25f, 0.00f, 0.55f }, { 200.0f, 200.0f, 1.8f, 0.40f, 0.82f } },
    },
    /* BRUSH: soft attacks, long noise, a part played with sticks of air. */
    {
        { { 48.0f, 300.0f, 2.8f, 0.55f, 0.95f }, { 420.0f, 220.0f, 1.2f, 0.02f, 0.85f },
          { 7000.0f, 120.0f, 0.4f, 0.00f, 0.55f }, { 190.0f, 240.0f, 1.8f, 0.30f, 0.82f } },
        { { 62.0f, 180.0f, 1.4f, 0.30f, 0.92f }, { 900.0f, 140.0f, 1.0f, 0.10f, 0.78f },
          { 6000.0f, 300.0f, 0.35f, 0.00f, 0.52f }, { 280.0f, 180.0f, 1.6f, 0.25f, 0.78f } },
    },
    /* MACHINE: the hardest and most regular — short gates, nothing left to the room. */
    {
        { { 40.0f, 260.0f, 3.0f, 0.80f, 1.00f }, { 320.0f, 90.0f, 0.7f, 0.00f, 0.92f },
          { 6800.0f, 30.0f, 0.15f, 0.00f, 0.70f }, { 175.0f, 120.0f, 1.2f, 0.50f, 0.88f } },
        { { 52.0f, 140.0f, 1.4f, 0.40f, 0.95f }, { 680.0f, 50.0f, 0.5f, 0.35f, 0.80f },
          { 5600.0f, 90.0f, 0.2f, 0.00f, 0.60f }, { 250.0f, 90.0f, 1.0f, 0.40f, 0.82f } },
    },
    /* EIGHT: the long sub and the snapping snare of the machine that named it. */
    {
        { { 38.0f, 700.0f, 3.8f, 1.00f, 1.05f }, { 280.0f, 150.0f, 0.9f, 0.10f, 0.88f },
          { 6000.0f, 60.0f, 0.2f, 0.00f, 0.62f }, { 140.0f, 300.0f, 2.0f, 0.45f, 0.88f } },
        { { 50.0f, 300.0f, 2.0f, 0.50f, 0.95f }, { 620.0f, 70.0f, 0.6f, 0.25f, 0.80f },
          { 4600.0f, 240.0f, 0.2f, 0.00f, 0.58f }, { 210.0f, 160.0f, 1.6f, 0.40f, 0.82f } },
    },
    /* NINE: the punch and the metal above it. */
    {
        { { 50.0f, 280.0f, 3.0f, 0.80f, 1.00f }, { 400.0f, 110.0f, 0.9f, 0.02f, 0.92f },
          { 6800.0f, 40.0f, 0.2f, 0.00f, 0.70f }, { 180.0f, 150.0f, 1.4f, 0.45f, 0.85f } },
        { { 62.0f, 160.0f, 1.6f, 0.35f, 0.95f }, { 900.0f, 60.0f, 0.5f, 0.30f, 0.80f },
          { 5400.0f, 180.0f, 0.2f, 0.00f, 0.62f }, { 255.0f, 110.0f, 1.2f, 0.40f, 0.82f } },
    },
    /* ROOM: the same kit heard from the back of a hall. */
    {
        { { 42.0f, 560.0f, 3.4f, 0.85f, 1.00f }, { 350.0f, 260.0f, 1.1f, 0.05f, 0.88f },
          { 5400.0f, 140.0f, 0.3f, 0.00f, 0.55f }, { 165.0f, 300.0f, 1.8f, 0.40f, 0.85f } },
        { { 55.0f, 240.0f, 1.8f, 0.45f, 0.95f }, { 700.0f, 140.0f, 0.7f, 0.20f, 0.78f },
          { 4200.0f, 380.0f, 0.25f, 0.00f, 0.55f }, { 240.0f, 200.0f, 1.4f, 0.35f, 0.80f } },
    },
    /* LOFI: dull hats, a soft kick, nothing above five kilohertz. */
    {
        { { 45.0f, 420.0f, 3.0f, 0.70f, 0.95f }, { 340.0f, 140.0f, 0.8f, 0.05f, 0.85f },
          { 3600.0f, 80.0f, 0.25f, 0.00f, 0.50f }, { 170.0f, 200.0f, 1.4f, 0.35f, 0.80f } },
        { { 58.0f, 200.0f, 1.4f, 0.30f, 0.92f }, { 640.0f, 70.0f, 0.6f, 0.20f, 0.78f },
          { 2800.0f, 240.0f, 0.2f, 0.00f, 0.50f }, { 230.0f, 150.0f, 1.2f, 0.30f, 0.78f } },
    },
    /* TRAP: a kick that outlasts the bar, and a snare with nowhere to hide. */
    {
        { { 45.0f, 900.0f, 4.0f, 1.00f, 1.05f }, { 320.0f, 120.0f, 0.8f, 0.06f, 0.90f },
          { 7000.0f, 35.0f, 0.15f, 0.00f, 0.68f }, { 150.0f, 260.0f, 1.8f, 0.40f, 0.86f } },
        { { 55.0f, 500.0f, 2.2f, 0.50f, 0.95f }, { 720.0f, 55.0f, 0.5f, 0.30f, 0.80f },
          { 5800.0f, 160.0f, 0.2f, 0.00f, 0.60f }, { 230.0f, 150.0f, 1.4f, 0.35f, 0.82f } },
    },
    /* CLUB: a hard small room, the kick short and forward, the hats tight. */
    {
        { { 48.0f, 320.0f, 3.2f, 0.85f, 1.00f }, { 380.0f, 90.0f, 0.8f, 0.02f, 0.92f },
          { 6600.0f, 50.0f, 0.2f, 0.00f, 0.66f }, { 175.0f, 140.0f, 1.4f, 0.50f, 0.86f } },
        { { 60.0f, 180.0f, 1.6f, 0.40f, 0.95f }, { 860.0f, 55.0f, 0.5f, 0.30f, 0.80f },
          { 5200.0f, 200.0f, 0.2f, 0.00f, 0.60f }, { 250.0f, 100.0f, 1.2f, 0.42f, 0.82f } },
    },
    /* JAZZ: a brush on the snare and a low ride where the hats would be. */
    {
        { { 52.0f, 300.0f, 2.6f, 0.60f, 0.92f }, { 450.0f, 200.0f, 1.0f, 0.02f, 0.82f },
          { 5000.0f, 160.0f, 0.35f, 0.00f, 0.48f }, { 190.0f, 220.0f, 1.6f, 0.25f, 0.80f } },
        { { 64.0f, 180.0f, 1.4f, 0.30f, 0.92f }, { 950.0f, 120.0f, 0.8f, 0.10f, 0.78f },
          { 4200.0f, 320.0f, 0.3f, 0.00f, 0.52f }, { 280.0f, 170.0f, 1.4f, 0.20f, 0.78f } },
    },
    /* STEEL: a kit with the noise left raw. */
    {
        { { 40.0f, 300.0f, 3.0f, 0.75f, 1.00f }, { 300.0f, 100.0f, 0.8f, 0.10f, 0.90f },
          { 7400.0f, 45.0f, 0.2f, 0.00f, 0.72f }, { 160.0f, 150.0f, 1.4f, 0.50f, 0.85f } },
        { { 52.0f, 160.0f, 1.4f, 0.40f, 0.95f }, { 680.0f, 50.0f, 0.4f, 0.40f, 0.80f },
          { 6200.0f, 120.0f, 0.2f, 0.00f, 0.65f }, { 240.0f, 100.0f, 1.1f, 0.45f, 0.82f } },
    },

    /* GLASS: brittle metal. A high, thin centre on every lane, a long ring on the hat and
     * nothing at all underneath: the kit of a machine that is being struck rather than hit. */
    {
        { { 58.0f, 220.0f, 2.4f, 0.30f, 0.95f }, { 820.0f, 300.0f, 0.9f, 0.00f, 0.84f },
          { 7000.0f, 220.0f, 0.35f, 0.00f, 0.62f }, { 320.0f, 260.0f, 2.0f, 0.20f, 0.84f } },
        { { 74.0f, 130.0f, 1.6f, 0.20f, 0.90f }, { 1250.0f, 90.0f, 0.5f, 0.05f, 0.76f },
          { 6100.0f, 420.0f, 0.30f, 0.00f, 0.55f }, { 430.0f, 170.0f, 1.6f, 0.15f, 0.80f } },
    },
    /* BOX: cardboard. All body, no bottom and no tail, the sound of a box hit with a hand in
     * a small room, which is a colour none of the electronic kits has. */
    {
        { { 70.0f, 120.0f, 1.8f, 0.25f, 0.88f }, { 480.0f, 70.0f, 0.6f, 0.20f, 0.86f },
          { 3400.0f, 22.0f, 0.15f, 0.00f, 0.52f }, { 240.0f, 80.0f, 1.0f, 0.45f, 0.82f } },
        { { 92.0f, 70.0f, 1.2f, 0.15f, 0.85f }, { 760.0f, 45.0f, 0.4f, 0.30f, 0.78f },
          { 2600.0f, 60.0f, 0.20f, 0.00f, 0.48f }, { 300.0f, 55.0f, 0.8f, 0.35f, 0.78f } },
    },
    /* NEON: the eighties. A gated snare that fills the bar, a click on the kick and a hat
     * with the top left open, bright and unembarrassed. */
    {
        { { 52.0f, 380.0f, 3.0f, 0.90f, 1.02f }, { 300.0f, 380.0f, 1.0f, 0.02f, 0.94f },
          { 6800.0f, 65.0f, 0.20f, 0.00f, 0.68f }, { 190.0f, 300.0f, 1.8f, 0.45f, 0.86f } },
        { { 64.0f, 220.0f, 2.0f, 0.60f, 0.95f }, { 900.0f, 220.0f, 0.8f, 0.05f, 0.85f },
          { 5600.0f, 300.0f, 0.30f, 0.00f, 0.60f }, { 280.0f, 260.0f, 1.6f, 0.40f, 0.82f } },
    },
    /* SUB: a kick and a promise. The lowest centre on the instrument with the longest fall,
     * and the other three lanes deliberately far behind it. */
    {
        { { 34.0f, 950.0f, 4.4f, 1.00f, 1.08f }, { 280.0f, 60.0f, 0.5f, 0.00f, 0.72f },
          { 6000.0f, 25.0f, 0.15f, 0.00f, 0.38f }, { 120.0f, 220.0f, 2.4f, 0.60f, 0.70f } },
        { { 38.0f, 1200.0f, 4.6f, 1.00f, 1.06f }, { 520.0f, 40.0f, 0.35f, 0.00f, 0.66f },
          { 4800.0f, 70.0f, 0.20f, 0.00f, 0.34f }, { 150.0f, 160.0f, 1.8f, 0.50f, 0.66f } },
    },
    /* WOOD: sticks on wood. A tom with the body all the way up and a snare with a wooden
     * ring under the noise, the one acoustic kit in the list with a warm middle. */
    {
        { { 48.0f, 300.0f, 2.6f, 0.80f, 0.98f }, { 420.0f, 110.0f, 0.7f, 0.45f, 0.88f },
          { 4400.0f, 45.0f, 0.25f, 0.05f, 0.55f }, { 210.0f, 240.0f, 1.6f, 0.85f, 0.90f } },
        { { 56.0f, 200.0f, 1.8f, 0.65f, 0.92f }, { 680.0f, 70.0f, 0.5f, 0.55f, 0.82f },
          { 3800.0f, 110.0f, 0.25f, 0.02f, 0.50f }, { 265.0f, 190.0f, 1.4f, 0.80f, 0.86f } },
    },
    /* GRIME: everything in the middle. A snare with a hand under it, a dull hat and a kick
     * that is all body, the kit for a room with a carpet and a sampler. */
    {
        { { 44.0f, 240.0f, 2.8f, 0.95f, 1.00f }, { 360.0f, 90.0f, 0.7f, 0.30f, 0.92f },
          { 3200.0f, 35.0f, 0.20f, 0.00f, 0.50f }, { 175.0f, 150.0f, 1.4f, 0.60f, 0.88f } },
        { { 52.0f, 150.0f, 1.6f, 0.70f, 0.95f }, { 640.0f, 55.0f, 0.4f, 0.35f, 0.86f },
          { 2900.0f, 95.0f, 0.20f, 0.00f, 0.46f }, { 230.0f, 120.0f, 1.2f, 0.55f, 0.82f } },
    },
    /* TIN: a toy kit. High centres, short gates and no weight anywhere, which is a joke the
     * instrument can make and none of the other twenty-seven can. */
    {
        { { 78.0f, 90.0f, 1.6f, 0.20f, 0.85f }, { 900.0f, 50.0f, 0.5f, 0.10f, 0.80f },
          { 6900.0f, 20.0f, 0.10f, 0.00f, 0.60f }, { 380.0f, 60.0f, 0.9f, 0.15f, 0.76f } },
        { { 96.0f, 60.0f, 1.1f, 0.10f, 0.80f }, { 1300.0f, 35.0f, 0.35f, 0.05f, 0.74f },
          { 6400.0f, 40.0f, 0.15f, 0.00f, 0.56f }, { 520.0f, 45.0f, 0.8f, 0.10f, 0.72f } },
    },
    /* INDUS: the metal end. A long slamming kick, a snare that rings for a third of a second
     * and a tom in the low middle, the heaviest kit here. */
    {
        { { 40.0f, 700.0f, 3.6f, 1.00f, 1.05f }, { 240.0f, 320.0f, 1.6f, 0.15f, 0.95f },
          { 7000.0f, 120.0f, 0.30f, 0.00f, 0.70f }, { 140.0f, 400.0f, 2.4f, 0.75f, 0.92f } },
        { { 50.0f, 480.0f, 2.6f, 0.85f, 1.00f }, { 820.0f, 420.0f, 1.2f, 0.10f, 0.90f },
          { 5800.0f, 500.0f, 0.35f, 0.00f, 0.62f }, { 200.0f, 300.0f, 2.0f, 0.70f, 0.88f } },
    },

    /* ABYSS: the floor of the voice. 35 Hz is the lowest centre it has, the gate is a second
     * and a quarter, and the fall is nearly the whole of ENV's travel — so the hit starts as a
     * click you can hear and ends as a pressure you feel, over a bar later. The snare is low and
     * long for the same reason and the hats are barely there: a kit is a place, and this one is
     * underneath the floor. */
    {
        { { 35.0f, 1250.0f, 4.8f, 0.97f, 1.02f }, { 200.0f, 520.0f, 2.4f, 0.20f, 0.86f },
          { 4200.0f, 34.0f, 0.15f, 0.00f, 0.46f }, { 88.0f, 760.0f, 3.2f, 0.80f, 0.88f } },
        { { 46.0f, 340.0f, 2.4f, 0.80f, 0.96f }, { 760.0f, 180.0f, 0.9f, 0.15f, 0.80f },
          { 3400.0f, 280.0f, 0.25f, 0.00f, 0.50f }, { 132.0f, 460.0f, 2.2f, 0.65f, 0.84f } },
    },
    /* SLUDGE: the same idea slower and thicker. A 38 Hz kick with a gate of nearly a second and
     * a half, a snare that smears into it, hats that arrive late and stay. Where ABYSS is deep,
     * this is heavy: the kit for a bar played at half speed by a machine that is not sure. */
    {
        { { 38.0f, 1460.0f, 4.2f, 1.00f, 1.00f }, { 280.0f, 620.0f, 2.0f, 0.35f, 0.90f },
          { 3600.0f, 190.0f, 0.25f, 0.00f, 0.55f }, { 110.0f, 940.0f, 2.8f, 0.85f, 0.90f } },
        { { 52.0f, 430.0f, 2.2f, 0.75f, 0.94f }, { 980.0f, 240.0f, 1.0f, 0.25f, 0.82f },
          { 4100.0f, 640.0f, 0.30f, 0.00f, 0.56f }, { 168.0f, 620.0f, 2.0f, 0.70f, 0.86f } },
    },
    /* MONK: a ritual built on metal. The kick is short and pitched high for this end of the
     * list, the snare is a struck plate and the hat is a bell with a gate long enough to
     * overlap the next beat — the lane that carries the figure here is metal, not skin. */
    {
        { { 44.0f, 880.0f, 3.4f, 0.55f, 0.98f }, { 340.0f, 700.0f, 1.4f, 0.12f, 0.92f },
          { 6900.0f, 520.0f, 0.40f, 0.00f, 0.58f }, { 130.0f, 420.0f, 2.6f, 0.45f, 0.86f } },
        { { 58.0f, 380.0f, 2.0f, 0.40f, 0.92f }, { 2400.0f, 300.0f, 1.0f, 0.05f, 0.84f },
          { 6600.0f, 700.0f, 0.35f, 0.00f, 0.54f }, { 260.0f, 380.0f, 1.8f, 0.35f, 0.82f } },
    },
    /* VOID: a kick and the air around it. The other three lanes are switched down to almost
     * nothing — a snare that is a breath, a hat that is a tick — so a bar of this kit is one
     * enormous hit and the room answering. The kit for a groove with holes in it. */
    {
        { { 36.0f, 1380.0f, 4.0f, 1.00f, 1.04f }, { 700.0f, 90.0f, 0.6f, 0.05f, 0.50f },
          { 3000.0f, 20.0f, 0.10f, 0.00f, 0.34f }, { 400.0f, 60.0f, 0.8f, 0.30f, 0.44f } },
        { { 44.0f, 820.0f, 2.0f, 0.90f, 0.96f }, { 1400.0f, 60.0f, 0.5f, 0.05f, 0.46f },
          { 2400.0f, 90.0f, 0.15f, 0.00f, 0.38f }, { 520.0f, 80.0f, 1.0f, 0.20f, 0.40f } },
    },

    /*
     * ЧЕТЫРЕ КИТА ПОД ТЕХНО, по одному на школу. Это места, а не настройки: у каждой школы
     * свой вес бочки, своё время у хэта и своё отношение к металлу. Кит — самый сильный
     * контрол на странице, и разница между DETRO и HARD должна слышаться с первого удара.
     */
    /* DETRO: детройт. Бочка низкая, мягкая и длинная — 46 Гц и почти половина секунды, — с
     * большой долей тона; хэт тусклый и короткий, снейр ближе к хлопку, чем к пластине.
     * Здесь важно не «жирно», а «тепло»: верх у кита намеренно приглушён. */
    {
        { { 44.0f, 760.0f, 2.6f, 0.98f, 1.06f, 0.12f },
          { 420.0f, 130.0f, 0.9f, 0.06f, 0.88f, 0.25f },
          { 6200.0f, 45.0f, 0.20f, 0.00f, 0.58f, 0.20f },
          { 150.0f, 200.0f, 1.5f, 0.45f, 0.84f, 0.15f } },
        { { 56.0f, 340.0f, 1.7f, 0.60f, 0.98f, 0.15f },
          { 860.0f, 70.0f, 0.6f, 0.28f, 0.78f, 0.30f },
          { 4600.0f, 190.0f, 0.25f, 0.00f, 0.50f, 0.25f },
          { 230.0f, 150.0f, 1.2f, 0.38f, 0.78f, 0.20f } },
    },
    /* HARD: хардтехно. Бочка выше и короче (56 Гц, 240 мс) с большой долей шума, снейр —
     * щелчок на 1.2 кГц, хэт на 9 кГц почти без тела. Кит для темпа, где удар должен
     * проходить через стену. */
    {
        { { 52.0f, 560.0f, 3.0f, 0.96f, 1.10f, 0.80f },
          { 1250.0f, 60.0f, 0.7f, 0.12f, 0.92f, 0.55f },
          { 9200.0f, 28.0f, 0.15f, 0.00f, 0.62f, 0.35f },
          { 205.0f, 120.0f, 1.6f, 0.40f, 0.86f, 0.60f } },
        { { 64.0f, 260.0f, 2.0f, 0.74f, 1.04f, 0.85f },
          { 2100.0f, 40.0f, 0.4f, 0.20f, 0.84f, 0.70f },
          { 7600.0f, 120.0f, 0.20f, 0.00f, 0.54f, 0.40f },
          { 280.0f, 90.0f, 1.1f, 0.30f, 0.80f, 0.65f } },
    },
    /* MNTL: ментал. Всё смещено: бочка 43 Гц с почти целой долей тона, снейр металлический
     * и высокий, том уехал вниз к 96 Гц — низ и верх поменялись местами на слух. Это кит
     * для фигур, которые должны звучать неверно, оставаясь на сетке. */
    {
        { { 41.0f, 880.0f, 2.2f, 1.00f, 1.06f, 0.55f },
          { 2400.0f, 46.0f, 1.2f, 0.10f, 0.86f, 0.75f },
          { 11200.0f, 22.0f, 0.10f, 0.00f, 0.60f, 0.60f },
          { 96.0f, 380.0f, 2.6f, 0.70f, 0.88f, 0.45f } },
        { { 54.0f, 400.0f, 2.8f, 0.66f, 0.99f, 0.60f },
          { 900.0f, 140.0f, 1.8f, 0.35f, 0.80f, 0.55f },
          { 8400.0f, 60.0f, 0.30f, 0.00f, 0.52f, 0.50f },
          { 320.0f, 160.0f, 1.6f, 0.50f, 0.82f, 0.55f } },
    },
    /* PSY: пси-техно. Бочка собранная — 50 Гц, 300 мс, тон и шум в равновесии, — снейр
     * короткий, хэт ровный и звонкий: кит, под которым долго идёт одна фигура, и он не
     * утомляет именно тем, что ничего не подчёркивает. */
    {
        { { 47.0f, 620.0f, 2.8f, 0.96f, 1.06f, 0.45f },
          { 780.0f, 80.0f, 0.8f, 0.10f, 0.88f, 0.35f },
          { 8000.0f, 34.0f, 0.18f, 0.00f, 0.60f, 0.30f },
          { 165.0f, 160.0f, 1.4f, 0.42f, 0.85f, 0.40f } },
        { { 60.0f, 300.0f, 1.9f, 0.70f, 0.99f, 0.50f },
          { 1500.0f, 55.0f, 0.5f, 0.22f, 0.80f, 0.40f },
          { 6500.0f, 150.0f, 0.22f, 0.00f, 0.52f, 0.35f },
          { 220.0f, 130.0f, 1.2f, 0.35f, 0.80f, 0.45f } },
    },
};

/*
 * THE GROOVE LIST: TWENTY-FOUR WRITTEN PARTS, EACH ONE BAR OF SIXTEENS.
 *
 * This is the Minipops lesson taken literally. A drum machine's rhythms sound like parts
 * because they WERE parts: somebody played them, the machine repeats them, and the player's
 * control is which one and how much of it moves. A density knob that sprinkles hits over a
 * Euclidean skeleton cannot produce a boogie or a trap pattern, because those patterns are
 * not evenly spread — they are written, with their own syncopation and their own ghosts.
 *
 * Bit i of a mask is position i of the bar. KICK, SNARE, HAT and TOM are the four lanes; GHOST
 * is a quiet hat on positions the hat itself leaves empty, which is where most of the
 * difference between a metronome and a part lives.
 *
 * THE CYCLE is how many bars the part repeats before VARIATION may vary it, and before a FILL
 * may close it. A two-bar part that is never varied is exactly what its name says.
 */
typedef struct {
    uint16_t hit[PERC_LANE_COUNT];
    uint16_t ghost;
    uint8_t  cycle;
    /*
     * ОТКРЫТЫЙ ХЭТ ОТДЕЛЬНОЙ МАСКОЙ: иначе ему пришлось бы делить шаги с закрытым, а
     * рисунок «закрытые на каждый шаг, открытые на слабые восьмые» — это два разных рисунка
     * на одной дорожке, и в одном шестнадцатибитном слове их не записать. Ноль — открытых
     * нет, как у всех грувов, которые были до этого поля.
     */
    uint16_t open = 0x0000u;
} perc_groove_t;

static const perc_groove_t s_perc_grooves[PERC_GROOVE_COUNT] = {
    /* MINIPOP: kick on one and three with the pickup, snare backbeat, hats on the eighths. */
    { { 0x0581, 0x1010, 0x5555, 0x0000 }, 0x0000, 4 },
    /* DISCO: four on the floor, hats on every eighth. */
    { { 0x1111, 0x1010, 0x5555, 0x0000 }, 0x0000, 4 },
    /* BOOGIE: the kick walks, the snare is late, the hats never stop. */
    { { 0x0941, 0x1010, 0x5555, 0x0000 }, 0x0000, 4 },
    /* ROCK: one and three, the kick pushed onto the last eighth. */
    { { 0x0501, 0x1010, 0x5555, 0x0000 }, 0x0000, 4 },
    /* FUNK: sixteen positions of kick, ghosts between the backbeats. */
    { { 0x0449, 0x1010, 0x494D, 0x0000 }, 0x8080, 2 },
    /* BREAK: the backbeat displaced, a ghost before the bar line. */
    { { 0x0441, 0x1090, 0x5555, 0x0000 }, 0x4000, 2 },
    /* HOUSE: four on the floor with a clap, open hats on the offbeat. */
    { { 0x1111, 0x1010, 0x4444, 0x0000 }, 0x0000, 4 },
    /* TECHNO: four on the floor and nothing in the snare lane at all — the owner took the
     * clap out of this one, and a techno bar is better for it: the kick and the hats carry the
     * bar, and the sixteenth flow under them is what a busy snare would only have covered.
     *
     * THE SNARE LANE IS EMPTY ON PURPOSE. This is the one written groove with no backbeat, so
     * FILL and VARIATION have nothing to displace there and leave it empty; the lane's own
     * ghost-note figures are off too, because a ghost is still a snare.
     *
     * THE HATS ARE ON THE EVEN SIXTEENTHS ON PURPOSE. SWING delays every second sixteenth,
     * so a hat written on an odd one is struck late whenever SWING is up, and a bar full of
     * them sounds like a drummer who has lost the grid rather than like a groove. Written on
     * the eighths, the open hat is straight at any SWING; only the ghost notes are swung,
     * which is what a shuffle in this music is. See perc_tick() for the swing itself. */
    /*
     * БОЧКИ НА 1, 5, 9 И 13, ХЭТЫ НА 3, 7, 11 И 15 — тот самый классический бит: удар на
     * каждой доле и хэт ровно между ними. Всё, что делает его техно, — это темп и то, что
     * вокруг бочки ничего нет.
     */
    { { 0x1111, 0x0000, 0x4444, 0x0000 }, 0x0000, 2, 0x4444 },
    /* TRAP: sparse kick, snare on three, hats on every sixteenth. */
    { { 0x0481, 0x0100, 0xFFFF, 0x0000 }, 0x0000, 2 },
    /* HALF: half-time — the snare on three, the kick late. */
    { { 0x0401, 0x0100, 0x5555, 0x0000 }, 0x0000, 2 },
    /* TWO STEP: the kick on one and the last eighth, snare on two and four. */
    { { 0x0401, 0x1010, 0x4444, 0x0000 }, 0x0000, 4 },
    /* AFRO: the kick and the tom answer each other across the bar. */
    { { 0x2449, 0x1010, 0x5555, 0x8880 }, 0x0000, 4 },
    /* LATIN: a sparse kick, the tom on the offbeats. */
    { { 0x0041, 0x1010, 0x5555, 0x088C }, 0x0000, 4 },
    /* MARCH: snare and hat on every quarter, the kick on one and three. */
    { { 0x0101, 0x1111, 0x1111, 0x0000 }, 0x0000, 4 },
    /* BOSSA: the kick on one, the tom on the second half of the beat. */
    { { 0x0441, 0x1010, 0x5555, 0x0088 }, 0x0000, 4 },
    /* GARAGE: the kick on the second sixteenth of the second beat, a hat ghost late. */
    { { 0x0421, 0x1010, 0x5555, 0x0000 }, 0x2000, 4 },
    /* CLUB: four on the floor, a clap on two and four, hats on every eighth, and a ghost
     * sixteenth between the hats — the same reason the techno bar keeps its loud hats off the
     * odd sixteenths: they are the ones swing moves. */
    { { 0x1111, 0x1010, 0x5555, 0x0000 }, 0x2222, 4 },

    /*
     * THE IDM END, seven bars, and what makes them strange is the same thing in each: the
     * grid is there and the part does not agree with it. These were asked for as "strange
     * grooves, like for IDM", and the seven below are that request taken at its word — the
     * kick stutters, the snare doubles, the hats sit off the eighths, the bar splits.
     *
     * They are APPENDED after CLUB, so the seventeen the instrument had keep their positions:
     * a preset that stored a groove still plays the groove it was written with.
     */
    /* SKIP: the kick stutters — three steps, then a hole, then two, and the last eighth is
     * where the bar line is. The snare stays on two and four, which is what keeps it a part
     * rather than a pile: something has to be reliable under the stutter. */
    { { 0x4A49, 0x1010, 0x5555, 0x0000 }, 0x8080, 2 },
    /* STUT: the snare doubles itself — two sixteenths on the second beat and two on the
     * fourth — over a written kick and a hat on every sixteenth. A drum machine asked to roll
     * and refusing to do it cleanly. */
    { { 0x0441, 0x1030, 0xFFFF, 0x0000 }, 0x0000, 2 },
    /* GRIT: the kick lands off the grid, the loud hats are the offbeat sixteenths and the tom
     * answers once in the third beat. Three bars before it repeats, so the ear never settles. */
    { { 0x2489, 0x1010, 0x2222, 0x0400 }, 0x4040, 3 },
    /* WOBBLE: kick and tom trade the same figure a step apart, which reads as a bar that is
     * limping rather than broken. Hats on the eighths hold the time. */
    { { 0x0511, 0x1010, 0x5555, 0x2222 }, 0x8888, 4 },
    /* SPLIT: half-time with the snare displaced to the a of the beat — the backbeat is there,
     * one sixteenth early, and the hats are quarters. The simplest of the seven and the one
     * that sounds most like a mistake, which is the point. */
    { { 0x0401, 0x0088, 0x4444, 0x1000 }, 0x2222, 2 },
    /* RUST: a machine being repaired while it plays. The kick keeps two of its four, the hats
     * have moved onto the odd sixteenths (the ones SWING moves, which makes SWING a second
     * fault on top of the first), and a ghost hat sits between two of them. */
    { { 0x0901, 0x1010, 0x5A5A, 0x0000 }, 0x0000, 2 },
    /* DRILL: three-three-two across the whole bar, kick and tom sharing the figure, the snare
     * on the backbeat and the hats on the offbeats. The one of the seven that is a groove
     * rather than a fault, and the one that sits best under a long kit. */
    { { 0x4949, 0x1010, 0x2222, 0x0080 }, 0x0000, 4 },

    /*
     * ШЕСТЬ ГРУВОВ ЧЕТЫРЕ-НА-ЧЕТЫРЕ, добавлены после IDM-конца по той же причине, что и он:
     * номера выше не двигаются, и сохранённый грув играет то, что играл.
     *
     * Все шесть — одна и та же бочка на каждой доле и разное отношение к тому, что вокруг
     * неё. Снейра в них нет ни в одном: техно держится бочкой и хэтом, а снейр — это уже
     * другой жанр, и владелец убрал его из техно-строки не для того, чтобы он вернулся
     * через новые имена.
     */
    /* FOUR: голый четыре-на-четыре. Бочка на каждой доле, хэт на слабых восьмых, призраки
     * между ними. Самая простая строка в списке и та, с которой техно начинается. */
    { { 0x1111, 0x0000, 0x4444, 0x0000 }, 0x0000, 2, 0x4444 },
    /* DRIVE: те же слабые восьмые, но с призраками на нечётных шестнадцатых — насос,
     * у которого между ударами что-то шевелится. */
    { { 0x1111, 0x0000, 0x4444, 0x0000 }, 0x2222, 2 },
    /* ROLL: бочка на каждой доле и две подряд на конце бара, а хэт — на «a» каждой доли, то
     * есть на последней шестнадцатой: он догоняет удар, а не предваряет его, и бар катится
     * вперёд. */
    { { 0x1311, 0x0000, 0x8888, 0x0000 }, 0x0000, 4, 0x4444 },
    /* PULSE: хэт на каждой шестнадцатой — самый плотный рисунок из шести, ровный и без
     * акцентов. Долгая строка: четыре бара до повтора, иначе пульс начинает раздражать. */
    { { 0x1111, 0x0000, 0xAAAA, 0x0000 }, 0x0000, 4, 0x4444 },
    /* HYPN: гипнотическая — та же бочка, хэт на слабых, и том отвечает на «и» третьей доли
     * раз в четыре бара. Единственная из шести, где что-то меняется от бара к бару. */
    { { 0x1111, 0x0000, 0x4444, 0x0400 }, 0x2222, 4, 0x4444 },
    /* STOMP: тяжёлая — бочка на каждой доле, том на каждой второй и редкий хэт на «e», между
     * ударами. Бар читается как шаг, а не как пульс. Для медленного темпа и большого зала. */
    { { 0x1111, 0x0000, 0x2222, 0x2222 }, 0x0000, 2, 0x0000 },
    /*
     * HATS: закрытые на КАЖДОМ шаге и открытые на слабых восьмых. Ровный частокол, поверх
     * него дыхание — фигура, ради которой в инструменте появился пятый голос: раньше
     * открытый хэт гасил закрытый, и услышать это было нельзя.
     */
    { { 0x1111, 0x0000, 0xFFFF, 0x0000 }, 0x0000, 4, 0x4444 },
    /*
     * SHAKE: закрытые на каждой восьмой, открытые на слабых, призраки между ними — тот же
     * приём, но на полшага реже, и бар получается качающимся, а не строчным.
     */
    { { 0x1111, 0x0000, 0xAAAA, 0x0000 }, 0x2222, 2, 0x4444 },
};

/*
 * THE NAMES THE TWO READOUTS PRINT, one per entry above and one per kit.
 *
 * Six characters is the budget: the value box on a drum page is shared by the knob's other
 * positions, and a list whose longest word is TIGHT never has to be shrunk to fit. They are
 * the same words the table's comments use, so a name in the readout is a name in the source.
 *
 * The names are the list's own, not the engine's: nothing reads them but synth_app_param_text(),
 * so renaming a kit on the panel is this table and the comment above the recipe, and never a
 * number stored in a preset — a preset carries the index.
 */
static const char *const s_perc_kit_names[PERC_KIT_COUNT] = {
    "TIGHT", "MINI", "BROKEN", "DUST", "TAPE", "DEEP", "BRUSH", "MACHINE",
    "EIGHT", "NINE", "ROOM", "LOFI", "TRAP", "CLUB", "JAZZ", "STEEL",
    "GLASS", "BOX", "NEON", "SUB", "WOOD", "GRIME", "TIN", "INDUS",
    "ABYSS", "SLUDGE", "MONK", "VOID",
    "DETRO", "HARD", "MNTL", "PSY",
};

static const char *const s_perc_groove_names[PERC_GROOVE_COUNT] = {
    "MINIPOP", "DISCO", "BOOGIE", "ROCK", "FUNK", "BREAK", "HOUSE", "TECHNO", "TRAP",
    "HALF", "TWOSTEP", "AFRO", "LATIN", "MARCH", "BOSSA", "GARAGE", "CLUB",
    "SKIP", "STUT", "GRIT", "WOBBLE", "SPLIT", "RUST", "DRILL",
    "FOUR", "DRIVE", "ROLL", "PULSE", "HYPN", "STOMP",
    "HATS", "SHAKE",
};

/*
 * THE BASS SECTION'S NAMES, one per kit and one per figure.
 *
 * synth_bass.cpp's KITS[] and PATTERNS[] have no names in them: a kit there is six numbers
 * and a pattern is sixteen characters, and the module never prints either. The readout does,
 * so the words live here, in the application, where every other panel word lives — a name is
 * a property of the panel and not of the voice.
 *
 * SEVEN CHARACTERS IS THE BUDGET this time, one more than the drum tables', because the bass
 * page's value box is its own sector and the longest word here (STAGGER, DESCEND) still clears
 * the arc. Every word is upper case: the font the readouts use has no lower case.
 *
 * THE KITS COME IN THE ENGINE'S THREE FAMILIES OF TEN — round, picked, driven — so the first
 * ten read as one family in the list, the next ten as another and the last ten as the third.
 * That ordering is the whole reason the names can be this short: ROUND, PICK and DRIVEN say
 * where in the travel a kit sits as well as what it sounds like. The figures are named for
 * the rhythm rather than for the notes, because the notes are the pattern's own business and
 * the same figure is played at any octave and under any kit.
 */
static const char *const s_bass_kit_names[BASS_KIT_COUNT] = {
    /* round: short, low, little snap */
    "ROUND", "SOFT", "DEEP", "WARM", "THUMB", "MUTE", "FELT", "HOLLOW", "PILLOW", "DUB",
    /* picked: brighter, more snap */
    "PICK", "BRIGHT", "EDGE", "TWANG", "PLUCK", "STING", "CLICK", "WIRE", "BITE", "TINE",
    /* trance: short, resonant, made for rolling and off-beat figures */
    "ROLL", "ROLL2", "PSYROLL", "OFFBEAT", "SQUELCH", "SUB", "GROWL", "TICK", "FLOW", "HYPNOT",
};

static const char *const s_bass_pat_names[BASS_PAT_COUNT] = {
    "BLANK", "SPACE", "OFFBEAT", "STAB", "JAB", "HALF", "DESCEND", "LATE", "CRAWL", "DUBGHOST",
    "SEEKER", "OFF16", "TRIPLET", "PUMP", "SLIDE", "PICKUP", "FLOW", "SKANK", "CLIMB",
    "SHUFFLE", "BASSX", "EIGHTH", "SKIP", "WALKER", "HALFGHOST", "ROLL", "GALLOP", "OCT8",
    "ROLL3", "PSYGHOST", "PULSE", "HOP", "SLIP", "TRIPGHOST", "PSYSHIFT", "DRIVE16", "ROLL2",
    "ACID", "RUN16", "OCT16", "PSYROLL", "ROLLGHOST",
};

/* Шесть характеров такта, в том же порядке, что таблица в synth_bass.cpp. */
static const char *const s_bass_var_names[6] = {
    "STEADY", "JUMP", "WALK", "ROLL", "DRIVE", "DROP",
};

static uint32_t s_perc_rng = 0x9E3779B9u;

static float perc_rand01(void)
{
    s_perc_rng ^= s_perc_rng << 13;
    s_perc_rng ^= s_perc_rng >> 17;
    s_perc_rng ^= s_perc_rng << 5;
    return (float)(s_perc_rng >> 8) / 16777216.0f;
}

static int perc_kit_index(void)
{
    int i = (int)(clamp01f(s_param[SYNTH_PARAM_PERC_KIT]) * (float)(PERC_KIT_COUNT - 1) + 0.5f);
    if (i < 0) {
        i = 0;
    }
    if (i >= PERC_KIT_COUNT) {
        i = PERC_KIT_COUNT - 1;
    }
    return i;
}

static const perc_kit_t *perc_kit(void)
{
    return &s_perc_kits[perc_kit_index()];
}

/*
 * The bass section's two positions, read the way every list on this instrument is read:
 * round(v * (count - 1)) of the knob's travel, from the same s_param[] the module is handed.
 * Kept together and next to the tables they index, so a name and the thing it names cannot
 * be the same number twice.
 */
static int bass_kit_index(void)
{
    int i = (int)(clamp01f(s_param[SYNTH_PARAM_BASS_KIT]) * (float)(BASS_KIT_COUNT - 1) + 0.5f);
    if (i < 0) {
        i = 0;
    }
    if (i >= BASS_KIT_COUNT) {
        i = BASS_KIT_COUNT - 1;
    }
    return i;
}

static int bass_var_index(void)
{
    int i = (int)(clamp01f(s_param[SYNTH_PARAM_BASS_VAR]) * 5.0f + 0.5f);

    if (i < 0) { i = 0; }
    if (i > 5) { i = 5; }

    return i;
}

static int bass_pat_index(void)
{
    int i = (int)(clamp01f(s_param[SYNTH_PARAM_BASS_PAT]) * (float)(BASS_PAT_COUNT - 1) + 0.5f);
    if (i < 0) {
        i = 0;
    }
    if (i >= BASS_PAT_COUNT) {
        i = BASS_PAT_COUNT - 1;
    }
    return i;
}

/*
 * ТЕХНО БЕЗ СНЕЙРА, и это не только строка таблицы.
 *
 * У владельца техно играет без снейра вообще, а «вообще» в этом инструменте значит ещё и
 * вариацию с филлом: и то и другое дописывает удары поверх написанного грува, и оба умеют
 * попасть именно в снейр — вариация подъёмом на «a» четвёртой доли, филл раскатом по снейру.
 * Поэтому у техно оба пути закрыты: вариация не выбирает подъём снейра, а филл берёт
 * единственную фигуру без снейра — раскат по тому. Номер строки в таблице ниже, а не поиск
 * по имени: имена печатает отдельная таблица, и связывать логику с текстом на экране незачем.
 */
#define PERC_GROOVE_TECHNO 7
#define PERC_FILL_TOM_ROLL 2

static int perc_groove_index(void)
{
    int i = (int)(clamp01f(s_param[SYNTH_PARAM_PERC_GROOVE]) * (float)(PERC_GROOVE_COUNT - 1)
                  + 0.5f);
    if (i < 0) {
        i = 0;
    }
    if (i >= PERC_GROOVE_COUNT) {
        i = PERC_GROOVE_COUNT - 1;
    }
    return i;
}

static const perc_groove_t *perc_groove(void)
{
    return &s_perc_grooves[perc_groove_index()];
}

static float perc_fader(void)
{
    return level_gain(clamp01f(s_param[SYNTH_PARAM_PERC_LEVEL]));
}

/*
 * МИКШЕР ДОРОЖЕК: четыре ручки страницы PERC MIX.
 *
 * Порядок PERC_LANE_* и порядок ручек один и тот же — KICK, SNARE, HAT, TOM, — и таблица
 * ниже это утверждает явно, чтобы правка энумератора не сдвинула уровни молча.
 */
static const synth_param_t s_perc_mix_param[PERC_LANE_COUNT] = {
    SYNTH_PARAM_PERC_MIX_KICK, SYNTH_PARAM_PERC_MIX_SNARE,
    SYNTH_PARAM_PERC_MIX_HAT,  SYNTH_PARAM_PERC_MIX_TOM,
};

static float perc_mix(int lane)
{
    return level_gain(clamp01f(s_param[s_perc_mix_param[lane]]));
}

/*
 * ПОКАЗАНИЯ ДОРОЖЕК ДЛЯ ЭКРАНА.
 *
 * Удар записывается здесь, в момент удара: уровень, с которым дорожка только что прозвучала,
 * — это её сила вместе с микшером. Дальше значение отпускается одной экспонентой за блок
 * (около 150 мс), и тело показанию даёт экран, у которого уже есть своя скорость подъёма и
 * спада (refresh_viz()). Так индикатор говорит о том, что слышно, и ничего не стоит
 * звуковому тракту: ни детектора, ни чтения голосов.
 */
static float s_perc_lane_env[PERC_LANE_COUNT];

static void perc_lane_env_tick(void)
{
    /* Блок 256 отсчётов при 48 кГц — 5.33 мс; exp(-5.33 / 150) = 0.965. */
    for (int l = 0; l < PERC_LANE_COUNT; l++) {
        s_perc_lane_env[l] *= 0.965f;
    }
}

extern "C" float synth_app_perc_lane_level(int lane)
{
    if (lane < 0 || lane >= PERC_LANE_COUNT) {
        return 0.0f;
    }
    return s_perc_lane_env[lane];
}

static float perc_timbre(void)
{
    return clamp01f(s_param[SYNTH_PARAM_PERC_TIMBRE]);
}

/* A transpose in semitones: 0.5 is none, and the ends are an octave each way. */
static float perc_tone_semis(void)
{
    return (clamp01f(s_param[SYNTH_PARAM_PERC_TONE]) - 0.5f) * 24.0f;
}

static float perc_tune_semis(void)
{
    return (clamp01f(s_param[SYNTH_PARAM_PERC_TUNE]) - 0.5f) * 24.0f;
}

/* The gate multiplier: 0.5 is the kit's own, the ends are ±1.32 octaves. */
static float perc_length_mul(void)
{
    return exp2f((clamp01f(s_param[SYNTH_PARAM_PERC_LENGTH]) - 0.5f) * 2.64f);
}

/*
 * PUNCH: the attack of the hit, straight through to the voice, which does the mapping.
 *
 * It used to be BODY — a multiplier on the kit's own body, 0.5..1.5 — and that was the knob
 * the player reported as doing nothing. It was half eaten by the clamp in the recipe and it
 * was completely dead on every lane whose recipe body is zero, which is the hats and the
 * snares of most kits: on those a multiplier on zero is zero however far the knob travels.
 * The kit's body is now the kit's, and this knob is the one thing that shapes every lane.
 */
static float perc_punch01(void)
{
    return clamp01f(s_param[SYNTH_PARAM_PERC_BODY_TRIM]);
}

/* SWING is stored 0..1 and is used as a fraction of a step, up to 0.6 of one. */
static float perc_swing_frac(void)
{
    return clamp01f(s_param[SYNTH_PARAM_PERC_SWING]) * 0.6f;
}

/*
 * SPEED, AND WHY IT IS A LIST OF FOUR.
 *
 * The drum's clock may only be a ratio of two against the transport's, because any other
 * ratio drifts and the drum ends up arguing with the bar — it would land a sixteenth early
 * in one bar and late in the next, and no amount of playing would fix it. The four positions
 * are ×0.25, ×0.5, ×1 and ×2: quarter, half, the same, double. 0.5 of the knob is not one of
 * them, since four positions have three gaps, so the index is what is read.
 */
static const float s_perc_speeds[PERC_SPEED_COUNT] = {
    0.25f, 0.5f, 0.75f, 1.0f, 1.5f, 2.0f, 3.0f
};

static int perc_speed_index(void)
{
    int i = (int)(clamp01f(s_param[SYNTH_PARAM_PERC_SPEED]) * (float)(PERC_SPEED_COUNT - 1)
                  + 0.5f);
    if (i < 0) {
        i = 0;
    }
    if (i >= PERC_SPEED_COUNT) {
        i = PERC_SPEED_COUNT - 1;
    }
    return i;
}

static float perc_speed(void)
{
    return s_perc_speeds[perc_speed_index()];
}

/* The figure's clock and its state, all of it the drum's own. */
static uint16_t s_perc_hit[PERC_LANE_COUNT];
static uint16_t s_perc_ghost;

/*
 * WHAT THE RING DRAWS, kept apart from the bar the engine is playing.
 *
 * The dots on PERC SEQ are the drum's part, and there are two states of the world they have
 * to show: while the drum plays, the bar it is actually playing, which the variation and the
 * fill have moved; and while it is stopped, or right after a knob was turned, the part as
 * written, so that choosing a groove can be done by eye.
 *
 * The second is the reason this copy exists at all: the engine's own s_perc_hit is rebuilt
 * only at a bar line, so a ring drawn from it would keep the old pattern until the next bar
 * and a groove chosen while stopped would never appear. perc_show_written() lays the table's
 * bar into this copy, perc_new_bar() overwrites it with the bar being played, and the display
 * reads nothing else.
 */
static uint16_t s_perc_show_hit[PERC_LANE_COUNT];
static uint16_t s_perc_show_ghost;
static bool     s_perc_show_fill;
static bool     s_perc_show_open_hat;   /* this bar ends with the open hat */
static uint64_t s_perc_step;            /* drum steps since the transport started */
static float    s_perc_acc;             /* the fraction of a step carried between blocks */
/* Первый шаг бара ещё не прозвучал: он бьёт в том же блоке, где пошёл транспорт. */
static bool     s_perc_hit_first = true;
static uint32_t s_perc_pending;         /* blocks until a swung step lands; 0 = none */
static uint64_t s_perc_bar_seen = ~0ull;
static bool     s_perc_filled;          /* this bar ends with a fill */
static bool     s_perc_open_hat;        /* this bar ends with the open hat */

/*
 * РАТЧЕТ: ОДИН ШАГ, ПОВТОРЁННЫЙ НЕСКОЛЬКО РАЗ ВНУТРИ СЕБЯ.
 *
 * Отдельной ручки у него нет и не будет — на странице PRC места нет. Он живёт в FILL и
 * появляется сам: раз в несколько барах, с вероятностью меньшей, чем у филла, на случайном
 * шаге бара и на случайной дорожке (чаще на хэте — ролл хэта и есть то, ради чего это
 * нужно). Так FILL остаётся тем, чем был — «этот бар кончается филлом», — а ратчет
 * добавляется поверх как украшение, которого никто не заказывал.
 *
 * Деление — 3, 4 или 6 долей шага: тройной ролл, шестнадцатые и секстоли. Воспроизведение
 * не в DSP: шаг и так делится на блоки, поэтому удары просто раскладываются по блокам
 * внутри шага, а не сэмплам — на этой высоте блока (2.7 мс) этого достаточно, и никакого
 * второго счётчика заводить не нужно.
 */
static int      s_perc_ratchet_step = -1;   /* -1: в этом баре ратчета нет */
static int      s_perc_ratchet_lane = -1;
static int      s_perc_ratchet_div;
static int      s_perc_rat_left;            /* сколько ударов ещё осталось */
static int      s_perc_rat_lane;
static float    s_perc_rat_wait;            /* блоков до следующего */
static float    s_perc_rat_gap;             /* блоков между ударами */
static float    s_perc_motion[PERC_LANE_COUNT];  /* the slow walk, in semitones */
static bool     s_perc_realign;         /* a speed change is waiting for the bar line */
static int      s_perc_speed_seen = -1;
static uint64_t s_perc_tp_bar_seen;

/*
 * THE FOUR MOVES THE VARIATION MAY MAKE, and why these four.
 *
 * A written part is a sentence; a variation is what a player does to it the fourth time
 * through, and players do a small number of things: they add the sixteenths under their hand,
 * they push the kick into the gap before a beat, they answer the last beat with the snare, and
 * they take something away to leave room. Each move below is one of those, expressed as an OR
 * or an AND on the written masks, so a move can only ever add a musical position or remove a
 * hat — it cannot invent a rhythm nobody wrote, and it never moves the downbeat.
 */
#define PERC_VAR_MOVES 4

/* Chosen at the start of a cycle and held for it; -1 is "the written bar". */
static int s_perc_var_move[2] = { -1, -1 };

/* Which of the fills below this bar takes; see perc_fill_pick(). */
static int s_perc_fill_pick;

/* The moves themselves. Order is arbitrary, and worth keeping so: the draw is uniform, and a
 * cycle that always started with the same move would be a knob with two positions. */
static void perc_var_apply(int move)
{
    switch (move) {
    case 0:
        /* GHOSTS: the sixteenth flow under the written part. On the e of every beat, quiet,
         * and on the odd sixteenths — which is where a quiet hat belongs. */
        s_perc_ghost |= 0x2222u;
        break;
    case 1:
        /* KICK PUSH: the & of the third beat. The one syncopation a four-on-the-floor bar
         * takes without arguing with the bar line. */
        s_perc_hit[PERC_LANE_KICK] |= 0x0400u;
        break;
    case 2:
        /* SNARE LIFT: the a of the fourth beat, a pickup into the next bar. It is what a
         * drummer plays instead of a fill when the phrase is about to turn.
         *
         * Не для техно: там снейра нет, и подъём был бы единственным снейром в баре. */
        if (perc_groove_index() == PERC_GROOVE_TECHNO) {
            break;
        }
        s_perc_hit[PERC_LANE_SNARE] |= 0x8000u;
        break;
    case 3:
        /* SPACE: the quarter-note hats go and the offbeats stay, so the bar opens up. Taking
         * something away is a variation too, and the one most often missed. */
        s_perc_hit[PERC_LANE_HAT] &= (uint16_t)~0x1111u;
        break;
    default:
        break;
    }
}


/*
 * The modulation, applied to the hit that is about to be struck rather than to the knobs: the
 * destination moves the drum's pitch, its fall, its gate or its attack, and the next hit comes
 * back to the kit's own numbers because the recipe is a copy.
 *
 * THE ATTACK IS NOT IN THE RECIPE. PUNCH used to be a multiplier on the kit's body, so the
 * destination could be written into the recipe like the other three; PUNCH is now the attack
 * of the voice, read at the moment of the hit, so it travels in and out through a pointer.
 */
static void perc_apply_mod(perc_recipe_t *r, float *punch01)
{
    const uint16_t bits = mod_dest_bits();

    if (!(bits & (MD_PITCH | MD_ENV | MD_DEC | MD_PUNCH))) {
        return;
    }
    /*
     * У УДАРНОЙ У КАЖДОГО ПРИЁМНИКА СВОЯ ГЛУБИНА: сумма двух LFO считается по тому биту,
     * которого касается закон, а не одна на все четыре.
     */
    if (bits & MD_PITCH) {
        r->pitch_hz *= exp2f(mod_sum_pm(MD_PITCH) * 0.5f);
    }
    if (bits & MD_ENV) {
        r->env_oct = perc_clampf(r->env_oct * (1.0f + mod_sum_pm(MD_ENV) * 0.5f), 0.0f,
                                 PERC_ENV_MAX_OCT);
    }
    if (bits & MD_DEC) {
        r->decay_ms = perc_clampf(r->decay_ms * (1.0f + mod_sum_pm(MD_DEC) * 0.5f), 20.0f,
                                  1500.0f);
    }
    if (bits & MD_PUNCH) {
        *punch01 = clamp01f(*punch01 + mod_sum_pm(MD_PUNCH) * 0.3f);
    }
}

/* ONE HIT of one lane: the kit's recipe, moved by the trims, the velocity and the walk. */
/*
 * БАЛАНС ДОРОЖЕК, ОБЩИЙ ДЛЯ ВСЕХ КИТОВ.
 *
 * В ките записаны числа, которыми он звучит, но записаны они в шкале самой дорожки: у хэта
 * «0.62» и у бочки «0.62» — это не одна громкость. Хэт живёт в 6–11 кГц, где ухо слышит
 * гораздо лучше, и на слух он выходит вдвое громче бочки при том же числе; с выключенными
 * акцентами он бьёт в полную силу на каждом шаге и перекрывает всё остальное. Пока числа
 * подбирались по одному киту, это лечилось правкой каждого кита, и владелец слышал
 * результат как «иногда хэты слишком громкие».
 *
 * Здесь это правится один раз и для всех: снейр тише бочки на 1 дБ, том на 1.3, хэт на
 * 2.6 дБ. Характер кита остаётся в его числах, а соотношение дорожек становится одинаковым
 * везде, и правка кита больше не может его сломать.
 */
/*
 * ОДНОВРЕМЕННЫЙ УДАР ТИШЕ, ЧЕМ ТОТ ЖЕ УДАР В ОДИНОЧКУ.
 *
 * Четыре дорожки бьют в один момент — и сумма выходит громче, чем каждая из них в отдельности:
 * бочка, снейр, хэт и том складываются по амплитуде, а мягкий лимитер на шине ударки после
 * этого срезает вершины и делает удар плоским. На слух это «слишком громко» на совпадающих
 * шагах и «нормально» на остальных.
 *
 * Поэтому удар на совпадающем шаге тише одиночного на долю, растущую с числом дорожек:
 * две — 0.77, три — 0.63, четыре — 0.53 от своей громкости. Сумма четырёх после этого
 * примерно равна сумме двух, лимитер перестаёт работать на каждом акценте, а рисунок
 * остаётся читаемым.
 */
#define PERC_SIMUL_K 0.30f

static float perc_simul_gain(int count)
{
    if (count <= 1) {
        return 1.0f;
    }
    return 1.0f / (1.0f + PERC_SIMUL_K * (float)(count - 1));
}

/* Дорожка кита -> голос модуля. Один инструмент — один голос, всегда. */

static const int s_perc_lane_voice[PERC_LANE_COUNT] = {
    PERC_VOICE_KICK,
    PERC_VOICE_SNARE,
    PERC_VOICE_HAT,
    PERC_VOICE_TOM,
};

static const float s_perc_lane_trim[PERC_LANE_COUNT] = {
    1.00f,   /* KICK: опора, по ней всё остальное и меряется */
    0.90f,   /* SNARE */
    0.74f,   /* HAT: самый «громкий» на слух при том же числе */
    0.86f,   /* TOM */
};

static void perc_strike(int lane, float velocity01, int voice = -1,
                        float decay_mul = 1.0f, float pitch_mul = 1.0f,
                        float level_mul = 1.0f, bool skip_alt = false)
{
    /*
     * A FADER AT ZERO STRIKES NOTHING. The hit is refused here rather than played at zero
     * level, because a voice spent on silence is both a voice the next hit cannot have and,
     * on this instrument, a block the drum pays for. Nothing of the part survives the test:
     * no tail is retuned, no send is opened, and the figure keeps counting as if the drummer
     * had stopped playing.
     */
    const float fader = perc_fader();
    if (!(fader > 0.0f)) {
        return;
    }

    /* Дорожка на нуле не бьёт: то же правило, что у фейдера части, и по той же
     * причине — голос на тишину не тратится. */
    const float mix = perc_mix(lane);
    if (!(mix > 0.0f)) {
        return;
    }

    const perc_kit_t *k = perc_kit();
    const float tim = perc_timbre();
    const float vel = clamp01f(velocity01);
    const bool alt = !skip_alt && (lane != PERC_LANE_KICK) && (perc_rand01() < tim * 0.22f);

    perc_recipe_t r = alt ? k->alt[lane] : k->voice[lane];

    float st = perc_tone_semis() + s_perc_motion[lane] + tim * 0.55f * (vel - 0.7f)
             + tim * 0.18f * (perc_rand01() * 2.0f - 1.0f);
    if (lane == PERC_LANE_KICK || lane == PERC_LANE_TOM) {
        st += perc_tune_semis();
    }

    r.pitch_hz = perc_clampf(r.pitch_hz * pitch_mul * exp2f(st / 12.0f), 35.0f, 7000.0f);
    r.decay_ms = perc_clampf(r.decay_ms * decay_mul * perc_length_mul() * (1.0f + tim * 0.30f * (vel - 0.7f))
                            * (1.0f + tim * 0.05f * (perc_rand01() * 2.0f - 1.0f)),
                        20.0f, 1500.0f);
    r.body = clamp01f(r.body * (1.0f + tim * 0.55f * (vel - 0.7f)));
    r.level = clamp01f(r.level * level_mul * s_perc_lane_trim[lane]
                       * (1.0f + tim * 0.06f * (perc_rand01() * 2.0f - 1.0f)));

    /*
     * Показание дорожки — сила удара вместе с микшером, до того как голос её
     * обработает: индикатор говорит о том, что в дорожку пришло.
     */
    const float shown = clamp01f(vel * mix);

    if (shown > s_perc_lane_env[lane]) {
        s_perc_lane_env[lane] = shown;
    }

    /*
     * THE DIVE IS THE KICK'S, AND THE TOM'S, AND NOBODY ELSE'S.
     *
     * A falling centre is what makes a kick, and it is also the module's most expensive
     * shape: a dive is a coefficient staircase rebuilt as the centre moves, and the module
     * builds it ahead of the hit only while the shape is not changing. A kit changes shape on
     * every hit — a different lane each time — so a lane that dives costs its staircase on
     * every one of its hits.
     *
     * A hi-hat and a snare are bands of noise with a gate; their centre does not need to
     * move. Taking the dive off those two lanes removes the staircase from the dense half of
     * the figure and leaves it where it is heard: the kick, and a little on the tom.
     */
    if (lane == PERC_LANE_SNARE || lane == PERC_LANE_HAT) {
        r.env_oct = 0.0f;
    } else if (lane == PERC_LANE_TOM) {
        r.env_oct = (r.env_oct > 1.0f) ? 1.0f : r.env_oct;
    }

    float punch01 = perc_punch01();   /* the knob as the hand left it, before the modulation */
    perc_apply_mod(&r, &punch01);

    /*
     * УРОВЕНЬ УДАРА И НЕ ТРОГАЕТ ЧУЖИХ.
     *
     * В synth_perc_set() идёт ФЕЙДЕР ЧАСТИ: он общий для всей ударки и скользит на всех
     * звучащих голосах, как фейдер и должен. Обрезка кита, обрезка дорожки и ручка
     * микшера идут отдельным вызовом, в свой голос — иначе удар одной дорожки
     * переставлял бы уровень всем остальным (см. synth_perc_strike_gain()).
     */
    const float hit_gain = clamp01f(r.level * mix);

    /* Дорожка на нуле не бьёт: голос на тишину не тратится. Случайные числа к этому
     * моменту уже взяты, поэтому глушение дорожки не сдвигает их череду у соседних. */
    if (!(hit_gain > 0.0f)) {
        return;
    }

    synth_perc_strike_gain(hit_gain);
    synth_perc_set(synth_perc_pitch_01(r.pitch_hz),
                   synth_app_param_default(SYNTH_PARAM_PERC_RESO),
                   perc_decay_v01(r.decay_ms), perc_env_v01(r.env_oct), fader, r.body,
                   punch01, r.shape);

    /*
     * THE LANE IS THE VOICE. Kick, snare, hat and tom each own one, so nothing one instrument
     * does can take another's tail: a four-on-the-floor bar used to strike the kick and the hat
     * on the same step, and with three voices shared between four lanes the quietest tail was
     * stolen — the hat under every kick, which is heard as a missing hit. Inside the lane the
     * voice is monophonic, which is what a drum is.
     */
    /*
     * И УДАРКА БЬЁТ БЕЗ ОЧЕРЕДИ. Дорожки ударки — это установка: удар обрывает свой же
     * хвост и звучит целиком, а не ждёт две миллисекунды, пока тот догаснет. Иначе бочка с
     * длинным хвостом на каждой доле оказывается в очереди и приходит тише и позже себя же.
     */
    synth_perc_retrigger((voice < 0) ? s_perc_lane_voice[lane] : voice, vel, 1.0f);
}

/*
 * THE FILLS, and why they are a table rather than an arithmetic.
 *
 * The fill used to be one thing: the snare running down the second half of the bar at a rising
 * level, sixteen to the bar. It is a good fill and it was the only one, so a cycle that filled
 * every fourth bar filled it the same way for as long as the instrument was on. A drummer does
 * not do that — they play the roll, or the tom figure, or the pickup with air around it, and
 * which one they play is the difference between a part and a loop.
 *
 * So: fifteen figures, fourteen written on the sixteen-position grid and each using only the
 * second half of the bar, and one that is drawn rather than written — the kick break below — and
 * each chosen at random when the fill is decided and never the same figure twice in
 * a row, where chosen at random when the fill is decided and never the same figure twice in
 * a row. The first six are the figures a rock drummer plays; the next eight are the ones that
 * say something else — the break with the kick alone, the snare ladder that walks from eighths
 * into sixteenths, the answer with the toms, the pair of kicks, the hat doing the fill instead
 * of the snare, the one hit in air before the bar line. Diversity here is not decoration: a
 * cycle that fills every fourth bar played the same six figures for as long as the instrument
 * was on, and the ear learns six in an evening. Every one of them is a rhythm a drummer plays — the sixteenths stay sixteenths, the
 * eighths stay eighths, and none of them puts a hit on an odd sixteenth that is loud enough to
 * argue with SWING. The kick's bits are marked so that a fill can land on the beat without
 * losing its weight under the rest of the kit.
 *
 * THE CRESCENDO IS THE RAMP, not a written level: every figure runs from the same quiet
 * beginning to the same loud end, which is what makes a fill lead anywhere. Writing the levels
 * into the table would have made six ramps to keep in tune with each other.
 */

#define PERC_FILL_COUNT 15

static const uint16_t s_perc_fills[PERC_FILL_COUNT][PERC_LANE_COUNT] = {
    /*  KICK     SNARE    HAT      TOM      */
    { 0x0000u, 0xFF00u, 0x0000u, 0x0000u }, /* snare roll, sixteen at a time */
    { 0x0000u, 0x5500u, 0x0000u, 0xAA00u }, /* snare on the eighths, tom between them */
    { 0x0000u, 0x0000u, 0x0000u, 0xFF00u }, /* tom roll, the other hand */
    { 0x1100u, 0x6600u, 0x0000u, 0x0000u }, /* kick on three and four, snare around it */
    { 0x0000u, 0x0F00u, 0x0000u, 0x0000u }, /* the pickup: beat three only, then air */
    { 0x0100u, 0xF000u, 0x0000u, 0x0000u }, /* one hit with the kick, then the last beat */
    /*
     * Восемь, которые говорят другое. Все — вторая половина, как и первые шесть: такт
     * входит в филл и после него остаётся только филл.
     */
    { 0x1000u, 0x8000u, 0x0000u, 0x0000u }, /* удар в воздух: бочка на четыре, снейр на последнюю */
    { 0x5900u, 0x0000u, 0x5500u, 0x0000u }, /* провал: только бочка с восьмыми хэта */
    { 0x0000u, 0xF500u, 0x0000u, 0x0000u }, /* лестница по снейру: восьмые, потом шестнадцатые */
    { 0x0100u, 0x1100u, 0x0000u, 0xAA00u }, /* ответ тома: снейр на третью и четвёртую, том между */
    { 0x2100u, 0x4400u, 0x5500u, 0x0000u }, /* бочка на третью и на «и» четвёртой, снейр в щели */
    { 0x1100u, 0x0000u, 0xFF00u, 0x0000u }, /* филл делает хэт, снейра нет вовсе */
    { 0x1000u, 0x8200u, 0x0000u, 0x0000u }, /* разрежение: два удара и больше ничего */
    { 0x0000u, 0x4900u, 0x9200u, 0x0000u }, /* тройками: снейр и хэт вразножку */
    /*
     * ПЯТНАДЦАТЫЙ РИСУЕТСЯ, А НЕ НАПИСАН, поэтому его строка пуста: сюда попадает бочка,
     * собранная на баре заново (см. perc_new_bar). Удары — третий шаг каждой доли, по одному
     * на долю, и какие из четырёх долей достались — решает жребий.
     */
    { 0x0000u, 0x0000u, 0x0000u, 0x0000u },
};

#define PERC_FILL_KICK_STEPS 14

/* A new bar: the groove may be varied, and this is where the fill and the walk are decided. */
static void perc_new_bar(uint64_t bar, int n)
{
    const perc_groove_t *g = perc_groove();
    const float var = clamp01f(s_param[SYNTH_PARAM_PERC_VARIATION]);
    const float fill = clamp01f(s_param[SYNTH_PARAM_PERC_FILL]);

    for (int l = 0; l < PERC_LANE_COUNT; l++) {
        s_perc_hit[l] = g->hit[l];
    }
    s_perc_ghost = g->ghost;

    /*
     * THE VARIATION IS A MOVE, CHOSEN ONCE PER CYCLE AND HELD FOR IT.
     *
     * What it used to be was a rotation of the snare, the hats and the ghosts by one sixteenth,
     * re-rolled every bar, plus a kick on a random empty step. Three things were wrong with
     * that, and all three are audible. A rotation by a sixteenth takes the hats off the eighths
     * and puts them on the odd sixteenths — the ones SWING moves — so a varied bar sounded
     * like a drummer losing the grid, which is the same fault the written techno bar had. The
     * rotation moved every lane together, so nothing answered anything: the bar was the same
     * bar, shifted, and the ear hears a mistake rather than a variation. And it was re-rolled
     * per bar, so a four-bar cycle had four different wagons and no shape at all.
     *
     * A move is the smallest edit that still says something, and each one keeps the downbeat
     * and stays inside the grid: ghosts under the written part, a kick pushed onto the & of the
     * third beat, a snare pickup on the a of the fourth, or the quarter-note hats dropped to
     * leave the offbeats alone. One move, or two when the knob is high, and the same two for
     * the whole cycle — so a cycle is a sentence and the next one answers it.
     */
    const uint64_t cycle_len = (uint64_t)g->cycle;
    const uint64_t in_cycle = (cycle_len > 0u) ? (bar % cycle_len) : 0u;

    if (in_cycle == 0u) {
        s_perc_var_move[0] = -1;
        s_perc_var_move[1] = -1;

        /* The first cycle is the written part, whatever the knob says: the player has to hear
         * what they chose before they hear it changed. */
        if (bar >= cycle_len && perc_rand01() < var) {
            s_perc_var_move[0] = (int)(perc_rand01() * (float)PERC_VAR_MOVES);
            if (s_perc_var_move[0] >= PERC_VAR_MOVES) {
                s_perc_var_move[0] = PERC_VAR_MOVES - 1;
            }
            if (perc_rand01() < var * 0.35f) {
                int second = (int)(perc_rand01() * (float)(PERC_VAR_MOVES - 1));
                if (second >= PERC_VAR_MOVES - 1) {
                    second = PERC_VAR_MOVES - 2;
                }
                if (second >= s_perc_var_move[0]) {
                    second++;
                }
                s_perc_var_move[1] = second;
            }
        }
    }

    perc_var_apply(s_perc_var_move[0]);
    perc_var_apply(s_perc_var_move[1]);

    const bool cycle_end = ((bar + 1u) % (uint64_t)g->cycle) == 0u;
    s_perc_filled = cycle_end && (perc_rand01() < fill);

    /*
     * РАТЧЕТ, тем же FILL и заметно реже его: вероятность 0.35 от филла. Он не привязан к
     * концу цикла — филл закрывает фразу, а ратчет просто украшение, и появляться он должен
     * неожиданно, а не в предсказуемом месте.
     */
    s_perc_ratchet_step = -1;
    s_perc_ratchet_lane = -1;
    s_perc_ratchet_div = 0;
    s_perc_rat_left = 0;

    if (n > 0 && fill > 0.02f && perc_rand01() < fill * 0.35f) {
        static const int divs[3] = { 3, 4, 6 };
        const float pick = perc_rand01();

        /*
         * НА БОЧКЕ РАТЧЕТА НЕТ И БЫТЬ НЕ ДОЛЖНО.
         *
         * Ратчет — украшение на том, что держит время: хэт, снейр, том. Бочка держит саму
         * долю, и дробь по ней слышна не как украшение, а как сбитая сетка: два удара ногой
         * вплотную не играют ни в одном рисунке.
         */
        s_perc_ratchet_lane = (pick < 0.62f) ? PERC_LANE_HAT
                            : ((pick < 0.88f) ? PERC_LANE_SNARE : PERC_LANE_TOM);

        if (s_perc_ratchet_lane == PERC_LANE_KICK) {
            s_perc_ratchet_lane = PERC_LANE_HAT;
        }
        s_perc_ratchet_div = divs[(int)(perc_rand01() * 3.0f) % 3];
        s_perc_ratchet_step = (int)(perc_rand01() * (float)n) % n;
    }
    /* В техно открытого хэта нет: он приходится на последнюю долю, где уже стоит бочка, и
     * его длинный хвост спорит с ударом. У остальных грувов он закрывает фразу, здесь —
     * мешает. */
    s_perc_open_hat = cycle_end && !s_perc_filled;

    if (s_perc_filled) {
        /*
         * WHICH FILL, and not the same one twice running: the point of having six is that the
         * ear does not learn the cycle. s_perc_fill_pick starts at zero and moves by at least
         * one every time, so two fills in a row always differ even when the draw repeats.
         */
        int pick = (int)(perc_rand01() * (float)PERC_FILL_COUNT);
        if (pick >= PERC_FILL_COUNT) {
            pick = PERC_FILL_COUNT - 1;
        }
        if (pick == s_perc_fill_pick) {
            pick = (pick + 1) % PERC_FILL_COUNT;
        }
        /*
         * ГРОУВ БЕЗ СНЕЙРА — И ФИЛЛ БЕЗ СНЕЙРА.
         *
         * В техно снейровой дорожки нет вовсе, и любой снейровой филл был бы единственным
         * снейром в баре. Раньше здесь стояла одна зашитая фигура — раскат по тому, — и
         * получалось, что такт с филлом звучит одинаково, сколько ни играй: владелец услышал
         * это сразу, «каждый раз один и тот же филл из восьми ударов».
         *
         * Бесснейровых фигур теперь четыре, и одна из них берётся жребием, с той же защитой
         * от повтора, что и у общего выбора.
         */
        if (s_perc_hit[PERC_LANE_SNARE] == 0u) {
            static const int quiet[4] = { 2, 7, 11, 14 };   /* том, бочка-брейк, хэт, бочка-жребий */
            int q = (int)(perc_rand01() * 4.0f);

            if (q >= 4) {
                q = 3;
            }
            pick = quiet[q];

            if (pick == s_perc_fill_pick) {
                pick = quiet[(q + 1) % 4];
            }
        }
        s_perc_fill_pick = pick;

        /*
         * БОЧКОВЫЙ ПЕРЕБИВ: ЕДИНСТВЕННЫЙ РИСУНОК, КОТОРЫЙ НЕ НАПИСАН, А ТЯНЕТСЯ.
         *
         * Третий шаг каждой доли — то место, где рука ставит «и» перед долей и где у бочки
         * обычно пусто. Один удар на долю и никогда два: перебив из одних только этих ударов
         * звучит как барабанщик, который бросает рисунок и добивает такт одной ногой.
         *
         * Какие доли достались, решает жребий на каждом таком филле: иногда один удар за весь
         * такт, иногда три. Поэтому жребий и нужен — фиксированный набор из четырёх звучал бы
         * четвёрками, а это уже не перебив.
         */
        if (pick == PERC_FILL_KICK_STEPS) {
            static const uint16_t beat_third[4] = { 0x0004u, 0x0040u, 0x0400u, 0x4000u };
            const int how_many = 1 + (int)(perc_rand01() * 3.0f);   /* один, два или три */
            uint16_t mask = 0x0000u;

            /* Перемешивание четырёх долей и берём первые how_many: так их ровно столько,
             * сколько выпало, и ни одна не достаётся дважды. */
            int order[4] = { 0, 1, 2, 3 };

            for (int i = 3; i > 0; i--) {
                const int j = (int)(perc_rand01() * (float)(i + 1));
                const int t = order[i];
                order[i] = order[j];
                order[j] = t;
            }

            for (int i = 0; i < how_many; i++) {
                mask |= beat_third[order[i]];
            }

            if (mask == 0x0000u) {
                mask = beat_third[3];   /* жребий не сошёлся — одна доля, последняя */
            }

            /* Бочка звучит на всём такте — только этими ударами: филл перебивает рисунок, а
             * не добавляется к нему. Остальные дорожки остаются в первой половине и молчат
             * во второй, как и в любом другом филле. */
            s_perc_hit[PERC_LANE_KICK] = mask;

            for (int l = 1; l < PERC_LANE_COUNT; l++) {
                s_perc_hit[l] = (uint16_t)(s_perc_hit[l] & 0x00FFu);
            }
        } else {
            /* The figure replaces the written part in the second half and leaves the first half
             * alone, so the bar walks into the fill and the fill is the only thing after it. The
             * written ghosts go with it: a quiet hat under a fill is a fill with somebody talking. */
            for (int l = 0; l < PERC_LANE_COUNT; l++) {
                s_perc_hit[l] = (uint16_t)((s_perc_hit[l] & 0x00FFu) | s_perc_fills[pick][l]);
            }
        }
        s_perc_ghost = (uint16_t)(s_perc_ghost & 0x00FFu);
    }

    for (int l = 0; l < PERC_LANE_COUNT; l++) {
        s_perc_motion[l] = perc_timbre() * 1.6f * (perc_rand01() * 2.0f - 1.0f);
    }

    s_perc_bar_seen = bar;

    for (int l = 0; l < PERC_LANE_COUNT; l++) {
        s_perc_show_hit[l] = s_perc_hit[l];
    }
    s_perc_show_ghost = s_perc_ghost;
    s_perc_show_fill = s_perc_filled;
    s_perc_show_open_hat = s_perc_open_hat;
}

/* The part as written: the chosen groove, before the variation and the fill have touched it.
 * Used while the drum is stopped and after a knob moves, so that what is shown is what was
 * chosen. See the note over s_perc_show_hit. */
static void perc_show_written(void)
{
    const perc_groove_t *g = perc_groove();

    for (int l = 0; l < PERC_LANE_COUNT; l++) {
        s_perc_show_hit[l] = g->hit[l];
    }
    s_perc_show_ghost = g->ghost;
    s_perc_show_fill = false;
    s_perc_show_open_hat = false;
}

/* One drum step: what plays on it, and nothing about when it is due. */
static void perc_fire_step(void)
{
    const int n = perc_steps();
    if (n <= 0) {
        return;
    }
    const uint64_t p = s_perc_step;
    s_perc_step = p + 1u;

    if (perc_reset_due(p) && perc_restart_free()) {
        s_perc_origin = p;
    }

    const uint64_t phrase = (p >= s_perc_origin) ? (p - s_perc_origin) : 0u;
    const uint32_t local = (uint32_t)(phrase % (uint64_t)n);
    const uint64_t bar = phrase / (uint64_t)n;
    s_perc_index = local;

    if (bar != s_perc_bar_seen) {
        perc_new_bar(bar, n);
    }

    /* фаза двигается в блоке, см. ниже */

    /* The groove is sixteen positions wide and the drum's grid is n: one maps onto the other
     * by proportion, so a written part plays on any division of the bar. */
    const uint32_t at = (uint32_t)((uint64_t)local * (uint64_t)PERC_GROOVE_STEPS / (uint64_t)n);

    if (s_perc_filled && local >= (uint32_t)(n / 2)) {
        /*
         * The fill: whatever figure this bar took, running from quiet to loud across the half.
         * The rest of the kit stops, which is what leaves room for it — and the figure itself
         * is in s_perc_hit, so the ring of dots shows the rhythm that is about to play rather
         * than a block that says "a fill happens here".
         */
        const uint32_t half = (uint32_t)(n / 2);
        const uint32_t in_half = local - half;
        const float ramp = (half > 1u) ? ((float)in_half / (float)(half - 1u)) : 1.0f;
        const float v = 0.34f + 0.56f * ramp;

        int count = 0;
        for (int l = 0; l < PERC_LANE_COUNT; l++) {
            if ((s_perc_hit[l] >> at) & 1u) {
                count++;
            }
        }
        const float gain = perc_simul_gain(count);

        for (int l = 0; l < PERC_LANE_COUNT; l++) {
            if ((s_perc_hit[l] >> at) & 1u) {
                perc_strike(l, ((l == PERC_LANE_KICK) ? 0.85f : v) * gain);
            }
        }
        return;
    }

    float velocity = figure_velocity_for(accent_index_perc(), local, n);

    /* Сколько дорожек бьёт в этот шаг: по нему и громкость, см. perc_simul_gain(). */
    int count = 0;
    for (int l = 0; l < PERC_LANE_COUNT; l++) {
        if ((s_perc_hit[l] >> at) & 1u) {
            count++;
        }
    }
    velocity *= perc_simul_gain(count);

    for (int l = 0; l < PERC_LANE_COUNT; l++) {
        if ((s_perc_hit[l] >> at) & 1u) {
            perc_strike(l, velocity);
        }
    }

    /* The ghosts: the written part's quiet hats, which are most of the difference between a
     * metronome and a drummer. */
    if ((s_perc_ghost >> at) & 1u) {
        perc_strike(PERC_LANE_HAT, 0.22f);
    }

    /*
     * The open hat closes the cycle — and in TECHNO it closes it one step EARLY.
     *
     * На последнем шаге бара в техно стоит бочка, и открытый хэт с его длинным хвостом бил
     * прямо в удар: владелец попросил его убрать. Убран он здесь не целиком, а сдвинут на
     * слабую долю перед ней — там хэт отвечает бочке, а не спорит с ней.
     */
    /*
     * РАТЧЕТ на этом шаге: удары раскладываются по блокам внутри шага, начиная со
     * следующего — первый удар шага уже прозвучал выше.
     */
    if (s_perc_ratchet_step >= 0 && (int)local == s_perc_ratchet_step && s_perc_ratchet_div > 1) {
        const float bar_blocks = (float)bar_blocks_now();
        const float step_blocks = (bar_blocks > 0.0f) ? (bar_blocks / ((float)n * perc_speed())) : 0.0f;

        if (step_blocks > 0.0f) {
            s_perc_rat_left = s_perc_ratchet_div - 1;
            s_perc_rat_lane = s_perc_ratchet_lane;
            s_perc_rat_gap = step_blocks / (float)s_perc_ratchet_div;
            s_perc_rat_wait = s_perc_rat_gap;
        }
    }

    /*
     * ОТКРЫТЫЙ ХЭТ: своя маска в груве, свой голос. Бьёт одновременно с закрытым, и это
     * удвоение — не ошибка, а сам приём: закрытый даёт точку, открытый хвост под ней.
     */
    {
        const uint16_t open_mask = perc_groove()->open;

        if (open_mask != 0u && local < 16u && (((uint32_t)open_mask >> local) & 1u) != 0u) {
            perc_strike(PERC_LANE_HAT, 0.46f, PERC_VOICE_OPEN, 6.0f, 0.90f, 0.80f, true);
        }
    }

    if (s_perc_open_hat && perc_groove_index() != PERC_GROOVE_TECHNO
        && local == (uint32_t)(n - 1)) {
        perc_strike(PERC_LANE_HAT, 0.50f, PERC_VOICE_OPEN, 6.0f, 0.90f, 0.80f, true);
    }
}

static void perc_tick(void)
{
    /*
     * THE DRUM'S PHRASE HAS AN ORIGIN OF ITS OWN, the exact counterpart of the lead's
     * s_seq_origin in the RESET section below — and the two are separate variables written
     * by separate gestures, which is the whole of why neither can move the other.
     *
     * A CHANGE OF STEPS RE-ANCHORS IT ON THE BAR, for the reason the lead's origin does:
     * the same bar divided differently is a different count of steps, and a phrase position
     * inherited across that change would be a number from a grid that no longer exists.
     */
    const uint32_t n = (uint32_t)perc_steps();

    if (n != s_perc_grid) {
        s_perc_origin = 0;
        s_perc_step = 0;
        s_perc_acc = 0.0f;
        s_perc_bar_seen = ~0ull;
        s_perc_grid = n;
        s_perc_hit_first = true;
    }

    /*
     * A CHANGE OF SPEED WAITS FOR THE BAR LINE AND THEN RE-ANCHORS ONCE. The ratios are exact
     * and the transport never moves, but the drum's counter is its own: without this the drum
     * would change gear wherever it happened to be and land its first step of the new speed
     * in the middle of a beat. Waiting for the bar line costs at most one bar and keeps the
     * one promise the knob makes — the drum comes back to the bar and stays there.
     */
    const int speed_now = perc_speed_index();
    if (speed_now != s_perc_speed_seen) {
        s_perc_speed_seen = speed_now;
        s_perc_realign = true;
    }
    if (s_perc_realign && s_tp_bar != s_perc_tp_bar_seen) {
        s_perc_step = 0;
        s_perc_origin = 0;
        s_perc_acc = 0.0f;
        s_perc_pending = 0u;
        s_perc_bar_seen = ~0ull;
        s_perc_realign = false;
        s_perc_hit_first = true;
    }
    s_perc_tp_bar_seen = s_tp_bar;

    /*
     * THE DRUM'S OWN CLOCK, and SPEED is the whole point of it having one: the transport says
     * how long a bar is, and the drum decides how many of its own steps to fit into it. A
     * step is therefore a fraction of a block, and the fraction is carried between blocks
     * rather than rounded — the alternative is a drum that drifts a block every bar.
     *
     * One step per block at most. At the fastest the drum goes — ×2 at 300 BPM — a step is
     * 1200 samples, which is nearly five blocks, so the cap is never reached by the sound
     * and is here only so that a block which somehow owes two steps cannot strike twice in
     * one sample.
     */
    if (!s_running) {
        return;
    }

    const float bar_blocks = (float)bar_blocks_now();
    if (bar_blocks <= 0.0f) {
        return;
    }
    const float steps_per_block = (float)n * perc_speed() / bar_blocks;

    if (s_perc_pending > 0u) {
        s_perc_pending--;
        if (s_perc_pending == 0u) {
            perc_fire_step();
        }
    }

    /*
     * Ратчет идёт по блокам внутри своего шага, независимо от шагового счётчика.
     */
    if (s_perc_rat_left > 0) {
        s_perc_rat_wait -= 1.0f;
        if (s_perc_rat_wait <= 0.0f) {
            perc_strike(s_perc_rat_lane, 0.45f);
            s_perc_rat_left--;
            s_perc_rat_wait += s_perc_rat_gap;
        }
    }

    /*
     * НУЛЕВОЙ ШАГ БЬЁТ В БЛОКЕ ПУСКА. Копитель начинает с нуля и переваливает через единицу
     * только через полную шестнадцатую, поэтому раньше барабан всегда опаздывал на шаг
     * против лида — тот берёт шаг прямо из позиции транспорта. Копитель в этом блоке не
     * двигается: шаг уже сыгран, и счёт от него идёт дальше.
     */
    if (s_perc_hit_first) {
        s_perc_hit_first = false;
        s_perc_acc = 0.0f;
        s_perc_pending = 0u;
        perc_fire_step();
        return;
    }

    s_perc_acc += steps_per_block;
    if (s_perc_acc >= 1.0f) {
        s_perc_acc -= 1.0f;
        if (s_perc_acc > 1.0f) {
            s_perc_acc = 1.0f;
        }
        /* SWING: every second step waits, and the wait is a fraction of a step in blocks. */
        const uint32_t swing_blocks =
            (uint32_t)(perc_swing_frac() * 0.5f * bar_blocks / (float)n + 0.5f);
        if (((s_perc_step % 2u) == 1u) && swing_blocks > 0u && s_perc_pending == 0u) {
            s_perc_pending = swing_blocks;
        } else {
            perc_fire_step();
        }
    }
}

/*
 * START, and the whole of what it means: the transport runs and the position goes back
 * to the first step of the bar.
 *
 * THE FIGURES HAVE NO PLAYHEADS OF THEIR OWN ANY MORE. The lead's grid, the drum's
 * figure and the arp's phrase all derive their step from the one position, so putting
 * that position on zero puts all three on their first steps in the same block, and
 * there is nothing else to reset. The step memories are marked "no step seen yet", so
 * each of them takes step zero in this block instead of waiting for a boundary, and the
 * three phrase origins — the lead's, the drum's and the arp's — are zeroed with the
 * position, because START is the one moment every figure begins together by definition.
 * Neither RESET comes through here: each is a gesture on its own part, see the section
 * below.
 *
 * THE NOTE THAT IS ALREADY SOUNDING IS LEFT ALONE. s_seq_gate_left counts down to the
 * release of the note the sequencer opened last, and zeroing it here would leave that
 * note with nothing to release it — a stuck note at the foot of the bar, which is the
 * one failure a transport reset must not cause. It expires a step later as it always
 * would, and the note that begins the new bar begins after it. The same is true of the
 * drum, whose DECAY is its gate and has no note-off at all.
 *
 * THE HELD KEYS ARE NOT TOUCHED EITHER: the arp moves to the top of its phrase with the
 * position, and whether it plays over the player's hands is still decided where it
 * always was — see arp_tick() and midi_gate_tick().
 */
static void midi_transport_reset(void)
{
    tp_restart();

    s_seq_origin = 0;
    s_arp_origin = 0;
    s_lead_grid = 0;
    s_lead_grid_prev = (uint32_t)~0u;

    s_seq_prev = (uint32_t)~0u;
    s_seq_pending = 0;
    s_seq_current = 0;

    s_perc_prev = (uint32_t)~0u;
    s_perc_origin = 0;
    s_perc_grid = 0;
    s_perc_index = 0;
    s_perc_acc = 0.0f;
    s_perc_pending = 0u;
    s_perc_hit_first = true;

    s_arp_prev = ~(uint64_t)0;
}

/* -------------------------------------------------------------------------- */
/* RESET                                                                      */
/* -------------------------------------------------------------------------- */
/*
 * RESET IS A MUSICAL GESTURE, AND EACH PART HAS ONE OF ITS OWN.
 *
 * There is nothing left to repair. Every figure takes its step from the one transport, so
 * two figures cannot drift apart, and a realignment mechanism would be a second phase
 * writing over the first — which is exactly the defect that produced the 659-block cycle
 * the owner heard. What a RESET parameter does instead is what a reset button does on
 * purpose: every N steps the phrase begins again. There are two of them, one per sequencer
 * and each on its own grid: SYNTH_PARAM_SEQ_RESET moves the LEAD's figure,
 * SYNTH_PARAM_PERC_RESET moves the DRUM's. A gesture aimed at one player must not stop the
 * other in the middle of a step: a polyrhythm is two figures disagreeing on purpose, and a
 * correction they both obey is no polyrhythm at all. So the lead's gesture never touches the
 * drum and the drum's never touches the lead, at any values of either period — and neither
 * of them touches the ARPEGGIATOR, which is a third player: the chord the hand is holding,
 * counted from an origin of its own. See the note where the lead's gesture fires.
 *
 * HOW THAT IS EXACT WITHOUT A SECOND COUNTER, AND WHY THEY STAY INDEPENDENT. The transport
 * position is one and stays one, and it is never written by either gesture. Each phrase is
 * an ORIGIN on the transport's own grid: s_seq_origin is the grid step the lead's phrase
 * began on, s_perc_origin the same for the drum's, and a phrase step is
 * (grid_step - origin) % n. Rewinding a phrase is writing a new origin for it, so nothing
 * else that reads the position can move by even a block, and neither parameter can reach
 * the other's origin — they are distinct variables written in distinct blocks of code. The
 * arp's origin is its own step number, set when the arp takes the lead and by nothing else,
 * so the pattern the chord plays is continuous across every sequencer gesture.
 *
 * N IS COUNTED IN STEPS OF THE GRID THE PLAYER SEES — the lead's STEPS on the LEAD EUCLID
 * page, the drum's STEPS on the PERC SEQ page — and it is an integer comparison of that
 * grid's own step numbers, so the gesture lands on a step boundary by construction. A knob
 * turned down to a smaller N while a step is running therefore fires at the next boundary
 * and never in the middle of a gate. Nothing counts blocks, nothing counts a generator's
 * index, so the gesture cannot lag behind the transport or run away from it while the arp
 * holds the lead.
 *
 * NOTHING IS CUT. At the boundary the lead's gesture lands on, the previous step's gate has
 * already expired — a gate is at most the step — so the note the gesture replaces has been
 * released and the new phrase's first note follows it. The ARP's note, if one is sounding,
 * is left alone: the gesture does not move the arp's origin, does not release its group and
 * does not force its next note, so the chord the hand is holding keeps arpeggiating across
 * the rewind without a stutter. No gate counter is zeroed.
 *
 * A SPARSE FIGURE HAS GATES LONGER THAN A STEP. The gate is a fraction of the distance to
 * the NEXT ONSET, so a figure marking four of twelve steps holds its notes for a step and a
 * half. When the lead is the figure playing, the gesture therefore waits for the first
 * boundary at which that note's gate has expired, and restarts the phrase there: the restart
 * can be a step or two later than the bare count, and it is never a cut. A dense figure —
 * every step an onset, which is the factory setting — is free at every boundary, so its
 * period is exactly N steps.
 *
 * THE DRUM HAS NO GATE AT ALL, so its gesture waits on its DECAY instead: a hit's envelope
 * is its only release, the render path reports how many voices are still sounding
 * (synth_perc_active_voices()), and the drum's gesture fires only at a boundary on which
 * that count is zero — see perc_tick(), which owns it and the origin it writes. The restart
 * lands on step zero of the phrase, and at ROTATE zero that step is an onset in every
 * Euclidean figure, so firing it into a ringing tail would double a hit rather than
 * celebrate one; with a rotation step zero may be a rest, and the wait there costs a single
 * boundary. A decay shorter than a step is over by the next boundary and the period is exact;
 * a longer one waits for the first quiet boundary, and a figure that sounds on every step
 * with a decay longer than that step has no quiet boundary at all — there the gesture keeps
 * waiting instead of stacking a hit on a tail, the stated price of "the previous hit has
 * sounded out".
 *
 * THE ONE THING THE LEAD'S GESTURE DROPS is a SCATTER note already scheduled for the step it
 * is abandoning: it was a fraction of a step ahead of the note it belonged to, and that note
 * no longer exists. At SCATTER's factory value of zero nothing is ever scheduled ahead, so
 * there is nothing to drop. The drum has no scatter, so its gesture drops nothing.
 *
 * N = 0 IS INF: the gesture is off and nothing happens at all. An N that is a whole number of
 * bars for the grid in force (16 on a sixteen-step grid) lands on the bar line the phrase was
 * going to start at anyway, so it is inaudible rather than wrong; an N that is not (16 on a
 * twelve-step grid) rewinds that phrase early, which is the gesture. Each value is a patch
 * parameter, read the way every list is read, so the number on the page and the period the
 * audio task uses cannot disagree.
 *
 * A CHANGE OF STEPS RE-ANCHORS THAT PHRASE ON THE BAR, in both sequencers. The same bar
 * divided differently is a different count of steps, and a phrase position inherited across
 * that change would be a number from a grid that no longer exists. The origin is therefore
 * set to bar * n at the change, so the phrase stands on the bar's own step and the new period
 * runs from there.
 */
static int reset_step_count(void)
{
    return reset_step_count_for(SYNTH_PARAM_SEQ_RESET);
}

/* The gesture is due when the phrase has stood on N steps of the grid. Integers only:
 * g and the origin are step numbers of the same grid, so there is no rounding here. */
static bool reset_due(uint64_t g)
{
    const int steps = reset_step_count();
    if (steps <= 0) {
        return false;
    }
    if (g < s_seq_origin) {
        return false;
    }
    return (g - s_seq_origin) >= (uint64_t)steps;
}

static void seq_tick(void)
{
#if SEQ_TRACE_ENABLE
    s_trace_block++;
#endif

    /*
     * The lead's phrase bookkeeping first, and every block, whatever the arp is doing.
     * The gesture is allowed to fire only on a step boundary of the transport's grid:
     * that is what makes it unable to cut a gate, and it is why the step is remembered
     * here rather than inside the lead branch, which the arp skips.
     */
    const uint32_t n = (uint32_t)seq_steps_for(s_param[SYNTH_PARAM_SEQ_STEPS]);
    if (n != s_lead_grid) {
        s_seq_origin = s_tp_bar * (uint64_t)n;
        s_lead_grid = n;
    }

    const uint32_t lead_local = tp_index(n);
    const bool lead_step = (lead_local != s_lead_grid_prev);
    s_lead_grid_prev = lead_local;
    const uint64_t g = s_tp_bar * (uint64_t)n + (uint64_t)lead_local;

    /*
     * The gesture: the lead's phrase and the arp's begin again, the position does not
     * move. The arp's first note is forced in this block, because its own step may be
     * in the middle: that is the documented replacement, not a cut with a release.
     *
     * WHEN THE LEAD IS THE ONE PLAYING, the gesture waits for a boundary at which the
     * note it opened has finished its gate (s_seq_gate_left is the count BEFORE this
     * block's decrement, so 1 means the release happens in this block). A sparse figure
     * gives its notes a gate longer than a step — the gate is a fraction of the distance
     * to the next onset — and firing step zero on a boundary inside that gate would cut
     * a note the player is still hearing. Waiting moves the restart to the first
     * boundary at which the lead is free; nothing is ever released early.
     */
    const bool phrase_free = arp_active() || (s_seq_gate_left <= 1u);

    if (lead_step && phrase_free && reset_due(g)) {
        /*
         * THE GESTURE IS THE LEAD'S FIGURE AND NOTHING ELSE. It used to take the arp's
         * origin with it and force the arp's first note in the same block, which meant a
         * RESET landed in the middle of a chord the player was holding and restarted the
         * pattern under their fingers — a rewind of the sequencer, heard as a stutter in
         * the arpeggio. The arp is not the phrase: it is the player's own notes, timed
         * from an origin of its own, and the only thing that may move that origin is the
         * arp's own start or a change of its grid.
         */
        s_seq_origin = g;
        s_seq_pending = 0;
#if SEQ_TRACE_ENABLE
        SEQ_TRACE("R block=%" PRIu32 " bar=%" PRIu32 " n=%d",
                  s_trace_block, (uint32_t)s_tp_bar, (int)n);
#endif
    }

    /* The percussion ticks on this clock but not inside this figure: it has its own
     * STEPS, its own step and its own origin, so the two play against each other. The
     * gesture above cannot reach it — it writes the lead's origin, and perc_tick() writes
     * the drum's — and the drum's gesture cannot reach the lead for the same reason. */
    perc_tick();

    /*
     * THE GATE'S EXPIRY NO LONGER RELEASES THE LEAD, and this counter is only the
     * arp's now. The sequencer's notes each own a gate of their own — see
     * lead_gen_tick() — because with overlapping steps there is no single "the note"
     * for one counter to let go of. What is left here is the arpeggiator, which does
     * still play one note in one group at a time: its gate is this number, and its
     * expiry hands its group back. seq_release() must not be called here in either
     * case: with a key down it would take the player's chord, and without one it would
     * cut the tails of notes the generator is still sounding.
     */
    if (s_seq_gate_left > 0) {
        s_seq_gate_left--;
        if (s_seq_gate_left == 0 && midi_note_active()) {
            lead_arp_group_off();
        }
    }

    lead_gen_tick();

    /*
     * The arp's claim on the lead, BEFORE the branch below: the block DIR changes under a
     * held chord is the block the other side of the change has to be silent on, and it has
     * to be one block for both — a chord released one block late would be a note left open
     * with nothing counting its gate. See arp_lead_tick().
     */
    arp_lead_tick();

    /*
     * The arp, when it is on, REPLACES the Euclidean figure rather than playing
     * alongside it. They are two answers to one question — what does the generator
     * play next — and running both would put two lines on the generator's group,
     * which is the group they share whenever the arp is playing its own figure.
     * That the arp is in a group of its own while keys are held does not make it a
     * second figure: it is still the one the question is about.
     */
    if (arp_active()) {
        /* The lead's own step memory follows the grid while the arp has the line. It
         * owns no note then, but when the arp is switched off the lead must resume on
         * the next boundary of the bar and not in the middle of the step the arp left
         * it standing in. */
        s_seq_prev = lead_local;
        arp_tick();
        return;
    }

    /*
     * The lead's step is the position's, not a countdown's.
     *
     * s_seq_pending holds a note SCATTER pulled away from its boundary. It is counted
     * down every block, so a note due inside a step fires where it was meant to; a note
     * the new boundary overtakes — only possible when a tempo change makes the step
     * shorter than the offset it was given — is fired at the boundary instead of being
     * lost, and the new step's own onset is then delayed by one block so the two cannot
     * land together. With SCATTER at zero, its factory value, nothing is ever pending at
     * a boundary and this cannot happen.
     */
    bool sounded = false;

    if (s_seq_pending > 0) {
        s_seq_pending--;
        if (s_seq_pending == 0) {
            seq_fire();
            sounded = true;
        }
    }

    const uint32_t local = lead_local;

    if (local == s_seq_prev) {
        return;
    }
    s_seq_prev = local;

    if (s_seq_pending > 0) {
        s_seq_pending = 0;
        seq_fire();
        sounded = true;
    }

    s_seq_n = (int)n;
    s_seq_k = seq_pulses();
    s_seq_rot = seq_rotate();

    /*
     * WHICH STEP OF THE PHRASE THIS IS. The boundaries are the transport's (local), but
     * the pattern is numbered from the origin, so the phrase begins on step zero of the
     * figure whenever the gesture last moved the origin. The two numbers are kept apart
     * on purpose: the pattern, the accents and the display want the phrase step; the
     * gate wants the length of the transport step this note physically occupies, and
     * that is local.
     */
    const uint32_t phrase_local = (g >= s_seq_origin)
                                ? (uint32_t)((g - s_seq_origin) % (uint64_t)n) : 0u;

    const uint32_t grid_blocks = phrase_step_blocks(bar_blocks_now(), n, local);
    s_seq_current = phrase_local;

    const float half_step = (float)grid_blocks * 0.5f
                          * s_param[SYNTH_PARAM_SEQ_SCATTER];

    if (seq_is_onset(phrase_local, s_seq_n, s_seq_k, s_seq_rot)) {
        const int32_t off = (int32_t)(seq_jitter(phrase_local, 0x9E37u) * half_step);
        s_seq_fire_index = phrase_local;
        s_seq_fire_raw = local;
        if (sounded) {
            s_seq_pending = 1u;
        } else if (off > 0) {
            s_seq_pending = (uint32_t)off;
        } else {
            seq_fire();
        }
    } else if (seq_is_onset(phrase_local + 1u, s_seq_n, s_seq_k, s_seq_rot)) {
        /*
         * A note that wants to arrive BEFORE its grid line, which lands inside
         * this step. Only when this step has no onset of its own: one note per
         * grid step is as dense as a Euclidean rhythm should ever get, and
         * scheduling both would put two notes in the same slot.
         */
        const int32_t off = (int32_t)(seq_jitter(phrase_local + 1u, 0x9E37u) * half_step);
        if (off < 0 && (uint32_t)(-off) < grid_blocks) {
            s_seq_fire_index = phrase_local + 1u;
            s_seq_fire_raw = (local + 1u) % n;
            s_seq_pending = grid_blocks - (uint32_t)(-off);
        }
    }
}

/*
 * What the display needs.
 *
 * Both of these are ANSWERS rather than state the UI keeps a copy of, so a
 * pattern drawn on the screen cannot disagree with the pattern being played. The
 * sequencer runs in the audio task and this is read from the UI task, so the read
 * is deliberately tolerant: steps is 0 until the first grid step has latched the
 * values, and the caller skips the frame.
 */
extern "C" int synth_app_arp_active(void)
{
    return arp_active() ? 1 : 0;
}

extern "C" void synth_app_seq_view(synth_app_seq_view_t *out)
{
    if (out == nullptr) {
        return;
    }

    out->steps = s_seq_n;
    out->pulses = s_seq_k;
    out->rotate = s_seq_rot;
    out->position = (s_seq_n > 0) ? (int)(s_seq_current % (uint32_t)s_seq_n) : 0;
    out->sounding = (s_seq_gate_left > 0) ? 1 : 0;
}

extern "C" int synth_app_seq_is_onset(int position)
{
    if (position < 0 || s_seq_n <= 0) {
        return 0;
    }
    return seq_is_onset((uint32_t)position, s_seq_n, s_seq_k, s_seq_rot) ? 1 : 0;
}

/*
 * The same two answers for the drum part.
 *
 * Separate calls rather than an argument to the two above, because the two figures
 * are independent by design: the lead's grid can be taken over by the arpeggiator,
 * while the percussion plays its own whether or not anything else is running. A
 * caller that asked for "the sequencer" would have to know which one it meant.
 *
 * Nothing is latched here, unlike the lead's view. The lead latches because the
 * arpeggiator can replace its figure mid-bar; the drum's figure IS its parameters,
 * so reading them live cannot disagree with what is being struck.
 */
extern "C" void synth_app_perc_view(synth_app_seq_view_t *out)
{
    if (out == nullptr) {
        return;
    }

    const int n = perc_steps();
    out->steps = n;
    out->pulses = perc_pulses();
    out->rotate = perc_rotate();
    /* The step that is sounding: s_perc_index is the PHRASE step this block is in — its
     * origin subtracted, exactly like the lead's s_seq_current — so the cursor shows the
     * step being played and not the transport's step number, which the drum's gesture may
     * have moved away from. The dots themselves stay bar positions: the figure is drawn in
     * the bar's coordinates and only the cursor follows the phrase, as on the lead's ring. */
    out->position = (n > 0) ? (int)s_perc_index : 0;
    /* Whether the step the cursor is on is striking: asked of the part that is playing rather
     * than of a euclidean figure, because the drum's part is a written groove now and the
     * cursor's brightness has to agree with the dots. */
    out->sounding = (s_running && (synth_app_perc_step_mask(out->position) & 0x0F) != 0) ? 1 : 0;
}

/*
 * WHAT PLAYS ON ONE STEP OF THE BAR, for the ring of dots.
 *
 * The grid the drum is on maps onto the written part's sixteen positions by proportion, the
 * same mapping perc_fire_step() uses to play it — so on the default sixteen steps this is a
 * direct read and on eight or twelve it is the part compressed, which is what the ear hears.
 *
 * Asked of the state the display is drawn from and not of the parameters: the variation has
 * already moved the snare and the hats, the fill has already replaced the second half, and a
 * ring that read the tables would draw the part as written over a bar that is playing
 * something else. See s_perc_show_hit.
 */
extern "C" int synth_app_perc_step_mask(int position)
{
    const int n = perc_steps();
    if (position < 0 || position >= n || n <= 0) {
        return 0;
    }

    const uint32_t local = (uint32_t)position;
    const uint32_t at = (uint32_t)((uint64_t)local * (uint64_t)PERC_GROOVE_STEPS / (uint64_t)n);

    if (s_perc_show_fill && local >= (uint32_t)(n / 2)) {
        /*
         * The fill: the figure is in the display's bar already, so the ring shows WHERE it
         * hits and the FILL bit only says that the hit belongs to the fill — one hot hollow
         * dot per note of the figure, which is the rhythm, and not a solid band across half
         * the bar, which was a note saying "something happens here".
         */
        const int any = (int)((s_perc_show_hit[PERC_LANE_KICK] >> at) & 1u)
                      | (int)((s_perc_show_hit[PERC_LANE_SNARE] >> at) & 1u)
                      | (int)((s_perc_show_hit[PERC_LANE_HAT] >> at) & 1u)
                      | (int)((s_perc_show_hit[PERC_LANE_TOM] >> at) & 1u);
        return any ? (SYNTH_APP_PERC_STEP_FILL | SYNTH_APP_PERC_STEP_SNARE) : 0;
    }

    int mask = 0;
    if ((s_perc_show_hit[PERC_LANE_KICK] >> at) & 1u) {
        mask |= SYNTH_APP_PERC_STEP_KICK;
    }
    if ((s_perc_show_hit[PERC_LANE_SNARE] >> at) & 1u) {
        mask |= SYNTH_APP_PERC_STEP_SNARE;
    }
    if ((s_perc_show_hit[PERC_LANE_HAT] >> at) & 1u) {
        mask |= SYNTH_APP_PERC_STEP_HAT;
    }
    if ((s_perc_show_hit[PERC_LANE_TOM] >> at) & 1u) {
        mask |= SYNTH_APP_PERC_STEP_TOM;
    }
    if ((s_perc_show_ghost >> at) & 1u) {
        mask |= SYNTH_APP_PERC_STEP_GHOST;
    }
    /* The open hat closes the cycle, on the last step of the bar. */
    if (s_perc_show_open_hat && local == (uint32_t)(n - 1)) {
        mask |= SYNTH_APP_PERC_STEP_HAT;
    }
    return mask;
}

/* Whether anything at all is struck on a step: the ring's "is this an onset" question, now
 * answered from the bar rather than from a euclidean figure the drum no longer plays. */
extern "C" int synth_app_perc_is_onset(int position)
{
    return (synth_app_perc_step_mask(position) & 0x0F) != 0 ? 1 : 0;
}

/*
 * Whether a given grid position of a figure is an ACCENTED one.
 *
 * Asked rather than recomputed, for the reason synth_app_seq_is_onset() gives above:
 * the rule IS how the accent is struck, and a ring that worked it out again could
 * mark a step the engine does not accent — which is worse than marking nothing,
 * because it would look authoritative.
 *
 * A PREDICATE and not "the index of the accented step", deliberately, and the reason
 * has not changed now that the accent is a figure of several steps rather than one:
 * the ring asks each dot in turn and the answer is the whole of the rule, so nothing
 * on the display had to be rebuilt when the rule grew from one position to a mask.
 *
 * False when the figure is OFF: there is no accent then, and a dot of a different size
 * would be the display inventing one. The position is the grid step within the figure,
 * the same number the ring already draws with; the mask itself is asked in terms of
 * the step's number in the bar, which is one more than this one.
 *
 * TWO ANSWERS, one per figure, and the only difference between them is which n the
 * rule is asked with: the lead's latched figure for the ring on EUCLID, the drum's own
 * live STEPS for the ring on PERC SEQ. Each caller passes that page's own accent index,
 * so a ring cannot show one figure's accent over the other figure's grid.
 */
static int accent_marks_position(int position, int n, int accent)
{
    if (position < 0 || position >= n) {
        return 0;
    }
    if (accent == 0) {
        return 0;
    }
    return accent_marks_step(accent, (uint32_t)position, n) ? 1 : 0;
}

/* The lead's figure: n is the same latched one synth_app_seq_is_onset() answers with
 * and the same one the lead's notes are struck against, so the ring and the line agree
 * by construction. */
extern "C" int synth_app_seq_is_accent(int position)
{
    return accent_marks_position(position, s_seq_n, accent_index_seq());
}

/* The drum's. */
extern "C" int synth_app_perc_is_accent(int position)
{
    return accent_marks_position(position, perc_steps(), accent_index_perc());
}

/*
 * БАС, ДЛЯ КОЛЬЦА НА RHYTHM.
 *
 * Ровно те же вопросы, что ударке и лиду, и отвечает на них сам басовый модуль: рисунок, длина,
 * акценты и шаг — его состояние. Здесь не считается ничего своего, поэтому кольцо не может
 * разойтись с тем, что играется.
 */
extern "C" void synth_app_bass_view(synth_app_seq_view_t *out)
{
    if (out == nullptr) {
        return;
    }

    const int n = synth_bass_steps();
    out->steps = n;
    /* У баса нет ни эвклидова сдвига, ни числа импульсов: рисунок задан готовой строкой. */
    out->pulses = 0;
    out->rotate = 0;
    out->position = (n > 0) ? synth_bass_step() : 0;
    out->sounding = (s_running && synth_bass_is_onset(out->position)) ? 1 : 0;
    out->figure = synth_bass_figure();
}

extern "C" int synth_app_bass_is_onset(int position)
{
    return synth_bass_is_onset(position);
}

extern "C" int synth_app_bass_is_accent(int position)
{
    return synth_bass_is_accent(position);
}

/*
 * Presets, from the side that owns the parameters.
 *
 * Through the public getter and setter rather than the array: the setter routes
 * through the same pending queue every knob uses, so a preset cannot arrive in
 * the audio task by a path the knobs do not take. A load therefore takes effect
 * at the next block boundary like any other parameter change, which is also what
 * keeps a preset from clicking.
 */
/* Deleting is the store's business only: nothing in the running sound changes, and the
 * sound the page is standing on is whatever the selection lands on next. */
extern "C" int synth_app_preset_delete(int slot)
{
    return app_settings_preset_delete(slot);
}

extern "C" int synth_app_preset_save(int slot)
{
    float values[SYNTH_PARAM_PATCH_COUNT];
    for (int i = 0; i < SYNTH_PARAM_PATCH_COUNT; i++) {
        values[i] = synth_app_get_param((synth_param_t)i);
    }
    return app_settings_preset_save(slot, values, SYNTH_PARAM_PATCH_COUNT);
}

/* The ROOT knob's travel before the range widened: A2..A4, MIDI 45..69. Written out here
 * rather than as another pair of defines in the header, because the only caller is the
 * migration and the numbers must never be used to map a LIVE value. */
#define SEQ_ROOT_LEGACY_MIN_MIDI 45
#define SEQ_ROOT_LEGACY_MAX_MIDI 69

/* A stored ROOT from the old range, as a value in the new one: the same NOTE, so the same
 * pitch. 128/255, the byte an old preset holds for A3, is 0.50196 and maps to (57-24)/84. */
static float seq_root_from_legacy(float v01)
{
    int note = SEQ_ROOT_LEGACY_MIN_MIDI
             + (int)(clamp01(v01)
                     * (float)(SEQ_ROOT_LEGACY_MAX_MIDI - SEQ_ROOT_LEGACY_MIN_MIDI) + 0.5f);
    if (note < SEQ_ROOT_LEGACY_MIN_MIDI) {
        note = SEQ_ROOT_LEGACY_MIN_MIDI;
    } else if (note > SEQ_ROOT_LEGACY_MAX_MIDI) {
        note = SEQ_ROOT_LEGACY_MAX_MIDI;
    }

    return (float)(note - SEQ_ROOT_MIN_MIDI)
         / (float)(SEQ_ROOT_MAX_MIDI - SEQ_ROOT_MIN_MIDI);
}

/*
 * THE FACTORY SOUND, AS A LOAD.
 *
 * Every patch parameter at synth_app_param_default(), applied through patch_apply() — the
 * same door a preset comes in by, so the sound glides to it, the migrations never see it
 * (the values ARE this firmware's defaults), the settings are untouched, and the tempo
 * comes back with the rest of the patch because the tempo is a patch parameter.
 *
 * The UI's INIT row calls this. Nothing else should: the app's own boot path already starts
 * from the defaults, and a random draw deliberately does not.
 *
 * Returns how many values were applied, which is what the row logs.
 */
extern "C" int synth_app_patch_factory(void)
{
    float values[SYNTH_PARAM_PATCH_COUNT];

    for (int p = 0; p < (int)SYNTH_PARAM_PATCH_COUNT; p++) {
        values[p] = synth_app_param_default((synth_param_t)p);
    }

    synth_app_patch_apply(values, (int)SYNTH_PARAM_PATCH_COUNT);
    return (int)SYNTH_PARAM_PATCH_COUNT;
}

extern "C" void synth_app_patch_apply(const float *values, int count)
{
    /* Для детектора скачков: загрузка патча — отдельная причина разрыва, и её надо уметь
     * отличить от опоздавшего блока. */
    s_patch_gen = s_patch_gen + 1u;
    if (!values || count <= 0) {
        return;
    }
    if (count > (int)SYNTH_PARAM_PATCH_COUNT) {
        count = (int)SYNTH_PARAM_PATCH_COUNT;
    }

    /*
     * THE AGE OF THE RECORD IS ITS LENGTH. The patch is the parameter list in order, so a
     * record that ends at or before the drum's RESET was written before this firmware
     * existed: it has no bytes for the drone's three shapes and none for FOLLOW, and its
     * ROOT was a normalised position on a twenty-five note knob.
     *
     * Deliberately `<= PERC_RESET` and not `== 84`: a record can be short for the older
     * reason too — the RESET fields themselves were appended — and every record shorter
     * than that is older still and needs exactly the same repair.
     */

    /*
     * СЛИЯНИЕ SYNC И TIME. Запись короче патча с посылом дилея в реверб несёт две ручки
     * времени — переключатель долей и миллисекунды, — а теперь ручка одна и положение в ней
     * одно. Пересчёт делается здесь, а не в app_settings: список долей и геометрическая
     * шкала миллисекунд живут в этом файле.
     *
     * Старое положение FREE (ноль) отправляет в миллисекундную часть: там ищется ближайшее
     * положение шкалы, чтобы старый звук получил то же время, а не соседнее.
     */
    float delay_time_fixed = -1.0f;

    if (count <= (int)SYNTH_PARAM_DELAY_VERB) {
        const float old_sync = s_param[SYNTH_PARAM_DELAY_SYNC];
        const float old_time = s_param[SYNTH_PARAM_DELAY_TIME];
        const int div_span = DELAY_DIV_COUNT - 1;
        const int div = (int)(clamp01(old_sync) * (float)div_span + 0.5f);

        if (div >= 1) {
            delay_time_fixed = (float)(div - 1) / (float)(DELAY_TIME_STEPS - 1);
        } else {
            const float want_ms = delay_ms_for(clamp01(old_time));
            int best = div_span;
            float best_d = 1.0e30f;

            for (int s = 0; s < DELAY_MS_STEPS; s++) {
                const float d = fabsf(delay_ms_step(s) - want_ms);

                if (d < best_d) {
                    best_d = d;
                    best = div_span + s;
                }
            }

            delay_time_fixed = (float)best / (float)(DELAY_TIME_STEPS - 1);
        }
    }

    const bool legacy = (count <= (int)SYNTH_PARAM_PERC_RESET);

    /*
     * THE FOLLOW BYTE HAS ITS OWN AGE TEST, and it is the length again.
     *
     * This firmware's patch is SYNTH_PARAM_PATCH_COUNT (90) values. The last one written
     * against the FOUR-position list was 88, and that is the only length from which a byte
     * for FOLLOW can be read while meaning a different list: 88 has the field, anything
     * shorter does not (the `legacy` branch below answers those), and anything longer was
     * written against this list or a later one. So the map is applied to that length and no
     * other, and a record this firmware writes takes the plain path with no recomputation.
     */
    const int follow_legacy_count = (int)SYNTH_PARAM_DRONE_FOLLOW + 1;   /* 88: the old patch */
    const bool follow_legacy = (count == follow_legacy_count);

    /*
     * THE ROOT IS TWO CONTROLS NOW, and its age is the length again.
     *
     * This firmware's patch is SYNTH_PARAM_PATCH_COUNT (104) values and its ROOT byte is a
     * NOTE. The patch before the split was 103 and its ROOT byte was a position on the
     * eighty-five semitone list; anything shorter still had the twenty-five note list, which
     * is what the `legacy` test above answers. So a 104 record is read as it stands, a 103
     * record's root is split into note and octave, and an older one is walked through the
     * twenty-five note range first and split after — the two mappings chained, which is what
     * the `continue` below does in one line.
     *
     * What the split cannot keep is the octave byte's own absence: a record without ROOT_OCT
     * gets the value this branch writes, not the factory default, because the pitch it stored
     * is known and a factory octave would move an old sound by an octave or two.
     */
    const int root_split_count = (int)SYNTH_PARAM_ROOT_OCT;      /* 103: the patch before */

    for (int i = 0; i < count; i++) {
        float v = values[i];

        if (i == (int)SYNTH_PARAM_ROOT && count <= root_split_count) {
            float note01 = 0.0f;
            float oct01 = 0.0f;

            seq_root_split(legacy ? seq_root_from_legacy(v) : v, &note01, &oct01);
            synth_app_set_param(SYNTH_PARAM_ROOT, note01);
            synth_app_set_param(SYNTH_PARAM_ROOT_OCT, oct01);
            continue;
        }
        if (follow_legacy && i == (int)SYNTH_PARAM_DRONE_FOLLOW) {
            v = drone_follow_from_legacy(v);
        }
        synth_app_set_param((synth_param_t)i, v);
    }

    if (!legacy) {
        return;
    }

    /* The old single shape becomes all three: the byte the record carries is the shape its
     * drone was made of, so the timbre comes back exactly as it was saved. A record older
     * than that byte keeps the factory SAW, which is what the firmware that wrote it used. */
    const float wave = (count > (int)SYNTH_PARAM_DRONE_WAVE)
                     ? s_param[SYNTH_PARAM_DRONE_WAVE]
                     : synth_app_param_default(SYNTH_PARAM_DRONE_WAVE);

    synth_app_set_param(SYNTH_PARAM_DRONE_OSC_LOW, wave);
    synth_app_set_param(SYNTH_PARAM_DRONE_OSC_MID, wave);
    synth_app_set_param(SYNTH_PARAM_DRONE_OSC_HIGH, wave);

    /* SCALE by name, not the live value: the old firmware could only hold a degree, and the
     * shortest answer this one has for "a follower at rest" is its factory position. A record
     * that DOES carry a FOLLOW byte was mapped by drone_follow_from_legacy() in the loop
     * above; this branch is the one with no byte at all. */
    synth_app_set_param(SYNTH_PARAM_DRONE_FOLLOW,
                        synth_app_param_default(SYNTH_PARAM_DRONE_FOLLOW));

    /* Слитая ручка времени: старое время, пересчитанное в одно положение. Только здесь, где
     * значения уже разложены и ремонт старых записей закончен. */
    if (delay_time_fixed >= 0.0f) {
        synth_app_set_param(SYNTH_PARAM_DELAY_TIME, delay_time_fixed);
    }
}

extern "C" int synth_app_preset_load(int slot)
{
    float values[SYNTH_PARAM_PATCH_COUNT];
    const int n = app_settings_preset_load(slot, values, SYNTH_PARAM_PATCH_COUNT);

    /* A preset is a batch, so it travels: the values below are the destination rather than
     * the jump. With no slide configured this is a no-op and the load lands at once. */
    synth_app_slide_begin();

    synth_app_patch_apply(values, n);

    /*
     * A RECORD WITHOUT A RESET FIELD MEANS THAT PARAMETER'S DEFINED DEFAULT, NOT "LEAVE IT",
     * and the two fields have DIFFERENT defaults for a reason.
     *
     * The two RESET parameters are the last two of the patch, so a preset saved before the
     * drum's gesture existed carries one byte fewer, and one saved before the lead's moved
     * here carries two fewer; the loop above never reaches what the record does not have.
     * The lead's missing field reads as sixteen, because that is what the field meant when it
     * was first written; the drum's reads as INF, the gesture off, because the drum never
     * reset before its field existed and an older sound must come back sounding exactly as it
     * did. Zero is INF for both, a real position, so a missing byte must not be allowed to
     * fall on the zero the array already holds.
     *
     * The rest of the tail is deliberately left as it is, and that is not an oversight: a
     * parameter appended since a record was written has always kept whatever value the
     * instrument already had (the loop only writes what the record carried), and changing
     * that here would move PERC QUANT and the drive on every old preset — exactly the kind
     * of "the sound came back different" this migration exists to avoid. The two RESET
     * fields are different because their absence is not an absence: each has a defined
     * answer. The drone's three shapes and FOLLOW are a third case, and they are answered in
     * synth_app_patch_apply(), where the record's own DRONE_WAVE byte is still in hand.
     *
     * n > 0 because an empty slot must keep the live sound, whatever the defaults are.
     */
    if (n > 0 && n <= (int)SYNTH_PARAM_SEQ_RESET) {
        synth_app_set_param(SYNTH_PARAM_SEQ_RESET,
                            synth_app_param_default(SYNTH_PARAM_SEQ_RESET));
    }
    if (n > 0 && n <= (int)SYNTH_PARAM_PERC_RESET) {
        synth_app_set_param(SYNTH_PARAM_PERC_RESET,
                            synth_app_param_default(SYNTH_PARAM_PERC_RESET));
    }
    return n;
}

/* -------------------------------------------------------------------------- */
/* Microphone                                                                 */
/* -------------------------------------------------------------------------- */
/*
 * THE PATH OF ONE BLOCK OF MICROPHONE
 *
 *   bsp_audio_in_read()   one engine block, 256 samples of 16 bits, timeout 0
 *        |                non-blocking: the audio loop is paced by the I2S output
 *        v                and a blocking read here would steal from synthesis
 *   DC blocker            one pole at 175 Hz, because the PDM part sits on an
 *        |                offset of ~1081 counts against ~46 RMS of signal
 *        v
 *   software gain         the sensitivity knob's own stage, 1..6x, one multiply a
 *        |                sample and then a clamp at full scale; this is the ONLY
 *        |                gain this input has, because the driver's amplify_num
 *        |                stage is not implemented on the S3 (see the constants)
 *        v
 *   envelope              0..1: instant attack, 150 ms release, normalised after
 *        |                that gain; this is what modulation reads
 *        v
 *   publish_mic_mod()     the number the DSP's MIC shape multiplies its depth by, and
 *                         THE WHOLE OUTPUT OF THIS MODULE
 *
 *   The block itself goes nowhere. It used to be published for synth_fx_mic_in() to add to
 *   the AUX bus, and from there into the three effects by the SEND_MIC knobs; the owner took
 *   the microphone out of the sends and kept it for modulation, so the samples stop at the
 *   peak detector and the bus carries nothing. synth_dsp_mic_publish() and synth_fx_mic_in()
 *   are still in the DSP — retired, not called — and the three send parameters are dead slots.
 *
 * WHY THE READ IS HERE AND NOT IN A TASK OF ITS OWN
 *   The engine has no locking, and the block that the DSP will add to its bus has to be
 *   the block the microphone delivered for THAT render — one block of slack is one
 *   block of misalignment between the room and the reverb, which is inaudible, but a
 *   second task reading the same I2S channel would be a second owner of the driver's
 *   position and would interleave with this one. The read is exactly as long as the
 *   block: 256 samples at 48 kHz is 5.33 ms, and the DMA descriptor is 240 frames, so
 *   one read serves one block, and the two are locked to the same clock by construction.
 *
 * NO ALLOCATION ANYWHERE
 *   The one buffer is a file-scope static in .bss (512 bytes), and nothing here is ever
 *   freed. The internal DMA pool has about 3 KB free once the network is up; a heap
 *   allocation per block would not fit once, let alone 187.5 times a second.
 */
static int16_t s_mic_raw[SYNTH_BLOCK_SAMPLES];     /* the driver's block, 16-bit counts */
/* s_mic_block[] is gone: the filtered block had one reader, synth_fx_mic_in(), and the
 * microphone no longer reaches the effects. */

static float s_mic_hp_r;        /* the DC blocker's pole, from MIC_HP_CORNER_HZ */
static float s_mic_hp_x1;       /* its last input sample and its last output sample */
static float s_mic_hp_y1;
static float s_mic_env_release; /* one-pole coefficient, from MIC_ENV_RELEASE_MS */

/*
 * The percussion's own ring telemetry, the counterpart of the microphone's envelope above.
 *
 * Where the microphone's number is COMPUTED here — the driver is read in this task and
 * nowhere else — the drum's is read from the module that renders it (synth_perc_env()) and
 * only SHAPED here, into the envelope the ring draws. The shaping lives in this task for
 * the same reason: this is what knows the block rate, and the release is a decision about
 * frames rather than about samples. See PERC_ENV_RELEASE_MS and publish_perc_env().
 */
static float s_perc_env01;      /* instant attack, one-pole release, 0..1 */
static float s_perc_env_release;/* its coefficient, from PERC_ENV_RELEASE_MS */

/* Called from synth_app_start(), before the audio task exists: the two coefficients are
 * computed once from the sample rate and the block size rather than per block. */
static void mic_init(void)
{
    /* First, because everything below that touches the gain reads it. */
    mic_sw_lut_build();

    s_mic_hp_r = 1.0f - (2.0f * 3.14159265f * MIC_HP_CORNER_HZ / (float)SYNTH_SAMPLE_RATE);
    s_mic_hp_x1 = 0.0f;
    s_mic_hp_y1 = 0.0f;

    s_mic_env_release = 1.0f - expf(-((float)SYNTH_BLOCK_SAMPLES / (float)SYNTH_SAMPLE_RATE) /
                                    (MIC_ENV_RELEASE_MS * 0.001f));

    s_mic_sens01 = 0.0f;
    s_mic_env01 = 0.0f;
    s_mic_replace = false;
    /* Unity, and the driver's stage is asked for the first time by the first detent above
     * zero. Both of these are the values that say "nothing has been gained yet". */
    s_mic_sw_gain = mic_sw_gain_for(0.0f);
    s_mic_drv_gain_absent = false;
    publish_mic_mod();
}

static void publish_mic_mod(void)
{
    synth_dsp_set_mic_env(s_mic_env01, s_mic_replace);
}

/*
 * The percussion's display envelope, from the module's own reading of its voices.
 *
 * The module reduces the three voices to one number — the loudest of them, its gate times
 * its velocity times the steal's fade — and this is where that reading is given the same
 * two-rate shape the layer telemetry uses (synth_pan_capture.cpp): instant on the way up,
 * so a hit is at full brightness in the block it lands in, and one-pole on the way down, so
 * a 20 ms gate is still a flash on a ring drawn every 120 ms. Why the release exists and
 * why it is 140 ms is beside PERC_ENV_RELEASE_MS.
 *
 * THE LEVEL AND THE SEND ARE NOT HERE. The ring weighs the part with part_output_gain()
 * exactly as it weighs a layer, and the drum's fader and send are applied there; a fader
 * counted twice would make the ring read the square of the knob. What crosses this seam is
 * the part's envelope and nothing else.
 *
 * Called from the audio task once per block, after the render — the value is produced BY
 * the render, unlike the microphone's block, which is published before it because the
 * render consumes it.
 */
static void publish_perc_env(void)
{
    const float now = synth_perc_env();

    if (now > s_perc_env01) {
        s_perc_env01 = now;
    } else {
        s_perc_env01 += (now - s_perc_env01) * s_perc_env_release;
    }

    if (!(s_perc_env01 > 0.0f)) {
        s_perc_env01 = 0.0f;
    } else if (s_perc_env01 > 1.0f) {
        s_perc_env01 = 1.0f;
    }

    synth_dsp_set_perc_env(s_perc_env01);
}

/* Called from synth_app_start(), beside mic_init() and for the same reason: the release is
 * a coefficient of the block rate, and the block rate is fixed. */
static void perc_env_init(void)
{
    s_perc_env01 = 0.0f;
    s_perc_env_release = 1.0f - expf(-((float)SYNTH_BLOCK_SAMPLES / (float)SYNTH_SAMPLE_RATE) /
                                     (PERC_ENV_RELEASE_MS * 0.001f));

    /* Silence, published at boot rather than left at whatever .bss held: the ring may be
     * drawn before the first block has rendered anything. */
    synth_dsp_set_perc_env(0.0f);
}

static void mic_process_block(void)
{
    /* OFF COSTS NOTHING. Not a read, not a filter, not an envelope: the driver is not
     * touched and the DSP is told the block is empty. This is the whole of what the
     * setting's zero means. */
    if (s_mic_sens01 <= 0.0f) {
        s_mic_env01 = 0.0f;
        publish_mic_mod();
        return;
    }

    size_t got = 0;
    const esp_err_t err = bsp_audio_in_read(s_mic_raw, sizeof(s_mic_raw), &got, 0);

    if (err != ESP_OK || got == 0) {
        /* A read that returns nothing is the ordinary case between PDM descriptors, not
         * a fault, so nothing is logged and nothing is counted. What matters is that the
         * block is not played twice: the DSP is told the input is silent, and the
         * envelope is allowed to fall rather than being held at its last value. */
        s_mic_env01 += (0.0f - s_mic_env01) * s_mic_env_release;
        publish_mic_mod();
        return;
    }

    int count = (int)(got / sizeof(s_mic_raw[0]));
    if (count > SYNTH_BLOCK_SAMPLES) {
        count = SYNTH_BLOCK_SAMPLES;
    }

    float peak = 0.0f;

    /*
     * THE GAIN STAGE, and the order it is in: after the DC blocker, so the offset is never
     * amplified, and in the same multiply as the conversion to full scale, so the stage
     * costs one multiply a sample and no more — 256 a block against a budget of 5333
     * microseconds.
     *
     * THE CLAMP IS FULL SCALE, and it is what keeps the int conversion safe: the block is
     * published as a float where 1.0 is 32767, and synth_fx_mic_in() turns it back into
     * the bus' int32 with v = x * 32768, so a float outside 1.0 would be a bus
     * contribution outside full scale. Nothing measured on this board can reach it — the
     * loudest thing ever seen is a clap at 0.115 of full scale, and 6x puts that at 0.688
     * — so in practice it guards against a knock on the microphone's port. What it does
     * there is hard clipping at exactly full scale: no wrap-around, and nothing left for
     * the DSP's own 2147483000 guard to catch, since 32768 is nowhere near int32
     * saturation.
     */
    const float scale = s_mic_sw_gain * (1.0f / 32768.0f);

    /*
     * THE BLOCK IS NO LONGER FILLED, only measured. The samples used to be written into
     * s_mic_block for synth_fx_mic_in(); with the sends gone the copy is a hundred and
     * twenty-eight wasted stores a block, so the loop keeps the high pass — the envelope must
     * not read the microphone's DC offset — and the peak, and drops the rest.
     */
    for (int i = 0; i < count; i++) {
        const float x = (float)s_mic_raw[i];
        /* y[n] = x[n] - x[n-1] + R*y[n-1]: one pole of high pass, which is all the
         * offset needs and all this block can afford. */
        const float y = x - s_mic_hp_x1 + s_mic_hp_r * s_mic_hp_y1;
        s_mic_hp_x1 = x;
        s_mic_hp_y1 = y;

        const float g = y * scale;      /* the gain, in full scale, before the clamp */

        /* The envelope reads the level BEFORE the clamp: a signal loud enough to be clamped
         * still has to be able to say how loud it was. */
        const float a = fabsf(g);
        if (a > peak) {
            peak = a;
        }
    }

    /*
     * The envelope: the block's peak, straight in, and a one-pole release out. A peak
     * rather than an RMS because a room's movement is a level and the ear reads the top
     * of it; the release is what keeps the value from dropping to zero between the
     * blocks that carry no transient.
     *
     * The peak is in FULL SCALE, like the published block and like the reference below:
     * after the gain, and from the value before the clamp, so a signal loud enough to be
     * clamped still tells the envelope how loud it was — and an envelope that then pins at
     * 1.0 is the right answer for a transient that loud.
     *
     * The division is what the SENSITIVITY knob is heard through: the gain scales the peak
     * before it, so the same sound reads small at the bottom of the travel and full scale
     * near the top. Nothing else scales the envelope.
     */
    const float target = peak * (1.0f / MIC_ENV_PEAK_REF);
    if (target > s_mic_env01) {
        s_mic_env01 = target;
    } else {
        s_mic_env01 += (target - s_mic_env01) * s_mic_env_release;
    }
    if (s_mic_env01 > 1.0f) {
        s_mic_env01 = 1.0f;
    }

    /* No publish: the DSP's copy of this block was only ever the effects' input. The
     * envelope is the microphone's whole remaining output; see publish_mic_mod(). */
    publish_mic_mod();
}

/* -------------------------------------------------------------------------- */
/* The rescue record that outlives the reset                                  */
/* -------------------------------------------------------------------------- */
/*
 * A silent failure is the one that leaves the least behind: the screen works, the knobs
 * read their values, and the only evidence is the sound that is not there. The rack's
 * watchdog (synth_rack.cpp) cures it and pins a snapshot, but if the owner does what one
 * does with a dead instrument — switches it off and on — the console line goes with the
 * power. So the last rescue, either kind, is pinned here in RTC slow memory, which a
 * reset does not clear, and the next boot prints it before it is overwritten.
 *
 * THE MAGIC IS WRITTEN LAST and cleared first, so a reset in the middle of an update
 * leaves an invalid record rather than a half-written one; a power cycle that takes the
 * RTC domain with it leaves no magic at all, which is the silent case. The chip's own
 * reset reason already says whether the RTC memory survived, so this record does not
 * repeat it.
 *
 * THE WRITE IS NOT ON THE AUDIO TASK. The rescue happens on the audio task, which hands
 * its snapshot to the statistics task through the pair of buffers below; that task owns
 * RTC memory here, exactly as it owns the counters it prints. The window is at most one
 * statistics period, and the record exists for the next boot rather than for a reset in
 * the same millisecond.
 */
#define RESCUE_RTC_MAGIC 0x534C4E43u   /* "SLNC" */

typedef struct {
    uint32_t magic;
    uint32_t magic_inv;
    uint32_t silence;
    uint32_t nonfinite;
    uint32_t cause;        /* 1 silence, 0 non-finite */
    uint32_t uptime_ms;    /* since boot, when that rescue fired */
    uint32_t lasted_ms;    /* how long the output had been silent */
    float    master;
    float    comp;
    float    gate;
    float    duck;
    float    drone;
} rescue_rtc_t;

RTC_NOINIT_ATTR static rescue_rtc_t s_rescue_rtc;

/*
 * The audio task's copy of the rack snapshot. TWO buffers, because the statistics task
 * reads one while a rescue can land in the other: the audio task always writes the buffer
 * the reader is not on and then flips the index, so a copy is never taken from under a
 * writer. The index is the only thing that crosses the cores.
 */
static synth_rack_rescue_t s_rescue_pending[2];
static volatile uint32_t   s_rescue_pending_idx;
static uint32_t            s_rescue_serial_seen;
static uint32_t            s_rescue_committed_serial;

/* The line is the rack's event and keeps the rack's tag: the troubleshooting page and
 * tools/stress.ps1 both look for `rack: rescue`, and the task that writes the line is the
 * instrument's business rather than the reader's. */
static const char *TAG_RESCUE = "rack";

/* The statistics task's print clock: the first line at once, then no more than one per
 * this many microseconds. The audio task used to keep this clock and print in the block;
 * both moved here with the line. */
#define RESCUE_LOG_US 3000000

static uint32_t s_rescue_printed_serial;
static int64_t  s_rescue_print_us;

static bool rescue_rtc_ok(void)
{
    return s_rescue_rtc.magic == RESCUE_RTC_MAGIC &&
           s_rescue_rtc.magic_inv == ~RESCUE_RTC_MAGIC;
}

/* One line, then the record is invalid until something writes it again. Called from
 * synth_app_start(), before any task exists, so there is no lock to take. */
static void rescue_rtc_report(void)
{
    if (!rescue_rtc_ok()) {
        return;
    }

    const double at_s = (double)s_rescue_rtc.uptime_ms / 1000.0;
    const double lasted_s = (double)s_rescue_rtc.lasted_ms / 1000.0;

    if (s_rescue_rtc.cause == 1u) {
        ESP_LOGE(TAG, "previous boot: silence at %.1f s, lasted %.1f s, master %g, "
                      "comp %g, gate %.3f, duck %.3f, drone %g",
                 at_s, lasted_s,
                 (double)s_rescue_rtc.master, (double)s_rescue_rtc.comp,
                 (double)s_rescue_rtc.gate, (double)s_rescue_rtc.duck,
                 (double)s_rescue_rtc.drone);
    } else {
        ESP_LOGE(TAG, "previous boot: non-finite at %.1f s, master %g, comp %g, "
                      "gate %.3f, duck %.3f, drone %g",
                 at_s,
                 (double)s_rescue_rtc.master, (double)s_rescue_rtc.comp,
                 (double)s_rescue_rtc.gate, (double)s_rescue_rtc.duck,
                 (double)s_rescue_rtc.drone);
    }

    /* Cleared only after the line is out: a reset during the print would show it again
     * next boot rather than lose it. */
    s_rescue_rtc.magic = 0u;
}

static void rescue_rtc_store(const synth_rack_rescue_t *r)
{
    s_rescue_rtc.magic = 0u;
    s_rescue_rtc.silence = r->silence_count;
    s_rescue_rtc.nonfinite = r->nonfinite_count;
    s_rescue_rtc.cause = r->cause;
    s_rescue_rtc.uptime_ms = r->uptime_ms;
    s_rescue_rtc.lasted_ms = r->lasted_ms;
    s_rescue_rtc.master = r->master;
    s_rescue_rtc.comp = r->comp;
    s_rescue_rtc.gate = r->gate;
    s_rescue_rtc.duck = r->duck;
    s_rescue_rtc.drone = r->drone;
    s_rescue_rtc.magic_inv = ~RESCUE_RTC_MAGIC;
    s_rescue_rtc.magic = RESCUE_RTC_MAGIC;
}

/*
 * The audio task's end, once per block after the render. It asks the rack whether a rescue
 * happened and copies the pinned state into the buffer the reader is not on; the flip is
 * the publication. A block that had no rescue costs one call, one load and one compare.
 */
static void rescue_poll(void)
{
    const uint32_t serial = synth_rack_rescue_serial();

    if (serial == s_rescue_serial_seen) {
        return;
    }
    s_rescue_serial_seen = serial;

    const uint32_t idx = 1u - s_rescue_pending_idx;
    synth_rack_rescue_snapshot(&s_rescue_pending[idx]);

    std::atomic_thread_fence(std::memory_order_release);
    s_rescue_pending_idx = idx;
}

/* The statistics task's end: the record reaches RTC memory here, off the audio task and
 * at most a second after the failure. */
static void rescue_commit(void)
{
    const uint32_t idx = s_rescue_pending_idx;

    std::atomic_thread_fence(std::memory_order_acquire);
    const synth_rack_rescue_t rec = s_rescue_pending[idx];

    if (s_rescue_pending_idx != idx || rec.serial == s_rescue_committed_serial) {
        return;     /* a newer rescue moved the writer, or this one is already stored */
    }

    s_rescue_committed_serial = rec.serial;
    rescue_rtc_store(&rec);
}

/*
 * The rescue line, printed here and nowhere else. The audio task pins the snapshot and
 * returns; this task reads it once per period, which is where a UART wait costs nothing
 * but its own tick — measured in the block, the same write held the audio task for 12-16
 * ms against a 5.33 ms budget, so the line about a rescue was creating the missed
 * deadlines it was reporting.
 *
 * THE RATE LIMIT IS THE OLD ONE, moved with the line: the first one at once, then no more
 * than one per RESCUE_LOG_US. A rescue that arrives while the limit holds is not lost —
 * `serial` and both counters have already counted it in the snapshot, and the first line
 * the limit allows prints the newest snapshot with the number that has accumulated. That
 * is why the reader keeps `s_rescue_printed_serial` rather than clearing a flag: a line
 * that is skipped for the limit is printed with the next one, not dropped.
 */
static void rescue_report(void)
{
    const uint32_t idx = s_rescue_pending_idx;

    std::atomic_thread_fence(std::memory_order_acquire);
    const synth_rack_rescue_t rec = s_rescue_pending[idx];

    if (s_rescue_pending_idx != idx) {
        return;     /* a newer rescue moved the writer; the next period prints that one */
    }
    if (rec.serial == s_rescue_printed_serial) {
        return;
    }

    const int64_t now = esp_timer_get_time();
    if (s_rescue_printed_serial != 0u && (now - s_rescue_print_us) < RESCUE_LOG_US) {
        return;
    }

    s_rescue_printed_serial = rec.serial;
    s_rescue_print_us = now;

    if (rec.cause == 1u) {
        ESP_LOGE(TAG_RESCUE,
                 "rescue %" PRIu32 ": silence for %.1f s, master %g, comp %g, gate %.3f, "
                 "duck %.3f, layers %.2f/%.2f/%.2f/%.2f/%.2f, delay %.0f, fb %.3f",
                 rec.serial, (double)rec.lasted_ms / 1000.0,
                 (double)rec.master, (double)rec.comp, (double)rec.gate,
                 (double)rec.duck,
                 (double)rec.layers[0], (double)rec.layers[1], (double)rec.layers[2],
                 (double)rec.layers[3], (double)rec.layers[4],
                 (double)rec.delay_samples, (double)rec.delay_fb);
    } else {
        ESP_LOGE(TAG_RESCUE,
                 "rescue %" PRIu32 ": output not finite (L %" PRIu32 ", R %" PRIu32
                 "), last %g/%g, master %g, comp %g, gate %.3f, duck %.3f, "
                 "delay %.0f, fb %.3f",
                 rec.serial, rec.bad_l, rec.bad_r,
                 (double)rec.last_l, (double)rec.last_r,
                 (double)rec.master, (double)rec.comp, (double)rec.gate,
                 (double)rec.duck, (double)rec.delay_samples, (double)rec.delay_fb);
    }
}

/* -------------------------------------------------------------------------- */
/* Audio task                                                                 */
/* -------------------------------------------------------------------------- */

/*
 * Wait until `due_us`, used only when bsp_audio_out_write() failed.
 *
 * The normal pacing is the I2S clock: a successful write blocks until the DMA has room,
 * so the loop cannot run faster than the sample rate. A failed write queues nothing, and
 * without this wait the loop would render the next block immediately — a silent, fast
 * spin whose blocks also never reach the counters below because the old path continued
 * before they were touched.
 *
 * ESP-IDF's tick is 1 ms, so short waits busy the last fraction of a millisecond. That is
 * bounded by one block and runs only on the failure path, never in normal playback.
 */
static void wait_for_block_pace(int64_t due_us)
{
    for (;;) {
        const int64_t now = esp_timer_get_time();
        if (now >= due_us) {
            return;
        }

        const int64_t left = due_us - now;
        if (left > 1500) {
            vTaskDelay(1);
        } else {
            esp_rom_delay_us((uint32_t)left);
            return;
        }
    }
}

#if STAGE_TIMING
/*
 * ONE BLOCK'S STAGE ACCOUNTING, at the end of the block.
 *
 * "layers" is the engine's render with the two bus-FX callbacks it makes subtracted: the
 * drone filter and the lead filter time themselves inside their own calls and are reported
 * as their own stages, and the sum of the stages is the block rather than the same
 * microseconds counted twice.
 *
 * The remainder is what the measured stages do not account for — the rack's own decisions
 * between them, the scope, the silence watchdog, the rescue poll. It is computed from the
 * block's own figure and never from a zero, so a stage that grows by a microsecond and a
 * remainder that shrinks by one are the same statement.
 */
static void stage_report_block(int64_t t_control, int64_t t_layers, uint32_t dsp_us)
{
    uint32_t render_us = 0;

    if (t_layers > t_control) {
        render_us = (uint32_t)(t_layers - t_control);
    }

    const uint32_t filters = synth_stage_block_us(SYNTH_STAGE_DRONE)
                           + synth_stage_block_us(SYNTH_STAGE_LEAD);

    synth_stage_add(SYNTH_STAGE_LAYERS, (render_us > filters) ? (render_us - filters) : 0u);

    uint32_t measured = 0;
    for (int s = 0; s < (int)SYNTH_STAGE_REMAINDER; s++) {
        measured += synth_stage_block_us((synth_stage_t)s);
    }

    synth_stage_add(SYNTH_STAGE_REMAINDER, (dsp_us > measured) ? (dsp_us - measured) : 0u);

    /* Publishes the block: totals into the window, maxima on the totals, counters cleared. */
    synth_stage_block();
}
#endif /* STAGE_TIMING */

/*
 * The loop is paced by the I2S clock itself: bsp_audio_out_write() blocks until
 * the DMA has room, so there is no timer to drift against and no need for
 * vTaskDelayUntil. The first few iterations run as fast as they can while the
 * DMA queue fills, and then the loop locks to the sample rate.
 *
 * One block per generateSamples() call, deliberately: the capture FX writes
 * from offset 0 of the layer accumulator and cannot know which chunk of a
 * larger request it is serving.
 */
static void audio_task(void *arg)
{
    (void)arg;

    const uint32_t budget_us =
        (uint32_t)((uint64_t)SYNTH_BLOCK_SAMPLES * 1000000ULL / SYNTH_SAMPLE_RATE);

    /* Consecutive failures keep a deadline of their own; 0 means the I2S clock is pacing. */
    int64_t write_pace_us = 0;

    for (;;) {
        const int64_t t0 = esp_timer_get_time();

        /* Просвет от начала прошлого блока: если задача стояла, он больше двух бюджетов. */
        if (s_gap_last != 0u) {
            const uint32_t gap = (uint32_t)t0 - s_gap_last;
            if (gap > s_gap_us_max) {
                s_gap_us_max = gap;
            }
            if (gap > 2u * (uint32_t)budget_us) {
                s_gap_bad = s_gap_bad + 1u;
            }
        }
        s_gap_last = (uint32_t)t0;

#if MIC_TEST_ENABLE
        /* MIC PROBE (retired; MIC_TEST_ENABLE is 0) — read the microphone and
         * accumulate one window.
         *
         * The request is exactly one engine block. A non-blocking read may hand
         * back fewer bytes than that (the PDM DMA works in whole descriptors, so
         * a call often ends on a partial one): that is expected and harmless,
         * the driver keeps its position. A read that returns NO bytes at all is
         * the failure worth counting. */
        {
            size_t got = 0;
            const esp_err_t mic_err =
                bsp_audio_in_read(s_mic_buf, sizeof(s_mic_buf), &got, 0);

            if (got == 0) {
                s_mic_errs = s_mic_errs + 1u;
                s_mic_last_err = (int)mic_err;
            } else {
                const uint32_t cnt = (uint32_t)(got / sizeof(s_mic_buf[0]));
                for (uint32_t i = 0; i < cnt; i++) {
                    const int32_t  v = s_mic_buf[i];
                    const uint32_t a = (v < 0) ? (uint32_t)(-v) : (uint32_t)v;
                    if (a > s_mic_peak) {
                        s_mic_peak = a;
                    }
                    s_mic_sum   += v;
                    s_mic_sumsq += (uint64_t)((int64_t)v * (int64_t)v);
                }
                s_mic_n = s_mic_n + cnt;
            }

            s_mic_blocks = s_mic_blocks + 1u;
            if (s_mic_blocks >= (uint32_t)MIC_TEST_WINDOW_BLOCKS) {
                const uint32_t n = s_mic_n;
                s_mic_out_peak = s_mic_peak;
                s_mic_out_rms  = (n > 0) ? mic_isqrt(s_mic_sumsq / n) : 0u;
                s_mic_out_dc   = (n > 0) ? (int32_t)(s_mic_sum / (int64_t)n) : 0;
                s_mic_out_n    = n;
                s_mic_out_errs = s_mic_errs;
                s_mic_out_last_err = s_mic_last_err;
                /* Published last: this is what tells the stats task to print. */
                s_mic_out_serial = s_mic_out_serial + 1u;

                s_mic_peak = 0;
                s_mic_sumsq = 0;
                s_mic_sum = 0;
                s_mic_n = 0;
                s_mic_blocks = 0;
                s_mic_errs = 0;
                s_mic_last_err = 0;
            }
        }
#endif /* MIC_TEST_ENABLE */

        /* User input arrives as plain data and becomes an engine write only
         * here, on the one task that owns the engine. */
        apply_pending_params();

        /*
         * Notes from outside, on exactly the same terms and in the same place:
         * the MIDI task only ever placed them in a ring, and the engine is
         * written here, by the task that owns it.
         *
         * Before seq_tick(), and that order IS the eviction rule: a note that
         * arrives in time to be heard this block has already taken the lead by
         * the time the sequencer looks at it, so the Euclidean figure steps aside
         * for this block rather than opening a second note on the generator's
         * group — while the arp, which is called from the same seq_tick() a few
         * lines down, plays the keys this drain has just recorded in the group
         * that belongs to it and to no key from the wire. With the arp ON those
         * keys open no other group at all, and the switch that decides it is read
         * on this same task: see midi_note_pressed() and arp_lead_tick().
         */
        drain_midi_events();

        /*
         * ПУСК С ПЕРВОГО ШАГА, если панель его попросила. Здесь, а не в seq_tick(): позиция
         * транспорта и три счётчика шагов — движка, и этот блок их ещё не читал, поэтому
         * первый шаг сыграет тот же блок, что и нажатие. START с провода приходит тем же
         * путём и сбрасывает то же самое (см. midi_transport_reset).
         */
        if (s_restart_req.exchange(false, std::memory_order_acq_rel)) {
            midi_transport_reset();
            /* Бас держит свой шаг и догоняет долю такта по кратчайшему пути — скачок на
             * половину такта для него выглядит как «стоять на месте», поэтому его счётчик
             * ставится здесь же, явно. */
            synth_bass_restart();
        }

        /*
         * What the notes that just arrived mean for the OUTPUT and for the DRONE, in the
         * same block and before the render.
         *
         * The gate first, and before the render rather than after it: a hit that arrives
         * this block has to open the output for this block, and the rack's own ramp (see
         * GATE_OPEN_TAU_S) is what makes opening it between two blocks a fade instead of a
         * step. The harmonisation then reads the same held-note state the drain has just
         * updated, so what the drone is tuned to and what the lead is playing cannot
         * disagree by a block.
         *
         * Both are gating and tuning and not note events: they run whether or not anything
         * arrived, because a tail has to be able to run out and a glide has to be able to
         * finish. See midi_gate_tick() and drone_tune_tick().
         */
        midi_gate_tick();
        drone_tune_tick();
        drone_drift_tick();
        mod_pw_tick();

        /* Фазы обоих LFO — раз в блок, как и всё остальное в этом месте. */
        mod_advance();

        /* И приёмники, которым нужен пересчёт на каждом блоке. */
        mod_receivers_tick();

        /*
         * Модуляция уровня дрона, если DRONE LVL выбран адресатом: LFO двигается каждый
         * блок, а уровень публикуется только на изменение, поэтому здесь и стоит пересчёт
         * — три int16 в слой, и только пока приёмник включён.
         */
        if (mod_dest_level()) {
            for (int r = 0; r < DRONE_REGISTERS; r++) {
                drone_level_apply(r);
            }
        }

        /*
         * The microphone, after the parameters and before the render: the sensitivity
         * applied above decides whether this reads at all and how hard the driver drives
         * it, and the block it publishes is the one synth_fx_mic_in() adds to the AUX bus
         * during generateSamples() below. Swap the two and the input is one block stale,
         * which is 2.7 ms and would still work — this order is simply the honest one.
         */
        mic_process_block();

        /* The sequencer is part of the block loop rather than a task beside it:
         * this is the only place allowed to touch the engine, and a step is then
         * an exact number of blocks instead of a hope about a timer. */
        seq_tick();

        /* Показания дорожек отпускаются здесь, на такте блоков, а не на таймере
         * экрана: так они не зависят от того, смотрим ли мы на PERC MIX. */
        perc_lane_env_tick();

        /* The block that just played used the position at its start; the next block
         * begins one increment later. Advancing here rather than inside seq_tick()
         * keeps the early returns in it from skipping musical time — the arp branch
         * returns, and a RESET branch resets. */
        tp_advance();

#if STAGE_TIMING
        /* Everything between the top of the loop and the render: parameters, MIDI, the
         * sequencer, the microphone. A stage of its own so that the remainder is the few
         * microseconds that belong to none of them, rather than a lump nobody can attribute. */
        const int64_t t_pre = esp_timer_get_time();
        synth_stage_add(SYNTH_STAGE_CONTROL, (uint32_t)(t_pre - t0));
#endif

        synth_layers_clear(SYNTH_BLOCK_SAMPLES);
        s_synth.generateSamples(s_engine_mono, SYNTH_BLOCK_SAMPLES);

        /* The bass, into its own layer, after the engine's block and before the rack sums
         * the layers: the rack is where its fader and sends live, so it has to be in the
         * layer by then. */
        /* Сетка баса — сетка прибора: та же доля такта, что у перкуссии и лида. */
    synth_bass_sync_phase(s_running ? 1 : 0, (float)s_tp_phase);

    synth_bass_set_swing(perc_swing_frac());

        /* Лад — вторая вещь, которую бас берёт у прибора. Маска собирается из той же
         * таблицы ступеней, по которой квантуется лид, поэтому бас и лид выбирают одну и ту
         * же ноту из двух равноудалённых. Считается только при смене лада. */
        {
            static uint16_t s_bass_mask_seen = 0xFFFFu;
            const seq_scale_cfg_t *sc = seq_scale();
            uint16_t mask = 0u;

            for (int i = 0; i < sc->len; i++) {
                mask |= (uint16_t)(1u << (sc->steps[i] & 31));
            }

            if (mask != s_bass_mask_seen) {
                s_bass_mask_seen = mask;
                synth_bass_set_scale_mask(mask);
            }
        }

        synth_bass_block(SYNTH_BLOCK_SAMPLES);

#if STAGE_TIMING
        /* The engine's render, with the drone and the lead filter callbacks in it: they are
         * measured inside those callbacks and subtracted in stage_report_block(). */
        const int64_t t_gen = esp_timer_get_time();
#endif

        synth_rack_process(SYNTH_BLOCK_SAMPLES, s_stereo_out);

        /* Доля клока: счётчик долей для кольца, один раз в блок. */
        {
            float bpm = seq_tempo_bpm(synth_app_tempo_now(NULL));

            if (!(bpm > 20.0f)) {
                bpm = 20.0f;
            }

            const float per_beat = 60.0f / bpm * (float)SYNTH_SAMPLE_RATE;

            s_beat_acc += (float)SYNTH_BLOCK_SAMPLES;

            if (s_beat_acc >= per_beat) {
                s_beat_acc -= per_beat;
                s_beat_count = s_beat_count + 1u;
            }
        }

        /* The rescue trail: one load a block, and the copy is taken only on the block a
         * rescue happened in. The statistics task below writes it to RTC memory. */
        /*
         * Детектор разрыва: соседние сэмплы ОДНОГО канала (в буфере они вперемешку), и
         * перепад выше порога считается скачком. prev держится между блоками, поэтому стык
         * блоков тоже проверяется.
         */
        {
            static int32_t prev_l;
            static int32_t prev_r;

            uint32_t worst = 0;
            int32_t pl = prev_l;
            int32_t pr = prev_r;

            for (int i = 0; i < SYNTH_BLOCK_SAMPLES; i++) {
                const int32_t l = (int32_t)s_stereo_out[2 * i];
                const int32_t r = (int32_t)s_stereo_out[2 * i + 1];
                const int32_t dl = (l > pl) ? (l - pl) : (pl - l);
                const int32_t dr = (r > pr) ? (r - pr) : (pr - r);

                if ((uint32_t)dl > worst) {
                    worst = (uint32_t)dl;
                }
                if ((uint32_t)dr > worst) {
                    worst = (uint32_t)dr;
                }

                pl = l;
                pr = r;
            }

            prev_l = pl;
            prev_r = pr;

            if (s_patch_gen != s_patch_gen_seen) {
                s_patch_gen_seen = s_patch_gen;
                s_patch_window = JUMP_WINDOW_BLOCKS;
            } else if (s_patch_window > 0u) {
                s_patch_window--;
            }

            if (worst > JUMP_THRESHOLD) {
                if (s_patch_window > 0u) {
                    s_jump_in_patch = s_jump_in_patch + 1u;
                } else {
                    s_jump_events = s_jump_events + 1u;
                }
            }

            if (worst > s_jump_max_q) {
                s_jump_max_q = worst;
            }
        }

        rescue_poll();

        /*
         * The percussion's telemetry, published here rather than beside the microphone's
         * own above: the microphone is published BEFORE the render because the render
         * consumes it, while the drum's number is produced BY the render — the voices are
         * only advanced inside it — and cannot be had any earlier. Same task, same block,
         * one line lower. See publish_perc_env().
         */
        publish_perc_env();

        const int64_t t1 = esp_timer_get_time();

        size_t written = 0;
        const esp_err_t err =
            bsp_audio_out_write(s_stereo_out, sizeof(s_stereo_out), &written, 100);

        /*
         * A short write is a failure too: the DAC has been handed fewer bytes than the
         * block contains, so the next block would arrive out of place even though the
         * driver called it a success.
         */
        const bool write_ok = (err == ESP_OK && written == sizeof(s_stereo_out));

        /* The DSP budget is measured before any recovery wait: a deliberate pause is
         * pacing, not work, and must not appear as an overload. */
        const uint32_t dsp_us = (uint32_t)(t1 - t0);
        s_dsp_us_last = dsp_us;

#if STAGE_TIMING
        stage_report_block(t_pre, t_gen, dsp_us);
#endif

        s_dsp_us_sum = s_dsp_us_sum + (uint64_t)dsp_us;
        s_dsp_us_n = s_dsp_us_n + 1u;

        if (dsp_us > s_dsp_us_max) {
            s_dsp_us_max = dsp_us;
        }
        if (dsp_us > budget_us) {
            s_deadline_misses = s_deadline_misses + 1;

            const uint32_t run = s_miss_run + 1u;
            s_miss_run = run;
            if (run > s_miss_run_max) {
                s_miss_run_max = run;
            }

            const uint32_t w = s_overload_w;
            s_overload[w & (OVERLOAD_SLOTS - 1)].block = s_blocks;
            s_overload[w & (OVERLOAD_SLOTS - 1)].us = dsp_us;
            s_overload[w & (OVERLOAD_SLOTS - 1)].voices = (int16_t)synth_perc_active_voices();
            s_overload_w = w + 1;
        } else {
            s_miss_run = 0u;
        }
        s_blocks = s_blocks + 1;
        s_cpu_load = s_synth.getCPULoad();

        if (!write_ok) {
            /*
             * Counted and published here, printed by the statistics task: a log line in
             * this loop would be worse than the dropout it reports. The old path also
             * did `continue` before the counters above, so a failing write was invisible
             * in the block and DSP figures as well as unpaced.
             *
             * The channel is NOT torn down and rebuilt on error. bsp_audio_out_deinit()
             * plus init() allocates DMA and reconfigures I2S, which cannot run in the
             * audio task without losing far more than the failed block; the errors that
             * actually occur (a timeout, a stopped channel) leave the driver intact and
             * the next write is the retry. If writes keep failing, the statistics line
             * and its warning say so every second rather than flooding the port.
             *
             * Plain assignment rather than ++: the counter is volatile, and C++20
             * deprecated incrementing a volatile-qualified value.
             */
            s_write_errors = s_write_errors + 1u;
            s_write_last_err = (int)err;
            s_write_last_bytes = (int)written;

            /*
             * The I2S clock did not pace this block. Wait one block from here, and keep
             * doing so for as long as the failures last; the deadline is re-seeded when
             * it has fallen far enough behind that the write itself blocked for longer
             * than its own block.
             */
            const int64_t now = esp_timer_get_time();
            if (write_pace_us <= 0 || now - write_pace_us > 100000) {
                write_pace_us = now;
            }
            write_pace_us += (int64_t)budget_us;
            wait_for_block_pace(write_pace_us);
        } else {
            write_pace_us = 0;
        }
    }
}

/*
 * The factory answer for one stored patch value, installed into app_settings so that the
 * component that owns NVS can repair a value without knowing the parameter table. Called
 * only for a value that is not finite or is outside 0..1; the log line is written there.
 */
static float patch_value_repair(int index, float value)
{
    (void)value;

    if (index < 0 || index >= (int)SYNTH_PARAM_PATCH_COUNT) {
        return 0.0f;
    }
    return synth_app_param_default((synth_param_t)index);
}

static void stats_task(void *arg)
{
    (void)arg;

    uint32_t write_seen = 0;
    uint32_t stats_ticks = 0;

    for (;;) {
        vTaskDelay(pdMS_TO_TICKS(STATS_PERIOD_MS));

        /* The rescue record reaches RTC memory here, off the audio task. At most a second
         * after the failure, which is far shorter than the hand that reaches for the power
         * switch. See the note over RESCUE_RTC_MAGIC. The line itself is printed right
         * after it, from the same snapshot: the audio task neither prints nor blocks. */
        rescue_commit();
        rescue_report();

#if MIC_TEST_ENABLE
        /* MIC PROBE (retired; MIC_TEST_ENABLE is 0) — one line a second. Printed
         * here, not in the audio task: a blocking UART write is the one thing that
         * would make this probe audible. peak and rms are 16-bit sample counts, dc
         * is the residual offset, n is how many samples the second delivered. */
        if (s_mic_out_serial != s_mic_seen_serial) {
            s_mic_seen_serial = s_mic_out_serial;
            ESP_LOGI(TAG, "mic: peak=%" PRIu32 " rms=%" PRIu32 " dc=%" PRId32
                          " n=%" PRIu32 " err=%" PRIu32,
                     s_mic_out_peak, s_mic_out_rms, s_mic_out_dc,
                     s_mic_out_n, s_mic_out_errs);
            if (s_mic_out_errs > 0) {
                ESP_LOGW(TAG, "mic: %" PRIu32 " of %d reads returned no data (last: %s)",
                         s_mic_out_errs, MIC_TEST_WINDOW_BLOCKS,
                         esp_err_to_name((esp_err_t)s_mic_out_last_err));
            }
        }
#endif /* MIC_TEST_ENABLE */

        /*
         * The battery is here rather than in its own line because its whole open question
         * is whether the sense pin follows the CELL or a fixed rail, and the answer is a
         * trend: a cell moves over hours, a rail does not. The raw pin voltage is printed
         * rather than the cell voltage for the same reason — it is the measurement, not
         * the guess that the divider constant still is. See bsp_battery.h.
         */

        /*
         * The blocks that ran past the budget, out of the record the audio task left. Logged
         * here and never there: a UART write inside the audio task would be the loudest
         * thing on the instrument. Three a second at most, so a burst cannot flood the port,
         * and the oldest are skipped rather than queued.
         */
        {
            const uint32_t ow = s_overload_w;
            bool ow_printed = false;

            if (ow - s_overload_seen > 3) {
                s_overload_seen = ow - 3;
            }

            while (s_overload_seen != ow && !ow_printed) {
                const overload_rec_t *r = &s_overload[s_overload_seen & (OVERLOAD_SLOTS - 1)];

                ESP_LOGW(TAG, "overload: block %" PRIu32 ", %" PRIu32 " us (budget %" PRIu32
                              "), drum voices %d",
                         r->block, r->us,
                         (uint32_t)((uint64_t)SYNTH_BLOCK_SAMPLES * 1000000ULL / SYNTH_SAMPLE_RATE),
                         (int)r->voices);

                s_overload_seen = s_overload_seen + 1;
                ow_printed = true;
            }
        }

        /*
         * A write error is printed once for the whole second in which it happened, from
         * here rather than from the audio task, and the audio task records only the last
         * one. One line a second is the rate limit; a persistent failure therefore reads
         * as a running total rather than as a waterfall.
         */
        const uint32_t wr = s_write_errors;
        if (wr != write_seen) {
            ESP_LOGW(TAG, "write: %" PRIu32 " block(s) failed (%" PRIu32 " total), "
                          "last %s after %d bytes",
                     wr - write_seen, wr, esp_err_to_name((esp_err_t)s_write_last_err),
                     (int)s_write_last_bytes);
            write_seen = wr;
        }

        /*
         * One short line every ten seconds. The counters are already kept for
         * synth_app_get_stats(); this is the reader that makes them visible without a
         * debugger attached, and the rescue count is the rack's fuse asking for attention
         * rather than a number that could be inferred from the other five.
         */
        if (++stats_ticks >= 10u) {
            stats_ticks = 0;

#if STAGE_TIMING
            /* Read before the reset below puts it back to the last block's own time. */
            const uint32_t window_dsp_max = s_dsp_us_max;
#endif

            const uint32_t n_dsp = s_dsp_us_n;
            const uint32_t avg_dsp = (n_dsp > 0u)
                                     ? (uint32_t)(s_dsp_us_sum / (uint64_t)n_dsp) : 0u;

            /* `runs` — самая длинная серия опоздавших блоков подряд. Меньше двенадцати
             * (столько блоков держит очередь звука) значит, что до уха ничего не дошло. */
            uint32_t runs = s_miss_run_max;
            s_miss_run_max = s_miss_run;

            ESP_LOGI(TAG, "stats: cpu %.0f%%, blocks %" PRIu32 ", miss %" PRIu32
                          ", runs %" PRIu32 ", wrerr %" PRIu32 ", dsp avg %" PRIu32
                          " us, max %" PRIu32 " us, rescue %" PRIu32 ", fxlate %" PRIu32
                          ", fxmax %" PRIu32 ", gap %" PRIu32 " us, gaps %" PRIu32
                          ", jump %" PRIu32 "/%" PRIu32 " max %" PRIu32 ", fx %d",
                     (double)s_cpu_load, s_blocks, s_deadline_misses, runs, s_write_errors,
                     avg_dsp, s_dsp_us_max, synth_rack_rescue_count(), synth_rack_fx_late(),
                     synth_rack_fx_late_max(), (uint32_t)s_gap_us_max, (uint32_t)s_gap_bad,
                     s_jump_in_patch, s_jump_events, s_jump_max_q, fx_type());

            s_dsp_us_sum = 0u;
            s_dsp_us_n = 0u;

            /*
             * The worst block is put back to the last block's own time HERE, with the line
             * that reports it, because the two describe the same window: the ten seconds
             * since the previous line. Measured from the audio task's own figure rather than
             * from zero, so the next line never reads lower than the block that is running,
             * and the audio task's compare-and-store beside it needs no lock — it can only
             * raise the value this store has put there.
             *
             * Not with the overload record above, which is read every second: nine of those
             * windows out of ten are never printed, and a per-second peak standing beside a
             * since-boot `miss` is a number that cannot be compared with anything on the
             * line — measured on the instrument as 2342 us printed while 253 blocks of the
             * same interval had overrun.
             */
            s_dsp_us_max = s_dsp_us_last;

#if STAGE_TIMING
            /*
             * The stage table for the same ten seconds, one line per stage: the average over
             * the window and the worst block in it, both in microseconds, and the share of
             * the 5333 us a block has. Printed from HERE and not from the audio task for the
             * reason every other line is: a UART write in the block is longer than a block.
             */
            {
                uint32_t sum_us[SYNTH_STAGE_COUNT];
                uint32_t max_us[SYNTH_STAGE_COUNT];
                uint32_t blocks = 0;

                synth_stage_window(sum_us, max_us, &blocks);

                const uint32_t budget = synth_stage_budget_us();

                ESP_LOGI(TAG, "stage: window %" PRIu32 " blocks, budget %" PRIu32
                              " us, dsp max %" PRIu32 " us, miss %" PRIu32,
                         blocks, budget, window_dsp_max, s_deadline_misses);

                for (int s = 0; s < (int)SYNTH_STAGE_COUNT; s++) {
                    const uint32_t avg = (blocks > 0u)
                                             ? ((sum_us[s] + blocks / 2u) / blocks) : 0u;

                    ESP_LOGI(TAG, "stage: %-19s avg %4" PRIu32 " us, max %4" PRIu32
                                  " us, %4.1f%% of budget",
                             synth_stage_name((synth_stage_t)s), avg, max_us[s],
                             (budget > 0u) ? ((double)avg * 100.0 / (double)budget) : 0.0);
                }


            }
#endif /* STAGE_TIMING */
        }

    }
}

/* -------------------------------------------------------------------------- */
/* Entry point                                                                */
/* -------------------------------------------------------------------------- */


extern "C" void synth_app_start(void)
{
    /* If a signature here ever drifts from the engine's typedef, the build stops
     * with this rather than with a corrupted call at runtime. */
    static_assert(std::is_same<decltype(&synth_fx_pan_capture), SynthCustomFXCallback>::value,
                  "synth_fx_pan_capture must match SynthCustomFXCallback");
    static_assert(std::is_same<decltype(&synth_fx_drone_filter), SynthCustomFXCallback>::value,
                  "synth_fx_drone_filter must match SynthCustomFXCallback");

    /*
     * Before anything else: the previous session's last rescue, if the RTC domain survived
     * the reset. A normal power-off leaves no magic and this prints nothing — which is
     * also what tells the two apart. See rescue_rtc_report().
     */
    rescue_rtc_report();

    /* Every layer lives on its own bus above the master. The engine's setters
     * reject out-of-range bus ids silently rather than asserting, so a
     * regression in MAX_BUSES would show up as a layer that is simply not
     * audible — this turns that into a build failure. */
    static_assert(MAX_BUSES >= SYNTH_NUM_LAYERS + 1,
                  "MAX_BUSES must cover the master bus plus every instrument layer");

    /*
     * Installed before anything can read the remembered sound: a stored value that is not
     * finite or is outside the control surface's range is repaired to its factory value at
     * the load boundary, not carried into the engine. See app_settings_patch_load().
     */
    app_settings_patch_set_repair(patch_value_repair);

    if (!bsp_audio_out_is_ready()) {
        ESP_LOGE(TAG, "audio output is not up; not starting the instrument");
        return;
    }

    /* The control surface starts at its designed values, and -1 in s_applied
     * makes the first audio block push all of them into the engine even though
     * buses_init() has already written the same numbers. That redundancy is the
     * point: it proves the whole parameter path works on every boot rather than
     * only after someone touches a knob. */
    for (int p = 0; p < (int)SYNTH_PARAM_COUNT; p++) {
        s_param[p] = synth_app_param_default((synth_param_t)p);
        s_cur[p] = s_param[p];
        s_from[p] = s_param[p];
        s_applied[p] = -1.0f;
    }
    s_slide_pos = 1.0f;

    /* A different line every boot. A generative sequencer that plays the same
     * melody each time you switch it on is a recording rather than an
     * instrument, so the seed comes from the clock and not from a constant.
     * The OR keeps it nonzero, which xorshift32 requires of its state. */
    s_seq_rng = (uint32_t)esp_timer_get_time() | 1u;

    synth_dsp_init(SYNTH_SAMPLE_RATE);
    synth_rack_set_master(0.9f);

    /* The microphone's filter and envelope coefficients, from the sample rate and the
     * block size. Here rather than per block: they never change, and this runs before
     * the audio task exists. The microphone's own setting is 0 at this point, so the
     * input is not read until someone turns it up. The percussion's display envelope has
     * one coefficient of its own and is initialised beside it. */
    mic_init();
    perc_env_init();

    /*
     * THE MICROPHONE'S DRIVER GAIN IS PRIMED HERE, off the audio deadline.
     *
     * bsp_audio_in_set_gain() is not a register poke: the first call reconfigures the PDM RX
     * channel, and measured on the instrument it costs about 4.8 ms — which is 90 percent of a
     * block. It used to happen in whichever audio block the restored setting happened to be
     * applied in, and that was the boot overload: lock 40, 9403 us, drum voices 0, every
     * single boot, with the drum innocent and the microphone nameless in the record.
     *
     * The value is the stored one and not the parameter default, so the restore that follows
     * finds the driver already at the step it is asking for and does nothing: mic_driver_apply()
     * compares the step before it touches the driver. Zero — the factory setting — returns
     * before any of this, so a device that has never used the microphone pays nothing.
     */
    mic_driver_apply((float)app_settings_get(APP_SET_MIC) / 100.0f);

    /*
     * The engine has no locking whatsoever — no critical sections, no atomics,
     * not even volatile on the voice array. Every setter is a plain write to a
     * struct the render path reads. So all configuration happens here, before
     * the audio task exists, and later phases must route user input through a
     * queue that the audio task drains rather than calling the engine directly.
     */
    if (!engine_init()) {
        return;
    }
    buses_init();
    voices_init();
    apply_fx_tempo();     /* STUTTER считает сетку от транспорта — ему нужен темп сразу */

    ESP_LOGI(TAG, "engine up: %d Hz, %d voices, %d buses, control rate %d Hz",
             SYNTH_SAMPLE_RATE, MAX_VOICES, MAX_BUSES, CONTROL_RATE_HZ);

    /*
     * THE DRUM'S TWO LIST POSITIONS, BY NAME, once per boot.
     *
     * Both are normalised positions in a list that has changed size — KIT grew from sixteen to
     * twenty-four, GROOVE from sixteen to seventeen — and a stored patch keeps the POSITION, not
     * the kit. So the same saved sound can come back on a different kit after an update, and the
     * only place that says which one is a sector on the PERC page. One line at boot answers the
     * question before it is asked: what did my patch land on.
     */
    ESP_LOGI(TAG, "perc: kit %d/%d %s, groove %d/%d %s",
             perc_kit_index() + 1, PERC_KIT_COUNT, s_perc_kit_names[perc_kit_index()],
             perc_groove_index() + 1, PERC_GROOVE_COUNT, s_perc_groove_names[perc_groove_index()]);

    /* Шаг фазы нужен первому же блоку, иначе оба LFO стоят, пока не тронешь SPEED. */
    mod_rate_refresh();

    if (xTaskCreatePinnedToCore(audio_task, "synth_audio", AUDIO_TASK_STACK, nullptr,
                                AUDIO_TASK_PRIO, nullptr, AUDIO_TASK_CORE) != pdPASS) {
        ESP_LOGE(TAG, "could not create the audio task");
        return;
    }

    xTaskCreatePinnedToCore(stats_task, "synth_stats", STATS_TASK_STACK, nullptr,
                            STATS_TASK_PRIO, nullptr, STATS_TASK_CORE);

}

/* -------------------------------------------------------------------------- */
/* Control surface — called from any task                                     */
/* -------------------------------------------------------------------------- */

extern "C" void synth_app_set_param(synth_param_t param, float v01)
{
    if (!param_valid(param)) {
        return;
    }
    s_param[param] = clamp01(v01);

    /*
     * THE SNAP BELONGS TO THE CONTROL SURFACE, and this is where the control surface writes.
     *
     * It was in apply_perc() first, which runs in the audio task, and that put a write to
     * s_param[] inside a block alongside the modulation's own save-and-restore of the same
     * parameter — the modulated value was snapped away and the restore then put the base back,
     * so the pitch of the next hit jumped about while the knob was being turned. Here there is
     * one writer, on the task that owns the knob, and the audio task sees a value that only
     * changes when a hand or a preset changes it.
     *
     * Three parameters change the answer: the pitch itself, the scale, and the root. PERC
     * QUANT is the fourth, because turning it on has to snap the pitch that is already there.
     */
    if (param == SYNTH_PARAM_PERC_PITCH || param == SYNTH_PARAM_PERC_QUANT ||
        param == SYNTH_PARAM_SCALE || param == SYNTH_PARAM_ROOT ||
        param == SYNTH_PARAM_ROOT_OCT) {
        perc_pitch_snap();

        /* И базис дрона: та же смена тональности, тот же повод. */
        drone_base_update();
    }

    /*
     * The microphone's driver step, on THIS task and never on the audio one: the first
     * set_gain() reconfigures the PDM RX channel and costs about 4.8 ms. See apply_mic().
     */
    if (param == SYNTH_PARAM_SET_MIC) {
        mic_driver_sync();
    }
}

extern "C" float synth_app_get_param(synth_param_t param)
{
    if (!param_valid(param)) {
        return 0.0f;
    }
    return s_param[param];
}



extern "C" void synth_app_get_params(float *out, int count)
{
    if (!out) {
        return;
    }
    if (count > SYNTH_PARAM_PATCH_COUNT) {
        count = SYNTH_PARAM_PATCH_COUNT;
    }
    for (int i = 0; i < count; i++) {
        out[i] = s_param[i];
    }
}

extern "C" float synth_app_param_default(synth_param_t param)
{
    switch (param) {
    case SYNTH_PARAM_LEVEL:
        /*
         * 80% and not full scale. MASTER_AT_FULL_SCALE is 0.9 because the layer faders
         * already sum to about 1.0 and the soft clipper is headroom, not a level; a
         * fresh instrument that opens at 100% of that has nothing left for the player
         * to turn up, and on headphones it is an injury rather than a surprise. 0.8 is
         * the designed listening level and it is what a fresh state and a reset get.
         *
         * A stored patch or a preset is NOT this number: both carry the level as their
         * first value and synth_app_patch_apply() writes the stored one over this
         * default, so a device that was left at some other level comes back to exactly
         * that level. Only a parameter the record does not carry keeps this default.
         */
        return 0.8f;
    case SYNTH_PARAM_MASTER_COMP:
        return 0.0f;        /* off — and off is bit-transparent, so the sound is unchanged */
    case SYNTH_PARAM_MASTER_DUCK:
        return 0.0f;        /* off: the drone's low end is the drone's, as it has always been */
    case SYNTH_PARAM_MASTER_DUCK_SRC:
        return 0.0f;        /* LP: дакинг слышит удар целиком, как до этих ручек */
    case SYNTH_PARAM_MASTER_DUCK_REL:
        return 0.35f;       /* ~180 мс: середина прежнего хода 220..90 */
    case SYNTH_PARAM_PERC_MIX_KICK:
    case SYNTH_PARAM_PERC_MIX_SNARE:
    case SYNTH_PARAM_PERC_MIX_HAT:
    case SYNTH_PARAM_PERC_MIX_TOM:
        return 1.0f;        /* дорожка звучит так, как её записал кит */
    case SYNTH_PARAM_GEN_SPAN:
        /* Two octaves at the middle detent: the walk the generator had before the knob
         * existed, so every sound saved earlier plays as it was recorded. */
        return 0.5f;
    case SYNTH_PARAM_DRONE_DRIFT:
        /* Ноль: ни одного цента. Всё, что было сохранено раньше, звучит как звучало. */
        return 0.0f;
    case SYNTH_PARAM_LEAD_PW:
        /* ЦЕНТР, А НЕ НОЛЬ: ноль теперь означает пять процентов, то есть тонкий импульс.
         * Половина хода даёт 50 %, то есть ровно меандр, и старый патч без этого поля
         * звучит как прежде. */
        return 0.5f;
    case SYNTH_PARAM_SEQ_ACCENT:
        return 0.0f;        /* OFF: the lead's notes keep the velocity they always had */
    case SYNTH_PARAM_ARP_ACCENT:
        return 0.0f;        /* OFF: the arp strikes every step at the key's own velocity */
    case SYNTH_PARAM_LEAD_SPREAD:
        return 0.0f;        /* без разброса: патч звучит как прежде */
    case SYNTH_PARAM_CUTOFF:
        return 0.5f;        /* the designed cutoff */
    case SYNTH_PARAM_RESONANCE:
        return 0.0f;        /* the designed Q, no added resonance */
    case SYNTH_PARAM_FILTER_RATE:
        return 0.0f;        /* the designed LFO rate */
    case SYNTH_PARAM_FILTER_DEPTH:
        /*
         * ГЛУБИНА СОБСТВЕННОГО МОДУЛЯТОРА ФИЛЬТРА ЗАВОДСКИ — НОЛЬ.
         *
         * Было 0.5: прибор включался с развёрткой в две октавы на LOW, и нижнее положение
         * ручки DEPTH означало не «фильтр стоит», а «фильтр стоит вдвое тише заводской
         * развёртки». Владелец попросил, чтобы глубина задавалась от нуля: свежий патч
         * приходит с неподвижным фильтром, а развёртка появляется только от руки.
         */
        return 0.0f;
    case SYNTH_PARAM_MOTION_DEPTH:
        /* Zero as well: the drift is the same kind of depth and a fresh instrument
         * should not arrive already drifting. */
        return 0.0f;
    case SYNTH_PARAM_MOTION_RATE:
        return 0.0f;        /* the designed drift rate */
    case SYNTH_PARAM_LEAD_LEVEL:
        /* sqrt(0.5): the layer level the lead was voiced at, 0.25, reached through the
         * fader law. The readout prints that 25 %. */
        return 0.7071f;
    case SYNTH_PARAM_SEQ_TEMPO:
        return SEQ_TEMPO_DEFAULT;   /* 60 BPM: one note per second */
    case SYNTH_PARAM_SEQ_GATE:
        return 0.5f;        /* half of each step */
    case SYNTH_PARAM_SCALE:
        return SEQ_SCALE_DEFAULT;
    case SYNTH_PARAM_ROOT:
        return SEQ_NOTE_DEFAULT;
    case SYNTH_PARAM_ROOT_OCT:
        return SEQ_OCT_DEFAULT;
    case SYNTH_PARAM_DENSITY:
        return SEQ_DENSITY_DEFAULT;
    case SYNTH_PARAM_OCTAVE:
        return SEQ_OCTAVE_DEFAULT;
    case SYNTH_PARAM_LFO_SHAPE:
        return SEQ_SHAPE_DEFAULT;
    case SYNTH_PARAM_MOD_DEST2:
        /* PAN: вместе с FILTER у DEST это прежнее FILT+PAN. */
        return 2.0f / (float)(MOD_DEST_COUNT - 1);
    case SYNTH_PARAM_MOD_DEST:
        /* FILT+PAN — the same destination the static s_mod_dest above carries and the one the page
         * did before the choice existed. The knob is read as round(v * (MOD_DEST_COUNT - 1)) by
         * both apply_mod_dest() and the readout, so a destination is written as its index over
         * that divisor and not as a frozen position: FILT+PAN is index 2, so 2 / 8 = 0.25.
         *
         * The 1.0 that used to stand here was the LAST entry of the list, LEAD+PERC (index 8): no
         * boot ever selected FILTER or FILT+PAN, so WIDTH's share never reached the filter's LFO
         * and the modulation page's WIDTH and SPEED drove the lead and percussion instead. A
         * division like ARP_SPEED and DELAY_SYNC in this same switch, and for the same reason: a
         * position goes on meaning whatever ends up standing in it, and this list is nine entries
         * long. */
        return (float)2 / (float)(MOD_DEST_COUNT - 1);
    case SYNTH_PARAM_MOD_TRIG:
        return 0.0f;        /* FREE: the modulation ran with the figure before this existed */
    case SYNTH_PARAM_MOD_DEPTH2:
        /* Ноль, как и у первой: прибор открывается без модуляции. */
        return 0.0f;
    case SYNTH_PARAM_MOD2_SHAPE:
        return SEQ_SHAPE_DEFAULT;
    case SYNTH_PARAM_MOD2_DEST:
        return 1.0f / (float)(MOD_DEST_COUNT - 1);
    case SYNTH_PARAM_MOD2_DEST2:
        return 2.0f / (float)(MOD_DEST_COUNT - 1);
    case SYNTH_PARAM_MOD2_DEPTH:
    case SYNTH_PARAM_MOD2_DEPTH2:
        /* Середина хода: ноль, как и у первого LFO. */
        return 0.5f;
    case SYNTH_PARAM_MOD2_RATE:
        return 0.0f;        /* заводская скорость дрейфа */
    case SYNTH_PARAM_MOD_DEPTH:
        /* СЕРЕДИНА ХОДА — НОЛЬ ГЛУБИНЫ. Ручка двусторонняя: влево уходит в противофазу,
         * вправо в фазу. Заводское положение молчит, как и раньше. */
        return 0.5f;
    case SYNTH_PARAM_SEQ_STEPS:
        return SEQ_STEPS_DEFAULT;
    case SYNTH_PARAM_SEQ_PULSES:
        return SEQ_PULSES_DEFAULT;
    case SYNTH_PARAM_SEQ_ROTATE:
        return SEQ_ROTATE_DEFAULT;
    case SYNTH_PARAM_SEQ_SCATTER:
        return SEQ_SCATTER_DEFAULT;
    case SYNTH_PARAM_DRONE_LOW:
        return DRONE_LOW_DEFAULT;
    case SYNTH_PARAM_DRONE_MID:
        return DRONE_MID_DEFAULT;
    case SYNTH_PARAM_DRONE_HIGH:
        return DRONE_HIGH_DEFAULT;
    case SYNTH_PARAM_LEAD_CUTOFF:
        return lead_fc_v01(LEAD_FC_DEFAULT_HZ);
    case SYNTH_PARAM_LEAD_RESO:
        return lead_q_v01(LEAD_Q_DEFAULT);
    case SYNTH_PARAM_LEAD_ENV:
        /* The factory travel, at the factory corner: the one position on the new
         * percentage scale that is the sound a stored patch had. */
        return lead_env_v01_for(LEAD_ENV_DEFAULT_OCT, LEAD_FC_DEFAULT_HZ);
    case SYNTH_PARAM_LEAD_ATTACK:
        return lead_time_v01(LEAD_AMP_ATTACK_DEFAULT_MS);
    case SYNTH_PARAM_LEAD_DECAY:
        return lead_time_v01(LEAD_AMP_DECAY_DEFAULT_MS);
    case SYNTH_PARAM_LEAD_SUSTAIN:
        return LEAD_AMP_SUSTAIN_DEFAULT;
    case SYNTH_PARAM_LEAD_RELEASE:
        return lead_time_v01(LEAD_AMP_RELEASE_DEFAULT_MS);
    case SYNTH_PARAM_LEAD_FENV_SHAPE:
        return LEAD_FENV_SHAPE_DEFAULT;
    case SYNTH_PARAM_LEAD_VOICE:
        return LEAD_VOICE_DEFAULT;
    case SYNTH_PARAM_LEAD_PORTA:
        return 0.0f;        /* off: the designed articulation, no glide at all */
    case SYNTH_PARAM_ARP_DIR:
        return 0.0f;        /* off: the arp is switched from its DIR, not its speed */
    case SYNTH_PARAM_ARP_SPEED:
        /* 1/4, and written as the division rather than as its position: the list has
         * grown twice and a frozen number would have gone on meaning whatever ended up
         * standing there. The division is what the instrument was voiced at, and the
         * division is what it must boot to. */
        return (float)ARP_SPEED_DEFAULT / (float)(ARP_SPEED_COUNT - 1);
    case SYNTH_PARAM_ARP_LEN:
        return 0.5f;        /* five notes to cross the range */
    case SYNTH_PARAM_ARP_RANGE:
        /* One octave: the shortest range that is a line rather than a pedal, and the one the
         * instrument was voiced at. Index 1 of 0..5, written as the position rather than as a
         * frozen number: the list has changed shape once already. */
        return 1.0f / (float)ARP_RANGE_MAX;

    /*
     * THE DRUM SECTION'S ELEVEN. Every one of them boots to the setting the section was
     * tuned at rather than to an extreme: MINI's recipes, no transposition, the kit's own
     * gates and bodies, a little life, the written figures with a modest amount of variation
     * and a fill now and then, and the transport's own speed. A fresh instrument therefore
     * plays a drum part that is recognisably a part, and every knob's first movement is a
     * change the player caused rather than a rescue.
     *
     * KIT is written as a division and not as a frozen position, for the reason every list on
     * this instrument is: MINI is the second of the eight, so 1 / 7.
     */
    case SYNTH_PARAM_PERC_KIT:
        return (float)PERC_KIT_MINI / (float)(PERC_KIT_COUNT - 1);
    case SYNTH_PARAM_PERC_TONE:
    case SYNTH_PARAM_PERC_TUNE:
        return 0.5f;        /* no transposition */
    case SYNTH_PARAM_PERC_LENGTH:
    case SYNTH_PARAM_PERC_BODY_TRIM:
        return 0.5f;        /* the kit's own gate and body, untouched */
    case SYNTH_PARAM_PERC_TIMBRE:
        return 0.35f;       /* alive, but able to repeat itself */
    case SYNTH_PARAM_PERC_GROOVE:
        return (float)PERC_GROOVE_MINIPOP / (float)(PERC_GROOVE_COUNT - 1);
    case SYNTH_PARAM_PERC_VARIATION:
        return 0.20f;
    case SYNTH_PARAM_PERC_FILL:
        return 0.40f;
    case SYNTH_PARAM_PERC_SWING:
        /* STRAIGHT. The written grooves are the music; swing is a decision a player makes,
         * and a fresh instrument that arrives already pushing the offbeats sounds like a
         * drummer who cannot keep time — which is exactly what a written hat on an odd
         * sixteenth plus a quarter of a step of swing sounded like. See perc_tick(). */
        return 0.0f;
    case SYNTH_PARAM_PERC_SPEED:
        /* ×1 — четвёртое из семи положений, не середина ручки: положений семь, промежутков
         * шесть. Записано индексом, чтобы смена количества переносила его сама. */
        return 3.0f / (float)(PERC_SPEED_COUNT - 1);

    /*
     * The effects. Every MIX is zero, so the instrument boots to the designed
     * sound and the effects stay something the player adds; the rest of each group
     * is set to the value that makes the first movement of that MIX worth
     * hearing.
     */
    case SYNTH_PARAM_DELAY_SYNC:
        /* 1/8 by name and not by position, for the arp's reason and with a sharper edge:
         * 0.5 was 1/8 against the old five-entry list and is a dotted eighth against this
         * one, which is exactly the drift the one-time migration in app_settings.c
         * rewrites in any sound already sitting in the flash. */
        return (float)DELAY_SYNC_DEFAULT / (float)(DELAY_DIV_COUNT - 1);
    case SYNTH_PARAM_DELAY_TIME:
        /* Слитая ручка стоит на 1/8 — на том самом эхе, которым прибор озвучен. */
        return (float)DELAY_TIME_DEFAULT / (float)(DELAY_TIME_STEPS - 1);
    case SYNTH_PARAM_DELAY_DAMP:
        return 0.0f;        /* открыто: повторы как были до этой ручки */
    case SYNTH_PARAM_DELAY_VERB:
        /* Ноль: повторы в реверб не уходят, всё как было до этой ручки. */
        return 0.0f;
    case SYNTH_PARAM_DELAY_FEEDBACK:
        return 0.37f;
    case SYNTH_PARAM_DELAY_MIX:
        /* Восемьдесят процентов: эффект должен быть слышен из коробки. */
        return 0.8f;
    case SYNTH_PARAM_DELAY_TIMEMODE:
        /* TAPE: the behaviour the delay has always had, so a device nobody has touched —
         * and every sound saved before this choice existed — plays exactly as it did. */
        return 0.0f;
    case SYNTH_PARAM_CHORUS_RATE:
        return chorus_rate_v01(0.6f);
    case SYNTH_PARAM_CHORUS_DEPTH:
        return 0.35f;
    case SYNTH_PARAM_FX_TYPE:
        /* ХОРУС: ноль значит именно его, поэтому ни один старый патч не меняет звук. */
        return 0.0f;
    case SYNTH_PARAM_FX_C:
        /* Середина третьего параметра: у всех эффектов она осмысленная. */
        return 0.5f;
    case SYNTH_PARAM_FX_VERB:
        /* Ноль: возврат машины в реверб не уходит, как было. */
        return 0.0f;
    case SYNTH_PARAM_CHORUS_MIX:
        /* Восемьдесят процентов: эффект должен быть слышен из коробки. */
        return 0.8f;
    case SYNTH_PARAM_VERB_MODE:
        /* HALL: the tuning this reverb has always had, so a device nobody has touched
         * sounds exactly as it did before there was a choice to make. */
        return (float)SYNTH_REVERB_HALL / (float)(SYNTH_REVERB_MODE_COUNT - 1);
    case SYNTH_PARAM_VERB_SIZE:
        return VERB_SIZE_DEFAULT;
    case SYNTH_PARAM_VERB_DAMP:
        return VERB_DAMP_DEFAULT;
    case SYNTH_PARAM_VERB_MIX:
        /* Восемьдесят процентов: эффект должен быть слышен из коробки. */
        return 0.8f;
    case SYNTH_PARAM_SEND_LOW:
        return SEND_LOW_DEFAULT;
    case SYNTH_PARAM_SEND_MID:
        return SEND_MID_DEFAULT;
    case SYNTH_PARAM_SEND_HIGH:
        return SEND_HIGH_DEFAULT;
    case SYNTH_PARAM_SEND_LEAD:
        return SEND_LEAD_DEFAULT;

    /*
     * The drum part, silent until it is asked for: LEVEL and SEND at zero, so a
     * device that has never been touched sounds exactly as it did before there was
     * a percussion voice at all — the same rule the effects follow. The rest is a
     * tom: 214 Hz, ringing gently, over ninety milliseconds, with the filter falling
     * a little over one octave.
     *
     * Two of the numbers below are not the ones this patch was voiced with, because the
     * knobs above them grew and the hit itself was not supposed to:
     *
     *   PITCH: the bottom of the knob moved from 55 Hz to 35 Hz, so the same position asks
     *   for a lower note — 0.28 was 214 Hz against the old floor and is 154 Hz against the
     *   new one. 0.3415 is log2(214 / 35) / 7.65, which puts the hit back on 214 Hz to
     *   within half a cent, so the floor only opens downward from there.
     *
     *   ENV: the top of the knob moved from three octaves to five, so the same position
     *   dives deeper — 0.45 was 1.35 octaves against the old top and is 2.25 against the
     *   new one. 0.27 is 0.45 * 3 / 5: the same 1.35 octaves, and the same 1.4 OCT the
     *   knob's own label reads. The whole of the new depth is reachable above the factory
     *   setting and none of it lands on the factory hit, which is what keeps that hit's
     *   level where the module's knee comment measured it — under PERC_LIMIT_KNEE, not
     *   inside it.
     */
    case SYNTH_PARAM_PERC_PITCH:
        return 0.3415f;
    case SYNTH_PARAM_PERC_RESO:
        return 0.35f;
    case SYNTH_PARAM_PERC_DECAY:
        return 0.35f;
    case SYNTH_PARAM_PERC_ENV:
        return 0.27f;
    /*
     * BODY at the bottom of its travel: the noise, and nothing added to it. This is
     * what a device that has never been touched sounds like, and it is also what an
     * older patch or preset gets, because it is a prefix of the parameter list and
     * simply does not carry this value.
     */
    case SYNTH_PARAM_PERC_BODY:
        return 0.0f;
    case SYNTH_PARAM_PERC_LEVEL:
        return 0.0f;
    /*
     * OFF, and off has to be the neutral value: a patch saved before this parameter existed
     * gets the default, and a device that has never been touched must play exactly what it
     * played before the snap was offered.
     */
    case SYNTH_PARAM_PERC_QUANT:
        return 0.0f;
    case SYNTH_PARAM_PERC_STEPS:
        /*
         * ШЕСТНАДЦАТЬ, А НЕ ЧЕТЫРЕ.
         *
         * Грувы написаны на шестнадцати позициях бара и переносятся на сетку ударки
         * пропорционально: позиция local * 16 / n. При четырёх шагах играют только позиции
         * 0, 4, 8 и 12 — то есть из любого рисунка выживает четверть, а всё, что попало на
         * нечётные позиции, не звучит никогда. Хэт «на каждом шестнадцатом» превращался в
         * четыре хэта на бар, а у тестового грува пропадала бочка, потому что её удары
         * стояли на позициях 3, 7, 11 и 15, которых на сетке из четырёх шагов нет.
         *
         * Четыре шага были заводским значением для всех фигур сразу. Ударке нужна своя:
         * бар шестнадцатых — это ровно та сетка, на которой написаны все тридцать три грува.
         */
        return 1.0f;
    case SYNTH_PARAM_PERC_PULSES:
        return SEQ_PULSES_DEFAULT;     /* four pulses: every beat */
    case SYNTH_PARAM_PERC_ROTATE:
        return SEQ_ROTATE_DEFAULT;
    case SYNTH_PARAM_SEND_PERC:
        return 0.0f;

    /*
     * The microphone's send, and the second of the two values that make the microphone
     * silent off the shelf. It is a patch parameter, so it is remembered and drawn like
     * the other sends; what makes it safe is that the SOURCE of it is switched off by
     * its own setting, which is not part of the patch at all.
     */
    case SYNTH_PARAM_SEND_MIC:
        return 0.0f;        /* dead slot: the microphone no longer reaches the sends */

    /*
     * THE BASS SECTION'S SIXTEEN.
     *
     * The twelve macros are the values synth_bass.cpp itself is voiced at — the module's own
     * init() writes the same numbers — so the factory sound of the bass is the module's
     * author's decision and not a second one written here. KIT and PAT are the BOTTOM of
     * their lists, index 0 of thirty, and the bottom of a list is the value 0 on every list
     * this instrument has, so they are written as zero and not as a position.
     *
     * THE FADER IS 0.80, SO THE BASS IS HEARD ON A SOUND THAT PREDATES IT. A patch or a
     * preset written before the section existed carries no byte for these sixteen: a patch
     * leaves the boot's defaults in place and a preset leaves the live values, and either
     * way the first kit at this fader is a bass line under a sound saved without one. That
     * is deliberate: the section is part of the instrument now, and a part present but
     * silent by default is a part nobody finds.
     */
    case SYNTH_PARAM_BASS_KIT:
        return 0.0f;        /* index 0 of thirty: the first round kit */
    case SYNTH_PARAM_BASS_OCT:
        /* Слот 1 теперь SNAP: ручки октавы больше нет, регистр ставит заготовка. */
        return 0.35f;
    case SYNTH_PARAM_BASS_TONE:
        /* Смена ноты по центру: линия там, где её ставит заготовка. */
        return 0.5f;
    case SYNTH_PARAM_BASS_DECAY:
        return 0.55f;
    case SYNTH_PARAM_BASS_SNAP:
        /* Слот 4 теперь SUB: саба нет, пока его не попросили. */
        return 0.0f;
    case SYNTH_PARAM_BASS_DRIVE:
        return 0.20f;
    case SYNTH_PARAM_BASS_PAT:
        return 24.0f / 29.0f;  /* EIGHTH: восьмыми со сдвигом — рисунок, а не метроном */
    case SYNTH_PARAM_BASS_VAR:
        return 0.0f;        /* STEADY: характер выбирают, а не получают по умолчанию */
    case SYNTH_PARAM_BASS_LEN:
        return 1.0f;        /* all sixteen steps of the bar */
    case SYNTH_PARAM_BASS_GATE:
        return 0.50f;
    case SYNTH_PARAM_BASS_SLIDE:
        return 0.15f;
    case SYNTH_PARAM_BASS_ACCENT:
        return 1.0f / 7.0f; /* 1/4: фигура акцентов, та же, что в остальных разделах */
    case SYNTH_PARAM_BASS_LVL:
        return 0.80f;       /* фейдер в уровень остальных частей: голос больше не давится */
    case SYNTH_PARAM_BASS_REV:
        return 0.12f;       /* the low end wants a short room, not a wash */
    case SYNTH_PARAM_BASS_CHR:
        return 0.0f;
    case SYNTH_PARAM_BASS_DLY:
        return 0.0f;

    /*
     * The accent figure, OFF out of the box, for both the parts it drives.
     *
     * OFF is the bottom of the list and it is the velocity every hit has been struck
     * at since the voice existed, and the one every lead note is opened at, so a device
     * that has never been touched, a sound remembered by an older firmware and a preset
     * that predates this parameter all play the drum and the line exactly as they were.
     * Which figure is played is the player's choice.
     */
    case SYNTH_PARAM_PERC_ACCENT:
        return 0.0f;

    /*
     * RESET, sixteen steps, which is the factory position of the list.
     *
     * It is a PATCH parameter now, so this is also the value a record written before it
     * existed comes back with: the record is a prefix of the list and carries no byte for
     * it, and a missing byte must mean sixteen rather than zero — zero is INF, a real
     * choice, and the one value the migration must not land on. See app_seq_reset_t in
     * app_settings.h.
     */
    case SYNTH_PARAM_SEQ_RESET:
        return (float)APP_SEQ_RESET_16 / (float)(APP_SEQ_RESET_COUNT - 1);

    /*
     * The drum's RESET is INF, the gesture off — and that default is the migration.
     *
     * The drum has never started resetting: before this parameter existed the drum played
     * its figure against the lead's phrase, and a sound saved then must come back sounding
     * exactly as it did. So a record without the field reads as zero, which is INF, and not
     * as sixteen: here the missing byte is an absence, not a value with a documented
     * meaning. See SYNTH_PARAM_PERC_RESET and synth_app_preset_load().
     */
    case SYNTH_PARAM_PERC_RESET:
        return 0.0f;

    /*
     * THE THREE SHAPES ARE SAW, which is what the drone sounded like before they existed
     * and what DRONE_WAVE defaults to. A record with no bytes for them gets this and is
     * therefore the sound it was saved with; a record that HAS the old DRONE_WAVE byte gets
     * that byte's value for all three instead — see synth_app_patch_apply().
     */
    case SYNTH_PARAM_DRONE_OSC_LOW:
    case SYNTH_PARAM_DRONE_OSC_MID:
    case SYNTH_PARAM_DRONE_OSC_HIGH:
        /* SAW на прежнем месте: 2 / 5, то есть та же доля хода, что была при шести формах. */
    return (float)PW_DEFAULT / (float)(PW_COUNT - 2);

    /* FOLLOW is SCALE: the pitch class in the nearest direction, which is the drone following
     * the line rather than holding a degree. A record written before the parameter gets this by
     * name rather than by absence, because a mode is a decision and not a hole. */
    case SYNTH_PARAM_DRONE_FOLLOW:
        return (float)DRONE_FOLLOW_SCALE / (float)(DRONE_FOLLOW_COUNT - 1);

    /* Both key trackers at zero: the cutoff is the knob's number and the pitch does not move
     * it. This is the behaviour the instrument had before the two parameters existed, and the
     * value a record without them keeps. */
    case SYNTH_PARAM_DRONE_KTRCK:
    case SYNTH_PARAM_LEAD_KTRCK:
    case SYNTH_PARAM_DRONE_FILTER_MODE:
    case SYNTH_PARAM_LEAD_FILTER_MODE:
        return 0.0f;

    /* Settings. The screen's default is read from the board's own configuration
     * rather than repeated here, so a device that has never been configured
     * reports the brightness it actually booted with. */
    case SYNTH_PARAM_DRONE_WAVE:
    case SYNTH_PARAM_LEAD_WAVE:
        return (float)PW_DEFAULT / (float)(PW_COUNT - 1);
    case SYNTH_PARAM_SET_SCREEN:
        return (float)CONFIG_BSP_LCD_BRIGHTNESS_DEFAULT / 100.0f;
    case SYNTH_PARAM_SET_RING:
        return 1.0f;
    case SYNTH_PARAM_SET_RINGMODE:
        return 0.0f;        /* page-aware */
    case SYNTH_PARAM_SET_AUTOPLAY:
        return 0.0f;        /* ON: как было — прибор играет сразу */
    case SYNTH_PARAM_SET_FASTRAND:
        return 0.5f;        /* PARAM: как было — случайное значение активной ручки */
    case SYNTH_PARAM_SET_PATCH:
        return 2.0f;


    case SYNTH_PARAM_SET_SLIDE:
        return 2.0f;        /* half a second: long enough to hear, short enough to forget */
    case SYNTH_PARAM_SET_RNDDELAY:
        return 1.0f;        /* on: the draw has always been allowed to move the delay time */
    /*
     * The microphone OFF, out of the box.
     *
     * Not a matter of taste: an instrument that listened to the room the moment it was
     * switched on would put every rehearsal into the reverb, and the setting is stored
     * per device rather than per patch for exactly this reason — turning it on is a
     * decision about the player's room and not about the sound being made in it.
     */
    case SYNTH_PARAM_SET_MIC:
        return 0.0f;
    /*
     * The weak hit, at the factory 80 of 127 — the same number the SETTINGS[] row in
     * app_settings.c falls back to, so the control surface, the readout and the sound all
     * begin the day saying the same thing. The engine does not read this copy; see
     * accent_velocity_weak().
     */
    case SYNTH_PARAM_SET_WEAKVEL:
        return (float)WEAK_VEL_FACTORY / (float)WEAK_VEL_MAX;
    /*
     * The note input, OFF — the same answer the SETTINGS[] row in app_settings.c falls back
     * to, so the switch on the screen, the stored byte and the port all begin the day saying
     * the same thing. It is the one setting whose default is about the DEBUG PORT rather than
     * about the sound: up means the USB-C socket is a MIDI interface and the console is gone
     * from the computer. See SYNTH_PARAM_SET_MIDIIN in synth_app.h.
     */
    case SYNTH_PARAM_SET_MIDIIN:
        return 0.0f;
    /*
     * The wave morph, 25 ms — index 5 of the eleven in WAVE_MORPH_MS, which is the same
     * number app_settings.c falls back to, so the knob, the readout and the fade all begin
     * the day saying the same thing. A POSITION, not an index: this table is read by the UI
     * as 0..1 for every control, with the list arithmetic in synth_ui.c's setting_of(), and
     * 5 / 10 = 0.5 is index 5 exactly. The engine does not read this copy; wave_morph_ms()
     * reads the stored setting. See SYNTH_PARAM_SET_WAVEMORPH in synth_app.h.
     */
    case SYNTH_PARAM_SET_WAVEMORPH:
        return (float)WAVE_MORPH_FACTORY / (float)(WAVE_MORPH_COUNT - 1);
    case SYNTH_PARAM_SET_DRIVE_POS:
        return 0.0f;    /* before the effects: the factory position */
    default:
        return 0.0f;
    }
}

extern "C" void synth_app_set_level(float v01)
{
    synth_app_set_param(SYNTH_PARAM_LEVEL, v01);
}

extern "C" void synth_app_set_cutoff(float v01)
{
    synth_app_set_param(SYNTH_PARAM_CUTOFF, v01);
}

extern "C" void synth_app_set_motion(float v01)
{
    synth_app_set_param(SYNTH_PARAM_MOTION_DEPTH, v01);
}

/*
 * THE WRITTEN PATTERN BEHIND A GROOVE, for the picture on the sector.
 *
 * The masks come straight out of the table above: the figure is not a second copy of the
 * grooves, it is the same numbers drawn, so a pattern that changes in the table changes in
 * the picture on the next frame without anybody remembering to update two places.
 *
 * VARIATION AND FILL are deliberately NOT applied. Both of them rewrite the bar while it
 * plays, and a picture that changed under a knob nothing touched would be a lie about what
 * the knob does: this sector says which part is written, and the redrawn bars are a
 * different question that belongs to the playhead, not to the groove's own name.
 */
extern "C" void synth_app_groove_pattern(int index, uint16_t out[4], uint16_t *ghost)
{
    if (!out) {
        return;
    }
    for (int lane = 0; lane < 4; lane++) {
        out[lane] = 0;
    }
    if (ghost) {
        *ghost = 0;
    }
    if (index < 0 || index >= PERC_GROOVE_COUNT) {
        return;
    }

    const perc_groove_t *g = &s_perc_grooves[index];

    for (int lane = 0; lane < PERC_LANE_COUNT && lane < 4; lane++) {
        out[lane] = g->hit[lane];
    }
    if (ghost) {
        *ghost = g->ghost;
    }
}

/*
 * СКОЛЬКО ШАГОВ В БАРЕ ТОЙ ИЛИ ДРУГОЙ ЧАСТИ — для картинки акцента.
 *
 * Не то же самое, что synth_app_param_steps(), и это важно: там COUNT значений ручки, а
 * здесь САМО число шагов. Ударка живёт всегда на шестнадцати (perc_steps()), у свинга —
 * своё, от четырёх до шестнадцати.
 *
 * Зачем понадобилось: картинка акцента считала длину бара как «1 + номер значения ручки»,
 * то есть на заводской настройке получала единицу. На единице все шестнадцать клеток
 * спрашивают одну и ту же позицию, и рисунок вырождался: у фигур с первой долей в маске
 * акцентированы ВСЕ шаги, у 2&4 — ни одного. Владелец это и увидел.
 */
extern "C" int synth_app_bar_steps(synth_param_t steps_param)
{
    if (steps_param == SYNTH_PARAM_PERC_STEPS) {
        return perc_steps();
    }
    /* Бас считает свой круг, а не такт секвенсора: длина приходит из его собственного LEN. */
    if (steps_param == SYNTH_PARAM_BASS_LEN) {
        return synth_bass_steps();
    }

    return seq_steps_for(s_param[SYNTH_PARAM_SEQ_STEPS]);
}

extern "C" int synth_app_param_steps(synth_param_t param)
{
    switch (param) {
    case SYNTH_PARAM_SET_AUTOPLAY:
        /* Три положения списка: ON, OFF, STORE. */
        return 3;
    case SYNTH_PARAM_SET_FASTRAND:
        /* Три положения: выключено, активная ручка, вся страница. */
        return 3;
    case SYNTH_PARAM_DELAY_TYPE:
        /* Шесть алгоритмов: цифровой, пинг-понг, мульти, лента, фильтр, размытие. */
        return 6;
    case SYNTH_PARAM_SCALE:
        return SEQ_SCALE_COUNT;
    case SYNTH_PARAM_ROOT:
        /* Twelve notes, one detent each: a list, so the note never accelerates. */
        return 12;
    case SYNTH_PARAM_ROOT_OCT:
        /* Seven octaves, one detent each, 1..7. See SYNTH_PARAM_ROOT_OCT. */
        return SEQ_OCT_COUNT;
    case SYNTH_PARAM_LFO_SHAPE:
    case SYNTH_PARAM_MOD2_SHAPE:
        /* Seven waveforms and MIC, which is not a waveform: the eighth entry is the
         * microphone's envelope, and choosing it hands the source over to the room.
         * See LFO_SHAPE_COUNT and mod_value(). */
        return LFO_SHAPE_SLOTS;      /* восемь свободных и семь с триггером */
    case SYNTH_PARAM_MOD_DEST:
    case SYNTH_PARAM_MOD_DEST2:
    case SYNTH_PARAM_MOD2_DEST:
    case SYNTH_PARAM_MOD2_DEST2:
        return MOD_DEST_COUNT;
    case SYNTH_PARAM_MOD2_DEPTH:
    case SYNTH_PARAM_MOD2_DEPTH2:
        return 0;       /* непрерывная: это глубина, а не выбор */
    case SYNTH_PARAM_MOD_TRIG:
        /* Four: FREE, NOTE, HOLD and ONES — when the cycle begins, not what it looks like. */
        return 4;
    case SYNTH_PARAM_LEAD_SPREAD:
        return 0;       /* непрерывная: это количество, а не выбор */
    case SYNTH_PARAM_SEQ_ACCENT:
        /* The lead's figure: the same eight, one detent each. */
        return ACCENT_COUNT;
    case SYNTH_PARAM_ARP_ACCENT:
        /* The arp's own figure: the same eight, one detent each. See SYNTH_PARAM_ARP_ACCENT. */
        return ACCENT_COUNT;
    case SYNTH_PARAM_LEAD_VOICE:
        /* Three, one detent each: POLY at 0, MONO at 50, CHORD at 100. */
        return 3;
    case SYNTH_PARAM_GEN_SPAN:
        /* Three, one octave each: ONE at 0, TWO at 50, THREE at 100. */
        return 3;
    case SYNTH_PARAM_LEAD_PW:
        return 0;       /* непрерывная: ширина, а не выбор */
    case SYNTH_PARAM_MOD_DEPTH:
        return 0;
    case SYNTH_PARAM_SEQ_STEPS:
        return SEQ_STEPS_MAX - SEQ_STEPS_MIN + 1;
    case SYNTH_PARAM_SEQ_PULSES:
        /*
         * AS MANY POSITIONS AS THE GRID HAS STEPS, and this is the one list on the instrument
         * whose length follows another parameter: the knob is then exactly as long as the
         * figure is (see seq_pulses_for()), so its last detent is the last pulse and there is
         * no dead travel past the end. The UI re-ranges the wheel when this number changes
         * under a selected PULSES.
         */
        return seq_steps_for(s_param[SYNTH_PARAM_SEQ_STEPS]);
    case SYNTH_PARAM_SEQ_ROTATE:
        /* A phase in steps of its own grid: see SYNTH_PARAM_SEQ_PULSES. */
        return seq_steps_for(s_param[SYNTH_PARAM_SEQ_STEPS]);
    case SYNTH_PARAM_PERC_STEPS:
        return SEQ_STEPS_MAX - SEQ_STEPS_MIN + 1;
    case SYNTH_PARAM_PERC_PULSES:
        /* The drum's own grid, exactly as the lead's: see SYNTH_PARAM_SEQ_PULSES. */
        return perc_steps();
    case SYNTH_PARAM_PERC_ROTATE:
        return perc_steps();
    case SYNTH_PARAM_PERC_BODY:
        /* Continuous, like the balance it is: every position of the arc is a real mix,
         * and a list of steps would quantise a crossfade. */
        return 0;
    case SYNTH_PARAM_PERC_QUANT:
        /* Two: OFF and ON. One detent each, no acceleration — the same rule every list
         * on this instrument follows. */
        return 2;
    case SYNTH_PARAM_PERC_ACCENT:
        /* A LIST, and the one about the rhythm rather than the timbre: eight figures,
         * OFF first. One detent, one figure, which is also why it must not be
         * accelerated — see proxy_load() in synth_ui.c. The count is a property of the
         * parameter and not of the page it is drawn on, so both pages get the same
         * eight-one-detent travel from this one answer. */
        return ACCENT_COUNT;
    /* The two brightnesses are not lists: every one of a hundred positions is a
     * visible difference, and a list of a hundred would defeat the point of
     * "one click, one entry" anyway. */
    case SYNTH_PARAM_DELAY_SYNC:
        /* Мёртвый слот: ручка SYNC ушла, её работу делает слитая TIME. Ноль значит
         * «непрерывная», и в интерфейсе этой ручки больше нет. */
        return 0;
    case SYNTH_PARAM_DELAY_TIME:
        return DELAY_TIME_STEPS;
    case SYNTH_PARAM_DELAY_TIMEMODE:
        return DELAY_TIME_MODE_COUNT;
    case SYNTH_PARAM_FX_TYPE:
        return SYNTH_FXM_COUNT;
    case SYNTH_PARAM_CHORUS_RATE:    return FX_STEPS[fx_type()][0];
    case SYNTH_PARAM_CHORUS_DEPTH:   return FX_STEPS[fx_type()][1];
    case SYNTH_PARAM_FX_C:           return FX_STEPS[fx_type()][2];
    case SYNTH_PARAM_ARP_DIR:
        return ARP_DIR_COUNT;
    case SYNTH_PARAM_ARP_SPEED:
        return ARP_SPEED_COUNT;
    case SYNTH_PARAM_ARP_LEN:
        return ARP_LEN_MAX - ARP_LEN_MIN + 1;
    case SYNTH_PARAM_ARP_RANGE:
        return ARP_RANGE_COUNT;
    case SYNTH_PARAM_VERB_MODE:
        return SYNTH_REVERB_MODE_COUNT;
    case SYNTH_PARAM_PERC_KIT:
        /* The kits, one detent each: a kit is a choice and not a dial, and the difference
         * between two of them is a different drum section. */
        return PERC_KIT_COUNT;
    case SYNTH_PARAM_PERC_GROOVE:
        /* Sixteen written parts, one detent each, for the same reason. */
        return PERC_GROOVE_COUNT;
    case SYNTH_PARAM_PERC_SPEED:
        /* Four ratios and nothing between them: the drum's clock only moves in twos, or it
         * would drift against the bar. */
        return PERC_SPEED_COUNT;
    case SYNTH_PARAM_BASS_KIT:
        /* Thirty kits, one detent each, for the drum's reason: a kit is a choice and not a
         * dial. The travel is the list, and the list is three families of ten. */
        return BASS_KIT_COUNT;
    case SYNTH_PARAM_BASS_PAT:
        /* Thirty written bars, one detent each: a figure is a place in the list and not a
         * position on an arc, and two neighbouring figures are two rhythms. */
        return BASS_PAT_COUNT;
    case SYNTH_PARAM_BASS_ACCENT:
        /* Восемь фигур акцента, те же, что на ударных, в секвенсоре и в арпеджиаторе. */
        return ACCENT_COUNT;
    case SYNTH_PARAM_BASS_VAR:
        /* Six characters, one detent each: JUMP, STEADY, WALK, ROLL, DRIVE, DROP are six
         * different behaviours of the bar, not six amounts of one. */
        return 6;
    case SYNTH_PARAM_BASS_TONE:
        /*
         * СЛОТ 2 — СМЕНА НОТЫ, ПЯТНАДЦАТЬ ПОЛОЖЕНИЙ: -7..+7 полутонов.
         *
         * Здесь стоял TONE, и срез фильтра был и полем заготовки, и ручкой сразу: владелец
         * попросил оставить фильтр только в китах. Место заняла смена ноты: сдвиг идёт до
         * прижатия к складу, поэтому линия и сдвигается, и остаётся в тональности.
         */
        return 15;
    case SYNTH_PARAM_PERC_TONE:
    case SYNTH_PARAM_PERC_LENGTH:
    case SYNTH_PARAM_PERC_BODY_TRIM:
    case SYNTH_PARAM_PERC_TIMBRE:
    case SYNTH_PARAM_PERC_TUNE:
    case SYNTH_PARAM_PERC_VARIATION:
    case SYNTH_PARAM_PERC_FILL:
    case SYNTH_PARAM_PERC_SWING:
        /* Continuous: every position of the arc is a real drum, and a list here would
         * quantise a transposition into steps nobody asked for. */
        return 0;
    case SYNTH_PARAM_SET_RINGMODE:
        return 5;           /* PARAM, STEREO, OFF, REACTIVE, ALWAYS */
    case SYNTH_PARAM_SEQ_RESET:
    case SYNTH_PARAM_PERC_RESET:
        /* Six positions, INF first, and every one of them a whole number of steps: the knob
         * is a list, so one detent is one position and nothing is accelerated. Both RESET
         * parameters read the same list — the positions are what a step count is made of —
         * and each is a patch parameter, so the list is also what a preset stores as one
         * byte. Which grid the number counts is the parameter's, not the list's. */
        return APP_SEQ_RESET_COUNT;
    case SYNTH_PARAM_DRONE_WAVE:
    case SYNTH_PARAM_LEAD_WAVE:
    case SYNTH_PARAM_DRONE_OSC_LOW:
    case SYNTH_PARAM_DRONE_OSC_MID:
    case SYNTH_PARAM_DRONE_OSC_HIGH:
        /*
         * У ДРОНА ШЕСТЬ ФОРМ, У ЛИДА СЕМЬ.
         *
         * SKEW — скошенная пила, её излом задаётся шириной импульса, а у дрона такой ручки
         * нет: форма попала в список потому, что он общий, и управлять ею в дроне нечем.
         */
        return PW_COUNT - 1;
    case SYNTH_PARAM_DRONE_FOLLOW:
        /* Three modes, one detent each: SCALE, FULL, CONS. Like every other list it is not
         * accelerated — crossing it is two clicks. */
        return DRONE_FOLLOW_COUNT;
    case SYNTH_PARAM_SET_PATCH:
        return 3;
    case SYNTH_PARAM_SET_SLIDE:
        return SLIDE_COUNT;
    case SYNTH_PARAM_SET_RNDDELAY:
        return 2;           /* off, on */
    case SYNTH_PARAM_SET_WEAKVEL:
        /* A LIST of a hundred and twenty-eight whole velocities, and the longest list on
         * the instrument by an order of magnitude: 0..127 is the engine's own velocity
         * range and every unit of it is a real difference in how hard the hit is struck,
         * so one arc step per unit — one detent, one velocity — is the resolution the
         * control wants. What that costs is stated rather than hidden: proxy_load() in
         * synth_ui.c gives a list no acceleration, so crossing the whole range is 127
         * detents and the number moves by exactly one on every one of them. The same
         * arithmetic is already in this project for the preset list's 128 rows — see the
         * note over preset_refresh() — where a thousand-step arc was rejected for the
         * very reason it is rejected here. The continuous alternative was measured too: a
         * thousand-step arc makes one detent a seventh of a unit at a steady turning
         * speed, eight clicks before the number moves at all, and it would need a second
         * percentage-style mapping beside the two brightnesses. See
         * SYNTH_PARAM_SET_WEAKVEL in synth_app.h. */
        return WEAK_VEL_STEPS;
    /*
     * Two positions, OFF and ON, the same shape the random-delay switch above has: a list of
     * two is never accelerated (proxy_load() in synth_ui.c gives a list no acceleration) and
     * the value is exact on both of them, which is what a switch has to be. It is
     * deliberately NOT a percentage: there is no third state, and an arc that could sit
     * halfway between off and on would be showing something the port cannot do.
     */
    case SYNTH_PARAM_SET_MIDIIN:
        return 2;
    /*
     * Eleven positions, one per duration in WAVE_MORPH_MS, and a list rather than a continuous
     * control on purpose: the durations are not evenly spaced, so a percentage would put the
     * useful millisecond values within a few detents of each other and the rest of the arc
     * would be one number. One detent, one duration, and the readout is the duration itself.
     * As a list it is also never accelerated (proxy_load() in synth_ui.c), which for eleven
     * entries costs nothing: the whole range is ten clicks.
     */
    case SYNTH_PARAM_SET_WAVEMORPH:
        return WAVE_MORPH_COUNT;
    /* Two positions, one detent each: BEFORE FX and AFTER FX. */
    case SYNTH_PARAM_SET_DRIVE_POS:
        return 2;
    default:
        /* Continuous. The arc keeps its full resolution, because for a filter
         * cutoff every one of those steps is a real change in the sound. */
        return 0;
    }
}

/*
 * The tempo's line of text, in one place because it is one line: the transport asks for it
 * by way of synth_app_tempo_text() below and the parameter's own readout asks for it here,
 * and the two must not be able to word the same number differently.
 */
static void seq_tempo_text(float v01, char *buf, size_t len)
{
    snprintf(buf, len, "%d BPM", (int)(seq_tempo_bpm(v01) + 0.5f));
}

extern "C" void synth_app_param_text(synth_param_t param, char *buf, size_t len)
{
    if (!buf || len == 0) {
        return;
    }
    if (!param_valid(param)) {
        buf[0] = '\0';
        return;
    }

    const float v = s_param[param];
    const drone_register_cfg_t *low = &s_drones[0];

    switch (param) {
    case SYNTH_PARAM_LEVEL:
        snprintf(buf, len, "%d%%", (int)(v * 100.0f + 0.5f));
        break;
    case SYNTH_PARAM_MASTER_COMP:
        /*
         * The ratio, because that is the half of the pair a listener can name, and OFF
         * rather than 1.0:1 because a ratio of one is not a compressor, it is the stage
         * being skipped — which is what the bottom of the travel actually does.
         */
        if (v <= 0.0f) {
            snprintf(buf, len, "OFF");
        } else {
            snprintf(buf, len, "%.1f:1", (double)synth_rack_comp_ratio(v));
        }
        break;
    case SYNTH_PARAM_MASTER_DUCK:
        if (v <= 0.0f) {
            snprintf(buf, len, "OFF");
        } else {
            snprintf(buf, len, "%d%%", (int)(v * 100.0f + 0.5f));
        }
        break;
    case SYNTH_PARAM_MASTER_DUCK_SRC:
        /* Что слышит дакинг. Слово, а не проценты: это выбор полосы, а не количество. */
        snprintf(buf, len, "%s", (v < 0.25f) ? "LP" : ((v > 0.75f) ? "HP" : "BP"));
        break;
    case SYNTH_PARAM_MASTER_DUCK_REL:
        snprintf(buf, len, "%d ms", (int)(60.0f + 340.0f * v + 0.5f));
        break;
    case SYNTH_PARAM_LEAD_PW:
        /* Скважность в процентах: 50 % это меандр, 4 % — узкий импульс. */
        snprintf(buf, len, "%d%%", (int)((float)lead_pw_value() * 100.0f / 255.0f + 0.5f));
        break;
    case SYNTH_PARAM_LEAD_SPREAD:
        /* Ширина в процентах: сколько разностного сигнала подмешано в стороны. */
        snprintf(buf, len, "%d%%", (int)(v * 100.0f + 0.5f));
        break;
    case SYNTH_PARAM_CUTOFF:
        snprintf(buf, len, "%d Hz", (int)cutoff_for(low, v));
        break;
    case SYNTH_PARAM_RESONANCE:
        snprintf(buf, len, "Q %.2f", (double)((float)resonance_for(low, v) * 0.01f));
        break;
    case SYNTH_PARAM_FILTER_RATE:
        /* Three decimals, because the bottom of the range is 0.050 Hz and the
         * point of showing it is that the number is small. */
        snprintf(buf, len, "%.3f Hz", (double)((float)filter_rate_for(low, v) * 0.001f));
        break;
    case SYNTH_PARAM_FILTER_DEPTH:
        /* The EFFECTIVE depth, WIDTH's share included, and not the knob's own value: the engine is
         * using the sum, so showing DEPTH alone under-reported the sweep — 4.00 oct on LOW while
         * 6.00 was going out at the old WIDTH share. filter_depth_for() on LOW is 100 centioct x
         * 4.0 = 400 per unit of the sum, so the sum printed as centioctaves over 100 is the 4.00
         * octaves DEPTH alone can reach and the 6.00 the two knobs together reach. */
        snprintf(buf, len, "%.2f oct",
                 (double)((float)filter_depth_for(low, filter_depth_sum(v)) * 0.01f));
        break;
    case SYNTH_PARAM_MOTION_DEPTH:
        /*
         * ШИРИНА В ПРОЦЕНТАХ. Ручка разводит три регистра по стерео: 0 — все в центре,
         * 100 — LOW влево, HIGH вправо, почти по краям. Раньше здесь печатался «ход»,
         * потому что ручка одновременно двигала семь чисел; теперь у неё одно дело, и
         * показывать надо его.
         */
        snprintf(buf, len, "%d%%", (int)(v * 100.0f + 0.5f));
        break;
    case SYNTH_PARAM_MOTION_RATE:
    case SYNTH_PARAM_MOD2_RATE: {
        /*
         * ЧАСТОТА, А РЯДОМ — ПОДСКАЗКА О ДОЛЯХ.
         *
         * Скорость LFO в герцах сама по себе ничего не говорит о ритме: 0.5 Гц при 120 bpm —
         * это два такта, а при 90 — полтора. Поэтому когда период попадает на целое число
         * долей (в пределах двух процентов), подпись называет долю: «1 BEAT», «2 BEAT»,
         * «1 BAR». Иначе — герцы, как было.
         */
        const float rate = (float)motion_rate_for(low->pan_rate1_mhz, v) * 0.001f;
        const float bpm = seq_tempo_bpm(synth_app_tempo_now(NULL));
        const float beats = (rate > 0.0f) ? ((60.0f / bpm) * rate) : 0.0f;

        if (beats > 0.0f) {
            const float period = 1.0f / beats;      /* период в долях */
            const int whole = (int)(period + 0.5f);

            if (whole >= 1 && whole <= 16 && fabsf(period - (float)whole) <= 0.02f * (float)whole) {
                if (whole % 4 == 0) {
                    snprintf(buf, len, "%d BAR", whole / 4);
                } else {
                    snprintf(buf, len, "%d BEAT", whole);
                }
                break;
            }
        }

        snprintf(buf, len, "%.3f Hz", (double)rate);
        break;
    }
    case SYNTH_PARAM_LEAD_LEVEL:
        /* The layer level itself, not the knob's travel: it is the number that
         * says how loud the lead actually is. */
        snprintf(buf, len, "%d%%", (int)(v * LEAD_LEVEL_MAX * 100.0f + 0.5f));
        break;
    case SYNTH_PARAM_SEQ_TEMPO:
        seq_tempo_text(v, buf, len);
        break;
    case SYNTH_PARAM_SEQ_GATE:
        snprintf(buf, len, "%d%%", (int)(v * 100.0f + 0.5f));
        break;
    case SYNTH_PARAM_SCALE:
        snprintf(buf, len, "%s", SEQ_SCALES[seq_scale_index()].name);
        break;
    case SYNTH_PARAM_ROOT: {
        static const char *const names[12] = {
            "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"
        };
        /* The NOTE alone: the octave is the sector beside it, and a readout that repeated it
         * would be the old single knob made of two halves. */
        const int note = (int)(clamp01f(v) * 11.0f + 0.5f);
        snprintf(buf, len, "%s", names[(note < 0) ? 0 : ((note > 11) ? 11 : note)]);
        break;
    }
    case SYNTH_PARAM_ROOT_OCT: {
        /* The octave's NUMBER, 1..7 — the same digit an old readout printed after the note. */
        const int oct = (int)(clamp01f(v) * (float)(SEQ_OCT_COUNT - 1) + 0.5f);
        snprintf(buf, len, "%d", (oct < 0) ? 1 : ((oct > SEQ_OCT_COUNT - 1) ? SEQ_OCT_COUNT
                                                                          : oct + 1));
        break;
    }
    case SYNTH_PARAM_DENSITY:
        snprintf(buf, len, "%d%%", (int)(v * 100.0f + 0.5f));
        break;
    case SYNTH_PARAM_OCTAVE:
        /* What the setting actually buys: the chance of taking the far
         * register, which is half the knob because the coin is tossed at twice
         * the travel. Showing the knob position instead would be showing a
         * number that means nothing on its own. */
        snprintf(buf, len, "%d%%", (int)(v * 50.0f + 0.5f));
        break;
    case SYNTH_PARAM_SEQ_STEPS:
        snprintf(buf, len, "%d", seq_steps_for(v));
        break;
    case SYNTH_PARAM_SEQ_PULSES:
        /* The EFFECTIVE count, as k over n. A pulse count above n does nothing,
         * and showing the request rather than the result would be a number that
         * lies about what is playing. */
        snprintf(buf, len, "%d/%d", seq_pulses(),
                 seq_steps_for(s_param[SYNTH_PARAM_SEQ_STEPS]));
        break;
    case SYNTH_PARAM_SEQ_ROTATE:
        snprintf(buf, len, "%d", seq_rotate());
        break;
    case SYNTH_PARAM_SEQ_SCATTER:
        /* How far a note may wander from its grid line, as a percentage of one
         * step — so the number means the same thing at any tempo. */
        snprintf(buf, len, "%d%%", (int)(v * 50.0f + 0.5f));
        break;
    case SYNTH_PARAM_MOD_DEPTH:
    /* Проценты у ВСЕХ четырёх глубин: обе у первого LFO и обе у второго. */
    case SYNTH_PARAM_MOD_DEPTH2:
    case SYNTH_PARAM_MOD2_DEPTH:
    case SYNTH_PARAM_MOD2_DEPTH2:
        snprintf(buf, len, "%+d%%", (int)((v * 2.0f - 1.0f) * 100.0f + 0.5f));
        break;
    case SYNTH_PARAM_MOD_TRIG: {
        static const char *const trigs[4] = { "FREE", "NOTE", "HOLD", "ONES" };
        int t = (int)(v * 3.0f + 0.5f);
        if (t < 0) {
            t = 0;
        } else if (t > 3) {
            t = 3;
        }
        snprintf(buf, len, "%s", trigs[t]);
        break;
    }
    case SYNTH_PARAM_MOD_DEST:
    case SYNTH_PARAM_MOD_DEST2:
    case SYNTH_PARAM_MOD2_DEST:
    case SYNTH_PARAM_MOD2_DEST2: {
        /* The name comes from MOD_DESTS, the same row the routing reads: one table, so
         * what the sector says and what the engine does cannot part company. */
        const int d = (v < 0.0f) ? 0
                    : (v > 1.0f) ? MOD_DEST_COUNT - 1
                                 : (int)(v * (float)(MOD_DEST_COUNT - 1) + 0.5f);
        snprintf(buf, len, "%s", MOD_DESTS[d].name);
        break;
    }
    case SYNTH_PARAM_LFO_SHAPE:
    case SYNTH_PARAM_MOD2_SHAPE: {
        /* MIC last, and out of the waveform names on purpose: it is the one entry that
         * is a source rather than a shape. See LFO_SHAPE_COUNT. */
        static const char *const shapes[LFO_SHAPE_COUNT] = {
            "SINE", "TRI", "SQUARE", "SAW", "RANDOM", "EXP+", "EXP-", "MIC"
        };
        /*
         * СЛОТОВ ПЯТНАДЦАТЬ: ВОСЕМЬ СВОБОДНЫХ И СЕМЬ С ТРИГГЕРОМ. Слот читается из
         * параметра ЭТОГО канала, поэтому F. и T. подписаны, а рисунок формы остаётся
         * общим — см. synth_ui_preview.c.
         */
        const int ch = (param == SYNTH_PARAM_MOD2_SHAPE) ? 1 : 0;
        const int slot = lfo_shape_slot(ch);
        const int s = (slot < LFO_SHAPE_COUNT) ? slot : (slot - LFO_SHAPE_COUNT);

        if (slot < LFO_SHAPE_COUNT) {
            snprintf(buf, len, "F.%s", shapes[s]);
        } else {
            snprintf(buf, len, "T.%s", shapes[s]);
        }
        break;
    }
    case SYNTH_PARAM_DRONE_LOW:
    case SYNTH_PARAM_DRONE_MID:
    case SYNTH_PARAM_DRONE_HIGH:
        /* The gain the fader ends up at, not the travel: under level_gain() the two
         * differ by a square, and the number worth reading is the one that says how loud
         * the register is. */
        snprintf(buf, len, "%d%%", (int)(drone_level_gain(v) * 100.0f + 0.5f));
        break;
    case SYNTH_PARAM_PERC_MIX_KICK:
    case SYNTH_PARAM_PERC_MIX_SNARE:
    case SYNTH_PARAM_PERC_MIX_HAT:
    case SYNTH_PARAM_PERC_MIX_TOM:
        /* The lane's gain, for the same reason the registers print theirs. */
        snprintf(buf, len, "%d%%", (int)(level_gain(v) * 100.0f + 0.5f));
        break;
    case SYNTH_PARAM_DRONE_DRIFT:
        /* Центы, как они есть: ручка спрашивает «насколько далеко», и ответ — число.
         * Ноль печатается нулём, а не «OFF»: это величина, а не выбор. */
        snprintf(buf, len, "%d CT", (int)(clamp01f(v) * DRONE_DRIFT_MAX_CT + 0.5f));
        break;
    case SYNTH_PARAM_GEN_SPAN: {
        /* The octaves themselves, not the knob's travel: "2 OCT" is the answer to the
         * question the page asks, and the detent is only how it is reached. */
        int oct = (int)(clamp01f(v) * 2.0f + 0.5f) + 1;
        if (oct < 1) {
            oct = 1;
        } else if (oct > 3) {
            oct = 3;
        }
        snprintf(buf, len, "%d OCT", oct);
        break;
    }
    case SYNTH_PARAM_LEAD_CUTOFF: {
        /* Tenths of a kHz above 1 kHz: four digits of hertz is precision nobody
         * reads off a round screen at arm's length. */
        const float hz = lead_fc_for(v);
        if (hz >= 1000.0f) {
            const int h10 = (int)(hz / 100.0f + 0.5f);
            snprintf(buf, len, "%d.%d k", h10 / 10, h10 % 10);
        } else {
            snprintf(buf, len, "%d Hz", (int)(hz + 0.5f));
        }
        break;
    }
    case SYNTH_PARAM_LEAD_RESO: {
        /* Built from tenths rather than printed as a float, so 1.95 comes out as
         * 2.0 and never as 1.10. */
        const int q10 = (int)(lead_q_for(v) * 10.0f + 0.5f);
        snprintf(buf, len, "%d.%d", q10 / 10, q10 % 10);
        break;
    }
    case SYNTH_PARAM_LEAD_ENV: {
        /* The percentage the knob is, and the octaves it turns out to be at this
         * corner: the first is what the hand set, the second is what the filter does
         * with it, and they differ as CUTOFF moves — which is the point of the change. */
        const int pct = (int)((v * 2.0f - 1.0f) * 100.0f + (v >= 0.5f ? 0.5f : -0.5f));
        snprintf(buf, len, "%+d%%", pct);
        break;
    }
    case SYNTH_PARAM_LEAD_FENV_SHAPE: {
        const int pct = (int)((v * 2.0f - 1.0f) * 100.0f + (v >= 0.5f ? 0.5f : -0.5f));
        snprintf(buf, len, "%+d%%", pct);
        break;
    }
    case SYNTH_PARAM_LEAD_VOICE: {
        /* The word, not a percentage: a choice has nothing to measure. */
        static const char *const names[] = { "POLY", "MONO", "CHORD" };
        int i = (int)(clamp01f(v) * 2.0f + 0.5f);
        if (i < 0) {
            i = 0;
        } else if (i > 2) {
            i = 2;
        }
        snprintf(buf, len, "%s", names[i]);
        break;
    }
    case SYNTH_PARAM_LEAD_ATTACK:
    case SYNTH_PARAM_LEAD_DECAY:
    case SYNTH_PARAM_LEAD_RELEASE: {
        const float ms = lead_time_for(v);
        if (ms >= 1000.0f) {
            const int t10 = (int)(ms / 100.0f + 0.5f);
            snprintf(buf, len, "%d.%d s", t10 / 10, t10 % 10);
        } else {
            snprintf(buf, len, "%d ms", (int)(ms + 0.5f));
        }
        break;
    }
    case SYNTH_PARAM_LEAD_PORTA: {
        const uint32_t ms = lead_porta_ms();
        if (ms == 0) {
            snprintf(buf, len, "OFF");
        } else {
            snprintf(buf, len, "%u MS", (unsigned)ms);
        }
        break;
    }
    case SYNTH_PARAM_ARP_DIR: {
        static const char *const dirs[ARP_DIR_COUNT] = {
            "OFF", "UP", "DN", "UP-DN", "DN-UP", "UP-DN+", "DN-UP+", "RAND"
        };
        snprintf(buf, len, "%s", dirs[arp_dir()]);
        break;
    }
    case SYNTH_PARAM_ARP_SPEED: {
        /* The same words the delay's sync uses, because they are the same divisions of
         * the same bar. The arp is switched from its DIR, so there is no OFF here. The
         * dot is the dotted note, which the font has; the
         * longest of these is five characters, which still fits the sector's panel. */
        static const char *const speeds[ARP_SPEED_COUNT] = {
            [ARP_DIV_4_1]      = "4/1",
            [ARP_DIV_2_1]      = "2/1",
            [ARP_DIV_1_1]      = "1/1",
            [ARP_DIV_1_2_DOT]  = "1/2.",
            [ARP_DIV_1_2]      = "1/2",
            [ARP_DIV_1_4_DOT]  = "1/4.",
            [ARP_DIV_1_4]      = "1/4",
            [ARP_DIV_1_8_DOT]  = "1/8.",
            [ARP_DIV_1_8]      = "1/8",
            [ARP_DIV_1_16_DOT] = "1/16.",
            [ARP_DIV_1_8_T]    = "1/8T",
            [ARP_DIV_1_16]     = "1/16",
            [ARP_DIV_1_32]     = "1/32",
        };
        snprintf(buf, len, "%s", speeds[arp_speed_index()]);
        break;
    }
    case SYNTH_PARAM_ARP_LEN:
        /* How many notes the figure has, which is also how many places there are
         * in it: the two are the same number read two ways. */
        snprintf(buf, len, "%d", arp_len());
        break;
    case SYNTH_PARAM_ARP_RANGE:
        /* The octaves, as a number and nothing else: the range has no sign to show, and where
         * the figure goes is the sector next door. "0" is a readout a player has to be able to
         * reach, so the bare number is the honest one — LEN prints itself the same way. */
        snprintf(buf, len, "%d", arp_range_index());
        break;
    case SYNTH_PARAM_LEAD_SUSTAIN:
        snprintf(buf, len, "%d%%", (int)(v * 100.0f + 0.5f));
        break;
    case SYNTH_PARAM_DELAY_SYNC: {
        /* The same words the arp's speed uses: they are the same divisions of the same
         * bar. FREE is first and is not a division. */
        static const char *const divs[DELAY_DIV_COUNT] = {
            [DELAY_DIV_FREE]     = "FREE",
            [DELAY_DIV_1_1]      = "1/1",
            [DELAY_DIV_1_2_DOT]  = "1/2.",
            [DELAY_DIV_1_2]      = "1/2",
            [DELAY_DIV_1_4_DOT]  = "1/4.",
            [DELAY_DIV_1_4]      = "1/4",
            [DELAY_DIV_1_8_DOT]  = "1/8.",
            [DELAY_DIV_1_8]      = "1/8",
            [DELAY_DIV_1_16_DOT] = "1/16.",
            [DELAY_DIV_1_8_T]    = "1/8T",
            [DELAY_DIV_1_16]     = "1/16",
            [DELAY_DIV_1_32]     = "1/32",
        };
        const int i = (int)(v * (float)(DELAY_DIV_COUNT - 1) + 0.5f);
        snprintf(buf, len, "%s",
                 divs[i < 0 ? 0 : (i > DELAY_DIV_COUNT - 1 ? DELAY_DIV_COUNT - 1 : i)]);
        break;
    }
    case SYNTH_PARAM_DELAY_TIME: {
        /*
         * СНАЧАЛА ДОЛИ, ПОТОМ МИЛЛИСЕКУНДЫ — и подпись говорит, где ручка стоит.
         *
         * Одна ручка времени держит и синхронные доли, и свободные миллисекунды, поэтому
         * показывать всегда миллисекунды значило бы прятать от игрока, что эхо сейчас
         * привязано к темпу.
         */
        if (delay_division() > 0) {
            static const char *const divs[] = {
                "1:1", "1:2.", "1:2", "1:4.", "1:4", "1:8.", "1:8", "1:16.", "1:8T", "1:16", "1:32",
            };
            const int idx = delay_time_index();

            snprintf(buf, len, "%s",
                     divs[(idx < 0) ? 0 : ((idx > 10) ? 10 : idx)]);
            break;
        }

        /* The time actually in force, synced or not. When the delay is following
         * the tempo this knob is a readout, and showing the free value instead
         * would be showing a number nobody is hearing.
         *
         * Clamped to the line the effect actually has, because the tempo can ask for
         * more than it holds: the slowest division is a whole note now, and below
         * 60 bpm that is longer than DELAY_LINE_MAX_MS. The effect clamps to its own
         * buffer and drops the rest, so an unclamped readout would name an echo that is
         * not in the room — eight seconds at 30 bpm against a four-second line. */
        float ms = delay_ms_now();
        if (ms > DELAY_LINE_MAX_MS) {
            ms = DELAY_LINE_MAX_MS;
        }
        snprintf(buf, len, "%d ms", (int)(ms + 0.5f));
        break;
    }
    case SYNTH_PARAM_FX_TYPE: {
        snprintf(buf, len, "%s", synth_app_fx_name());
        break;
    }
    case SYNTH_PARAM_CHORUS_RATE:
    case SYNTH_PARAM_CHORUS_DEPTH:
    case SYNTH_PARAM_FX_C: {
        /* Подпись сектора говорит, ЧТО это, а число — сколько. Единицы разные: частота в
         * герцах у качаний, разрядность в битах у биткраша, проценты у остальных. */
        const fx_desc_t *d = &FX_DESC[fx_type()];
        const int slot = (param == SYNTH_PARAM_CHORUS_RATE) ? 0
                        : ((param == SYNTH_PARAM_CHORUS_DEPTH) ? 1 : 2);

        if (slot >= d->used) {
            snprintf(buf, len, "--");
            break;
        }

        const int type = fx_type();

        /* Гребёнка показывает, попала ли в ноту: имя ноты или герцы. */
        if (type == SYNTH_FXM_COMB && slot == 0) {
            synth_fx_comb_text(v, buf, len);
            break;
        }

        /* STUTTER: длина куска долями, число повторов, затухание процентами. */
        if (type == SYNTH_FXM_STUTTER) {
            if (slot == 0) {
                static const char *const LEN[4] = { "1:32", "1:16", "1:8", "1:4" };
                const int k = (int)(v * 3.0f + 0.5f);

                snprintf(buf, len, "%s", LEN[(k < 0) ? 0 : ((k > 3) ? 3 : k)]);
                break;
            }
            if (slot == 1) {
                snprintf(buf, len, "%d%%", (int)(v * 100.0f + 0.5f));
                break;
            }
            if (slot == 2) {
                snprintf(buf, len, "x%d", 2 + (int)(v * 6.0f + 0.5f));
                break;
            }
        }

        const bool rate = (slot == 0) && (type == SYNTH_FXM_CHORUS || type == SYNTH_FXM_TREMOLO
                                         || type == SYNTH_FXM_AUTOPAN
                                         || type == SYNTH_FXM_VIBRATO
                                         || type == SYNTH_FXM_PHASER
                                         || type == SYNTH_FXM_FLANGER
                                         || type == SYNTH_FXM_RING);
        const bool bits = (type == SYNTH_FXM_BITCRUSH) && (slot == 0);

        if (rate) {
            snprintf(buf, len, "%d Hz", (int)(0.05f + v * 19.95f + 0.5f));
        } else if (bits) {
            snprintf(buf, len, "%d bit", 1 + (int)((1.0f - v) * 15.0f + 0.5f));
        } else {
            snprintf(buf, len, "%d%%", (int)(v * 100.0f + 0.5f));
        }
        break;
    }
    case SYNTH_PARAM_VERB_MODE: {
        /* As short as a mode's own name can be: the font is the one the chips use and
         * CATHEDRAL does not fit anywhere on this screen. Each word says what the tail
         * DOES, and PLAT is the one mode here that is a different topology rather than a
         * different tuning. There were five of these and there are four: HOLD is gone because
         * the sound broke on the way out of HOLD into CATHEDRAL when the delay lines were
         * re-cut — see the note over MODE[] in synth_fx_reverb.cpp — and the value a saved HOLD
         * left in the flash is migrated to HALL, not read as CATH. */
        static const char *const modes[SYNTH_REVERB_MODE_COUNT] = {
            "ROOM", "HALL", "CATH", "PLAT"
        };
        snprintf(buf, len, "%s", modes[verb_mode()]);
        break;
    }
    case SYNTH_PARAM_DELAY_TIMEMODE: {
        /* Two words, and as short as the two ideas can be made: the sector prints this
         * inside an arc a fifth of the rim wide, beside the value that names it. TAPE is
         * the pointer braking, XFADE is the crossfade. */
        snprintf(buf, len, "%s", delay_crossfade() ? "XFADE" : "TAPE");
        break;
    }
    case SYNTH_PARAM_DELAY_DAMP:
        /* Частота фильтра в цепи обратной связи: видно, насколько темнеет повтор. */
        snprintf(buf, len, "%d Hz",
                 (int)(18000.0f * expf(-logf(18000.0f / 700.0f) * v) + 0.5f));
        break;
    case SYNTH_PARAM_DELAY_FEEDBACK:
    case SYNTH_PARAM_DELAY_MIX:
    case SYNTH_PARAM_CHORUS_MIX:
    case SYNTH_PARAM_VERB_SIZE:
    case SYNTH_PARAM_VERB_DAMP:
    case SYNTH_PARAM_VERB_MIX:
    case SYNTH_PARAM_SEND_LOW:
    case SYNTH_PARAM_SEND_MID:
    case SYNTH_PARAM_SEND_HIGH:
    case SYNTH_PARAM_SEND_LEAD:
    case SYNTH_PARAM_SEND_PERC:
    case SYNTH_PARAM_SEND_MIC:
    case SYNTH_PARAM_CHR_SEND_LOW:
    case SYNTH_PARAM_CHR_SEND_MID:
    case SYNTH_PARAM_CHR_SEND_HIGH:
    case SYNTH_PARAM_CHR_SEND_LEAD:
    case SYNTH_PARAM_CHR_SEND_PERC:
    case SYNTH_PARAM_CHR_SEND_MIC:
    case SYNTH_PARAM_DLY_SEND_LOW:
    case SYNTH_PARAM_DLY_SEND_MID:
    case SYNTH_PARAM_DLY_SEND_HIGH:
    case SYNTH_PARAM_DLY_SEND_LEAD:
    case SYNTH_PARAM_DLY_SEND_PERC:
    case SYNTH_PARAM_DLY_SEND_MIC:
    case SYNTH_PARAM_PERC_RESO:
        snprintf(buf, len, "%d%%", (int)(v * 100.0f + 0.5f));
        break;
    case SYNTH_PARAM_PERC_LEVEL:
        snprintf(buf, len, "%d%%", (int)(level_gain(v) * 100.0f + 0.5f));
        break;
    case SYNTH_PARAM_PERC_QUANT:
        snprintf(buf, len, "%s", (v > 0.5f) ? "ON" : "OFF");
        break;
    case SYNTH_PARAM_PERC_PITCH: {
        /*
         * WITH THE SNAP ON THE READOUT IS THE NOTE, and nothing else.
         *
         * Hertz would be a number nobody can act on once the pitch is on the scale: the
         * answer to "which note" is a name, and the tuned kick is picked by name. The two
         * readouts are exclusive on purpose — showing "D1 36.7 HZ" would fill a round
         * screen's sector with a number that the snap has already decided.
         *
         * The note is derived rather than stored: the value in s_param[] is already the
         * snapped one, so rounding it back to MIDI returns exactly the note that was
         * chosen, and the label cannot disagree with the voice.
         */
        if (s_param[SYNTH_PARAM_PERC_QUANT] > 0.5f) {
            static const char *const names[12] = {
                "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"
            };
            const float hz = synth_perc_pitch_hz(v);
            const int note = (int)lroundf(69.0f + 12.0f * log2f(hz / 440.0f));
            snprintf(buf, len, "%s%d", names[(note % 12 + 12) % 12], note / 12 - 1);
            break;
        }

        /* Tenths of a kHz above 1 kHz, the same rule the lead's cutoff follows: four
         * digits of hertz is precision nobody reads off a round screen. */
        const float hz = synth_perc_pitch_hz(v);
        if (hz >= 1000.0f) {
            const int h10 = (int)(hz / 100.0f + 0.5f);
            snprintf(buf, len, "%d.%d k", h10 / 10, h10 % 10);
        } else {
            snprintf(buf, len, "%d Hz", (int)(hz + 0.5f));
        }
        break;
    }
    case SYNTH_PARAM_PERC_KIT:
        /* The kit's name, not its number: sixteen positions of a list are a place in a
         * list, and the list is what a player chooses from. Same for the groove below. */
        snprintf(buf, len, "%s", s_perc_kit_names[perc_kit_index()]);
        break;
    case SYNTH_PARAM_PERC_GROOVE:
        snprintf(buf, len, "%s", s_perc_groove_names[perc_groove_index()]);
        break;
    case SYNTH_PARAM_PERC_SPEED:
        /*
         * The ratio the drum's clock runs at, written the way a musician writes it: the
         * two faster positions as the multiple they are, the two slower as the fraction of
         * the bar's step they take. "X2" and not "x2" because the display has no lower case
         * in this font; "1/2" and not "HALF" because the pair to compare it with is ×2, and
         * a word would hide which way the knob goes.
         */
        switch (perc_speed_index()) {
        case 0:  snprintf(buf, len, "1/4"); break;
        case 1:  snprintf(buf, len, "1/2"); break;
        case 2:  snprintf(buf, len, "3/4"); break;
        case 3:  snprintf(buf, len, "X1");  break;
        case 4:  snprintf(buf, len, "1.5"); break;
        case 5:  snprintf(buf, len, "X2");  break;
        default: snprintf(buf, len, "X3");  break;
        }
        break;
    case SYNTH_PARAM_PERC_DECAY: {
        const float ms = synth_perc_decay_ms(v);
        if (ms >= 1000.0f) {
            const int t10 = (int)(ms / 100.0f + 0.5f);
            snprintf(buf, len, "%d.%d s", t10 / 10, t10 % 10);
        } else {
            snprintf(buf, len, "%d ms", (int)(ms + 0.5f));
        }
        break;
    }
    case SYNTH_PARAM_PERC_ENV:
        /* Octaves, like the lead's filter envelope, because that is what the knob
         * does: it drops the centre by a musical interval rather than by a number of
         * hertz that would mean something different at every pitch.
         *
         * NO SIGN, deliberately, and this is the only readout on the instrument where
         * a character is worth a comment: the range is 0..5 octaves upwards and never
         * negative, so a sign would say nothing, and unsigned is what keeps the widest
         * string ENV can print at seven characters — "5.0 OCT". ENV now lives only on
         * PERC, which draws no ring of dots, so the old collision with the ring on
         * PERC SEQ is gone by construction rather than by shortening the word; the
         * figure page no longer carries this value at all. */
        snprintf(buf, len, "%.1f OCT", (double)synth_perc_env_octaves(v));
        break;
    case SYNTH_PARAM_PERC_BODY:
        /* The share of the hit that is the tone, so 0% is the noise burst the voice
         * has always been and 100% is the sine alone. Percent, like the other
         * balances: the number is a proportion and there is no unit to name. */
        snprintf(buf, len, "%d%%", (int)(v * 100.0f + 0.5f));
        break;
    case SYNTH_PARAM_PERC_STEPS:
        snprintf(buf, len, "%d", perc_steps());
        break;
    case SYNTH_PARAM_PERC_PULSES:
        snprintf(buf, len, "%d/%d", perc_pulses(), perc_steps());
        break;
    case SYNTH_PARAM_PERC_ROTATE:
        snprintf(buf, len, "%d", perc_rotate());
        break;
    case SYNTH_PARAM_PERC_ACCENT:
        /*
         * The figure's NAME, because it is a list and there is no number left to print:
         * HOW HARD the weak onsets are struck is the WEAK VEL setting now, on its own
         * sector on OPTIONS, and this knob would only be repeating it. The names are the
         * table the engine reads its masks from, so the display and the rule cannot drift
         * apart — see ACCENT_NAME.
         *
         * The SAME text on both pages because both read ACCENT_NAME, not because the value
         * is shared: each part has its own figure (see SYNTH_PARAM_SEQ_ACCENT), and one
         * table of names is what keeps the two sectors reading alike. The widest form is
         * five characters and 46 px — that is the budget the ring's fourth seat was
         * measured against, so a longer name here is a layout change; see the note above
         * SEQ_RING_R in synth_ui.c.
         */
        snprintf(buf, len, "%s", ACCENT_NAME[accent_index_perc()]);
        break;
    case SYNTH_PARAM_SEQ_ACCENT:
        snprintf(buf, len, "%s", ACCENT_NAME[accent_index_seq()]);
        break;
    case SYNTH_PARAM_ARP_ACCENT:
        snprintf(buf, len, "%s", ACCENT_NAME[accent_index_arp()]);
        break;

    /*
     * THE BASS SECTION'S SIXTEEN READOUTS.
     *
     * KIT and PAT print their NAME and nothing else: both are lists of thirty and the arc
     * already shows WHERE in the list the knob is, so a number beside it would be the one
     * thing nobody reads. The names are the tables above, which is the only reason those
     * tables exist — nothing in the audio path knows what a kit is called.
     *
     * OCT and LEN print the NUMBER the module is actually using, computed with the module's
     * own mapping (floor(v * 4 + 0.5) - 2 and 4 + floor(v * 12 + 0.5), see root_hz() and the
     * step length in synth_bass.cpp) so the display cannot name an octave or a bar length the
     * voice is not playing.
     *
     * The eight macros that are proportions print percent, and LVL prints the GAIN the fader
     * lands on rather than its travel — the same rule the drone's registers and the drum's
     * lanes follow, because the fader law is a square and the number worth reading is the one
     * that says how loud the part is.
     */
    case SYNTH_PARAM_BASS_KIT:
        snprintf(buf, len, "%s", s_bass_kit_names[bass_kit_index()]);
        break;
    case SYNTH_PARAM_BASS_PAT:
        snprintf(buf, len, "%s", s_bass_pat_names[bass_pat_index()]);
        break;
    case SYNTH_PARAM_BASS_OCT:
        /* Слот 1 теперь SNAP: доля, как у остальных пропорций, поэтому процент. */
        snprintf(buf, len, "%d%%", (int)floorf(clamp01f(v) * 100.0f + 0.5f));
        break;
    case SYNTH_PARAM_BASS_LEN: {
        /* The steps of the bar the figure plays: 4 at the bottom of the arc, 16 at the top. */
        const int steps = 4 + (int)floorf(clamp01f(v) * 12.0f + 0.5f);
        snprintf(buf, len, "%d", steps);
        break;
    }
    case SYNTH_PARAM_BASS_VAR:
        snprintf(buf, len, "%s", s_bass_var_names[bass_var_index()]);
        break;
    case SYNTH_PARAM_BASS_ACCENT:
        snprintf(buf, len, "%s", ACCENT_NAME[accent_index_of(SYNTH_PARAM_BASS_ACCENT)]);
        break;
    case SYNTH_PARAM_BASS_TONE: {
        /*
         * ОКТАВА ЛИНИИ. Пять положений, и печатается сдвиг, а не номер: «+1 окт».
         *
         * Срез и добротность больше не показываются: они живут в заготовке, и число у них
         * одно — то, которое выбрал кит. Ручки для них на странице нет.
         */
        const int shift = (int)lroundf(s_param[SYNTH_PARAM_BASS_TONE] * 14.0f) - 7;

        if (shift == 0) {
            snprintf(buf, len, "0");
        } else {
            /* Полутоны, а не номер положения: «+7 ST» — это квинта, и её видно сразу. */
            snprintf(buf, len, "%+d ST", shift);
        }
        break;
    }
    case SYNTH_PARAM_BASS_DRIVE:
        /* Слот мёртв: резонанс приходит из заготовки. Показываем добротность кита, чтобы
         * настройка не выглядела пустой, если слот всё-таки попадёт на экран. */
        snprintf(buf, len, "Q %.2f", (double)synth_bass_q());
        break;
    case SYNTH_PARAM_BASS_DECAY:
    case SYNTH_PARAM_BASS_SNAP:
    case SYNTH_PARAM_BASS_GATE:
    case SYNTH_PARAM_BASS_SLIDE:
    case SYNTH_PARAM_BASS_REV:
    case SYNTH_PARAM_BASS_CHR:
    case SYNTH_PARAM_BASS_DLY:
        snprintf(buf, len, "%d%%", (int)(v * 100.0f + 0.5f));
        break;
    case SYNTH_PARAM_BASS_LVL:
        snprintf(buf, len, "%d%%", (int)(level_gain(v) * 100.0f + 0.5f));
        break;
    case SYNTH_PARAM_SET_SCREEN:
    case SYNTH_PARAM_SET_RING:
    case SYNTH_PARAM_SET_MIC:
        snprintf(buf, len, "%d%%", (int)(v * 100.0f + 0.5f));
        break;
    case SYNTH_PARAM_SET_WEAKVEL:
        /*
         * The velocity itself, as a plain number — the units the engine and every other
         * velocity readout in this file use. Three characters at most, so it is the
         * shortest value on the OPTIONS page while its NAME is the longest on the
         * instrument; see the note over SEQ_RING_R in synth_ui.c for why that costs
         * nothing on a page that draws no ring of dots. The rounding is the same one
         * synth_ui.c's setting_of() performs, so the number on the screen and the number
         * the knob moves by cannot disagree. */
        snprintf(buf, len, "%d", (int)(v * (float)WEAK_VEL_MAX + 0.5f));
        break;
    case SYNTH_PARAM_SET_DRIVE_POS:
        /*
         * Two positions, and the words say what the chain does rather than naming a stage:
         * BEFORE FX puts the saturation on the sum of the layers, so the chorus, the delay and
         * the reverb all hear it; AFTER FX puts it on the mixed output and the effects hear the
         * dry sum.
         */
        snprintf(buf, len, "%s", (v > 0.5f) ? "AFTER FX" : "BEFORE FX");
        break;
    case SYNTH_PARAM_SET_RINGMODE: {
        static const char *const modes[] = { "PARAM", "STEREO", "OFF", "REACTIVE", "ALWAYS" };
        const int i = (int)(v * 4.0f + 0.5f);
        snprintf(buf, len, "%s", modes[i < 0 ? 0 : (i > 4 ? 4 : i)]);
        break;
    }
    case SYNTH_PARAM_SEQ_RESET:
    case SYNTH_PARAM_PERC_RESET: {
        /* The same six positions on both pages, printed the same way: INF for zero, the step
         * count otherwise. Which part's grid that count belongs to is said by the page the
         * knob is on and by the parameter's own description, not by the number. */
        const int i = (int)(v * (float)(APP_SEQ_RESET_COUNT - 1) + 0.5f);
        const int steps = app_seq_reset_steps(i < 0 ? 0 : (i >= APP_SEQ_RESET_COUNT
                                                           ? APP_SEQ_RESET_COUNT - 1 : i));
        if (steps == 0) {
            snprintf(buf, len, "INF");
        } else {
            snprintf(buf, len, "%d", steps);
        }
        break;
    }
    case SYNTH_PARAM_SET_FASTRAND: {
        static const char *const rand_modes[] = { "OFF", "PARAM", "PAGE" };
        int k = (int)(v * 2.0f + 0.5f);

        if (k < 0) {
            k = 0;
        } else if (k > 2) {
            k = 2;
        }
        snprintf(buf, len, "%s", rand_modes[k]);
        break;
    }
    case SYNTH_PARAM_SET_AUTOPLAY: {
        static const char *const auto_modes[] = { "ON", "OFF", "STORE" };
        int k = (int)(v * 2.0f + 0.5f);

        if (k < 0) {
            k = 0;
        } else if (k > 2) {
            k = 2;
        }
        snprintf(buf, len, "%s", auto_modes[k]);
        break;
    }
    case SYNTH_PARAM_SET_PATCH: {
        static const char *const modes[] = { "FORGET", "STORE", "RANDOM" };
        const int i = (int)(v * 2.0f + 0.5f);
        snprintf(buf, len, "%s", modes[i < 0 ? 0 : (i > 2 ? 2 : i)]);
        break;
    }
    case SYNTH_PARAM_DRONE_WAVE:
    case SYNTH_PARAM_LEAD_WAVE:
    case SYNTH_PARAM_DRONE_OSC_LOW:
    case SYNTH_PARAM_DRONE_OSC_MID:
    case SYNTH_PARAM_DRONE_OSC_HIGH: {
        /* Three letters each, and the words are what the shapes ARE rather than what the
         * generator is called: SQR, not PLS, because the width is fixed at half the period
         * and a pulse width is not a control this instrument has; NSE, not NOI, to sit in
         * the same three columns as the rest. See part_wave_t in this file. */
        static const char *const waves[] = { "SIN", "TRI", "SAW", "SQR", "SPR", "NSE", "SKW" };

        /*
         * У ДРОНА ШЕСТЬ ИМЁН, У ЛИДА СЕМЬ: SKW есть только у лида, потому что излом
         * скошенной пилы задаётся шириной импульса, а её ручки в дроне нет.
         */
        const bool lead = (param == SYNTH_PARAM_LEAD_WAVE);
        const int count = lead ? PW_COUNT : (PW_COUNT - 1);
        const int i = (int)(v * (float)(count - 1) + 0.5f);

        snprintf(buf, len, "%s", waves[i < 0 ? 0 : (i > count - 1 ? count - 1 : i)]);
        break;
    }
    case SYNTH_PARAM_DRONE_FOLLOW: {
        /* The three modes by the names the page prints, in list order. */
        static const char *const modes[] = { "SCALE", "CONS", "FULL" };
        const int i = (int)(v * (float)(DRONE_FOLLOW_COUNT - 1) + 0.5f);
        snprintf(buf, len, "%s",
                 modes[i < 0 ? 0 : (i > DRONE_FOLLOW_COUNT - 1 ? DRONE_FOLLOW_COUNT - 1 : i)]);
        break;
    }
    case SYNTH_PARAM_DRONE_KTRCK:
    case SYNTH_PARAM_LEAD_KTRCK:
        /* The knob's own travel, in percent: 0 is "the cutoff does not follow the pitch" and
         * 100 is "it follows it octave for octave", and there is no unit in between to name. */
        snprintf(buf, len, "%d%%", (int)(v * 100.0f + 0.5f));
        break;
    case SYNTH_PARAM_SET_RNDDELAY: {
        static const char *const modes[] = { "OFF", "ON" };
        const int i = (int)(v * 1.0f + 0.5f);
        snprintf(buf, len, "%s", modes[i < 0 ? 0 : (i > 1 ? 1 : i)]);
        break;
    }
    case SYNTH_PARAM_SET_MIDIIN: {
        /*
         * The same two words as the random-delay switch, and for the same reason: they are
         * what the two positions ARE rather than what the mechanism is called, and they are
         * three characters at most — the shortest value on a page whose longest is RANDOM.
         * The rounding is synth_ui.c's setting_of(), so the word and the position the knob
         * lands on cannot disagree.
         */
        static const char *const modes[] = { "OFF", "ON" };
        const int i = (int)(v * 1.0f + 0.5f);
        snprintf(buf, len, "%s", modes[i < 0 ? 0 : (i > 1 ? 1 : i)]);
        break;
    }
    case SYNTH_PARAM_SET_WAVEMORPH: {
        /*
         * The duration itself, read out of the same table the fade reads, so the number on the
         * screen and the time the engine takes cannot drift apart — "OFF" is the table's 0 and
         * there is no second copy of the strings to keep in step. Four to six characters,
         * which is what this page already draws: its longest value is RANDOM.
         */
        const int i = (int)(v * (float)(WAVE_MORPH_COUNT - 1) + 0.5f);
        const int k = i < 0 ? 0 : (i > WAVE_MORPH_COUNT - 1 ? WAVE_MORPH_COUNT - 1 : i);
        const unsigned ms = WAVE_MORPH_MS[k];
        if (ms == 0) {
            snprintf(buf, len, "OFF");
        } else {
            snprintf(buf, len, "%u MS", ms);
        }
        break;
    }
    case SYNTH_PARAM_SET_SLIDE: {
        static const char *const times[] = { "OFF", "0.2 S", "0.5 S", "1.5 S", "3 S" };
        const int i = (int)(v * (float)(SLIDE_COUNT - 1) + 0.5f);
        snprintf(buf, len, "%s",
                 times[i < 0 ? 0 : (i > SLIDE_COUNT - 1 ? SLIDE_COUNT - 1 : i)]);
        break;
    }
    /*
     * СТРАНИЦА УДАРКИ: ЕДИНИЦЫ В ПОДПИСИ.
     *
     * Здесь стоял общий случай — голое число без знака, и было непонятно, проценты это,
     * миллисекунды или полутоны. Теперь у каждой ручки своя единица: доли удара в
     * процентах, строй в полутонах, длина удара множителем к своей.
     */
    case SYNTH_PARAM_PERC_TONE:
    case SYNTH_PARAM_PERC_TIMBRE:
    case SYNTH_PARAM_PERC_BODY_TRIM:
        snprintf(buf, len, "%d%%", (int)(v * 100.0f + 0.5f));
        break;
    case SYNTH_PARAM_PERC_TUNE: {
        /* Строй: середина хода — ноль, края — плюс и минус двенадцать полутонов. */
        const int semis = (int)((v - 0.5f) * 24.0f + (v >= 0.5f ? 0.5f : -0.5f));

        if (semis == 0) {
            snprintf(buf, len, "0");
        } else {
            snprintf(buf, len, "%+d st", semis);
        }
        break;
    }
    case SYNTH_PARAM_PERC_LENGTH: {
        /* Длина удара — множитель к своей: 0.5 — вдвое короче, 2.0 — вдвое длиннее. */
        snprintf(buf, len, "x%.2f", (double)exp2f((v - 0.5f) * 2.64f));
        break;
    }
    /*
     * ТИП ДИЛЕЯ — НАЗВАНИЕМ.
     *
     * Списочная ручка, и в подписи стоит слово: DIGITAL, PINGPONG, MULTI, TAPE, FILTER или
     * DIFFUSE. Без этого случая ручка показывала голое число, и владелец справедливо сказал,
     * что списка режимов не видно.
     */
    case SYNTH_PARAM_DELAY_TYPE: {
        static const char *const dly_types[] = { "DIGITAL", "PINGPONG", "MULTI",
                                                 "TAPE", "FILTER", "DIFFUSE" };
        int k = (int)(v * 5.0f + 0.5f);

        if (k < 0) {
            k = 0;
        } else if (k > 5) {
            k = 5;
        }
        snprintf(buf, len, "%s", dly_types[k]);
        break;
    }

    /* Посылы повторов и эффект-машины в реверб — доля, значит проценты. */
    case SYNTH_PARAM_DELAY_VERB:
    case SYNTH_PARAM_FX_VERB:
        snprintf(buf, len, "%d%%", (int)(v * 100.0f + 0.5f));
        break;

    default:
        snprintf(buf, len, "%d", (int)(v * 100.0f + 0.5f));
        break;
    }
}

/*
 * The tempo's readout for the transport, from the published snapshot rather than from the
 * parameter: while a clock is live the number beside the wheel is the tempo being played,
 * and the moment the clock times out the same call answers with the parameter, so the
 * screen follows the instrument back without a second rule of its own. The format is
 * seq_tempo_text()'s, which is the parameter's own line as well — one string, two sources.
 */
extern "C" void synth_app_tempo_text(char *buf, size_t len)
{
    if (!buf || len == 0) {
        return;
    }

    seq_tempo_text(synth_app_tempo_now(nullptr), buf, len);
}

extern "C" void synth_app_get_stats(synth_app_stats_t *out)
{
    if (!out) {
        return;
    }

    for (int p = 0; p < (int)SYNTH_PARAM_COUNT; p++) {
        out->param[p] = s_param[p];
    }

    out->cpu_load = s_cpu_load;
    out->blocks = s_blocks;
    out->deadline_misses = s_deadline_misses;
    out->write_errors = s_write_errors;
    out->dsp_us_last = s_dsp_us_last;
    out->dsp_us_max = s_dsp_us_max;
    out->block_budget_us =
        (uint32_t)((uint64_t)SYNTH_BLOCK_SAMPLES * 1000000ULL / SYNTH_SAMPLE_RATE);
    out->heap_internal_free = (uint32_t)heap_caps_get_free_size(MALLOC_CAP_INTERNAL);
}

/* -------------------------------------------------------------------------- */
/* The random draws                                                          */
/* -------------------------------------------------------------------------- */
/*
 * A DRAW CHOOSES A CHARACTER BEFORE IT CHOOSES A NUMBER, and everything that can be
 * derived from that choice is derived rather than thrown.
 *
 * The arithmetic lives in synth_random_math.h, where it is plain numbers and no
 * engine: the application passes its own constants and its own generator, and the
 * host test in build/accept/random_host.c passes the same constants and a seeded one
 * and checks a hundred thousand draws against the rules. What is here is the wiring —
 * which parameter each number goes to, in the order that keeps the drum's snap honest.
 *
 * WHY THIS AND NOT A WIDER WINDOW. The old draw was one window for thirty parameters
 * and no relations at all. tools/random-model.js puts a number on what that sounded
 * like: 1.7 % of draws were muddy, 38 % had no bottom once the corner went high and
 * the drum stayed out of the bass, 95 % put more than one full wet level into the
 * room, and the drum was never in the key. The harness says this draw is clean on all
 * four and still spreads the corner over 128 to 1.
 */
#include "synth_random_math.h"

static_assert(RR_SCALE_COUNT == SEQ_SCALE_COUNT, "one weight per scale");

/* esp_random() and not the sequencer's own generator: a draw must not walk the stream
 * the figure is playing from. */
static float random_unit_ctx(void *ctx)
{
    (void)ctx;
    return (float)(esp_random() >> 8) / 16777216.0f;
}

extern "C" int synth_app_random_draw(int structural, int draw_delay_time)
{
    void *const ctx = nullptr;
    const int ch_index = rr_index(random_unit_ctx, ctx, RR_CHARACTER_COUNT);
    const rr_character_t *ch = &RR_CHARACTERS[ch_index];
    const rr_feel_t *feel = &RR_FEEL[ch_index];
    int written = 0;

#define RW(p, v) do { synth_app_set_param((p), (v)); written++; } while (0)

    /* --- the sound ---------------------------------------------------------- */
    /*
     * BITE first: one draw in three is pushed away from the middle of every texture
     * control at once, so two draws do not land on the same comfortable average. The
     * corner is not stretched — it is the character, and it is snapped to a semitone.
     */
    const float bite = rr_bite(random_unit_ctx, ctx);
    const int wild = rr_wild(random_unit_ctx, ctx);
    const float cutoff = rr_cutoff_snapped(rr_pick(random_unit_ctx, ctx, ch->cutoff, RR_SHARE_IDENTITY, wild),
                                           s_drones[0].fc_hz,
                                           DRONE_CUTOFF_MIN_HZ, DRONE_CUTOFF_MAX_HZ,
                                           CUTOFF_MACRO_OCTAVES);
    float depth = rr_stretch(rr_pick(random_unit_ctx, ctx, ch->depth, RR_SHARE_TEXTURE, wild), bite);
    RW(SYNTH_PARAM_CUTOFF, cutoff);

    /*
     * THE SHAPE IS A DRAW OF ITS OWN, and it is where most of the difference between two
     * patches of one character comes from: a low pass and a band pass at the same corner
     * are two different instruments, and so are a saw and a supersaw behind them. The
     * character weights the choice; it does not fix it.
     */
    RW(SYNTH_PARAM_DRONE_FILTER_MODE,
       rr_step01(rr_weighted(random_unit_ctx, ctx, ch->mode, 3), 3));
    RW(SYNTH_PARAM_LEAD_FILTER_MODE,
       rr_step01(rr_weighted(random_unit_ctx, ctx, ch->mode, 3), 3));
    RW(SYNTH_PARAM_LEAD_WAVE, rr_step01(rr_weighted(random_unit_ctx, ctx, ch->wave, 6), 6));

    /*
     * THE DRONE'S THREE OSCILLATORS, one shape for all three. This is the largest single
     * difference a draw can make: a saw drone and a square drone under the same corner are
     * two instruments, and the filter's window was tuned to allow either. All three
     * registers take the same shape because the drone is one voice — registers that
     * disagree about their waveform are a different machine, not a different colour.
     */
    int drone_wave = rr_weighted(random_unit_ctx, ctx, ch->wave, 6);
    if (drone_wave == 5) {
        /* NOISE is the lead's colour, not the drone's: a band of hiss under everything is
         * the one shape that reads as a fault rather than as a patch. */
        drone_wave = 2;
    }
    RW(SYNTH_PARAM_DRONE_OSC_LOW, rr_step01(drone_wave, 6));
    RW(SYNTH_PARAM_DRONE_OSC_MID, rr_step01(drone_wave, 6));
    RW(SYNTH_PARAM_DRONE_OSC_HIGH, rr_step01(drone_wave, 6));

    /*
     * WHAT THE MODULATION MOVES, and from where. Six draws in ten keep it on the drone's
     * own filter and pan — that is the instrument's designed movement — and four send it to
     * the drum or to the lead's pitch, which is a different patch rather than a different
     * number. The trigger follows the same rule: FREE and NOTE most of the time, ONES and
     * STEP when the draw is already unconventional.
     */
    const int dest = (rr_index(random_unit_ctx, ctx, 10) < 6)
                         ? rr_index(random_unit_ctx, ctx, 3)
                         : 3 + rr_index(random_unit_ctx, ctx, MOD_DEST_COUNT - 3);
    RW(SYNTH_PARAM_MOD_DEST, rr_step01(dest, MOD_DEST_COUNT));
    /* Второй приёмник — из середины списка одиночных: OFF и пары оставлены в покое, иначе
     * случайный патч складывал бы четыре места сразу. */
    RW(SYNTH_PARAM_MOD_DEST2, rr_step01(1 + rr_index(random_unit_ctx, ctx, 8), MOD_DEST_COUNT));
    const int trig = (rr_index(random_unit_ctx, ctx, 10) < 7)
                         ? rr_index(random_unit_ctx, ctx, 2)
                         : 2 + rr_index(random_unit_ctx, ctx, 3);
    RW(SYNTH_PARAM_MOD_TRIG, rr_step01(trig, 4));

    const float res = rr_stretch(rr_pick(random_unit_ctx, ctx, ch->res, RR_SHARE_TEXTURE, wild), bite);
    RW(SYNTH_PARAM_RESONANCE, res);
    /* The corner, the resonance and the sweep are drawn before either of the two is
     * written, so the one combination that sounds blocked can be refused here; see
     * rr_clean_sweep(). */
    depth = rr_clean_sweep(depth, rr_cutoff_hz(cutoff, s_drones[0].fc_hz,
                                               DRONE_CUTOFF_MIN_HZ, DRONE_CUTOFF_MAX_HZ,
                                               CUTOFF_MACRO_OCTAVES),
                           resonance_for(&s_drones[0], res) * 0.01f);
    RW(SYNTH_PARAM_FILTER_DEPTH, depth);
    RW(SYNTH_PARAM_FILTER_RATE, rr_stretch(rr_pick(random_unit_ctx, ctx, ch->rate, RR_SHARE_TEXTURE, wild), bite));
    RW(SYNTH_PARAM_MOTION_DEPTH,
       rr_stretch(0.3f + 0.4f * random_unit_ctx(ctx), bite));
    RW(SYNTH_PARAM_MOTION_RATE, 0.1f + 0.5f * random_unit_ctx(ctx));

    int shape = ch->lfo_lo + rr_index(random_unit_ctx, ctx, ch->lfo_hi - ch->lfo_lo + 1);
    if (depth > 0.6f && shape == 4) {
        shape = 0;                  /* a random sweep under a deep one is noise */
    }
    RW(SYNTH_PARAM_LFO_SHAPE, rr_step01(shape, LFO_SHAPE_COUNT));

    RW(SYNTH_PARAM_LEAD_CUTOFF,
       rr_pick(random_unit_ctx, ctx, ch->lead_cutoff, 0.55f, wild));
    RW(SYNTH_PARAM_LEAD_RESO, rr_stretch(rr_pick(random_unit_ctx, ctx, ch->lead_reso, RR_SHARE_TEXTURE, wild), bite));
    RW(SYNTH_PARAM_LEAD_ENV, 0.2f + 0.6f * random_unit_ctx(ctx));
    RW(SYNTH_PARAM_LEAD_ATTACK,
       rr_stretch(rr_pick(random_unit_ctx, ctx, ch->lead_attack, RR_SHARE_TEXTURE, wild), bite));
    RW(SYNTH_PARAM_LEAD_DECAY,
       rr_stretch(rr_pick(random_unit_ctx, ctx, ch->lead_decay, RR_SHARE_TEXTURE, wild), bite));
    RW(SYNTH_PARAM_LEAD_SUSTAIN,
       rr_stretch(rr_pick(random_unit_ctx, ctx, ch->lead_sustain, RR_SHARE_TEXTURE, wild), bite));
    RW(SYNTH_PARAM_LEAD_RELEASE,
       rr_stretch(rr_pick(random_unit_ctx, ctx, ch->lead_release, RR_SHARE_TEXTURE, wild), bite));

    /*
     * GLIDE IS NOT DRAWN. It is the lead's playing and not its tone, and the playing is the
     * one thing a draw must not decide: a slide under every note turns a new sound into the
     * same sound wet. It stays where the player left it.
     */

    /* Ducking on the hit, or not: it is a sound, and a third of the draws use it. */
    RW(SYNTH_PARAM_MASTER_DUCK,
       (rr_index(random_unit_ctx, ctx, 3) == 0) ? 0.2f + 0.3f * random_unit_ctx(ctx) : 0.0f);
    RW(SYNTH_PARAM_MASTER_DUCK_SRC,
       (rr_index(random_unit_ctx, ctx, 2) == 0) ? 0.5f * random_unit_ctx(ctx) : 0.0f);
    RW(SYNTH_PARAM_MASTER_DUCK_REL, 0.2f + 0.5f * random_unit_ctx(ctx));

    /*
     * THE PERFORMANCE, which is half of what a listener calls a character and the half
     * that the corner cannot carry: a dark patch at 45 BPM with three notes in a bar and
     * a bright one at 210 BPM with every step firing are two instruments, and that is
     * true even when both are heard through the same room. The windows are narrow per
     * character on purpose — this is the difference the draw is FOR.
     */
    RW(SYNTH_PARAM_DENSITY,
       rr_stretch(rr_pick(random_unit_ctx, ctx, feel->density, RR_SHARE_TEXTURE, wild), bite));
    /*
     * BPM IS NOT DRAWN, AND THE WINDOW IN RR_FEEL STAYS BECAUSE THE DESIGN ARGUES IT.
     *
     * A tempo is the player's collusion with everyone else in the room — the other machines,
     * the click, the hands — and a patch that arrives at 47 BPM because a die said so is a
     * patch nobody can use without moving one knob first. The character's window is what the
     * design measured, so it stays where it is and the draw simply does not spend a throw on
     * it: the tempo is the one number a randomiser may not touch.
     */
    RW(SYNTH_PARAM_ARP_SPEED,
       rr_pick(random_unit_ctx, ctx, feel->arp, RR_SHARE_TEXTURE, wild));
    RW(SYNTH_PARAM_SEQ_SCATTER,
       rr_stretch(rr_pick(random_unit_ctx, ctx, feel->scatter, RR_SHARE_TEXTURE, wild), bite));
    RW(SYNTH_PARAM_SEQ_GATE,
       rr_stretch(rr_pick(random_unit_ctx, ctx, feel->gate, RR_SHARE_TEXTURE, wild), bite));

    /* DRIVE IS NOT DRAWN AT ALL. The shaper is a decision about the recording rather than
     * about the patch, and a draw that lands on fold is an accident the player has to undo
     * by ear. The knob stays exactly where the hand put it, whatever it was. */

    /*
     * THE DRUM SECTION IS DRAWN AS A KIT AND A PART, and the trims stay near the middle.
     *
     * A kit is already a character: one position of the list changes four recipes, so a draw
     * that also swung every trim would be a draw with two characters in it. The kit and the
     * groove are therefore chosen outright, the trims are drawn in the middle half of their
     * travel, and SPEED is almost always the one ratio that agrees with the transport — a
     * randomiser that half-times the drum is a randomiser that makes the player fix the bar.
     */
    RW(SYNTH_PARAM_PERC_KIT,
       rr_step01(rr_index(random_unit_ctx, ctx, PERC_KIT_COUNT), PERC_KIT_COUNT));
    RW(SYNTH_PARAM_PERC_GROOVE,
       rr_step01(rr_index(random_unit_ctx, ctx, PERC_GROOVE_COUNT), PERC_GROOVE_COUNT));
    RW(SYNTH_PARAM_PERC_TONE,
       rr_stretch(0.42f + 0.16f * random_unit_ctx(ctx), bite));
    RW(SYNTH_PARAM_PERC_TUNE,
       rr_stretch(0.44f + 0.12f * random_unit_ctx(ctx), bite));
    RW(SYNTH_PARAM_PERC_LENGTH,
       rr_stretch(0.36f + 0.28f * random_unit_ctx(ctx), bite));
    RW(SYNTH_PARAM_PERC_BODY_TRIM,
       rr_stretch(0.38f + 0.24f * random_unit_ctx(ctx), bite));
    RW(SYNTH_PARAM_PERC_TIMBRE,
       rr_stretch(0.18f + 0.42f * random_unit_ctx(ctx), bite));
    RW(SYNTH_PARAM_PERC_VARIATION,
       rr_stretch(0.05f + 0.35f * random_unit_ctx(ctx), bite));
    RW(SYNTH_PARAM_PERC_FILL,
       rr_stretch(0.15f + 0.45f * random_unit_ctx(ctx), bite));
    RW(SYNTH_PARAM_PERC_SWING,
       rr_stretch(0.30f * random_unit_ctx(ctx), bite));
    /*
     * SPEED IS NOT DRAWN EITHER, and for the same reason as the glide: it is a decision about
     * the part and not a colour of the sound. A draw that halved the drum's clock turned every
     * other sound into half time, and the one thing a fresh sound must not do is arrive with
     * the tempo already moved.
     */

    /*
     * THE BASS IS DRAWN TOO, and by the same three rules as the drums: a character is
     * chosen outright, a sound control is drawn in the middle of its travel, and the line's
     * playing is drawn as playing rather than as tone.
     *
     * Before this the draw stepped around the whole bass section, so a fresh sound arrived
     * over the previous bass — the kit and the figure that were there before. The kit is a
     * character (as PERC_KIT is), the figure is the music (as PERC_GROOVE is), and both are
     * therefore chosen rather than nudged.
     */
    RW(SYNTH_PARAM_BASS_KIT,
       rr_step01(rr_index(random_unit_ctx, ctx, BASS_KIT_COUNT), BASS_KIT_COUNT));

    /*
     * РИСУНОК — ПО ПЛОТНОСТИ, А НЕ ПО СПИСКУ.
     *
     * Таблица рисунков отсортирована по плотности, поэтому номер и есть плотность. Центр окна
     * берётся у характера: у DEEP и NOISE он ниже, у MACHINE и DIRT выше, — и бросок тянется к
     * нему. Так редкий характер получает редкую линию, а густой густую, вместо того чтобы
     * одинаково часто получать и педаль из одной ноты, и сплошные шестнадцатые.
     */
    const float char_density = (feel->density[0] + feel->density[1]) * 0.5f;
    const int bass_rank = rr_bass_rank(random_unit_ctx, ctx, BASS_PAT_COUNT,
                                       0.30f + 0.45f * char_density, wild);
    RW(SYNTH_PARAM_BASS_PAT, rr_step01(bass_rank, BASS_PAT_COUNT));

    /* Плотность рисунка, 0..1 — из неё выводится игра: чем гуще линия, тем короче нота и тем
     * реже акцент, иначе густая фигура превращается в кашу, а редкая звучит вяло. */
    const float bass_dense = (float)bass_rank / (float)(BASS_PAT_COUNT - 1);

    /* The sound: windows inside the musical part of each knob, pushed off the middle by
     * BITE the way the drone's textures are. The sub is left out on a third of the draws —
     * otherwise every new patch would stand on the same bottom. */
    RW(SYNTH_PARAM_BASS_OCT,                    /* slot 1: the edge's envelope, SNAP */
       rr_stretch(0.20f + 0.45f * random_unit_ctx(ctx), bite));
    /* Слот 2 — октава линии. Бросок держит её около центра: сдвиг на октаву меняет регистр
     * всей линии, и это решение, а не украшение, поэтому крайности редки. */
    {
        const int oct_pick = rr_index(random_unit_ctx, ctx, 10);

        /*
         * СМЕНА НОТЫ в броске: центр в половине случаев, квинта и кварта — в четверти,
         * терции — в остальном. Крайности (±6, ±7) редки: сдвиг на квинту меняет всю линию,
         * и это решение, а не украшение.
         */
        {
            const int pick = rr_index(random_unit_ctx, ctx, 16);

            switch (pick) {
            case 0:  RW(SYNTH_PARAM_BASS_TONE, 12.0f / 14.0f); break;   /* +5: кварта */
            case 1:  RW(SYNTH_PARAM_BASS_TONE, 14.0f / 14.0f); break;   /* +7: квинта */
            case 2:  RW(SYNTH_PARAM_BASS_TONE, 9.0f / 14.0f);  break;   /* +2: секунда */
            case 3:  RW(SYNTH_PARAM_BASS_TONE, 10.0f / 14.0f); break;   /* +3: терция */
            case 4:  RW(SYNTH_PARAM_BASS_TONE, 2.0f / 14.0f);  break;   /* -5: кварта вниз */
            default: RW(SYNTH_PARAM_BASS_TONE, 0.5f);          break;   /* центр */
            }
        }
    }
    RW(SYNTH_PARAM_BASS_DECAY,
       rr_stretch(0.30f + 0.30f * random_unit_ctx(ctx), bite));
    RW(SYNTH_PARAM_BASS_SNAP,                   /* slot 4: the sub, SUB */
       (rr_index(random_unit_ctx, ctx, 3) == 0) ? 0.0f : 0.10f + 0.40f * random_unit_ctx(ctx));
    /* Слот 5 мёртв: резонанс приходит из заготовки, и двигать в патче нечего. */

    /* The playing, not the tone: the same division the drone makes between its corner and
     * its density. LEN takes one of three musical lengths, because a figure seven and a half
     * steps long reads as neither a figure nor a mistake. */
    RW(SYNTH_PARAM_BASS_VAR,
       rr_stretch(0.20f + 0.55f * random_unit_ctx(ctx), bite));
    RW(SYNTH_PARAM_BASS_GATE,
       rr_stretch(0.30f + 0.45f * (1.0f - bass_dense) + 0.12f * random_unit_ctx(ctx), bite));
    RW(SYNTH_PARAM_BASS_ACCENT,
       rr_stretch(0.12f + 0.40f * (1.0f - bass_dense) + 0.10f * random_unit_ctx(ctx), bite));
    RW(SYNTH_PARAM_BASS_SLIDE,
       rr_stretch(0.25f * random_unit_ctx(ctx), bite));

    /* Цикл делит такт: 4, 8 или 16. См. rr_bass_len01(). */
    RW(SYNTH_PARAM_BASS_LEN, rr_bass_len01(random_unit_ctx, ctx));

    /*
     * ФЕЙДЕРЫ СЛОЯМ — НЕ СЛУЧАЮ, А ХАРАКТЕРУ.
     *
     * Уровни — это микс, и отдавать их кости нельзя: патч, у которого лид громче ударки на
     * восемь децибел, звучит не смело, а сломанно. Но и стоять всем патчам на одной фабричной
     * балансировке скучно. Поэтому каждый фейдер получает ТРИМ в полдецибела плюс надбавку от
     * самого характера: DEEP и QUIET тянут вверх дрон, DIRT — бас, MACHINE — ударку, GLASS —
     * лид. Сумма уровней при этом не растёт: надбавка одному снимается с другого.
     */
    {
        float drone_boost = 0.0f, lead_boost = 0.0f, perc_boost = 0.0f, bass_boost = 0.0f;

        if (ch->cutoff[1] <= 0.45f) {          /* DEEP, DIRT, QUIET: тёмные */
            drone_boost += 0.05f;
            bass_boost += 0.03f;
        }
        if (feel->density[1] >= 0.65f) {       /* MACHINE, GLASS: густые и звонкие */
            perc_boost += 0.05f;
            lead_boost += 0.02f;
        }
        if (ch->verb_size[1] >= 0.95f) {       /* NOISE, QUIET: большая комната */
            lead_boost -= 0.03f;
            drone_boost += 0.02f;
        }

        /*
         * ЦЕНТР БАЛАНСИРОВКИ — ЧИСЛО, А НЕ УМОЛЧАНИЕ ПАРАМЕТРА.
         *
         * Здесь стоял synth_app_param_default(), и это была ошибка: у PERC_LEVEL умолчание
         * ноль, потому что патч, написанный до появления этого фейдера, не должен вдруг
         * начать играть ударку. Но бросок — не старый патч, а НОВЫЙ звук, и новый звук с
         * выключенной ударкой это поломка, а не замысел. (Владелец: «ударные тоже должны
         * участвовать в рандоме, сейчас их уровень ставится на ноль».)
         *
         * Центр поэтому задан явно, в ходах фейдера: 0.80 — общий уровень как на свежем
         * приборе; 0.7071 — лид, это ровно его умолчание (25 % от задуманного 0.5); 0.894 —
         * ударка, 0.894^2 = 0.8 усиления, то есть та громкость, на которой она сведена;
         * 0.80 — бас, его умолчание. Дальше надбавка характера и трим в полдецибела.
         */
        const float jitter = 0.025f;           /* +-0.5 дБ каждому, независимо */
        RW(SYNTH_PARAM_LEVEL,
           rr_clamp01(0.80f + drone_boost + (random_unit_ctx(ctx) - 0.5f) * jitter));
        /* Разброс стерео у лида: в половине бросков ноль — моно это тоже решение, — иначе до
     * половины хода: больше на аккорде уже разваливает центр. */
    /* Ширина импульса: в половине бросков меандр, иначе до половины хода. */
    RW(SYNTH_PARAM_LEAD_PW,
       (rr_index(random_unit_ctx, ctx, 10) < 5) ? 0.0f : 0.5f * random_unit_ctx(ctx));
    RW(SYNTH_PARAM_LEAD_SPREAD,
       (rr_index(random_unit_ctx, ctx, 10) < 5) ? 0.0f : 0.5f * random_unit_ctx(ctx));
    RW(SYNTH_PARAM_LEAD_LEVEL,
           rr_clamp01(0.7071f + lead_boost + (random_unit_ctx(ctx) - 0.5f) * jitter));
        RW(SYNTH_PARAM_PERC_LEVEL,
           rr_clamp01(0.894f + perc_boost + (random_unit_ctx(ctx) - 0.5f) * jitter));
        RW(SYNTH_PARAM_BASS_LVL,
           rr_clamp01(0.80f + bass_boost + (random_unit_ctx(ctx) - 0.5f) * jitter));
    }

    /* THE SENDS STAY: how much of a part sits in the room is a decision about the
     * recording, not about the sound, and the wet budget below decides the room itself. */

    RW(SYNTH_PARAM_VERB_MODE, rr_step01(rr_weighted(random_unit_ctx, ctx, ch->verb, 4), 4));
    RW(SYNTH_PARAM_VERB_SIZE,
       rr_stretch(rr_pick(random_unit_ctx, ctx, ch->verb_size, RR_SHARE_TEXTURE, wild), bite));
    RW(SYNTH_PARAM_VERB_DAMP,
       rr_stretch(rr_pick(random_unit_ctx, ctx, ch->verb_damp, RR_SHARE_TEXTURE, wild), bite));
    RW(SYNTH_PARAM_CHORUS_RATE,
       rr_stretch(0.2f + 0.5f * random_unit_ctx(ctx), bite));
    RW(SYNTH_PARAM_CHORUS_DEPTH,
       rr_stretch(0.2f + 0.6f * random_unit_ctx(ctx), bite));

    if (draw_delay_time) {
        /* The delay's time section is the one part of the timbre the player can take
         * out of the draw, and it stays out when RND DEL is off: both halves of it
         * move the read pointer, and that is heard as rhythm. */
        /* Одно положение слитой ручки: розыгрыш может попасть и в доли такта, и в
             * миллисекунды — это одно и то же время. */
            RW(SYNTH_PARAM_DELAY_TIME, random_unit_ctx(ctx));
    }

    /*
     * ONE WET BUDGET, SHARED OUT — but WHICH effect owns it is a draw of its own. In the
     * first version the reverb took the largest share on nearly every draw, so every patch
     * sat in the same room; now a draw can be a delay patch with almost no room, or a
     * chorus patch, or a hall.
     */
    float delay_mix = 0.0f, chorus_mix = 0.0f, verb_mix = 0.0f, feedback = 0.0f;
    rr_wet_budget(random_unit_ctx, ctx, &delay_mix, &chorus_mix, &verb_mix, &feedback);
    RW(SYNTH_PARAM_DELAY_MIX, delay_mix);
    RW(SYNTH_PARAM_CHORUS_MIX, chorus_mix);
    RW(SYNTH_PARAM_VERB_MIX, verb_mix);
    /* Демпфирование дилея: у половины бросков открыто, у остальных до 70 % хода. */
    RW(SYNTH_PARAM_DELAY_DAMP,
       (rr_index(random_unit_ctx, ctx, 10) < 5) ? 0.0f : 0.7f * random_unit_ctx(ctx));
    RW(SYNTH_PARAM_DELAY_FEEDBACK, feedback);
    /* --- the music ---------------------------------------------------------- */
    int scale = (int)lroundf(s_param[SYNTH_PARAM_SCALE] * (float)(SEQ_SCALE_COUNT - 1));
    int root = seq_root_midi();

    if (structural) {
        scale = rr_scale(random_unit_ctx, ctx);
        /* Тоника — по весу круга, а не поравну: A и E втрое вероятнее остальных, и это
         * слышно как «патч попал в тональность», а не как «патч попал в случайную». */
        root = 33 + 12 * rr_index(random_unit_ctx, ctx, 2) + rr_root_note(random_unit_ctx, ctx);
        if (root < SEQ_ROOT_MIN_MIDI) {
            root = SEQ_ROOT_MIN_MIDI;
        } else if (root > SEQ_ROOT_MAX_MIDI) {
            root = SEQ_ROOT_MAX_MIDI;
        }
        RW(SYNTH_PARAM_SCALE, rr_step01(scale, SEQ_SCALE_COUNT));
        /*
         * The tonic is drawn as a pitch and written as the two lists that name it: the note by
         * its position among the twelve, the octave by its position among the seven. A draw
         * that wrote only the note would keep the octave of whatever sound was standing there,
         * which is how a random patch ends up in a register nobody chose.
         */
        int root_note = root % 12;
        int root_oct = root / 12 - 1;
        if (root_oct < 1) {
            root_oct = 1;
        } else if (root_oct > SEQ_OCT_COUNT) {
            root_oct = SEQ_OCT_COUNT;
        }
        RW(SYNTH_PARAM_ROOT, (float)root_note / 11.0f);
        RW(SYNTH_PARAM_ROOT_OCT, (float)(root_oct - 1) / 6.0f);
        RW(SYNTH_PARAM_DENSITY, 0.3f + 0.4f * random_unit_ctx(ctx));
        RW(SYNTH_PARAM_OCTAVE, 0.35f + 0.3f * random_unit_ctx(ctx));

        const int steps = rr_grid(random_unit_ctx, ctx);
        int lead = 3 + rr_index(random_unit_ctx, ctx, 5);
        if (lead > steps) {
            lead = steps;
        }
        const int pick = rr_index(random_unit_ctx, ctx, 4);
        int perc = (pick < 2) ? lead : (pick == 2 ? lead - 1 : lead + 1);
        if (perc < 1) {
            perc = 1;
        } else if (perc > steps) {
            perc = steps;
        }

        const float steps01 = (float)(steps - SEQ_STEPS_MIN)
                              / (float)(SEQ_STEPS_MAX - SEQ_STEPS_MIN);
        RW(SYNTH_PARAM_SEQ_STEPS, steps01);
        RW(SYNTH_PARAM_SEQ_PULSES, rr_step01(lead - 1, steps));
        RW(SYNTH_PARAM_SEQ_SCATTER, 0.05f + 0.20f * random_unit_ctx(ctx));
        RW(SYNTH_PARAM_PERC_STEPS, steps01);
        RW(SYNTH_PARAM_PERC_PULSES, rr_step01(perc - 1, steps));
        /*
         * ROTATION IS NOT DRAWN, on either grid. It used to be drawn with rr_rotation(), whose
         * whole job was to put a pulse back on the downbeat after it had moved the figure; with
         * the draw gone there is nothing to put back, because at rotation zero the first step of
         * a euclidean figure is a pulse by construction. Rotation stays a knob: where the figure
         * starts is the player's decision, and a fresh sound that arrives already displaced
         * sounds like a mistake rather than like a pattern.
         */

        /* A rise has to have room to rise: length follows range. The range drawn is 1..3
         * octaves — never zero, because a pedal is a decision and not a colour — and a wide
         * range takes a longer figure so the climb is spread rather than compressed. */
        const int range = 1 + rr_index(random_unit_ctx, ctx, 3);
        RW(SYNTH_PARAM_ARP_RANGE, (float)range / (float)ARP_RANGE_MAX);
        const int len = 2 + rr_index(random_unit_ctx, ctx, range > 2 ? 4 : 3);
        RW(SYNTH_PARAM_ARP_LEN,
           (float)(len - ARP_LEN_MIN) / (float)(ARP_LEN_MAX - ARP_LEN_MIN));
        RW(SYNTH_PARAM_ARP_DIR, rr_step01(rr_index(random_unit_ctx, ctx, 3), ARP_DIR_COUNT));
        RW(SYNTH_PARAM_ARP_SPEED, 8.0f / 12.0f + (3.0f / 12.0f) * random_unit_ctx(ctx));
    }

    /*
     * The drum last, and in the key the draw just chose: QUANT first because turning it
     * on snaps the pitch that is already there, then the pitch itself. A drum outside
     * the scale is the single largest source of the sound the player calls a mess, and
     * it is the one thing the old draw never fixed.
     */
    const seq_scale_cfg_t *sc = &SEQ_SCALES[scale];
    RW(SYNTH_PARAM_PERC_QUANT, 1.0f);
    RW(SYNTH_PARAM_PERC_PITCH,
       synth_perc_pitch_01(rr_drum_pitch_hz(random_unit_ctx, ctx, sc->steps, sc->len,
                                            root, 45 /* A2, the middle register */,
                                            rr_cutoff_hz(cutoff, s_drones[0].fc_hz,
                                                         DRONE_CUTOFF_MIN_HZ,
                                                         DRONE_CUTOFF_MAX_HZ,
                                                         CUTOFF_MACRO_OCTAVES) > 1200.0f)));

#undef RW

    return written;
}