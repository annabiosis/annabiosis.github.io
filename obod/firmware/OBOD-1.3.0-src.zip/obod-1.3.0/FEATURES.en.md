[Русский](FEATURES.md) · **English**

# Guition Knob

A round synthesizer-controller on the ESP32-S3: a 360 × 360 dial, not a single tab and not a
single list menu. Everything the instrument has lives on the rim and on the pages that are
flipped through by swiping.

## Hardware

| | |
|---|---|
| Microcontroller | ESP32-S3, 240 MHz, 8 MB PSRAM, 16 MB flash, two 4 MB OTA slots |
| Display | round 360 × 360 LCD, ST77916 over QSPI, capacitive touch CST816S |
| Audio | PCM5100A DAC on the output, PDM microphone on the input, 48 kHz |
| Feedback | RGB ring around the perimeter |
| Debugging | USB-Serial-JTAG: log and flashing over one cable, no adapters — while note input over USB is off (setting **MIDI IN**, factory OFF). Turning the input off on the fly does not bring the debug port back: it is in place again only after the device is rebooted |

## Sound

Engine: 48 kHz, **24 voices**, **6 buses**, 500 Hz control rate, 128-sample block.

- **Drone** — three spectral parts (LOW, MID, HIGH), **a waveform of its own for each** (three
  knobs, H.OSC, M.OSC and L.OSC; SIN, TRI, SAW, SQR, SPR, NSE), a filter with sweep (cutoff,
  resonance, rate 0.04–8.4 Hz by registers, for LOW
  0.050–6.000 Hz, sweep depth up to four octaves with the DEPTH knob and up to six together with
  WIDTH) and modulation: panorama drift 0.029–7.161 Hz
  by registers, for LOW 0.031–6.000 Hz, the wandering accelerates eightfold
- **The drone follows the lead on request (FOLLOW)** — the drone has its own base, one for all
  three modes: 55, 110 and 220 Hz by register. ROOT does not move it — the knob names the scale
  and its tonic — and the drone is brought into the key through the scale. The list runs SCALE,
  CONS, FULL. SCALE (the factory setting) follows the newest lead note's pitch class in the
  nearest direction, within half an octave, and keeps its register. CONS takes only a consonance
  above the base — unison, third, fourth or fifth — and on anything else the drone stands where
  it stood. FULL is the only mode in which the drone leaves its register: the whole interval,
  octaves included. The shift is smoothed by the same 8 ms pole as the pitch itself, so changing
  the mode and changing the note do not click
- **The lead's tonic spans seven octaves**, C1..C8 (MIDI 24..108): 85 detents a semitone apart,
  the readout is the note name. The drone is not transposed by the tonic: it has its own
  55/110/220 base, and only FULL drives it down. A register that falls under 16 Hz is
  **turned down by level**, not lifted by an octave — the pitch stays the arithmetic of the
  base and the shift, which is why FOLLOW behaves the same over the whole range
- **Lead** — waveform selection (the same six), pitch, envelope, note generator, arpeggiator,
  Euclidean grid. Waveforms for both parts: SIN and TRI are the engine's own generators, SAW and
  SQR are PolyBLEP anti-aliasing tables (the engine's built-in saw is naive and aliases heavily,
  and the drone is held for minutes), SPR is the same three saws with detuning spread threefold,
  that is a supersaw of three voices rather than seven, NSE is the engine's noise, with an
  independent stream per voice, so nine drone voices give a haze rather than a single hiss; it
  also goes through the part's filter and envelope. The default is SAW, that is the factory
  sound; changing the waveform restarts nothing, so it can be selected on a sounding drone, and
  when several shapes change at once the morph goes one voice at a time, 20 ms apart
- **The lead filter's envelope is an AR, not an ADSR.** Two stages: a rise to the top and a
  fall back. Its length is its own, not the note's: a quarter at the tempo times GATE, with a
  three-second ceiling — the sixteenth that used to serve as the note's length is too short
  for a slow stage (62 ms at 120 BPM). The SHAPE knob on LEAD TONE splits that length between
  attack and release: at the bottom an instant attack and the rest in release, in the middle evenly,
  at the top the rest in attack and an instant release. The envelope is one-shot: the fall
  begins as soon as the rise reaches the top, so the filter is closed by the end of the note
  at any SHAPE. It is triggered by the gate's rising edge, not its level: on the level it
  would restart in every block while the note is held
- **The ENV depth is measured to the stops, not in octaves on a scale.** −100 closes the
  corner to 20 Hz, +100 opens it to the ceiling (0.45 of the sample rate, about 21.6 kHz),
  0 leaves the corner where CUTOFF put it. The octaves are counted from the current corner
  with the key tracker, so the stop is reached at any CUTOFF: the knob is a share of the way
  to the edge, and the edge is always the same
- **The four LEAD ENV knobs are the amplitude, not the filter.** ATTACK, DECAY, SUSTAIN and
  RELEASE write the lead voices' own envelope; the factory values are 40 ms, 250 ms, 0.86 and
  500 ms, which are the ones the voices sounded with before the knobs existed. RELEASE is
  also the number that keeps the output open for a note that arrived over MIDI
- **The lead has four notes.** A note's group is three voices (two detuned saws and the sub),
  twelve for four notes, plus the arpeggiator's group: exactly the engine's twenty-four
  voices. The fourth is for a long attack and a long release — they have to ring while the
  next note starts. How many of them are in use is the VOICE knob: four in POLY, one in MONO,
  and in CHORD one per note of the chord
- **POLY, MONO and CHORD on the LEAD page, its fourth knob.** The knob's order is POLY, MONO,
  CHORD, and the zero of the scale means POLY: this is how a sound stored before the third
  position existed reads back. POLY is four voices: a step that arrives while the previous tail
  is still sounding takes the next group, and a chord on the keys is heard whole. MONO is one:
  every note retriggers the same three voices, a release is cut by the note after it, and a
  chord is heard as its newest key. CHORD has one note sound as three scale degrees a third
  apart, each in its own group, so the chord holds instead of stopping on the second tone; the
  levels 0.70, 0.55 and 0.55 keep the root ahead of the rest. Turning it to MONO closes the
  extra groups at once rather than waiting for them to finish: a lead that is still sounding
  four notes is not monophonic
- **Sequencer steps overlap.** The line used to be one voice for the whole generator: every
  step retriggered the same three voices and a long release was cut by the next step — at
  120 BPM a step is 125 ms, so of a two-second release the same 62 ms was heard. Now a step
  that arrives while the previous tail is still sounding takes the next group, and up to
  four notes of the line sound together; the fifth takes the oldest. Each note's gate is
  counted on its own group, and the group is released at the end of the amplitude release
  rather than at the end of the gate: otherwise the tail would be cut. PORTA glides from the
  previous note of the LINE, not of the same group. The arpeggiator is still one note at a
  time — it plays in its own group, and that is the price of a staircase being a line rather
  than a chord
- **There are twenty-one scales**, and they stand in order of consonance: from both pentatonics
  through the church modes to the diminished and the chromatic one. The criterion is a count and
  not a taste: how many semitone steps a scale has and whether its tonic holds a third and a
  fifth. The five added are the Eastern ones — IN-SEN, NIKRIZ, HIJAZ, SABA and PERSIAN — and each
  stands where that same count put it rather than at the tail of the list. The position in the
  list is the value of the SCALE parameter stored in the preset, so the reordering costs a
  migration: both the remembered patch and every record in the store walk a "old position → new
  position" map once, and a saved sound keeps the scale it was saved with. **CHROMATIC** — all
  twelve degrees, that is a scale that quantizes nothing
- **A received note on channel 1 is pulled to the selected scale** relative to ROOT: the nearest
  degree is taken, and at equal distance the lower one, and the result goes further both into the
  direct voice and into the arpeggiator ladder and into the drone harmonization, so they do not
  diverge from what is heard. On **CHROMATIC** the note passes bit for bit. This does not touch
  percussion: on channel 2 the note sets the pitch of the hit, not a scale degree, and the hit
  has its own quantizer — **PERC QUANT** — which is off by default
- **Percussion is a kit and a groove.** The drum section is arranged the way a drum machine
  is: **the kit is the sound**, **the groove is the part**. A kit is twenty-eight sets of four
  lanes (kick, snare, hat, tom), each with its own recipe and its alternate voice (open hat,
  rim, tight kick, higher tom): from the dry TIGHT to the long DEEP, from BRUSH to MACHINE and
  STEEL, and behind them eight characters with no relative among the first sixteen — GLASS and
  BOX with no bottom at all, the eighties NEON, the one-kick SUB, the wooden WOOD, the
  middle-heavy GRIME, the toy TIN and the heaviest thing in the list, INDUS. **The last four are
  the deep end**: ABYSS at 35 Hz, the very floor of the voice, with a gate of a second and a
  quarter and a fall across nearly the whole of ENV; SLUDGE is the same idea slower and thicker,
  a 38 Hz kick at 1.46 s; MONK is a ritual on metal instead of skin, its hat ringing over the
  next beat; VOID is a kick and the air around it, the other three lanes almost switched off.
  A groove is twenty-four written patterns of sixteenths: MINIPOP, DISCO, BOOGIE, ROCK, FUNK,
  BREAK, HOUSE, TECHNO, TRAP, HALF, TWO STEP, AFRO, LATIN, MARCH, BOSSA, GARAGE, CLUB, and then
  seven IDM bars where the grid is there and the part disagrees with it: SKIP (the kick
  stutters), STUT (the snare doubles), GRIT (off-grid steps, three bars to the repeat), WOBBLE
  (kick and tom limp a step apart), SPLIT (the backbeat a sixteenth early), RUST (a machine
  repaired while it plays) and DRILL (three-three-two across the bar); each with its own ghost
  notes and its own cycle of bars
- **PERC is the timbre.** KIT picks the set, TONE transposes the whole kit, TUNE only the kick
  and the tom (so the kick sits in the key while the hat stays a hat), DECAY scales every
  gate, PUNCH the attack of the hit — long and soft at the bottom, short with the beater's
  click at the top — and TIMBRE is the life: how much a harder hit brightens and lengthens it,
  the per-hit jitter, the slow walk of pitch across bars, and how often a lane takes its
  alternate voice
- **PERC SEQ is the part.** GROOVE picks the pattern; FILL closes the last bar of the cycle
  with a fill; SWING delays every second sixteenth; ACCENT is the pattern of the loud steps
  (below).
- **There are six fills, and they differ.** A snare roll in sixteenths, snare on the eighths
  with the tom between them, a tom roll, kick on three and four with the snare around it, a
  single pickup on the third beat with air after it, and one hit with the kick followed by the
  last beat. The figure is chosen on the bar the fill is decided and never comes twice in a
  row. The second half runs from quiet to loud — one ramp for all six, which is what makes any
  of them lead into the next bar. The first half stays as written: the bar walks into the fill
  rather than being cut off by it.
- **VAR is a move per cycle, not a wobble per bar.** On the first bar of a cycle the knob
  picks one of four moves with probability VAR and holds it for the whole cycle, so a four-bar
  phrase sounds like one thought rather than like four different drummers. The moves: ghost
  sixteenths under the written part, a kick on the & of the third beat, a snare on the a of the
  fourth as a pickup into the next bar, and the quarter-note hats dropped so the bar opens up.
  At a high VAR a second move joins the first. The first cycle is always the written part, so
  the player hears what they chose before hearing it changed. No move touches the downbeat, and
  none puts a loud hit on an odd sixteenth — those are the ones SWING moves, and a loud hat
  there sounds like a lost grid. SPEED moves only in twos — ×0.25, ×0.5, ×1 and ×2 — and a change of speed
  waits for the bar line and re-anchors the drum's count on it once, so the drum never argues
  with the rest of the instrument
- **A fader at zero is silence.** PERC on LEVELS closes the voice and the sends together: at
  zero a hit takes no voice at all, so neither a dry hit nor a reverb tail survives it
- **The ring on PERC SEQ is the part.** Sixteen dots around the circle say what sounds on each
  sixteenth of the bar, and every lane is drawn its own way: the kick is a large amber disc,
  the snare a smaller white mark, the tom a teal one, the hat an outline ring — a surface
  rather than a hit — the ghost note a small dot, and silence the darkest mark on the ring. A
  FILL is a large hollow ring in the cursor's colour, because it is a different event and not a
  louder hit, so the second half of a fill bar is unmistakable. The accent takes four pixels
  off the steps it does not mark. The dots follow what is played: a change of GROOVE shows at
  once, while VAR and FILL move the bar at the next bar line. The LED ring repeats the same
  picture in brightness
- **The old hit knobs** — PITCH, QUANT, ENV, BODY, DECAY, STEPS, PULSES and ROTATE — keep
  their numbers and their places in old patches, but the voice is set from the kit now and
  those values no longer move it. BODY's place on the page is PUNCH now, and that is another
  knob: that one was the tone's share of the hit, this one its attack. STEPS still decides the grid the groove is stretched onto,
  ACCENT still decides which steps play softer, and the drum's RESET is still a parameter with
  no knob
- **The accent pattern** — the ACCENT knob, and it sits on **two pages**: on PERC SEQ for hits
  and on LEAD EUCLID for lead notes. There are **two parameters**: the hit grid has its own
  pattern, the lead grid its own, and the knob on one grid does not move the other. The list has
  eight patterns, OFF and seven named ones. The pattern decides **which** beats play
  weaker, and **how much** weaker is the **WEAK VEL** setting on the OPTIONS page: integers
  0..127, factory value
  80. A marked hit stays at 127, the rest go to WEAK VEL, that is at the factory value almost
  4 dB lower (20·log10(127/80) = 4.01 dB; on a dense pattern the hits share the limiter knee,
  and by ear the difference is slightly smaller — no separate number was measured for the
  pair 80). Both edges of the setting are meaningful: **127** — there is no difference at all,
  the pattern is selected but will not be heard; **0** — there are no weak hits, the engine
  reads zero velocity as "there was no hit", so only the marked beats sound. The accent is made
  by weakening the weak ones rather than by raising the strong one: the median hit is already
  normalized almost up to the limiter knee, and a raised accent would be the limiter's answer,
  not the player's. OFF is the factory value of the knob, and then all hits go to 127, exactly
  as before this knob, and all lead notes open at their factory 70/70/55 — bit for bit the same
  sound. Patterns: **1/4** (beats 1, 5, 9, 13), **2&4** (5, 13), **OFFB** (3, 7, 11, 15),
  **3-3-2** (1, 7, 13), **FUNK** (1, 4, 7, 10, 13, 16), **RMB** (1, 4, 7) and **BOS** (1, 4, 7,
  10, 13); the full names — QUARTER, OFFBEAT, FUNK16, RUMBA and BOSSA — stayed with the figures
  in the code. The short form is what the sector prints: the long word reached the dot ring.
  Beats
  are counted from the first beat of the bar, so the pattern **does not travel with ROTATE** —
  the accent stands on the beat while the Euclidean figure beneath it rotates; it **does not
  stretch** with the number of steps either: at seven steps the quarters keep only 1 and 5,
  everything that went beyond the bar does not participate. Each part counts beats on its own
  grid: the lead has its own STEPS, the percussion its own, and each has its own figure — only
  the list of names is shared. On
  the screen a marked step is marked with a larger dot, for the lead too. **The arpeggiator reads
  the accent**: its note goes at the level of the place in the bar its step falls on, so marked
  beats sound loud and the rest go at the WEAK VEL setting, and the ring of dots under the
  ARP IS ACTIVE notice is exactly the picture it reads. The division does not matter to this: a
  1/16 step lands on a sixteenth and a 4/1 step lands on the first beat of its bar, and one and
  the same figure answers both. The arp still has no figure of its own, so it still does not play
  the lead grid
- **RESET — two gestures, one per sequencer** — a RESET knob on the LEAD EUCLID page and a
  parameter of the drum that no longer has a knob of its own: INF, 16, 32, 64, 128 or 256
  steps of ITS OWN grid, after which that part begins its phrase at the first step. There is one bar position for the whole
  instrument, and both parts take their step from it; each also has a beginning of its
  phrase of its own — an origin on its own grid — and only its own gesture moves it. The
  lead's gesture therefore does not shift the drum by a single block, and the drum's does
  not touch the lead: two independent variables, and the only thing they share is the
  position, which neither of them writes. The polyrhythm stays a polyrhythm at any pair of
  values. The lead begins its phrase at the first step at which its note has been let go,
  so nothing is cut: a sparse figure with a long gate is shifted a step after the count, a
  dense one exactly. The arpeggiator goes with the lead, because it is the lead's figure in
  place of the grid. The drum waits until its previous hit has rung out: its gate is DECAY,
  and a new hit on top of an old tail would double the step — at ROTATE zero the first step
  is an onset in every Euclidean figure, and with a rotation it can be a rest, where the
  wait costs one boundary. With a long DECAY and frequent hits the drum's gesture can
  therefore never fire; that is the price of the wait, and it is honest: nothing is cut and
  nothing is sped up. If N is a whole number of bars for the grid (16 on sixteen steps),
  the shift lands on the bar line and changes nothing audible; if it is not, the phrase
  returns early, and that is the gesture. INF switches the gesture off.
  Both are **sound parameters**, not settings: a preset carries them. A preset saved by a
  version without these fields reads as the **factory 16 for the lead and INF for the
  drum**: zero means INF for the drum, and "the field is missing" must not switch the
  gesture on
- **A change of the arp's speed waits for the bar line.** The division takes effect at once,
  and the figure is re-anchored at the nearest bar line and starts from its first note:
  without that, a new step length landed on the old phase and the lead hit the middle of its
  own figure, which sounds like a stumble rather than like a new rate. It waits one bar at
  most, whatever the division. DIR, RANGE and LEN do not wait: they change the shape of the
  figure and not its step, and the figure goes on from where it stood — that stumble was heard
  and kept on purpose
- **Modulation** — the MOD page: destination, shape, depth, rate and retrigger. There are nine
  destinations: FILTER, PAN, FILT+PAN, four percussion bindings (pitch, pitch with ENV, pitch
  with DECAY, all three together) and two for the lead (step pitch, and step pitch together with
  percussion pitch). There are eight shapes: SINE, TRI, SQUARE, SAW, RANDOM, EXP+ and EXP-, and
  the eighth is MIC. Both exponential
  curves live below zero: EXP+ falls from zero to minus one, EXP- rises from minus one to
  zero. MIC is not a shape but a source: the microphone envelope moves the filter and the
  panorama, DEPTH sets the depth, and SPEED means nothing, because the room has no phase. The
  envelope goes from zero upwards, so both the filter and the panorama move in one direction
  from their base. The modulation depth goes up to one hundred percent, factory value one
  hundred. There are three retrigger modes: FREE, NOTE and HOLD; a note means a lead note, that
  is a step of its sequencer. NOTE starts the shape anew on every note, HOLD takes the value on
  the note and holds it until the next one
- **The modulation generator** lives in the application: the LFO phase in synth_dsp cannot be
  reached from the application. The phase advances on percussion steps, one step equals one beat
  at the current tempo, and the rate is set by the SPEED knob: the generator takes it from LOW,
  so at the bottom 0.031 Hz, at the top 6.000 Hz — the same number the knob prints, and the one
  the panorama drifts with (for MID 7.161 Hz, for HIGH 5.613 — the same multiplier over its own
  37 and 29 mHz). The engine's filter LFO knows the first five shapes and plays RANDOM on the
  exponential one; on MIC it takes the microphone envelope instead of its own generator rather
  than substituting a shape; the exponential shapes belong to this generator
- **Modulation shifts are relative**: percussion pitch is the value of the PITCH knob plus a
  shift of up to a quarter of the range, ENV and DECAY up to half, lead step pitch is the note
  frequency multiplied by an interval in semitones, up to two octaves in either direction. The
  span of the panorama drift and wandering and the addition to the filter LFO depth are set by
  the WIDTH knob on the DRONE page: DEPTH alone gives up to four octaves, WIDTH adds up to two,
  together up to six on LOW (4.80 on MID and 3.60 on HIGH)
- **Effects** — chorus, ping-pong delay, reverb in four modes: ROOM, HALL, CATH and
  PLAT. The first three are three sets of settings of one Freeverb: line lengths, feedback,
  damping and input — so any of them costs as much as the previous one; all buffers are in
  PSRAM. All three work **as sends and in parallel**: each has its own bus, summed from the
  weights of the six parts, each processes only that bus and returns its answer beside the dry
  sound. The MIX knob on the effect pages is therefore a **return level, not a balance**: the
  dry path stays whole and the answer is added to it; at zero nothing is added at all. The
  sends live on three pages — REV SENDS, CHR SENDS and DEL SENDS — with five parts in one order:
   LEAD, PERC, LOW, MID, HIGH. The microphone is not among them: it no longer goes into the
   effects at all. The sixth reverb mode, GATE, is gone: the gate and its
   plumbing were removed entirely, and a mode nobody chooses only rots.- **Mixer** — master volume and master compressor as a separate first section, part levels,
  three send pages with five parts each: REV SENDS, CHR SENDS and DEL SENDS
- **No overdrive, and that is the point** — the instrument used to carry four shapers (SOFT,
  HARD, FOLD, TUBE), a DRIVE and an ALGO knob on the MASTER page, a per-bus level estimate and
  a compensation table so the character moved without the loudness, and a second knob for
  whether it sat before the effects or after them. All of it is gone, on the owner's decision,
  and what is left is the summing loop, the drum, the three effects, the compressor and the
  master: there is no saturation stage anywhere in the signal path, and nothing to switch off.
  Two facts are worth stating rather than hiding: the three parameters (DRIVE, ALGO, DRIVE POS)
  and the setting are still in the enums with their places untouched, because a parameter's
  number addresses every stored preset, so they are dead slots their appliers ignore and no
  page offers; and the MASTER page therefore has three knobs, VOL, COMP and DUCK, while SYSTEM
  has four.
- **Microphone** — a PDM microphone on the input, read one engine block at a time in the audio
  task, without a single memory allocation. There is one knob: sensitivity on the SYSTEM page.
  **The microphone no longer goes into the effects** - it is a modulation source only (the MIC
  shape on LFO moves the filter and the pan with the room's envelope). There is no MIC
  send on the SENDS pages, and the three send parameters are dead slots in the enum so that no
  stored preset shifts; those sends are written as zero. The AUX bus the input used to arrive
  on now carries nothing: its level has always been zero and its three sends are written as
  zero, so a patch saved with a microphone send turned up does not bring the input back.
  Sensitivity is software gain up to 6x (+15.6 dB) after the DC offset is removed, and it also
  normalizes the envelope; this chip has no driver gain (`amplify_num` exists only on P4 and
  S31, on S3 `bsp_audio_in_set_gain()` answers `ESP_ERR_NOT_SUPPORTED` and does not touch the
  channel), so sixfold is the entire sensitivity headroom, not an addition to the driver. Zero
  turns the microphone off entirely, and then the input is not read at all. The DC offset of the PDM
  part (about 1081 counts against 46 RMS of signal) is removed by a one-pole filter at 175 Hz in
  the application. The software gain raises the microphone's own noise along with the signal: at
  the upper edge of the knob the hiss is audible, and this chip has no analog gain. The limit
  here is set not by noise but by a clap: at unity gain it gives 0.115 of full scale, 6× puts it
  at 0.69 of full scale, and 8.7× — already into clipping
- **Master compressor** — one knob: threshold and ratio together, attack and release fixed
  (25 and 250 ms), soft knee 6 dB, sidechain filter 150 Hz; at the bottom of the knob it is off —
  and then the output stage is bit for bit the previous one
- **116 sound parameters** on **23 pages** — everything from one dial. Plus ten instrument
  settings that are visible as knobs too but are not part of a preset: brightness of the screen
  and of the ring, the ring mode, the microphone, what to do
  with the sound on power-off, the transition time, the random draw of the delay's time, USB
  note input, the wave morph time and the strength of an unaccented hit. There are 110 knobs on
  the screens, one for every parameter shown and none shown twice: the drum's ENV lives only on
  PERC, and the levels of the lead, the percussion and the three drone registers only on LEVELS.
  The part pages no longer carry those handles

## Interface

- the rim is divided into sectors according to the number of knobs on the page: one, two, three,
  four, five or six
- a tap on a sector selects a knob; **a long press merges the parameter into a macro**. Only the
  encoder changes the value — for knobs and for settings, including **MIDI IN**: a tap on the
  sector only selects it
- **a macro** is a live link, not a preset: several parameters are driven by one knob,
  and each of them is marked in red both on the sector and on the tile of its section
- only timbre parameters go into a macro: hardware settings — brightness, ring, screen — are
  neither added to a macro nor moved by a macro
- **a double tap** on a parameter that is already in a macro enables **inversion**: the parameter
  moves against the macro, and all its markers become yellow instead of red
- on the lead grid page, when the arpeggiator is on, the text
  `ARP IS ACTIVE` appears in the center: the grid does not play at that time, and its knobs
  change nothing
- a left-right swipe pages through the pages; a downward swipe opens the **shade** — a map of
  sections as a mosaic of colored areas that covers the whole disc; an upward swipe from below
  opens the **transport screen** — a 160 px (20.9 mm) stop/play button, and while it is open
  nothing beneath it accepts input
- the transport button holds its state color: green when running, red when stopped
- **the transport screen mirrors the actual tempo**: the tick ring and the BPM label show the
  tempo the instrument is playing at right now — the tempo from the wire while the clock is
  running, and the knob value when the clock is gone. The ring is built from the same ticks as
  the page rings: a 6 px step, a 2 px body, filled clockwise from the top. The knob and the
  writing of the tempo into the patch work as before
- in the center of the page, above the title, **pagination dots**: you can see where the page is
  within its family, the current one is marked by size
- **eight color families**: body, voice, generation (teal), percussion, effects, mixer,
  presets, service
  and presets — the color says what the section belongs to before the name is read
- **the indicator ring** in four modes: the value of the selected knob, the stereo picture,
  light show (color and brightness by what is playing and where it sits), off
- the selected sector is filled with the shape of its sector in the family color, its rim is
  brighter
- **128 slots** in NVS, two-word names, a PRESET page with a list in the center
- **LOAD / SAVE / RND**, the SAVE button blinks while the sound differs from the slot. The
  buttons and the rows have an 8 px (1.05 mm) reaction field, so a touch near the edge still
  lands on them, while the list itself is not clickable — a preset is chosen with the wheel and
  a swipe
- **random sound in two depths**: a short press — timbre only, a long one — timbre
  together with the structure (grids, arpeggiator, effect mixes; sends
  send, are never randomized)
- **what the draw does not touch**: the tempo, the drum's speed, the lead's portamento and the
  rotation of the euclidean figure. Those are decisions about playing rather than colours of the
  sound: a new sound must not arrive with the tempo already moved, the drum in half time, a slide
  under every note, or the figure displaced off the beat
- presets **survive a firmware change from the command line**: the storage is no longer cleared
  by the image fingerprint. The format version is stored in a separate record; a slot written in
  an incompatible format is not read and stays in place, and one line about this goes to the
  log. Browser flashing uses a merged image from address zero and overwrites the settings area:
  with it, presets and settings are lost
- the **PATCH** setting: FORGET, STORE, RANDOM. In RANDOM mode the instrument invents a
  new sound at every power-on, so the **factory value is STORE**: a device that has
  never been set up must power on with the sound it was left with. Boards whose
  memory holds the old factory RANDOM are switched to STORE once, on the first
  run of the new firmware: otherwise "nobody touched it" cannot be told from "chosen
  deliberately", because the old value was written by the very same default. Whoever turns
  RANDOM back on will have it saved — the transfer is done exactly once, by a separate mark in
  NVS
- the sound is stored **on change, not on a timer**: any knob, macro, RND and preset load sets
  the mark, and the value goes to flash 2 s after the last movement —
  one gesture gives one write, not one per click. In addition, once every half second
  the UI compares the 116 sound parameters with the last mark and picks up everything that went
  past those paths: a preset load goes straight into the engine, bypassing the common writer.
  Two minutes of idle gave not a single write — the panorama drift lives inside the engine and
  does not reach the parameters
- **the tempo lives apart from the patch**: it has its own key in NVS and therefore comes back at
  power-on whatever the PATCH mode says — RANDOM draws a new sound while the tempo stays where it
  was left. It is written by the same debounce as the sound, read before the boot draw and applied
  after it
- **write debounce**: 2 s after the last movement. It used to be armed via
  `esp_timer_restart()`, and that **does not start an unarmed timer** — it returns
  `ESP_ERR_INVALID_STATE` and exits — and the one-shot timer is unarmed exactly at the moment
  when it fired. Before this fix nothing at all got to flash: neither settings nor patch.
  The `patch_mig` key in NVS looked alive only because the preset module's `nvs_commit`
  commits the whole page and drags along other people's uncommitted keys
- the sound is stored in NVS as a single blob: a `uint16_t` with the number of values and a `float`
  array. Between them there are two bytes of alignment, so the length is written as
  `offsetof(value) + n·4` rather than
  `sizeof(count) + n·4`: otherwise the last of the 116 parameters goes to flash half-written and
  comes back half from garbage on the stack. Reading rejects a blob that is shorter than
  the values read from it — a short blob is not silently restored
- the **SLIDE** setting: OFF / 0.2 / 0.5 / 1.5 / 3 s — how long new values
  take to arrive. Preset load and RND do not substitute the sound but lead it to the new one: the
  starting point is taken by the audio task itself from what is sounding now, and only a flag
  and a duration cross the task boundary, so there are no races by construction. A second slide
  moves from the current position rather than jumping to the start. List parameters (reverb mode,
  scale, root, steps, delay sync, arp direction and rate) and settings switch instantly:
  a mode is never "half", and a setting is not part of the sound
- four parameters **changed the meaning of their value**, so the stored sound in flash
  is rewritten once, under the `param_mig` key in NVS (flag and values in one
  `nvs_commit`, otherwise the flag would survive a power failure but the values would not). The
  division lists expanded from five to thirteen (ARP SPEED) and twelve (DELAY SYNC), and the
  position in the list is `round(v·(N−1))`, so the conversion goes **by division name**, not
  arithmetically: the old delay 1/8 was index 2 of 5, its 0.5 against the new list is
  index 6, the dotted eighth. The delay division list now starts at 1/1 (nothing longer than a
  whole), the arp's at 4/1. PERC PITCH: floor 55 → 35 Hz, range 7.00 → 7.65
  octaves, equal pitches give `new = old·7.00/7.65 + log2(55/35)/7.65` = `old·0.9150327 +
  0.0852388`; PERC ENV: depth ceiling 3 → 5 octaves, that is `old·3/5`. Check: the old
  0.28 and 0.45 give 0.3415 and 0.27 — exactly what synth_app already holds as factory
  values. The indices of the four parameters are written out in `app_settings.c` as numbers
  (`synth_app.h` cannot be included there — that is a cycle), and in `synth_app.cpp` next to
  the list there are `static_assert`s on the same numbers. Presets are not touched by this:
  the conversion concerns only parameter values, while the storage format is versioned
  separately and does not erase slots on a firmware change
- **the patch grew from 84 to 88 parameters**, and a record older than that growth is read
  whole rather than refused: the blob's length is a prefix of the list, so a record of 84 values
  yields the same 84 values in their places. The four new ones get: the three shapes — the old
  shared `DRONE_WAVE` value (the very byte that was index 22), FOLLOW — the factory SCALE. The
  root is **recomputed by note**: its scale used to be 45..69 and is now 24..107, and a stored
  0.5 meant A3 rather than F#4, so the conversion goes through the note number and the sound
  stays what it was. No migration flag is needed for this: the conversion is idempotent, and a
  record in the new format (88 values) takes the common path without any recomputation. Checked
  on eight old presets in the live instrument: after loading, only the ROOT byte differs, and the
  note is the same for all eight

## Settings

- **SYSTEM** (SYS tile): SCREEN (screen brightness), RING (ring brightness), RING FX
  (ring mode), MIC (microphone sensitivity) — four sectors; the fifth was where the overdrive
  sat in the rack, and it left with the overdrive
- **OPTIONS** (OPT tile): PATCH (what to do with the sound at power-off), SLIDE (how long
  new values take to arrive), RND DEL (whether the random sound touches the delay time and sync),
  WEAK VEL (velocity of a non-accented hit: integers 0..127, factory 80, and 127 —
  no difference, and 0 — no weak hits at all), MIDI IN (note input over USB: OFF — factory —
  and ON), MORPH (how long a voice takes to move from one waveform to another: OFF, then
  5, 10, 15, 20, 25, 30, 40, 60, 80 and 100 ms, factory 25 ms; OFF is the shape changing in
  one sample, as it was before this setting). Settings are stored separately from the sound,
  do not get into
  presets and are not moved by the random sound. RESET is not a setting but two sound
  parameters, one per sequencer: on LEAD EUCLID and on PERC SEQ. There is no RESET sector in
  SYSTEM any more

### Moving between waveforms

- **MORPH, factory 25 ms** — the time a voice takes to move from one waveform to another. A
  shape is a list, and a list arrives in one step: without a transition, changing the shape
  on a sounding drone is heard as a click. The smoothing lives in the voice rather than in the
  parameter: for the length of the transition the engine renders the voice twice — through the
  old shape and through the new one — from the same phase, and adds them with a weight that
  travels from zero to one, so the pitch does not move
- **covered: DRONE and LEAD**, including a preset load: a shape stored in a preset arrives over
  the same transition. The drone has a shape of its own for each of its three registers (H.OSC,
  M.OSC, L.OSC), and only the register whose shape actually changed starts one: a knob turned
  onto the position it already holds changes nothing
- **boundaries**: SUPERSAW is not a separate shape but the same saw on three detuned voices, so
  a change into or out of it is instant (a step of no more than fourteen cents); wavetables,
  samples and streams cannot be rendered twice by the engine, so on them, as on tracker
  instruments and the sequencer, the shape changes at once
- **turning the knob faster than the transition** does not build a queue: a voice runs one
  transition at a time and holds one request for the next, the request is replaced, and the
  running transition is never cut short. That cannot click either, but the sound is at most one
  transition behind the knob
- **the voices enter the transition one after another**, twenty milliseconds apart: a voice's
  delay is its index among the drone's nine times 20 ms — 0, 20 and 40 ms in the first register,
  60, 80 and 100 in the second, 120, 140 and 160 in the third. Even with all three shapes changed
  at once no more than one transition starts per 20 ms, so the nine voices do not add up to a
  click, and changing all three registers takes 160 ms from the first voice to the last

### Note input over USB

- **MIDI IN, factory OFF**, and this is a setting about the port, not about the sound:
  USB-Serial-JTAG and USB-OTG are two controllers behind one PHY on this chip, so while the
  application brings up USB-MIDI, the USB connector on the computer is a MIDI port, and the
  debug port (COM) and the log from it disappear
- **enabling on the fly** does not require a reboot: the USB connector on the computer becomes
  a MIDI device, the port "OBOD MIDI IN" appears, the debug port disappears from the computer
- **disabling on the fly** removes the MIDI device, the driver is unloaded, the USB controller
  is released, but the debug port does NOT come back on the fly: it returns only after
  the device is rebooted with note input off. What exactly `usb_del_phy()` promises for the
  debug port is written in `midi_in.h` honestly: the PHY is released, while the enumeration of
  the console by the host is on its side, and on real hardware the host does not bring it back
  up
- **flashing without buttons follows the same order**: turn off note input, replug USB, after
  boot the debug port is in place again, and esptool enters the bootloader by itself. The ROM
  bootloader and esptool do not depend on the MIDI mode
- notes are read by channel: channel 1 is the lead, channel 2 is percussion, the other fourteen
  are discarded. A channel 1 note is pulled to the selected scale before sounding,
  percussion is not (see "Sound")
- **transport from the wire is accepted**: 0xFA is start, it enables the transport and puts
  the sequencers at the beginning of the phrase; 0xFB is continue, it enables without resetting
  the position; 0xFC is stop. Stop works by the previous rule: the sequencers and percussion do
  not open notes, while the arpeggiator keeps sounding on held MIDI keys, as those notes
  themselves also sound. The other bytes, as before, are discarded
- **clock from the wire is accepted**: 0xF8, twenty-four ticks per quarter. The tempo is
  estimated over a window of one beat with smoothing and is limited by the bounds of the tempo
  knob (30..300 BPM). While the clock runs, this tempo substitutes for the knob value for the
  two Euclidean sequencers, the arpeggiator and the modulation generator. The patch parameter is
  not rewritten, however: the tempo from the wire does not get into the preset, and about a
  second without ticks later the tempo is taken from the knob again. Note input has no new
  settings and no new patch parameters: it works when note input on OPTIONS is on
- **what is accepted and what is discarded**: note-on and note-off with velocity are accepted,
  and a note-on with zero velocity is considered a note release, as is a note-off with any
  velocity. Of the real-time bytes, four are accepted: 0xF8, 0xFA, 0xFB, 0xFC.
  The rest is recognized and discarded: control change, pitch bend, program change,
  aftertouch (channel pressure), system common, SysEx and notes on channels 3..16. The device
  does not react to control change in any way, so CC 123 (all notes off) does not release notes,
  and it has no other way to release all notes from the wire. The message handler
  (`midi_message()` in `components/midi/src/midi_in.c`) knows only note-on, note-off and these
  four bytes, while `synth_app` exposes only `synth_app_midi_note_on()`,
  `synth_app_midi_note_off()`, `synth_app_midi_clock()` and `synth_app_midi_transport()`;
  there is no other path for an incoming message into the sound in the code
- **the setting does not go into a macro or into the random sound**, like the others: it is not
  part of the timbre

## Update

- **the instrument has no network**: at startup Wi-Fi is not brought up and no access point
  appears — updating only over the wire, via the browser firmware page or `idf.py flash`
- **the update channel is not connected, the scaffold remains**: the `app_net` component
  (provisioning and OTA with rollback) is not removed and still builds, the two 4 MB OTA slots
  and image confirmation are in place. It is turned back on with one line — `APP_NET_BRINGUP`
  in `main/main.c`

## Under the hood

- real-time budget: **2.67 ms** per block; in typical mode a block is computed
  in about 1.3 ms
- **22 areas** in the shade — a weighted Voronoi mosaic: equal areas of 4617..4619 px², cut and
  baked once at power-on in 155 ms into a 360 × 360 image;
  **23 pages**, **116 sound parameters**, **110 on-screen knobs** — one per parameter shown, none
  shown twice: the drum's ENV only on PERC, part levels only on LEVELS, and ACCENT, though named
  alike, is two independent figures for the lead and the percussion; the knobs of the settings
  add a knob without adding a patch parameter; eight color families
- **master compressor**: the gain curve is computed once every 16 samples (3 kHz) with
  interpolation between them. The per-sample variant was measured at 1.1 ms
  per block against a budget of 2.67 ms — `log2f`/`exp2f` are software on this chip; after
  the fix the addition is within the noise (steady `dsp` 1240–1324 µs against 1229–1303 before
  it)
- the application occupies **1 191 728 bytes**, the merged image for flashing is **1 322 800
  bytes**, **72%** of the application partition is free
- stack: **ESP-IDF 6.1**, **LVGL 9.6**
- the integrity of the page tables and rim layouts is checked by static assertions
  in the code and by a script before the build

## What is not there yet

- Bluetooth-MIDI — decided not to do it
- blinking of the transport button in tempo — dropped: the indication is polled once every
  25 ms, the pulse lies by tens of milliseconds, and a lying metronome is worse than none
- a beat pulse on the RGB ring — an idea for later: overall brightness down, so as not to
  interfere with the existing indication. It must be done from the exact phase of the engine
  rather than by polling, otherwise the same unevenness results for which the metronome on the
  button was dropped
- **the remaining reverb algorithms** — four modes already exist: three sets of SETTINGS of one
  Freeverb and the **Dattorro plate**, which is already a different topology. The plate was made
  from the numbers of the paper, verified line by line against the port (el-visio/dattorro-verb),
  and the verification was not in vain: the first version placed the modulated allpass AFTER the
  delay rather than before it, and took all seven taps of the channel from the opposite half of
  the tank, whereas in fact four are taken from the opposite one and three from its own. Three
  numbers in it are deliberately not from the paper, and they are named right in the file: the
  lengths are scaled to the rate (the port runs them without scaling, which makes its hall
  1.6 times shorter than the author's), the modulation is a sine instead of a triangle, and
  DAMP and SIZE map to the damping of the tank and to the decay. What remains are third
  topologies:
  - **Jot's FDN** on eight lines with a Hadamard matrix — the matrix is only additions
    (a fast Walsh transform), and there are eight lines, that is fewer PSRAM accesses than in
    Freeverb. It is a modern "natural hall"
  - **spring** — a chain of diffusing allpasses: cheap, with its own recognizable character
  - **shimmer + and shimmer −** — as requested, without extra knobs: the tail travels up or down
    an octave. Of the whole list it is the most expensive, and here is why: for the shimmer to
    accumulate, the shift must be placed in the reverb loop, not at the input — a shift at the
    input gives a harmonized input, not a shimmer
  - **convolution with an impulse — out of the question**: two seconds of stereo is 768 KB and
    96 thousand multiplications per sample. There is nothing close to that in the budget
- **a new topology should be done only with ears on the instrument**: a new feedback loop is a
  new question about stability, and no number settles it
- for any addition in the reverb the rule is: **measure on the block, not by ear**. An instrument
  with three long drum tails already takes about 2.0 ms of 2.67, and extra accesses to
  PSRAM in that place cost exactly the crackle that we have just cured. The line pool is therefore
  one, cut for the widest mode, and it never moves: the forty to ninety microseconds a block that the
  lines cost in external memory are cheaper than the three to six milliseconds a move would cost on
  every change of algorithm

## Attribution

- **The synth voice is ESP32Synth 2.5.0**, author Danilo Gabriel, MIT license (Copyright (c) 2025
  danilogcrf2-oss), source https://github.com/danilogcrf2-oss/ESP32Synth. It sits in
  `components/synth_core` as is plus edits for ESP-IDF 6.1 listed in
  `components/synth_core/PATCHES.md`. Taken from the library are the voice engine, the buses, the
  built-in integer DSP and the anti-aliasing tables `AA_Saw` and `AA_Pulse`: the SAW and SQR
  waveforms in the instrument are them
- **Our layer** is written by us: `components/synth_dsp` (stereo after the engine, the drone and lead
  filters with their own LFOs, percussion, the effect rack), the modulation generator,
  `components/synth_ui` and `components/synth_app`. The library provides the voice, the rest is
  done here

The Russian text in [FEATURES.md](FEATURES.md) is the source; if the two diverge, the Russian one is right.
